const { resolve } = require('path');

module.exports = function(config, env, merge) {
  const developConfig = merge(config, {
    resolve: {
      alias: {
        components: resolve('./src/components'),
        constants: resolve('./src/constants'),
        containers: resolve('./src/containers'),
        imgs: resolve('./src/imgs'),
        pages: resolve('./src/pages'),
        services: resolve('./src/services'),
        utils: resolve('./src/utils'),
        mambaWidget: resolve('./src/mamba-widget'),
      },
    },
    module: {
      rules: [
        {
          test: /\.(png|svg|jpe?g|gif|woff|eot|otf|ttf|woff2)$/,
          use: [
            {
              loader: 'file-loader',
            },
          ],
        }
      ],
    },
    // devtool: 'cheap-module-eval-source-map',
    devServer: {
      host: 'my.console.aliyun.com',
      port: 3001,
      proxy: {
        '/data/api.json': {
          target: 'https://pre-mse.console.aliyun.com/',
          pathRewrite: { '^/': '/' },
          changeOrigin: true,
          secure: false,
          withCredentials: true,
        },
        '/sp': {
          // target: 'https://mocks.alibaba-inc.com/mock/service-authentication',
          // target: 'http://edas.console.aliyun.com:84/',
          target: 'http://edas.console.aliyun.com/',
          pathRewrite: { '^/': '/' },
          changeOrigin: true,
          secure: false,
          withCredentials: true,
        },
        '/install_package': {
          target: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/',
          pathRewrite: { '^/': '/' },
          changeOrigin: true,
          secure: false,
          withCredentials: true,
        },
      },
    },
  });
  const productConfig = merge(developConfig, {
    // module: {
    //   rules: [
    //     {
    //       test: /\.(png|svg|jpe?g|gif)$/,
    //       use: [
    //         {
    //           loader: 'file-loader',
    //         },
    //       ],
    //     }
    //   ],
    // },
    externals: [
      {
        lodash: 'lodash',
        moment: 'moment',
        // bizcharts: 'bizcharts',
      },
    ],
  });
  return env.mode === 'development' ? developConfig : productConfig;
};
