import React, { useState, useEffect } from 'react';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { Select, Icon } from '@ali/cn-design';
import { head, map, find, assign, filter } from 'lodash';
import PropTypes from 'prop-types';
import services from 'services';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const AppTagSelector = (props) => {
  const { value = {}, onChange, namespaces } = props;
  const [appId, setAppId] = useState(value.appId);
  const [searchValues] = useGlobalState('searchValues');
  const [appList, setAppList] = useState([]);
  const [tagList, setTagList] = useState([]);
  const [isLoadingApp, setIsLoadingApp] = useState(false);
  const [isLoadingTag, setIsLoadingTag] = useState(false);

  const intl = useIntl();
  const { regionId, namespaceId } = assign({}, searchValues, MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? namespaces : {});
  const currentAppList = [];

  useEffect(() => {
    setAppId(value.appId);
  }, [value]);

  useEffect(() => {
    fetchAppList({ pageNumber: 1, pageSize: 50 });
  }, [namespaces]);

  // 这个是分页接口，但是需要拿到全部数据
  const fetchAppList = async ({ pageNumber, pageSize }) => {
    setIsLoadingApp(true);
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      let { data = [] } = await services.GetAppList({ params: { regionId, namespaceId } });
      data = filter(data, item => item.regionId === namespaceId);
      const newData = map(data, item => ({
        ...item,
        key: item.appId,
        value: item.appId,
        label: item.appName,
      }));
      if (!value.appId || !find(newData, item => item.value === value.appId)) {
        const firstItem = head(newData) || {};
        handleChangeAppId(firstItem.value);
      } else {
        handleChangeAppId(value.appId);
      }
      setAppList(newData);
      setIsLoadingApp(false);
      return;
    }
    const { Result = [] } = await services.GetAppList({ params: { regionId, namespaceId, pageNumber, pageSize } });
    const newData = map(Result, item => ({
      ...item,
      key: item.AppId,
      value: item.AppId,
      label: item.AppName,
    }));
    currentAppList.push(...newData);
    if (Result.length && Result.length === pageSize) {
      fetchAppList({ pageNumber: pageNumber + 1, pageSize });
    } else {
      if (!value.appId || !find(currentAppList, item => item.value === value.appId)) {
        const firstItem = head(currentAppList) || {};
        handleChangeAppId(firstItem.value);
      } else {
        handleChangeAppId(value.appId);
      }
      setIsLoadingApp(false);
      setAppList(currentAppList);
    }
  };

  const handleChangeAppId = async (val) => {
    setAppId(val);
    if (!val) return;
    setIsLoadingTag(true);
    const Data = await services.GetApplicationTags({
      params: {
        regionId,
        namespaceId,
        appId: val,
        source: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'EDAS' : undefined
      }
    });
    let newData = [];
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      newData = map(Data.data || [], item => ({
        ...item,
        key: item.tag,
        value: item.tag,
        label: item.tag,
      }));
    } else {
      newData = map(Data || [], item => ({
        ...item,
        key: item.Tag,
        value: item.Tag,
        label: item.Tag,
      }));
    }
    if (!value.tag || !find(newData, item => item.value === value.tag)) {
      const firstItem = head(newData) || {};
      handleChangeTag(val, firstItem.value);
    } else {
      handleChangeTag(val, value.tag);
    }
    setIsLoadingTag(false);
    setTagList(newData);
  };

  const handleChangeTag = (id, tag) => {
    onChange && onChange({ appId: id, tag });
  };

  return (
    <React.Fragment>
      <Select
        state={isLoadingApp ? 'loading' : ''}
        showSearch
        style={{ width: '47%', marginRight: 8 }}
        dataSource={appList}
        value={appId}
        onChange={handleChangeAppId}
        placeholder={intl('widget.common.select_app')}
      />
      <Select
        state={isLoadingTag ? 'loading' : ''}
        showSearch
        style={{ width: '47%' }}
        dataSource={tagList}
        value={value.tag}
        onChange={(val) => handleChangeTag(appId, val)}
        placeholder={intl('widget.common.select_tag')}
      />
      <Icon type="refresh" style={{ marginLeft: 8, cursor: 'pointer' }} onClick={() => fetchAppList({ regionId, pageNumber: 1, pageSize: 50 })} />
    </React.Fragment>
  );
};

AppTagSelector.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
  namespaces: PropTypes.objectOf(PropTypes.any),
};

export default AppTagSelector;
