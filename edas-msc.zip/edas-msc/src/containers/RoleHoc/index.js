import React from 'react';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { get } from 'lodash';
import { NoPermission } from 'components/Icon';
import { Button } from '@ali/cn-design';

const RoleHoc = (WrapComp, isShow = true) => (props) => {
  const [mscAccount] = useGlobalState('mscAccount');
  const intl = useIntl();

  const Version = get(mscAccount, 'Version', 0);
  if (Version === 0) {
    const isMore1115 = new Date('2021-11-15 00:00:00') - new Date(Date.now());
    if (isMore1115 > 0) {
      return <WrapComp {...props} />;
    }
    if (!isShow) return null;
    return (
      <div style={{ display: 'flex', justifyContent: 'center', margin: 100 }}>
        <NoPermission style={{ width: 120, height: 120, marginRight: 16 }} />
        <div>
          <h5 style={{ margin: '16px 0 0' }}>{intl('widget.msc.pro_version_not_activated')}</h5>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500 }}>{intl.html('widget.msc.account_version_0', { userId: mscAccount.UserId })}</div>
          <Button type="primary">{intl.html('widget.msc.upgrade_to_professional_edition_button', { userId: mscAccount.UserId })}</Button>
        </div>
      </div>
    );
  }
  return <WrapComp {...props} />;
};

export default RoleHoc;
