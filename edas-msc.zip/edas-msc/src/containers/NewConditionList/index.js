import React, { useEffect, useState } from 'react';
import { Balloon, Select, Input, Icon } from '@ali/cn-design';
import styles from './index.less';
import { useIntl } from '@ali/widget-hooks';
import { filter } from 'lodash';
import PropTypes from 'prop-types';

const NewConditionList = ({ value, radioVal, handleDeleteCondition, condition = [] }) => {
  const intl = useIntl();
  const [isFlag, setFlag] = useState();
  useEffect(() => {

  }, [radioVal, condition]);

  return (
    <React.Fragment>
      <div style={{ display: 'flex' }}>
        <div style={{ width: '90px' }}>
          <span
            className={`${isFlag ? styles['btn-and'] : styles['btn-or']}`}
            onClick={() => setFlag(true)}
          >
            {intl('widget.msc.common.and')}
          </span>
          <span
            className={`${isFlag ? styles['btn-or'] : styles['btn-and']}`}
            onClick={() => setFlag(false)}
          >
            {intl('widget.msc.common.or')}
          </span>
        </div>
        <If condition={radioVal === 'Dubbo'}>
          <div className={styles['if-title']}>{intl('widget.route.condition.params_name')}</div>
        </If>
        <If condition={radioVal !== 'Dubbo'}>
          <div className={styles['if-title']}>{intl('widget.route.condition.params_type')}</div>
        </If>
        <If condition={radioVal === 'Dubbo'}>
          <div className={styles['if-title']}>
            {intl('widget.k8s_gray.expr')}{' '}
            <Balloon
              align="t"
              trigger={
                <Icon
                  type="help"
                  style={{ color: '#888', cursor: 'pointer', marginLeft: 4 }}
                />
              }
              triggerType="hover"
              style={{ minWidth: 360 }}
            >
              {intl.html('widget.route.condition.expre_label')}
            </Balloon>
          </div>
        </If>
        <If condition={radioVal !== 'Dubbo'}>
          <div className={styles['if-title']}>{intl('widget.route.condition.params_name')}</div>
        </If>
        <div className={styles['if-title']}>{intl('widget.route.condition')}</div>
        <div className={styles['if-title']}>{intl('widget.route.condition.value')}</div>
        <div style={{ width: '30px' }} />
      </div>
      <For index="index" each="item" of={condition}>
        <div style={{ display: 'flex' }}>
          <div
            className={`${
              index === 0 ? styles['if-line-short'] : styles['if-line']
            }`}
          />
          <div
            className={`${
              index === 0 ? styles['if-title'] : styles['if-title1']
            }`}
          >
            <Select style={{ width: '90%' }} />
          </div>
          <div
            className={`${
              index === 0 ? styles['if-title'] : styles['if-title1']
            }`}
          >
            <Input style={{ width: '90%' }} />
          </div>
          <div
            className={`${
              index === 0 ? styles['if-title'] : styles['if-title1']
            }`}
          >
            <Select style={{ width: '90%' }} />
          </div>
          <div
            className={`${
              index === 0 ? styles['if-title'] : styles['if-title1']
            }`}
          >
            <Input style={{ width: '90%' }} />
          </div>
          <div
            style={{
              width: '30px',
              height: '30px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              cursor: 'pointer',
              marginTop: `${index === 0 ? 0 : '9px'}`,
            }}
          >
            <Icon
              type="ashbin"
              size="medium"
              onClick={() => handleDeleteCondition(index)}
            />
          </div>
        </div>
      </For>
    </React.Fragment>
  );
};

NewConditionList.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  handleDeleteCondition: PropTypes.objectOf(PropTypes.any),
  condition: PropTypes.objectOf(PropTypes.any),
  radioVal: PropTypes.string,
}
export default NewConditionList;