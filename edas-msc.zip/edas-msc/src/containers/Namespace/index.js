/**
 * Created by huangfushan on 2019-11-27
*/
import React, { useState, useEffect } from 'react';
import { map, head, find, isEmpty } from 'lodash';
import PropTypes from 'prop-types';
import { Select, Icon } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';

const Namespace = (props) => {
  const {
    onChange,
    value = {
      //   regionId: undefined,
      //   namespaceId: undefined,
    },
    style,
    refreshStyle,
    refreshTime = undefined,
  } = props;
  const intl = useIntl();

  const [isRegionLoading, setIsRegionLoading] = useState(false);
  const [isNamespaceLoading, setIsNamespaceLoading] = useState(false);

  const [regions, setRegions] = useState([]);
  const [namespaces, setNamespaces] = useState([]);
  const { regionId, namespaceId } = value;

  // const [regionId, setRegionId] = useState(value.regionId);
  // const [namespaceId, setNamespaceId] = useState(value.namespaceId);

  useEffect(() => {
    fetchRegionList();
  }, [refreshTime]);

  const fetchRegionList = async () => {
    setIsRegionLoading(true);
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);

    setIsRegionLoading(false);
    setRegions(newData);
    if (regionId && find(newData, { regionId })) {
      fetchNamespaces(regionId);
    } else {
      const firstRegion = head(newData) || {};
      fetchNamespaces(firstRegion.regionId);
    }
  };

  const fetchNamespaces = async (rId) => {
    setIsNamespaceLoading(true);
    const { data = [] } = await services.fetchNamespaces({ params: { regionId: rId } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    setIsNamespaceLoading(false);
    setNamespaces(newData)
    if (namespaceId && find(newData, { namespaceId })) {
      handleChangeNamespace(rId, namespaceId);
    } else {
      const firstNamespace = head(data) || {};
      handleChangeNamespace(rId, firstNamespace.namespaceId);
    }
  };

  const handleChangeRegion = (rId) => {
    fetchNamespaces(rId);
  };

  const handleChangeNamespace = (rId, nId) => {
    handleChange({ regionId: rId, namespaceId: nId });
  };

  const handleChange = (params) => {
    onChange && onChange(params);
  };

  const handleRefresh = () => {
    fetchRegionList();
  };

  return (
    <div className="demo-container">
      <Select
        state={isRegionLoading ? 'loading' : undefined}
        style={{ width: 300, marginRight: 8, ...style }}
        dataSource={map(regions, n => ({ label: n.regionName, value: n.regionId }))}
        value={regionId}
        onChange={handleChangeRegion}
      />
      <Select
        cacheValue={false}
        state={isNamespaceLoading ? 'loading' : undefined}
        style={{ width: 300, ...style }}
        dataSource={map(namespaces, n => ({ label: n.namespaceName, value: n.namespaceId }))}
        value={namespaceId}
        onChange={(rId) => handleChangeNamespace(regionId, rId)}
      />
      <Icon
        type="refresh"
        size="small"
        onClick={handleRefresh}
        style={{ ...styles.refresh, ...refreshStyle }}
      />
    </div>
  );
};

const styles = {
  add: {
    marginLeft: 8,
    color: '#0070cc',
    cursor: 'pointer',
    lineHeight: 'initial',
  },
  refresh: {
    marginLeft: 8,
    color: '#777',
    cursor: 'pointer',
  }
};

Namespace.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
  style: PropTypes.objectOf(PropTypes.any),
  refreshStyle: PropTypes.objectOf(PropTypes.any),
  refreshTime: PropTypes.number,
};

export default Namespace;
