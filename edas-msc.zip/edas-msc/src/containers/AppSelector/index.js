import React, { useState, useEffect } from 'react';
import { useIntl } from '@ali/widget-hooks';
import { Select, Icon } from '@ali/cn-design';
import { head, map, find, isEmpty, filter, includes } from 'lodash';
import PropTypes from 'prop-types';
import services from 'services';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const AppSelector = (props) => {
  const { value, onChange, namespaces = {}, showAll, mode, ...reset } = props;
  const [appList, setAppList] = useState([]);
  const [isLoadingApp, setIsLoadingApp] = useState(false);
  const intl = useIntl();
  const { regionId, namespaceId } = namespaces;
  const currentAppList = showAll ? [{ value: '*', label: '*' }] : [];
  useEffect(() => {
    if (isEmpty(namespaces) || !regionId) return;
    fetchAppList({ pageNumber: 1, pageSize: 50 });
  }, [regionId, namespaceId]);

  // 这个是分页接口，但是需要拿到全部数据
  const fetchAppList = async ({ pageNumber, pageSize }) => {
    setIsLoadingApp(true);
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      let { data = [] } = await services.GetAppList({ params: { regionId, namespaceId } });
      data = filter(showAll ? [{ appId: '*', appName: '*' }, ...data] : data, item => (item.regionId === namespaceId || item.appId === '*'));
      const newData = map(data, item => ({
        ...item,
        key: item.appId,
        value: item.appId,
        label: item.appName,
      }));
      setAppList(newData);
      setIsLoadingApp(false);
      if (!value) {
        const firstItem = head(newData) || {};
        handleChangeApp(mode === 'multiple' ? [firstItem.value] : firstItem.value, newData);
      }
      return;
    }
    const { Result = [] } = await services.GetAppList({ params: { regionId, namespaceId, pageNumber, pageSize } });
    const newData = map(Result, item => ({
      ...item,
      key: item.AppId,
      value: item.AppId,
      label: item.AppName,
    }));
    currentAppList.push(...newData);
    if (Result.length && Result.length === pageSize) {
      fetchAppList({ pageNumber: pageNumber + 1, pageSize });
    } else {
      setIsLoadingApp(false);
      setAppList(currentAppList);
      if (!value) {
        const firstItem = head(currentAppList) || {};
        handleChangeApp(mode === 'multiple' ? [firstItem.value] : firstItem.value, currentAppList);
      }
    }
  };

  const handleChangeApp = (id, list = appList) => {
    if (mode === 'multiple') {
      const selectApp = filter(list, item => includes(id, item.value));
      const appNames = map(selectApp, item => item.label);
      onChange && onChange(id, appNames);
    } else {
      const item = find(list, { value: id }) || {};
      onChange && onChange(id, item.label);
    }
  };
  return (
    <React.Fragment>
      <If condition={mode === 'multiple'}>
        <Select
          state={isLoadingApp ? 'loading' : ''}
          showSearch
          style={{ width: 'calc(100% - 32px)' }}
          dataSource={appList}
          value={value}
          onChange={(id) => handleChangeApp(id)}
          placeholder={intl('widget.common.select_app')}
          mode="multiple"
          {...reset}
        />
      </If>
      <If condition={mode !== 'multiple'}>
        <Select
          state={isLoadingApp ? 'loading' : ''}
          showSearch
          style={{ width: 'calc(100% - 32px)' }}
          dataSource={appList}
          value={value}
          onChange={(id) => handleChangeApp(id)}
          placeholder={intl('widget.common.select_app')}
          {...reset}
        />
      </If>
      <Icon type="refresh" style={{ marginLeft: 8, cursor: 'pointer' }} onClick={() => fetchAppList({ regionId, pageNumber: 1, pageSize: 50 })} />
    </React.Fragment>
  );
};

AppSelector.propTypes = {
  mode: PropTypes.string,
  onChange: PropTypes.func,
  value: PropTypes.number,
  showAll: PropTypes.arrayOf(PropTypes.any),
  namespaces: PropTypes.objectOf(PropTypes.any),
};

export default AppSelector;
