import React, { useEffect, useState } from 'react';
import { RemoteSelect, Empty, InputTooltip, BalloonIcon, IconButton } from '@ali/cn-design';
import { Icon, Table, NumberPicker, Select, Input, Balloon, Field, CascaderSelect } from '@alicloud/console-components';
import { useIntl } from '@ali/widget-hooks';
import { uniqueId, filter, map, find, join, get, includes } from 'lodash';
import PropTypes from 'prop-types';
import { jsonParse } from 'utils/transfer-data';
import './index.less';

const ConditionList = (props) => {
  const { value, onChange, show, protocol, method = '{}' } = props;
  const intl = useIntl();
  const [dataSource, setDataSource] = useState(value);
  const [indexDataSource, setIndexDataSource] = useState([]);
  const field = Field.useField();
  const { init, setValue } = field;

  useEffect(() => {
    setDataSource(value || []);
  }, [value]);

  useEffect(() => {
    const newMethod = jsonParse(method);
    const parameterTypes = get(newMethod, 'parameterTypes') || [];
    const newData = map(parameterTypes, (item, index) => {
      return (
        {
          value: index,
          label: (
            <Balloon
              align="l"
              trigger={intl('widget.k8s_gray.params_n', { n: `${index}${item ? ` (${item})` : ''}` })}
              triggerType="hover"
            >
              {intl('widget.k8s_gray.params_n', { n: `${index}${item ? ` (${item})` : ''}` })}
            </Balloon>
          )
        });
    });
    setIndexDataSource(newData);
  }, [method]);

  const typeData = [
    { value: 'cookie', label: 'Cookie', placeholder: intl('widget.k8s_gray.cookie_placeholder') },
    { value: 'header', label: 'Header', placeholder: intl('widget.k8s_gray.header_placeholder') },
    { value: 'param', label: 'Parameter', placeholder: intl('widget.k8s_gray.param_placeholder') },
    // { value: 'body', label: 'Body Content', placeholder: intl('widget.k8s_gray.body_placeholder') },
  ];

  const conditionData = [
    { value: '==', label: '=' },
    { value: '!=', label: '!=' },
    { value: '>', label: '>' },
    { value: '<', label: '<' },
    { value: '>=', label: '>=' },
    { value: '<=', label: '<=' },
    { value: 'list', label: intl('widget.k8s_gray.white_list') },
    // { value: '%', label: intl('widget.k8s_gray.streaming_percentage') },
    {
      value: 'mod',
      label: intl('widget.k8s_gray.mode_100'),
      children: [
        { value: 'mod-==', label: '=' },
        { value: 'mod-!=', label: '!=' },
        { value: 'mod->', label: '>' },
        { value: 'mod-<', label: '<' },
        { value: 'mod->=', label: '>=' },
        { value: 'mod-<=', label: '<=' },
      ]
    },
  ];

  const numberArr = ['==', '!=', 'mod-==', 'mod-!='];
  const columns = [
    {
      key: 'type',
      title: intl('widget.k8s_gray.params_type'),
      dataIndex: 'type',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <RemoteSelect
              width="100%"
              {...init(`type-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { type: v })
                }
              })}
              style={{ maxWidth: 250, width: '100%' }}
              dataSource={typeData}
            />
          </If>
        </React.Fragment>
      ),
      width: 200,
      visible: protocol === 'springcloud',
    },
    {
      key: 'name',
      title: intl('widget.k8s_gray.params_name'),
      dataIndex: 'name',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <InputTooltip
              {...init(`name-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { name: v })
                }
              })}
              style={{ width: '100%' }}
              triggerStyle={{ width: 200, minWidth: 200 }}
              maxLength={64}
              showLimitHint
              placeholder={find(typeData, item => item.value === record.type) && find(typeData, item => item.value === record.type).placeholder}
            />
          </If>
        </React.Fragment>
      ),
      width: 300,
      visible: protocol === 'springcloud',
    },
    {
      key: 'index',
      title: intl('widget.k8s_gray.params_name'),
      dataIndex: 'index',
      cell: (val, index, record) => (
        <div>
          <If condition={show}>
            <Empty value={val}>{intl('widget.k8s_gray.condition.params', { n: val })}</Empty>
          </If>
          <If condition={!show}>
            <RemoteSelect
              width="100%"
              {...init(`index-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { index: v })
                }
              })}
              style={{ maxWidth: 250, width: '100%' }}
              dataSource={indexDataSource}
            />
          </If>
        </div>
      ),
      width: 200,
      visible: protocol === 'dubbo',
    },
    {
      key: 'expr',
      title: (
        <React.Fragment>
          <span>{intl('widget.k8s_gray.expr')}</span>
          <BalloonIcon text={intl('widget.k8s_gray.expre_label')} style={{ marginLeft: 4, verticalAlign: 'bottom', cursor: 'pointer' }} />
        </React.Fragment>
      ),
      dataIndex: 'expr',
      cell: (val, index, record) => (
        <div>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <InputTooltip
              {...init(`expre-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { expr: v })
                }
              })}
              triggerStyle={{ width: 200, minWidth: 200 }}
              addonTextBefore={`arg${record.index >= 0 ? record.index : ''}`}
              style={{ width: '100%' }}
              maxLength={64}
              showLimitHint
              placeholder={intl('widget.k8s_gray.condition.expre_placeholder')}
            />
          </If>
        </div>
      ),
      width: 300,
      visible: protocol === 'dubbo',
    },
    {
      key: 'cond',
      title: intl('widget.k8s_gray.condition'),
      dataIndex: 'cond',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <If condition={val === '%'}>
              {intl('widget.k8s_gray.streaming_percentage')}
            </If>
            <If condition={val !== '%'}>
              <Empty value={val}>
                {val}
              </Empty>
            </If>
          </If>
          <If condition={!show}>
            <CascaderSelect
              {...init(`cond-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => {
                    setValue(`value-${record.uid}`, undefined);
                    handleChange(record.uid, { cond: v, value: undefined });
                  }
                }
              })}
              style={{ width: '100%' }}
              dataSource={conditionData}
              placeholder={intl('widget.k8s_gray.please_select_condition')}
            />
          </If>
        </React.Fragment>
      ),
      width: 150,
      visible: true,
    },
    {
      key: 'value',
      title: intl('widget.k8s_gray.value'),
      dataIndex: 'value',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <If condition={record.operator === 'list'}>
              <Empty value={val}>{join(val, ', ')}</Empty>
            </If>
            <If condition={record.operator !== 'list'}>
              <Empty value={val}>{val}</Empty>
            </If>
          </If>
          <If condition={!show}>
            <Choose>
              <When condition={record.cond === 'list'}>
                <Select
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  mode="tag"
                  dataSource={val}
                  style={{ width: '100%' }}
                  placeholder={intl('widget.k8s_gray.condition_list_placeholder')}
                />
              </When>
              <When condition={record.cond === '%'}>
                <NumberPicker
                  style={{ width: '100%' }}
                  max={100}
                  min={0}
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  placeholder={intl('widget.k8s_gray.condition_stream_percent_value_placeholder')}
                />
              </When>
              <When condition={includes(numberArr, record.cond)}>
                <Input
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  style={{ width: '100%' }}
                  placeholder={intl('widget.k8s_gray.please_enter_value')}
                />
              </When>
              <Otherwise>
                <NumberPicker
                  style={{ width: '100%' }}
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  placeholder={intl('widget.k8s_gray.please_enter_value')}
                />
              </Otherwise>
            </Choose>
          </If>
        </React.Fragment>
      ),
      width: 300,
      visible: true,
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => (
        <Icon type="delete" size="xs" style={{ cursor: 'pointer' }} onClick={() => handleDelete(record.uid)} />
      ),
      width: 100,
      visible: true,
    },
  ];

  const handleChange = (uid, obj) => {
    const newData = map(dataSource, item => item.uid === uid ? ({ ...item, ...obj }) : item);
    onChange(newData);
  };

  const handleDelete = (uid) => {
    const newData = filter(dataSource, item => item.uid !== uid);
    onChange(newData);
  };

  const handleAdd = () => {
    const newData = [...dataSource, { uid: uniqueId(), type: 'cookie' }];
    onChange(newData);
  };

  const currentColumns = filter(columns, { visible: true });

  return (
    <div className="condition-list">
      <Table dataSource={dataSource} hasBorder={false}>
        <For each="item" of={show ? currentColumns.slice(0, -1) : currentColumns}>
          <Table.Column {...item} />
        </For>
      </Table>
      <If condition={!show}>
        <IconButton style={{ marginTop: 8 }} onClick={handleAdd}>{intl('widget.k8s_gray.add_condition_list')}</IconButton>
      </If>
    </div>
  );
};

ConditionList.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  onChange: PropTypes.func,
  show: PropTypes.bool,
  protocol: PropTypes.string,
  method: PropTypes.string,
};

export default ConditionList;
