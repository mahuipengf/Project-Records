import React from 'react';
import PropTypes from 'prop-types';
import { TableContainer } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import columns from './columns';
import { lowerFirstData } from 'utils/transfer-data';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const ServiceList = (props) => {
  const { condition = {}, title, onCall, ...rest } = props;
  const intl = useIntl();

  const fetchData = async (params) => {
    const values = {
      ...condition,
      ...params,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      values.page = values.pageNumber - 1;
      values.size = values.pageSize;
      values.searchType = 'app';
      values.region = values.regionId;
      values.namespace = values.namespaceId;
      values.searchValue = values.appId;
      const res = await services.fetchServicesList({ data: values });
      const { content = [], totalElements = 0 } = res;
      onCall && onCall(totalElements);
      return {
        Data: content,
        TotalCount: totalElements,
      };
    }
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'arms') {
      values.page = values.pageNumber - 1;
      values.size = values.pageSize;
      values.searchType = 'app';
      values.region = values.regionId;
      values.namespace = values.namespaceId;
      values.searchValue = values.appId;
      const res = await services.fetchArms({
        data: values,
        params: { action: 'ContainerAction', eventSubmitDoServiceQuery: 1 }
      });
      const { content = [], totalElements = 0 } = res;
      onCall && onCall(totalElements);
      return {
        Data: content,
        TotalCount: totalElements,
      };
    }
    const res = await services.fetchServicesList({ data: values });
    const { result = [], totalSize = 0 } = lowerFirstData(res) || {};
    onCall && onCall(totalSize);
    return {
      Data: result,
      TotalCount: totalSize,
    };
  };

  return (
    <React.Fragment>
      <If condition={title}>
        <h4 style={{ fontWeight: 600, margin: '16px 0 8px 0' }}>{title}</h4>
      </If>
      <TableContainer fetchData={fetchData} columns={columns(intl, condition)} {...rest} />
    </React.Fragment>
  );
};

ServiceList.propTypes = {
  condition: PropTypes.objectOf(PropTypes.any),
  title: PropTypes.string,
  onCall: PropTypes.func,
};

export default ServiceList;
