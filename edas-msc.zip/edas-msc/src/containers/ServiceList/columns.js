import React from 'react';
import { Empty, CopyContent } from '@ali/cn-design';
import Events from './Events';

const columns = (intl, condition) => {
  const column = [
    {
      key: 'serviceName',
      title: intl('widget.service.service_name'),
      dataIndex: 'serviceName',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <If condition={condition.side === 'consumer'}>
            {record.serviceName}
          </If>
          <If condition={condition.side === 'provider'}>
            <Events condition={condition} record={record}>
              {record.serviceName}
            </Events>
          </If>
        </CopyContent>
      ),
      width: '40%'
    }
  ];
  if (condition.serviceType !== 'springCloud') {
    column.push(
      {
        key: 'version',
        title: intl('widget.service.version'),
        dataIndex: 'version',
        cell: value => value || '--',
        width: '20%'
      },
      {
        key: 'group',
        title: intl('widget.service.group'),
        dataIndex: 'group',
        cell: value => value || '--',
        width: '20%'
      }
    );
  }
  return column;
};

export default (intl, condition) => columns(intl, condition);
