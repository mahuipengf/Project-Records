import React from 'react';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import { modelDecorator } from '@ali/cn-design';
import ServiceInfo from 'pages/ServiceManage/ServiceList/components/ServiceInfo';

const Events = ({ record, children, toggleModal, condition }) => {
  const intl = useIntl();

  const handleOpenInfo = () => {
    const { serviceType, regionId, namespaceId, origin, appId } = condition;
    const { group: serviceGroup, version: serviceVersion, serviceName, serviceId, registryType } = record;
    const newRecord = {
      serviceType,
      regionId,
      namespaceId,
      origin,
      appId,
      serviceGroup,
      serviceVersion,
      serviceName,
      serviceId,
      registryType,
    };
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'xl',
      title: intl('widget.service.serviceInfo'),
      content: (
        <ServiceInfo
          value={newRecord}
        />
      ),
    });
  };

  return (
    <span className="link-primary" onClick={handleOpenInfo}>{children}</span>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  condition: PropTypes.shape(),
  toggleModal: PropTypes.func,
  children: PropTypes.string,
};

export default modelDecorator(Events);
