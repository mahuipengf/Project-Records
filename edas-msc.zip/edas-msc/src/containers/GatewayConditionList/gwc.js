import React, { useState, useEffect } from 'react';
import { Table, Field, RemoteSelect, Icon, Input } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import { filter, map, head, uniqueId, get, isEmpty } from 'lodash';
import CommonEvent from 'components/CommonEvent';
import './index.less';

const GatewayConditionList = (props) => {
  const { onChange, value } = props;
  const intl = useIntl();
  const field = Field.useField();
  const { init, setValue, getValue } = field;
  const [dataSource, setDataSource] = useState(value);
  const typeData = [
    { value: 'header', label: 'Header', placeholder: intl('widget.route.header_placeholder'), visible: true },
    { value: 'param', label: 'Parameter', placeholder: intl('widget.route.param_placeholder'), visible: true },
  ];

  const gwConditionData = [
    { value: 'PRE', label: ' 前缀匹配' },
    { value: 'EQUAL', label: '精确匹配' },
    { value: 'ERGULAR', label: '正则匹配' },
  ];

  useEffect(() => {
    setDataSource(value);
  }, [value]);
  const columns = [
    {
      key: 'type',
      title: intl('widget.route.condition.params_type'),
      dataIndex: 'type',
      width: 150,
      cell: (val, index, record) => {
        return (
          <React.Fragment>
            <RemoteSelect
              width="100%"
              {...init(`type-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { type: v })
                }
              })}
              // value={val}
              // onChange={(v) => handleChange(record.uid, { type: v })}
              style={{ maxWidth: 250, width: '100%' }}
              dataSource={filter(typeData, item => item.visible)}
            />
          </React.Fragment>
        );
      },
    },
    {
      key: 'name',
      title: intl('widget.route.condition.params_name'),
      dataIndex: 'name',
      width: 300,
      cell: (val, index, record) => {
        return (
          <React.Fragment>
            <Input
              {...init(`name-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { name: v })
                }
              })}
              // value={val}
              // onChange={(v) => handleChange(record.uid, { name: v })}
              style={{ width: '100%' }}
              placeholder={'请输入字段名'}
            />
          </React.Fragment>
        );
      },
    },
    {
      key: 'cond',
      title: intl('widget.route.condition'),
      dataIndex: 'cond',
      width: 150,
      cell: (val, index, record) => {
        return (
          <React.Fragment>
            <RemoteSelect
              width="100%"
              {...init(`cond-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { cond: v })
                }
              })}
              // value={val}
              // onChange={(v) => handleChange(record.uid, { cond: v })}
              style={{ maxWidth: 250, width: '100%' }}
              dataSource={gwConditionData}
              placeholder={intl('widget.route.condition_placeholder')}
            />
          </React.Fragment>
        );
      },
    },
    {
      key: 'value',
      title: intl('widget.route.condition.value'),
      dataIndex: 'value',
      width: 300,
      cell: (val, index, record) => {
        return (
          <React.Fragment>
            <Input
              {...init(`value-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { value: v })
                }
              })}
              // value={val}
              // onChange={(v) => handleChange(record.uid, { value: v })}
              style={{ width: '100%' }}
              placeholder={intl('widget.route.condition.input_value_placeholder')}
            />
          </React.Fragment>
        );
      },
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => (
        <Icon type="delete" size="xs" style={{ cursor: 'pointer' }} onClick={() => handleDelete(record.uid)} />
      ),
      width: 100,
    },
  ];
  const handleChange = (uid, obj) => {
    const newData = map(dataSource, item => item.uid === uid ? ({ ...item, ...obj }) : item);
    onChange(newData);
  };
  const handleDelete = (uid) => {
    const newData = filter(dataSource, item => item.uid !== uid);
    console.log('newData', newData);
    onChange(newData);
  };
  const handleAdd = () => {
    const newTypeData = filter(typeData, item => item.visible);
    const headTypeData = head(newTypeData);
    const newData = [...dataSource, { uid: uniqueId(), type: get(headTypeData, 'value') }];
    onChange(newData);
  };

  return (
    <div className="condition-list">
      <Table dataSource={dataSource} hasBorder={false}>
        <For each="item" of={columns}>
          <Table.Column {...item} />
        </For>
      </Table>
      <CommonEvent style={{ marginTop: 8 }} onClick={handleAdd} text={intl('widget.route.add_condition_rule')} />
    </div>
  );
};

export default GatewayConditionList;
