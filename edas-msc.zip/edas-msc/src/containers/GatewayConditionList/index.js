import React, { useEffect, useState } from 'react';
import { RemoteSelect, Empty, InputTooltip, Icon, Table, NumberPicker, Select, Input, Balloon } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { useIntl } from '@ali/widget-hooks';
import { uniqueId, filter, map, find, join, split, includes, replace, head, get } from 'lodash';
import PropTypes from 'prop-types';
import CommonEvent from 'components/CommonEvent';
import CascaderSelector from 'components/CascaderSelector';
import './index.less';

const ConditionList = (props) => {
  const { value, onChange, show, protocol, method = '', parent = '' } = props;
  const intl = useIntl();
  const [dataSource, setDataSource] = useState(value);
  const [indexDataSource, setIndexDataSource] = useState([]);
  const field = Field.useField();
  const { init, setValue, getValue } = field;

  useEffect(() => {
    if (show) {
      setDataSource(mapConditionsLabel(value));
      return;
    }
    setDataSource(value);
  }, [value]);

  useEffect(() => {
    const [serviceName, version, group, methodName, parameterTypes = '', returnType] = split(method, ':');
    const newData = map(split(parameterTypes, ','), (item, index) => {
      return (
        {
          value: index,
          // label: intl('widget.route.condition.params', { n: `${index}${item ? `(${item})` : ''}` })
          label: (
            <Balloon
              align="l"
              trigger={intl('widget.route.condition.params', { n: `${index}${item ? ` (${item})` : ''}` })}
              triggerType="hover"
            >
              {intl('widget.route.condition.params', { n: `${index}${item ? ` (${item})` : ''}` })}
            </Balloon>
          )
        });
    });
    setIndexDataSource(newData);
  }, [method]);

  // condition 展示，凸显的是：渲染文案
  const mapConditionsLabel = (conditions = []) => map(conditions, child => {
    switch (child.operator) {
      case 'list':
        return {
          ...child,
          cond: intl('widget.route.white_list'),
          value: join(child.value, ', '),
          type: find(typeData, item => item.value === child.type) && find(typeData, item => item.value === child.type).label
        };
      case 'mod':
        return {
          ...child,
          cond: `${intl('widget.route.mode_100')} / ${replace(child.cond, 'mod-', '') === '==' ? '=' : replace(child.cond, 'mod-', '')}`,
          type: find(typeData, item => item.value === child.type) && find(typeData, item => item.value === child.type).label
        };
      case 'rawvalue':
        return {
          ...child,
          cond: child.cond === '==' ? '=' : child.cond,
          type: find(typeData, item => item.value === child.type) && find(typeData, item => item.value === child.type).label,
        };
      case 'deterministic_proportional_steaming_division':
        return {
          ...child,
          cond: intl('widget.route.streaming_percentage'),
          type: find(typeData, item => item.value === child.type) && find(typeData, item => item.value === child.type).label
        };
      case 'string':
        return {
          ...child,
          type: find(typeData, item => item.value === child.type) && find(typeData, item => item.value === child.type).label
        };
      case 'regexp':
        return {
          ...child,
          cond: intl('widget.common.regexp'),
          type: find(typeData, item => item.value === child.type) && find(typeData, item => item.value === child.type).label,
        };
      default:
        return child;
    }
  });
  const typeData = [
    { value: 'cookie', label: 'Cookie', placeholder: intl('widget.route.cookie_placeholder'), visible: protocol === 'istio' },
    { value: 'header', label: 'Header', placeholder: intl('widget.route.header_placeholder'), visible: protocol === 'springCloud' || protocol === 'istio' },
    { value: 'param', label: 'Parameter', placeholder: intl('widget.route.param_placeholder'), visible: (protocol === 'springCloud') },
    { value: 'body', label: 'Body Content', placeholder: intl('widget.route.body_placeholder'), visible: false },
    { value: 'method', label: 'Method', placeholder: intl('widget.route.method_placeholder'), visible: protocol === 'istio' },
    { value: 'param', label: 'Parameter', placeholder: intl('widget.msc.please_enter_parameter'), visible: (protocol === 'dubbo' && parent === 'MstMock') },
    { value: 'rpccontext', label: 'RpcContext', placeholder: intl('widget.msc.please_enter_rpc_context'), visible: protocol === 'dubbo' && parent === 'MstMock' },
  ];

  const conditionData = [
    { value: '==', label: '=' },
    { value: '!=', label: '!=' },
    { value: '>', label: '>' },
    { value: '<', label: '<' },
    { value: '>=', label: '>=' },
    { value: '<=', label: '<=' },
    { value: 'list', label: intl('widget.route.white_list') },
    { value: '%', label: intl('widget.route.streaming_percentage') },
    { value: 'regexp', label: intl('widget.common.regexp') },
    {
      value: 'mod',
      label: intl('widget.route.mode_100'),
      children: [
        { value: 'mod-==', label: '=' },
        { value: 'mod-!=', label: '!=' },
        { value: 'mod->', label: '>' },
        { value: 'mod-<', label: '<' },
        { value: 'mod->=', label: '>=' },
        { value: 'mod-<=', label: '<=' },
      ]
    },
  ];

  const mstConditionData = [
    { value: '==', label: '=' },
    { value: '!=', label: '!=' },
    { value: '>', label: '>' },
    { value: '<', label: '<' },
    { value: '>=', label: '>=' },
    { value: '<=', label: '<=' },
  ];

  const istioConditionData = [
    { value: 'exact', label: 'exact' },
    { value: 'prefix', label: 'prefix' },
    { value: 'regex', label: 'regex' },
  ];

  const numberArr = ['==', '!=', 'mod-==', 'mod-!=', 'exact', 'prefix', 'regex'];
  const columns = [
    {
      key: 'type',
      title: intl('widget.route.condition.params_type'),
      dataIndex: 'type',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <RemoteSelect
              width="100%"
              {...init(`type-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { type: v })
                }
              })}
              style={{ maxWidth: 250, width: '100%' }}
              dataSource={filter(typeData, item => item.visible)}
            />
          </If>
        </React.Fragment>
      ),
      width: 200,
      visible: protocol === 'springCloud',
    },
    {
      key: 'name',
      title: intl('widget.route.condition.params_name'),
      dataIndex: 'name',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <InputTooltip
                {...init(`name-${record.uid}`, {
                  initValue: val,
                  props: {
                    onChange: (v) => handleChange(record.uid, { name: v })
                  }
                })}
                style={{ width: '100%' }}
                triggerStyle={{ width: 200, minWidth: 200 }}
                maxLength={64}
                showLimitHint
                placeholder={find(typeData, item => item.value === record.type) && find(typeData, item => item.value === record.type).placeholder}
              />
              <If condition={getValue(`type-${record.uid}`) === 'body'}>
                <Balloon
                  align="t"
                  trigger={<Icon type="help" style={{ color: '#888', cursor: 'pointer', marginLeft: 4 }} />}
                  triggerType="hover"
                  style={{ minWidth: 360 }}
                >
                  {intl.html('widget.route.condition.body_label')}
                </Balloon>
              </If>
            </div>
          </If>
        </React.Fragment>
      ),
      width: 300,
      visible: protocol === 'springCloud',
    },
    {
      key: 'index',
      title: intl('widget.route.condition.params_name'),
      dataIndex: 'index',
      cell: (val, index, record) => (
        <div>
          <If condition={show}>
            <Empty value={val}>{intl('widget.route.condition.params', { n: val })}</Empty>
          </If>
          <If condition={!show}>
            <RemoteSelect
              width="100%"
              {...init(`index-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { index: v })
                }
              })}
              style={{ maxWidth: 250, width: '100%' }}
              dataSource={indexDataSource}
            />
          </If>
        </div>
      ),
      width: 200,
      visible: protocol === 'dubbo' && parent !== 'MstMock',
    },
    {
      key: 'expr',
      title: (
        <React.Fragment>
          <span>{intl('widget.route.condition.expr')}</span>
          <Balloon
            align="t"
            trigger={<Icon type="help" style={{ color: '#888', cursor: 'pointer', marginLeft: 4 }} />}
            triggerType="hover"
            style={{ minWidth: 360 }}
          >
            {intl.html('widget.route.condition.expre_label')}
          </Balloon>
        </React.Fragment>
      ),
      dataIndex: 'expr',
      cell: (val, index, record) => (
        <div>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <InputTooltip
              {...init(`expre-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { expr: v })
                }
              })}
              triggerStyle={{ width: 200, minWidth: 200 }}
              addonTextBefore={`arg${record.index >= 0 ? record.index : ''}`}
              style={{ width: '100%' }}
              maxLength={64}
              showLimitHint
              placeholder={intl('widget.route.condition.expre_placeholder')}
            />
          </If>
        </div>
      ),
      width: 300,
      visible: protocol === 'dubbo' && parent !== 'MstMock',
    },
    {
      key: 'type',
      title: intl('widget.route.condition.params_type'),
      dataIndex: 'type',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <RemoteSelect
              width="100%"
              {...init(`type-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { type: v })
                }
              })}
              style={{ maxWidth: 250, width: '100%' }}
              dataSource={filter(typeData, item => item.visible)}
            />
          </If>
        </React.Fragment>
      ),
      width: 200,
      visible: protocol === 'dubbo' && parent === 'MstMock', // mst服务mock，在dubbo时也会有这个type
    },
    {
      key: 'name',
      title: intl('widget.mock.condition.params_name'),
      dataIndex: 'name',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <InputTooltip
                {...init(`name-${record.uid}`, {
                  initValue: val,
                  props: {
                    onChange: (v) => handleChange(record.uid, { name: v })
                  }
                })}
                style={{ width: '100%' }}
                triggerStyle={{ width: 200, minWidth: 200 }}
                maxLength={64}
                showLimitHint
                placeholder={find(typeData, item => item.value === record.type && item.visible) && find(typeData, item => item.value === record.type && item.visible).placeholder}
              />
              <If condition={getValue(`type-${record.uid}`) === 'param'}>
                <Balloon
                  align="t"
                  trigger={<Icon type="help" style={{ color: '#888', cursor: 'pointer', marginLeft: 4 }} />}
                  triggerType="hover"
                  style={{ minWidth: 360 }}
                >
                  {intl.html('widget.mock.condition.param_label')}
                </Balloon>
              </If>
              <If condition={getValue(`type-${record.uid}`) === 'rpccontext'}>
                <Balloon
                  align="t"
                  trigger={<Icon type="help" style={{ color: '#888', cursor: 'pointer', marginLeft: 4 }} />}
                  triggerType="hover"
                  style={{ minWidth: 360 }}
                >
                  {intl.html('widget.mock.condition.rpccontext_label')}
                </Balloon>
              </If>
            </div>
          </If>
        </React.Fragment>
      ),
      width: 300,
      visible: protocol === 'dubbo' && parent === 'MstMock', // mst服务mock，在dubbo时也会有这个type
    },
    {
      key: 'type',
      title: intl('widget.route.condition.params_type'),
      dataIndex: 'type',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <RemoteSelect
              width="100%"
              {...init(`type-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { type: v })
                }
              })}
              style={{ maxWidth: 250, width: '100%' }}
              dataSource={filter(typeData, item => item.visible)}
              followTrigger
            />
          </If>
        </React.Fragment>
      ),
      width: 200,
      visible: protocol === 'istio',
    },
    {
      key: 'name',
      title: intl('widget.route.condition.params_name'),
      dataIndex: 'name',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <InputTooltip
                {...init(`name-${record.uid}`, {
                  initValue: val,
                  props: {
                    onChange: (v) => handleChange(record.uid, { name: v })
                  }
                })}
                style={{ width: '100%' }}
                triggerStyle={{ width: 200, minWidth: 200 }}
                maxLength={64}
                showLimitHint
                placeholder={find(typeData, item => item.value === record.type) && find(typeData, item => item.value === record.type).placeholder}
              />
              <If condition={getValue(`type-${record.uid}`) === 'body'}>
                <Balloon
                  align="t"
                  trigger={<Icon type="help" style={{ color: '#888', cursor: 'pointer', marginLeft: 4 }} />}
                  triggerType="hover"
                  style={{ minWidth: 360 }}
                >
                  {intl.html('widget.route.condition.body_label')}
                </Balloon>
              </If>
            </div>
          </If>
        </React.Fragment>
      ),
      width: 300,
      visible: protocol === 'istio',
    },
    {
      key: 'cond',
      title: intl('widget.route.condition'),
      dataIndex: 'cond',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>
              {val}
            </Empty>
          </If>
          <If condition={!show}>
            <If condition={parent === 'MstMock'}>
              <If condition={(protocol === 'dubbo' || protocol === 'springCloud')}>
                <CascaderSelector
                  {...init(`cond-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => {
                        setValue(`value-${record.uid}`, undefined);
                        handleChange(record.uid, { cond: v, value: undefined });
                      }
                    }
                  })}
                  style={{ width: '100%' }}
                  dataSource={mstConditionData}
                  placeholder={intl('widget.route.condition_placeholder')}
                />
              </If>
              <If condition={protocol === 'istio'}>
                <Select
                  {...init(`cond-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => {
                        setValue(`value-${record.uid}`, undefined);
                        handleChange(record.uid, { cond: v, value: undefined });
                      }
                    }
                  })}
                  style={{ width: '100%' }}
                  dataSource={istioConditionData}
                  placeholder={intl('widget.route.condition_placeholder')}
                />
              </If>
            </If>
            <If condition={parent !== 'MstMock'}>
              <If condition={(protocol === 'dubbo' || protocol === 'springCloud')}>
                <CascaderSelector
                  {...init(`cond-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => {
                        setValue(`value-${record.uid}`, undefined);
                        handleChange(record.uid, { cond: v, value: undefined });
                      }
                    }
                  })}
                  style={{ width: '100%' }}
                  dataSource={conditionData}
                  placeholder={intl('widget.route.condition_placeholder')}
                />
              </If>
              <If condition={protocol === 'istio'}>
                <Select
                  {...init(`cond-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => {
                        setValue(`value-${record.uid}`, undefined);
                        handleChange(record.uid, { cond: v, value: undefined });
                      }
                    }
                  })}
                  style={{ width: '100%' }}
                  dataSource={istioConditionData}
                  placeholder={intl('widget.route.condition_placeholder')}
                />
              </If>
            </If>
          </If>
        </React.Fragment>
      ),
      width: 150,
      visible: protocol === 'dubbo' || protocol === 'springCloud' || protocol === 'istio',
    },
    {
      key: 'value',
      title: intl('widget.route.condition.value'),
      dataIndex: 'value',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <Choose>
              <When condition={record.cond === 'list'}>
                <Select
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  mode="tag"
                  dataSource={val}
                  style={{ width: '100%' }}
                  placeholder={intl('widget.route.condition.list_placeholder')}
                />
              </When>
              <When condition={record.cond === '%'}>
                <NumberPicker
                  style={{ width: '100%' }}
                  max={100}
                  min={0}
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  placeholder={intl('widget.route.condition.stream_percent_value_placeholder')}
                />
              </When>
              <When condition={includes(numberArr, record.cond)}>
                <Input
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  style={{ width: '100%' }}
                  placeholder={intl('widget.route.condition.input_value_placeholder')}
                />
              </When>
              {/* todo */}
              <When condition={record.cond === 'regexp'}>
                <Input
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  style={{ width: '100%' }}
                  placeholder={intl('widget.route.condition.input_regexp_placeholder')}
                />
              </When>
              <Otherwise>
                <NumberPicker
                  style={{ width: '100%' }}
                  {...init(`value-${record.uid}`, {
                    initValue: val,
                    props: {
                      onChange: (v) => handleChange(record.uid, { value: v })
                    }
                  })}
                  placeholder={intl('widget.route.condition.input_value_placeholder')}
                />
              </Otherwise>
            </Choose>
          </If>
        </React.Fragment>
      ),
      width: 300,
      visible: protocol === 'dubbo' || protocol === 'springCloud' || protocol === 'istio',
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => (
        <Icon type="delete" size="xs" style={{ cursor: 'pointer' }} onClick={() => handleDelete(record.uid)} />
      ),
      width: 100,
      visible: !show,
    },
  ];

  const handleChange = (uid, obj) => {
    const newData = map(dataSource, item => item.uid === uid ? ({ ...item, ...obj }) : item);
    onChange(newData);
  };

  const handleDelete = (uid) => {
    const newData = filter(dataSource, item => item.uid !== uid);
    onChange(newData);
  };

  const handleAdd = () => {
    const newTypeData = filter(typeData, item => item.visible);
    const headTypeData = head(newTypeData);
    const newData = [...dataSource, { uid: uniqueId(), type: get(headTypeData, 'value') }];
    onChange(newData);
  };

  return (
    <div className="condition-list">
      <Table dataSource={dataSource} hasBorder={false}>
        <For each="item" of={filter(columns, { visible: true })}>
          <Table.Column {...item} />
        </For>
      </Table>
      <If condition={!show}>
        <CommonEvent style={{ marginTop: 8 }} onClick={handleAdd} text={intl('widget.route.add_condition_rule')} />
      </If>
    </div>
  );
};

ConditionList.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  onChange: PropTypes.func,
  show: PropTypes.bool,
  protocol: PropTypes.string,
  method: PropTypes.string,
};

export default ConditionList;
