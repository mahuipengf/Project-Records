import React, { useEffect, useState } from 'react';
import { Empty, Icon, Table, Input } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { useIntl } from '@ali/widget-hooks';
import { uniqueId, filter, map } from 'lodash';
import PropTypes from 'prop-types';
import CommonEvent from 'components/CommonEvent';
import './index.less';

const TagList = (props) => {
  const { value, onChange, show, add = true } = props;
  const intl = useIntl();
  const [dataSource, setDataSource] = useState(value);
  const field = Field.useField();
  const { init } = field;

  useEffect(() => {
    setDataSource(value || []);
  }, [value]);

  const columns = [
    {
      key: 'key',
      title: intl('widget.common.name'),
      dataIndex: 'key',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <Input
              {...init(`key-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { key: v })
                }
              })}
              style={{ width: '100%' }}
              placeholder={intl('widget.common.please_enter_name')}
            />
          </If>
        </React.Fragment>
      ),
    },
    {
      key: 'value',
      title: intl('widget.route.condition.value'),
      dataIndex: 'value',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={show}>
            <Empty value={val}>{val}</Empty>
          </If>
          <If condition={!show}>
            <Input
              {...init(`value-${record.uid}`, {
                initValue: val,
                props: {
                  onChange: (v) => handleChange(record.uid, { value: v })
                }
              })}
              style={{ width: '100%' }}
              placeholder={intl('widget.route.condition.input_value_placeholder')}
            />
          </If>
        </React.Fragment>
      ),
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => (
        <Icon type="delete" size="xs" style={{ cursor: 'pointer' }} onClick={() => handleDelete(record.uid)} />
      ),
      visible: !show,
    },
  ];

  const handleChange = (uid, obj) => {
    const newData = map(dataSource, item => item.uid === uid ? ({ ...item, ...obj }) : item);
    onChange(newData);
  };

  const handleDelete = (uid) => {
    const newData = filter(dataSource, item => item.uid !== uid);
    onChange(newData);
  };

  const handleAdd = () => {
    const newData = [...dataSource, { uid: uniqueId() }];
    onChange(newData);
  };

  return (
    <div className="tag-list">
      <Table dataSource={dataSource} hasBorder={false}>
        <For each="item" of={columns}>
          <Table.Column {...item} />
        </For>
      </Table>
      <If condition={!show && add}>
        <CommonEvent style={{ marginTop: 8 }} onClick={handleAdd} text={intl('widget.common.add')} />
      </If>
    </div>
  );
};

TagList.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  onChange: PropTypes.func,
  show: PropTypes.bool,
  protocol: PropTypes.string,
  method: PropTypes.string,
};

export default TagList;
