import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { get, map, isEmpty } from 'lodash';
import { Loading, Empty } from '@ali/cn-design';
import ConditionList from 'containers/ConditionList';
import DataFields from 'components/DataFields';
import { lowerFirstData } from 'utils/transfer-data';
import IstioTagTable from 'pages/RouteManage/components/IstioTagTable';
import { mapConditions } from 'utils';

const RouteInfo = (props) => {
  const { id, appId, style, callback, value } = props;
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState(value || {});
  const intl = useIntl();
  const [searchValues] = useGlobalState('searchValues');

  useEffect(() => {
    if (id) {
      fetchData(id);
    }
  }, [id]);

  useEffect(() => {
    if (appId) {
      fetchCanaryPolicy(appId);
    }
  }, [appId]);

  const fetchCanaryPolicy = async (Id) => {
    const { regionId, namespaceId } = searchValues;
    const params = {
      regionId,
      namespaceId,
      appId: Id,
    };
    setIsLoading(true);
    const res = await services.getCanaryPolicy({
      params,
      customErrorHandle: (err, response, call) => {
        setIsLoading(false);
        call();
      }
    }) || {};
    const { id } = lowerFirstData(res);
    if (id) {
      fetchData(id);
    } else {
      setIsLoading(false);
    }
  };

  const fetchData = async (Id) => {
    const { regionId, namespaceId } = searchValues;
    const params = {
      regionId,
      namespaceId,
      policyId: Id,
    };
    setIsLoading(true);
    let res = await services.getRoutePolicy({
      params,
      customErrorHandle: (err, response, call) => {
        setIsLoading(false);
        call();
      }
    }) || {};
    res = lowerFirstData(res) || {};
    setIsLoading(false);
    const scRules = get(res, 'scRules', []);
    const newScRules = map(scRules, item => {
      const conditions = mapConditions(item.restItems, intl);
      return { ...item, conditions, protocol: 'springCloud' };
    });
    const dubboArgRules = get(res, 'dubboArgRules', []);
    const newDubboRules = map(dubboArgRules, item => {
      const conditions = mapConditions(item.argumentItems, intl);
      return { ...item, conditions, protocol: 'dubbo' };
    });
    callback && callback({ ...res, rules: [...newScRules, ...newDubboRules] });
    setData({ ...res, rules: [...newScRules, ...newDubboRules], isIstioApp: !isEmpty(res.istioRules) });
  };

  const CONDITION = { OR: intl('widget.route.condition_or'), AND: intl('widget.route.condition_and') };

  const protocol = { springCloud: 'Spring Cloud', dubbo: 'Dubbo' };

  const getItems = (item) => [
    {
      dataIndex: 'protocol',
      label: intl('widget.route.frame_type'),
      visible: true,
      render: val => protocol[val],
    },
    {
      dataIndex: 'condition',
      label: intl('widget.route.condition_mode'),
      visible: true,
    },
    {
      dataIndex: 'path',
      label: intl('widget.route.path'),
      visible: item.protocol === 'springCloud',
    },
    {
      dataIndex: 'service',
      label: intl('widget.app.service_method'),
      visible: item.protocol === 'dubbo',
      span: 24,
    },
    {
      dataIndex: 'conditions',
      label: intl('widget.route.condition_list'),
      visible: !item.isIstioApp,
      span: 24,
      render: (val) => <ConditionList value={val} show protocol={item.protocol} />
    },
  ];

  return (
    <Loading style={{ width: '100%', ...style }} visible={isLoading}>
      <If condition={isEmpty(data)}>
        <Empty showIcon emptyMessage={intl('widget.common.no_data')} />
      </If>
      <If condition={!isEmpty(data)}>
        <If condition={!data.isIstioApp && data.triggerPolicy === 'CONTENT'}>
          <For each="item" index="index" of={data.rules}>
            <div key={index} className="common-box">
              <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.app.flow_rule', { n: index + 1 })}</div>
              <DataFields
                key={index}
                dataSource={{
                  condition: CONDITION[item.condition],
                  path: item.path,
                  service: `${item.serviceName || ''}:${item.version || ''}:${item.group || ''} / ${item.methodName || ''} (${item.paramTypes || ''})`,
                  conditions: item.conditions || [],
                  protocol: item.protocol,
                }}
                items={getItems(item)}
                style={{ padding: '8px 0', borderBottom: 0 }}
              />
            </div>
          </For>
        </If>
        <If condition={data.isIstioApp}>
          <IstioTagTable appId={data.appId} show />
        </If>
      </If>
    </Loading>
  );
};

RouteInfo.propTypes = {
  id: PropTypes.number,
  appId: PropTypes.string,
  style: PropTypes.objectOf(PropTypes.any),
  value: PropTypes.objectOf(PropTypes.any),
  callback: PropTypes.func,
};

export default RouteInfo;
