// sc 的 path 选择输入组件
import { Input, Select } from '@ali/cn-design';
import React, { useState } from 'react';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';

const ScPath = (props) => {
  const { value, dataSource = [], ...rest } = props;
  const [isSelect, setIsSelect] = useState(true);
  const intl = useIntl();

  return (
    <React.Fragment>
      <If condition={isSelect}>
        <Select value={value} dataSource={dataSource} followTrigger {...rest} />
      </If>
      <If condition={!isSelect}>
        <Input value={value} {...rest} />
      </If>
      <span style={{ marginLeft: 4 }} className="link-primary" onClick={() => setIsSelect(!isSelect)}>{isSelect ? intl('widget.sc_change_input') : intl('widget.sc_change_select')}</span>
    </React.Fragment>
  );
};

ScPath.propTypes = {
  value: PropTypes.func,
  dataSource: PropTypes.arrayOf(PropTypes.any),
};

export default ScPath;
