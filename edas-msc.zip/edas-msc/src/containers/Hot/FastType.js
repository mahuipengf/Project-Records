// 快捷方式
import React from 'react';
import CardBox from 'components/CardBox';
import { MenuButton } from '@alicloud/console-components';
import { useIntl } from '@ali/widget-hooks';
import Cookie from 'js-cookie';

const { Item } = MenuButton;

const FastType = () => {
  const intl = useIntl();
  const aliyunSite = Cookie.get('aliyun_site');
  const list = [
    {
      title: intl('widget.app.app_access'),
      sub: [
        { title: intl('widget.msc.containers.app_access_title1'), url: intl('widget.msc.containers.app_access_url1') },
        // { title: intl('widget.msc.containers.app_access_title2'), url: intl('widget.msc.containers.app_access_url2') },
        // { title: intl('widget.msc.containers.app_access_title3'), url: intl('widget.msc.containers.app_access_url3') },
        { title: intl('widget.msc.containers.app_access_title4'), url: intl('widget.msc.containers.app_access_url4') },
      ]
    },
    {
      title: intl('widget.msc.containers.product_pricing'),
      url: intl('widget.msc.containers.product_pricing_url'),
    },
    {
      title: intl('widget.msc.containers.hotspot_func'),
      sub: [
        { title: intl('widget.msc.containers.hotspot_func_title1'), url: intl('widget.msc.containers.hotspot_func_url1') },
        { title: intl('widget.msc.containers.hotspot_func_title2'), url: intl('widget.msc.containers.hotspot_func_url2') },
        { title: intl('widget.msc.containers.hotspot_func_title3'), url: intl('widget.msc.containers.hotspot_func_url3') },
        { title: intl('widget.msc.containers.hotspot_func_title4'), url: intl('widget.msc.containers.hotspot_func_url4') },
        { title: intl('widget.msc.containers.hotspot_func_title5'), url: intl('widget.msc.containers.hotspot_func_url5') },
        { title: intl('widget.msc.containers.hotspot_func_title6'), url: intl('widget.msc.containers.hotspot_func_url6') },
        { title: intl('widget.msc.containers.hotspot_func_title7'), url: intl('widget.msc.containers.hotspot_func_url7') },
      ]
    },
    {
      title: intl('widget.msc.containers.best_practices'),
      sub: [
        { title: intl('widget.msc.containers.best_practices_title1'), url: intl('widget.msc.containers.best_practices_url1') },
        { title: intl('widget.msc.containers.best_practices_title2'), url: intl('widget.msc.containers.best_practices_url2') },
        { title: intl('widget.msc.containers.best_practices_title3'), url: intl('widget.msc.containers.best_practices_url3') },
        { title: intl('widget.msc.containers.best_practices_title4'), url: intl('widget.msc.containers.best_practices_url4') },
        { title: intl('widget.msc.containers.best_practices_title5'), url: intl('widget.msc.containers.best_practices_url5') },
        { title: intl('widget.msc.containers.best_practices_title6'), url: intl('widget.msc.containers.best_practices_url6') },
        { title: intl('widget.msc.containers.best_practices_title7'), url: intl('widget.msc.containers.best_practices_url7') },
      ]
    },
  ];

  return (
    <CardBox title={intl('widget.msc.fast_type')}>
      <div style={{ padding: '0 8px', lineHeight: '32px' }} className="fast-type">
        <For each="item" index="index" of={list}>
          <If condition={!!item.sub}>
            <MenuButton text label={item.title} key={index} style={{ color: '#555', width: '50%', textAlign: 'left' }} autoWidth={false} className="aaaa">
              <For each="sub" index="subIndex" of={item.sub}>
                {!(aliyunSite === 'INTL' && sub.title === intl('widget.msc.containers.hotspot_func_title7')) && <Item key={subIndex} style={{ padding: '0 8px' }}>
                  <a style={{ color: '#555', width: 'auto' }} href={sub.url} target="_blank">
                    {sub.title}
                  </a>
                </Item>}
              </For>
            </MenuButton>
          </If>
          <If condition={!item.sub}>
            <a key={index} style={{ color: '#555', width: '50%' }} href={item.url} target="_blank">
              {item.title}
            </a>
          </If>
        </For>
      </div>
    </CardBox>
  );
};

export default FastType;
