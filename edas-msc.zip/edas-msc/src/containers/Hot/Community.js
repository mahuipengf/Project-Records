import React, { useEffect, useState } from 'react';
import CardBox from 'components/CardBox';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import services from 'services';
import { map } from 'lodash';
import Cookie from 'js-cookie';

const Community = () => {
  const intl = useIntl();
  const aliyunSite = Cookie.get('aliyun_site');
  const list = [
    {
      Url: intl('widget.msc_hot_overview.communites.url1'),
      Title: intl('widget.msc_hot_overview.communites.title1'),
    },
    {
      Url: aliyunSite === 'INTL' ? '#' : intl('widget.msc_hot_overview.communites.url2'),
      Title: intl('widget.msc_hot_overview.communites.title2'),
    },
    {
      Url: aliyunSite === 'INTL' ? '#' : intl('widget.msc_hot_overview.communites.url3'),
      Title: intl('widget.msc_hot_overview.communites.title3'),
    },
    {
      Url: aliyunSite === 'INTL' ? '#' : intl('widget.msc_hot_overview.communites.url4'),
      Title: intl('widget.msc_hot_overview.communites.title4'),
    },
    {
      Url: aliyunSite === 'INTL' ? '#' : intl('widget.msc_hot_overview.communites.url5'),
      Title: intl('widget.msc_hot_overview.communites.title5'),
    },
    {
      Url: intl('widget.msc_hot_overview.communites.url6'),
      Title: intl('widget.msc_hot_overview.communites.title6'),
    },
    {
      Url: intl('widget.msc_hot_overview.communites.url7'),
      Title: intl('widget.msc_hot_overview.communites.title7'),
    },
  ];
  return (
    <CardBox title={intl('widget.msc.community_recommendation')}>
      <For each="item" index="index" of={list}>
        <div key={index} style={{ padding: 8 }}>
          {item.Url === '#' ? 
            <span style={{color: '#555'}}>{item.Title}</span> : 
            <a href={item.Url} target="_blank">
              {item.Title}
            </a>
          }
        </div>
      </For>
    </CardBox>
  );
};

export default Community;
