/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react';
import CardBox from 'components/CardBox';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import FastType from './FastType';
import './fast-type.less';
import Community from './Community';
import Cookie from 'js-cookie';
import { Card, Button, Icon, Balloon, Progress } from '@ali/cn-design';
import { get } from 'lodash';
import services from 'services';
import { timeFmtC } from 'utils/time';
import { IS_SAU_BUSINESS } from 'constants';

const Hot = () => {
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';
  const [resource, setResource] = useState({ currCapacity: 0, initCapacity: 0, percent: 0, resourcePackageCount: 0 });
  const [mscAccount] = useGlobalState('mscAccount');
  const [searchValues] = useGlobalState('searchValues');
  const { regionId } = searchValues;
  const Status = get(mscAccount, 'Status'); // 是否开通 1未开通 2 开通
  const Version = get(mscAccount, 'Version'); // 开通版本
  const FreeOpen = get(mscAccount, 'FreeOpen', 0); // 试用版开通时间
  const FreeVersion = get(mscAccount, 'FreeVersion', 0); // 是否开通试用版 0 未开通 1 开通试用版 2试用版到期
  // const Status = 2;
  // const Version = 2;
  // const FreeOpen = '1678863520200'; // 1665199757969
  // const FreeVersion = 1;
  const UserId = get(mscAccount, 'UserId');
  const TimeLeft = get(mscAccount, 'TimeLeft');
  const intl = useIntl();
  let openHref = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn';
  let rechargeHref = 'https://usercenter2.aliyun.com/finance/fund-management/recharge';
  const openTrialHref = 'https://common-buy.aliyun.com/?commodityCode=mse_sergofree_public_cn';
  const openEnterpriseHref = `https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn&orderType=UPGRADE&instanceId=synthetic_post_${UserId}`;
  const commonResourcePackage = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_dp_cn';
  if (aliyunSite === "INTL") {
    openHref =
      "https://common-buy-intl.alibabacloud.com/?commodityCode=mse_basic_public_intl";
    rechargeHref =
      "https://usercenter2-intl.aliyun.com/renew/manual?spm=5176.mse-ops.top-nav.ditem-ren.36c3142fCQOCud&expiresIn=&commodityCode=";
  }
  const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL'); // 虚商渠道接入 屏蔽续费按钮
  const isVirtualBusinessChannel = channel === 'OFFICIAL'; // OFFICIAL 为默认未接入虚商

  useEffect(() => {
    fetchResoucePackageStatus();
  }, []);
  const fetchResoucePackageStatus = async () => {
    const res = await services.GetResourcePackageStatus({
      params: {
        Region: regionId
      }
    });
    setResource({ ...res, percent: (res.currCapacity / res.initCapacity) * 100 });
  };
  const version = {
    User: {
      title: intl('widget.msc.common.resource.open')
    },
    Basic: {
      title: intl('widget.msc.official_version'),
      src: 'https://img.alicdn.com/imgextra/i4/O1CN01UKWd9R1igU4dnv6Zk_!!6000000004442-55-tps-109-35.svg',
    },
    Professional: {
      title: intl('widget.msc.professional_version'),
      src: 'https://img.alicdn.com/imgextra/i1/O1CN01bIj3Uj1I5gEjBlvdD_!!6000000000842-55-tps-109-35.svg',
    },
    Enterprise: {
      title: intl('widget.msc.enterprise_version'),
      src: 'https://img.alicdn.com/imgextra/i1/O1CN01nj5JQj1JGxbhU8F1W_!!6000000001002-55-tps-109-35.svg',
    },
    Trial: {
      title: intl('widget.msc.enterprise_version'),
      src: 'https://img.alicdn.com/imgextra/i4/O1CN01on9HX81IMcvDK1bIz_!!6000000000879-55-tps-109-35.svg',
    },
  };
  const getVersion = () => {
    if (FreeVersion === 1 && Status !== 3) { // 试用版
      return <span style={{ position: 'absolute', top: '-12px', left: '-17px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: 'calc(100% + 17px)' }}><img style={{ position: 'relative', zIndex: 2 }} src={version.Trial.src} /><span style={{ fontFamily: 'PingFangSC', fontSize: '14px', fontWeight: 500, lineHeight: '18px', top: '6px' }}>{timeFmtC(Number(FreeOpen) + (30 * 24 * 60 * 60 * 1000), 'YYYY-MM-DD')}到期</span></span>;
    }
    if (Status === 1) { // 未开通
      return <span style={{ fontFamily: 'PingFangSC', fontSize: '14px', fontWeight: 700, color: '#333' }}>{version.User.title}</span>;
    }
    if (Status === 2) { // 已开通
      if (!Version) { // 基础版
        return <span style={{ position: 'absolute', top: '-12px', left: '-17px' }}><img style={{ position: 'relative', zIndex: 2 }} src={version.Basic.src} /></span>;
      } else if (Version === 1) { // 专业版
        return <span style={{ position: 'absolute', top: '-12px', left: '-17px' }}><img style={{ position: 'relative', zIndex: 2 }} src={version.Professional.src} /></span>;
      } else if (Version === 2) { // 企业版
        return <span style={{ position: 'absolute', top: '-12px', left: '-17px' }}><img style={{ position: 'relative', zIndex: 2 }} src={version.Enterprise.src} /></span>;
      }
    }
    if (Status === 3) {
      if (!Version) {
        return <span style={{ position: 'absolute', top: '-12px', left: '-17px' }}><img style={{ position: 'relative', zIndex: 2 }} src={version.Basic.src} /><span style={{ position: 'absolute', left: 252, fontFamily: 'PingFangSC', fontSize: '12px', color: '#EC4344', fontWeight: 400, lineHeight: '18px', top: '6px' }}>欠费停机</span></span>;
      } else if (Version === 1) {
        return <span style={{ position: 'absolute', top: '-12px', left: '-17px' }}><img style={{ position: 'relative', zIndex: 2 }} src={version.Professional.src} /><span style={{ position: 'absolute', left: 252, fontFamily: 'PingFangSC', fontSize: '12px', color: '#EC4344', fontWeight: 400, lineHeight: '18px', top: '6px' }}>欠费停机</span></span>;
      } else if (Version === 2) {
        return <span style={{ position: 'absolute', top: '-12px', left: '-17px' }}><img style={{ position: 'relative', zIndex: 2 }} src={version.Enterprise.src} /><span style={{ position: 'absolute', left: 252, fontFamily: 'PingFangSC', fontSize: '12px', color: '#EC4344', fontWeight: 400, lineHeight: '18px', top: '6px' }}>欠费停机</span></span>;
      }
    }
  };
  const commonProps = {
    style: { width: 320, marginBottom: 16 },
    title: getVersion(),
    // extra: <Icon size="xs" type="ellipsis-vertical" />,
    showTitleBullet: false,
    showHeadDivider: false,
    contentHeight: 'auto',
  };
  const CountDown = (new Date().getTime() - Number(FreeOpen)) <= (15 * 24 * 60 * 60 * 1000); // 试用版是否超过15天
  const target = <div>{intl('widget.msc.add.group.service')}<Icon type="qrcode" /></div>;
  return (
    <React.Fragment>
      {/* 国内站 */}
      <If condition={aliyunSite !== 'INTL'}>
        <Card {...commonProps}>
          {/* 公测用户 */}
          <If condition={Status === 0}>
            <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
              {intl('widget.msc.hot.remain.resources')}
            </div>
            <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
              <span style={{ display: 'flex', alignItems: 'baseline', marginBottom: '-6px' }}><span style={{ fontSize: '24px', fontWeight: 'bold' }}>{resource.currCapacity || 0}</span><span style={{ color: '#666', marginLeft: 4, fontSize: '12px' }}>/{resource.initCapacity || 0} {intl('widget.msc.hot.agent.company')}</span></span>
              <span style={{ flex: 1, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>{intl.html('widget.msc.hot.commo_buy.resource.package', { commonResourcePackage })}</span>
            </div>
            <div>
              <Progress percent={resource.percent || 0} size="small" textRender={() => ''} />
            </div>
            <div style={{ fontWeight: '300', fontSize: '12px', fontFamily: 'PingFangSC', }}>{intl.html('widget.msc.hot.current.resource.package.count')}{resource.resourcePackageCount || 0}</div>
            <div style={{ display: 'flex', background: '#fafafa', padding: 8 }}>
              <span style={{ flex: 1 }}>{intl('widget.msc.public_beta')}</span>
              <span style={{ flex: 1 }}>{intl.html('widget.msc.valid_period', { n: TimeLeft || 0 })}</span>
              <span style={{ flex: 1 }} className="link-primary">{intl.html('widget.msc.public_beta_to_commercialization')}</span>
            </div>
          </If>
          <If condition={Status === 1}>
            <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
              <span style={{ color: '#666666', fontWeight: 500, lineHeight: '18px' }}>{intl('widget.msc.billing.method')}</span>
              <span style={{ marginLeft: 12, color: '#333333', fontWeight: 700 }}>{intl('widget.msc.charge.by.volume')}</span>
              <span style={{ flex: 1, textAlign: 'right', marginTop: '-4px' }}>
                <Button type="primary" style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}>
                  <span
                    data-tracker="widget.overview.msc.open_the_official_version_new&type=widget-overview-governance-open"
                  >
                    {intl.html('widget.msc.open_the_official_version_new', { openHref })}
                  </span>
                </Button>
                <If condition={FreeVersion === 0}>
                  <Button
                    data-tracker="widget.overview-governance-msc-trial-open&type=widget-overview-governance-open"
                    type="primary"
                    style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}
                    onClick={() => (window.open(
                      openTrialHref,
                      '_blank'
                    ))}
                  >
                    {intl('widget.msc.common.free.trial')}
                  </Button>
                </If>
              </span>
            </div>
          </If>
          <If condition={Status === 2}>
            <If condition={FreeVersion !== 1}>
              <If condition={Version === 1 || Version === 2}> {/* 资源包（专业版、企业版） */}
                <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
                  {intl('widget.msc.hot.remain.resources')}
                </div>
                <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
                  <span style={{ display: 'flex', alignItems: 'baseline', marginBottom: '-6px' }}><span style={{ fontSize: '24px', fontWeight: 'bold' }}>{resource.currCapacity || 0}</span><span style={{ color: '#666', marginLeft: 4, fontSize: '12px' }}>/{resource.initCapacity || 0} {intl('widget.msc.hot.agent.company')}</span></span>
                  <span style={{ flex: 1, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>{intl.html('widget.msc.hot.commo_buy.resource.package', { commonResourcePackage })}</span>
                </div>
                <div>
                  <Progress percent={resource.percent || 0} size="small" textRender={() => ''} />
                </div>
                <div style={{ fontWeight: '300', fontSize: '12px', fontFamily: 'PingFangSC', }}>{intl.html('widget.msc.hot.current.resource.package.count')}{resource.resourcePackageCount || 0}</div>
              </If>
            </If>
            <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
              <If condition={FreeVersion !== 1}>
                <span style={{ color: '#666666', fontWeight: 500, lineHeight: '18px' }}>{intl('widget.msc.billing.method')}</span>
                <span style={{ marginLeft: 12, color: '#333333', fontWeight: 700 }}>{intl('widget.msc.charge.by.volume')}</span>
              </If>
              <If condition={FreeVersion === 1}>
                <span style={{ color: '#666666', fontWeight: 500, lineHeight: '18px' }}>{intl('widget.msc.billing.method')}</span>
                <span style={{ marginLeft: 12, color: '#333333', fontWeight: 700 }}>{intl('widget.msc.trial.period')}</span>
              </If>
              <span style={{ flex: 1, textAlign: 'right', marginTop: '-4px' }}>
                <If condition={FreeVersion !== 1}>
                  <If condition={!Version}>
                    <Button type="primary" style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px', color: '#fff' }}>{intl.html('widget.msc.upgrade_to_professional_edition.enterprise_new', { openEnterpriseHref })}</Button>
                    <If condition={isVirtualBusinessChannel}>
                      <Button style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}>{intl.html('widget.msc.open_the_official_version_renew', { rechargeHref })}</Button>
                    </If>
                  </If>
                  <If condition={Version === 1}>
                    <Button type="primary" style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px', color: '#fff' }}>{intl.html('widget.msc.upgrade_to_professional_edition.enterprise_new', { openEnterpriseHref })}</Button>
                    <If condition={isVirtualBusinessChannel}>
                      <Button style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}>{intl.html('widget.msc.open_the_official_version_renew', { rechargeHref })}</Button>
                    </If>
                  </If>
                  <If condition={Version === 2}>
                    <If condition={isVirtualBusinessChannel}>
                      <Button style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}>{intl.html('widget.msc.open_the_official_version_renew', { rechargeHref })}</Button>
                    </If>
                  </If>
                </If>
                <If condition={FreeVersion === 1}>
                  <Button
                    data-tracker="widget.overview-governance-msc-open&type=widget-overview-governance-open"
                    type="primary"
                    style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}
                    onClick={() => (window.open(
                      openHref,
                      '_blank'
                    ))}
                  >
                    {intl('widget.msc.common.open')}
                  </Button>
                  {/* <Button type="primary" style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px', color: '#fff' }}>{intl.html('widget.msc.upgrade_to_professional_edition.enterprise_new', { openEnterpriseHref })}</Button> */}
                  {/* <If condition={isVirtualBusinessChannel}>
                    <Button style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}>{intl.html('widget.msc.open_the_official_version_renew', { rechargeHref })}</Button>
                  </If> */}
                </If>
              </span>
            </div>
          </If>
          <If condition={Status === 3}>
            <If condition={Version === 1 || Version === 2}>
              <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
                {intl('widget.msc.hot.remain.resources')}
              </div>
              <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
                <span style={{ display: 'flex', alignItems: 'baseline', marginBottom: '-6px' }}><span style={{ fontSize: '24px', fontWeight: 'bold' }}>{resource.currCapacity || 0}</span><span style={{ color: '#666', marginLeft: 4, fontSize: '12px' }}>/{resource.initCapacity || 0} {intl('widget.msc.hot.agent.company')}</span></span>
                <span style={{ flex: 1, display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>{intl.html('widget.msc.hot.commo_buy.resource.package', { commonResourcePackage })}</span>
              </div>
              <div>
                <Progress percent={resource.percent || 0} size="small" textRender={() => ''} />
              </div>
              <div style={{ fontWeight: '300', fontSize: '12px', fontFamily: 'PingFangSC', }}>{intl.html('widget.msc.hot.current.resource.package.count')}{resource.resourcePackageCount || 0}</div>
            </If>
            <div style={{ display: 'flex', marginTop: '6px', fontFamily: 'PingFangSC', }}>
              <span style={{ color: '#666666', fontWeight: 500, lineHeight: '18px' }}>{intl('widget.msc.billing.method')}</span>
              <span style={{ marginLeft: 12, color: '#333333', fontWeight: 700 }}>{intl('widget.msc.charge.by.volume')}</span>
              <span style={{ flex: 1, textAlign: 'right', marginTop: '-4px' }}>
                <If condition={!Version}>
                  <If condition={isVirtualBusinessChannel}>
                    <Button style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}>{intl.html('widget.msc.open_the_official_version_renew', { rechargeHref })}</Button>
                  </If>
                </If>
                <If condition={Version === 1}>
                  <If condition={isVirtualBusinessChannel}>
                    <Button style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}>{intl.html('widget.msc.open_the_official_version_renew', { rechargeHref })}</Button>
                  </If>
                </If>
                <If condition={Version === 2}>
                  <If condition={isVirtualBusinessChannel}>
                    <Button style={{ height: '24px', weight: '48px', fontSize: '12px', textAlign: 'center', lineHeight: '16px', borderRadius: '2px', marginLeft: '8px' }}>{intl.html('widget.msc.open_the_official_version_renew', { rechargeHref })}</Button>
                  </If>
                </If>
              </span>
            </div>
          </If>
          <div className="font-group">
            <div className="font-group-line" />
            <div className="font-style">
              <Balloon type="primary" trigger={target} closable={false} align="br">
                <img src="https://img.alicdn.com/imgextra/i2/O1CN01DB6Y311fyrAZRrJtN_!!6000000004076-2-tps-654-652.png" style={{ width: 100 }} />
              </Balloon>
            </div>
          </div>
        </Card>
      </If>
      {/* 国际站 */}
      <If condition={aliyunSite === 'INTL'}>
        <CardBox title={intl('widget.msc.resource_overview')}>
          <div style={{ borderBottom: '1px solid #eee', paddingBottom: 8 }}>
            <div style={{ display: 'flex', padding: 8, fontWeight: 500 }}>
              <span style={{ flex: 1 }}>{intl('widget.msc.current_version')}</span>
              <span style={{ flex: 1 }}>{intl('widget.msc.billing_mode')}</span>
              {/* 不是专业版或不可用时 */}
              {/* 企业版暂不上线 */}
              <If condition={(Version !== 2 && Status === 2 && aliyunSite !== 'INTL') || (Status !== 2 && (Version !== 1 || Status !== 2))}>
                <span style={{ flex: 1 }}>{intl('widget.common.operating')}</span>
              </If>
            </div>
            {/* 公测用户 */}
            <If condition={Status === 0}>
              <div style={{ display: 'flex', background: '#fafafa', padding: 8 }}>
                <span style={{ flex: 1 }}>{intl('widget.msc.public_beta')}</span>
                <span style={{ flex: 1 }}>{intl.html('widget.msc.valid_period', { n: TimeLeft || 0 })}</span>
                <span style={{ flex: 1 }} className="link-primary">{intl.html('widget.msc.public_beta_to_commercialization')}</span>
              </div>
            </If>
            {/* 新用户 */}
            <If condition={Status === 1}>
              <div style={{ display: 'flex', background: '#fafafa', padding: 8, alignItems: 'center' }}>
                <span style={{ flex: 1 }}>{intl('widget.msc.nonactivated')}</span>
                <span style={{ flex: 1 }}>{intl('widget.common.none')}</span>
                <div style={{ flex: 1 }} className="link-primary">{intl.html('widget.msc.open_the_official_version', { openHref })}</div>
              </div>
            </If>
            {/* 可用 */}
            <If condition={Status === 2}>
              <div style={{ display: 'flex', background: '#fafafa', padding: 8 }}>
                <If condition={!Version}>
                  <span style={{ flex: 1 }}>{intl('widget.msc.official_version')}</span>
                </If>
                <If condition={Version === 1}>
                  <span style={{ flex: 1 }}>{intl('widget.msc.professional_version')}</span>
                </If>
                <If condition={Version === 2}>
                  <span style={{ flex: 1 }}>{intl('widget.msc.enterprise_version')}</span>
                </If>
                <span style={{ flex: 1 }}>{intl('widget.msc.pay_as_you_go')}</span>
                {/* <If condition={Version !== 1}>
                  <span style={{ flex: 1 }} className="link-primary">{intl.html('widget.msc.upgrade_to_professional_edition', { userId: UserId })}</span>
                </If> */}
                {/* userId: UserId */}
                <If condition={aliyunSite !== 'INTL'}>
                  <If condition={Version !== 2}>
                    <span style={{ flex: 1 }} className="link-primary">{intl.html('widget.msc.upgrade_to_professional_edition.enterprise', { openEnterpriseHref })}</span>
                  </If>
                </If>
              </div>
            </If>
            {/* 欠费停机 */}
            <If condition={Status === 3}>
              <div style={{ display: 'flex', background: '#fafafa', padding: 8 }}>
                <span style={{ flex: 1 }}>
                  <If condition={!Version}>
                    <span style={{ flex: 1 }}>{intl('widget.msc.official_version')}</span>
                  </If>
                  <If condition={Version === 1}>
                    <span style={{ flex: 1 }}>{intl('widget.msc.professional_version')}</span>
                  </If>
                  <span style={{ color: 'red' }}>{intl('widget.msc.paused')}</span>
                </span>
                <span style={{ flex: 1 }}>{intl('widget.msc.pay_as_you_go')}</span>
                <span style={{ flex: 1, padding: 0 }} className="link-primary"> {intl.html('widget.msc.recharge', { rechargeHref })}</span>
              </div>
            </If>
          </div>
          <div style={{ padding: 8, display: 'flex' }}>
            <span>{intl('widget.msc.join_in_dingding')}</span>
            <img src="https://img.alicdn.com/imgextra/i4/O1CN01uJCfFX1Xcr5qkpnzb_!!6000000002945-2-tps-890-896.png" style={{ width: 100 }} />
          </div>
        </CardBox>
      </If>
      <FastType />
      <Community />
    </React.Fragment >
  );
};

export default Hot;
