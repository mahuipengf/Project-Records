import React, { useState, useEffect } from 'react';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { Select, Icon } from '@ali/cn-design';
import { head, map, find, assign } from 'lodash';
import PropTypes from 'prop-types';
import services from 'services';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const TagSelector = (props) => {
  const { value, onChange, namespaces, appId, ...reset } = props;
  const [searchValues] = useGlobalState('searchValues');
  const [tagList, setTagList] = useState([]);
  const [isLoadingTag, setIsLoadingTag] = useState(false);

  const intl = useIntl();
  const { regionId, namespaceId } = assign({}, searchValues, MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? namespaces : {});

  useEffect(() => {
    handleChangeAppId(appId);
  }, [appId]);

  const handleChangeAppId = async (val) => {
    if (!val) return;
    setIsLoadingTag(true);
    const Data = await services.GetApplicationTags({
      params: {
        regionId,
        namespaceId,
        appId: val,
        source: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'EDAS' : undefined
      }
    });
    let newData = [];
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      newData = map(Data.data || [], item => ({
        ...item,
        key: item.tag,
        value: item.tag,
        label: item.tag,
      }));
    } else {
      newData = map(Data || [], item => ({
        ...item,
        key: item.Tag,
        value: item.Tag,
        label: item.Tag,
      }));
    }
    if (!value) {
      const firstItem = head(newData) || {};
      handleChangeTag(firstItem.value);
    } else {
      handleChangeTag(value);
    }
    setIsLoadingTag(false);
    setTagList(newData);
  };

  const handleChangeTag = (tag) => {
    onChange && onChange(tag);
  };

  return (
    <React.Fragment>
      <Select
        state={isLoadingTag ? 'loading' : ''}
        showSearch
        style={{ width: '97%' }}
        dataSource={tagList}
        value={value}
        onChange={(val) => handleChangeTag(val)}
        placeholder={intl('widget.common.select_tag')}
        {...reset}
      />
      <Icon type="refresh" style={{ marginLeft: 8, cursor: 'pointer' }} onClick={() => handleChangeAppId(appId)} />
    </React.Fragment>
  );
};

TagSelector.propTypes = {
  onChange: PropTypes.func,
  appId: PropTypes.number,
  value: PropTypes.number,
  namespaces: PropTypes.objectOf(PropTypes.any),
};

export default TagSelector;
