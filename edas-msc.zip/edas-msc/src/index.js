/**
 * -----------------------------------------------------------
 * 此文件为 widget 的入口文件，通常来说开发者无需关注这个文件
 * 此入口文件主要用于数据传递与功能配置
 * -----------------------------------------------------------
 */
import { createRoot } from '@ali/widget-utils-rc';
import { WIDGET_ID } from './constants';
import stateHandlers from './stateHandlers';
import App from './app';
import '@alicloud/console-components/dist/wind.css';
import '@ali/cn-design/dist/index.css';
import '@alife/aisc-widgets/build/index.css';
import './index.less';

export default createRoot({ id: WIDGET_ID, stateHandlers })(App);
