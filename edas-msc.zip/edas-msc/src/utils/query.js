
import _ from 'lodash';
import queryString from 'querystring';

export const queryDecode = () => {
  const { search = '?', hash = '?' } = window.location;
  const searchs = queryString.parse(_.split(search, '?')[1]);
  const hashs = queryString.parse(_.split(hash, '?')[1]);
  return { ...searchs, ...hashs, };
};

export const queryDecodeHash = () => {
  const { hash = '?' } = window.location;
  const hashs = queryString.parse(_.split(hash, '?')[1]);
  return hashs;
};

export const queryEncode = (query = {}) => {
  return queryString.encode(query) || '';
};

// 修改url后搜索参数，兼容 hashRouter、browserRouter
export const changeQuery = (query, callBack) => {
  if (query) {
    const { hash } = window.location;
    const hashUrl = `${_.split(hash, '?')[0]}`;
    const oldQuery = hashUrl ? queryDecodeHash() : queryDecode();
    const newQuery = { ...oldQuery, ...query };
    const newSearch = decodeURIComponent(queryEncode(newQuery));
    window.history.pushState({}, '', `${_.split(hash, '?')[0]}?${newSearch}`);
    callBack && callBack();
  }
};

export default {
  changeQuery,
  queryEncode,
  queryDecode,
  queryDecodeHash,
};
