function Validator(rule) {
	// 校验规则
	this.rule = rule || {};
}

function isUndefined(val) {
	return val === undefined;
}

Validator.prototype.validate = function (name, value, values) {
	// 根据名字以及值做校验
	// console.log('rule--', this.rule, name, value);
	if (!name) {
		console.warn('name is require in validateField!');
		return;
	}
	let errors = [];
	if (this.rule[name]) {
		let target = this.rule[name];
		const required = typeof target.required === "function" ? target.required(values) : target.required;
		if (required) {
			if (!value && value !== 0) {
				errors.push(target.requiredMessage);
				return { [name]: { errors } };
			}
		}
		if (target.pattern) {
			console.log(target.pattern.test(value));
			if (!value) {
				return null;
			}
			// console.log(target);
			// console.log(value);
			// console.log(!target.pattern.test(value));
			if (!target.pattern.test(value)) {
				errors.push(target.patternMessage);
			}
		}
		if ((!isUndefined(target.min) || !isUndefined(target.max)) && (value || value === 0)) {
			// if (!value && value !== 0) {
			// 	return;
			// }
			if (
				(!isUndefined(target.min) && value < target.min) ||
				(!isUndefined(target.max) && value > target.max)
			) {
				errors.push(target.minmaxMessage);
			}
		}
	}
	return errors.length ? { [name]: { errors } } : null;
};

Validator.prototype.validateAll = function (values = {}) {
	// 校验所有数据
	if (!values) {
		return null;
	}
	const keys = Object.keys(this.rule) || {};
	let errors = null;
	keys.forEach((k) => {
		let err = this.validate(k, values[k], values);
		if (err) {
			errors = errors || {};
			errors[k] = err[k];
		}
	});
	return errors;
};

export default Validator;
