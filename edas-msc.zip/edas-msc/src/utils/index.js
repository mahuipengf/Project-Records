import { isEmpty, isAllEmpty, isNoneEmpty } from '@ali/cn-design';
import Cookie from 'js-cookie';
import _ from 'lodash';
import yamljs from 'js-yaml';
import { timeFmt } from './time';
import Cookies from 'js-cookie';

export const validateContent = {
  /**
   * 检测json是否合法
   */
  validateJson(str) {
    try {
      return !!JSON.parse(str);
    } catch (e) {
      return false;
    }
  },

  /**
   * 检测xml和html是否合法
   */
  validateXml(str) {
    try {
      if (typeof DOMParser !== 'undefined') {
        const parserObj =
          new window.DOMParser()
            .parseFromString(str, 'application/xml')
            .getElementsByTagName('parsererror') || {};
        return parserObj.length === 0;
      } else if (typeof window.ActiveXObject !== 'undefined') {
        const xml = new window.ActiveXObject('Microsoft.XMLDOM');
        xml.async = 'false';
        xml.loadXML(str);
        return xml;
      }
    } catch (e) {
      return false;
    }
  },

  /**
   * 检测yaml是否合法
   */
  validateYaml(str) {
    try {
      return yamljs.safeLoad(str);
    } catch (e) {
      console.log('e: ', e);
      return false;
    }
  },

  /**
   * 检测属性是否正确
   */
  validateProperties(str = '') {
    const reg = /^#|([^=]+=.*)$/;
    return str
      .replace('\n\r', '\n')
      .split('\n')
      .every((_str) => reg.test(_str.trim()));
  },

  /**
   * 根据类型验证类型
   */
  validate({ content, type }) {
    const validateObj = {
      json: this.validateJson,
      xml: this.validateXml,
      'text/html': this.validateXml,
      html: this.validateXml,
      properties: this.validateProperties,
      yaml: this.validateYaml,
    };

    if (!validateObj[type]) {
      return true;
    }

    return validateObj[type](content);
  },
};
const getCurrentRegion = () => {
  const regionList = _.get(window, 'viewframeSetting.regionList', []);
  const defaultRegionId = _.get(window, 'viewframeSetting.defaultRegionId', '');
  const urlRegionId = window.self.location.href.match(
    new RegExp(`^.+${window.self.location.host}/([^/]+)/.*`)
  );
  const currentUrlRegionId = _.nth(urlRegionId, 1);
  if (_.find(regionList, (item) => item.regionId === currentUrlRegionId)) {
    return currentUrlRegionId;
  }
  return Cookie.get('currentRegionId') || defaultRegionId;
};

const getParams = (name) => {
  const reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`, 'i');
  let result = [];
  if (window.self.location.hash !== '') {
    result = window.self.location.hash.split('?'); // 优先判别hash
  } else {
    result = window.self.location.href.split('?');
  }
  try {
    if (result.length === 1) {
      result = window.parent.location.hash.split('?');
    }
  } catch (e) {
    console.log(e);
  }


  if (result.length > 1) {
    const r = result[1].match(reg);
    if (r != null) {
      return decodeURIComponent(r[2]);
    }
  }

  return null;
};

const setParams = (name, value) => {
  const _originHref = window.self.location.href.split('#')[0];
  if (!name) {
    return;
  }
  let obj = {};
  if (typeof name === 'string') {
    obj = {
      [name]: value,
    };
  }

  if (Object.prototype.toString.call(name) === '[object Object]') {
    obj = name;
  }

  let hashArr = [];
  if (window.self.location.hash) {
    hashArr = window.self.location.hash.split('?');
  }

  const paramArr = (hashArr[1] && hashArr[1].split('&')) || [];

  let paramObj = {};
  paramArr.forEach((val) => {
    const tmpArr = val.split('=');
    paramObj[tmpArr[0]] = decodeURIComponent(tmpArr[1] || '');
  });
  paramObj = Object.assign({}, paramObj, obj);

  const resArr =
    Object.keys(paramObj).map(
      (key) => `${key}=${encodeURIComponent(paramObj[key] || '')}`
    ) || [];

  hashArr[1] = resArr.join('&');
  const hashStr = hashArr.join('?');
  if (window.history.replaceState) {
    const url = _originHref + hashStr;
    window.history.replaceState(null, '', url);
  } else {
    window.self.location.hash = hashStr;
  }
};

// condition 回显，凸显的是：值
const mapConditions = (conditions = []) =>
  _.map(conditions, (child) => {
    switch (child.operator) {
      case 'list':
        return {
          uid: _.uniqueId(),
          ...child,
          cond: child.operator,
          value: child.nameList,
        };
      case 'mod':
        return {
          uid: _.uniqueId(),
          ...child,
          cond: `mod-${child.cond}`,
          value: child.remainder,
        };
      case 'rawvalue':
        return { uid: _.uniqueId(), ...child, value: child.datum };
      case 'deterministic_proportional_steaming_division':
        return {
          uid: _.uniqueId(),
          ...child,
          cond: '%',
          value: child.remainder,
        };
      case 'string': // istio 的条件类型
        return { uid: _.uniqueId(), ...child };
      case 'regexp': // 正则匹配
        return { uid: _.uniqueId(), ...child, value: child.datum };
      default:
        return { uid: _.uniqueId(), ...child };
    }
  });

// 提交数据处理 conditions
const mapConditionsFormData = (conditions = [], type = 'springCloud') =>
  _.map(conditions, (child) => {
    const val = {};
    if (child.cond === 'list') {
      val.cond = child.cond;
      val.operator = 'list';
    } else if (child.cond === '%') {
      val.cond = '%';
      val.operator = 'deterministic_proportional_steaming_division';
    } else if (child.cond === 'regexp') {
      val.cond = 'regexp';
      val.operator = 'regexp';
    } else if (child.cond && child.cond.indexOf('mod-') > -1) {
      val.cond = _.split(child.cond, '-')[1];
      val.operator = 'mod';
    } else if (
      child.cond === 'exact' ||
      child.cond === 'prefix' ||
      child.cond === 'regex'
    ) {
      // istio 的条件类型
      val.cond = child.cond;
      val.operator = 'string';
    } else {
      val.cond = child.cond;
      val.operator = 'rawvalue';
    }
    switch (type) {
      case 'springCloud':
        return {
          type: child.type,
          name: child.name,
          value:
            child.cond === 'list'
              ? _.join(_.map(child.value || [], (n) => _.trim(n)))
              : child.value,
          ...val,
        };
      case 'dubbo':
        return {
          index: child.index,
          expr: child.expr,
          type: child.type,
          name: child.name,
          value:
            child.cond === 'list'
              ? _.join(_.map(child.value || [], (n) => _.trim(n)))
              : child.value,
          ...val,
        };
      case 'istio':
        return {
          type: child.type,
          name: child.name,
          value:
            child.cond === 'list'
              ? _.join(_.map(child.value || [], (n) => _.trim(n)))
              : child.value,
          ...val,
        };
      default:
        return child;
    }
  });
const lang = () => {
  let language =
    Cookies.get('aliyun_lang') || Cookies.get('inner_oneconsole_lang') || 'zh';
  // 兼容取值 zh-TW 的case
  if (language.startsWith('zh')) {
    language = 'zh';
  }
  if (language.startsWith('en')) {
    language = 'en';
  }
  if (language.startsWith('ja')) {
    language = 'ja';
  }
  return language;
};
const aliyunSite = Cookie.get('aliyun_site') || 'CN';

export {
  isEmpty,
  isAllEmpty,
  isNoneEmpty,
  getCurrentRegion,
  timeFmt,
  getParams,
  setParams,
  mapConditions,
  mapConditionsFormData,
  lang,
  aliyunSite,
};
