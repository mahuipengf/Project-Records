import { getActiveNamespace, getParams } from '@ali/sre-utils';

export function getPostMessage(flag, data) {
  if (flag) {
    window.top.postMessage(
      { type: flag, data: { ns: getActiveNamespace(), ...data } },
      'https://advisor.console.aliyun.com',
    );
  }
}

export function getAppName() {
  const { pathname } = location;
  const appName = pathname.split('/');
  return appName[appName.length - 1];
}

/*
* 跳转到锚点位置
* @param {string} anchorName 类名
* block: 滚动到锚点的顶部或者底部: start/end
* behavior: 滚动效果: auto/smooth
*/
export function scrollToAnchor() {
  const anchorElement = document.getElementById('content-scroll-top');
  if (anchorElement) {
    anchorElement.scrollIntoView({ block: 'start', behavior: 'auto' });
  }
}

// 获取语言
export const getLocal = (function(window) {
  return function() {
    let local = window?.ALIYUN_CONSOLE_CONFIG?.LOCALE;
    if (local && typeof local === 'string') {
      local = local.toLocaleLowerCase();
    } else {
      local = 'zh-cn';
    }
    return local;
  };
})(window);

// 标识是否为虚商,默认不展示虚商 regionId 导航
export const getVirtualMerchant = (function(window) {
  return function() {
    const win = window;
    const { ALIYUN_CONSOLE_CONFIG = {} } = win;
    const { CHANNEL_FEATURE_STATUS = {} } = ALIYUN_CONSOLE_CONFIG;
    const { close_mk_and_toplogy = {} } = CHANNEL_FEATURE_STATUS;
    const { status = false } = close_mk_and_toplogy;
    return status;
  };
})(window);

// ahasAppName
export const getAppNameOnlyUseShow = () => {
  const ahasAppName = getParams('ahasAppName')
    ? getParams('ahasAppName')
    : getParams('appName');
  return ahasAppName;
};

/*
 * 版本号比较方法
 * @param {string} curV 当前版本号
 * @param {string} reqV 比较版本号
 */
export function compare(curV, reqV) {
  if (curV && reqV) {
    const arr1 = curV.split('.'),
      arr2 = reqV.split('.');
    const minLength = Math.min(arr1.length, arr2.length);
    let position = 0,
      diff = 0;
    while (position < minLength && ((diff = parseInt(arr1[position]) - parseInt(arr2[position])) === 0)) {
      position++;
    }
    diff = (diff !== 0) ? diff : (arr1.length - arr2.length);
    return diff >= 0;
  }
  return false;
}


// 渲染行为描述
export function contentTextOfBehaviorDesc(record) {
  let contentText;

  const { fallbackBehavior = {}, resourceClassification = 1 } = record;
  if (resourceClassification === 1) {
    const { webFallbackMode = 0, webRedirectUrl = '', webRespMessage = '', webRespStatusCode = 429, webRespContentType = 0 } = fallbackBehavior;
    if (webFallbackMode) {
      contentText = `跳转至链接：${webRedirectUrl}`;
    } else if (webRespContentType) {
      contentText = `ContentType = JSON字符串，HTTP status code = ${webRespStatusCode}，返回内容 = ${webRespMessage}`;
    } else {
      contentText = `ContentType = 普通文本，HTTP status code = ${webRespStatusCode}，返回内容 = ${webRespMessage}`;
    }
  } else {
    const { rpcFallbackMode = 0, rpcRespFallbackClassName = '', rpcFallbackExceptionMessage = '', rpcFallbackCacheMode = 0, rpcRespContentBody = '' } = fallbackBehavior;
    const rpcType = rpcFallbackMode ? '异常' : '返回值';
    const backUrl = rpcRespFallbackClassName;
    const entityClass = rpcFallbackMode ? rpcFallbackExceptionMessage : rpcRespContentBody;
    const status = rpcFallbackCacheMode ? '' : '不';
    const testType = rpcFallbackMode ? '异常信息文本' : '对象内容';

    contentText = `${status}缓存实例对象，${rpcType}类型 = ${backUrl}，${testType} = ${entityClass}`;
  }

  return contentText;
}
