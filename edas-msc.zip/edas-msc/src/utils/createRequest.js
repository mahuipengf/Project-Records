import { customRequest } from '@ali/cn-design';
import { WIDGET_CONSOLE_CONFIG, IS_PRE_OR_LOCAL } from 'constants';
import { get, first } from 'lodash';
import Cookie from 'js-cookie';

const consoleService = customRequest({
  request: (config) => {
    const { data, params, action } = config;
    const MseSessionId = localStorage && localStorage.getItem("MseSessionId");
    if (action !== 'QueryMetric') {
      params['X-EDAS-AT-ROUTER-KEY'] = IS_PRE_OR_LOCAL ? localStorage.getItem('edasEnvActiveKey') || '' : undefined;
    }
    if (MseSessionId) {
      params.MseSessionId = MseSessionId;
    }
    const defaultRegionId = get(window, 'viewframeSetting.defaultRegionId')
    return {
      ...config,
      data: {
        data,
        params,
        region: action === 'QueryMetric' ? 'cn-beijing' : Cookie.get('currentRegionId') || defaultRegionId || undefined,
      },
    };
  },
  response: (res) => {
    const resultSymbol = first(Object.getOwnPropertySymbols(res));
    const action = get(res[resultSymbol], 'config.action');
    // const data = get(res, 'Data');
    switch (action) {
      case 'ListApplication':
        return get(res, 'ApplicationList.Application', []);
      case 'Applcation':
        return get(res, 'Applcation', {});
      case 'QueryMetric':
        return get(JSON.parse(get(res, 'Data', '{}')), 'data', []);
      default:
        return get(res, 'Data');
    }
  },
});
const axiosService = customRequest();

export default ({ action, product = WIDGET_CONSOLE_CONFIG.productName, ...rest }) => {
  if (WIDGET_CONSOLE_CONFIG.isUsePopApi) {
    return consoleService({
      product,
      action,
      baseURL: window.location.origin,
      ...rest,
    });
  } else {
    return axiosService(rest);
  }
};
