
import { isPlainObject, lowerFirst, upperFirst, isArrayLikeObject } from 'lodash';

// 循环遍历，全部转小写
const lowerFirstData = object => {
  // eslint-disable-next-line guard-for-in
  for (const key in object) {
    const value = object[key];
    if (isPlainObject(value) || isArrayLikeObject(value)) {
      lowerFirstData(value);
    }
    delete object[key];
    object[lowerFirst(key)] = value;
  }
  return object;
};

// 循环遍历，全部转大写
const upperFirstData = object => {
  // eslint-disable-next-line guard-for-in
  for (const key in object) {
    const value = object[key];
    if (isPlainObject(value) || isArrayLikeObject(value)) {
      upperFirstData(value);
    }
    delete object[key];
    object[upperFirst(key)] = value;
  }
  return object;
};

// 只做第一层的大写转换
const upperFirstData1 = object => {
  // eslint-disable-next-line guard-for-in
  if (isArrayLikeObject(object)) {
    for (const key in object) {
      const value = object[key];
      if (isPlainObject(value) || isArrayLikeObject(value)) {
        upperFirstData1(value);
      }
    }
    return object;
  }
  for (const key in object) {
    const value = object[key];
    delete object[key];
    object[upperFirst(key)] = value;
  }
  return object;
};

const jsonStringify = (value) => {
  try {
    return JSON.stringify(value);
  } catch (err) {
    throw new Error('stringify error');
  }
};

const jsonParse = (value) => {
  try {
    return JSON.parse(value);
  } catch (err) {
    throw new Error('parse error');
  }
};

export {
  lowerFirstData,
  upperFirstData,
  upperFirstData1,
  jsonStringify,
  jsonParse,
};
