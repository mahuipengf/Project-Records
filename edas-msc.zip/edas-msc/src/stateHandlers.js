import { assign } from 'lodash';

export default {
  initialState: props => ({
    component: props.component || '',
    searchValues: props.searchValues || {},// 表格/编辑/详情页面的搜索默认值
    appList: [], // 应用列表(服务鉴权搜索以及创建时需要)
    editValues: props.editValues || {},
    serviceList: [], // 被调用方服务接口列表(服务鉴权创建时需要)
    springCloudServiceList: [], // 被调用方服务接口列表(服务鉴权创建时需要)
    regions: [],
    namespaces: [],
    isNeedOpenGraphical: true, // 创建离群实例策略第二步，首次创建需要默认打开生效原理示意图
    appServiceData: {
      dubbo: [],
      springCloud: [],
      istio: [],
    },
    k8sNamespaceData: [],
    mscAccount: {}, // 用户状态, status: 0 公测, 1 新用户，2 可用，3停用
  }),
  stateUpdaters: {
    // eslint-disable-next-line no-unused-vars
    setAppList: (state, props) => (payload) => {
      const nextState = {
        appList: payload,
      };
      return nextState;
    },
    setEditValues: (state, props) => (payload) => {
      const editValues = assign({}, state.editValues, payload)
      const nextState = {
        editValues,
      };
      return nextState;
    },
    setServiceList: (state, props) => (payload) => {
      const nextState = {
        serviceList: payload,
      };
      return nextState;
    },
    setSpringCloudServiceList: (state, props) => (payload) => {
      const nextState = {
        springCloudServiceList: payload,
      };
      return nextState;
    },
    setSearchValues: (state, props) => (payload) => {
      const nextState = {
        searchValues: payload,
      };
      return nextState;
    },
    setIsNeedOpenGraphical: () => (payload) => {
      const nextState = {
        isNeedOpenGraphical: payload,
      };
      return nextState;
    },
    setAppServiceData: () => (payload) => {
      const nextState = {
        appServiceData: payload,
      };
      return nextState;
    },
    setK8sNamespaceData: () => (payload) => {
      const nextState = {
        k8sNamespaceData: payload,
      };
      return nextState;
    },
    setMscAccount: () => (payload) => {
      const nextState = {
        mscAccount: payload,
      };
      return nextState;
    },
  },
};


// 更多细节请参考：https://github.com/acdlite/recompose/blob/master/docs/API.md#withstatehandlers
