// Widget 所使用的常量定义在这里
import { get, includes } from 'lodash';

export const WIDGET_ID = '@ali/widget-edas-msc';

export const MSC_WIDGET_CONSOLE_CONFIG = window.WIDGET_CONSOLE_CONFIG.edasmsc || {};

export const NNAME_PATTERN = /^[0-9a-zA-Z\-_]{1,64}$/;

export const IS_ENV_PRIVATE = get(window, 'EDAS_USER_FEATURES.envIsPrivateCloud', false); // 转有云

export const IS_SHOW_DUBBO_TIMEOUTCONFIG = get(window, 'EDAS_USER_FEATURES.featureDubboServiceTimeoutControlEnable', false);

export const EDAS_CHANNEL_INFO = get(window, 'EDAS_CHANNEL_INFO.channel', '');

// 沙特开服
export const IS_SAU_BUSINESS = includes(['vco_mpkintl_saudijv', 'vco_mpkintl_saudijv01', 'vco_mpkintl_saudijv02', 'vco_mpkintl_saudijv03', 'ali_testforJV'], window.ALIYUN_CONSOLE_CONFIG.CHANNEL);

// 预发、本地多环境
const fEnv = get(window, 'ALIYUN_CONSOLE_CONFIG.fEnv');
const host = get(window, 'location.host');
const str = /^([a-z\-\d+]+\.){1,}[a-z\-\d]+:\d{1,5}$/i;
export const IS_PRE_OR_LOCAL = fEnv === 'pre' || str.test(host);
