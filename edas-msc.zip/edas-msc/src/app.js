import React, { useEffect, useState } from 'react';
import { WIDGET_ID, MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE } from 'constants';
import { ModalProvider, Modal, Message } from '@ali/cn-design';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import AuthenticationList from 'pages/Authentication';
import AppList from 'pages/App';
import AppInfo from 'pages/App/AppInfo';
import AppGovernance from 'pages/App/AppGovernance';
import AppDetail from 'pages/App/AppDetail';
import Interface from 'pages/App/Interface';
import AppAccessType from 'pages/App/AccessType';
import LosslessList from 'pages/Lossless/LosslessList/Markdown';
import LosslessLineList from 'pages/Lossless/LosslessLineList';
import ServiceList from 'pages/ServiceManage/ServiceList';
import ServiceTestList from 'pages/ServiceTest';
import AppService from 'pages/ServiceManage/AppService';
import OutlierEjectionList from 'pages/OutlierEjection';
import OutlierEjectionNew from 'pages/OutlierEjection/OutlierEjectionNew';
import RouteCanaryList from 'pages/RouteManage/RouteCanaryList';
import RouteTagList from 'pages/RouteManage/RouteTagList';
import MockList from 'pages/Mock';
import MstMockList from 'pages/MstMock';
import EventCenterList from 'pages/EventCenter';
import FlowSetting from 'pages/FlowSetting';
import Home from 'pages/Home';
import { forEach, isEmpty } from 'lodash';
import NewRouteTagList from 'pages/RouteManage/NewRouteTagList';
import FaultInjectionList from 'pages/FaultInjection';
import ServiceRetryPolicyList from 'pages/ServiceRetryPolicy';
import ServiceTimeoutPolicyList from 'pages/ServiceTimeoutPolicy';
import LoadBalanceList from 'pages/LoadBalance';
import K8sClusterList from 'pages/K8sCluster/List';
import K8sClusterInfo from 'pages/K8sCluster/Info';
import MethodTestPage from 'pages/ServiceTest/MethodTestPage';
import FullLinkGrayscalekHome from 'pages/FullLinkGrayscale';
import SwimminLaneMonitorList from 'pages/FullLinkGrayscale/FullLinkGrayscaleHome/containers/SwimminLaneMonitorList';
import MethodTest from './pages/ServiceTest/components/MethodTest'
import services from 'services';
import { timeFmt } from './utils/time';

const Loading = () => {
  const [show, setShow] = useState(0);

  useEffect(() => {
    setTimeout(() => {
      setShow(true);
    }, 300);
  });
  return show ? 'Loading' : '';
};


export default () => {
  const [component] = useGlobalState('component');
  const [mscAccount, setMscAccount] = useGlobalState('mscAccount');
  const [searchValues] = useGlobalState('searchValues');
  const intl = useIntl();

  useEffect(() => {
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      const slidePanels = document.getElementsByClassName('slide-panels');
      forEach(slidePanels, item => {
        item.setAttribute('style', 'top: 50px');
      });
    }
  }, []);


  useEffect(() => {
    // edas 控制暂时不知道有没有这个产品授权
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      setMscAccount({
        Status: 2, // 0-公测，1-新用户，2-已开通，3-欠费停机
        Version: 1, // 0-基础班，1-专业版
      });
      return;
    }
    fetchState();
  }, []);

  const dateFmt = (s) => {
    if (!(s > 0)) return 0;
    return parseInt((s / 1000) / 3600 / 24, 10);
  };

  const fetchState = async () => {
    const data = await services.GetUserStatus({
      params: searchValues
    });
    if (data.Status === 0) { // 公测
      data.TimeLeft = dateFmt(new Date('2021-07-02 00:00:00') - new Date(timeFmt(Date.now(), 'YYYY-MM-DD 00:00:00')));
    }
    console.log('data', data);
    setMscAccount({ ...data, Status: 3 });
  };

  if (isEmpty(mscAccount)) {
    return <Loading />;
  }

  // // 公测用户，已过期 或 商业化不可用的用户只能看到这些 --- 这块逻辑已经放到 MSE 容器控制台
  // if (!((mscAccount.Status === 0 && mscAccount.TimeLeft > 0) || mscAccount.Status === 2)) {
  //   return (
  //     <div className="msc-widget">
  //       <Choose>
  //         <When condition={component === 'Home'}>
  //           <Home />
  //         </When>
  //         <When condition={component === 'AppList'}>
  //           <AppList tableUniqueKey={`${WIDGET_ID}-app-list`} />
  //         </When>
  //         <When condition={component === 'AppAccessType'}>
  //           <AppAccessType />
  //         </When>
  //         <Otherwise>
  //           <NewAccount mscAccount={mscAccount} setMscAccount={setMscAccount} Region={searchValues.regionId} />
  //         </Otherwise>
  //       </Choose>
  //     </div>
  //   );
  // }

  return (
    <div className="msc-widget">
      <ModalProvider>
        <Choose>
          <When condition={component === 'Home'}>
            <Home />
          </When>
          <When condition={component === 'AuthenticationList'}>
            <AuthenticationList tableUniqueKey={`${WIDGET_ID}-authentication-list`} />
          </When>
          <When condition={component === 'AppList'}>
            <AppList tableUniqueKey={`${WIDGET_ID}-app-list`} />
          </When>
          <When condition={component === 'AppInfo'}>
            <AppInfo />
          </When>
          <When condition={component === 'AppGovernance'}>
            <AppGovernance />
          </When>
          <When condition={component === 'AppDetail'}>
            <AppDetail />
          </When>
          <When condition={component === 'Interface'}>
            <Interface />
          </When>
          <When condition={component === 'AppAccessType'}>
            <AppAccessType />
          </When>
          <When condition={component === 'LosslessList'}>
            <LosslessList tableUniqueKey={`${WIDGET_ID}-lossless-list`} />
          </When>
          <When condition={component === 'LosslessLineList'}>
            <LosslessLineList tableUniqueKey={`${WIDGET_ID}-lossless-list`} />
          </When>
          <When condition={component === 'ServiceList'}>
            <ServiceList tableUniqueKey={`${WIDGET_ID}-service-list`} />
          </When>
          <When condition={component === 'AppService'}>
            <AppService />
          </When>
          <When condition={component === 'OutlierEjectionList'}>
            <OutlierEjectionList tableUniqueKey={`${WIDGET_ID}-outlier-ejection-list`} />
          </When>
          <When condition={component === 'OutlierEjectionNew'}>
            <OutlierEjectionNew />
          </When>
          <When condition={component === 'RouteCanaryList'}>
            <RouteCanaryList tableUniqueKey={`${WIDGET_ID}-route-canary-list`} />
          </When>
          <When condition={component === 'RouteTagList'}>
            <RouteTagList tableUniqueKey={`${WIDGET_ID}-route-tag-list`} />
          </When>
          <When condition={component === 'NewRouteTagList'}>
            <NewRouteTagList />
          </When>
          <When condition={component === 'ServiceTestList'}>
            <ServiceTestList tableUniqueKey={`${WIDGET_ID}-service-test-list`} />
          </When>
          <When condition={component === 'MockList' || component === 'DegradationList'}>
            <MockList />
          </When>
          <When condition={component === 'MstMockList'}>
            <MstMockList />
          </When>
          <When condition={component === 'EventCenterList'}>
            <EventCenterList tableUniqueKey={`${WIDGET_ID}-event-center-list`} />
          </When>
          <When condition={component === 'FlowSetting'}>
            <FlowSetting tableUniqueKey={`${WIDGET_ID}-FlowSetting`} />
          </When>
          <When condition={component === 'FaultInjectionList'}>
            <FaultInjectionList tableUniqueKey={`${WIDGET_ID}-fault-injection-list`} />
          </When>
          <When condition={component === 'ServiceRetryPolicyList'}>
            <ServiceRetryPolicyList tableUniqueKey={`${WIDGET_ID}-service-retry-policy-list`} />
          </When>
          <When condition={component === 'ServiceTimeoutPolicyList'}>
            <ServiceTimeoutPolicyList tableUniqueKey={`${WIDGET_ID}-service-timeout-policy-list`} />
          </When>
          <When condition={component === 'LoadBalanceList'}>
            <LoadBalanceList tableUniqueKey={`${WIDGET_ID}-load-balance-list`} />
          </When>
          <When condition={component === 'K8sClusterList'}>
            <K8sClusterList tableUniqueKey={`${WIDGET_ID}-k8s-cluster-list`} />
          </When>
          <When condition={component === 'K8sClusterInfo'}>
            <K8sClusterInfo />
          </When>
          <When condition={component === 'MethodTestPage'}>
            <MethodTestPage />
          </When>
          <When condition={component === 'MethodTest'}>
            <MethodTest />
          </When>
          <When condition={component === 'FullLinkGrayscalekHome'}>
            <FullLinkGrayscalekHome />
          </When>
          <When condition={component === 'SwimminLaneMonitorList'}>
            <SwimminLaneMonitorList />
          </When>
          <Otherwise>
            404
          </Otherwise>
        </Choose>
        <Modal />
      </ModalProvider>
    </div>
  );
};
