import React, { useEffect } from 'react';
import { Form, Switch, Icon, Field, Balloon, Select, Message } from '@ali/cn-design';
import DialogComponent from 'components/Dialog';
import { useIntl } from '@ali/widget-hooks';
import services from 'services';
import { get } from 'lodash';
import PropTypes from 'prop-types';


const DataGrayscale = (props) => {
  const intl = useIntl();
  const field = Field.useField();
  const { init, setValues, validate } = field;
  const { handleGrayscaleVisible, grayscaleVisible, Region, AppId, AppName } = props;
  const formItemLayout = {
    labelCol: { span: 10 },
    wrapperCol: { span: 12 },
  };

  useEffect(() => {
    grayscaleVisible && fetchData();
  }, [AppId, Region, grayscaleVisible]);
  const fetchData = async () => {
    const Data = await services.QueryDatabaseRoute({
      params: {
        Region,
        AppId,
      }
    });
    const Enable = get(Data, 'Enable', false);
    const Threshold = get(Data, 'Tables', []);
    setValues({ Enable, Threshold });
  };

  const triggerIcon = <Icon size="xs" type="help" className="lossless-app-list-icon" />;
  const WcontainerTitle = (
    <Balloon trigger={triggerIcon} align="t" closable={false}>
      表示针对哪些表进行灰度，如果不填则对全部数据库表进行灰度。
    </Balloon>
  );
  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      await services.UpdateDatabaseRoute({
        params: {
          AppId,
          RegionId: Region,
          Enable: values.Enable || false,
          Tables: values.Threshold || [],
        }
      }).then(() => {
        fetchData();
        handleGrayscaleVisible();
        Message.success(intl('widget.common.update_successful'));
      });
    });
  };
  return (
    <DialogComponent
      visible={grayscaleVisible}
      title="编辑数据库灰度"
      onOk={() => handleSubmit()}
      onCancel={() => handleGrayscaleVisible()}
      onClose={() => handleGrayscaleVisible()}
    >
      <Form {...formItemLayout} style={{ width: 400 }}>
        <Form.Item label="开启数据库灰度">
          <Switch
            {
              ...init('Enable', {
                initValue: false,
                valueName: 'checked',
              })
            }
            data-tracker="ahasnext-database-grayscale-open"
            style={{ marginTop: -4 }}
          />
        </Form.Item>
        <Form.Item
          label={
            <React.Fragment>
              <span style={{ lineHeight: '32px' }}>需要灰度的数据库表{WcontainerTitle}</span>
            </React.Fragment>
            }
        >
          <Select
            maxTagCount={10}
            mode="tag"
            style={{ width: 240 }}
            {...init('Threshold', {
              rules: [
                {
                  required: false,
                  message: '请选择灰度',
                },
              ],
            })}
            placeholder={'请选择灰度'}
            notFoundContent={intl('widget.route.condition.no_data_list_placeholder')}
          />
        </Form.Item>
      </Form>
    </DialogComponent>
  );
};
DataGrayscale.propTypes = {
  Region: PropTypes.string,
  AppId: PropTypes.string,
  AppName: PropTypes.string,
  grayscaleVisible: PropTypes.bool,
  handleGrayscaleVisible: PropTypes.func,
};
export default DataGrayscale;
