import React, { useState, useEffect } from 'react';
import services from 'services';
import PropTypes from 'prop-types';
import Wline from 'containers/Chart/Wline';
import { forIn, forEach, find, isEmpty, replace, keys, get } from 'lodash';
import { Loading, Icon } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import { lowerFirstData } from 'utils/transfer-data';
import DataGrayscale from '../DataGrayscale';
import Cookie from 'js-cookie';


const mapNumber = (value) => {
  if (typeof value === 'number') {
    if (value >= 1000) return `${Math.round(value / 100) / 10}k`;
    else return value;
  } else {
    return value;
  }
};

const mapPercent = (value, total) => {
  return `${Math.round(value / total * 1000) / 10}%`;
};

const Observability = (props) => {
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';
  const [loading, setLoading] = useState(false);
  const [currentData, setCurrentData] = useState([]);
  const intl = useIntl();
  const { AppId, Region, AppName, handlePageStatus, handleCurMetricsFm, searchValues = {}, currentTime, qpsRefreshIndex } = props;
  const [grayscaleVisible, setGrayscaleVisible] = useState(false);
  const [startTime, endTime] = currentTime;

  useEffect(() => {
    setLoading(true);
    fetchData();
    let interval;
    if (!interval) {
      interval = setInterval(() => {
        fetchData();
      }, 10000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [AppId, searchValues, currentTime, qpsRefreshIndex]);

  const fetchData = async () => {
    const Data = AppId && Region && await services.QueryAppSummaryMetricsOverview({
      params: {
        AppId,
        Region,
        StartTime: startTime || new Date().getTime() - (5 * 60 * 1000),
        EndTime: endTime || new Date().getTime(),
      }
    });

    const WlineData = [
      { name: intl('widget.home.total_count'), key: 'Qps', data: [] },
      { name: intl('widget.msc.throw_name', { name: 'QPS' }), key: 'ExpQps', data: [] },
    ];
    const CurMetrics = get(Data, 'CurMetrics', []);
    forEach(CurMetrics, d => {
      const Time = d.Timestamp;
      d.TagValues = lowerFirstData(d.TagValues);
      forIn(d.TagValues || {}, (tag, key) => {
        if (!find(WlineData, { key })) {
          WlineData.push({ name: key === 'null' ? intl('widget.app.canary_no_tag') : key, key, data: [] });
          WlineData.push({ name: intl('widget.msc.throw_name', { name: key }), key: `exp_${intl('widget.app.canary_no_tag')}`, data: [] });
        }
      });
      forEach(WlineData, item => {
        if (d[item.key] === 0 || d[item.key] || d[item.key] === null) {
          if (d[item.key] === -1) return item.data.push([Time, undefined]);
          else return item.data.push([Time, Number(d[item.key])]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[item.key])) {
          if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.TagValues[item.key].qps)]);
          else return item.data.push([Time, d.TagValues[item.key].qps]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[replace(item.key, 'exp_', '')])) {
          if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.TagValues[replace(item.key, 'exp_', '')].expQps)]);
          else return item.data.push([Time, d.TagValues[replace(item.key, 'exp_', '')].expQps]);
        }
      });
    });

    const CurMetricsFm = {
      ExpQps: get(Data, 'CurMetricsFm.ExpQps', 0),
      Qps: get(Data, 'CurMetricsFm.Qps', 0),
      TagValues: get(Data, 'CurMetricsFm.TagValues', {}),
    };
    handleCurMetricsFm(CurMetricsFm);
    setCurrentData({
      WlineData,
      CurMetricsFm,
    });
    setLoading(false);
  };
  return (
    <Loading visible={loading} style={{ width: '100%' }}>
      <div style={{ border: '1px solid #eee', boxShadow: '0 0 5px #eee', padding: '8px 16px 0px 16px', marginBottom: '16px', marginRight: '16px', display: 'flex' }}>
        <div style={{ flex: 1 }}>
          <If condition={searchValues && searchValues.appName}>
            <div style={{ display: 'flex' }}>
              <span style={{ lineHeight: '32px', fontWeight: 500 }}>{intl('widget.msc.qps_data')}</span>
              <span><span style={{ display: 'inline-block', border: '1px solid #f5f5f5', backgroundColor: '#f5f5f5', borderRadius: '16px', padding: '8px', marginLeft: '8px' }}>{searchValues && searchValues.appName}</span></span>
              <If condition={aliyunSite !== 'INTL'}>
                <div style={{ textAlign: 'right', flex: 1 }}>  {/* 数据库灰度 */}
                  <span>{intl('widget.msc.fulllink.grayscale.observability.data.base')}<span href="#" style={{ lineHeight: '32px', color: '#0070cc', cursor: 'pointer' }} onClick={() => setGrayscaleVisible(true)}>{intl('widget.msc.fulllink.grayscale.observability.config.msg')}</span></span>
                </div>
              </If>
            </div>
          </If>
          <div style={{ display: 'flex', }}>
            <div style={{ borderRight: '1px solid #eee', width: 160, minWidth: 160, marginRight: 16, marginBottom: 8, padding: '8px 16px 0 0' }}>
              <div style={{ color: '#777', marginBottom: 8 }}>{intl('widget.home.error_count_total_count')}</div>
              <span style={{ fontSize: 18, paddingRight: 2, color: get(currentData, 'CurMetricsFm.ExpQps', 0) === 0 ? '' : 'red' }}>{get(currentData, 'CurMetricsFm.ExpQps', 0) === -1 ? 0 : mapNumber(get(currentData, 'CurMetricsFm.ExpQps', 0))}</span>
              /
              <span style={{ paddingLeft: 2 }}>{mapNumber(get(currentData, 'CurMetricsFm.Qps', 0))}</span>
            </div>
            <div style={{ display: 'flex', padding: '8px 16px 0 0', overflowX: 'scroll', }}>
              <If condition={!isEmpty(get(currentData, 'CurMetricsFm.TagValues', {}))}>
                <For index="index" each="item" of={keys(get(currentData, 'CurMetricsFm.TagValues', {}))}>
                  <div key={index} style={{ display: 'inline-block', width: 100, minWidth: 100 }}>
                    <div style={{ color: '#777', marginBottom: 8 }}>{item === 'null' ? intl('widget.app.canary_no_tag') : item}</div>
                    <span style={{ fontSize: 18, paddingRight: 2, color: mapNumber(currentData.CurMetricsFm.TagValues[item].ExpQps) === 0 ? 'red' : 'red' }}>{mapNumber(currentData.CurMetricsFm.TagValues[item].ExpQps || 0)}</span>
                    /
                    <span style={{ paddingLeft: 2 }}>{mapNumber(currentData.CurMetricsFm.TagValues[item].Qps || 0)}</span>
                  </div>
                </For>
              </If>
              <If condition={isEmpty(get(currentData, 'CurMetricsFm.TagValues', {}))}>
                <div style={{ textAlign: 'center' }}>{intl('widget.common.no_data')}</div>
              </If>
            </div>
          </div>
        </div>
      </div>
      <div className="link-primary" style={{ display: 'flex', justifyContent: 'flex-end', padding: '8px 16px', zIndex: '99999' }} onClick={() => {
        handlePageStatus(false);
        window.CN_TRACKER.send({ 
          name: 'trafficEscapeObservation', 
          type:'mse-msc-grayscale'
        },{});
        }} >
        <span>{intl('widget.k8s_gray.arms_all_app')}</span>
        <Icon type="angle-right" />
      </div>
      <div style={{ width: '100%' }}>
        <Wline
          data={currentData.WlineData || []}
          height={200}
          title={intl('widget.msc.qps.monitor.chart')}
          style={{ width: '100%', marginTop: '-15px' }}
          option={{
            legend: {
              position: 'bottom',
              align: 'center',
            },
            padding: [12, 16, 48, 32],
            tooltip: {
              valueFormatter: (value, data, index, rawData) => {
                if (index === 0) return value || 0;
                const item = find(rawData, { name: intl('widget.home.total_count') });
                if (!item) {
                  return value || 0;
                }
                return `${value} (${mapPercent(value || 0, item.value || 0)})`;
              },
            }
          }}
        />
      </div>
      <DataGrayscale
        grayscaleVisible={grayscaleVisible}
        handleGrayscaleVisible={() => setGrayscaleVisible(false)}
        AppId={AppId}
        Region={Region}
        AppName={AppName}
      />
    </Loading>
  );
};
Observability.propTypes = {
  AppId: PropTypes.string,
  Region: PropTypes.string,
  handlePageStatus: PropTypes.func,
  AppName: PropTypes.string,
};

export default Observability;
