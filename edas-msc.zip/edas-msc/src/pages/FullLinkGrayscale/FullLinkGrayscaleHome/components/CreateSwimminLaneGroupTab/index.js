import React, { useState, useEffect } from 'react';
import { Tab, Button, Icon, Balloon, TimeContainer, Field } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import { forEach, map, isEmpty, last, head, find } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import PropTypes from 'prop-types';

const CreateSwimminLaneGroupTab = ({ dataSource = [], onChange, handleAdd, fetchQueryAllSwimmingLaneGroup, handleTabActiveKey, curTabKey, handleCreateSwimminLaneGroup, isCreateSwimminLaneTab, handleRefresh, getStartAndEndTime }) => {
  const [tabData, setTabData] = useState([]);
  const [activeKey, setActiveKey] = useState(0);
  const [isCloseable, setCloseable] = useState(false);
  const [searchValues] = useGlobalState('searchValues');
  const { regionId } = searchValues;
  const intl = useIntl();

  const field = Field.useField();
  const { init, getValue } = field;


  useEffect(() => {
    getTabData();
    curTabKey === 0 && !isEmpty(dataSource) && setActiveKey(head(dataSource).id);
    curTabKey !== 0 && setActiveKey(curTabKey);
    isCreateSwimminLaneTab && createSWimminLaneGroupTabStatus(true);
  }, [dataSource, curTabKey, isCreateSwimminLaneTab]);

  // useEffect(() => {
  //   const { value = [] } = getValue('time') || {};
  //   getStartAndEndTime(value);
  // }, [getValue('time')]);

  const createSWimminLaneGroupTabStatus = (params) => {
    if (params && !isEmpty(dataSource)) {
      handleTabActiveKey(last(dataSource).id);
      setActiveKey(last(dataSource).id);
    } else if (!isEmpty(dataSource)) {
      handleTabActiveKey(head(dataSource).id);
      setActiveKey(head(dataSource).id);
    }
  };
  const getTabData = () => {
    if (!isEmpty(dataSource)) {
      const tab = map(dataSource, items => ({ tab: items.name, key: items.id, closeable: true }));
      setTabData(tab);
    } else {
      setTabData([]);
    }
  };
  const handleChangeGroup = (val) => {
    setActiveKey(val);
    handleTabActiveKey && handleTabActiveKey(Number(val));
    onChange && onChange(Number(val));
    handleCreateSwimminLaneGroup && handleCreateSwimminLaneGroup(false);
  };
  const handleClose = (targetKey) => {
    const lang_group = find(dataSource || {}, { id: Number(targetKey) });
    handleCreateSwimminLaneGroup && handleCreateSwimminLaneGroup(false);
    DialogAlert({
      title: intl('widget.k8s_gray.swimming_lane_group_delete_tips'),
      content: intl('widget.k8s_gray.swimming_lane_delete_name', { name: lang_group.name || '' }),
      onOk: () => {
        deleteSwimmingLaneGroup(targetKey);
      }
    });
  };
  const deleteSwimmingLaneGroup = async (targetKey) => {
    await services.DeleteSwimmingLaneGroup({
      params: {
        GroupId: targetKey,
        Region: regionId,
      }
    }).then(async () => {
      setActiveKey(true);
      if (Number(targetKey) === Number(activeKey)) {
        await createSWimminLaneGroupTabStatus(false);
      } else {
        await setActiveKey(curTabKey);
      }
      await fetchQueryAllSwimmingLaneGroup && fetchQueryAllSwimmingLaneGroup();
    });
  };
  return (
    <div style={{ width: '100%' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }} >
        <div style={{ display: 'flex' }} data-wrapper='mse-msc-grayscale' >
          <Button type="primary" onClick={handleAdd} style={{ marginBottom: '16px' }} data-tracker ='createLaneGroup'><Icon type="add" />{intl('widget.k8s_gray.swimming_lane_group')}</Button>
          <If condition={!isCloseable} >
            <Balloon trigger={<Icon type="set" onClick={() => setCloseable(true)} style={{ width: '20px', height: '20px', display: 'flex', justifyContent: 'center', alignItems: 'center', border: '1px solid #C0C6CC', borderRadius: '50%', margin: '6px', color: '#202020', cursor: 'pointer' }} />} align="b" closable={false}>
              {intl('widget.k8s_gray.swimming_lane_group_edit')}
            </Balloon>
          </If>
          <If condition={isCloseable}>
            <Icon type="select" onClick={() => setCloseable(false)} style={{ width: '20px', height: '20px', display: 'flex', justifyContent: 'center', alignItems: 'center', border: '1px solid #C0C6CC', borderRadius: '50%', margin: '6px', color: '#202020', cursor: 'pointer' }} />
          </If>
        </div>
        {/* <div>
          <Icon type="refresh" size="small" style={{ marginRight: '8px', cursor: 'pointer' }} onClick={handleRefresh} />
          <TimeContainer
            {...init('time', {
              initValue: 'last_5_minutes',
            })}
            useLoop={false}
          />
        </div> */}
      </div>
      <If condition={!isEmpty(dataSource)} >
        <Tab shape="wrapped" onChange={handleChangeGroup} activeKey={activeKey} onClose={handleClose} defaultActiveKey={curTabKey !== 0 ? curTabKey || '' : activeKey || ''}>
          <For index="index" each="tab" of={tabData}>
            <Tab.Item title={tab.tab} key={tab.key} closeable={isCloseable ? tab.closeable : false} />
          </For>
        </Tab>
      </If>
      {/* <IconButton type="add"  style={{ marginLeft: 16 }}>{intl('widget.common.create')}</IconButton> */}
    </div>
  );
};

CreateSwimminLaneGroupTab.propTypes = {
  dataSource: PropTypes.array,
  onChange: PropTypes.func,
  handleAdd: PropTypes.func,
  fetchQueryAllSwimmingLaneGroup: PropTypes.func,
  handleTabActiveKey: PropTypes.func,
  curTabKey: PropTypes.number,
};
export default CreateSwimminLaneGroupTab;
