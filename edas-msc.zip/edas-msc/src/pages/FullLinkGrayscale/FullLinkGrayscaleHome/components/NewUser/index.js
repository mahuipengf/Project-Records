import React from 'react';
import Cookie from 'js-cookie';
import { Button } from '@alicloud/console-components';
import propTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import './index.less';

const NewUser = props => {
  const { handleShowGroupForm } = props;
  const intl = useIntl();
  const aliyunLang = Cookie.get('aliyun_lang') || 'zh';
  const img_cn = 'https://img.alicdn.com/imgextra/i4/O1CN01NpCsyK1tsM6EOYOwZ_!!6000000005957-55-tps-975-308.svg';
  const img_intl = 'https://img.alicdn.com/imgextra/i1/O1CN01mgzBRz1ykB79nQ4pq_!!6000000006616-55-tps-1019-321.svg';
  return (
    <React.Fragment>
      <div className="new-user-container">
        <div className="sub-title">{intl('widget.k8s_gray.customer_order_operation')}</div>
        <div className="tip">{intl('widget.k8s_gray.customer_order_tips1')}</div>
        <div className="tip">{intl('widget.k8s_gray.customer_order_tips2')}</div>
        <div className="create-btn"><Button type="primary" onClick={handleShowGroupForm}>{intl('widget.k8s_gray.create_lane_groups_lanes')}</Button></div>
        <div className="flow-line-chart">
          <div className="flow-control-link">{intl('widget.k8s_gray.flow_control_link_diagram')}</div>
          <div className="step-img">
            <img src={aliyunLang === 'en' ? img_intl : img_cn} />
          </div>
          <div>
            {/* <div className="flow-rule">{intl('widget.route.business_flow')}</div>
            <div className="lane">{intl('widget.k8s_gray.swimming_lane_entrance_A')}</div>
            <div className="lane">{intl('widget.k8s_gray.swimming_lane_entrance_B')}</div> */}
            <div style={{ display: 'flex', marginTop: '8px' }}>
              <div>
                <span className="circular circular-flow" />
                <span className="font-style">{intl('widget.common.other_flow')}</span>
              </div>
              <div>
                <span className="circular circular-a" />
                <span className="font-style">header = A</span>
              </div>
              <div>
                <span className="circular circular-b" />
                <span className="font-style">header = B</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

NewUser.propTypes = {
  handleShowGroupForm: propTypes.func,
};

export default NewUser;
