import React, { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { IconButton, Query } from '@ali/cn-design';
import { Loading, Search } from '@alicloud/console-components';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { filter, includes, find } from 'lodash';
import services from 'services';
import './index.less';

const GroupAppList = (props) => {
  const { handleEdit, applicationList = [], entryApplication } = props;
  const [searchValues] = useGlobalState('searchValues');
  const [appsList, setAppsList] = useState(applicationList);
  const [slbIprefreshIndex, setSlbIprefreshIndex] = useState(Date.now())
  const [eventEmitter] = useGlobalState('eventEmitter');
  const [csbAppList, setCsbAppList] = useState([]);
  const intl = useIntl();
  useEffect(() => {
    // ListCSBGateway();
    setAppsList(applicationList);
  }, []);
  const handleOnSearch = (key) => {
    if (key) {
      const _appsList = filter(applicationList, v => includes(v.AppName, key));
      setAppsList(_appsList);
    } else {
      setAppsList(applicationList);
    }

  }

  const ListCSBGateway = async () => {
    const data = await services.ListCSBGateway({
      params: {
        LogicalRegionId: searchValues.namespaceId,
      },
      // data: {
      //   LogicalRegionId: searchValues.namespaceId, // 报错 Specified content md5 is not matched with your request body.
      // }
    });
    const csbAppData = filter(data, item => item.ClusterType === 5);
    setCsbAppList(csbAppData);
  }

  const fetchSlbIp = async () => {
    if (entryApplication && entryApplication.AppId) {
      const { AppId, Source } = entryApplication;
      if (Source === 'EDAS') {
        const { ExtSlbIp } = await services.GetApplication({
          params: {
            AppId
          },
          data: {
            AppId
          }
        });
        return ExtSlbIp;
      }
    }
    return null
  };
  const viewAppDetail = (value) => {
    eventEmitter.emit('@ali/widget-edas-k8s-gray:view-app-detail', value);
  };
  const handleGoMicrogw = useCallback(() => {
    const csb = find(csbAppList, v => v.Name === entryApplication.AppName);
    if (csb) {
      const { GatewayType, Id, Name } = csb;
      window.open(`https://microgw.console.aliyun.com/gateway/gatewayDetail?gatewayId=${Id}&gatewayType=${GatewayType}&gatewayName=${Name}`, '_blank');
    }
  }, [csbAppList])
  return (
    <React.Fragment>
      <div className="GroupAppList-container">
        <div className="header">
          <div className="title">{intl('widget.k8s_gray.swim_lane_group_apps')}</div>
          <IconButton showIcon={false} onClick={handleEdit} >{intl('widget.common.edit')}</IconButton>
        </div>
        <div className="ip-box">
          {/* <Query fetchData={fetchSlbIp} refreshIndex={slbIprefreshIndex}>
            {({ data, loading }) => (
              <Loading visible={loading} inline={true}>
                <If condition={entryApplication && entryApplication.Source === 'EDAS'}>
                  <span className="ip-lable">EDAS{intl('widget.common.app')}/{intl('widget.common.gateway')} : {entryApplication.AppName || ''}<If condition={data}><a href={`http://${data}`} target='_blank'>({data})</a></If></span>
                </If>
                <If condition={entryApplication && entryApplication.Source === 'CSB'}>
                  <span className="ip-lable" onClick={handleGoMicrogw} style={{ cursor: 'pointer' }}>{intl('widget.common.microservice.gateway')} : {entryApplication.AppName || ''}</span>
                </If>
              </Loading>
            )}
          </Query> */}
          <If condition={entryApplication && entryApplication.Source === 'EDAS'}>
            <span className="ip-lable">
              EDAS{intl('widget.common.app')}/{intl('widget.common.gateway')} :
            </span>
            <If condition={entryApplication.AppName}>
              <span style={{ padding: '8px 16px', background: '#F5F5F5', borderRadius: '16px', marginLeft: 8 }}>{entryApplication.AppName}</span>
            </If>
          </If>
          <If condition={entryApplication && entryApplication.Source === 'CSB'}>
            <span className="ip-lable" onClick={handleGoMicrogw} style={{ cursor: 'pointer' }}>
              {intl('widget.common.microservice.gateway')}
            </span>
            <If condition={entryApplication.AppName}>
              <span style={{ padding: '8px 16px', background: '#F5F5F5', borderRadius: '16px', marginLeft: 8 }}>{entryApplication.AppName}</span>
            </If>
          </If>
        </div>
        <div className="search-box">
          <Search
            shape="simple"
            style={{ width: '100%' }}
            onSearch={handleOnSearch}
          />
        </div>
        <div className="list-box">
          <For each="item" index="index" of={appsList}>
            <div className="item" onClick={() => viewAppDetail(item)}>{item && item.AppName}</div>
          </For>
          <If condition={!appsList || appsList.length === 0}>
            <div className="empty-box">
              <span>{intl('widget.common.none_data')}</span>
            </div>
          </If>
        </div>
      </div>
    </React.Fragment>
  );
};

GroupAppList.propTypes = {
  handleEdit: PropTypes.func,
  applicationList: PropTypes.arrayOf(PropTypes.any),
  entryApplication: PropTypes.objectOf(PropTypes.any)
};

export default GroupAppList;
