import React, { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import './index.less';
import Wline from 'components/chart/Wline';
import services from 'services';
import { map, split, isEmpty, forEach } from 'lodash';
import { Loading, Icon } from '@alicloud/console-components';
import { Util } from '@alife/aisc-widgets';

let chart = [];
const GroupMonitoring = (props) => {
  const intl = useIntl();
  const [metricQuery] = useGlobalState('metricQuery');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const { NamespaceId, AppId, GroupId, swimmingLanes } = props;
  const [totalData, setTotalData] = useState([]);
  const [unmarkData, setUnmarkData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [swimmingLaneCharData, setSwimmingLaneCharData] = useState([]);
  const chart1 = useRef();
  const chart2 = useRef();
  console.log('swimmingLanes', swimmingLanes);
  useEffect(() => {
    if (!AppId || !NamespaceId || isEmpty(metricQuery)) return;
    const params = {
      AppId,
      regionId: split(NamespaceId, ':')[0],
      ...metricQuery,
    };
    fetchData(params);
    fetchListSwimmingLaneCharData(params)
  }, [NamespaceId, AppId, metricQuery, swimmingLanes]);

  const fetchListSwimmingLaneCharData = async (params) => {
    if (isEmpty(swimmingLanes)) {
      return;
    }
    const promiseList = [];
    const dataList = [];
    for (let i = 0; i < swimmingLanes.length; i++) {
      const p = new Promise(async (resolve, reject) => {
        const {AppId, regionId, StartTime, EndTime} = params;
        const dataSource = await fetchArmsData(regionId, AppId, swimmingLanes[i].Tag,StartTime, EndTime,'appstat.incall', 60000,reject);
        resolve(dataSource);
      });
      promiseList.push(p);
    }
    const list = await Promise.all(promiseList);
    forEach(list, (value, index) => {
      const name = `${swimmingLanes[index].Name}(${swimmingLanes[index].Tag})`;
      dataList.push({
        name,
        data: map(value, (item) => [item.date, item.count]),
      });
    });
    setSwimmingLaneCharData(dataList);
  };
const fetchArmsData = async (regionId, AppId, Tag, StartTime, EndTime, Metric = 'appstat.incall', IntervalInSec = 60000, reject) => {
    const data = await services.QueryMetric({
      params: {
        'Dimensions.1': 'scenario',
        'Filters.1.Key': 'pid',
        'Filters.1.Value': AppId,
        'Filters.2.Key': 'regionId',
        'Filters.2.Value': regionId,
        'Filters.3.Key': 'scenario',
        'Filters.3.Value': Tag, // 1cc88a15
        StartTime,
        EndTime,
        Metric,
        'Measures.1': 'count',
        'Measures.2': 'rt',
        'Measures.3': 'error',
        'CustomFilters.1': '(scenario:DEFAULT)',
        IntervalInSec,
      },
      customErrorHandle: (err, response, callback) => {
        if(err){
          reject(err);
        }
      }
    });
    return data
  };

  const fetchData = (params) => {
    setLoading(true);
    Promise.all([fetchArmsTotalData(params), fetchArmsUnmarkData(params)]).then((res) => {
      if (!isEmpty(res[0])) {
        setTotalData([
          {
            name: intl('widget.common.monitoring.qps_chart_all'),
            data: map(res[0], item => ([item.date, item.count]))
          }
        ]);
      } else {
        setTotalData([]);
      }
      if (!isEmpty(res[1])) {
        setUnmarkData([
          {
            name: intl('widget.common.monitoring.qps_chart_unmark'),
            data: map(res[1], item => ([item.date, item.count]))
          }
        ]);
      } else {
        setUnmarkData([]);
      }
      //new Util.Connect(chart); // 图表联动，需要在图表渲染之后才能配置
      setLoading(false);
    });
  };
  const fetchArmsTotalData = async ({ regionId, AppId, StartTime, EndTime, Metric = 'appstat.incall', IntervalInSec = 60000 }) => {
    const newParams = {
      'Filters.1.Key': 'pid',
      'Filters.1.Value': AppId, // '40f68a5d-4131-4fa1-8386-5817a01d2142',
      'Filters.2.Key': 'regionId',
      'Filters.2.Value': regionId, // 'cn-beijing',
      // 'Filters.1.Value': '40f68a5d-4131-4fa1-8386-5817a01d2142', // '40f68a5d-4131-4fa1-8386-5817a01d2142',
      // 'Filters.2.Key': 'regionId',
      // 'Filters.2.Value': 'cn-beijing', // 'cn-beijing',
      StartTime,
      EndTime,
      Metric,
      'Measures.1': 'count',
      'Measures.2': 'rt',
      'Measures.3': 'error',
      IntervalInSec,
    };
    const data = await services.QueryMetric({
      params: newParams,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      }
    });
    return data;
  };

  const fetchArmsUnmarkData = async ({ regionId, AppId, StartTime, EndTime, Metric = 'appstat.incall', IntervalInSec = 60000 }) => {
    const data = await services.QueryMetric({
      params: {
        'Dimensions.1': 'scenario',
        'Filters.1.Key': 'pid',
        'Filters.1.Value': AppId,
        'Filters.2.Key': 'regionId',
        'Filters.2.Value': regionId,
        // 'Filters.1.Value': '40f68a5d-4131-4fa1-8386-5817a01d2142',
        // 'Filters.2.Key': 'regionId',
        // 'Filters.2.Value': 'cn-beijing',
        'Filters.3.Key': 'scenario',
        'Filters.3.Value': 'noLabel',
        StartTime,
        EndTime,
        Metric,
        'Measures.1': 'count',
        'Measures.2': 'rt',
        'Measures.3': 'error',
        'CustomFilters.1': '(scenario:DEFAULT)',
        IntervalInSec,
      },
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      }
    });
    return data;
  };
  const viewAllAppDetail = () => {
    eventEmitter.emit('@ali/widget-edas-k8s-gray:view-arms-detail', GroupId);
  }
  return (
    <Loading visible={loading} style={{ flex: 1 }}>
      <div className="link-primary" style={{ float: 'right', padding: '8px 16px' }} onClick={viewAllAppDetail}>
        <span>{intl('widget.k8s_gray.arms_all_app')}</span>
        <Icon type="angle-right" />
      </div>
      <Wline
        data={[...totalData, ...unmarkData, ...swimmingLaneCharData]}
        title={intl('widget.k8s_gray.lane_group_monitoring_total')}
        height={330}
        style={{ boxShadow: '0 0 4px 0 rgba(0,0,0,0.12)' }}
        getChartInstance={c => (chart[0] = c)}
        options={{
          tooltip:{
            nameFormatter: function(v) {
              return v;
            },
            valueFormatter: function(v) {
              return v;
            },
          }
        }}
      />
      {/* <Wline
        getChartInstance={c => (chart[1] = c)}
        data={unmarkData}
        title={intl('widget.k8s_gray.swimlane_group_monitoring_unmarked')}
        height={140}
        style={{ boxShadow: '0 0 4px 0 rgba(0,0,0,0.12)', marginTop: 16 }}
        option={{
          areaColors: ['l(90) 0:#ff0000 1:#ff000000'], // 颜色渐变
          colors: ['#f00'],
        }}
      /> */}
    </Loading>
  );
};

GroupMonitoring.propTypes = {
  AppId: PropTypes.number,
  NamespaceId: PropTypes.string,
  GroupId: PropTypes.number
};

export default GroupMonitoring;
