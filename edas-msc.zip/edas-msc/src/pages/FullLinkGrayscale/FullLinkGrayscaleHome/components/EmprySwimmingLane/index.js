import React from 'react';
import { IconButton } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import { useIntl } from '@ali/widget-hooks';
import propTypes from 'prop-types';
import './index.less';

const EmptySwimminLane = (props) => {
  const { handleAdd } = props;
  const intl = useIntl();

  const handleConfim = () => {
    DialogAlert({
      title: intl('widget.common.warning'),
      content: intl('widget.k8s_gray.add_swimming_lane_label'),
      onOk: () => {
        handleAdd && handleAdd();
      },
      footerActions: ['ok', 'cancel']
    });
  };

  return (
    <React.Fragment>
      <div className="EmptySwimminLane-container">
        <div className="inner-box">
          <div className="tip">{intl('widget.k8s_gray.no_line_text')}</div>
          <IconButton showIcon={false} style={{ fontSize: 20 }} onClick={handleAdd}>{intl('widget.k8s_gray.click_create_first_split_lane')}</IconButton>
        </div>
      </div>
    </React.Fragment>
  );
};
EmptySwimminLane.propTypes = {
  handleAdd: propTypes.func,
};

export default EmptySwimminLane;
