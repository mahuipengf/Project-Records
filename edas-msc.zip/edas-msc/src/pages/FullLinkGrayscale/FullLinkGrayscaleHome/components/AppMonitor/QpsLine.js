import React, { useEffect, useState } from 'react';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { isEmpty, split, map } from 'lodash';
import './index.less';
import Wline from 'components/chart/Wline';
import services from 'services';
import { Loading } from '@alicloud/console-components';
import PropTypes from 'prop-types';

const QpsLine = (props) => {
  const { AppId, NamespaceId } = props;
  const intl = useIntl();
  const [loading, setLoading] = useState(false);
  const [metricQuery] = useGlobalState('metricQuery');
  const [totalData, setTotalData] = useState([]);

  useEffect(() => {
    if (!AppId || !NamespaceId || isEmpty(metricQuery)) return;
    const params = {
      AppId,
      regionId: split(NamespaceId, ':')[0],
      ...metricQuery,
    };
    fetchTotalData(params);
  }, [AppId, NamespaceId, metricQuery]);

  const fetchTotalData = async ({ regionId, AppId, StartTime, EndTime, Metric = 'appstat.incall', IntervalInSec = 60000 }) => {
    const newParams = {
      'Filters.1.Key': 'pid',
      'Filters.1.Value': AppId, // '40f68a5d-4131-4fa1-8386-5817a01d2142',
      'Filters.2.Key': 'regionId',
      'Filters.2.Value': regionId, // 'cn-beijing',
      // 'Filters.1.Value': '40f68a5d-4131-4fa1-8386-5817a01d2142', // '40f68a5d-4131-4fa1-8386-5817a01d2142',
      // 'Filters.2.Key': 'regionId',
      // 'Filters.2.Value': 'cn-beijing', // 'cn-beijing',
      StartTime,
      EndTime,
      Metric,
      'Measures.1': 'count',
      'Measures.2': 'rt',
      'Measures.3': 'error',
      IntervalInSec,
    };
    setLoading(true);
    const data = await services.QueryMetric({
      params: newParams,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      }
    });
    setLoading(false);
    if (!isEmpty(data)) {
      setTotalData([
        {
          name: intl('widget.common.monitoring.chart'),
          data: map(data, item => ([item.date, item.count]))
        }
      ]);
    } else {
      setTotalData([]);
    }
  };

  return (
    <Loading visible={loading} style={{ flex: 2, boxShadow: '0 0 4px 0 rgba(0,0,0,0.12)' }}>
      <Wline
        data={totalData}
        title={intl('widget.common.monitoring.qps_chart')}
        titleStyle={{ padding: '16px 0' }}
        height={400}
      />
    </Loading>
  );
};

QpsLine.propTypes = {
  NamespaceId: PropTypes.string,
  AppId: PropTypes.number,
};

export default QpsLine;
