import React, { useEffect, useState } from 'react';
import { Search } from '@alicloud/console-components';
import { useIntl } from '@ali/widget-hooks';
import { head, filter } from 'lodash';
import './index.less';
import QpsLine from './QpsLine';
import PropTypes from 'prop-types';

const AppMonitor = (props) => {
  const { appList, NamespaceId } = props;
  const [selectAppId, setSelectAppId] = useState(undefined);
  const intl = useIntl();
  const [dataSource, setDataSource] = useState([]);

  useEffect(() => {
    setDataSource(appList);
  }, [appList]);

  useEffect(() => {
    const firstApp = head(dataSource) || {};
    setSelectAppId(firstApp.AppId);
  }, [dataSource]);

  const onChange = (val) => {
    const newData = filter(appList, item => item.AppName && item.AppName.indexOf(val) > -1);
    setDataSource(val ? newData : appList);
  };
  return (
    <div style={{ display: 'flex', marginTop: 16 }} className="app-monitor">
      <div className="common-box" style={{ flex: 1, marginRight: 8, marginBottom: 0 }} >
        <h4 className="common-title" style={{ marginTop: 8 }}>{intl('widget.k8s_gray.swimming_lane_app')}</h4>
        <Search
          onChange={onChange}
          shape="simple"
          placeholder={intl('widget.k8s_gray.please_enter_swimming_lane_app')}
          style={{ width: '100%', marginBottom: 16 }}
        />
        <div style={{ height: 400, 'overflow-y': 'scroll', margin: '0 -16px', boxShadow: ' 0 0 5px #eee' }}>
          <For index="index" each="item" of={dataSource}>
            <div
              onClick={() => setSelectAppId(item.AppId)}
              key={index}
              className={item.AppId === selectAppId ? 'app-box app-box-active' : 'app-box'}
            >
              {item.AppName}
            </div>
          </For>
        </div>
      </div>
      <QpsLine AppId={selectAppId} NamespaceId={NamespaceId} />
    </div >
  );
};

AppMonitor.propTypes = {
  appList: PropTypes.arrayOf(PropTypes.any),
  NamespaceId: PropTypes.string,
};
export default AppMonitor;
