import React, { useState } from 'react';
import NewUser from './components/NewUser';
import services from 'services';
import { isEmpty, map } from 'lodash';
import { Query } from '@ali/cn-design';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import CreateSwimminLaneGroupForm from './containers/CreateSwimminLaneGroupForm';
import { Loading } from '@alicloud/console-components';
import LaneGroupDisplay from './containers/LaneGroupDisplay';
import SwimminLaneMonitorList from './containers/SwimminLaneMonitorList';

const FullLinkGrayscalekHome = () => {
  const [searchValues] = useGlobalState('searchValues');
  const [isShowGroupForm, setIsShowGroupForm] = useState(false);
  const [groupList, setGroupList] = useState([]);
  const [groupInfo, setGroupInfo] = useState({});
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [showSwimminLaneMonitor, setShowSwimminLaneMonitor] = useState(true);
  const [curTabKey, setCurTabKey] = useState(0);
  const [updateFlag, setUpDateFlag] = useState('create');
  const [isCreateSwimminLaneTab, setCreateSwimminLaneTab] = useState(false);
  const intl = useIntl();

  const fetchQueryAllSwimmingLaneGroup = async () => {
    const data = await services.QueryAllSwimmingLaneGroup({
      params: {},
    });
    const newData = map(data, item => ({ ...item, value: item.id, label: item.name }));
    setGroupList(newData);
    return newData;
  };

  const handleShowGroupForm = (bool, val = {}, flag = 'create') => {
    setIsShowGroupForm(bool);
    setGroupInfo({ ...val });
    setUpDateFlag(flag);
  };
  const handleOk = () => {
    setIsShowGroupForm(false);
    setRefreshIndex(Date.now());
  };
  const handlePageStatus = (flag) => setShowSwimminLaneMonitor(flag);
  const handleTabActiveKey = (key) => setCurTabKey(key);
  const handleCreateSwimminLaneGroup = (falg) => setCreateSwimminLaneTab(falg);
  return (
    <React.Fragment>
      <Query fetchData={fetchQueryAllSwimmingLaneGroup} refreshIndex={refreshIndex}>
        {({ data, loading }) => (
          <Loading visible={loading} inline={false}>
            <If condition={isEmpty(data)}>
              <NewUser handleShowGroupForm={() => handleShowGroupForm(true)} />
            </If>
            <If condition={!isEmpty(data)}>
              <If condition={showSwimminLaneMonitor}>
                <LaneGroupDisplay
                  handleShowGroupForm={handleShowGroupForm}
                  groupList={groupList}
                  fetchQueryAllSwimmingLaneGroup={() => setRefreshIndex(Date.now())}
                  handlePageStatus={handlePageStatus}
                  handleTabActiveKey={handleTabActiveKey}
                  curTabKey={curTabKey}
                  handleCreateSwimminLaneGroup={handleCreateSwimminLaneGroup}
                  isCreateSwimminLaneTab={isCreateSwimminLaneTab}
                />
              </If>
              <If condition={!showSwimminLaneMonitor}>
                <SwimminLaneMonitorList handlePageStatus={handlePageStatus} groupId={curTabKey === 0 ? groupList[0].id : curTabKey} intl={intl} groupList={groupList} />
              </If>
            </If>
          </Loading>
        )}
      </Query>
      <CreateSwimminLaneGroupForm
        visible={isShowGroupForm}
        value={groupInfo}
        onClose={() => setIsShowGroupForm(false)}
        onOk={handleOk}
        updateFlag={updateFlag}
        handleCreateSwimminLaneGroup={handleCreateSwimminLaneGroup}
      />
    </React.Fragment>
  );
};

export default FullLinkGrayscalekHome;
