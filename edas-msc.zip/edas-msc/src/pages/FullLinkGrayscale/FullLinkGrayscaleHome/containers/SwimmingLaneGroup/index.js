import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import GroupSelector from 'components/GroupSelector';
import GroupAppList from '../../components/GroupAppList';
import GroupMonitoring from '../../components/GroupMonitoring';
import { find, isEmpty, map, uniqueId, get, head } from 'lodash';
import services from 'services';
import { Query } from '@ali/cn-design';
import { Loading } from '@alicloud/console-components';
import EmptySwimminLane from '../../components/EmprySwimmingLane';
import CreateSwimminLaneForm from '../CreateSwimminLaneForm';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import SwimminLaneTable from '../SwimminLaneTable';
import SwimmingLaneInfo from '../SwimminLaneInfo';
import { jsonParse } from 'utils/transfer-data';
import ArmsTimer from 'components/ArmsTimer';

const SwimminLaneGroup = (props) => {
  const [searchValues] = useGlobalState('searchValues');
  const { groupList, handleShowGroupForm } = props;
  const [groupInfo, setGroupInfo] = useState({});
  const [laneInfo, setLaneInfo] = useState({});
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [isShowForm, setIsShowForm] = useState(false);
  const [isShowInfo, setIsShowInfo] = useState(false);
  const [swimmingLanes, setSwimmingLanes] = useState([]);
  const intl = useIntl();

  useEffect(() => {
    const data = find(groupList, { value: groupInfo.Id }) || groupList[0];
    setGroupInfo(data);
    setRefreshIndex(Date.now());
  }, [groupList]);

  const handleChangeGroup = (id) => {
    const data = find(groupList, { value: id }) || {};
    setGroupInfo(data);
    setRefreshIndex(Date.now());
  };

  const fetchListSwimmingLane = async () => {
    if (!groupInfo.Id) return;
    const data = await services.ListSwimmingLane({
      params: { GroupId: groupInfo.Id }
    });
    setSwimmingLanes(data);
    const newData = getDatasource(data);
    const item = find(newData, { Id: laneInfo.Id }) || {};
    setLaneInfo(item);
    return newData;
  };

  const handleShowForm = (bool, val = {}) => {
    setLaneInfo({ ...val });
    setIsShowForm(bool);
  };

  const handleShowInfo = (bool, val = {}) => {
    setLaneInfo({ ...val });
    setIsShowInfo(bool);
  };

  const handleOk = () => {
    setIsShowForm(false);
    setRefreshIndex(Date.now());
  };

  const getDatasource = (data) => map(data, item => {
    const EntryRule = get(item, 'EntryRule', '[]') || '[]';
    const condition = head(jsonParse(EntryRule)) || {};
    const newValue = {
      ...item,
      priority: condition.priority,
      path: condition.path,
      condition: condition.condition,
      conditions: map(condition.restItems, child => {
        if (child.operator === 'list') {
          return { uid: uniqueId(), ...child, cond: child.operator, value: child.nameList };
        }
        if (child.operator === 'mod') {
          return { uid: uniqueId(), ...child, cond: `mod-${child.cond}`, value: child.remainder };
        }
        if (child.operator === 'rawvalue') {
          return { uid: uniqueId(), ...child, value: child.datum };
        }
        if (child.operator === 'deterministic_proportional_steaming_division') {
          return { uid: uniqueId(), ...child, cond: '%', value: child.remainder }
        }
        return { uid: uniqueId(), ...child };
      }),
      EnableRules: !!item.EnableRules,
      AppIds: map(item.SwimmingLaneAppRelationShipList || [], child => ({ ...child, value: child.AppId, label: child.AppName, uid: uniqueId() }))
    };
    return newValue;
  });

  return (
    <React.Fragment>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 16, boxShadow: '0 0 4px 0 #ddd', marginBottom: 16 }}>
        <GroupSelector handleAdd={() => handleShowGroupForm()} dataSource={groupList} onChange={handleChangeGroup} />
        <ArmsTimer />
      </div>
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 1, marginRight: 16 }}>
          <GroupAppList handleEdit={() => handleShowGroupForm(groupInfo)} key={JSON.stringify(groupInfo)} applicationList={groupInfo.ApplicationList} entryApplication={groupInfo.EntryApplication} />
        </div>
        <GroupMonitoring
          NamespaceId={get(groupInfo, 'NamespaceId')}
          AppId={get(groupInfo, 'EntryApplication.AppId')}
          GroupId={get(groupInfo, 'Id')}
          swimmingLanes={swimmingLanes}
        />
      </div>
      <Query autoFetch={false} refreshIndex={refreshIndex} fetchData={fetchListSwimmingLane}>
        {({ data = [], loading }) => {
          return (
            <Loading visible={loading} inline={false}>
              <If condition={isEmpty(data)}>
                <EmptySwimminLane handleAdd={() => handleShowForm(true, {})} />
              </If>
              <If condition={!isEmpty(data)}>
                <SwimminLaneTable
                  AppId={get(groupInfo, 'EntryApplication.AppId')}
                  GroupId={get(groupInfo, 'Id')}
                  dataSource={data}
                  dataSourceChange={setRefreshIndex}
                  handleEdit={(val) => handleShowForm(true, val)}
                  handleAdd={() => handleShowForm(true, {})}
                  handleOpenInfo={(val) => handleShowInfo(true, val)}
                />
              </If>
            </Loading>
          );
        }}
      </Query>
      <CreateSwimminLaneForm
        groupInfo={groupInfo}
        visible={isShowForm}
        onClose={() => setIsShowForm(false)}
        onOk={handleOk}
        value={laneInfo}
      />
      <SwimmingLaneInfo
        visible={isShowInfo}
        handleEdit={(val) => handleShowForm(true, val)}
        onClose={() => setIsShowInfo(false)}
        value={laneInfo}
      />
    </React.Fragment>
  );
};

SwimminLaneGroup.propTypes = {
  handleShowGroupForm: PropTypes.func,
  groupList: PropTypes.arrayOf(PropTypes.any),
};

export default SwimminLaneGroup;
