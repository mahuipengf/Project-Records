import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { TableContainer, Balloon, Loading, Empty } from '@ali/cn-design';
import { Button, Icon } from '@alicloud/console-components';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { map, isEmpty, head, get, forEach, find } from 'lodash';
import services from 'services';
import './index.less';
import Status from 'components/Status/CommonStatus';
import Event from './Event';
import { Dubbo, SpringCloud, Istio } from 'components/Icon';

const SwimminLaneTable = (props) => {
  const intl = useIntl();
  const { dataSource = [], handleEdit, dataSourceChange, handleAdd, curMetricsFm, EntryApp = 'ingress', curTabKey = 0 } = props;
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [isShow, setShow] = useState(false);
  const [refresh, setRefresh] = useState(0);
  const [dataList, setDataList] = useState([]);
  const [rowData, setRowData] = useState({});
  const [EntryAppParams, EntryAppId] = EntryApp.split(':');
  const [entryType, setEntryType] = useState('ingress');
  const [routeRuleDataSource, setRouteRuleDataSource] = useState([]);
  const [searchValues] = useGlobalState('searchValues');

  useEffect(() => {
    EntryAppParams === 'mse-gw' && getDataSource();
    // 泳道兼容
    if (EntryAppParams === 'mse') {
      setEntryType('Java');
    } else if (EntryAppParams === 'aliyun-ingress') {
      setEntryType('AliCloudIngress');
    } else if (EntryAppParams === 'ingress') {
      setEntryType('ingress');
    } else if (EntryAppParams === 'mse-gw') {
      setEntryType('CloudPrimordium');
    }
  }, [EntryApp]);

  useEffect(() => {
    setDataList([]);
    setRefreshIndex(Date.now());
    if (isShow) {
      fetchData();
    }
    // !isEmpty(dataSource) && fetchData();
  }, [dataSource, refresh, curTabKey]);
  // useEffect(() => {
  //   setDataList([]);
  //   setRefreshIndex(Date.now());
  //   // !isEmpty(dataSource) && fetchData();
  // }, [dataSource]);
  const ICON = {
    'spring-cloud-a-1230': <Dubbo />,
    'spring-cloud-c': <SpringCloud />,
  };
  const listAppBySwimmingLaneGroupTag = async(Tag, GroupId) => {
    const res = await services.ListAppBySwimmingLaneGroupTag({
      params: {
        Tag,
        GroupId,
      }
    });
    return res || [];
  };
  const fetchData = () => {
    deleteBugFixed();
    return {
      Data: dataSource || [],
      TotalCount: dataSource.length || 0,
    };
  };
  const deleteBugFixed = async() => {
    for (let i = 0; i < dataSource.length; i++) {
      dataSource[i].appList = await listAppBySwimmingLaneGroupTag(dataSource[i].tag, dataSource[i].groupId);
      const data = await services.QuerySwimmingLaneById({
        params: { LaneId: dataSource[i].id }
      });
      dataSource[i] = { ...dataSource[i], ...data }; // 赋值网关路由数据
    }
    const newData = await dataSource;
    await setDataList(newData);
    await setRowData(head(newData));
  };
  const refreshRenderPage = () => setRefreshIndex(Date.now());
  const flowPercentage = isEmpty(get(curMetricsFm, 'TagValues', {})) ? { null: '' } : get(curMetricsFm, 'TagValues', { null: '' });
  const handleRefsh = () => setRefresh(Date.now());
  const columns = [
    {
      title: intl('widget.k8s_gray.swimming_lane_name1'),
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: intl('widget.k8s_gray.swimming_lane_corresponding_tag'),
      dataIndex: 'tag',
      key: 'tag',
      cell: (val) => <div><span style={{ border: '1px solid #C0C6CC', borderRadius: '12px', width: 'auto', padding: '0px 8px 3px 8px' }}>{val}</span></div>
    },
    {
      title: intl('widget.k8s_gray.swimming_lane_corresponding_applist'),
      dataIndex: 'appList',
      key: 'appList',
      cell: (val, index, record) => {
        const list = map(record.appList || [], item => item.appName);
        return <Balloon trigger={<div style={{ width: 200, textOverflow: 'ellipsis', whiteSpace: 'nowrap', overflow: 'hidden', cursor: 'pointer' }}>{list.join()}</div>} align="t" closable={false}>{list.join()}</Balloon>;
      }
    },
    {
      title: intl('widget.common.state'),
      dataIndex: 'enable',
      key: 'enable',
      cell: (val) => <Status value={val} intl={intl} />
    },
    {
      title: intl('widget.common.operating'),
      dataIndex: 'operate',
      key: 'operate',
      cell: (val, index, record) => <Event record={record} refreshRenderPage={refreshRenderPage} dataSourceChange={dataSourceChange} handleAdd={handleAdd} handleRefsh={handleRefsh} EntryAppId={EntryAppId} entryType={entryType} />
    }
  ];
  const Java_event = {
    title: intl('widget.k8s_gray.mark_traffic_by_rules'),
    dataIndex: 'entryRule',
    key: 'entryRule',
    cell: (_val, index, record) => {
      const val = head(JSON.parse(_val)) || {};
      const Exhibition = val.restItems && val.restItems.length > 0 && `${val.restItems[0].type}[${val.restItems[0].name}]${val.restItems[0].cond}${val.restItems[0].value}`;
      const other = val.restItems && val.restItems.length > 1 && `${val.restItems[1].type}[${val.restItems[1].name}]${val.restItems[1].cond}${val.restItems[1].value}`;
      return (<Balloon
        trigger={(<div style={{ width: 200, cursor: 'pointer' }}>
          <div>{intl('widget.service.condition')}：{val.condition || 'AND'}</div>
          <div>{Exhibition} {other} <If condition={val.restItems && val.restItems.length > 2}>...</If></div>
        </div>)}
        align="t"
        closable={false}
      >
        <div style={{ width: 'auto' }}>
          <div>{intl('widget.service.condition')}：{val.condition || 'AND'}</div>
          <For each="items" index="index" of={val.restItems || []}>
            <div>
              {`${items.type}[${items.name}]${items.cond}${items.value}`}
            </div>
          </For>
        </div>
      </Balloon>
      );
    }
  };
  const CloudPrimordium_event = {
    title: '路由规则',
    dataIndex: 'gatewaySwimmingLaneRouteJson',
    key: 'gatewaySwimmingLaneRouteJson',
    cell: (_val, index, record) => {
      const { gatewaySwimmingLaneRouteJson } = record;
      const gatewaySwimmingLaneRoute = gatewaySwimmingLaneRouteJson ? JSON.parse(gatewaySwimmingLaneRouteJson) : {};
      const { routeIdList = [] } = gatewaySwimmingLaneRoute;
      const routeRuleNames = [];
      forEach(routeIdList, item => {
        const filterData = find(routeRuleDataSource, { Id: item }) || {};
        const name = filterData.Name || '';
        routeRuleNames.push(name);
      });
      return (<Balloon
        trigger={(<div style={{ width: 200, cursor: 'pointer' }}>
          {routeRuleNames.join(',')}
        </div>)}
        align="t"
        closable={false}
      >
        <div style={{ width: 'auto' }}>
          {routeRuleNames.join(',')}
        </div>
      </Balloon>
      );
    }
  };

  if (entryType === 'Java' || entryType === 'AliCloudIngress') columns.splice(3, 0, Java_event);
  if (entryType === 'CloudPrimordium') columns.splice(3, 0, CloudPrimordium_event);
  const getDataSource = async () => {
    const data = await services.ListSwimmingLaneGatewayRoute({ // ListSwimmingLaneGatewayRoute ListGatewayRoute
      params: {
        PageSize: 200,
        PageNumber: 1,
        RegionId: searchValues.regionId,
        Region: searchValues.regionId,
        GatewayUniqueId: EntryAppId,
      }
    });
    const result = data || [];
    const newReuslt = result.map((item => ({ ...item, label: item.Name, value: item.Id })));
    setRouteRuleDataSource(newReuslt);
  };
  return (
    <React.Fragment>
      <If condition={!isEmpty(dataSource)}>
        <div className="swimminLaneTable">
          <div className="fontsize">{intl('widget.route.flow_distribution')}</div>
          <div style={{ flex: 1, justifyContent: 'flex-end' }}>
            <div style={{ position: 'relative', bottom: '-35px', zIndex: '9' }}>
              <div className="swimiminLane-icon">
                <span className={`${isShow ? 'swimiminLane-icon-style-bg' : 'swimiminLane-icon-style'}`} onClick={() => setShow(true)}><img src="https://img.alicdn.com/imgextra/i3/O1CN01wdMfPK1ulJcy6wUiO_!!6000000006077-55-tps-24-26.svg" style={{ width: '14px', height: '14px', filter: `${isShow ? 'drop-shadow(#0064C8 80px 0px)' : 'none'}`, transform: `${isShow ? 'translateX(-80px)' : 'none'}` }} /></span>
                <span className={`${isShow ? 'swimiminLane-icon-style' : 'swimiminLane-icon-style-bg'}`} onClick={() => setShow(false)}><Icon type="menu" /></span>
                <span className={'swimiminLane-icon-style-refresh'} onClick={() => setRefresh(Date.now())}><Icon type="refresh" /></span>
              </div>
            </div>
          </div>
        </div>
        <If condition={isShow}>
          <Button type="primary" style={{ marginBottom: '20px' }} onClick={() => handleEdit()}>{intl('widget.k8s_gray.create_swimming_lane_group')}</Button>
          <div style={{ paddingBottom: '46px', position: 'relative' }}>
            <Loading visible={isEmpty(dataList)} inline={false} >
              <For index="index" each="item" of={dataList}>
                <div style={{ display: 'flex', position: 'relative', paddingBottom: '16px' }}>
                  <Balloon trigger={<div style={{ width: '80px', marginRight: '20px' }} className={`swimiminLane-tag ${item.enable ? '' : 'font-gray'}`}>{item.name}</div>} align="b" closable={false}>
                    {item.name}
                  </Balloon>
                  {/* <For index="index" each="_t" of={flowPercentage}> */}
                  {/* <If condition={!isEmpty(_map[item])}>
                    <div className={`swimmin-lane-tag-percentage ${item.enable ? '' : 'font-gray'}`}>{`${(curMetricsFm.TagValues[item].qps / curMetricsFm.Qps * 100).toFixed()}%`}</div>
                  </If>
                  <If condition={isEmpty(_map[item])}>
                    <div className={`swimmin-lane-tag-percentage ${item.enable ? '' : 'font-gray'}`}>0%</div>
                  </If> */}
                  {
                    !isEmpty(flowPercentage[item.tag]) ? (
                      <div className={`swimmin-lane-tag-percentage ${item.enable ? '' : 'font-gray'}`}>{`${(curMetricsFm.TagValues[item.tag].Qps / curMetricsFm.Qps * 100).toFixed()}%`}</div>
                    ) : (
                      <div className={`swimmin-lane-tag-percentage ${item.enable ? '' : 'font-gray'}`}>0%</div>
                    )
                  }
                  {/* </For> */}
                  <div style={{ flex: 1 }}>
                    <div style={{ position: 'absolute', width: 'calc(100% - 126px)', zIndex: 1, top: '12px', borderTop: '1px solid #cfd5d8' }} />
                    <div style={{ marginLeft: '25px', position: 'relative', top: '3px', zIndex: 9 }}>
                      <For index="index" each="items" of={item.appList || []}>
                        <span className="icon-img-box">
                          {ICON['spring-cloud-c']}
                          <span className="icon-font" style={{ color: `${item.enable ? '#333' : '#ccc'}` }}>{items.appName}</span>
                        </span>
                      </For>
                    </div>
                    <div className={`swimmin-lane-tag ${item.enable ? '' : 'font-gray'}`} style={{ marginRight: '20px' }}>{item.tag}</div>
                  </div>
                </div>
              </For>
            </Loading>
          </div>
        </If>
        <If condition={!isShow} >
          <TableContainer
            fetchData={fetchData}
            refreshIndex={refreshIndex}
            // search={searchs}
            primaryKey="Id"
            columns={columns}
            // hideOnlyOnePage
            pagination={<div />}
            rowProps={(record) => ({
              className: `${
                `${record.name}:${record.userId}:${record.tag}` ===
                `${rowData.name}:${rowData.userId}:${rowData.tag}`
                  ? 'table-active'
                  : ''
              } ${record.Uid}`,
              style: {
                position: 'relative',
              },
            })}
            onRowClick={(record) => { setRowData(record); }}
            operation={() => <Button type="primary" onClick={() => {
              handleEdit();
              window.CN_TRACKER.send({ 
                name: 'grayscale-createSwimLanes', 
                type:'mse-msc-grayscale'
              },{});
            }}>
              {intl('widget.k8s_gray.create_swimming_lane_group')}
              </Button>}
          />
        </If>
      </If>
    </React.Fragment>
  );
};

SwimminLaneTable.propTypes = {
  handleEdit: PropTypes.func,
  dataSource: PropTypes.arrayOf(PropTypes.any),
  handleAdd: PropTypes.func,
  dataSourceChange: PropTypes.func,
  EntryApp: PropTypes.string,
  curTabKey: PropTypes.number,
};

export default SwimminLaneTable;
