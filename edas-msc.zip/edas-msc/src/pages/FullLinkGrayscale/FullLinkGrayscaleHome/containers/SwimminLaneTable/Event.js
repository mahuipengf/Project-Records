import React, { useState, useEffect } from 'react';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import DialogAlert from 'components/DialogAlert';
import { get } from 'lodash';
import { upperFirstData } from 'utils/transfer-data';
import PropTypes from 'prop-types';
import services from 'services';
import './index.less';

const Event = ({ record, refreshRenderPage, dataSourceChange, handleAdd, EntryAppId, entryType }) => {
  const { enable: Enable, groupId: GroupId, id: Id, name: Name, source: Source, status: Status, tag: Tag, userId: UserId, handleRefsh, gatewaySwimmingLaneRouteJson } = record;
  const intl = useIntl();
  const { searchValues } = useGlobalState();
  const { regionId: RegionId } = searchValues;
  const EntryRules = upperFirstData(JSON.parse(get(record, 'entryRule', [{}])));
  const gatewaySwimmingLaneRoute = gatewaySwimmingLaneRouteJson ? JSON.parse(gatewaySwimmingLaneRouteJson) : {};
  const { conditions = [], routeIdList } = gatewaySwimmingLaneRoute;
  useEffect(() => {}, [record]);
  const updateOrUpdateSwimmingLane = async () => {
    const GatewaySwimmingLaneRouteJson = {
      GatewayUniqueId: EntryAppId || '',
      RouteIdList: routeIdList || [],
      Conditions: upperFirstData(conditions),
    };
    await services.CreateOrUpdateSwimmingLane({
      params: {
        Id: record.id,
        Name: record.name,
        Tag: record.tag,
        Enable: !record.enable,
        Status: record.status || 1,
        GroupId: record.groupId,
        RegionId,
        EntryRules,
        EntryRule: EntryRules,
        GatewaySwimmingLaneRouteJson: entryType === 'CloudPrimordium' ? GatewaySwimmingLaneRouteJson : {}
      }
    }).then((res) => {
      dataSourceChange && dataSourceChange();
      refreshRenderPage && refreshRenderPage();
    });
  };

  const deleteRepeatAlert = () => {
    const dialogDle = DialogAlert({
      title: intl('widget.k8s_gray.swimming_lane_group_delete_tips'),
      content: intl('widget.k8s_gray.swimming_lane_delete', { name: Name || '' }),
      onOk: async() => {
        await services.DeleteSwimmingLane({
          params: {
            LaneId: Id
          }
        }).then(async() => {
          await dataSourceChange && dataSourceChange();
          // fetchQueryAllSwimmingLaneGroup && fetchQueryAllSwimmingLaneGroup();
          await handleRefsh && handleRefsh();
          // await refreshRenderPage && refreshRenderPage();
        });
      },
      onCancel: () => dialogDle.hide(),
    });
  };
  const operateManagementApplication = () => {
    handleAdd && handleAdd(true, record, 'upDate');
  };
  return (
    <div style={{ display: 'flex' }} className="event">
      <div className="operate" onClick={updateOrUpdateSwimmingLane}>{ Enable ? intl('widget.common.close1') : intl('widget.common.open1') }</div>
      <div className="line">|</div>
      <div className="operate" onClick={operateManagementApplication}>{intl('widget.common.edit')}</div>
      <div className="line">|</div>
      <div className="operate" onClick={deleteRepeatAlert}>{intl('widget.common.delete')}</div>
    </div>
  );
};
Event.propTypes = {
  record: PropTypes.object,
  refreshRenderPage: PropTypes.func,
  dataSourceChange: PropTypes.func,
  handleAdd: PropTypes.func,
  handleRefsh: PropTypes.func,
  EntryAppId: PropTypes.string,
  entryType: PropTypes.string,
};

export default Event;
