import React from 'react';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import SlidePanel from 'components/SlidePanel';
import ConditionList from 'containers/ConditionList';
import { IconButton, Empty } from '@ali/cn-design';
import DataFields from 'components/DataFields';
import AppMonitor from '../../components/AppMonitor';
import IconBack from 'components/IconBack';
import { get } from 'lodash';

const SwimmingLaneInfo = (props) => {
  const { value, visible, onClose, handleEdit } = props;
  const intl = useIntl();

  const handleClose = () => {
    onClose();
  };
  const items = [
    {
      dataIndex: 'Name',
      label: intl('widget.k8s_gray.swimming_lane_name'),
      visible: true,
      render: (val) => <Empty value={val}>{val}</Empty>
    },
    {
      dataIndex: 'path',
      label: 'Path',
      visible: true,
      render: (val) => <Empty value={val}>{val}</Empty>
    },
    {
      dataIndex: 'Tag',
      label: intl('widget.common.tag'),
      visible: true,
      render: (val) => <Empty value={val}>{val}</Empty>
    },
    {
      dataIndex: 'EnableRules',
      label: intl('widget.k8s_gray.mark_traffic_by_rules'),
      visible: true,
      render: (val) => !!val ? intl('widget.common.open1') : intl('widget.common.close1')
    },
  ];

  const modeData = {
    AND: intl('widget.k8s_gray.condition_and'),
    OR: intl('widget.k8s_gray.condition_or')
  };

  return (
    <SlidePanel
      title={
        <IconBack goBack={handleClose}>{intl('widget.k8s_gray.swimming_lane_info')}</IconBack>
      }
      processingText={intl('widget.common.ok')}
      isShowing={visible}
      onClose={handleClose}
      width={780}
      onMaskClick={handleClose}
    >
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <h4 className="common-title" style={{ width: 144, marginTop: 8 }}>{intl('widget.common.basic_info')}</h4>
        <IconButton onClick={() => handleEdit && handleEdit(value)}>{intl('widget.common.edit')}</IconButton>
      </div>
      <DataFields
        dataSource={value}
        items={items}
      />
      <h4 className="common-title" style={{ marginTop: 16 }}>
        {intl('widget.k8s_gray.condition_list')}
        <span style={{ color: '#777', fontWeight: 'normal', fontSize: 12, marginLeft: 8 }}>{modeData[value.condition] || '--'}</span>
      </h4>
      <ConditionList protocol="springcloud" value={value.conditions || []} show />
      <AppMonitor
        appList={value.AppIds || []}
        NamespaceId={get(value, 'NamespaceId')}
      />
    </SlidePanel>
  );
};

SwimmingLaneInfo.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  handleEdit: PropTypes.func,
};

export default SwimmingLaneInfo;
