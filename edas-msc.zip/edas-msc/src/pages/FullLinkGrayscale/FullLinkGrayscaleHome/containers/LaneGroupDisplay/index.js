import React, { useState, useEffect } from 'react';
import LaneGroupApplication from '../LaneGroupApplication';
import Observability from '../../components/Observability';
import CreateSwimminLaneForm from '../CreateSwimminLaneForm';
import EmptySwimminLane from '../../components/EmprySwimmingLane';
import SwimminLaneTable from '../SwimminLaneTable';
import CreateSwimminLaneGroupTab from '../../components/CreateSwimminLaneGroupTab';
import services from 'services';
import { find, get, isEmpty, head, map } from 'lodash';
import { Query, Loading } from '@ali/cn-design';
import { mapConditions } from 'utils';
import { jsonParse } from 'utils/transfer-data';
import PropTypes from 'prop-types';
import styles from './index.less';


const LaneGroupDisplay = (props) => {
  const { groupList, handleShowGroupForm, fetchQueryAllSwimmingLaneGroup, handlePageStatus, handleTabActiveKey, curTabKey, handleCreateSwimminLaneGroup, isCreateSwimminLaneTab } = props;
  const [groupInfo, setGroupInfo] = useState({});
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [isShowForm, setIsShowForm] = useState(false);
  const [laneInfo, setLaneInfo] = useState({});
  const [searchValues, setSearchValues] = useState({ appId: '', regionId: '' });
  const [upDateFlag, setUpDateFlag] = useState('create');
  const [curMetricsFm, setCurMetricsFm] = useState({});
  const EntryApp = get(groupInfo, 'entryApp', 'ingress');
  const [EntryAppParams, EntryAppId] = EntryApp.split(':');
  const [currentTime, setCurrentTime] = useState([]);
  const [qpsRefreshIndex, setQpsRefreshIndex] = useState(0);

  useEffect(() => {
    setRefreshIndex(Date.now);
    const data = find(groupList, { id: curTabKey === 0 ? groupInfo.Id : curTabKey }) || groupList[0] || {};
    setGroupInfo(data);
  }, [groupList, curTabKey]);
  const handleChangeGroup = (id) => {
    const data = find(groupList, { id }) || {};
    setGroupInfo(data);
    setRefreshIndex(Date.now());
  };

  const fetchQueryAllSwimmingLane = async () => {
    if (!groupInfo.id) return;
    const data = await services.QueryAllSwimmingLane({
      params: { GroupId: groupInfo.id }
    });
    const newData = map(data, item => {
      const EntryRule = get(item, 'EntryRule', '[]') || '[]';
      const condition = head(jsonParse(EntryRule)) || {};
      return {
        ...item,
        value: item.id,
        label: item.name,
        priority: condition.priority,
        path: condition.path,
        condition: condition.condition,
        conditions: mapConditions(condition.restItems),
      };
    });
    return newData;
  };
  const handleRowData = (params) => { setSearchValues(params); };
  const handleShowForm = (bool, val = {}, params) => {
    setLaneInfo({ ...val });
    setIsShowForm(bool);
    setUpDateFlag(params);
  };
  const handleOk = () => {
    setIsShowForm(false);
    setRefreshIndex(Date.now());
  };
  const handleCurMetricsFm = (params) => setCurMetricsFm(params);

  const getStartAndEndTime = (time) => {
    setCurrentTime(time);
  };

  const handleRefresh = () => {
    setQpsRefreshIndex(new Date().getTime());
  };
  return (
    <div className={styles['lane-group-content']}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: 16 }}>
        <CreateSwimminLaneGroupTab handleAdd={() => handleShowGroupForm(true)} dataSource={groupList} onChange={handleChangeGroup} fetchQueryAllSwimmingLaneGroup={fetchQueryAllSwimmingLaneGroup} handleTabActiveKey={handleTabActiveKey} curTabKey={curTabKey} handleCreateSwimminLaneGroup={handleCreateSwimminLaneGroup} isCreateSwimminLaneTab={isCreateSwimminLaneTab} handleRefresh={handleRefresh} getStartAndEndTime={getStartAndEndTime} />
      </div>
      <div style={{ display: 'flex' }}>
        <div className={styles['box-border']}>
          <LaneGroupApplication handleRowData={handleRowData} key={JSON.stringify(groupInfo)} applicationList={groupInfo.applicationList} groupInfo={groupInfo} rowValue={searchValues} groupId={groupInfo.id || ''} curTabKey={curTabKey} handleUpdate={handleShowGroupForm} />
        </div>
        <div style={{ flex: 1, width: '100%', overflow: 'hidden' }} className={styles['lane-group-qps']}>
          <Observability AppId={searchValues ? searchValues.appId : ''} AppName={searchValues ? searchValues.appName : ''} Region={searchValues ? searchValues.regionId : ''} handlePageStatus={handlePageStatus} handleCurMetricsFm={handleCurMetricsFm} curTabKey={curTabKey} searchValues={searchValues} currentTime={currentTime} qpsRefreshIndex={qpsRefreshIndex} />
        </div>
      </div>
      <div style={{ display: 'flex', marginTop: '16px' }}>
        <div className={styles['swimmin-table']}>
          <Query autoFetch={false} refreshIndex={refreshIndex} fetchData={fetchQueryAllSwimmingLane}>
            {({ data = [], loading }) => (
              <Loading visible={false} inline={false}>
                <If condition={isEmpty(data)}>
                  <EmptySwimminLane handleAdd={() => handleShowForm(true, {})} />
                </If>
                <SwimminLaneTable
                  AppId={get(groupInfo, 'EntryApplication.AppId')}
                  GroupId={get(groupInfo, 'id')}
                  applicationList={get(groupInfo, 'applicationList', [])}
                  dataSource={data}
                  dataSourceChange={() => setRefreshIndex(Date.now())}
                  handleEdit={() => handleShowForm(true, data, 'create')}
                  handleAdd={handleShowForm}
                  curMetricsFm={curMetricsFm}
                  fetchQueryAllSwimmingLaneGroup={fetchQueryAllSwimmingLaneGroup}
                  EntryApp={get(groupInfo, 'entryApp', 'ingress')}
                  curTabKey={curTabKey}
                />
              </Loading>
            )}
          </Query>
        </div>
      </div>
      <CreateSwimminLaneForm
        groupInfo={groupInfo}
        visible={isShowForm}
        onClose={() => setIsShowForm(false)}
        onOk={handleOk}
        value={laneInfo}
        upDateFlag={upDateFlag}
      />
    </div>
  );
};
LaneGroupDisplay.propTypes = {
  handleShowGroupForm: PropTypes.func,
  groupList: PropTypes.array,
  fetchQueryAllSwimmingLaneGroup: PropTypes.func,
  handlePageStatus: PropTypes.func,
  handleTabActiveKey: PropTypes.func,
  curTabKey: PropTypes.number,
  isCreateSwimminLaneTab: PropTypes.bool,
  handleCreateSwimminLaneGroup: PropTypes.func,
};

export default LaneGroupDisplay;
