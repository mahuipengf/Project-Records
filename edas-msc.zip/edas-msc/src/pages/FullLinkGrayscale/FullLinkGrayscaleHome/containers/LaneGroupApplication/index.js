import React, { useState, useEffect } from 'react';
import { Icon, Search, Table, CopyContent, Balloon } from '@ali/cn-design';
import { filter, head, map, get, forEach } from 'lodash';
import PropTypes from 'prop-types';
import styles from './index.less';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';

const LaneGroupApplication = (props) => {
  const { applicationList, handleRowData, groupInfo, handleUpdate, curTabKey } = props;
  const [searchValues] = useGlobalState('searchValues');
  const [appsList, setAppsList] = useState([]);
  const [rowData, setRowData] = useState();
  const [gatewayName, setGatewayName] = useState([]);
  // const [currentPage, setCurrentPage] = useState(1); 暂无分页
  const intl = useIntl();

  const gEntryApp = get(groupInfo, 'entryApp', 'ingress');
  const [gEntryAppParams, gEntryAppId] = gEntryApp.split(':');

  useEffect(() => {
    setAppsList(applicationList);
    setRowData(head(applicationList));
    handleRowData(head(applicationList));
    getAppList();
  }, [applicationList, curTabKey]);
  const columns = [
    {
      dataIndex: 'appName',
      title: intl('widget.k8s_gray.swimming_lane_group_involving_application'),
      key: 'appName',
      cell: (val) => <CopyContent text={val}>{val}</CopyContent>
    }
  ];
  const handleOnSearch = (key) => {
    if (key) {
      const _appsList = filter(applicationList, v => {
        if (v.appName.indexOf(key) !== -1) return true;
        else return false;
      });
      setAppsList(_appsList);
      setRowData(head(_appsList));
    } else {
      setAppsList(applicationList);
      setRowData(head(applicationList));
    }
  };
  // const handleOnChangePage = (current) => {
  //   setCurrentPage(current);
  // };
  const getAhasAppList = async() => {
    // const data = await services.SentinelListTopNAppsSummaryMetricOfAppType({
    //   params: {
    //     pageNumber: 1,
    //     pageSize: 500,
    //     searchKey: '',
    //     appTypes: '[14]', // 14
    //     AhasRegionId: searchValues.regionId,
    //     Namespace: 'default',
    //     NameSpace: 'default',
    //     RegionId: searchValues.regionId,
    //   }
    // });
    const data = await services.QueryNginxIngressGateway({
      params: {
        pageNumber: 1,
        pageSize: 500,
        searchKey: '',
        appTypes: '[14]', 
        AhasRegionId: searchValues.regionId,
        Namespace: 'default',
        Region: searchValues.regionId,
      }
    });
    // const metrics = get(data, 'metrics', []);
    // const metricsList = map(metrics, items => ({ ...items, label: items.app, value: items.armsPid }));
    const metricsList = map(data.Result, items => ({ ...items, label: items.app, value: items.armsPid }));
    return metricsList;
  };
  const getAppList = async() => {
    const entryApp = get(groupInfo, 'entryApp', 'ingress');
    const [EntryAppParams, EntryAppId] = entryApp.split(':');
    if (EntryAppId) {
      let entryGateway;
      if (EntryAppParams === 'mse') {
        // 查询MSE列表数据
        const res = await services.GetApplicationDetail({
          params: {
            regionId: searchValues.regionId,
            pageNumber: 1,
            pageSize: 100,
            AppId: EntryAppId,
          }
        });
        const result = res || [];
        // const applicationListAll = map(result, items => ({ ...items, value: items.AppId, label: items.AppName }));
        // entryGateway = filter(applicationListAll, (_t) => _t.AppId === EntryAppId);
        entryGateway = [{ ...result, value: result.AppId, label: result.AppName }];
        setGatewayName(entryGateway);
      } else if (EntryAppParams === 'aliyun-ingress') {
        const ahasAppList = await getAhasAppList();
        entryGateway = filter(ahasAppList, (_t) => _t.armsPid === EntryAppId);
        setGatewayName([{ label: entryGateway[0]?.label, nofunc: true }]); // nofunc定义不掉用接口应用可视化及Qps展示
        // 阿里云Ingress暂无入口应用
      } else if (EntryAppParams === 'mse-gw') {
        // 查询MSE云原生网关
        const data = await services.ListSwimmingLaneGateway({
          params: {
            pageNumber: 1,
            pageSize: 100,
            RegionId: searchValues.regionId,
            Region: searchValues.regionId,
            FilterParams: {
              GatewayUniqueId: EntryAppId,
            },
          }
        });
        const gw_result = get(data, 'Result', []);
        const gw_applicationList = map(gw_result, items => ({ ...items, value: items.GatewayUniqueId, label: <div>{items.Name}（<span style={{ color: '#33333385' }}>{items.GatewayUniqueId}</span>）</div> }));
        entryGateway = filter(gw_applicationList, (_t) => _t.GatewayUniqueId === EntryAppId);
        setGatewayName([{ label: entryGateway[0]?.label, nofunc: true }]); // nofunc定义不掉用接口应用可视化及Qps展示
      }
    }
    if (entryApp === 'ingress' || !entryApp) {
      setGatewayName([{ label: entryApp || 'ingress', nofunc: true }]); // nofunc定义不掉用接口应用可视化及Qps展示
    }
  };
  const EntryTypeMap = {
    ingress: intl('widget.k8s_gray.swimming_lane_group_ingress'),
    mse: intl('widget.k8s_gray.swimming_lane_group_java_gateway_server'),
    'aliyun-ingress': intl('widget.msc.fulllink.grayscale.application.ack_nginx_ingress'),
    'mse-gw': intl('widget.msc.fulllink.grayscale.application.mse.cloudprimordium'),
  };
  return (
    <div className={styles['lane-group-content']}>

      <div className={styles['lane-group-app']}>
        <div style={{ width: 240, paddingRight: 16 }}>
          <div style={{ display: 'flex' }}>
            <div>{intl('widget.common.swimming_lane_group_name')}</div>
            <div className={styles['lane-group-edit']} >
              <Balloon trigger={<Icon type="edit" onClick={() => handleUpdate(true, groupInfo, 'update')} />} align="b" closable={false}>
                {intl('widget.k8s_gray.swimming_lane_group_involving_application_edit')}
              </Balloon>
            </div>
          </div>
          {/* 搜索功能 */}
          <Search
            shape="simple"
            style={{ width: '100%', margin: '8px 0px 6px 0px' }}
            onSearch={handleOnSearch}
          />
          <div style={{ margin: '4px 0px 2px 0px' }}>
            <span>{intl('widget.k8s_gray.entry_type')}：{EntryTypeMap[gEntryAppParams]}</span>
          </div>
          <If condition={gatewayName.length > 0}>
            <div style={{ margin: '2px 0px 6px 0px' }}>
              <span>{intl('widget.k8s_gray.entry_application_title')}：</span><span className={styles['gateway-name']} style={{ cursor: gatewayName.length > 0 && gatewayName[0].label !== 'ingress' && !gatewayName[0].nofunc ? 'pointer' : 'auto' }} onClick={() => { if ((gatewayName.length > 0 && gatewayName[0].label !== 'ingress' && !gatewayName[0].nofunc)) { handleRowData({ appId: gatewayName[0].AppId, regionId: gatewayName[0].RegionId, appName: gatewayName[0].AppName }); } }}>
                <Balloon
                  closable={false}
                  trigger={<div className={styles['portal-gateway']} style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{gatewayName.length > 0 && gatewayName[0].label}</div>}
                >
                  <div>{gatewayName.length > 0 && gatewayName[0].label}</div>
                </Balloon>
              </span>
            </div>
          </If>
          <div>
            <Table
              columns={columns}
              dataSource={appsList}
              hasBorder={false}
              style={{
                border: 'none'
              }}
              cellProps={(rowIndex, colIndex, dataIndex, record) => ({
                style: {
                  cursor: 'pointer',
                },
              })}
              rowProps={(record) => ({
                className: `${
                  `${record.appName}:${record.appId}` ===
                  `${rowData.appName}:${rowData.appId}`
                    ? 'table-active'
                    : ''
                } ${record.Uid}`,
                style: {
                  position: 'relative',
                },
              })}
              fixedHeader
              maxBodyHeight={300}
              onRowClick={(record) => { setRowData(record); handleRowData(record); }}
            />
            {/* <Pagination
              shape="no-border"
              type="simple"
              current={currentPage}
              total={applicationList && applicationList.length}
              onChange={handleOnChangePage}
              pageSize={10}
              hideOnlyOnePage
            /> */}
          </div>
        </div>
      </div>
    </div>
  );
};
LaneGroupApplication.propTypes = {
  applicationList: PropTypes.array,
  handleRowData: PropTypes.func,
  handleUpdate: PropTypes.func,
  groupInfo: PropTypes.object,
};

export default LaneGroupApplication;
