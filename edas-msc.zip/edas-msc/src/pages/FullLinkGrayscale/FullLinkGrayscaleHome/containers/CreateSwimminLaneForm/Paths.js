import React from 'react';
import { useIntl } from '@ali/widget-hooks';
import { map, filter, uniqueId, isEmpty, size, find } from 'lodash';
import { Icon, Input, Message } from '@alicloud/console-components';
import PropTypes from 'prop-types';
import { IconButton } from '@ali/cn-design';

const Paths = ({ onChange, dataSource, value = [], addText, canEmpty = false }) => {
  const intl = useIntl();

  const handleAdd = () => {
    const newValue = [...value, { uid: uniqueId() }];
    onChange(newValue);
  };

  const handleDelete = (uid) => {
    const newValue = filter(value, item => item.uid !== uid);
    onChange(newValue);
  };

  const handleChange = (uid, val) => {
    const newValue = map(value, item => item.uid === uid ? { ...item, value: val } : item);
    onChange(newValue);
  };

  console.log('dataSouvaluerce', value);
  return (
    <React.Fragment>
      <For each="item" of={value}>
        <div key={item.uid}>
          <Input
            style={{ width: '95%', marginTop: 4 }}
            onChange={(val) => handleChange(item.uid, val)}
            // dataSource={getDataSource()}
            value={item.value}
            placeholder={intl('widget.k8s_gray.please_enter_path')}
          />
          <If condition={value.length > 1 || canEmpty}>
            <Icon type="delete" size="xs" style={{ marginLeft: 8, cursor: 'pointer' }} onClick={() => handleDelete(item.uid)} />
          </If>
        </div>
      </For>
      <If condition={isEmpty(value)}>
        <div style={{ color: '#777', }}>{intl('widget.common.no_data')}</div>
      </If>
      <IconButton style={{ marginTop: 8 }} type="add" onClick={handleAdd}>{addText}</IconButton>
    </React.Fragment>
  );
};

Paths.propTypes = {
  onChange: PropTypes.func,
  placeholder: PropTypes.string,
  dataSource: PropTypes.arrayOf(PropTypes.object),
};

export default Paths;
