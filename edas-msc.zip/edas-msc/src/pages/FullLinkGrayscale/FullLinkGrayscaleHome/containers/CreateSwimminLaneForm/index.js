import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Field, Form, Input, Message, Select, Icon, Radio, Button } from '@alicloud/console-components';
import Dialog from 'components/Dialog';
import services from 'services';
import { TableContainer, Transfer } from '@ali/cn-design';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { map, get, isEmpty, forEach, uniqueId, cloneDeep } from 'lodash';
import ConditionList from 'containers/ConditionList';
import GatewayConditionList from 'containers/GatewayConditionList/gwc';
import { upperFirstData } from 'utils/transfer-data';
import { mapConditions, mapConditionsFormData } from 'utils';
import styles from './index.less';


let allRouteData = 0; // 初始化总可选路由
const EditForm = (props) => {
  const field = Field.useField();
  const { value = {}, visible, onClose, onOk, groupInfo, enable, upDateFlag } = props;
  const [searchValues] = useGlobalState('searchValues');
  const [dataSource, setDataSource] = useState({});
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [selTag, setSelTag] = useState('');
  const [isAppList, setIsAppList] = useState(false);
  const intl = useIntl();
  const { init, validate, getValue, setValues, getValues, setValue } = field;
  const Id = get(groupInfo, 'id');
  const RegionId = get(groupInfo, 'region');
  const EntryApp = get(groupInfo, 'entryApp', 'ingress');
  const [EntryAppParams, EntryAppId] = EntryApp.split(':');
  const [entryType, setEntryType] = useState('ingress');
  const [transferDataSource, setTransferDataSource] = useState([]);
  const [leftRouteDataLen, setLeftRouteDataLen] = useState(0);
  const [rightRouteDataLen, setRightRouteDataLen] = useState(0);
  const [loading, setLoading] = useState(false);

  // MSE 云原生网关 回显
  const gatewaySwimmingLaneRouteJson = get(value, 'gatewaySwimmingLaneRouteJson', '{}');
  const gatewaySwimmingLaneRoute = gatewaySwimmingLaneRouteJson ? JSON.parse(gatewaySwimmingLaneRouteJson) : {};
  const { conditions: gw_conditions = [], routeIdList } = gatewaySwimmingLaneRoute;
  const new_gw_conditions = map(gw_conditions, item => ({ ...item, uid: uniqueId() }));

  useEffect(() => {
    // 泳道兼容
    if (EntryAppParams === 'mse') {
      setEntryType('Java');
    } else if (EntryAppParams === 'aliyun-ingress') {
      setEntryType('AliCloudIngress');
    } else if (EntryAppParams === 'ingress') {
      setEntryType('ingress');
    } else if (EntryAppParams === 'mse-gw') {
      setEntryType('CloudPrimordium');
    }
  }, [EntryApp]);
  useEffect(() => {
    EntryAppParams === 'mse-gw' && getDataSource();
  }, [EntryAppId, upDateFlag]);

  const entryRule = !isEmpty(value) && upDateFlag === 'upDate' && JSON.parse(get(value, 'entryRule', '[{}]'));
  const paths = (entryRule && entryRule.length > 0 && (EntryAppParams !== 'mse-gw' && EntryAppParams !== 'ingress') && entryRule[0].paths) || [];
  const [pathsDataSource, setPathsDataSource] = useState([]);


  useEffect(() => {
    setRefreshIndex(Date.now());
    setIsAppList(false);
    // ACK Ingress网关、 Java、 微服务网关、 其他 Ingress 网关
    !isEmpty(value) && entryRule && (EntryAppParams !== 'mse-gw' && EntryAppParams !== 'ingress') && setValues({ ...value, paths: entryRule[0].paths || [], conditions: mapConditions(entryRule[0].restItems), condition: entryRule[0].condition });
    // 其他 Ingress 网关
    !isEmpty(value) && entryRule && EntryAppParams === 'ingress' && setValues({ ...value });
    // MSE 云原生网关
    !isEmpty(value) && entryRule && EntryAppParams === 'mse-gw' && setValues({ ...value, conditions: new_gw_conditions, condition: entryRule[0]?.condition || 'AND', baseRoute: routeIdList }); // condition 网关目前支持所有and
    !isEmpty(groupInfo) && featchGetTagsBySwimmingLaneGroupId();
    setPathsDataSource(paths);
    upDateFlag !== 'upDate' && setValue('conditions', []);
  }, [value]);
  const featchGetTagsBySwimmingLaneGroupId = async() => {
    const res = await services.GetTagsBySwimmingLaneGroupId({
      params: { GroupId: Id }
    });
    const Tags = map(res, items => ({
      value: JSON.parse(items)[0].tag,
      label: JSON.parse(items)[0].tag,
      key: JSON.parse(items)[0].tag,
    }));
    setDataSource(Tags);
  };

  const handleChange = (val) => {
    setIsAppList(true);
    setValues({ tag: val });
    setSelTag(val);
    setRefreshIndex(Date.now());
    setValue('tag', val);
    setValue('name', val);
    validate(['tag']);
  };
  const handleRadioChange = (val) => {
    setValues('condition', val);
  };
  const fetchAppTagList = async(params) => {
    const res = await services.ListAppBySwimmingLaneGroupTag({
      params: {
        ...params,
        Tag: selTag,
        GroupId: Id,
      }
    });
    return {
      Data: res,
      TotalCount: res.length || 1,
    };
  };
  const handleSubmit = () => {
    setLoading(true);
    let validate_check_Data = EntryApp !== 'ingress' ? ['name', 'tag', 'condition', 'conditions', 'path', 'paths'] : ['name', 'tag'];
    if (EntryAppParams === 'mse') {
      validate_check_Data = ['name', 'tag', 'condition', 'conditions', 'path', 'paths'];
    } else if (EntryAppParams === 'aliyun-ingress') {
      validate_check_Data = ['name', 'tag', 'condition', 'conditions', 'path', 'paths'];
    } else if (EntryAppParams === 'ingress') {
      validate_check_Data = ['name', 'tag'];
    } else if (EntryAppParams === 'mse-gw') {
      validate_check_Data = ['name', 'tag', 'condition', 'conditions', 'path', 'baseRoute'];
    }
    validate(validate_check_Data, async(error, values) => {
      if (error) {
        setLoading(false);
        return;
      }
      // 深拷贝
      const deep_gw_conditions = values.conditions ? cloneDeep(values.conditions) : [];
      const conditions = entryType !== 'CloudPrimordium' ? map(upperFirstData(mapConditionsFormData(deep_gw_conditions)), items => ({ ...items, Value: `${items.Value}` })) : [];
      const valId = upDateFlag === 'upDate' ? value.id : -1;
      const valEnable = upDateFlag === 'upDate' ? value.enable : true;
      const valStatus = upDateFlag === 'upDate' ? value.status : 0;
      const valGroupId = upDateFlag === 'upDate' ? value.groupId : Id;
      const valTag = upDateFlag === 'upDate' ? values.tag : selTag;
      const Paths = get(values, 'paths', []);
      const EntryRules = [
        {
          Priority: 1,
          Paths,
          Condition: values.condition,
          RestItems: [
            ...conditions
          ]
        }
      ];
      // 网关MSE云原生
      const baseRoute = values?.baseRoute || [];
      const GatewaySwimmingLaneRouteJson = {
        GatewayUniqueId: EntryAppId || '',
        RouteIdList: baseRoute || [],
        Conditions: values.conditions ? upperFirstData(deep_gw_conditions) : [], // upperFirstData(
      };
      await services.CreateOrUpdateSwimmingLane({
        params: {
          Id: valId,
          Name: values.name,
          Tag: valTag, // valTag
          Enable: valEnable,
          Status: valStatus,
          GroupId: valGroupId,
          RegionId,
          EntryRules,
          EntryRule: JSON.stringify(EntryRules),
          GatewaySwimmingLaneRouteJson: entryType === 'CloudPrimordium' ? GatewaySwimmingLaneRouteJson : {},
        }
      }).then((res) => {
        if (value.id && value.enable && value.status && upDateFlag === 'upDate') {
          Message.success(intl('widget.k8s_gray.swimming_lane_update_success'));
        } else {
          Message.success(intl('widget.k8s_gray.swimming_lane_create_success'));
        }
        setValue('conditions', []);
        onOk && onOk();
        setLoading(false);
      }).catch((err) => {
        setLoading(false);
        if (value.id && value.enable && value.status && upDateFlag === 'upDate') {
          Message.error(intl('widget.k8s_gray.swimming_lane_update_error'));
          return true;
        } else {
          Message.error(intl('widget.k8s_gray.swimming_lane_create_error'));
          return true;
        }
      });
    });
    window.CN_TRACKER.send({ 
      name: 'grayscale-createSwimLanes-ok', 
      type:'mse-msc-grayscale'
    },{});
  };


  const columns = [
    {
      title: intl('widget.common.app_name'),
      dataIndex: 'appName',
      key: 'appName',
    }
  ];

  const handleValidatorConditions = (rule, val, callback) => {
    forEach(val, item => {
      if (EntryAppParams === 'mse-gw' || EntryAppParams === 'aliyun-ingress') {
        if (!item.type || !item.name || !item.cond || !item.value) {
          // callback('请添加完整规则列表');
          callback(intl('widget.route.condition.rule_not_complete'));
          return;
        }
      }
      if (EntryAppParams === 'mse') {
        if (!item.type || !item.name || !item.cond || (!item.value && item.value !== 0)) {
          callback(intl('widget.route.condition.rule_not_complete'));
        }
      }
      if (getValue('protocol') === 'dubbo') {
        if (!(item.index >= 0) || !item.cond || (!item.value && item.value !== 0)) {
          callback(intl('widget.route.condition.rule_not_complete'));
          return;
        }
      }
      if (getValue('protocol') === 'springCloud' || getValue('protocol') === 'istio') {
        if (!item.type || !item.name || !item.cond || (!item.value && item.value !== 0)) {
          callback(intl('widget.route.condition.rule_not_complete'));
        }
      }
    });
    callback();
  };

  const handleChangeConditionList = () => {
    setValues({ ...value, ...getValues() });
  };
  const modeData = [
    { value: 'AND', label: intl('widget.route.condition_and') },
    { value: 'OR', label: intl('widget.route.condition_or') },
  ];
  const gw_modeData = [
    { value: 'AND', label: intl('widget.route.condition_and') },
  ];

  const getDataSource = async () => {
    const data = await services.ListSwimmingLaneGatewayRoute({ // ListSwimmingLaneGatewayRoute ListGatewayRoute
      params: {
        PageSize: 200,
        PageNumber: 1,
        RegionId: searchValues.regionId,
        Region: searchValues.regionId,
        GatewayUniqueId: EntryAppId,
      }
    });
    const result = data || [];
    const newReuslt = result.map((item => ({ ...item, label: item.Name, value: item.Id })));
    allRouteData = newReuslt && newReuslt.length > 0 ? newReuslt.length : 0;
    setTransferDataSource(newReuslt);
    if (upDateFlag !== 'upDate') {
      setLeftRouteDataLen(allRouteData);
      setRightRouteDataLen(0);
    }
    if (upDateFlag === 'upDate') {
      const leftLen = newReuslt && newReuslt.length > 0 && routeIdList && routeIdList.length > 0 ? newReuslt.length - routeIdList.length : 0;
      const rightLen = routeIdList && routeIdList.length > 0 ? routeIdList.length : 0;
      setLeftRouteDataLen(leftLen);
      setRightRouteDataLen(rightLen);
    }
  };

  const handleTransferChange = (val, data, extra) => {
    const { leftData } = extra;
    const leftLen = leftData?.length || 0;
    const rightLen = allRouteData - leftLen;
    setLeftRouteDataLen(leftLen);
    setRightRouteDataLen(rightLen);
  };

  return (
    <Form field={field}>
      <Dialog
        title={`${upDateFlag === 'upDate' ? intl('widget.k8s_gray.edit_swimming_lane_group') : intl('widget.k8s_gray.create_swimming_lane_group')}`}
        visible={visible}
        // onOk={handleSubmit}
        // onCancel={onClose}
        onClose={() => { setValue('conditions', []); onClose(); }}
        footer={[
        <Button type="primary" onClick={handleSubmit}><If condition={loading}><Icon type="loading" /></If>确定</Button>, 
        <Button onClick={() => { setValue('conditions', []); onClose(); }}>取消</Button>
      ]}
      >
        <div className={styles['step-content']}>
          <div className={styles['step-explain']}>{intl.html('widget.app.new_canary_instructions')}</div>
          {/* <div style={{ width: 678 }}>
            <span className={styles['step-title']}>STEP 1</span>
            <span className={styles['step-circular']} />
            {intl.html('widget.k8s_gray.swimming_lane_one_tag')}
          </div>
          <div style={{ display: 'flex' }}>
            {intl.html('widget.k8s_gray.swimming_lane_one_msg')}
            <span className={styles['step-line']} />
            <Form.Item required>
              <Input
                {
                    ...init('name', {
                      intlValue: '',
                      rules: [
                        { required: true, message: intl('widget.msc.place.enter.lane.name') },
                      ],
                      props: {
                        onchange: (v) => v,
                      }
                    })
                }
                style={{ width: '280px' }}
              />
            </Form.Item>
          </div> */}
          <div style={{ display: 'flex' }}>
            <span className={styles['step-title']}>STEP 1</span>
            <span className={styles['step-circular-config']} />
            {intl.html('widget.k8s_gray.swimming_lane_two_tag')}
          </div>
          <div style={{ display: 'flex' }}>
            <span>
              {intl.html('widget.k8s_gray.swimming_lane_two_msg')}
            </span>
            <span className={styles['step-line2']} />
            {intl.html('widget.msc.fulllink.grayscale.lane.config.node.tag', { tag: '{tag}' })}
            {/* <div className={styles['step-font']}>
              <div>{intl.html('widget.k8s_gray.swimming_lane_two_config', { name: 'B' })}</div>
              <div><span className={styles['step-tip']}> msePilotCrateAppName</span> :${'{AppName}'}</div>
              <div><span className={styles['step-tip']}> alicloud.service.tag</span>: gray</div>
            </div> */}
          </div>
          <div>
            <span className={styles['step-title']}>STEP 2</span>
            <span className={`${enable ? styles['step-circular-err'] : styles['step-circular']}`} />
            {intl.html('widget.k8s_gray.swimming_lane_three_add_application')}
          </div>
          <div style={{ display: 'flex' }}>
            <span className={styles['step-msg']}>{intl.html('widget.k8s_gray.swimming_lane_three_msg')}</span>
            <div className={styles['line-bfc-box']}>
              <div>
                <div style={{ display: 'flex' }}>
                  <Form.Item required>
                    <Select.AutoComplete
                      {
                        ...init('tag', {
                          intlValue: '',
                          rules: [
                            { required: true, message: intl('widget.service_retry.tag_placeholder') }, //  message: intl('widget.service_retry.tag_placeholder')
                          ],
                        })
                      }
                      showSearch
                      style={{ minWidth: '280px', marginTop: '4px' }}
                      dataSource={dataSource}
                      defaultValue={selTag}
                      onChange={handleChange}
                      placeholder={intl('widget.service_retry.tag_placeholder')}
                      disabled={upDateFlag === 'upDate' && entryType === 'CloudPrimordium'}
                      followTrigger
                    />
                  </Form.Item>
                  <Form.Item required style={{ width: '300px', marginLeft: '24px' }}>
                    <Input
                      {
                          ...init('name', {
                            intlValue: '',
                            rules: [
                              { required: true, message: intl('widget.msc.place.enter.lane.name') },
                            ],
                            props: {
                              onchange: (v) => v,
                            }
                          })
                      }
                      placeholder={intl('widget.msc.place.enter.lane.name')}
                      style={{ width: '280px', marginTop: '4px' }}
                    />
                  </Form.Item>
                </div>
                <div className={styles['step-tips']}>
                  <Icon type="info-circle-fill" size="medium" className={styles['step-icon']} /> {intl.html('widget.k8s_gray.swimming_lane_three_after_creation')}
                </div>
                <If condition={isAppList}>
                  <TableContainer
                    refreshIndex={refreshIndex}
                    fetchData={fetchAppTagList}
                    columns={columns}
                    pagination={{ shape: 'no-border', type: 'simple', pageSize: '10', pageSizeSelector: false, hideOnlyOnePage: true }}
                  />
                </If>
              </div>
            </div>
          </div>
          <div>
            <span className={styles['step-title']}>STEP 3</span>
            <span className={`${enable ? styles['step-circular-err'] : styles['step-circular']}`} />
            <If condition={EntryApp === 'ingress'}>
              {intl.html('widget.k8s_gray.swimming_lane_four_tag')}
            </If>
            <If condition={entryType === 'Java' || entryType === 'AliCloudIngress' || entryType === 'CloudPrimordium'}>
              {intl.html('widget.k8s_gray.swimming_lane_four_rule')}
            </If>
          </div>
          <div style={{ display: 'flex' }}>
            <span>{intl.html('widget.k8s_gray.swimming_lane_four_msg')}</span>
            <div className={styles['swimming-event-list']}>
              <If condition={entryType === 'Java' || entryType === 'AliCloudIngress'}>
                <div className={styles['swimming-event-list-box']}>
                  <Form.Item label="Path">
                    <Select
                      {
                        ...init('paths', {
                        })
                      }
                      maxTagCount={10}
                      mode="tag"
                      dataSource={pathsDataSource}
                      style={{ width: '100%' }}
                      placeholder={intl('widget.route.condition.list_placeholder')}
                      notFoundContent={intl('widget.route.condition.no_data_list_placeholder')}
                    />
                  </Form.Item>
                  <Form.Item label={intl('widget.route.condition_mode')} required>
                    <Radio.Group
                      {...init('condition', {
                        initValue: value.condition || 'AND',
                        rules: [
                          {
                            required: true,
                            message: intl('widget.route.condition_mode_error'),
                          },
                        ],
                        props: {
                          onChange: handleRadioChange
                        }
                      })}
                      dataSource={modeData}
                    />
                  </Form.Item>
                  <Form.Item
                    label={intl('widget.route.condition_list')}
                    style={{ width: '700px' }}
                    required
                  >
                    <ConditionList
                      {...init('conditions', {
                        initValue: value.conditions || [],
                        rules: [
                          {
                            required: true,
                            message: intl('widget.route.condition_list_error'),
                          },
                          {
                            validator: handleValidatorConditions,
                          }
                        ],
                        props: {
                          onChange: handleChangeConditionList
                        }
                      })}
                      method={getValue('method')}
                      protocol="springCloud"
                    />
                  </Form.Item>
                </div>
              </If>
              <If condition={entryType === 'CloudPrimordium'}>
                <div className="createswimminglaneform">
                  <Form.Item
                    label="选择已在网关创建的基线路由"
                    required
                  >
                    <Transfer
                      {...init('baseRoute', {
                        props: {
                          rules: [
                            {
                              required: true,
                              message: '请选择网关基线路由',
                            },
                          ],
                          onChange: handleTransferChange
                        }
                      })}
                      listClassName="swimmingTransfer"
                      showSearch
                      mode="simple"
                      dataSource={transferDataSource}
                      // onChange={handleTransferChange}
                      titles={[`可选路由（${leftRouteDataLen}）`, `已选路由（${rightRouteDataLen}）`]}
                      itemRender={(obj) => {
                        const DomainNameList = obj?.DomainNameList.length > 0 ? obj.DomainNameList.join(',') : '';
                        const Predicates = obj.RoutePredicates || {};
                        const pathPredicates = Predicates.PathPredicates || {};
                        const path = pathPredicates?.Path || '';
                        return (<div>
                          <div style={{ fontWeight: 'bold', height: '18px' }}>{obj.label}</div>
                          <div style={{ color: '#33383394' }}>
                            <div style={{ height: '12px' }}>{DomainNameList}</div>
                            <div style={{ height: '12px' }}>{path}</div>
                          </div>
                        </div>);
                      }}
                    />
                  </Form.Item>
                  <Form.Item label={intl('widget.route.condition_mode')} required>
                    <Radio.Group
                      {...init('condition', {
                        initValue: 'AND',
                        rules: [
                          {
                            required: true,
                            message: intl('widget.route.condition_mode_error'),
                          },
                        ],
                      })}
                      disabled
                      dataSource={gw_modeData}
                    />
                  </Form.Item>
                  <Form.Item
                    label={intl('widget.route.condition_list')}
                    style={{ width: '700px' }}
                    required
                  >
                    <GatewayConditionList
                      {...init('conditions', {
                        initValue: value.conditions || [],
                        rules: [
                          {
                            required: true,
                            message: intl('widget.route.condition_list_error'),
                          },
                          {
                            validator: handleValidatorConditions,
                          }
                        ],
                        props: {
                          onChange: handleChangeConditionList
                        }
                      })}
                      method={getValue('method')}
                      protocol="springCloud"
                    />
                  </Form.Item>
                </div>
              </If>
            </div>
          </div>
        </div>
      </Dialog>
    </Form>
  );
};

EditForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  groupInfo: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
  enable: PropTypes.bool,
  appName: PropTypes.string,
  upDateFlag: PropTypes.string,
};

export default EditForm;
