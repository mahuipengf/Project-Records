import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Field, Form, Input, Radio, Select, Switch, Balloon, Icon, Message } from '@alicloud/console-components';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { NNAME_PATTERN } from 'constants';
import SlidePanel from 'components/SlidePanel';
import { map, find, join, get, uniqueId, filter, forEach, isEmpty } from 'lodash';
import IconBack from 'components/IconBack';
import { aliyunSite } from 'utils';
import DialogAlert from 'components/DialogAlert';

const FormItem = Form.Item;

const EditForm = (props) => {
  // 网关初始化
  const initPortalApplication = aliyunSite !== 'INTL' ? 'CloudPrimordium' : 'ingress';
  const field = Field.useField();
  const [searchValues] = useGlobalState('searchValues');
  const [appList, setAppList] = useState([]);
  const [initList, setInitList] = useState([]);
  const [ahasInitList, setAhasInitList] = useState([]);
  const [entryAppList, setEntryAppList] = useState([]);
  const [entryApplication, setEntryApplication] = useState(initPortalApplication);
  const { value, visible, onClose, onOk, updateFlag, handleCreateSwimminLaneGroup } = props;
  const intl = useIntl();
  const { init, validate, setValues, reset, setValue, getValue } = field;
  const entryApp = get(value, 'entryApp', '');
  const [EntryAppParams, EntryAppId] = entryApp.split(':');
  const Name = get(value, 'name', '');
  let EntryType = initPortalApplication;
  if (EntryAppParams === 'mse') {
    EntryType = 'Java';
  } else if (EntryAppParams === 'aliyun-ingress') {
    EntryType = 'AliCloudIngress';
  } else if (EntryAppParams === 'ingress') {
    EntryType = 'ingress';
  } else if (EntryAppParams === 'mse-gw') {
    EntryType = 'CloudPrimordium';
  }
  // 采集请求详情
  const RecordCanaryDetail = get(value, 'RecordCanaryDetail', false);
  // 消息灰度
  const MessageQueueGrayEnable = get(value, 'messageQueueGrayEnable', false);
  const MessageQueueFilterSide = get(value, 'messageQueueFilterSide', 'Client');
  const DbGrayEnable = get(value, 'dbGrayEnable', false);
  // const EntryType = EntryAppId ? 'Java' : 'ingress';
  const ApplicationList = map(get(value, 'applicationList', []), item => ({ ...item, value: item.appId, label: item.appName, uid: uniqueId() }));
  const [ahasAppList, setAhasAppList] = useState([]);
  const [gatewayAppList, setGatewayAppList] = useState([]);
  const [gatewayInitList, setgatewayInitList] = useState([]);
  const [isGrayscale, setIsGrayscale] = useState(false);
  const [searchKey, setSearchKey] = useState('');
  const [searchApp, setSearchApp] = useState('');
  const [searchName, setSearchName] = useState('');
  const [swimminLaneGroupTag, setSwimminLaneGroupTag] = useState('entrance');

  useEffect(() => {
    setEntryApplication(initPortalApplication);
    (visible) && getGatewayAppList();
  }, [visible]);
  useEffect(() => {
    const newValue = {
      ...value || {},
      Name,
      EntryType,
      EntryAppId: (EntryType === 'Java' && EntryAppId) || '',
      AppIds: ApplicationList,
      AhasIngressAppId: (EntryType === 'AliCloudIngress' && EntryAppId) || '',
      GatewayIngressAppId: (EntryType === 'CloudPrimordium' && EntryAppId) || '',
      MessageQueueGrayEnable,
      MessageQueueFilterSide,
      DbGrayEnable,
      RecordCanaryDetail,
    };
    setEntryApplication(EntryType);
    setValues(newValue || {});
    setIsGrayscale(MessageQueueGrayEnable);
  }, [value]);
  // useEffect(() => {
  //   getValue('EntryType') === 'AliCloudIngress' && getAhasAppList();
  // }, [value, searchKey, getValue('EntryType')]);


  useEffect(() => {
    getAppList();
  }, [value, searchApp]);

  // useEffect(() => {
  //   getValue('EntryType') === 'CloudPrimordium' && getGatewayAppList();
  // }, [value, searchName, getValue('EntryType')]);

  // AHAS列表
  const getAhasAppList = async() => {
    // const data = await services.SentinelListTopNAppsSummaryMetricOfAppType({
    //   params: {
    //     pageNumber: 1,
    //     pageSize: 500,
    //     searchKey,
    //     appTypes: '[14]', // 14
    //     AhasRegionId: searchValues.regionId,
    //     Namespace: 'default',
    //     NameSpace: 'default',
    //     RegionId: searchValues.regionId,
    //   }
    // });
    const data = await services.QueryNginxIngressGateway({
      params: {
        pageNumber: 1,
        pageSize: 500,
        searchKey,
        appTypes: '[14]', // 14
        AhasRegionId: searchValues.regionId,
        Namespace: 'default',
        Region: searchValues.regionId,
      }
    });
    // const metrics = get(data, 'metrics', []);
    const metricsList = map(data.Result, items => ({ ...items, label: items.app, value: items.armsPid }));
    let editApplicationList_Init = metricsList;
    forEach(ApplicationList, (_t) => {
      editApplicationList_Init = filter(editApplicationList_Init, (item) => _t.appId !== item.armsPid);
    });
    const editApplicationList = editApplicationList_Init.map(ite => ite.AppName)
    setAhasAppList(editApplicationList);
    setAhasInitList(metricsList);
  };
  // MSE网关列表
  const getGatewayAppList = async() => {
    const data = await services.ListSwimmingLaneGateway({
      params: {
        pageNumber: 1,
        pageSize: 100,
        RegionId: searchValues.regionId,
        Region: searchValues.regionId,
        FilterParams: {
          Name: searchName,
        },
      }
    });
    const result = get(data, 'Result', []);
    const applicationList = map(result, items => ({ ...items, value: items.GatewayUniqueId, label: <div>{items.Name}（<span style={{ color: '#33333385' }}>{items.GatewayUniqueId}</span>）</div> }));
    let editApplicationList_getway = applicationList;
    forEach(ApplicationList, (_t) => {
      editApplicationList_getway = filter(editApplicationList_getway, (item) => _t.appId !== item.GatewayUniqueId);
    });
    setGatewayAppList(editApplicationList_getway);
    setgatewayInitList(applicationList);
  };
  // Mse列表
  const getAppList = async(flag) => {
    const res = await services.GetAppList({
      params: {
        regionId: searchValues.regionId,
        pageNumber: 1,
        pageSize: 100,
        AppName: searchApp
      }
    });
    const result = get(res, 'Result', []);
    const applicationList = map(result, items => ({ ...items, value: items.AppId, label: items.AppName }));
    let editApplicationList = filter(applicationList, _t => _t.AppId !== EntryAppId);
    let editApplicationList_Init = applicationList;

    forEach(ApplicationList, (_t) => {
      editApplicationList_Init = filter(editApplicationList_Init, (item) => _t.AppId !== item.AppId);
    });
    const entry = getValue('EntryType');
    const entryAppId = getValue('EntryAppId');
    const appIds = getValue('AppIds');
    if (entry === 'Java' && entryAppId) {
      editApplicationList = filter(applicationList, _t => _t.AppId !== entryAppId);
    }
    if (entry === 'Java' && appIds?.length > 0) {
      forEach(appIds, (aId) => {
        if (aId instanceof Object) { // 编辑初始化时为object类型
          editApplicationList_Init = filter(editApplicationList_Init, (item) => aId.appId !== item.AppId);
        } else {
          editApplicationList_Init = filter(editApplicationList_Init, (item) => aId !== item.AppId);
        }
      });
    }
    setAppList(editApplicationList_Init);
    (swimminLaneGroupTag === 'swimminLaneGroup' || !searchApp) && setInitList(applicationList);
    if ((entryAppList.length === 0 || flag === 'ingress') && entry !== 'Java') setEntryAppList(applicationList);
    else (swimminLaneGroupTag === 'swimminLaneGroup' || !searchApp) && setEntryAppList(editApplicationList);
  };

  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const Id = get(value, 'id');
      const _Id = updateFlag === 'update' ? Id : -1;
      const EntryAppMap = {
        Java: `mse:${values.EntryAppId}`,
        ingress: values.EntryType,
        AliCloudIngress: `aliyun-ingress:${values.AhasIngressAppId}`,
        CloudPrimordium: `mse-gw:${values.GatewayIngressAppId}`
      };
      const EntryApp = EntryAppMap[values.EntryType];
      // 初始化AppIds
      let appId = '';
      if (values && values.AppIds.length > 0 && typeof values.AppIds[0] === 'string') {
        appId = join(values.AppIds);
      } else if (values && values.AppIds.length > 0 && typeof values.AppIds[0] !== 'string') {
        appId = join(map(values.AppIds, item => {
          return item.appId;
        }));
      }
      if (values.RecordCanaryDetail) {
        const Data = await services.CheckXTraceServiceStatus({
          params: {
            Region: searchValues.regionId,
          }
        });
        if (!Data) {
          DialogAlert({
            title: intl('widget.common.tips.info'),
            content: <div style={{ width: '340px', lineHeight: '18px' }}>{intl('widget.msc.fulllink.grayscale.collection.request.details')}</div>,
            onOk: async () => {
              const isSuccess = await services.OpenXTraceService({
                params: {
                  Region: searchValues.regionId,
                }
              });
              isSuccess && Message.success({ title: intl('widget.common.open.success'), duration: 3000 });
              !isSuccess && Message.warning({ title: intl('widget.common.open.error'), duration: 3000 });
              await services.CreateOrUpdateSwimmingLaneGroup({
                params: {
                  Id: _Id,
                  Name: values.Name,
                  AppIds: appId || '',
                  Region: searchValues.regionId,
                  Enable: true,
                  Status: 0,
                  EntryApp,
                  RecordCanaryDetail: values.RecordCanaryDetail || false,
                  MessageQueueGrayEnable: values.MessageQueueGrayEnable || false,
                  MessageQueueFilterSide: values.MessageQueueFilterSide || 'Client',
                  DbGrayEnable: values.DbGrayEnable || false,
                }
              }).then(() => {
                onOk && onOk();
                if (updateFlag !== 'update') {
                  handleCreateSwimminLaneGroup && handleCreateSwimminLaneGroup(true);
                  setIsGrayscale(false);
                }
              });
              // window.open('https://common-buy.aliyun.com/?spm=5176.22294701.J_5253785160.2.15971088TixWtq&commodityCode=xtrace#/open');
            },
            onCancel: () => {
            },
            okProps: { children: intl('widget.common.ok') },
            cancelProps: { children: intl('widget.common.cancel') },
            footerActions: ['ok', 'cancel'],
            closeable: false,
          });
        } else {
          await services.CreateOrUpdateSwimmingLaneGroup({
            params: {
              Id: _Id,
              Name: values.Name,
              AppIds: appId || '',
              Region: searchValues.regionId,
              Enable: true,
              Status: 0,
              EntryApp,
              RecordCanaryDetail: values.RecordCanaryDetail || false,
              MessageQueueGrayEnable: values.MessageQueueGrayEnable || false,
              MessageQueueFilterSide: values.MessageQueueFilterSide || 'Client',
              DbGrayEnable: values.DbGrayEnable || false,
            }
          }).then(() => {
            onOk && onOk();
            if (updateFlag !== 'update') {
              handleCreateSwimminLaneGroup && handleCreateSwimminLaneGroup(true);
              setIsGrayscale(false);
            }
          });
        }
      } else {
        await services.CreateOrUpdateSwimmingLaneGroup({
          params: {
            Id: _Id,
            Name: values.Name,
            AppIds: appId || '',
            Region: searchValues.regionId,
            Enable: true,
            Status: 0,
            EntryApp,
            RecordCanaryDetail: values.RecordCanaryDetail || false,
            MessageQueueGrayEnable: values.MessageQueueGrayEnable || false,
            MessageQueueFilterSide: values.MessageQueueFilterSide || 'Client',
            DbGrayEnable: values.DbGrayEnable || false,
          }
        }).then(() => {
          onOk && onOk();
          if (updateFlag !== 'update') {
            handleCreateSwimminLaneGroup && handleCreateSwimminLaneGroup(true);
            setIsGrayscale(false);
          }
        });
      }
    });
    window.CN_TRACKER.send({ 
      name: 'grayscale-createLaneGroup-ok', 
      type:'mse-msc-grayscale'
    },{});
  };

  const handleClose = () => {
    reset();
    onClose && onClose();
    setEntryApplication(initPortalApplication);
    setIsGrayscale(false);
  };

  const handleVilidataAppIds = (rule, val, callback) => {
    // if (!val || find(val, item => !item.value)) {
    //   callback(intl('widget.k8s_gray.please_select_swimming_lang_group_application'));
    // }
    if (isEmpty(val)) {
      callback(intl('widget.k8s_gray.please_select_swimming_lang_group_application'));
    }
    callback();
  };

  const handleAhasEntryAppIdChange = (val) => {
    setValue('AhasIngreesAppId', val);
    let list = initList;
    list = filter(initList, (item) => item.AppId !== val);
    setEntryAppList(list);
  };
  const handleCloudPrimordiumEntryAppIdChange = (val) => {
    setValue('GatewayIngressAppId', val);
    let list = initList;
    list = filter(initList, (item) => item.AppId !== val);
    setEntryAppList(list);
  };
  const handleEntryAppIdChange = (val) => {
    let list = initList;
    list = filter(initList, (item) => item.AppId !== val);
    setEntryAppList(list);
  };
  const handleSwimmingGroupChange = (val) => {
    if (val?.length === 0) setSearchApp('');
    let list = initList;
    let ahasList = ahasInitList;
    // 旧版单个多选操作
    // forEach(val, (_t) => {
    //   list = filter(list, (item) => item.AppId !== _t.value);
    // });
    // 新版多选操作
    forEach(val, (_t) => {
      list = filter(list, (item) => item.AppId !== _t);
    });
    forEach(val, (_t) => {
      ahasList = filter(ahasList, (item) => item.armsPid !== _t);
    });
    setAppList(list);
    setAhasAppList(ahasList);
  };
  const handleSwimmingGroupSearch = (val) => {
    setSearchKey(val);
  };

  const handleCloudPrimordiumEntryAppNameSearch = (val) => {
    setSearchName(val);
  };
  const handleEntryAppIdSearch = (val, tag) => {
    setSearchApp(val);
    setSwimminLaneGroupTag(tag);
  };

  const initGatewayData = { value: 'ingress', label: <React.Fragment>{intl('widget.k8s_gray.swimming_lane_group_ingress')}<Balloon closable={false} trigger={<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} />}>{intl('widget.k8s_gray.swimming_lane_group_ingress.tips.doc')}</Balloon></React.Fragment> };
  // const initGatewayData = [{ value: 'Java', label: intl('widget.k8s_gray.swimming_lane_group_java_gateway_server'), defaultChecked: true }];
  // Java服务网关
  const JavaGateway = { value: 'Java', label: <React.Fragment>{intl('widget.k8s_gray.swimming_lane_group_java_gateway_server')}<Balloon closable={false} trigger={<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} />}>{intl.html('widget.k8s_gray.swimming_lane_group_java_gateway_server.tips.doc')}</Balloon></React.Fragment> };
  // ACk
  const AliCloudIngress = [{ value: 'AliCloudIngress', label: <React.Fragment>{intl('widget.msc.fulllink.grayscale.application.ack_nginx_ingress')}<Balloon closable={false} trigger={<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} />}>{intl.html('widget.msc.fulllink.grayscale.application.ack_nginx_ingress.tips_doc')}</Balloon></React.Fragment>, defaultChecked: aliyunSite !== 'INTL' }];
  // 阿里云Ingress网关
  const CloudPrimordium = { value: 'CloudPrimordium', label: <React.Fragment>{intl('widget.msc.fulllink.grayscale.application.mse.cloudprimordium')}<Balloon closable={false} trigger={<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} />}>{intl.html('widget.msc.fulllink.grayscale.application.mse.cloudprimordium.tips.doc')}</Balloon></React.Fragment> };
  // 消息灰度 队列过滤
  const initMessageQueueFilterSide = [{
    value: 'Client',
    label: (<span>
      <Balloon trigger={<span>{intl('widget.msc.message.grayscale.client.filter')}<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} /></span>} closable={false} >{intl('widget.msc.message.grayscale.client.filter.tips')}</Balloon></span>)
  }, {
    value: 'Server',
    label: (<span><Balloon trigger={<span>{intl('widget.msc.message.grayscale.service.filter')}<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} />{intl('widget.msc.message.grayscale.recommend')}</span>} closable={false} >{intl('widget.msc.message.grayscale.service.filter.tips')}</Balloon></span>)
  }];
  // 国际站兼容
  if (aliyunSite !== 'INTL') {
    AliCloudIngress.unshift(initGatewayData);
    AliCloudIngress.unshift(JavaGateway);
    AliCloudIngress.unshift(CloudPrimordium);
  }
  return (
    <SlidePanel
      title={
        <IconBack goBack={handleClose}>{intl(updateFlag === 'update' ? 'widget.k8s_gray.edit_swimming_lane_group_name' : 'widget.k8s_gray.create_swimming_lane_group_name')}</IconBack>
      }
      processingText={intl('widget.common.ok')}
      isShowing={visible}
      onOk={handleSubmit}
      onClose={handleClose}
      onCancel={handleClose}
      width={780}
    >
      <Form field={field}>
        <FormItem label={intl('widget.k8s_gray.swimming_lane_group_name')} required>
          <Input
            {...init('Name', {
              initValue: '',
              rules: [
                {
                  required: true,
                  message: intl('widget.k8s_gray.please_enter_swimmig_lane_group_name'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.common.name_pattern'),
                },
              ],
            })}
            placeholder={intl('widget.common.name_placeholder')}
            maxLength={64}
            minLength={1}
            showLimitHint
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem label={intl('widget.k8s_gray.entry_type')}>
          <Radio.Group
            {...init('EntryType', {
              initValue: 'ingress',
              rules: [
                {
                  required: true,
                },
              ],
              props: {
                onChange: (val) => {
                  setValue('EntryType', val);
                  setSearchKey('');
                  setSearchApp('');
                  if (val === 'Java') {
                    handleAhasEntryAppIdChange();
                    setEntryApplication('Java');
                  } else if (val === 'AliCloudIngress') {
                    // getAppList(val);
                    getAhasAppList()
                    handleEntryAppIdChange();
                    setEntryApplication('AliCloudIngress');
                  }
                  if (val === 'CloudPrimordium') {
                    getGatewayAppList()
                    handleEntryAppIdChange();
                    setEntryApplication('CloudPrimordium');
                  }
                  if (val === 'ingress') {
                    handleEntryAppIdChange();
                    handleAhasEntryAppIdChange();
                    setEntryApplication('ingress');
                  }
                }
              }
            })}
            // onChange={onhandleRedioChange}
            dataSource={AliCloudIngress}
            disabled={updateFlag === 'update'}
          />
        </FormItem>
        <If condition={entryApplication === 'AliCloudIngress'}>
          <FormItem label={intl('widget.k8s_gray.entry_application_title')} required>
            <Select
              {...init('AhasIngressAppId', {
                initValue: [],
                rules: [
                  {
                    required: true,
                    message: intl('widget.k8s_gray.please_select_application'),
                  },
                ],
                props: {
                  onChange: handleAhasEntryAppIdChange,
                  onSearch: handleSwimmingGroupSearch
                }
              })}
              showSearch
              filterLocal={false}
              style={{ width: '100%', marginTop: 4 }}
              dataSource={ahasAppList}
              placeholder={intl('widget.k8s_gray.select_link_related_to_the_application')}
            />
          </FormItem>
        </If>
        <If condition={entryApplication === 'CloudPrimordium'}>
          <FormItem>
            <Message type="warning">
              {intl('widget.fulllink.grayscale.gateway.cloud_primordium_msg')}
            </Message>
          </FormItem>
          <FormItem label={intl('widget.k8s_gray.entry_application_title')} required>
            <Select
              {...init('GatewayIngressAppId', {
                initValue: [],
                rules: [
                  {
                    required: true,
                    message: intl('widget.k8s_gray.please_select_application'),
                  },
                ],
                props: {
                  onChange: handleCloudPrimordiumEntryAppIdChange,
                  onSearch: handleCloudPrimordiumEntryAppNameSearch,
                  onFocus: () => { setSearchName(''); },
                }
              })}
              showSearch
              style={{ width: '95%', marginTop: 4 }}
              dataSource={gatewayAppList}
              filterLocal={false}
              placeholder={intl('widget.k8s_gray.select_link_related_to_the_application')}
            />
          </FormItem>
        </If>
        <If condition={entryApplication === 'Java'}>
          <FormItem label={intl('widget.k8s_gray.entry_application_title')} required>
            <Select
              {...init('EntryAppId', {
                initValue: [],
                rules: [
                  {
                    required: true,
                    message: intl('widget.k8s_gray.please_select_application'),
                  },
                  // {
                  //   validator: handleVilidataAppIds
                  // }
                ],
                props: {
                  onChange: handleEntryAppIdChange,
                  onSearch: (val) => handleEntryAppIdSearch(val, 'entrance'),
                  onFocus: () => { setSearchApp(''); },
                }
              })}
              showSearch
              style={{ width: '100%', marginTop: 4 }}
              // onChange={(val) => handleChange(item.uid, val)}
              dataSource={appList}
              filterLocal={false}
              // value={item.value}
              placeholder={intl('widget.k8s_gray.select_link_related_to_the_application')}
            />
          </FormItem>
        </If>
        <FormItem label={intl('widget.k8s_gray.swimming_lang_group_application')} required>
          {/* <AppIds //旧版本单选
            width="100%"
            {...init('AppIds', {
              initValue: [],
              rules: [
                {
                  required: true,
                  message: intl('widget.k8s_gray.please_select_swimming_lang_group_application'),
                },
                {
                  validator: handleVilidataAppIds
                }
              ],
              props: {
                onChange: handleSwimmingGroupChange
              }
            })}
            dataSource={entryAppList}
            placeholder={intl('widget.k8s_gray.select_link_related_to_the_application')}
            addText={intl('widget.k8s_gray.add_link_related_application')}
          /> */}
          <Select
            {...init('AppIds', {
              initValue: [],
              rules: [
                {
                  required: true,
                  message: intl('widget.k8s_gray.please_select_swimming_lang_group_application'),
                },
                {
                  validator: handleVilidataAppIds
                }
              ],
              props: {
                onChange: handleSwimmingGroupChange,
                onSearch: (val) => handleEntryAppIdSearch(val, 'swimminLaneGroup'),
              }
            })}
            style={{ width: '100%' }}
            dataSource={entryAppList}
            maxTagCount={15}
            showSearch
            filterLocal={false}
            mode="multiple"
            placeholder={intl('widget.k8s_gray.please_select_swimming_lang_group_involve_application')}
          />
        </FormItem>
        <If condition={aliyunSite !== 'INTL'}>
          {/* 采集请求详情 */}
          <FormItem label={<Balloon trigger={<span>{intl('widget.msc.message.grayscale.collection_request_details')}<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} /></span>} closable={false} >{intl('widget.msc.message.grayscale.collection_request_details_tips')}</Balloon>}>
            <Switch
              {...init('RecordCanaryDetail', {
                initValue: false,
                valueName: 'checked',
              })}
            />
          </FormItem>
          <FormItem label={<Balloon trigger={<span>{intl('widget.msc.message.grayscale.rocketmq_open_setting_hint')}<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} /></span>} closable={false} >{intl('widget.msc.message.grayscale.rocketmq_open_setting_tips')}</Balloon>}>
            <Switch
              {...init('MessageQueueGrayEnable', {
                initValue: false,
                valueName: 'checked',
                props: {
                  onChange: (val) => {
                    setIsGrayscale(val);
                  },
                },
              })}
            />
          </FormItem>
          <If condition={isGrayscale}>
            <FormItem label={intl('widget.msc.message.grayscale.filter_test')}>
              <Radio.Group
                {...init('MessageQueueFilterSide', {
                  initValue: 'Client',
                  // valueName: 'checked',
                })}
                dataSource={initMessageQueueFilterSide}
              />
            </FormItem>
          </If>
          <FormItem label={<span>{intl('widget.msc.message.grayscale.database')}</span>}>
            <Switch
              {...init('DbGrayEnable', {
                initValue: false,
                valueName: 'checked',
              })}
            />
          </FormItem>
        </If>
      </Form>
    </SlidePanel>
  );
};

EditForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
  updateFlag: PropTypes.string,
};

export default EditForm;
