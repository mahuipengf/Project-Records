import './RuleMarketSlideFile.less';
import React, { useEffect, useMemo, useState } from 'react';
import _, { isEmpty } from 'lodash';
import { Balloon, Checkbox, Icon, Input, Radio, Loading, Dialog, Message, Empty } from '@ali/cn-design';
import { useIntl, useGlobalState, useFeature } from '@ali/widget-hooks';
import services from 'services';
import { lowerFirstData } from 'utils/transfer-data';
import Status from 'components/Status/CommonStatus';
import DialogAlert from 'components/DialogAlert';
import { getParams } from 'utils';


// search原数据
let searchLangName = [];
let searchLangApp = [];
let searchNodeTag = [];
let searchFlowTag = [];

// 排序数组
let langArr = [];
let nameArr = [];

const RuleMarketContent = (props) => {
  const intl = useIntl();
  const [searchValues] = useGlobalState('searchValues');
  const { regionId: region } = searchValues;
  const { currentTime = [], groupId, groupList = [], refresh, tabkey } = props;
  const [startTime, endTime] = currentTime;
  const [loading, setLoading] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const ns = getParams('ns') || 'default';

  const [langNameDatasource, setLangNameDataSource] = useState([]);
  const [langAppDataSource, setLangAppDataSource] = useState([]);
  const [nodeTagDataSource, setNodeTagDataSource] = useState([]);
  const [flowTagDataSource, setFlowTagDataSource] = useState([]);
  const [checkeLangName, setCheckeLangName] = useState([]);
  const [checkedLangApp, setCheckedLangApp] = useState([]);
  const [radioNodeTag, setRadioNodeTag] = useState('');
  const [radioFlowTag, setRadioFlowTag] = useState('');

  const [filterData, setFilterData] = useState([]);
  const [isOpenXTrace, setIsOpenXTrace] = useState(false);

  const [isRecordCanaryDetail, setIsRecordCanaryDetail] = useState(false); // 是否开启请求采集详情

  useEffect(() => {
    setLoading(true);
    initXTraceRender();
    return () => {
      setIsLoading(false);
    };
  }, [refresh]);
  useEffect(() => {
    if (tabkey === 'details') {
      checkXTraceServiceStatus();
      getAllInterface();
      langArr = [];
      nameArr = [];
    }
  }, [groupId, groupList, refresh, tabkey]);

  const initXTraceRender = () => {
    setTimeout(() => {
      setIsLoading(true);
    }, 2000);
  };
  const getAllInterface = async () => {
    const [initLangAppArr] = await Promise.all([
      fetchSwimminLangList(),
      fetchQueryAllSwimmingLane(),
      featchGetTagsBySwimmingLaneGroupId(),
      fetchLangName(),
    ]);
    await getHandleFilterName([checkeLangName, initLangAppArr, radioNodeTag, radioFlowTag]);
  };
  const fetchSwimminLangList = async () => {
    if (groupId && !isEmpty(groupList)) {
      const swimminLaneGroupList = groupList.filter((item) => item?.id === groupId) || [];
      const swimminLaneGroupObj = _.head(swimminLaneGroupList) || {};
      const EntryApp = _.get(swimminLaneGroupObj, 'entryApp', 'ingress');
      const [EntryAppParams, EntryAppId] = EntryApp.split(':');
      let result = [];
      setIsRecordCanaryDetail(swimminLaneGroupObj?.RecordCanaryDetail || false);
      if (EntryAppParams === 'mse') {
        // 查询MSE列表数据
        const res = await services.GetApplicationDetail({
          params: {
            regionId: searchValues.regionId,
            pageNumber: 1,
            pageSize: 100,
            AppId: EntryAppId,
          }
        });
        result = [lowerFirstData(res)] || [];
      }
      const langAppList = _.map(swimminLaneGroupObj?.applicationList.concat(result), (item) => ({
        ...item,
        label: <Balloon closable={false} trigger={<span className="trace_sidebar-filter" style={{ maxWidth: '150px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{item.appName}</span>}>{item.appName}</Balloon>,
        value: item.appId,
        search: item.appName,
        Uid: _.uniqueId(),
      }));
      const initLangAppArr = [];
      if (langAppList.length > 0) {
        _.forEach(langAppList, (item, i) => {
          if (i === 0) {
            item.checked = true;
            langArr.push(item);
            initLangAppArr.push(item.appName);
            setCheckedLangApp([item.appName]);
          }
        });
      }
      searchLangApp = langAppList;
      setLangAppDataSource(langAppList);
      return initLangAppArr;
    }
  };
  const fetchQueryAllSwimmingLane = async () => {
    const data = await services.QueryAllSwimmingLane({
      params: { GroupId: groupId }
    });
    const flowTags = _.map(data, item => {
      return {
        value: item.tag,
        label: <Balloon closable={false} trigger={<span className="trace_sidebar-filter" style={{ maxWidth: '150px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{item.tag}</span>}>{item.tag}</Balloon>,
        key: item.tag,
        search: item.tag,
      };
    });
    flowTags.push({
      value: 'base',
      label: <Balloon closable={false} trigger={<span className="trace_sidebar-filter" style={{ maxWidth: '150px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>base</span>}>base</Balloon>,
      key: 'base',
      search: 'base',
    });
    searchFlowTag = flowTags;
    setFlowTagDataSource(flowTags);
    return flowTags;
  };

  const featchGetTagsBySwimmingLaneGroupId = async() => {
    const res = await services.GetTagsBySwimmingLaneGroupId({
      params: { GroupId: groupId }
    });
    const Tags = _.map(res, items => ({
      value: JSON.parse(items)[0].tag,
      label: <Balloon closable={false} trigger={<span className="trace_sidebar-filter" style={{ maxWidth: '150px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{JSON.parse(items)[0].tag}</span>}>{JSON.parse(items)[0].tag}</Balloon>,
      key: JSON.parse(items)[0].tag,
      search: JSON.parse(items)[0].tag,
    }));
    Tags.push({
      value: 'base',
      label: <Balloon closable={false} trigger={<span className="trace_sidebar-filter" style={{ maxWidth: '150px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>base</span>}>base</Balloon>,
      key: 'base',
      search: 'base',
    });
    searchNodeTag = Tags;
    setNodeTagDataSource(Tags);
  };

  const fetchLangName = async () => {
    const Data = await services.GetTagVal({
      params: {
        Region: region,
        StartTime: startTime || new Date().getTime() - (5 * 60 * 1000),
        EndTime: endTime || new Date().getTime(),
        TagKey: 'mse.interface.name',
      }
    });
    const Body = _.get(Data, 'Body', []);
    const TagValues = _.get(Body, 'TagValues', {});
    const TagValue = _.get(TagValues, 'TagValue', []).map((item) => ({ TagValue: item, Uid: _.uniqueId(), search: item }));
    searchLangName = TagValue;
    setLangNameDataSource(TagValue);
  };

  const handleClickShowSwimminLangDetails = async (record) => {
    const appList = await listAppBySwimmingLaneGroupTag(record.tag, record.groupId);
    const list = _.map(appList || [], item => item.appName);
    const val = _.head(JSON.parse(record.entryRule)) || {};
    const Exhibition = val.restItems && val.restItems.length > 0 && `${val.restItems[0].type}[${val.restItems[0].name}]${val.restItems[0].cond}${val.restItems[0].value}`;
    const other = val.restItems && val.restItems.length > 1 && `${val.restItems[1].type}[${val.restItems[1].name}]${val.restItems[1].cond}${val.restItems[1].value}`;
    Dialog.show({
      title: intl('widget.msc.fulllink.grayscale.swmming.details'),
      // eslint-disable-next-line jsx-control-statements/jsx-use-if-tag
      content: (<div style={{ width: '360px', lineHeight: '28px', marginTop: '-20px', fontSize: '12px' }}>
        <div>
          <span style={{ display: 'inline-block', width: '100px', textAlign: 'right' }}>{intl('widget.msc.fulllink.grayscale.swmming.lang.name')}</span>
          <span ><Balloon closable={false} trigger={<span className="trace_sidebar-filter" style={{ maxWidth: '150px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{record.name}</span>}>{record.name}</Balloon></span>
        </div>
        <div>
          <span style={{ display: 'inline-block', width: '100px', textAlign: 'right' }}>{intl('widget.msc.fulllink.grayscale.swmming.lang.tag')}</span>
          <span>{record.tag}</span>
        </div>
        <div>
          <span style={{ display: 'inline-block', width: '100px', textAlign: 'right' }}>{intl('widget.msc.fulllink.grayscale.swmming.lang.status')}</span>
          <span><Status value={record.enable} intl={intl} /></span>
        </div>
        <div style={{ whiteSpace: 'nowrap' }}>
          <span style={{ display: 'inline-block', width: '100px', textAlign: 'right' }}>{intl('widget.msc.fulllink.grayscale.swmming.lang.application')}</span>
          <span style={{ display: 'inline-block' }}><Balloon closable={false} trigger={<span className="trace_sidebar-filter" style={{ maxWidth: '230px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis', display: 'inline-block' }}>{list.join()}</span>}>{list.join()}</Balloon></span>
        </div>
        <div style={{ display: 'flex' }}>
          <span style={{ display: 'inline-block', width: '100px', textAlign: 'right' }}>{intl('widget.msc.fulllink.grayscale.swmming.lang.traffic.match.rules')}</span>
          <span style={{ display: 'inline-block' }}><Balloon
            trigger={(<span style={{ display: 'inline-block', width: 200, cursor: 'pointer', overflow: 'hidden', textOverflow: 'ellipsis', }}>
              <div>{intl('widget.service.condition')}：{val.condition || 'AND'}</div>
              <div style={{ width: 200, cursor: 'pointer', overflow: 'hidden', textOverflow: 'ellipsis' }}>{Exhibition} {other} <If condition={val.restItems && val.restItems.length > 2}>...</If></div>
            </span>)}
            align="t"
            closable={false}
          >
            <div style={{ width: 'auto' }}>
              <div>{intl('widget.service.condition')}：{val.condition || 'AND'}</div>
              <For each="items" index="index" of={val.restItems || []}>
                <div>
                  {`${items.type}[${items.name}]${items.cond}${items.value}`}
                </div>
              </For>
            </div>
          </Balloon></span>
        </div>
      </div>),
      okProps: { children: intl('widget.common.ok') },
      cancelProps: { children: intl('widget.common.cancel') },
      footerActions: ['ok', 'cancel'],
    });
  };

  const listAppBySwimmingLaneGroupTag = async(Tag, GroupId) => {
    const res = await services.ListAppBySwimmingLaneGroupTag({
      params: {
        Tag,
        GroupId,
      }
    });
    return res || [];
  };


  const handleSearch = (val, tag) => {
    if (tag === 'langName') {
      const searchData = searchLangName.filter(_t => _t.search.indexOf(val) !== -1);
      const sortData = sortCheckedSelect(searchData);
      setLangNameDataSource(sortData);
    }
    if (tag === 'langApp') {
      const searchData = searchLangApp.filter(_t => _t.search.indexOf(val) !== -1);
      const sortData = sortCheckedSelect(searchData);
      setLangAppDataSource(sortData);
    }
    if (tag === 'nodeTag') {
      const searchData = searchNodeTag.filter(_t => _t.search.indexOf(val) !== -1);
      const sortData = sortChecked(searchData, radioNodeTag);
      setNodeTagDataSource(sortData);
    }
    if (tag === 'flowTag') {
      const searchData = searchFlowTag.filter(_t => _t.search.indexOf(val) !== -1);
      const sortData = sortChecked(searchData, radioFlowTag);
      setFlowTagDataSource(sortData);
    }
  };

  const sortCheckedSelect = (payload) => { // 排序checkoed放最前
    const arr = [];
    if (payload.length > 0) {
      payload.forEach(_t => {
        if (_t.checked) {
          arr.unshift(_t);
        } else {
          arr.push(_t);
        }
      });
    }
    return arr;
  };

  const sortChecked = (payload, radioValue) => { // 排序checkoed放最前
    const arr = [];
    if (payload.length > 0) {
      payload.forEach(_t => {
        if (_t.value === radioValue) {
          arr.unshift(_t);
        } else {
          arr.push(_t);
        }
      });
    }
    return arr;
  };

  const handleRadioChange = (val, str) => {
    // if (str === 'langName') {
    //   setCheckeLangName(val);
    //   const sortData = sortChecked(langNameDatasource, val);
    //   setLangNameDataSource(sortData);
    //   getHandleFilterName([val, checkedLangApp, radioNodeTag, radioFlowTag]);
    // }
    // if (str === 'langApp') {
    //   setCheckedLangApp(val);
    //   const sortData = sortChecked(langAppDataSource, val);
    //   setLangAppDataSource(sortData);
    //   getHandleFilterName([checkeLangName, val, radioNodeTag, radioFlowTag]);
    // }
    if (str === 'nodeTag') {
      setRadioNodeTag(val);
      const sortData = sortChecked(nodeTagDataSource, val);
      setNodeTagDataSource(sortData);
      getHandleFilterName([checkeLangName, checkedLangApp, val, radioFlowTag]);
    }
    if (str === 'flowTag') {
      setRadioFlowTag(val);
      const sortData = sortChecked(flowTagDataSource, val);
      setFlowTagDataSource(sortData);
      getHandleFilterName([checkeLangName, checkedLangApp, radioNodeTag, val]);
    }
  };

  const getHandleFilterName = (payload) => {
    const [spanName, serviceName, appTag, Tag] = payload;
    const namesapce = `attributes.mse.namespace="${ns}"`;
    const servicename = serviceName && serviceName.length > 0 ? `+AND+serviceName IN ("${serviceName.join('"+,+"')}")` : '';
    const apptag = appTag ? serviceName.length > 0 ? `+AND+attributes.mse.app.tag IN ("${appTag}")` : `attributes.mse.app.tag IN ("${appTag}")` : '';
    const tag = Tag ? serviceName.length > 0 || appTag ? `+AND+attributes.mse.tag IN ("${Tag}")` : `attributes.mse.tag IN ("${Tag}")` : '';
    const spanname = spanName.length > 0 ? (serviceName.length > 0 || appTag || Tag ? `+AND+spanName IN ("${spanName.join('"+,+"')}")` : `spanName IN ("${spanName.join('"+,+"')}")`) : '';


    if (spanName || serviceName || appTag || Tag) {
      const filter = `${namesapce}${spanname}${servicename}${apptag}${tag}`;
      setFilterData(filter);
    } else {
      setFilterData(namesapce);
    }
  };
  const checkXTraceServiceStatus = async () => {
    const Data = await services.CheckXTraceServiceStatus({
      params: {
        Region: region,
      }
    });
    setIsOpenXTrace(Data);
  };
  const handleClickOpenTrace = () => {
    DialogAlert({
      title: intl('widget.common.tips.info'),
      content: (<div style={{ width: '400px', lineHeight: '18px' }}>
        {intl('widget.msc.fulllink.grayscale.xtrace.open.tips.info')}
      </div>),
      onOk: async () => {
        const Data = await services.OpenXTraceService({
          params: {
            Region: region,
          }
        });
        const { data: isSuccess } = Data;
        isSuccess && Message.success({ title: intl('widget.common.open.success'), duration: 3000 });
        !isSuccess && Message.warning({ title: intl('widget.common.open.error'), duration: 3000 });
        checkXTraceServiceStatus();
      },
      okProps: { children: intl('widget.common.ok') },
      cancelProps: { children: intl('widget.common.cancel') },
      footerActions: ['ok', 'cancel'],
      closeable: false,
    });
  };

  const renderEmpty = () => {
    setTimeout(() => {
      setLoading(false);
    }, 8000);
  };

  const langAppArr = [];
  const onChangeLangApp = (checked, uid) => {
    let obj;
    langAppDataSource.forEach((item) => {
      if (item.Uid === uid) {
        item.checked = checked;
        if (checked) {
          langArr.push(item);
          langAppArr.unshift(item);
        } else {
          obj = item;
        }
        langArr.length > 0 && langArr.forEach((_t) => {
          if (_t.Uid === uid) {
            if (!checked) {
              langArr = langArr.filter(items => items.Uid !== _t.Uid);
            }
          }
        });
      } else {
        langAppArr.push(item);
      }
    });
    if (obj) {
      langAppArr.push(obj);
    }
    const langAppNames = langArr.map(item => item.appName);
    setCheckedLangApp(langAppNames);
    getHandleFilterName([checkeLangName, langAppNames, radioNodeTag, radioFlowTag]);
    setLangAppDataSource(langAppArr);
  };

  const langNameArr = [];
  const onChangeLangName = (checked, uid) => {
    let obj;
    langNameDatasource.forEach((item) => {
      if (item.Uid === uid) {
        item.checked = checked;
        if (checked) {
          nameArr.push(item);
          langNameArr.unshift(item);
        } else {
          obj = item;
        }
        nameArr.length > 0 && nameArr.forEach((_t) => {
          if (_t.Uid === uid) {
            if (!checked) {
              nameArr = nameArr.filter(items => items.Uid !== _t.Uid);
            }
          }
        });
      } else {
        langNameArr.push(item);
      }
    });
    if (obj) {
      langNameArr.push(obj);
    }
    const tagValues = nameArr.map(item => item.TagValue);
    setCheckeLangName(tagValues);
    getHandleFilterName([tagValues, checkedLangApp, radioNodeTag, radioFlowTag]);
    setLangNameDataSource(langNameArr);
  };

  const renderComponent = useMemo(() => (
    <div className="microServiceInsightContent">
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>{intl('widget.msc.fulllink.grayscale.reqest.details.swmming.lang.application')}</span>
        </div>
        <div style={{ marginTop: '16px' }}>
          <Input
            placeholder={intl('widget.common.search.field.value')}
            innerBefore={
              <Icon type="search" style={{ margin: 4 }} />
              }
            onChange={(val) => handleSearch(val, 'langApp')}
          />
          <div style={{ maxHeight: '200px', paddingBottom: '12px', overflowY: langAppDataSource && langAppDataSource.length > 0 ? 'scroll' : 'visible', borderBottom: '2px solid rgb(51 53 41 / 17%)' }} className="style-scroll">
            {
              langAppDataSource && langAppDataSource.length > 0 ?  (
                langAppDataSource.map((item) => {
                  return (
                    <div className="rule-market-content" >
                      <div style={{ display: 'flex' }}>
                        <Checkbox
                          style={{ marginRight: 8, marginTop: 5 }}
                          checked={item?.checked}
                          onChange={(checked) => {
                            onChangeLangApp(checked, item.Uid);
                          }}
                        />
                        <Balloon closable={false} trigger={<div className="trace_sidebar-filter" style={{ maxWidth: '150px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{item.appName}</div>}>{item.appName}</Balloon>
                      </div>
                    </div>
                  );
                })
                // <Radio.Group
                //   style={{ display: 'block' }}
                //   className="rule-market-content"
                //   dataSource={langAppDataSource}
                //   value={radioLangApp}
                //   onChange={(val) => handleRadioChange(val, 'langApp')}
                //   direction="ver"
                // />
              ) : (
                <div style={{ maxHeight: '200px', overflowY: langAppDataSource && langAppDataSource.length > 0 ? 'scroll' : 'visible', borderBottom: '2px solid rgb(51 53 41 / 17%)' }} className="style-scroll">
                  <div style={{ minHeight: '200px', display: 'flex', justifyContent: 'center', marginTop: '16px' }}><Icon type="warning" size="xs" style={{ color: '#888' }} /><span style={{ color: '#888' }}>{intl('widget.common.no.match.value')}</span></div>
                </div>
              )
            }
          </div>
        </div>
      </div>
      <div style={{ marginTop: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>{intl('widget.msc.fulllink.grayscale.reqest.details.swmming.lang.flow.tag')} <Balloon closable={false} trigger={<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} />}>{intl('widget.msc.fulllink.grayscale.reqest.details.swmming.lang.flow.tag.tip')}</Balloon></span>
        </div>
        <div style={{ marginTop: '16px' }}>
          <Input
            placeholder={intl('widget.common.search.field.value')}
            innerBefore={
              <Icon type="search" style={{ margin: 4 }} />
              }
            onChange={(val) => handleSearch(val, 'flowTag')}
          />
          <div style={{ maxHeight: '200px', overflowY: flowTagDataSource && flowTagDataSource.length > 0 ? 'scroll' : 'visible', borderBottom: '2px solid rgb(51 53 41 / 17%)' }} className="style-scroll">
            {
              flowTagDataSource && flowTagDataSource.length > 0 ? (
                <Radio.Group
                  style={{ display: 'block' }}
                  className="rule-market-content"
                  dataSource={flowTagDataSource}
                  value={radioFlowTag}
                  onChange={(val) => handleRadioChange(val, 'flowTag')}
                  direction="ver"
                />
              ) : (
                <div style={{ maxHeight: '200px', overflowY: flowTagDataSource && flowTagDataSource.length > 0 ? 'scroll' : 'visible', borderBottom: '2px solid rgb(51 53 41 / 17%)' }} className="style-scroll">
                  <div style={{ minHeight: '200px', display: 'flex', justifyContent: 'center', marginTop: '16px' }}><Icon type="warning" size="xs" style={{ color: '#888' }} /><span style={{ color: '#888' }}>{intl('widget.common.no.match.value')}</span></div>
                </div>
              )
              }
          </div>
        </div>
      </div>
      <div style={{ marginTop: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>{intl('widget.msc.fulllink.grayscale.reqest.details.swmming.lang.tag')} <Balloon closable={false} trigger={<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} />}>{intl('widget.msc.fulllink.grayscale.reqest.details.swmming.lang.tag.tips')}</Balloon></span>
        </div>
        <div style={{ marginTop: '16px' }}>
          <Input
            placeholder={intl('widget.common.search.field.value')}
            innerBefore={
              <Icon type="search" style={{ margin: 4 }} />
              }
            onChange={(val) => handleSearch(val, 'nodeTag')}
          />
          <div style={{ maxHeight: '200px', overflowY: nodeTagDataSource && nodeTagDataSource.length > 0 ? 'scroll' : 'visible', borderBottom: '2px solid rgb(51 53 41 / 17%)' }} className="style-scroll">
            {
              nodeTagDataSource && nodeTagDataSource.length > 0 ? (
                <Radio.Group
                  style={{ display: 'block' }}
                  className="rule-market-content"
                  dataSource={nodeTagDataSource}
                  value={radioNodeTag}
                  onChange={(val) => handleRadioChange(val, 'nodeTag')}
                  direction="ver"
                />
              ) : (
                <div style={{ maxHeight: '200px', overflowY: nodeTagDataSource && nodeTagDataSource.length > 0 ? 'scroll' : 'visible', borderBottom: '2px solid rgb(51 53 41 / 17%)' }} className="style-scroll">
                  <div style={{ minHeight: '200px', display: 'flex', justifyContent: 'center', marginTop: '16px' }}><Icon type="warning" size="xs" style={{ color: '#888' }} /><span style={{ color: '#888' }}>{intl('widget.common.no.match.value')}</span></div>
                </div>
              )
            }
          </div>
        </div>
      </div>
      <div style={{ marginTop: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>{intl('widget.msc.fulllink.grayscale.swmming.lang')}</span>
        </div>
        <div style={{ marginTop: '16px' }}>
          <Input
            placeholder={intl('widget.common.search.field.value')}
            innerBefore={
              <Icon type="search" style={{ margin: 4 }} />
              }
            onChange={(val) => handleSearch(val, 'langName')}
          />
          <div style={{ maxHeight: '200px', paddingBottom: '12px', overflowY: langNameDatasource && langNameDatasource.length > 0 ? 'scroll' : 'visible', borderBottom: '2px solid rgb(51 53 41 / 17%)' }} className="style-scroll">
            {
              langNameDatasource && langNameDatasource.length > 0 ? (
                langNameDatasource.map((item) => {
                  return (
                    <div className="rule-market-content" >
                      <div style={{ display: 'flex' }}>
                        <Checkbox
                          style={{ marginRight: 8, marginTop: 5 }}
                          checked={item?.checked}
                          onChange={(checked) => {
                            onChangeLangName(checked, item.Uid);
                          }}
                        />
                        <Balloon closable={false} trigger={<div className="trace_sidebar-filter" style={{ maxWidth: '150px', overflow: 'hidden', whiteSpace: 'nowrap', textOverflow: 'ellipsis' }}>{item.TagValue}</div>}>{item.TagValue}</Balloon>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div style={{ maxHeight: '200px', overflowY: langNameDatasource && langNameDatasource.length > 0 ? 'scroll' : 'visible', borderBottom: '2px solid rgb(51 53 41 / 17%)' }} className="style-scroll">
                  <div style={{ minHeight: '200px', display: 'flex', justifyContent: 'center', marginTop: '16px' }}><Icon type="warning" size="xs" style={{ color: '#888' }} /><span style={{ color: '#888' }}>{intl('widget.common.no.match.value')}</span></div>
                </div>
              )
            }
          </div>
        </div>
      </div>
    </div>), [langNameDatasource, langAppDataSource, langAppDataSource, nodeTagDataSource, flowTagDataSource, currentTime]);
  return (
    <Loading visible={loading} style={{ width: 'calc(100vw - 256px)', height: 'calc(100vh - 150px)' }}>
      <If condition={!loading}>
        <If condition={!isOpenXTrace}>
          <Message type="notice" style={{ marginTop: '16px' }}>
            {intl('widget.msc.fulllink.grayscale.xtrace.open.message')}<span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={handleClickOpenTrace}>{intl('widget.common.please.open')}</span>
          </Message>
        </If>
        <If condition={isOpenXTrace}>
          <If condition={isRecordCanaryDetail}>
            <Message type="notice" style={{ marginTop: '16px' }}>
              {intl('widget.msc.fulllink.grayscale.xtrace.microservices.msg')}
            </Message>
          </If>
          <If condition={!isRecordCanaryDetail}>
            <Message type="notice" style={{ marginTop: '16px' }}>
              {intl.html('widget.msc.fulllink.grayscale.record_canary_detail.msg')}
            </Message>
          </If>
        </If>
      </If>
      <div style={{ display: 'flex' }}>
        <div style={{ marginTop: '16px', borderRight: '1px solid #eee', padding: '0px 16px', background: '#fff' }}>
          {renderComponent}
        </div>
        <div style={{ flex: 1, paddingLeft: '16px' }}>
          <If condition={isOpenXTrace && isLoading}>
            <iframe
              id="xTraceIframe"
              name="xTraceIframe"
              src={`https://arms.console.aliyun.com/?iframeMode=true&product=mse#/tracing/callChains/${region}?filters=${filterData}&partialMode=true&start=${startTime}&end=${endTime}`}
              width="100%"
              scrolling="auto"
              height="1100px"
              style={{ border: 'none', backgroundColor: '#fff', marginBottom: '16px' }}
              onLoad={() => setLoading(false)}
              key={refresh}
            />
          </If>
          <If condition={!isOpenXTrace}>
            {!isOpenXTrace && renderEmpty()}
            <Empty showIcon emptyMessage={<div>{intl('widget.msc.fulllink.grayscale.xtrace.open.message')}<span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={handleClickOpenTrace}>{intl('widget.common.please.open')}</span></div>} />;
          </If>
        </div>
      </div>
    </Loading>
  );
};

export default RuleMarketContent;
