import React, { useState, useEffect } from 'react';
import { Icon, Query, Loading, Empty, Pagination, Tab, Field, TimeContainer } from '@ali/cn-design';
import { Wcontainer, Wline } from '@alife/aisc-widgets';
import services from 'services';
import { forEach, find, isEmpty, forIn, get, replace, keys, map, filter } from 'lodash';
import RuleMarketContent from './RuleMarketContent';
import { aliyunSite } from 'utils';

const mapNumber = (value) => {
  if (typeof value === 'number') {
    if (value >= 1000) return `${Math.round(value / 100) / 10}k`;
    else return value;
  } else {
    return value;
  }
};
const mapPercent = (value, total) => `${Math.round(value / total * 1000) / 10}%`;
const SwimminLaneMonitorList = ({ handlePageStatus, groupId, intl, groupList }) => {
  const [upData, setUpData] = useState([]);
  const [total, setTotal] = useState(6);
  const [page, setPage] = useState(1);
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [tabkey, setTabKey] = useState('overview'); // overview
  const [currentTime, setCurrentTime] = useState([0, 0]);
  const [refresh, setRefresh] = useState(0);


  const field = Field.useField();
  const { init, getValue } = field;


  useEffect(() => {
    let interval;
    if (!interval) {
      interval = setInterval(() => {
        setRefreshIndex(Date.now());
      }, 10000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [groupId, groupList]);

  useEffect(() => {
    const { value = [] } = getValue('time') || {};
    setCurrentTime(value);
    setRefreshIndex(Date.now());
  }, [getValue('time')]);

  const fetchQueryAppListMetrics = async() => {
    const [startTime, endTime] = currentTime;
    const data = find(groupList, { id: groupId }) || [];
    const res = await services.QueryAppListMetrics({
      params: {
        GroupId: groupId,
        StartTime: startTime || new Date().getTime() - (5 * 60 * 1000),
        EndTime: endTime || new Date().getTime(),
        PageSize: 6,
        PageNumber: page,
      }
    });
    const MseAppMetricsMap = get(res, 'MseAppMetricsMap', []);
    const TotalSize = get(res, 'TotalSize', 1);
    const PageNumber = get(res, 'PageNumber', 1);
    if (!isEmpty(data.applicationList) && res) {
      const curData = [];
      forIn(MseAppMetricsMap || {}, (val) => {
        const WlineData = [
          { name: intl('widget.home.total_count'), key: 'Qps', data: [] },
          { name: intl('widget.msc.throw_name', { name: 'QPS' }), key: 'ExpQps', data: [] },
        ];
        forEach(data.applicationList || [], _n => {
          if (_n.appId === val.AppId) {
            WlineData.push({ appName: _n.appName });
          }
        });
        const CurMetricsFm = {
          ExpQps: get(val, 'CurMetrics_5m.ExpQps', 0),
          Qps: get(val, 'CurMetrics_5m.Qps', 0),
          TagValues: get(val, 'CurMetrics_5m.TagValues', {}),
        };
        forEach(val.CurMetrics || [], d => {
          forIn(d.TagValues || {}, (tag, key) => {
            if (!find(WlineData, { key })) {
              WlineData.push({ name: key === 'null' ? intl('widget.app.canary_no_tag') : key, key, data: [] });
              WlineData.push({ name: intl('widget.msc.throw_name', { name: key }), key: `exp_${intl('widget.app.canary_no_tag')}`, data: [] });
            }
          });
          const Time = d.Timestamp;
          forEach(WlineData, item => {
            if (d[item.key] === 0 || d[item.key] || d[item.key] === null) {
              if (d[item.key] === -1) return item.data.push([Time, undefined]);
              else return item.data.push([Time, Number(d[item.key])]);
            } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[item.key])) {
              if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.TagValues[item.key].Qps)]);
              else return item.data.push([Time, d.TagValues[item.key].Qps]);
            } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[replace(item.key, 'exp_', '')])) {
              if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.tagValues[replace(item.key, 'exp_', '')].ExpQps)]);
              else return item.data.push([Time, d.TagValues[replace(item.key, 'exp_', '')].ExpQps]);
            }
          });
        });
        curData.push({ WlineData, CurMetricsFm });
      });
      setTotal(TotalSize);
      setUpData(curData);
      setPage(PageNumber);
      return curData;
    } else {
      setUpData([]);
      return [];
    }
  };
  const options = {
    xAxis: {
      mask: 'HH:mm',
    },
    yAxis: [
      {
        min: 0,
        labelFormatter: (value) => {
          if (value >= 1000) return `${(value / 1000).toFixed(1)}k`;
          else return value;
        }
      },
    ],
    legend: {
      position: 'bottom',
      align: 'center',
    },
    tooltip: {
      valueFormatter: (value, data, index, rawData) => {
        if (index === 0) return value || 0;
        const item = find(rawData, { name: intl('widget.home.total_count') });
        if (!item) {
          return value || 0;
        }
        return `${value} (${mapPercent(value || 0, item.value || 0)})`;
      },
    }
  };
  const currentPage = (val) => {
    setPage(val);
    setRefreshIndex(Date.now());
  };

  const tabs = [
    {
      title: intl('widget.msc.fulllink.grayscale.request_overview'),
      key: 'overview',
      visible: true,
    },
    {
      title: intl('widget.msc.fulllink.grayscale.record_canary_detail'),
      key: 'details',
      visible: aliyunSite !== 'INTL',
    },
  ];

  const handleChangeTagKey = (val) => {
    setTabKey(val);
  };

  const handleRefresh = () => {
    setRefresh(Date.now());
    if (tabkey === 'overview') {
      setRefreshIndex(Date.now());
    }
  };
  return (
    <Loading visible={false} inline={false} >
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex' }}>
          <Icon type="wind-arrow-left" size="large" style={{ cursor: 'pointer' }} onClick={() => handlePageStatus(true)} />
          <Tab onChange={handleChangeTagKey}>
            {
              map(filter(tabs, item => item.visible), item => <Tab.Item title={item.title} key={item.key} />)
            }
          </Tab>
        </div>
        <div>
          <If condition={tabkey === 'details'}>
            <Icon type="refresh" size="small" style={{ marginRight: '8px', cursor: 'pointer' }} onClick={handleRefresh} />
            <TimeContainer
              {...init('time', {
                initValue: 'last_5_minutes',
              })}
              useLoop={false}
            />
          </If>
        </div>
      </div>
      <If condition={tabkey === 'overview'}>
        <Query fetchData={fetchQueryAppListMetrics} refreshIndex={refreshIndex} >
          {({ data = [], loading }) => (
            <div>
              <If condition={isEmpty(data)}>
                <Loading visible={loading} inline={false}>
                  <Empty showIcon value={[]} />
                </Loading>
              </If>
              <If condition={!isEmpty(data)}>
                <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                  <For index="index" each="item" of={data}>
                    <div
                      style={{ padding: 16, margin: '8px 8px 8px 0px', borderRadius: 4, border: '1px solid #eee', width: '48%', boxShadow: '0 1px 4px 0 rgb(0 0 0 / 13%)' }}
                    >
                      <div style={{ border: '1px solid #eee', boxShadow: '0 0 5px #eee', padding: '8px 16px 0 16px' }}>
                        <For index="index" each="_t" of={item.WlineData}>
                          <If condition={_t.appName}>
                                  <div style={{ color: '#000', fontSize: '16px', fontWeight: 'bold' }}>{_t.appName}</div>
                                </If>
                        </For>
                        <div style={{ display: 'flex', }}>
                          <div style={{ borderRight: '1px solid #eee', width: 160, minWidth: 160, marginRight: 16, marginBottom: 8, padding: '8px 16px 0 0' }}>
                                  <div style={{ color: '#777', marginBottom: 8 }}>{intl('widget.home.error_count_total_count')}</div>
                                  <span style={{ fontSize: 18, paddingRight: 2, color: get(item.CurMetricsFm, 'ExpQps', 0) === 0 ? '' : 'red' }}>{get(item.CurMetricsFm, 'ExpQps', 0) === -1 ? 0 : mapNumber(get(item.CurMetricsFm, 'ExpQps', 0))}</span>
                                  /
                          <span style={{ paddingLeft: 2 }}>{mapNumber(get(item.CurMetricsFm, 'Qps', 0))}</span>
                                </div>
                          <div style={{ display: 'flex', padding: '8px 16px 0 0', overflowX: 'scroll', }}>
                                  <If condition={!isEmpty(get(item.CurMetricsFm, 'TagValues', {}))}>
                            <For index="index" each="_d" of={keys(get(item.CurMetricsFm, 'TagValues', {}))}>
                              <div key={index} style={{ display: 'inline-block', width: 100, minWidth: 100 }}>
                                <div style={{ color: '#777', marginBottom: 8 }}>{_d === 'null' ? intl('widget.app.canary_no_tag') : _d}</div>
                                <span style={{ fontSize: 18, paddingRight: 2, color: mapNumber(item.CurMetricsFm.TagValues[_d].ExpQps) === 0 ? '' : 'red' }}>{mapNumber(item.CurMetricsFm.TagValues[_d].ExpQps || 0)}</span>
                                /
                                  <span style={{ paddingLeft: 2 }}>{mapNumber(item.CurMetricsFm.TagValues[_d].Qps)}</span>
                              </div>
                            </For>
                          </If>
                                  <If condition={isEmpty(get(item.CurMetricsFm, 'TagValues', {}))}>
                            <div style={{ textAlign: 'center' }}>{intl('widget.common.no_data')}</div>
                          </If>
                                </div>
                        </div>
                      </div>
                      <If condition={item.WlineData[0].key === 'Qps' && !isEmpty(item.WlineData[0].data)}>
                        <div style={{ marginTop: '16px' }}>
                          <Wcontainer >
                                  <Wline
                            height={300}
                            config={options}
                            data={item.WlineData}
                          />
                                </Wcontainer>
                        </div>
                      </If>
                      <If condition={item.WlineData[0].key === 'Qps' && isEmpty(item.WlineData[0].data)}>
                        <Empty showIcon value={[]} />
                      </If>
                    </div>
                  </For>
                  <If condition={!isEmpty(data)}>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', width: '100%', marginRight: '40px' }}>
                      <Pagination shape="no-border" type="simple" onChange={currentPage} currentPage={page} pageSize={6} total={total} />
                    </div>
                  </If>
                </div>
              </If>
            </div>
          )}
        </Query>
      </If>
      <If condition={tabkey === 'details'}>
        <RuleMarketContent groupId={groupId} groupList={groupList} currentTime={currentTime} refresh={refresh} tabkey={tabkey} />
      </If>
    </Loading>

  );
};
export default SwimminLaneMonitorList;
