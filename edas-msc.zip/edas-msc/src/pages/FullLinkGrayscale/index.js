import FullLinkGrayscalekHome from './FullLinkGrayscaleHome';

export default FullLinkGrayscalekHome;
