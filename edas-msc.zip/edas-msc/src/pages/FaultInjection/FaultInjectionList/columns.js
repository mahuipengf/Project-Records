import React from 'react';
import { CopyContent, Empty } from '@ali/cn-design';
import Status from 'components/Status/CommonStatus';
import { Dubbo, SpringCloud, Istio } from 'components/Icon';
import { timeFmt } from 'utils';
import Events from './Events';

const ICON = {
  DUBBO: <Dubbo />,
  SPRING_CLOUD: <SpringCloud />,
  istio: <Istio />,
};

const columns = (intl, handleEdit, setFetchDataTime) => {

  const PROTOCOL_TYPE = {
    'istio': intl('widget.service.service_mesh')
  };

  const FAULT_TYPE = {
    'abort': intl('widget.fault_injection.abort_type'),
    'delay': intl('widget.fault_injection.delay_type')
  };

  return [
    {
      key: 'name',
      title: intl('widget.fault_injection.rule_name'),
      dataIndex: 'name',
      width: 120,
      cell: value => (
        <CopyContent text={value}>
          <Empty value={value}>{value}</Empty>
        </CopyContent>
      ),
    },
    {
      key: 'enable',
      title: intl('widget.common.state'),
      dataIndex: 'enable',
      width: 80,
      cell: value => <Status value={value} intl={intl} />
    },
    {
      key: 'protocol',
      title: intl('widget.fault_injection.protocol_type'),
      dataIndex: 'protocol',
      width: 100,
      cell: value => (
        <Empty value={value}>
          <div style={{ display: 'flex' }}>
            {ICON[value]}
            <span>{PROTOCOL_TYPE[value]}</span>
          </div>
        </Empty>
      ),
    },
    {
      key: 'appName',
      title: intl('widget.fault_injection.app'),
      dataIndex: 'appName',
      width: 120,
      cell: value => (
        <Empty value={value}>{value}</Empty>
      ),
    },
    {
      key: 'tag',
      title: intl('widget.fault_injection.tag'),
      dataIndex: 'tag',
      width: 60,
      cell: value => (
        <Empty value={value}>{value}</Empty>
      ),
    },
    {
      key: 'sourceLabels',
      title: intl('widget.fault_injection.traffic_sources'),
      dataIndex: 'routeRules',
      width: 120,
      cell: value => {
        const text = value && value[0].sourceLabels ? value[0].sourceLabels.join() : undefined;
        return (
          <Empty value={text}>{text}</Empty>
        );
      },
    },
    {
      key: 'faultType',
      title: intl('widget.fault_injection.fault_type'),
      dataIndex: 'routeRules',
      width: 80,
      cell: value => {
        const faultType = value && value[0] ? value[0].faultType : undefined;
        return (
          <Empty value={FAULT_TYPE[faultType]}>{FAULT_TYPE[faultType]}</Empty>
        );
      },
    },
    {
      key: 'percentage',
      title: intl('widget.fault_injection.percentage'),
      dataIndex: 'routeRules',
      width: 80,
      cell: value => {
        const percentage = value && value[0] ? value[0].percentage : undefined;
        return (
          <Empty value={percentage}>{percentage}%</Empty>
        );
      },
    },
    {
      key: 'config',
      title: intl('widget.fault_injection.config'),
      dataIndex: 'routeRules',
      width: 140,
      cell: value => {
        const rule = value && value[0] ? value[0] : undefined;
        if (!rule || !rule.config || !rule.faultType) {
          return <>---</>;
        }
        let intlKey = '';
        let config = rule.config + '';
        if (rule.faultType === "delay") {
          config = rule.config.split(":")[1] || '-';
          intlKey = "widget.fault_injection.delay_config";
        } else {
          intlKey = "widget.fault_injection.abort_config";
        }
        const configText = intl(intlKey, { config });
        return (
          <Empty value={configText}>{configText}</Empty>
        );
      },
    },
    {
      key: 'gmtModified',
      title: intl('widget.fault_injection.modified_date'),
      dataIndex: 'gmtModified',
      width: 160,
      cell: value => <Empty value={value}>{timeFmt(value, 'YYYY-MM-DD HH:mm:ss')}</Empty>
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      width: 100,
      cell: (value, index, record) => (
        <Events record={record} handleEdit={() => handleEdit(record)} setFetchDataTime={setFetchDataTime} />
      ),
    },
  ];
};

export default columns;