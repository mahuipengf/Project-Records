import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, modelDecorator, Button } from '@ali/cn-design';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { map, isEmpty } from 'lodash';
import { lowerFirstData } from 'utils/transfer-data';
import EditForm from './components/EditForm';
import columns from './columns';
import styles from './index.less';

function FaultInjectionList(props) {
  const { tableUniqueKey, toggleModal } = props;
  const [isCanCustomColumns] = useState(true);
  const [isCanMultipleSearch] = useState(true);
  const [isCanRefresh] = useState(true);
  const [isAutoAddSorted] = useState(true);
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const [appList, setAppList] = useGlobalState('appList');
  const [searchValues] = useGlobalState('searchValues');
  const [autoFetch, setAutoFetch] = useState(false);
  const editForm = useRef(null);
  const intl = useIntl();
  const { regionId, namespaceId } = searchValues;
  const currentAppList = [];
  const defaultValue = {
    protocol: searchValues.protocol || 'istio',
    enable: true,
  };

  useEffect(() => {
    fetchAppList({ regionId, namespaceId, pageNumber: 1, pageSize: 50 });
  }, []);

  // 这个是分页接口，但是需要拿到全部数据
  const fetchAppList = async ({ regionId: RegionId, namespaceId: NamespaceId, pageNumber, pageSize }) => {
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      const { data = [] } = await services.GetAppList({
        params: { regionId: RegionId, namespaceId: NamespaceId }
      });
      const newData = map(data, item => ({
        ...item,
        key: item.appId,
        value: item.appId,
        label: item.appName,
      }));
      setAppList(newData);
      if (!autoFetch) {
        setAutoFetch(true);
      }
      return;
    }
    const res = await services.GetAppList({ params: { regionId: RegionId, pageNumber, pageSize } });
    const { result = [] } = lowerFirstData(res) || {};
    const newData = map(result, item => ({
      ...item,
      key: item.appId,
      value: item.appId,
      label: item.appName,
    }));
    currentAppList.push(...newData);
    if (result.length && result.length === pageSize) {
      fetchAppList({ regionId, pageNumber: pageNumber + 1, pageSize })
    } else {
      setAppList(currentAppList);
      if (!autoFetch) {
        setAutoFetch(true);
      }
    }
  };

  const fetchData = async (params) => {
    const res = await services.fetchFaultInjectionPolicy({
      params: {
        ...params,
        protocol: params.protocol || undefined,
        region: regionId,
        namespaceId
      }
    });
    const { result: List = [], results: NewList = [], totalSize: TotalCount } = lowerFirstData(res) || {};
    return {
      Data: isEmpty(List) ? NewList : List,
      TotalCount,
    };
  };

  const searchs = {
    typeInfo: {
      types: [
        { value: '', label: intl('widget.fault_injection.all_frame') },
        { value: 'istio', label: intl('widget.service.service_mesh') }
      ],
      defaultValue: searchValues.protocol || '',
      value: 'protocol',
    },
    filterInfo: {
      filters: [
        {
          label: intl('widget.fault_injection.rule_name'),
          value: 'name',
          placeholder: intl('widget.fault_injection.rule_name_placeholder')
        },
        {
          label: intl('widget.fault_injection.app'),
          value: 'appId',
          mode: 'select',
          dataSource: [
            { label: intl('widget.fault_injection.all_app'), value: '' },
            ...appList
          ],
        },
      ],
      defaultValue: 'name',
    },
    isCanCustomColumns,
    isCanMultipleSearch,
    tableUniqueKey,
    isCanRefresh,
  };

  const handleEdit = (record = defaultValue) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl(record.id ? 'widget.fault_injection.edit_rule_title' : 'widget.fault_injection.create_rule_title'),
      content: (
        <EditForm
          ref={editForm}
          value={record}
          setRefreshIndex={setFetchDataTime}
        />
      ),
      onConfirm: () => editForm.current.handleSubmit(),
    });
  };

  return (
    <div className={styles.tableContainer}>
      <TableContainer
        fixedHeader
        autoFetch={autoFetch}
        fetchData={fetchData}
        primaryKey="id"
        columns={columns(intl, handleEdit, setFetchDataTime)}
        search={searchs}
        refreshIndex={fetchDataTime}
        affixActionBar
        isUseStorage={MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas'}
        sortConfig={{
          isAutoAddSorted,
        }}
        operation={() => (
          <Button type="primary" onClick={() => handleEdit()}>
            {intl('widget.fault_injection.create_rule')}
          </Button>
        )}
        emptyContent={
          <div >
            <Actions expandTriggerType="hover" style={{ justifyContent: 'center' }}>
              <LinkButton
                key="1"
                onClick={() => handleEdit()}
              >
                {intl('widget.fault_injection.no_data_go_create')}
              </LinkButton>
            </Actions>
          </div>
        }
      />
    </div>
  );
}

FaultInjectionList.propTypes = {
  toggleModal: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default modelDecorator(FaultInjectionList);
