import React from 'react';
import PropTypes from 'prop-types';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { WIDGET_ID } from 'constants';
import { modelDecorator } from '@ali/cn-design';
import { assign } from 'lodash';
import MethodTest from './components/MethodTest';

const Events = ({ record, children, emitName, toggleModal }) => {
  const [searchValues] = useGlobalState('searchValues');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const { serviceType, regionId, namespaceId, origin } = searchValues;
  const { group: serviceGroup, version: serviceVersion, serviceName, edasAppId: appId, serviceId, registryType } = record;
  const newRecord = {
    serviceType,
    regionId,
    namespaceId,
    origin,
    appId,
    serviceGroup,
    serviceVersion,
    serviceName,
    serviceId,
    registryType,
  };
  const intl = useIntl();


  const handleGoAppInfo = () => {
    const { searchType, searchValue: searchValue1, ip } = searchValues;
    const values = assign(
      { serviceType, searchType, searchValue: searchValue1, origin, ip },
      { ...record, appId: record.edasAppId },
      { regionId, namespaceId }
    );
    eventEmitter.emit(emitName, values);
  };

  const handleMethodTest = () => {
    const value = newRecord;
    // console.log('调用路由，去新页面');
    // toggleModal({
    //   type: 'slide',
    //   visible: true,
    //   size: 'xl',
    //   title: intl('widget.service.select_test_method'),
    //   content: (
    //     <MethodTest value={newRecord} />
    //   ),
    // });
    // 调用路由，去新页面
    eventEmitter.emit(`${WIDGET_ID}:go-to-MethodTestPage`, value);
  };
  return (
    <React.Fragment>
      <If condition={!emitName}>
        <span className="link-primary" onClick={handleMethodTest}>{children}</span>
      </If>
      <If condition={emitName}>
        <span className="link-primary" onClick={handleGoAppInfo}>{children}</span>
      </If>
    </React.Fragment>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  children: PropTypes.string,
  emitName: PropTypes.string,
};

export default modelDecorator(Events);
