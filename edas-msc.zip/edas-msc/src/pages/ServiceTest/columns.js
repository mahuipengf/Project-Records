import React from 'react';
import { Empty, CopyContent } from '@ali/cn-design';
import Events from './Events';
import { WIDGET_ID, MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE } from 'constants';
import './index.less';

const SPRING_CLOUD = 'springCloud';

const columns = (intl, type) => {
  let column = [
    {
      key: 'serviceName',
      title: intl('widget.service.service_name'),
      dataIndex: 'serviceName',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <Events record={record}>
            {record.serviceName}
          </Events>
        </CopyContent>
      ),
    },
    {
      key: 'version',
      title: intl('widget.service.version'),
      dataIndex: 'version',
      cell: value => <Empty value={value}>{value}</Empty>,
    },
    {
      key: 'group',
      title: intl('widget.service.group'),
      dataIndex: 'group',
      cell: value => (
        <Empty value={value}>
          {value}
        </Empty>
      ),
    },
    {
      key: 'edasAppName',
      title: intl('widget.service.app_name'),
      dataIndex: 'edasAppName',
      cell: (value, index, record) => (
        <Empty value={value}>
          <CopyContent text={value}>
            <If condition={!record.edasAppId || MSC_WIDGET_CONSOLE_CONFIG.productName === 'mse'}>
              {record.edasAppName}
            </If>
            <If condition={record.edasAppId && MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
              <If condition={!!record.edasAppId}>
                <Events record={record} emitName={`${WIDGET_ID}:go-to-appInfo`}>
                  {record.edasAppName}
                </Events>
              </If>
            </If>
          </CopyContent>
        </Empty>
      ),
    },
    {
      key: 'instanceNum',
      title: intl('widget.service.instance_number'),
      dataIndex: 'instanceNum',
      cell: value => <Empty value={value}>{value}</Empty>,
    },
  ];
  if (type === SPRING_CLOUD) {
    column = [
      {
        key: 'serviceName',
        title: intl('widget.service.service_name'),
        dataIndex: 'serviceName',
        cell: (value, index, record) => (
          <CopyContent text={value}>
            <Events record={record}>
              {record.serviceName}
            </Events>
          </CopyContent>
        ),
      },
      {
        key: 'edasAppName',
        title: intl('widget.service.app_name'),
        dataIndex: 'edasAppName',
        cell: (value, index, record) => (
          <Empty value={value}>
            <CopyContent text={value}>
              <If condition={!record.edasAppId || MSC_WIDGET_CONSOLE_CONFIG.productName === 'mse'}>
                {record.edasAppName}
              </If>
              <If condition={record.edasAppId && MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
                <If condition={!!record.edasAppId}>
                  <Events record={record} emitName={`${WIDGET_ID}:go-to-appInfo`}>
                    {record.edasAppName}
                  </Events>
                </If>
              </If>
            </CopyContent>
          </Empty>
        ),
      },
      {
        key: 'instanceNum',
        title: intl('widget.service.instance_number'),
        dataIndex: 'instanceNum',
        cell: value => <Empty value={value}>{value}</Empty>,
      },
    ];
  }
  if (!IS_ENV_PRIVATE) {
    column.push({
      key: 'remark',
      title: intl('widget.common.operating'),
      dataIndex: 'remark',
      cell: (value, index, record) => (
        <Events record={record}>
          {intl('widget.service.test')}
        </Events>
      ),
    });
  }
  return column;
};

export default (intl, type) => columns(intl, type);
