import React, { useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { useIntl } from '@ali/widget-hooks';
import { Loading } from '@alicloud/console-components';
import PropTypes from 'prop-types';
import services from 'services';
import { concat, isEmpty } from 'lodash';
import { jsonStringify, lowerFirstData } from 'utils/transfer-data';
import { MultiLines } from '@alicloud/console-components-truncate';
import { Empty } from '@ali/cn-design';
import './index.less';

const jsonParse = (value) => {
  try {
    return JSON.parse(value);
  } catch (err) {
    return value;
  }
};

const Record = (props, ref) => {
  const intl = useIntl();
  const { value = {}, handleEcho } = props;
  const [loading, setLoading] = useState(false);
  const { regionId, namespaceId, serviceType, appId, serviceName, serviceVersion, serviceGroup } = value;

  const [historys, setHistorys] = useState([]);
  const [loadMore, setLoadMore] = useState({ pageNumber: 1, pageSize: 50 });

  useImperativeHandle(ref, () => ({
    fetchLastHistory,
  }));

  useEffect(() => {
    fetchTestHistorys();
  }, [loadMore]);

  const fetchTestHistorys = async () => {
    if (serviceType === 'dubbo') {
      const params = {
        region: regionId,
        namespace: namespaceId,
        objectId: namespaceId ? `dubbo:${namespaceId}:${appId}:${serviceName}:${serviceGroup}:${serviceVersion}` : `dubbo:${appId}:${serviceName}:${serviceGroup}:${serviceVersion}`,
        pageNumber: loadMore.pageNumber,
        pageSize: loadMore.pageSize
      };
      setLoading(true);
      const data = await services.fetchTestHistorys({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const res = lowerFirstData(data || []) || [];
      setHistorys(concat(historys, res));
      setLoading(false);
      if (res.length && res.length === loadMore.pageSize) {
        setLoadMore({ ...params, pageNumber: loadMore.pageNumber + 1 });
      }
    } else if (serviceType === 'springCloud') {
      const params = {
        region: regionId,
        namespace: namespaceId,
        objectId: namespaceId ? `springCloud:${namespaceId}:${appId}` : `springCloud:${appId}`,
        pageNumber: loadMore.pageNumber,
        pageSize: loadMore.pageSize
      };
      setLoading(true);
      const data = await services.fetchTestHistorys({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const res = lowerFirstData(data || []) || [];
      setHistorys(concat(historys, res));
      setLoading(false);
      if (res.length && res.length === loadMore.pageSize) {
        setLoadMore({ ...params, pageNumber: loadMore.pageNumber + 1 });
      }
    } else if (serviceType === 'istio') {
      const params = {
        region: regionId,
        namespace: namespaceId,
        objectId: namespaceId ? `istio:${namespaceId}:${appId}` : `istio:${appId}`,
        pageNumber: loadMore.pageNumber,
        pageSize: loadMore.pageSize
      };
      setLoading(true);
      const data = await services.fetchTestHistorys({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const res = lowerFirstData(data || []) || [];
      setHistorys(concat(historys, res));
      setLoading(false);
      if (res.length && res.length === loadMore.pageSize) {
        setLoadMore({ ...params, pageNumber: loadMore.pageNumber + 1 });
      }
    } else if ( serviceType === 'hsf' ) {
      const params = {
        region: regionId,
        namespace: namespaceId,
        objectId: `hsf:${appId}`,
        pageNumber: loadMore.pageNumber,
        pageSize: loadMore.pageSize
      };
      setLoading(true);
      const data = await services.fetchTestHistorys({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const res = lowerFirstData(data || []) || [];
      setHistorys(concat(historys, res));
      setLoading(false);
      if (res.length && res.length === loadMore.pageSize) {
        setLoadMore({ ...params, pageNumber: loadMore.pageNumber + 1 });
      }
    }
  };

  const fetchLastHistory = async () => {
    if (serviceType === 'dubbo') {
      const params = {
        region: regionId,
        namespace: namespaceId,
        objectId: namespaceId ? `dubbo:${namespaceId}:${appId}:${serviceName}:${serviceGroup}:${serviceVersion}` : `dubbo:${appId}:${serviceName}:${serviceGroup}:${serviceVersion}`,
        pageNumber: 1,
        pageSize: 1
      };
      setLoading(true);
      const data = await services.fetchTestHistorys({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const res = lowerFirstData(data || []) || [];
      const currentHistorys = concat(res, historys);
      setHistorys(currentHistorys);
      setLoading(false);
    } else if (serviceType === 'springCloud') {
      const params = {
        region: regionId,
        namespace: namespaceId,
        objectId: namespaceId ? `springCloud:${namespaceId}:${appId}` : `springCloud:${appId}`,
        pageNumber: 1,
        pageSize: 1
      };
      setLoading(true);
      const data = await services.fetchTestHistorys({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const res = lowerFirstData(data || []) || [];
      const currentHistorys = concat(res, historys);
      setHistorys(currentHistorys);
      setLoading(false);
    } else if (serviceType === 'istio') {
      const params = {
        region: regionId,
        namespace: namespaceId,
        objectId: namespaceId ? `istio:${namespaceId}:${appId}` : `istio:${appId}`,
        pageNumber: 1,
        pageSize: 1
      };
      setLoading(true);
      const data = await services.fetchTestHistorys({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const res = lowerFirstData(data || []) || [];
      const currentHistorys = concat(res, historys);
      setHistorys(currentHistorys);
      setLoading(false);
    } else if(serviceType === 'hsf') {
      const params = {
        region: regionId,
        namespace: namespaceId,
        objectId: `hsf:${appId}`,
        pageNumber: 1,
        pageSize: 1
      };
      setLoading(true);
      const data = await services.fetchTestHistorys({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const res = lowerFirstData(data || []) || [];
      const currentHistorys = concat(res, historys);
      setHistorys(currentHistorys);
      setLoading(false);
    }
  };

  const getScItem = (item) => {
    const request = jsonParse(item.request);
    let bizMethod = '';
    if (request.methodTypes && request.methodTypes === '[]') {
      bizMethod = `${request.methodName || ''}(${''})`;
    } else {
      bizMethod = `${request.methodName || ''}(${typeof request.methodTypes === 'string' ? request.methodTypes.replace(/\["|"]|"/g, '') : jsonStringify(request.methodTypes).replace(/\["|"]|"/g, '') || ''})`;
    }
    return (
      <React.Fragment>
        <div>{request.url}</div>
        <MultiLines lines={3} ellipsis={<span>...</span>}>
          {bizMethod}
        </MultiLines>
      </React.Fragment>
    );
  };

  console.log('historys', historys);

  return (
    <React.Fragment>
      <Loading visible={loading} style={{ width: '100%' }}>
        <div className="record" style={{ border: '1px solid #ebebeb' }}>
          <div style={{ padding: '8px 16px', background: '#fafafa', borderBottom: '1px solid #ebebeb' }}>{intl('widget.service.record')}</div>
          <div style={{ height: 750, overflow: 'auto' }}>
            <If condition={isEmpty(historys)}>
              <Empty showIcon />
            </If>
            <If condition={!isEmpty(historys)}>
              <For index="index" each="item" of={historys}>
                <div className="record-item" onClick={() => handleEcho(item)} key={index}>
                  <If condition={serviceType === 'dubbo'}>
                    {
                      getScItem(item)
                    }
                  </If>
                  <If condition={serviceType === 'springCloud'}>
                    <div>
                      <span style={{ marginRight: 16 }}>{jsonParse(item.request)?.method}</span>
                      <span>{jsonParse(item.request)?.address}</span>
                    </div>
                    <MultiLines lines={3} ellipsis={<span>...</span>}>
                      {jsonParse(item.request)?.uri}
                    </MultiLines>
                  </If>
                  <If condition={serviceType === 'istio'}>
                    <div>
                      <span style={{ marginRight: 16 }}>{jsonParse(item.request)?.method}</span>
                      <span>{jsonParse(item.request)?.address}</span>
                    </div>
                    <MultiLines lines={3} ellipsis={<span>...</span>}>
                      {jsonParse(item.request)?.uri}
                    </MultiLines>
                  </If>
                  <If condition={serviceType === 'hsf'}>
                    <div>
                      <span style={{ marginRight: 16 }}>{jsonParse(item.request)?.method}</span>
                      <span>{ jsonParse(jsonParse(item.request)?.methodTypes) && jsonParse(jsonParse(item.request)?.methodTypes).length > 0 ? '(' + jsonParse(jsonParse(item.request)?.methodTypes).join(',') + ')' : ''}</span>
                    </div>
                    <MultiLines lines={3} ellipsis={<span>...</span>}>
                      {jsonParse(item.request)?.url}
                    </MultiLines>
                  </If>
                </div>
              </For>
            </If>
          </div>
        </div>
      </Loading>
    </React.Fragment>
  );
};

const RefRecord = forwardRef(Record);

Record.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  handleEcho: PropTypes.func,
};

export default RefRecord;
