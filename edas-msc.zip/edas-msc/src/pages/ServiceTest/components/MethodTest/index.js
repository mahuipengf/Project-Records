import React, { useEffect, useState, useRef } from 'react';
import { useIntl } from '@ali/widget-hooks';
import { Field, Select, Button, Form, Loading, Message, Input, Grid } from '@alicloud/console-components';
import { BalloonIcon } from '@ali/cn-design'
import DialogAlert from 'components/DialogAlert';
import { validateContent } from 'utils';
import PropTypes from 'prop-types';
import services from 'services';
import { head, get, map, forEach, find, isEmpty, includes } from 'lodash';
import { IS_ENV_PRIVATE, MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { jsonStringify, lowerFirstData } from 'utils/transfer-data';
import DialogResult from './DialogResult';
import ScPath from 'containers/ScPath';
import JsonEditor from '@ali/cn-design-json-editor';
import Record from '../Record';
import '@ali/cn-design-json-editor/dist/index.css';

const { Row, Col } = Grid;

const jsonParse = (value) => {
  try {
    return JSON.parse(value);
  } catch (err) {
    return value;
  }
};

const NewMethodTest = (props) => {
  const intl = useIntl();
  const field = Field.useField();
  const { value = {}, rowData = {} } = props;
  const { init, setValues, validate, getValue } = field;
  const [loading, setLoading] = useState(false);
  const [ips, setIps] = useState([]);
  const [methods, setMethods] = useState([]);
  const [isRunning, setIsRunning] = useState(false);
  const [result, setResult] = useState(undefined);
  const { regionId, namespaceId, serviceType, appId, serviceName, serviceVersion, serviceGroup } = value;
  const [postResult, setPostResult] = useState('');
  const [dialogVisible, setDialogVisible] = useState(false);
  const dialogResultRef = useRef({});
  const recordRef = useRef();
  const [basicInfo, setBasicInfo] = useState({});
  const [hsfBaseInfo, setHsfBaseInfo] = useState({});
  const [testMethods, setTestMethods] = useState({});
  const [ hsfMethod, setHsfMethod ] = useState([]);
  const [parameterTypes, setParameterTypes] = useState([]);
  const [changeParameterTypes, setChangeParameterTypes] = useState([]);
  

  const SERVICE_TYPE = {
    springCloud: 'Spring Cloud',
    dubbo: 'Dubbo',
    hsf: 'HSF',
    istio: intl('widget.service.service_mesh')
  };

  // 获取基本信息
  useEffect(() => {
    console.log('getHsfDetail', serviceType);
    if(serviceType === 'hsf') {
      getHsfDetail();
    } else {
      fetchBaiscInfo();
    }
  }, []);

  // 读取sc，dubbo的接口，istio 的 Ip
  useEffect(() => {
    if (isEmpty(basicInfo)) return;
    if (serviceType === 'springCloud') {
      const scMethods = getPaths(get(basicInfo, 'methods', []));
      setTestMethods(scMethods);
      const firstMethod = head(scMethods);
      setValues({
        path: head(rowData.Paths) || firstMethod.value, // 自定义输入的path
        requiredPath: head(rowData.Paths) || firstMethod.value, // 选中的path
        needLoad: true,
      });
    } else if (serviceType === 'dubbo') {
      const dubboMethods = getDubboMethods(get(basicInfo, 'methods', []));
      setTestMethods(dubboMethods);
      const firstMethod = head(dubboMethods);
      setValues({
        dubboMethod: isEmpty(rowData) ? firstMethod.value : jsonStringify({ name: rowData.Name, parameterTypes: rowData.ParameterTypes }),
        needLoad: true,
      });
    } else if (serviceType === 'istio') {
      GetIstioTestMethod();
    }
  }, [basicInfo]);

  useEffect(() => {
    if(isEmpty(hsfBaseInfo)) return;
    console.log('hsfBaseInfo', hsfBaseInfo);
    const providers = map(get(hsfBaseInfo, 'providers'), item => ({ label: `${item.ip}:${item.port}`, value: `${item.ip}:${item.port}` }));
    setIps(providers);
    const hsfMethod = map(get(hsfBaseInfo, 'methods', []), item => ({ ...item, label: `${item.name}${ item.parameterTypes && item.parameterTypes.length > 0 ? '(' + item.parameterTypes.join(',') + ')' : ''}`, value: item.name }));
    setHsfMethod(hsfMethod);
    console.log(hsfMethod, 'setHsfMethod');
    const firstMethod = head(hsfMethod);
    setValues({
      needLoad: true,
    });
  }, [hsfBaseInfo])

  useEffect(() => {
    if (!getValue('requiredPath') || !getValue('needLoad')) {
      return;
    }
    const newMethod = find(testMethods, { value: getValue('requiredPath') });
    if (!newMethod) {
      return;
    }
    GetSpringCloudTestMethod(newMethod);
  }, [getValue('requiredPath')]);

  useEffect(() => {
    if (!getValue('dubboMethod') || !getValue('needLoad')) {
      return;
    }
    const newMethod = find(testMethods, { value: getValue('dubboMethod') });
    if (!newMethod) {
      return;
    }
    GetDubboTestMethod(newMethod);
  }, [getValue('dubboMethod')]);

  const getPaths = (list = []) => {
    const newData = [];
    forEach(list, item => {
      forEach(item.paths, path => {
        const methodItem = {
          name: item.name,
          requestMethods: item.requestMethods,
          requiredPath: path,
          path,
          value: path,
          label: path
        };
        newData.push(methodItem);
      });
    });
    return newData;
  };

  const getDubboMethods = (list = []) => {
    const newData = list.length ? map(list, child => {
      const methodItem = {
        name: child.name,
        parameterTypes: child.parameterTypes,
      };
      return ({
        ...child,
        key: jsonStringify(methodItem),
        value: jsonStringify(methodItem),
        label: `${child.name} (${child.parameterTypes})`,
      });
    }) : [];
    return newData;
  };

  // 读取dubbo 的  IP 列表、测试参数 等信息
  const GetDubboTestMethod = async ({ name, parameterTypes }) => {
    const params = {
      region: regionId,
      namespace: namespaceId,
      appId,
      serviceName,
      serviceVersion,
      serviceGroup,
      method: `${name || ''}(${parameterTypes || ''})`,
    };
    setLoading(true);
    const data = await services.GetDubboTestMethod({
      params,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        const code = get(err, 'code');
        const message = get(err, 'response.Message');
        if (code === 441 || code === 228) {
          DialogAlert({
            title: intl('widget.common.tips'),
            content: message,
          });
          throw new Error();
        } else {
          callback();
        }
      },
    });
    const res = lowerFirstData(data || {}) || {};
    const urls = get(res, 'urls', []);
    const firstIp = head(urls);
    const newUrls = map(urls, item => ({ label: item, value: item }));
    setIps(newUrls);
    setValues({
      params: get(res, 'methodMetadata.parameterTypes'),
      url: firstIp,
    });
    setLoading(false);
  };

  // 获取hsf服务信息
  const getHsfDetail = async () => {
    setLoading(true);
    console.log('getHsfDetail', value);
    const params = { ...value, group: value.serviceGroup && value.serviceGroup, region: value.regionId && value.regionId, namespace: value.namespaceId && value.namespaceId };
    const res = await services.fetchHsfDetail({
      params: {
        ...params,
        region: regionId,
        namespaceId
      }
    })
    console.log(res, 'getHsfDetail');
    const data = lowerFirstData(res) || {};
    console.log(data, 'getHsfDetail1111');
    setLoading(false);
    setHsfBaseInfo(data);
  }

  // 读取sc 的  IP 列表、测试参数 等信息
  const GetSpringCloudTestMethod = async ({ requiredPath }) => {
    const params = {
      region: regionId,
      namespace: namespaceId,
      appId,
      serviceName,
      requiredPath,
    };
    setLoading(true);
    const res = await services.GetSpringCloudTestMethod({
      params,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        const code = get(err, 'code');
        const message = get(err, 'response.Message');
        if (code === 441 || code === 228) {
          DialogAlert({
            title: intl('widget.common.tips'),
            content: message,
          });
          throw new Error();
        } else {
          callback();
        }
      },
    });
    const { params: Params = {}, httpHeaders = {}, urls = [], requestMethods = [] } = lowerFirstData(res) || {};
    const firstIp = head(urls);
    const firstMethod = head(requestMethods);
    const newUrls = map(urls, item => ({ label: item, value: item }));
    const newMethods = map(requestMethods, item => ({ label: item, value: item }));
    setIps(newUrls);
    setMethods(newMethods);
    setValues({
      params: JSON.stringify({ headers: httpHeaders, params: Params }, null, 2),
      url: firstIp,
      httpMethod: firstMethod,
    });
    setLoading(false);
  };

  // 获取istio 的 IP
  const GetIstioTestMethod = async () => {
    const params = {
      region: regionId,
      namespace: namespaceId,
      appId,
    };
    setLoading(true);
    const res = await services.GetIstioTestMethod({
      params,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        const code = get(err, 'code');
        const message = get(err, 'response.Message');
        if (code === 441 || code === 228) {
          DialogAlert({
            title: intl('widget.common.tips'),
            content: message,
          });
          throw new Error();
        } else {
          callback();
        }
      },
    });
    const { urls = [] } = lowerFirstData(res) || {};
    const firstIp = head(urls);
    const newUrls = map(urls, item => ({ label: item, value: item }));
    setIps(newUrls);
    setValues({
      url: firstIp,
      params: JSON.stringify({ headers: {}, params: {} }, null, 2),
    });
    setLoading(false);
  };

  // 获取服务基础信息
  const fetchBaiscInfo = async () => {
    setLoading(true);
    const params = { ...value, region: value.regionId, namespace: value.namespaceId };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'arms') {
      params.version = params.serviceVersion;
      params.group = params.serviceGroup;
      const res = await services.fetchArms({
        data: params,
        params: { action: 'ContainerAction', eventSubmitDoServiceDetail: 1 },
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      const data = lowerFirstData(res) || {};
      setLoading(false);
      const newBasicInfo = {
        ...data,
        serviceTypeLabel: SERVICE_TYPE[data.serviceType],
      };
      setBasicInfo(newBasicInfo);
      return;
    }
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params.version = params.serviceVersion;
      params.group = params.serviceGroup;
    }
    const res = await services.fetchServiceBasicInfo({
      data: params,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      }
    });
    const data = lowerFirstData(res) || {};
    setLoading(false);
    const newBasicInfo = {
      ...data,
      serviceTypeLabel: SERVICE_TYPE[data.serviceType],
    };
    setBasicInfo(newBasicInfo);
  };

  const handleOk = () => {
    validate(async (errors, values) => {
      if (errors) return;
      setIsRunning(true);
      if (serviceType === 'dubbo') {
        const dubboMethod = JSON.parse(values.dubboMethod);
        const name = get(dubboMethod, 'name', '');
        const parameterTypes = get(dubboMethod, 'parameterTypes', '');
        const params = {
          region: regionId,
          namespace: namespaceId,
          appId,
          serviceName,
          serviceVersion,
          serviceGroup,
          method: `${name}(${parameterTypes})`
        };
        const res = await services.postDubboParams({
          data: {
            ...params,
            url: values.url,
            params: values.params,
          },
          customErrorHandle: (err, response, callback) => {
            setIsRunning(false);
            if (dialogResultRef.current.diable) {
              throw new Error();
            }
            const code = get(err, 'code');
            const message = get(err, 'response.Message');
            console.log('err', err, code);
            if (code === 441) {
              DialogAlert({
                title: intl('widget.common.tips'),
                content: message,
              });
              throw new Error();
            } else {
              callback();
            }
          },
        });
        const { content: Content, status: Status } = lowerFirstData(res) || {};
        if (Status === 'creating') {
          setDialogVisible(true);
          return;
        }
        recordRef.current.fetchLastHistory();
        setDialogVisible(false);
        setResult(Content);
        setPostResult(intl('widgt.common.success'));
        setIsRunning(false);
      } else if (serviceType === 'springCloud') {
        const newValue = values.params;
        const { params: Params, headers } = JSON.parse(newValue);
        const params = {
          region: regionId,
          namespace: namespaceId,
          appId,
          serviceName,
          requiredPath: values.requiredPath,
          httpMethod: values.httpMethod,
          url: values.url,
          path: values.path,
          httpHeaders: JSON.stringify(headers),
          params: JSON.stringify(Params),
        };
        const res = await services.postSCParams({
          data: params,
          customErrorHandle: (err, response, callback) => {
            setIsRunning(false);
            console.log('err', err);
            if (dialogResultRef.current.diable) {
              throw new Error();
            }
            const code = get(err, 'code');
            const message = get(err, 'response.Message');
            if (code === 441) {
              DialogAlert({
                title: intl('widget.common.tips'),
                content: message,
              });
              throw new Error();
            } else {
              callback();
            }
          },
        });
        const { content: Content, status: Status } = lowerFirstData(res) || {};
        if (Status === 'creating') {
          setDialogVisible(true);
          return;
        }
        recordRef.current.fetchLastHistory();
        setDialogVisible(false);
        setResult(Content);
        setPostResult(intl('widgt.common.success'));
        setIsRunning(false);
      } else if (serviceType === 'istio') {
        const newValue = values.params;
        const { params: Params, headers } = JSON.parse(newValue);
        const params = {
          region: regionId,
          namespace: namespaceId,
          appId,
          serviceName,
          requiredPath: values.requiredPath,
          httpMethod: values.httpMethod,
          url: values.url,
          path: values.path,
          httpHeaders: JSON.stringify(headers),
          params: JSON.stringify(Params),
        };
        const res = await services.InvokeIstioTestMethod({
          data: params,
          customErrorHandle: (err, response, callback) => {
            setIsRunning(false);
            console.log('err', err);
            if (dialogResultRef.current.diable) {
              throw new Error();
            }
            const code = get(err, 'code');
            const message = get(err, 'response.Message');
            if (code === 441) {
              DialogAlert({
                title: intl('widget.common.tips'),
                content: message,
              });
              throw new Error();
            } else {
              callback();
            }
          },
        });
        const { content: Content, status: Status } = lowerFirstData(res) || {};
        if (Status === 'creating') {
          setDialogVisible(true);
          return;
        }
        recordRef.current.fetchLastHistory();
        setDialogVisible(false);
        setResult(Content);
        setPostResult(intl('widgt.common.success'));
        setIsRunning(false);
      } else if (serviceType === 'hsf') {
        console.log(values.hsfMethod, values, 'values.hsfMethod');
        const params = {
          regionId: regionId,
          appId: appId,
          serviceType: serviceType,
          serviceName: serviceName,
          serviceVersion: serviceVersion,
          group: serviceGroup,
          method: values.hsfMethod,
          methodTypes: JSON.stringify(parameterTypes),
          url: `hsf://${values.url}`,
          params: values.params,
        };

        const res = await services.RunServiceTest({
         params,
         customErrorHandle: (err, response, callback) => {
            setLoading(false);
            callback();setIsRunning(false);
            if (dialogResultRef.current.diable) {
              throw new Error();
            }
            const code = get(err, 'code');
            const message = get(err, 'response.Message');
            console.log('err', err, code);
            if (code === 441) {
              DialogAlert({
                title: intl('widget.common.tips'),
                content: message,
              });
              throw new Error();
            } else {
              callback();
            }
          }
        })
        console.log('res', lowerFirstData(res));
        const { engineStatus, engineResult } = lowerFirstData(res) || {};
        if (engineStatus === 'WAITING') {
          setDialogVisible(true);
          return;
        }
        recordRef.current.fetchLastHistory();
        setDialogVisible(false);
        setResult(engineResult);
        setPostResult(intl('widgt.common.success'));
        setIsRunning(false);
      }
    });
  };

  const handleJsonValidator = (rule, val, callback) => {
    if (val) {
      if (validateContent.validateJson(val)) {
        callback();
      } else {
        callback(intl('widget.service.service_test_error'));
      }
      return;
    }
    callback();
  };

  const handleEcho = (record) => {
    if (serviceType === 'dubbo') {
      const request = jsonParse(record.request);
      const methodItem = {
        name: request.methodName,
        parameterTypes: typeof request.methodTypes === 'string' ? jsonParse(request.methodTypes) : request.methodTypes,
      };
      setValues({
        url: request.url,
        dubboMethod: jsonStringify(methodItem),
        params: request.params,
        needLoad: false,
      });
      const response = jsonParse(record.response);
      setResult(response.content);
    } else if (serviceType === 'springCloud') {
      const request = jsonParse(record.request);
      const headers = jsonParse(request.headers) || [];
      let headersObject = {};
      forEach(headers, item => {
        headersObject = { ...headersObject, ...item };
      });

      let paramsObject = {};
      if (request.body) {
        const body = jsonParse(request.body) || [];
        if (includes(request.headers, 'application/json')) {
          paramsObject = body;
        } else {
          forEach(body, item => {
            paramsObject = { ...paramsObject, ...item };
          });
        }
      }
      setValues({
        url: request.address,
        path: request.uri,
        requiredPath: request.uri,
        params: JSON.stringify({ headers: headersObject, params: paramsObject }),
        httpMethod: request.method,
        needLoad: false,
      });
      const response = jsonParse(record.response);
      setResult(response.content);
    } else if (serviceType === 'istio') {
      const request = jsonParse(record.request);
      const headers = jsonParse(request.headers) || [];
      let headersObject = {};
      forEach(headers, item => {
        headersObject = { ...headersObject, ...item };
      });

      let paramsObject = {};
      if (request.body) {
        const body = jsonParse(request.body) || [];
        if (includes(request.headers, 'application/json')) {
          paramsObject = body;
        } else {
          forEach(body, item => {
            paramsObject = { ...paramsObject, ...item };
          });
        }
      }
      setValues({
        url: request.address,
        path: request.uri,
        requiredPath: request.uri,
        params: JSON.stringify({ headers: headersObject, params: paramsObject }),
        httpMethod: request.method,
        needLoad: false,
      });
      const response = jsonParse(record.response);
      setResult(response.content);
    } else if (serviceType === 'hsf') {
      console.log('record', record);
      const request = jsonParse(record.request);
      const url = request.url;
      const urlarr = url.split('/');
      const newUrl = urlarr[urlarr.length - 1];
      setValues({
        url: newUrl,
        params: request.params,
        hsfMethod: request.method,
        needLoad: false,
      });
      setParameterTypes(jsonParse(request.methodTypes));
      const response = jsonParse(record.response);
      setResult(response.content);
    }
  };

  const onHsfSelectChange = (value) => {
    const obj = hsfMethod.find((item) => item.value == value);
    obj && setParameterTypes(obj.parameterTypes);
    obj && setChangeParameterTypes(obj.parameterTypes);
    obj && setValues({
      params: obj.parameterAsJsonInput
    })
  }

  const onInputChange = (value, index) => {
    const arr = parameterTypes.map((item, i) => i === index ? value : item);
    setParameterTypes(arr);
    setChangeParameterTypes(arr);
  }

  const renderParamsType = () => {
    return <div style={{ display: 'inline-block', alignItems: 'center' }}>
      <span>{intl('widget.k8s_gray.params_type')}</span>
      <BalloonIcon
        text={intl('widget.service.service_test_request_hsf_method_balloon')}
        type="help"
        size="small"
        style={{ marginLeft: 8, cursor: 'pointer' }}
      />
    </div>
  }

  return (
    <React.Fragment>
      <If condition={!IS_ENV_PRIVATE}>
        <Message type="warning" style={{ marginBottom: 8 }}>
          {intl.html(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'widget.service.method_test_hint' : 'widget.service.method_test_hint_mse')}
        </Message>
      </If>
      <Row style={{ width: '100%' }}>
        <Col span="8" style={{ position: 'relative' }}>
          <div style={{ flex: 1, position: 'relative', color: '#555', paddingRight: 16 }}>
            <Record
              ref={recordRef}
              value={value}
              handleEcho={handleEcho}
            />
          </div>
        </Col>
        <Col span="16" style={{ position: 'relative' }}>
          <Loading visible={loading} style={{ width: '100%' }}>
            <Form field={field} labelAlign="top" >
              <If condition={serviceType === 'springCloud'}>
                <Form.Item label={intl('widget.service.service_test_ip')} required>
                  <Select
                    {...init('url', {
                      initValue: '',
                      rules: [
                        {
                          required: true,
                          message: intl('widget.service.service_ip_cannot_be_empty'),
                        },
                      ],
                    })}
                    style={{ width: '100%' }}
                    dataSource={ips}
                  />
                </Form.Item>
                <Form.Item label={intl('widget.service.service_test_path')} required>
                  <ScPath
                    {...init('path', {
                      rules: [
                        {
                          required: true,
                          message: intl('widget.authentication.caller_path_placeholder'),
                        },
                      ],
                      props: {
                        onChange: (val, actionType, item) => {
                          if (item) {
                            setValues({
                              requiredPath: val,
                              needLoad: true
                            });
                          }
                        }
                      }
                    })}
                    hasClear
                    showSearch
                    style={{ width: '80%' }}
                    dataSource={testMethods}
                    placeholder={intl('widget.authentication.caller_path_placeholder')}
                  />
                </Form.Item>
                <Form.Item label={intl('widget.service.service_test_request_method')} required>
                  <Select
                    {...init('httpMethod', {
                      initValue: '',
                      rules: [
                        {
                          required: true,
                          message: intl('widget.service.service_request_method_cannot_be_empty'),
                        },
                      ],
                    })}
                    style={{ width: '100%' }}
                    dataSource={methods}
                  />
                </Form.Item>
              </If>
              <If condition={serviceType === 'dubbo'}>
                <Form.Item label={intl('widget.service.service_test_ip')} required>
                  <Select
                    {...init('url', {
                      initValue: '',
                      rules: [
                        {
                          required: true,
                          message: intl('widget.service.service_ip_cannot_be_empty'),
                        },
                      ],
                    })}
                    style={{ width: '100%' }}
                    dataSource={ips}
                  />
                </Form.Item>
                <Form.Item label={intl('widget.service.test.test_method')} required>
                  <Select
                    {...init('dubboMethod', {
                      rules: [
                        {
                          required: true,
                          message: intl('widget.service.service_test_cannot_be_empty'),
                        },
                      ],
                      props: {
                        onChange: () => {
                          setValues({
                            needLoad: true
                          });
                        }
                      }
                    })}
                    style={{ width: '100%' }}
                    dataSource={testMethods}
                  />
                </Form.Item>
              </If>
              <If condition={serviceType === 'istio'}>
                <Form.Item label={intl('widget.service.service_test_ip')} required>
                  <Select
                    {...init('url', {
                      initValue: '',
                      rules: [
                        {
                          required: true,
                          message: intl('widget.service.service_ip_cannot_be_empty'),
                        },
                      ],
                    })}
                    placeholder={intl('widget.service.service_ip_cannot_be_empty')}
                    style={{ width: '100%' }}
                    dataSource={ips}
                  />
                </Form.Item>
                <Form.Item label={intl('widget.service.service_test_path')} required>
                  <Input
                    {...init('path', {
                      rules: [
                        {
                          required: true,
                          message: intl('widget.authentication.caller_path_placeholder'),
                        },
                      ],
                      props: {
                        onChange: (val) => {
                          setValues({
                            requiredPath: val,
                            needLoad: false
                          });
                        }
                      }
                    })}
                    hasClear
                    showSearch
                    style={{ width: '100%' }}
                    placeholder={intl('widget.authentication.caller_path_placeholder')}
                  />
                </Form.Item>
                <Form.Item label={intl('widget.service.service_test_request_method')} required>
                  <Select
                    {...init('httpMethod', {
                      initValue: head(rowData.RequestMethods) === 'ALL' ? 'GET' : (head(rowData.RequestMethods) || 'GET'),
                      rules: [
                        {
                          required: true,
                          message: intl('widget.service.please_enter_service_request_method'),
                        },
                      ],
                    })}
                    placeholder={intl('widget.service.please_enter_service_request_method')}
                    style={{ width: '100%' }}
                    dataSource={
                      [
                        { value: 'GET', label: 'GET' },
                        { value: 'POST', label: 'POST' },
                        { value: 'PUT', label: 'PUT' },
                        { value: 'DELETE', label: 'DELETE' },
                      ]
                    }
                  />
                </Form.Item>
              </If>
              <If condition={serviceType === 'hsf'}>
                <Form.Item label={intl('widget.service.service_test_ip')} required>
                  <Select
                    {...init('url', {
                      initValue: '',
                      rules: [
                        {
                          required: true,
                          message: intl('widget.service.service_ip_cannot_be_empty'),
                        },
                      ],
                    })}
                    style={{ width: '100%' }}
                    dataSource={ips}
                  />
                </Form.Item>
                <Form.Item label={intl('widget.service.test.test_method')} required>
                  <Select
                    {...init('hsfMethod', {
                      rules: [
                        {
                          required: true,
                          message: intl('widget.service.service_test_cannot_be_empty'),
                        },
                      ],
                      props: {
                        onChange: (value, item) => {
                          onHsfSelectChange(value);
                          setValues({
                            needLoad: true
                          });
                        }
                      }
                    })}
                    style={{ width: '100%' }}
                    dataSource={hsfMethod}
                  />
                </Form.Item>
              </If>
              <If condition={serviceType === 'hsf'}>
                {
                  parameterTypes.length > 0 &&
                  <Form.Item label={renderParamsType()} required>
                    <div style={{ display: 'flex', flexDirection: 'column' }}>
                      {
                        parameterTypes.map((item, index) => (
                          <Input style={{ marginTop: 5 }} key={index} value={item} onChange={(value) => onInputChange(value, index)} />
                        ))
                      }    
                    </div>
                  </Form.Item>
                }
              </If>
              <Form.Item label={intl('widget.service.service_test_params')} required>
                <JsonEditor
                  {...init('params', {
                    initValue: '', // 接收字符串，onChange回传也是字符串
                    rules: [
                      {
                        required: true,
                        message: intl('widget.service.please_entry_service_test_params'),
                      },
                      {
                        validator: handleJsonValidator,
                      },
                    ],
                  })}
                  style={{ height: 240 }}
                />
              </Form.Item>
              <Form.Item>
                <div style={{ textAlign: 'right' }}>
                  <Button
                    validate="true"
                    type="primary"
                    onClick={() => {
                      dialogResultRef.current.diable = false;
                      handleOk();
                    }}
                    loading={isRunning}
                  >
                    {intl('widget.service.service_test_run')}
                  </Button>
                </div>
              </Form.Item>
            </Form>
            <Form.Item label={intl('widget.service.service_test_resulet', { result: <span style={{ color: postResult === intl('widgt.common.fail') ? 'red' : '' }}>{postResult}</span> })}>
              <JsonEditor
                value={result ? JSON.stringify(jsonParse(result), null, 2) : ''}
                modes={['preview']}
                mode="preview"
                style={{ height: 240 }}
              />
            </Form.Item>
          </Loading>
        </Col>
      </Row>
      <If condition={dialogVisible}>
        <DialogResult
          onClose={() => {
            dialogResultRef.current.diable = true;
            setDialogVisible(false);
            setIsRunning(false);
          }}
          refresh={handleOk}
        />
      </If>
    </React.Fragment >
  );
};
NewMethodTest.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
};

export default NewMethodTest;
