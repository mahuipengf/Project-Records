import React from 'react';
import { Icon } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import Dialog from 'components/Dialog';
import PropTypes from 'prop-types';
import { Consumer } from '@ali/widget-context';

class DialogResult extends React.Component {
  state = {
    count: 0,
    visible: true,
  }

  componentDidMount() {
    this.timer = setInterval(() => {
      if (this.state.count === 99) {
        clearInterval(this.timer);
        const { onClose } = this.props;
        onClose();
        const { intl } = this.props;
        DialogAlert({
          title: intl('widget.common.tips'),
          content: intl.html('widget.service_test.start_error'),
        });
      } else {
        this.setState({ count: this.state.count + 1 });
      }
    }, 500);

    this.refresher = setInterval(() => {
      if (this.state.count === 98) {
        clearInterval(this.refresher);
      } else {
        this.props.refresh();
      }
    }, 5000);
  }

  componentWillUnmount() {
    clearInterval(this.timer);
    clearInterval(this.refresher);
  }

  render() {
    const { onClose, intl } = this.props;
    return (
      <Dialog
        style={{ width: 340 }}
        title={
          <div>
            <Icon type="warning" style={{ color: '#ffc440', marginRight: 16 }} />
            {intl('widget.common.tips')}
          </div>
        }
        visible={this.state.visible}
        footer={false}
        onClose={onClose}
      >
        <div style={{ padding: '0 16px 16px 28px', marginTop: -16 }}>
          {intl.html('widget.service_test.starting', { count: this.state.count })}
        </div>
      </Dialog>
    );
  }
}

DialogResult.propTypes = {
  onClose: PropTypes.func,
  refresh: PropTypes.func,
  intl: PropTypes.func,
};

export default props => (
  <Consumer>
    {({ intl }) => <DialogResult intl={intl} {...props} />}
  </Consumer>
);
