import { get } from 'lodash';
import { EDAS_CHANNEL_INFO } from 'constants';

export const RPC_TYPE = {
  DUBBO: 7,
  SPRING_CLOUD: 25,
  ISTIO: 26,
};

export const RPC_TYPE_DATA = (intl, productName) => {
  const featureIstioEnable = get(window, 'EDAS_USER_FEATURES.featureIstioEnable', false);
  if (productName === 'Edas' && featureIstioEnable && EDAS_CHANNEL_INFO.toLowerCase() !== 'finance') {
    return [
      { value: RPC_TYPE.SPRING_CLOUD, label: 'Spring Cloud' },
      { value: RPC_TYPE.DUBBO, label: 'Dubbo' },
      { value: RPC_TYPE.ISTIO, label: intl('widget.service.service_mesh') },
    ];
  } else {
    return [
      { value: RPC_TYPE.SPRING_CLOUD, label: 'Spring Cloud' },
      { value: RPC_TYPE.DUBBO, label: 'Dubbo' },
    ];
  }
};

// 创建策略的初始信息
export const DEFAULT_INFO = {
  policyName: undefined, // 策略名称
  policyDescription: undefined, // 描述
  rpcType: 25, // 被调用服务应用框架，7-dubbo，25-spring cloude
  appList: [], // 应用列表 Array<appId, appName>
  shouldCountBizError: false, // 异常类型，false-网络异常，true-网络异常+业务异常
  requestThreshold: 1, // QPS阈值
  errorRateThreshold: 50, // 错误率阈值
  maxIsolationRate: 20, // 摘除比例阈值
  isolationTime: 30000, // 恢复时间
  maxIsolationTimeMultiple: 40, // 未恢复实际累计次数上限
  isOutlierEnabled: true, // 离群摘除默认开启状态
  source: 0,

  // istio
  maxEjectionPercent: 10, // 最大驱逐的实例比例
  // interval: 10000, // 恢复检测单位时间
  consecutiveErrors: 5, // 连续错误的次数
  http1MaxPendingRequests: 1024, // 最大Pending请求数
  maxRequestsPerConnection: 1024, // 单条连接最大请求数
  maxConnections: 1024, // 最大连接数
};
