import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Message, Radio, BalloonIcon, Field, NumberPicker, Collapse, Switch } from '@ali/cn-design';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { NNAME_PATTERN, MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import SlidePanel from 'components/SlidePanel';
import { forEach, map, get, uniqueId, unionBy } from 'lodash';
import IconBack from 'components/IconBack';
import { RPC_TYPE_DATA, RPC_TYPE, DEFAULT_INFO } from '../../../constants';
import EffectiveAppTranfer from '../../components/EffectiveAppTransfer';
import styles from './index.less';
import { lowerFirstData } from 'utils/transfer-data';
import NamespaceComp from 'containers/Namespace';

const OutlierEjectionEditForm = (props) => {
  const field = Field.useField();
  const [loading, setLoading] = useState(false);
  const { value, visible, onClose, onOk } = props;
  const intl = useIntl();
  const { init, validate, getValue, setValues, reset, getValues, setValue } = field;

  useEffect(() => {
    const PolicyName = get(value, 'PolicyName', '');
    const Protocol = get(value, 'Protocol', '');
    const Region = get(value, 'Region', '');
    const Namespace = get(value, 'Namespace', '');
    const ErrorRateThreshold = get(value, 'ErrorRateThreshold', '');

    if (value.Id) {
      setValues({
        PolicyName,
        Protocol,
        Region,
        Namespace,
        ErrorRateThreshold,
      });
    } else {
      setValues({
        AppList: [],
        Protocol,
        Region,
        Namespace,
      });
    }
  }, [value]);

  const handleSubmit = () => {
    validate(async (errors, values) => {
      console.log(values)
      if (errors) return;
      let params = {
        PolicyName: values.PolicyName,
        Namespace: values.Namespace,
        Region: values.Region,
        AppList: values.AppList,
        OutlierConfig: {}
      };

      if (values.Protocol === RPC_TYPE.DUBBO || values.Protocol === RPC_TYPE.SPRING_CLOUD) {
        params.OutlierConfig = {
          rpcType: values.Protocol,
          isOutlierEnabled: values.IsOutlierEnabled,
          errorRateThreshold: values.ErrorRateThreshold / 100,
          source: 0,
          shouldCountBizError: values.ShouldCountBizError,
          requestThreshold: values.RequestThreshold,
          maxIsolationRate: values.MaxIsolationRate / 100,
          isolationTime: values.IsolationTime,
          maxIsolationTimeMultiple: values.MaxIsolationTimeMultiple,
        };
      }
      if (values.Protocol === RPC_TYPE.ISTIO) {
        params.OutlierConfig = {
          source: 0,
          rpcType: values.Protocol,
          isOutlierEnabled: values.IsOutlierEnabled,
          maxEjectionPercent: values.MaxEjectionPercent / 100,
          isolationTime: values.IsolationTime,
          consecutiveErrors: values.ConsecutiveErrors,
          http1MaxPendingRequests: values.Http1MaxPendingRequests,
          maxRequestsPerConnection: values.MaxRequestsPerConnection,
          maxConnections: values.MaxConnections,
        };
      }
      if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
        params = {
          regionId: params.Region,
          namespaceId: params.Namespace,
          policyName: params.PolicyName,
          appList: params.AppList,
          outlierConfigDO: params.OutlierConfig,
        };
      }
      createOutlierEjection(params);
    });
  };

  // 创建
  const createOutlierEjection = async (params) => {
    setLoading(true);
    await services.addOutlierEjection({
      data: params,
      customErrorHandle: (error, respongse, callback) => {
        setLoading(false);
        callback();
      }
    });
    setLoading(false);
    onOk();
    Message.success(intl(value.Id ? 'widget.common.update_successful' : 'widget.common.add_successful'));
  };

  const handleClose = () => {
    setLoading(false);
    onClose();
  };

  const checkPolicyName = (rule, val, callback) => {
    if (!NNAME_PATTERN.test(val)) {
      callback(intl('widget.outlier_ejection.name_pattern'));
    } else {
      callback();
    }
  };

  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  const fetchNamespaces = async (regionId) => {
    const { data = [] } = await services.fetchNamespaces({ params: { regionId } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  return (
    <SlidePanel
      title={
        <IconBack goBack={handleClose}>{intl(getValue('uid') ? 'widget.outlier_ejection.edit_policy' : 'widget.outlier_ejection.create_policy')}</IconBack>
      }
      processingText={intl('widget.common.ok')}
      isShowing={visible}
      onOk={handleSubmit}
      onClose={handleClose}
      onCancel={handleClose}
      isProcessing={loading}
      width={780}
    >
      <Form field={field}>
        <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && visible}>
          <Form.Item label={intl('widget.common.microservice_space')} required>
            <NamespaceComp
              {...init('namespaces', {
                initValue: { regionId: get(value, 'Region'), namespaceId: get(value, 'Namespace') },
                rules: [
                  {
                    required: true,
                    message: intl('widget.common.please_select_microservice_space'),
                  },
                ],
                props: {
                  onChange: v => {
                    setValues({
                      Region: v.regionId,
                      Namespace: v.namespaceId,
                      AppList: [],
                    });
                  }
                },
              })}
              style={{ width: 346 }}
              fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
              fetchNamespaces={fetchNamespaces}
            />
          </Form.Item>
        </If>
        <Form.Item label={intl('widget.outlier_ejection.policy_name')} required>
          <Input
            style={{ width: 'calc(100% - 32px)' }}
            maxLength={64}
            showLimitHint
            placeholder={intl('widget.outlier_ejection.input_policy_name')}
            {...init('PolicyName', {
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.input_policy_name'),
                },
                {
                  validator: checkPolicyName
                }
              ],
            })}
          />
        </Form.Item>
        <Form.Item label={intl('widget.outlier_ejection.use_frame')} required requiredMessage={intl('widget.outlier_ejection.select_use_frame')}>
          <Radio.Group
            {...init('Protocol', {
              rules: [
                {
                  required: true,
                },
              ],
              props: {
                onChange: () => setValue('AppList', [])
              }
            })}
            dataSource={RPC_TYPE_DATA(intl, MSC_WIDGET_CONSOLE_CONFIG.productName)}
          />
        </Form.Item>
        <Form.Item required requiredMessage={intl('widget.outlier_ejection.select_effect_app')}>
          <EffectiveAppTranfer
            {...init('AppList', {
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.select_effect_app')
                },
              ],
            })}
            listStyle={{ width: 310, height: 300 }}
            Namespace={getValue('Namespace')}
            Region={getValue('Region')}
            Protocol={getValue('Protocol')}
          />
        </Form.Item>
        <If condition={getValue('Protocol') === RPC_TYPE.DUBBO || getValue('Protocol') === RPC_TYPE.SPRING_CLOUD}>
          <Form.Item
            label={
              <React.Fragment >
                <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.error_rate_threshold')}</span>
                <BalloonIcon text={intl('widget.outlier_ejection.error_rate_threshold_hint')} />
              </React.Fragment>
            }
            required
          >
            <NumberPicker
              min={0}
              max={100}
              style={{ width: 'calc(100% - 32px)' }}
              placeholder="0~100"
              {...init('ErrorRateThreshold', {
                initValue: DEFAULT_INFO.errorRateThreshold,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.input_error_rate_threshold'),
                  },
                ],
              })}
            />
            <span style={{ marginLeft: 8 }}>%</span>
          </Form.Item>
          <Collapse>
            <Collapse.Panel title={intl('widget.msc.advanced_config')}>
              <div className={styles.strategyConfig}>
                <Form.Item
                  label={intl('widget.outlier_ejection.exception_type')}
                  required
                >
                  <Radio.Group
                    {...init('ShouldCountBizError', {
                      initValue: DEFAULT_INFO.shouldCountBizError,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.select_exception_type')
                        }
                      ]
                    })}
                    dataSource={[
                      { value: false, label: intl('widget.outlier_ejection.network_abnormal') },
                      {
                        value: true,
                        label: (
                          <React.Fragment>
                            <If condition={getValue('Protocol') === RPC_TYPE.DUBBO}>
                              {intl('widget.outlier_ejection.dubbo_network_abnormal')}
                            </If>
                            <If condition={getValue('Protocol') === RPC_TYPE.SPRING_CLOUD}>
                              {intl('widget.outlier_ejection.spring_cloud_network_abnormal')}
                            </If>
                          </React.Fragment>
                        ),
                      },
                    ]}
                  />
                </Form.Item>
                <Form.Item
                  label={
                    <React.Fragment>
                      <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.QPS_threshold')}</span>
                      <BalloonIcon
                        text={intl('widget.outlier_ejection.QPS_threshold_hint')}
                      />
                    </React.Fragment>
                  }
                  required
                >
                  <NumberPicker
                    min={0}
                    style={{ width: 'calc(100% - 32px)' }}
                    {...init('RequestThreshold', {
                      initValue: DEFAULT_INFO.requestThreshold,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.input_QPS_threshold'),
                        },
                      ],
                    })}
                    placeholder={intl('widget.outlier_ejection.non_negative_integer')}
                  />
                  <span style={{ marginLeft: 8 }}>s</span>
                </Form.Item>
                <Form.Item
                  label={
                    <React.Fragment>
                      <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.remove_rate_threshold')}</span>
                      <BalloonIcon text={intl('widget.outlier_ejection.remove_rate_threshold_hint')} />
                    </React.Fragment>
                  }
                  required
                >
                  <NumberPicker
                    min={0}
                    max={100}
                    style={{ width: 'calc(100% - 32px)' }}
                    placeholder="0~100"
                    {...init('MaxIsolationRate', {
                      initValue: DEFAULT_INFO.maxIsolationRate,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.input_remove_rate_threshold'),
                        },
                      ],
                    })}
                  />
                  <span style={{ marginLeft: 8 }}>%</span>
                </Form.Item>
                <Form.Item label={intl('widget.outlier_ejection.recovery_unit_time')} required>
                  <NumberPicker
                    min={1}
                    style={{ width: 'calc(100% - 32px)' }}
                    placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
                    {...init('IsolationTime', {
                      initValue: DEFAULT_INFO.isolationTime,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.input_recovery_unit_time'),
                        },
                      ],
                    })}
                  />
                  <span style={{ marginLeft: 8 }}>ms</span>
                </Form.Item>
                <Form.Item
                  label={
                    <React.Fragment>
                      <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.not_restored_times')}</span>
                      <BalloonIcon text={intl('widget.outlier_ejection.not_restored_times_hint')} />
                    </React.Fragment>
                  }
                  required
                >
                  <NumberPicker
                    min={1}
                    style={{ width: 'calc(100% - 32px)' }}
                    placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
                    {...init('MaxIsolationTimeMultiple', {
                      initValue: DEFAULT_INFO.maxIsolationTimeMultiple,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.input_not_restored_times'),
                        },
                      ],
                    })}
                  />
                </Form.Item>
                <Form.Item label={intl('widget.outlier_ejection.default_state')} style={{ margin: '18px 0 0' }}>
                  <Switch
                    {...init('IsOutlierEnabled', {
                      initValue: DEFAULT_INFO.isOutlierEnabled,
                      valueName: 'checked'
                    })}
                  />
                </Form.Item>
              </div>
            </Collapse.Panel>
          </Collapse>
        </If>
        <If condition={getValue('Protocol') === RPC_TYPE.ISTIO}>

          <Form.Item
            label={intl('widget.outlier_ejection.continuou_error_times')}
            required
          >
            <NumberPicker
              min={1}
              style={{ width: 'calc(100% - 32px)' }}
              placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
              {...init('ConsecutiveErrors', {
                initValue: DEFAULT_INFO.consecutiveErrors,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.please_continuou_error_times'),
                  },
                ],
              })}
            />
          </Form.Item>
          <Collapse>
            <Collapse.Panel title={intl('widget.msc.advanced_config')}>
              <div className={styles.strategyConfig}>
                <Form.Item label={intl('widget.outlier_ejection.exception_type')}>
                  <div style={{ marginTop: 8 }}>{intl('widget.outlier_ejection.5xx_exception')}</div>
                </Form.Item>
                <Form.Item
                  label={intl('widget.outlier_ejection.max_ejection_percent')}
                  required
                >
                  <NumberPicker
                    min={0}
                    max={100}
                    style={{ width: 'calc(100% - 32px)' }}
                    placeholder="0~100"
                    {...init('MaxEjectionPercent', {
                      initValue: DEFAULT_INFO.maxEjectionPercent,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.please_entry_max_ejection_percent'),
                        },
                      ],
                    })}
                  />
                  <span style={{ marginLeft: 8 }}>%</span>
                </Form.Item>
                <Form.Item label={intl('widget.outlier_ejection.recovery_unit_time')} required>
                  <NumberPicker
                    min={1}
                    style={{ width: 'calc(100% - 32px)' }}
                    placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
                    {...init('IsolationTime', {
                      initValue: DEFAULT_INFO.isolationTime,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.input_recovery_unit_time'),
                        },
                      ],
                    })}
                  />
                  <span style={{ marginLeft: 8 }}>ms</span>
                </Form.Item>
                <Form.Item
                  label={intl('widget.outlier_ejection.max_connections_times')}
                  required
                >
                  <NumberPicker
                    min={1}
                    style={{ width: 'calc(100% - 32px)' }}
                    placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
                    {...init('MaxConnections', {
                      initValue: DEFAULT_INFO.maxIsolationRate,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.please_intry_max_connections_times'),
                        },
                      ],
                    })}
                  />
                </Form.Item>
                <Form.Item
                  label={intl('widget.outlier_ejection.max_pending_request_times')}
                  required
                >
                  <NumberPicker
                    min={1}
                    style={{ width: 'calc(100% - 32px)' }}
                    placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
                    {...init('Http1MaxPendingRequests', {
                      initValue: DEFAULT_INFO.http1MaxPendingRequests,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.please_entry_max_pending_request_times'),
                        },
                      ],
                    })}
                  />
                </Form.Item>
                <Form.Item
                  label={intl('widget.outlier_ejection.single_link_max_request_times')}
                  required
                >
                  <NumberPicker
                    min={1}
                    style={{ width: 'calc(100% - 32px)' }}
                    placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
                    {...init('MaxRequestsPerConnection', {
                      initValue: DEFAULT_INFO.maxRequestsPerConnection,
                      rules: [
                        {
                          required: true,
                          message: intl('widget.outlier_ejection.please_entry_single_link_max_request_times'),
                        },
                      ],
                    })}
                  />
                </Form.Item>
                <Form.Item label={intl('widget.outlier_ejection.default_state')} style={{ margin: '18px 0 0' }}>
                  <Switch
                    {...init('IsOutlierEnabled', {
                      initValue: DEFAULT_INFO.isOutlierEnabled,
                      valueName: 'checked'
                    })}
                  />
                </Form.Item>
              </div>
            </Collapse.Panel>
          </Collapse>
        </If>
      </Form>
    </SlidePanel>
  );
};

OutlierEjectionEditForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
  k8sData: PropTypes.objectOf(PropTypes.any),
};

export default OutlierEjectionEditForm;
