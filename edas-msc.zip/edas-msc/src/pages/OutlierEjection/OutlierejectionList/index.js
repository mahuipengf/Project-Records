/**
 * Created by huangfushan on 2019-11-14
*/
import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { map, head } from 'lodash';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { modelDecorator, TableContainer, Button, Message } from '@ali/cn-design';
import confirm from 'components/Confirm';
import columns from './columns';
import services from 'services';
import Intro from './components/Introduction';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE } from 'constants';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import EditConfigModal from './components/EditConfigForm';
import EditAppModal from './components/EditAppForm';
import OutlierEjectionInfo from './components/OulierEjectionInfo';
import OutlierEjectionEditForm from './containers/OutlierEjectionEditForm';
import { upperFirstData } from 'utils/transfer-data';
import RoleHoc from 'containers/RoleHoc';

const OutlierEjectionList = (props) => {
  const { toggleModal, tableUniqueKey } = props;
  const intl = useIntl();
  const [refreshIndex, setRefreshIndex] = useState(undefined); // 手动触发表格更新
  const [searchValues] = useGlobalState('searchValues');
  const [showIntro, setShowIntro] = useState(undefined);
  const editConfigForm = useRef(null);
  const [autoFetch, setAutoFetch] = useState(false);
  const [visible, setVisible] = useState(false);
  const [currentValue, setCurrentValue] = useState({});

  useEffect(() => {
    setAutoFetch(true);
  }, []);

  const fetchData = async (params = {}) => {
    const newParams = {
      ...searchValues,
      ...params,
      currentPage: params.pageNumber,
    };
    // SAE嵌入离群摘除
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'sae') {
      const firstApp = head(searchValues.appList) || {};
      if (!firstApp.appName) {
        return {
          Data: [],
          TotalCount: 0,
        };
      }
      newParams.appName = firstApp.appName;
    }
    let res = await services.fetchOutlierEjectionList({ params: newParams });
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      res = upperFirstData(res);
    }
    const { Result = [], TotalSize = 0 } = res || {};
    if (TotalSize && TotalSize > 0) {
      setShowIntro(false);
    } else {
      setShowIntro(true);
    }

    const Data = map(Result, item => ({
      ...item,
      Protocol: item.RpcType, // rpcType 后续会慢慢统一改成 protocol
      Region: item.RegionId || searchValues.regionId,
      Namespace: item.NamespaceId || searchValues.namespaceId,
      ErrorRateThreshold: ((item.ErrorRateThreshold || 0) * 100).toFixed(0),
      MaxIsolationRate: ((item.MaxIsolationRate || 0) * 100).toFixed(0),
      MaxEjectionPercent: ((item.MaxEjectionPercent || 0) * 100).toFixed(0),
    }));
    return {
      Data,
      TotalCount: TotalSize,
    };
  };

  const handleCreate = (record = { Protocol: searchValues.rpcType || 25, Region: searchValues.regionId, Namespace: searchValues.namespaceId }) => {
    setCurrentValue({ ...record });
    setVisible(true);
  };

  const handleEditConfig = record => {
    toggleModal({
      size: 'large',
      type: 'slide',
      visible: true,
      title: intl('widget.outlier_ejection.edit_policy'),
      content: (
        <EditConfigModal
          ref={editConfigForm}
          value={record}
          setRefreshIndex={setRefreshIndex}
        />
      ),
      onConfirm: () => editConfigForm.current.handleSubmit(),
    });
  };

  const handleOpenInfo = (record) => {
    toggleModal({
      size: 'large',
      autoClose: true,
      // maskClick: () => console.log(1),
      type: 'slide',
      visible: true,
      title: intl('widget.outlier_ejection.info'),
      content: (
        <OutlierEjectionInfo
          value={record}
          handleEditApp={openEditApp}
          handleEditConfig={handleEditConfig}
        />
      ),
      onConfirm: null,
    });
  };

  const openEditApp = (record) => {
    toggleModal({
      size: 'large',
      autoClose: false,
      // maskClick: undefined,
      type: 'slide',
      visible: true,
      title: intl('widget.outlier_ejection.edit_policy'),
      content: (
        <EditAppModal
          ref={editConfigForm}
          value={record}
          setRefreshIndex={setRefreshIndex}
        />
      ),
      onConfirm: () => editConfigForm.current.handleSubmit(),
    });
  };

  const removeOutlierEjection = (record) => {
    const { PolicyId } = record;
    confirm({
      title: intl('widget.outlier_ejection.delete_policy'),
      content: intl('widget.outlier_ejection.delete_policy_confirm', { n: record.PolicyName }),
      onOk: async () => {
        const data = await services.removeOutlierEjection({
          data: { PolicyId },
        });
        Message.success(intl('widget.common.delete_successful'));
        setRefreshIndex(Date.now());
        return data;
      },
    });
  };


  const closeOutlierEjection = (record) => {
    const { PolicyId } = record;
    confirm({
      title: intl('widget.outlier_ejection.close_policy'),
      content: intl('widget.common.close_confirm', { name: record.PolicyName }),
      onOk: async () => {
        const data = await services.updateOutlierEjectionConfig({
          data: {
            PolicyId,
            IsOutlierEnabled: false,
          },
        });
        Message.success(intl('widget.common.close_successful'));
        setRefreshIndex(Date.now());
        return data;
      },
    });
  };


  const openOutlierEjection = (record) => {
    const { PolicyId } = record;
    confirm({
      title: intl('widget.outlier_ejection.open_policy'),
      content: intl('widget.common.open_confirm', { name: record.PolicyName }),
      onOk: async () => {
        const data = await services.updateOutlierEjectionConfig({
          data: {
            PolicyId,
            IsOutlierEnabled: true,
          }
        });
        Message.success(intl('widget.common.open_successful'));
        setRefreshIndex(Date.now());
        return data;
      },
    });
  };

  const searchs = {
    typeInfo: {
      types: [
        // { value: '', label: intl('widget.authentication.all_frame') },
        { value: 25, label: 'Spring Cloud' },
        { value: 7, label: 'Dubbo' },
      ],
      // defaultValue: searchValues.rpcType || '',
      defaultValue: 25,
      value: 'rpcType',
    },
    filterInfo: {
      filters: [
        {
          label: intl('widget.outlier_ejection.policy_name'),
          value: 'policyName',
          placeholder: intl('widget.outlier_ejection.policy_name_placeholder'),
        },
        {
          label: intl('widget.outlier_ejection.effect_app'),
          value: 'appName',
          placeholder: intl('widget.outlier_ejection.effect_app_placeholder'),
        },
      ],
      defaultValue: 'policyName',
    },
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };

  const searchs2 = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.outlier_ejection.policy_name'),
          value: 'policyName',
          placeholder: intl('widget.outlier_ejection.policy_name_placeholder'),
        },
        {
          label: intl('widget.outlier_ejection.effect_app'),
          value: 'appName',
          placeholder: intl('widget.outlier_ejection.effect_app_placeholder'),
        },
      ],
      defaultValue: 'policyName',
    },
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };

  const getcolumns = () => {
    const columnList = columns({
      handleEdit: handleEditConfig,
      handleRemove: removeOutlierEjection,
      handleClose: closeOutlierEjection,
      handleOpen: openOutlierEjection,
      openEditAppModal: openEditApp,
      handleOpenInfo,
    }, intl, MSC_WIDGET_CONSOLE_CONFIG.productName, searchValues.rpcType);
    return columnList;
  };

  if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'sae') {
    searchs.filterInfo.filters = [{
      label: intl('widget.outlier_ejection.policy_name'),
      value: 'policyName',
      placeholder: intl('widget.outlier_ejection.policy_name_placeholder'),
    }];
  }

  return (
    <React.Fragment>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && !IS_ENV_PRIVATE && (searchValues.rpcType === 7 || searchValues.rpcType === 25)}>
        <Message type="warning" style={{ marginBottom: 16 }} >{intl.html('widget.outlier_ejection.label')}</Message>
      </If>
      <TableContainer
        autoFetch={autoFetch}
        search={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? searchs2 : searchs}
        columns={getcolumns()}
        isUseStorage
        fetchData={fetchData}
        refreshIndex={refreshIndex}
        affixActionBar
        followTrigger
        primaryKey="Id"
        operation={() => (
          <Button type="primary" onClick={() => handleCreate()} style={{ marginRight: 8 }}>
            {intl('widget.outlier_ejection.create_policy')}
          </Button>
        )}
        emptyContent={
          <Actions expandTriggerType="hover" style={{ justifyContent: 'center' }}>
            <LinkButton key="1" onClick={() => handleCreate()}>{intl('widget.outlier_ejection.no_data_go_create')}</LinkButton>
          </Actions>
        }
      />
      <If condition={showIntro}>
        <Intro />
      </If>
      <OutlierEjectionEditForm
        value={currentValue}
        visible={visible}
        onClose={() => setVisible(false)}
        onOk={() => {
          setVisible(false);
          setRefreshIndex(Date.now());
        }}
      />
    </React.Fragment >
  );
};

OutlierEjectionList.propTypes = {
  toggleModal: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default RoleHoc(modelDecorator(OutlierEjectionList));

