/**
 * Created by huangfushan on 2019-11-14
*/
import React from 'react';
import { find, map, join, filter } from 'lodash';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { RPC_TYPE_DATA, RPC_TYPE } from '../constants';
import { CopyContent, Empty, Icon, Balloon } from '@ali/cn-design';
import Status from 'components/Status/CommonStatus';
import styles from './index.less';
import { Dubbo, SpringCloud, Istio } from 'components/Icon';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const ICON = {
  7: <Dubbo style={{ width: 16, minWidth: 16, marginRight: 4 }} />,
  25: <SpringCloud style={{ width: 16, minWidth: 16, marginRight: 4 }} />,
  26: <Istio />,
};

export default ({ handleEdit, handleRemove, openEditAppModal, handleOpenInfo, handleClose, handleOpen }, intl, productName, protocol) => {
  const columnList = [
    {
      key: 'PolicyName',
      title: intl('widget.outlier_ejection.policy_name'), // '策略名称',
      dataIndex: 'PolicyName',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <span className="link-primary" onClick={() => handleOpenInfo(record)}>{value}</span>
        </CopyContent>
      ),
      width: 160,
      visible: true,
    },
    {
      key: 'IsOutlierEnabled',
      title: intl('widget.common.state'), // '状态',
      dataIndex: 'IsOutlierEnabled',
      cell: value => <Status value={value} />,
      width: 100,
      visible: true,
    },
    {
      key: 'AppList',
      title: intl('widget.outlier_ejection.effect_app'), // '生效应用',
      dataIndex: 'AppList',
      cell: (value, index, record) => {
        const AppNames = map(value, n => n.AppName);
        return (
          <React.Fragment>
            <div className={styles.columns}>
              <Balloon align="t" trigger={<div className={styles.AppName}>{join(AppNames, ', ')}</div>}>
                {join(AppNames, ', ')}
              </Balloon>
              <Icon className={styles.icon} type="edit" size="small" onClick={() => openEditAppModal(record)} />
            </div>
          </React.Fragment>
        );
      },
      width: 200,
      visible: productName !== 'sae',
    },
    {
      key: 'RpcType',
      title: intl('widget.outlier_ejection.facing_this_frame'), // '针对框架',
      dataIndex: 'RpcType',
      cell: value => {
        const rpcTypeObj = find(RPC_TYPE_DATA(intl, MSC_WIDGET_CONSOLE_CONFIG.productName), ['value', value]) || {};
        return (
          <Empty value={value}>
            <div style={{ display: 'flex' }}>
              {ICON[value]}
              <span>{rpcTypeObj.label}</span>
            </div>
          </Empty>
        );
      },
      width: 100,
      visible: true,
    },
    {
      key: 'ShouldCountBizError',
      title: intl('widget.outlier_ejection.exception_type'), // '异常类型',
      dataIndex: 'ShouldCountBizError',
      cell: (value, index, record) => (
        <React.Fragment>
          <If condition={value}>
            <If condition={record.RpcType === RPC_TYPE.DUBBO}>
              {intl('widget.outlier_ejection.dubbo_network_abnormal')}
            </If>
            <If condition={record.RpcType === RPC_TYPE.SPRING_CLOUD}>
              {intl('widget.outlier_ejection.spring_cloud_network_abnormal')}
            </If>
          </If>
          <If condition={!value}>{intl('widget.outlier_ejection.network_abnormal')}</If>
        </React.Fragment>
      ),
      width: 200,
      visible: protocol !== 26,
    },
    {
      key: 'ErrorRateThreshold',
      title: intl('widget.outlier_ejection.error_rate_threshold2'), // '错误率阈值（%）',
      dataIndex: 'ErrorRateThreshold',
      width: 100,
      visible: protocol !== 26,
    },
    {
      key: 'RequestThreshold',
      title: intl('widget.outlier_ejection.QPS_threshold'), // 'QPS阈值'
      dataIndex: 'RequestThreshold',
      width: 100,
      visible: protocol !== 26,
    },
    {
      key: 'MaxIsolationRate',
      title: intl('widget.outlier_ejection.remove_rate_threshold2'), // '摘除机器比例阈值（%）',
      dataIndex: 'MaxIsolationRate',
      width: 100,
      visible: protocol !== 26,
    },
    {
      key: 'IsolationTime',
      title: intl('widget.outlier_ejection.recovery_unit_time2'), // '恢复检测单位时间（ms）',
      dataIndex: 'IsolationTime',
      width: 100,
      visible: protocol !== 26,
    },
    {
      key: 'MaxIsolationTimeMultiple',
      title: intl('widget.outlier_ejection.not_restored_times'), // 未恢复累计次数上限
      dataIndex: 'MaxIsolationTimeMultiple',
      width: 100,
      visible: protocol !== 26,
    },
    {
      key: 'IsolationTime',
      title: intl('widget.outlier_ejection.recovery_unit_time'),
      dataIndex: 'IsolationTime',
      width: 100,
      visible: protocol === 26,
    },
    {
      key: 'MaxEjectionPercent',
      title: intl('widget.outlier_ejection.exception_type'),
      dataIndex: 'MaxEjectionPercent',
      cell: () => intl('widget.outlier_ejection.5xx_exception'),
      width: 100,
      visible: protocol === 26,
    },
    {
      key: 'ConsecutiveErrors',
      title: intl('widget.outlier_ejection.continuou_error_times'),
      dataIndex: 'ConsecutiveErrors',
      width: 100,
      visible: protocol === 26,
    },
    {
      key: 'MaxConnections',
      title: intl('widget.outlier_ejection.max_connections_times'),
      dataIndex: 'MaxConnections',
      width: 100,
      visible: protocol === 26,
    },
    {
      key: 'Http1MaxPendingRequests',
      title: intl('widget.outlier_ejection.max_pending_request_times'),
      dataIndex: 'Http1MaxPendingRequests',
      width: 100,
      visible: protocol === 26,
    },
    {
      key: 'MaxRequestsPerConnection',
      title: intl('widget.outlier_ejection.single_link_max_request_times'),
      dataIndex: 'MaxRequestsPerConnection',
      width: 100,
      visible: protocol === 26,
    },
    {
      key: 'remark',
      title: intl('widget.common.operating'), // '操作',
      dataIndex: 'remark',
      cell: (value, index, record) => (
        <Actions>
          <LinkButton onClick={() => handleEdit(record)}>
            {intl('widget.common.edit')}
          </LinkButton>
          {/* <If condition={record.isOutlierEnabled}>
            <LinkButton onClick={() => handleClose(record)}>
              {intl('widget.common.close1')}
            </LinkButton>
          </If>
          <If condition={!record.isOutlierEnabled}>
            <LinkButton onClick={() => handleOpen(record)}>
              {intl('widget.common.open1')}
            </LinkButton>
          </If> */}
          <LinkButton onClick={() => handleRemove(record)}>
            {intl('widget.common.delete')}
          </LinkButton>
        </Actions>
      ),
      width: 140,
      visible: true,
    },
  ];

  return filter(columnList, item => item.visible);
};

