/**
 * Created by huangfushan on 2019-11-15
*/
import React, { useImperativeHandle, forwardRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Message } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import EffectiveAppTranfer from '../EffectiveAppTransfer';
import { lowerFirstData } from 'utils/transfer-data';

const EffectiveApp = (props, ref) => {
  const field = Field.useField();
  const intl = useIntl();
  const { value, setRefreshIndex } = props;
  const { init, validate } = field;

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));


  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        if (errors) return reject(errors);
        let params = {
          PolicyId: value.PolicyId,
          AppList: values.AppList,
        };
        if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
          params = {
            policyId: params.PolicyId,
            appList: params.AppList,
          };
        }
        await services.updateOutlierEjectionConfig({
          data: params,
          customErrorHandle: (error, respongse, callback) => {
            callback();
          }
        });
        Message.success(intl('widget.common.update_successful'));
        resolve();
        setRefreshIndex(Date.now());
      });
    });
  };

  return (
    <Form field={field}>
      <Form.Item required requiredMessage={intl('widget.outlier_ejection.select_effect_app')}>
        <EffectiveAppTranfer
          {...init('AppList', {
            initValue: value.AppList || [],
            rules: [
              {
                required: true,
                message: intl('widget.outlier_ejection.select_effect_app')
              },
            ],
          })}
          listStyle={{ width: 310, height: 300 }}
          Namespace={value.Namespace}
          Region={value.Region}
          Protocol={value.Protocol}
        />
      </Form.Item>
    </Form>
  );
};

const RefEffectiveApp = forwardRef(EffectiveApp);

EffectiveApp.propTypes = {
  setRefreshIndex: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
};

export default RefEffectiveApp;
