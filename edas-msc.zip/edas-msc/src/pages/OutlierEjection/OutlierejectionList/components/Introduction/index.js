import React from 'react';
import styles from './index.less';
import { useIntl } from '@ali/widget-hooks';
import { Collapse } from '@alicloud/console-components';

const { Panel } = Collapse;

const Intro = () => {
  const intl = useIntl();

  return (
    <div className={styles.intro}>
      <h4 className={styles.title}>{intl('widget.outlier_ejection.intro')}</h4>
      <Collapse>
        <Panel title={intl('widget.outlier_ejection.intro_title')}>
          <ul>
            <li className={styles.row}>
              {intl('widget.outlier_ejection.intro_li1')}
            </li>
            {/* <li className={styles.flex}>
              <span>{intl('widget.outlier_ejection.intro_consumer')}</span>
              <img src="https://img.alicdn.com/tfs/TB1Q12fnvb2gK0jSZK9XXaEgFXa-535-309.png" className={styles.img} />
              <div className={styles.flex}>
                <div className={styles.imageRightDiv}>
                  <p className={styles.p}>{intl('widget.outlier_ejection.intro_issue1')}</p>
                  <p className={styles.p}>{intl('widget.outlier_ejection.intro_issue2')}</p>
                  <p className={styles.p}>{intl('widget.outlier_ejection.intro_issue3')}</p>
                </div>
                <div className={styles.provider}>{intl('widget.outlier_ejection.intro_provider')}</div>
              </div>
            </li> */}
            <li className={{ marginTop: 16 }}>{intl('widget.outlier_ejection.intro_li2')}</li>
            <li className={styles.row}>{intl('widget.outlier_ejection.intro_li3')}</li>
            <li className={styles.row}>{intl('widget.outlier_ejection.intro_li4')}</li>
          </ul>
        </Panel>
      </Collapse>
    </div>
  );
};

export default Intro;
