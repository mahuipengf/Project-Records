/**
 * Created by huangfushan on 2019-11-15
*/
import React, { useImperativeHandle, forwardRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Radio, NumberPicker, Switch, Message, BalloonIcon } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { RPC_TYPE } from '../../../constants';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const EditConfigModal = (props, ref) => {
  const field = Field.useField();
  const { value, setRefreshIndex } = props;
  const intl = useIntl();
  const { init, validate, getValue } = field;

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  useEffect(() => {
    field.setValues(value);
  }, [value]);

  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        if (errors) return reject(errors);
        let params = {
          PolicyId: value.PolicyId,
          OutlierConfig: {},
        };
        if (value.Protocol === RPC_TYPE.DUBBO || value.Protocol === RPC_TYPE.SPRING_CLOUD) {
          params.OutlierConfig = {
            rpcType: values.Protocol,
            isOutlierEnabled: values.IsOutlierEnabled,
            errorRateThreshold: values.ErrorRateThreshold / 100,
            shouldCountBizError: values.ShouldCountBizError,
            requestThreshold: values.RequestThreshold,
            maxIsolationRate: values.MaxIsolationRate / 100,
            isolationTime: values.IsolationTime,
            maxIsolationTimeMultiple: values.MaxIsolationTimeMultiple,
          };
        }
        if (value.Protocol === RPC_TYPE.ISTIO) {
          params.OutlierConfig = {
            rpcType: values.Protocol,
            isOutlierEnabled: values.IsOutlierEnabled,
            maxEjectionPercent: values.MaxEjectionPercent / 100,
            isolationTime: values.IsolationTime,
            consecutiveErrors: values.ConsecutiveErrors,
            http1MaxPendingRequests: values.Http1MaxPendingRequests,
            maxRequestsPerConnection: values.MaxRequestsPerConnection,
            maxConnections: values.MaxConnections,
          };
        }

        if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
          params = {
            policyId: params.PolicyId,
            outlierConfigDO: params.OutlierConfig,
          };
        }
        await services.updateOutlierEjectionConfig({
          data: params,
          customErrorHandle: (error, respongse, callback) => {
            callback();
          }
        });
        Message.success(intl('widget.common.update_successful'));
        resolve();
        setRefreshIndex(Date.now());
      });
    });
  };

  const getShouldCountBizErrorData = () => {
    const shouldCountBizErrorData = [
      { value: false, label: intl('widget.outlier_ejection.network_abnormal') },
      {
        value: true,
        label: (
          <React.Fragment>
            <If condition={value.Protocol === RPC_TYPE.DUBBO}>
              {intl('widget.outlier_ejection.dubbo_network_abnormal')}
            </If>
            <If condition={value.Protocol === RPC_TYPE.SPRING_CLOUD}>
              {intl('widget.outlier_ejection.spring_cloud_network_abnormal')}
            </If>
          </React.Fragment>
        ),
      },
    ];
    return shouldCountBizErrorData;
  };

  return (
    <Form field={field} labelAlign="top">
      <If condition={value.Protocol === RPC_TYPE.DUBBO || value.Protocol === RPC_TYPE.SPRING_CLOUD}>
        <Form.Item label={intl('widget.outlier_ejection.open_state')} required>
          <Switch
            {...init('IsOutlierEnabled', {
              initValue: value.isOutlierEnabled,
              valueName: 'checked',
            })}
          />
        </Form.Item>
        <Form.Item label={intl('widget.outlier_ejection.exception_type')} required requiredMessage={intl('widget.outlier_ejection.select_exception_type')}>
          <Radio.Group
            {...init('ShouldCountBizError', {
              initValue: value.ShouldCountBizError,
              props: {
                onChange: v => field.setValue('ShouldCountBizError', v),
              },
            })}
            dataSource={getShouldCountBizErrorData()}
          />
        </Form.Item>
        <Form.Item
          label={
            <React.Fragment>
              <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.QPS_threshold')}</span>
              <BalloonIcon text={intl('widget.outlier_ejection.QPS_threshold_hint')} />
            </React.Fragment>
          }
          required
        >
          <NumberPicker
            min={0}
            max={1000000}
            style={{ width: '95%' }}
            {...init('RequestThreshold', {
              initValue: value.RequestThreshold,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.input_QPS_threshold'),
                },
              ],
            })}
            placeholder={intl('widget.outlier_ejection.non_negative_integer')}
          />
          <span style={{ marginLeft: 8 }}>s</span>
        </Form.Item>
        <Form.Item label={intl('widget.outlier_ejection.error_rate_threshold')} required>
          <NumberPicker
            min={0}
            max={100}
            style={{ width: '95%' }}
            placeholder="0~100"
            {...init('ErrorRateThreshold', {
              initValue: value.ErrorRateThreshold,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.input_error_rate_threshold'),
                },
              ],
            })}
          />
          <span style={{ marginLeft: 8 }}>%</span>
        </Form.Item>
        <Form.Item
          label={
            <React.Fragment>
              <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.remove_rate_threshold')}</span>
              <BalloonIcon text={intl('widget.outlier_ejection.remove_rate_threshold_hint')} />
            </React.Fragment>
          }
          required
          requiredMessage={intl('widget.outlier_ejection.input_remove_rate_threshold')}
        >
          <NumberPicker
            min={0}
            max={100}
            style={{ width: '95%' }}
            placeholder="0~100"
            {...init('MaxIsolationRate', {
              initValue: value.MaxIsolationRate,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.input_remove_rate_threshold'),
                },
              ],
            })}
          />
          <span style={{ marginLeft: 8 }}>%</span>
        </Form.Item>
        <Form.Item label={intl('widget.outlier_ejection.recovery_unit_time')} required>
          <NumberPicker
            min={1}
            max={100000000}
            style={{ width: '95%' }}
            placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
            {...init('IsolationTime', {
              initValue: value.IsolationTime,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.input_recovery_unit_time'),
                },
              ],
            })}
          />
          <span style={{ marginLeft: 8 }}>ms</span>
        </Form.Item>
        <Form.Item
          label={
            <React.Fragment>
              <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.not_restored_times')}</span>
              <BalloonIcon text={intl('widget.outlier_ejection.not_restored_times_hint')} />
            </React.Fragment>
          }
          required
        >
          <NumberPicker
            min={1}
            max={100000000}
            style={{ width: '95%' }}
            placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
            {...init('MaxIsolationTimeMultiple', {
              initValue: value.MaxIsolationTimeMultiple,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.input_not_restored_times'),
                },
              ],
            })}
          />
        </Form.Item>
      </If>
      <If condition={value.Protocol === RPC_TYPE.ISTIO}>
        <Form.Item label={intl('widget.outlier_ejection.open_state')} required>
          <Switch
            {...init('IsOutlierEnabled', {
              initValue: value.isOutlierEnabled,
              valueName: 'checked',
            })}
          />
        </Form.Item>
        <Form.Item label={intl('widget.outlier_ejection.exception_type')}>
          {intl('widget.outlier_ejection.5xx_exception')}
        </Form.Item>
        <Form.Item
          label={intl('widget.outlier_ejection.max_ejection_percent')}
          required
        >
          <NumberPicker
            min={0}
            max={100}
            style={{ width: '95%' }}
            placeholder="0~100"
            {...init('MaxEjectionPercent', {
              initValue: value.MaxEjectionPercent,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.please_entry_max_ejection_percent'),
                },
              ],
            })}
          />
          <span style={{ marginLeft: 8 }}>%</span>
        </Form.Item>
        <Form.Item label={intl('widget.outlier_ejection.recovery_unit_time')} required>
          <NumberPicker
            min={1}
            style={{ width: '95%' }}
            placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
            {...init('IsolationTime', {
              initValue: value.IsolationTime,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.input_recovery_unit_time'),
                },
              ],
            })}
          />
          <span style={{ marginLeft: 8 }}>ms</span>
        </Form.Item>
        <Form.Item
          label={intl('widget.outlier_ejection.continuou_error_times')}
          required
        >
          <NumberPicker
            min={1}
            style={{ width: 608 }}
            placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
            {...init('ConsecutiveErrors', {
              initValue: value.ConsecutiveErrors,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.please_continuou_error_times'),
                },
              ],
            })}
          />
        </Form.Item>
        <Form.Item
          label={intl('widget.outlier_ejection.max_connections_times')}
          required
        >
          <NumberPicker
            min={1}
            style={{ width: '95%' }}
            placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
            {...init('MaxConnections', {
              initValue: value.MaxConnections,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.please_intry_max_connections_times'),
                },
              ],
            })}
          />
        </Form.Item>
        <Form.Item
          label={intl('widget.outlier_ejection.max_pending_request_times')}
          required
        >
          <NumberPicker
            min={1}
            style={{ width: '95%' }}
            placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
            {...init('Http1MaxPendingRequests', {
              initValue: value.Http1MaxPendingRequests,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.please_entry_max_pending_request_times'),
                },
              ],
            })}
          />
        </Form.Item>
        <Form.Item
          label={intl('widget.outlier_ejection.single_link_max_request_times')}
          required
        >
          <NumberPicker
            min={1}
            style={{ width: '95%' }}
            placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
            {...init('MaxRequestsPerConnection', {
              initValue: value.MaxRequestsPerConnection,
              rules: [
                {
                  required: true,
                  message: intl('widget.outlier_ejection.please_entry_single_link_max_request_times'),
                },
              ],
            })}
          />
        </Form.Item>
      </If>
    </Form>
  );
};

const RefEditConfitModal = forwardRef(EditConfigModal);

EditConfigModal.propTypes = {
  setRefreshIndex: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
};

export default RefEditConfitModal;
