/**
 * Created by huangfushan on 2019-11-12
*/
import React, { useEffect, useState } from 'react';
import { map, filter, includes, unionBy, get } from 'lodash';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import { Transfer, Icon } from '@alife/dpl-console-design-2019';
import services from 'services';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { upperFirstData } from 'utils/transfer-data';

const EffectiveAppTranfer = (props) => {
  const intl = useIntl();
  const {
    onChange,
    Namespace,
    Region,
    Protocol,
    value = [],
    listStyle,
  } = props;
  const [appList, setAppList] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchApplications();
  }, [Protocol, Region, Namespace]);

  const fetchApplications = async () => {
    if (!Protocol || !Region) return;
    setLoading(true);
    const params = { Region, Namespace, RpcType: Protocol };
    let Data = await services.fetchApplicationsByRpcType({
      params: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? { regionId: params.Region, namespaceId: params.Namespace, rpcType: params.RpcType } : params,
      customErrorHandle: (error, response, callback) => {
        setLoading(false);
        callback();
      }
    });
    setLoading(false);
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      Data = get(upperFirstData(Data), 'Data', []);
    }
    Data = unionBy(Data, value, 'AppId');
    setAppList(Data);
  };

  const handleChange = (list) => {
    const selectedAppList = filter(appList, n => includes(list, n.AppId));
    onChange && onChange(selectedAppList);
  };

  const RefreshRender = () => (
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span>{intl('widget.outlier_ejection.create.select_effect_app')}</span>
      <Icon type="refresh" size="small" style={{ cursor: 'pointer' }} onClick={fetchApplications} />
    </div>
  );

  return (
    <Transfer
      disabled={loading}
      notFoundContent={intl('widget.outlier_ejection.not_fount_content')}
      showSearch
      listStyle={listStyle}
      value={map(value, n => n.AppId)}
      dataSource={map(unionBy(appList, value, 'AppId'), n => ({ label: n.AppName, value: n.AppId }))}
      onChange={handleChange}
      titles={[RefreshRender(), intl('widget.outlier_ejection.selected_effect_app')]}
    />
  );
};

EffectiveAppTranfer.propTypes = {
  onChange: PropTypes.func,
  Namespace: PropTypes.string,
  Region: PropTypes.string,
  Protocol: PropTypes.number,
  value: PropTypes.arrayOf(PropTypes.string),
  listStyle: PropTypes.shape(),
};

export default EffectiveAppTranfer;
