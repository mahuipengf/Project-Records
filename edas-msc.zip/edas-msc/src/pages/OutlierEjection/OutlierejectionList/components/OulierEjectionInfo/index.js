import React from 'react';
import DataFields from 'components/DataFields';
import { Empty, CopyContent, Balloon } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import { join, map } from 'lodash';
import styles from './index.less';
import ConfigInfo from './ConfigInfo';
import CommonEvent from 'components/CommonEvent';
import Status from 'components/Status/CommonStatus';


const BasicInfo = ({ value = {}, handleEditApp, handleEditConfig }) => {
  const intl = useIntl();
  const PROTOCOL_DATA = {
    7: 'Dubbo',
    25: 'Spring Cloud',
    26: intl('widget.service.service_mesh')
  };
  const items = [
    {
      dataIndex: 'PolicyName',
      label: intl('widget.outlier_ejection.policy_name'),
      render: val => {
        return (
          <Empty value={val}>
            <CopyContent text={val}>
              {val}
            </CopyContent>
          </Empty>
        );
      },
      visible: true
    },
    {
      dataIndex: 'Protocol',
      label: intl('widget.outlier_ejection.facing_this_frame'),
      render: val => <Empty value={PROTOCOL_DATA[val]}>{PROTOCOL_DATA[val]}</Empty>,
      visible: true
    },
    {
      dataIndex: 'AppList',
      label: intl('widget.outlier_ejection.effect_app'),
      render: (val) => {
        const AppNames = map(val, n => n.AppName);
        return (
          <React.Fragment>
            <div className={styles.columns}>
              <Balloon align="t" trigger={<div className={styles.appName}>{join(AppNames, ', ')}</div>}>
                {join(AppNames, ', ')}
              </Balloon>
              <If condition={handleEditApp}>
                <CommonEvent type="edit" text={intl('widget.common.edit')} onClick={() => handleEditApp(value)} style={{ marginLeft: 8 }} />
              </If>
            </div>
          </React.Fragment>
        );
      },
      visible: true,
    },
    {
      dataIndex: 'IsOutlierEnabled',
      label: intl('widget.common.state'),
      render: val => <Status value={val} />,
      visible: true,
    },
  ];

  return (
    <div>
      <DataFields
        title={intl('widget.common.basic_info')}
        dataSource={value}
        items={items}
      />
      <ConfigInfo value={value} handleEditConfig={handleEditConfig} />
    </div>
  );
};

BasicInfo.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  handleEditApp: PropTypes.func,
  handleEditConfig: PropTypes.func,
};

export default BasicInfo;
