import React from 'react';
import DataFields from 'components/DataFields';
import { Empty } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import { RPC_TYPE } from '../../../constants';
import CommonEvent from 'components/CommonEvent';

const ConfigInfo = ({ value = {}, handleEditConfig, style }) => {
  const intl = useIntl();

  const confitItems = [
    {
      label: intl('widget.outlier_ejection.exception_type'),
      dataIndex: 'ShouldCountBizError',
      render: (val) => (
        <React.Fragment>
          <If condition={val}>
            <If condition={value.Protocol === RPC_TYPE.DUBBO}>
              {intl('widget.outlier_ejection.dubbo_network_abnormal')}
            </If>
            <If condition={value.Protocol === RPC_TYPE.SPRING_CLOUD}>
              {intl('widget.outlier_ejection.spring_cloud_network_abnormal')}
            </If>
          </If>
          <If condition={!val}>{intl('widget.outlier_ejection.network_abnormal')}</If>
        </React.Fragment>
      ),
      visible: value.Protocol === RPC_TYPE.DUBBO || value.Protocol === RPC_TYPE.SPRING_CLOUD,
    },
    {
      label: intl('widget.outlier_ejection.QPS_threshold'),
      dataIndex: 'RequestThreshold',
      render: val => <Empty value={val}>{`${val} s`}</Empty>,
      visible: value.Protocol === RPC_TYPE.DUBBO || value.Protocol === RPC_TYPE.SPRING_CLOUD,
    },
    {
      label: intl('widget.outlier_ejection.error_rate_threshold'),
      dataIndex: 'ErrorRateThreshold',
      render: val => <Empty value={val}>{`${val} %`}</Empty>,
      visible: value.Protocol === RPC_TYPE.DUBBO || value.Protocol === RPC_TYPE.SPRING_CLOUD,
    },
    {
      label: intl('widget.outlier_ejection.remove_rate_threshold'),
      dataIndex: 'MaxIsolationRate',
      render: val => <Empty value={val}>{`${val} %`}</Empty>,
      visible: value.Protocol === RPC_TYPE.DUBBO || value.Protocol === RPC_TYPE.SPRING_CLOUD,
    },
    {
      label: intl('widget.outlier_ejection.recovery_unit_time'),
      dataIndex: 'IsolationTime',
      render: val => <Empty value={val}>{`${val} ms`}</Empty>,
      visible: value.Protocol === RPC_TYPE.DUBBO || value.Protocol === RPC_TYPE.SPRING_CLOUD,
    },
    {
      label: intl('widget.outlier_ejection.not_restored_times'),
      dataIndex: 'MaxIsolationTimeMultiple',
      visible: value.Protocol === RPC_TYPE.DUBBO || value.Protocol === RPC_TYPE.SPRING_CLOUD,
    },
    {
      label: intl('widget.outlier_ejection.exception_type'),
      dataIndex: 'ShouldCountBizError',
      render: () => intl('widget.outlier_ejection.5xx_exception'),
      visible: value.Protocol === RPC_TYPE.ISTIO,
    },
    {
      label: intl('widget.outlier_ejection.max_ejection_percent'),
      dataIndex: 'MaxEjectionPercent',
      render: val => <Empty value={val}>{`${val} %`}</Empty>,
      visible: value.Protocol === RPC_TYPE.ISTIO,
    },
    {
      label: intl('widget.outlier_ejection.recovery_unit_time'),
      dataIndex: 'IsolationTime',
      render: val => <Empty value={val}>{`${val} ms`}</Empty>,
      visible: value.Protocol === RPC_TYPE.ISTIO,
    },
    {
      label: intl('widget.outlier_ejection.continuou_error_times'),
      dataIndex: 'ConsecutiveErrors',
      render: val => <Empty value={val}>{val}</Empty>,
      visible: value.Protocol === RPC_TYPE.ISTIO,
    },
    {
      label: intl('widget.outlier_ejection.max_connections_times'),
      dataIndex: 'MaxConnections',
      render: val => <Empty value={val}>{val}</Empty>,
      visible: value.Protocol === RPC_TYPE.ISTIO,
    }, {
      label: intl('widget.outlier_ejection.max_pending_request_times'),
      dataIndex: 'Http1MaxPendingRequests',
      render: val => <Empty value={val}>{val}</Empty>,
      visible: value.Protocol === RPC_TYPE.ISTIO,
    }, {
      label: intl('widget.outlier_ejection.single_link_max_request_times'),
      dataIndex: 'MaxRequestsPerConnection',
      render: val => <Empty value={val}>{val}</Empty>,
      visible: value.Protocol === RPC_TYPE.ISTIO,
    },
  ];

  return (
    <div style={{ width: 680, ...style }}>
      <div style={{ display: 'flex', alignItems: 'center', marginTop: 8, }}>
        <h4 className="common-title" style={{ width: 144, }}>{intl('widget.outlier_ejection.create.strategy_config')}</h4>
        <If condition={handleEditConfig}>
          <CommonEvent style={{ marginTop: 8 }} type="edit" text={intl('widget.common.edit')} onClick={() => handleEditConfig(value)} />
        </If>
      </div>
      <DataFields
        dataSource={value}
        items={confitItems}
      />
    </div>
  );
};

ConfigInfo.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  style: PropTypes.objectOf(PropTypes.any),
  handleEditConfig: PropTypes.func,
};

export default ConfigInfo;
