/**
 * Created by huangfushan on 2019-11-12
*/
import React, { useEffect, useState } from 'react';
import { map, filter, includes, unionBy, get } from 'lodash';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import { Transfer, Icon } from '@alife/dpl-console-design-2019';
import services from 'services';
import { lowerFirstData } from 'utils/transfer-data';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const EffectiveAppTranfer = (props) => {
  const intl = useIntl();
  const {
    onChange,
    namespaceId,
    regionId,
    rpcType,
    value = [],
    handleChangeLoading,
    listStyle,
    refreshTime = 0,
  } = props;
  const [appList, setAppList] = useState([]);

  useEffect(() => {
    fetchApplications();
  }, [refreshTime]);

  const fetchApplications = async () => {
    handleChangeLoading && handleChangeLoading(true);
    const params = { regionId, namespaceId, rpcType };
    const res = await services.fetchApplicationsByRpcType({
      params,
      customErrorHandle: (error, response, callback) => {
        handleChangeLoading(false);
        callback();
      }
    });
    handleChangeLoading(false);
    const data = lowerFirstData(res) || [];
    let newAppList = [];
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      const newData = get(data, 'data');
      newAppList = unionBy(newData, value, 'appId');
    } else {
      newAppList = unionBy(data, value, 'appId');
    }
    setAppList(newAppList);
  };
  const handleChange = (list) => {
    const selectedAppList = filter(appList, n => includes(list, n.appId));
    onChange && onChange(selectedAppList);
  };

  const RefreshRender = () => (
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <span>{intl('widget.outlier_ejection.create.select_effect_app')}</span>
      <Icon type="refresh" size="small" style={{ cursor: 'pointer' }} onClick={fetchApplications} />
    </div>
  );
  return (
    <Transfer
      notFoundContent={intl('widget.outlier_ejection.not_fount_content')}
      showSearch
      listStyle={listStyle}
      value={map(value, n => n.appId)}
      dataSource={map(appList, n => ({ label: n.appName, value: n.appId }))}
      onChange={handleChange}
      titles={[RefreshRender(), intl('widget.outlier_ejection.selected_effect_app')]}
    />
  );
};

EffectiveAppTranfer.propTypes = {
  onChange: PropTypes.func,
  namespaceId: PropTypes.string,
  regionId: PropTypes.string,
  rpcType: PropTypes.number,
  value: PropTypes.arrayOf(PropTypes.string),
  listStyle: PropTypes.shape(),
  handleChangeLoading: PropTypes.func,
  refreshTime: PropTypes.number,
};

export default EffectiveAppTranfer;
