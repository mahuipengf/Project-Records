import React from 'react';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.less';
import PropTypes from 'prop-types';

const RecoveryTimeline = (props) => {
  const { value } = props;
  const intl = useIntl();
  const { maxIsolationTimeMultiple: n = 0, isolationTime: x = 0 } = value;

  const getRender = () => {
    const arr = [];
    for (let i = 1; i < n; i++) {
      arr.push(
        <div className={styles.flex1} key={i}>
          <div className={styles.title}>{intl('widget.outlier_ejection.recover', { n: i })}</div>
          <div className={styles.orange}>{`${i + 1} * ${x} ms`}</div>
        </div>
      );
    }
    return arr;
  };
  return (
    <div className={styles.recoveryTimeLine}>
      <If condition={!n || n > 5}>
        <div className={styles.flex1}>
          <div className={styles.title}>{intl('widget.outlier_ejection.recover.remove_time')}</div>
          <div className={styles.orange}>{`1 * ${x} ms`}</div>
        </div>
        <div className={styles.flex1}>
          <div className={styles.title}>{intl('widget.outlier_ejection.recover.1')}</div>
          <div className={styles.orange}>{`2 * ${x} ms`}</div>
        </div>
        <div className={styles.flex1}>
          <div className={styles.title}>{intl('widget.outlier_ejection.recover.2')}</div>
          <div className={styles.orange}>{`3 * ${x} ms`}</div>
        </div>
        <div className={styles.flex1}>
          <div className={styles.title}>{intl('widget.outlier_ejection.recover.3')}</div>
          <div className={styles.gray}>{}</div>
        </div>
        <div className={styles.flex1}>
          <div className={styles.title} />
          <div className={styles.orange}>{`n * ${x} ms`}</div>
        </div>
        <div className={styles.flex1}>
          <div className={styles.title}>{intl('widget.outlier_ejection.recover.n')}</div>
          <div className={styles.orange}>{`(n+1) * ${x} ms`}</div>
        </div>
        <div className={styles.flex1}>
          <div className={styles.title} />
          <div className={styles.gray} />
        </div>
        <div className={styles.flex1}>
          <div className={styles.title} />
          <div className={styles.orange}>{`${n} * ${x} ms`}</div>
        </div>
        <div>
          <div className={styles.title}>{intl('widget.outlier_ejection.recover.total_times')}</div>
        </div>
      </If>
      <If condition={n > 0 && n <= 5}>
        <div className={styles.flex1}>
          <div className={styles.title}>{intl('widget.outlier_ejection.recover.remove_time')}</div>
          <div className={styles.orange}>{`1 * ${x} ms`}</div>
        </div>
        {getRender()}
        <div className={styles.title}>{intl('widget.outlier_ejection.recover', { n })}</div>
      </If>
    </div>
  );
};

RecoveryTimeline.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
};

export default RecoveryTimeline;

