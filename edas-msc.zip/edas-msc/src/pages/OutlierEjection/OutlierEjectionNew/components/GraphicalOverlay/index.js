import React, { useState } from 'react';
import { Balloon, Icon } from '@ali/cn-design';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import styles from './index.less';

const Graphical = () => {
  const intl = useIntl();
  const [isOpen, setIsOpen] = useState(false);
  const [isNeedOpenGraphical, setIsNeedOpenGraphical] = useGlobalState('isNeedOpenGraphical');

  const handleClose = () => {
    isNeedOpenGraphical && setIsNeedOpenGraphical(false);
    isOpen && setIsOpen(false);
  };

  const handleOpen = () => {
    !isOpen && setIsOpen(true);
  };

  const bool = isNeedOpenGraphical || isOpen;
  return (
    <div className={styles.graphical}>
      <div className={styles.header}>
        <span className={styles.title}>{intl('widget.outlier_ejection.effective_sketch')}</span>
        <If condition={!bool}>
          <Icon
            type="add"
            onClick={handleOpen}
            size="small"
            style={{ cursor: 'pointer', color: '#999' }}
          />
        </If>
        <If condition={bool}>
          <Icon
            type="subtract"
            onClick={handleClose}
            size="small"
            style={{ cursor: 'pointer', color: '#999' }}
          />
        </If>
      </div>
      <If condition={bool}>
        <div className={styles.container}>
          <img src="https://img.alicdn.com/tfs/TB1Q12fnvb2gK0jSZK9XXaEgFXa-535-309.png" className={styles.img} />
          <div className={styles.label}>{intl('widget.outlier_ejection.effective_sketch_label')}</div>
        </div>
        <div className={styles.info}>
          <span>{intl('widget.outlier_ejection.effective_sketch_detail1')}</span>
          <Balloon align="t" trigger={<span className={styles.detail}>{intl('widget.outlier_ejection.effective_sketch_detail')}</span>}>
            {intl('widget.outlier_ejection.effective_sketch_detail2')}
          </Balloon>
        </div>
      </If>
    </div>
  );
};

export default Graphical;
