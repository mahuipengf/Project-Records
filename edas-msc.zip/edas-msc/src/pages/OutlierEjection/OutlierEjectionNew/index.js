/**
 * Created by huangfushan on 2019-11-11
*/
import React, { useState, useEffect } from 'react';
import { Step, Loading } from '@ali/cn-design';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import CreateBasicInfo from './containers/BasicInfo';
import EffectiveApp from './containers/EffectiveApp';
import Config from './containers/CreateConfig';
import CreateComplete from './containers/CreateComplete';
import { DEFAULT_INFO } from '../constants';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

import './index.less';

const CreateStrategy = () => {
  const intl = useIntl();
  const [current, setCurrent] = useState(0);
  const [isConfirmLoading, setIsConfirmLoading] = useState(false);
  const [editValues] = useGlobalState('editValues');

  const [formValues, setFormValues] = useState({
    ...DEFAULT_INFO,
    ...editValues,
  });

  useEffect(() => {
    if (current === 0 && MSC_WIDGET_CONSOLE_CONFIG.productName !== 'sae') {
      setFormValues({ ...formValues, appList: [] });
    }
  }, [current]);

  const nextStep = (values) => {
    setFormValues(values);
    setCurrent(current + 1);
  };
  const preStep = () => {
    setCurrent(current - 1);
  };

  const handleChangeStep = (step) => {
    if (step < current) setCurrent(step);
  };

  const steps = [
    {
      title: intl('widget.outlier_ejection.create.basic_info'), // 基本信息
      key: 'createBasicApp',
    },
    {
      title: intl('widget.outlier_ejection.create.select_effect_app'), // 选择生效应用
      key: 'createEnv',
    },
    {
      title: intl('widget.outlier_ejection.create.strategy_config'), // 配置策略
      key: 'createConfig',
    },
    {
      title: intl('widget.outlier_ejection.create.complete'), // 创建完成
      key: 'completeCreate',
    },
  ];

  const saeSteps = [
    {
      title: intl('widget.outlier_ejection.create.basic_info'), // 基本信息
      key: 'createBasicApp',
    },
    {
      title: intl('widget.outlier_ejection.create.strategy_config'), // 配置策略
      key: 'createConfig',
    },
    {
      title: intl('widget.outlier_ejection.create.complete'), // 创建完成
      key: 'completeCreate',
    },
  ];
  return (
    <Loading visible={isConfirmLoading} style={{ marginTop: 16, width: '100%' }} >
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'sae'}>
        <Step current={current} shape="circle" labelPlacement="hoz">
          <For each="item" index="index" of={saeSteps}>
            <Step.Item
              key={item.key}
              title={item.title}
              onClick={() => handleChangeStep(index)}
            />
          </For>
        </Step>
        <div className="create-strategy">
          <Choose>
            <When condition={current === 0}>
              <CreateBasicInfo nextStep={nextStep} value={formValues} />
            </When>
            <When condition={current === 1}>
              <Config preStep={preStep} nextStep={nextStep} value={formValues} />
            </When>
            <Otherwise>
              <CreateComplete preStep={preStep} setIsConfirmLoading={setIsConfirmLoading} value={formValues} />
            </Otherwise>
          </Choose>
        </div>
      </If>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName !== 'sae'}>
        <Step current={current} shape="circle" labelPlacement="hoz">
          <For each="item" index="index" of={steps}>
            <Step.Item
              key={item.key}
              title={item.title}
              onClick={() => handleChangeStep(index)}
            />
          </For>
        </Step>
        <div className="create-strategy">
          <Choose>
            <When condition={current === 0}>
              <CreateBasicInfo nextStep={nextStep} value={formValues} />
            </When>
            <When condition={current === 1}>
              <EffectiveApp preStep={preStep} nextStep={nextStep} value={formValues} />
            </When>
            <When condition={current === 2}>
              <Config preStep={preStep} nextStep={nextStep} value={formValues} />
            </When>
            <Otherwise>
              <CreateComplete preStep={preStep} setIsConfirmLoading={setIsConfirmLoading} value={formValues} />
            </Otherwise>
          </Choose>
        </div>
      </If>
    </Loading>
  );
};

export default CreateStrategy;
