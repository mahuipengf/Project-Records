/**
 * Created by huangfushan on 2019-11-15
*/
import React, { useState } from 'react';
import { Form, Radio, Input } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { MSC_WIDGET_CONSOLE_CONFIG, NNAME_PATTERN } from 'constants';
import { RPC_TYPE_DATA } from '../../../constants';
import { useIntl } from '@ali/widget-hooks';
import { isEmpty, find, get, map } from 'lodash';
import { Namespace } from '@ali/mamba-namespace';
import services from 'services';
import PropTypes from 'prop-types';

const BasicInfo = (props) => {
  const field = Field.useField();
  const { value, nextStep } = props;
  const intl = useIntl();
  const { init, validate, setValues } = field;
  const [regions, setRegions] = useState([]);
  const [namespaces, setNamespaces] = useState([]);

  const handleSubmit = () => {
    validate((errors, values) => {
      if (!isEmpty(errors)) return;
      const namespaceId = get(values, 'namespaces.namespaceId');
      const regionId = get(values, 'namespaces.regionId');
      const namespace = find(namespaces, ['namespaceId', namespaceId]) || {};
      const region = find(regions, ['regionId', regionId]) || {};
      const namespaceNames = {
        regionName: region.regionName,
        namespaceName: namespace.namespaceName,
      };
      nextStep && nextStep({ ...value, ...values, ...namespaceNames });
    });
  };

  const checkPolicyName = (rule, val, callback) => {
    if (!NNAME_PATTERN.test(val)) {
      callback(intl('widget.outlier_ejection.name_pattern'));
    } else {
      callback();
    }
  };

  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    setRegions(newData);
    return newData;
  };

  const fetchNamespaces = async (regionId) => {
    const { data = [] } = await services.fetchNamespaces({ params: { regionId } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    setNamespaces(newData);
    return newData;
  };

  return (
    <Form field={field}>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
        <Form.Item label={intl('widget.common.microservice_space')} required>
          <Namespace
            {...init('namespaces', {
              initValue: { regionId: value.regionId, namespaceId: value.namespaceId },
              rules: [
                {
                  required: true,
                  message: intl('widget.common.please_select_microservice_space'),
                },
              ],
              props: {
                onChange: v => setValues(v),
              },
            })}
            fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
            fetchNamespaces={fetchNamespaces}
          />
        </Form.Item>
      </If>
      <Form.Item label={intl('widget.outlier_ejection.policy_name')} required>
        <Input
          style={{ width: 608 }}
          maxLength={64}
          showLimitHint
          placeholder={intl('widget.outlier_ejection.input_policy_name')}
          {...init('policyName', {
            initValue: value.policyName,
            rules: [
              {
                required: true,
                message: intl('widget.outlier_ejection.input_policy_name'),
              },
              {
                validator: checkPolicyName
              }
            ],
          })}
        />
      </Form.Item>
      <Form.Item label={intl('widget.outlier_ejection.use_frame')} required requiredMessage={intl('widget.outlier_ejection.select_use_frame')}>
        <Radio.Group
          dataSource={RPC_TYPE_DATA(intl, MSC_WIDGET_CONSOLE_CONFIG.productName)}
          name="rpcType"
          defaultValue={value.rpcType}
        />
      </Form.Item>
      {/* <Form.Item label={intl('离群摘除策略描述')}>
        <Input.TextArea
          style={{ width: 608 }}
          maxLength={64}
          showLimitHint
          {...init('policyDescription', {
            initValue: value.policyDescription,
            rules: [
              {
                required: true,
                message: intl('请输入描述'),
              },
            ],
          })}
        />
      </Form.Item> */}
      <Form.Item>
        <Form.Submit validate type="primary" onClick={handleSubmit}>
          {intl('widget.common.aliyun-widget_step')}
        </Form.Submit>
      </Form.Item>
    </Form>
  );
};

BasicInfo.propTypes = {
  nextStep: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
};

export default BasicInfo;
