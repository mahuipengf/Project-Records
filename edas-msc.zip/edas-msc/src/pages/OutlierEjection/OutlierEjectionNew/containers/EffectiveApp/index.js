/**
 * Created by huangfushan on 2019-11-12
*/
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { isEmpty } from 'lodash';
import { Form, Button, Loading } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import EffectiveAppTranfer from '../../components/EffectiveAppTransfer';
import Graphical from '../../components/GraphicalOverlay';
import { useIntl } from '@ali/widget-hooks';

const EffectiveApp = (props) => {
  const field = Field.useField();
  const intl = useIntl();
  const [isLoading, setIsLoading] = useState(false);
  const { value, nextStep, preStep } = props;
  const { validate } = field;

  const handleChangeLoading = (bool) => setIsLoading(bool);

  const handleSubmit = () => {
    validate((errors, values) => {
      if (!isEmpty(errors)) return;
      nextStep && nextStep({ ...value, ...values });
    });
  };

  const handlePreStep = () => {
    preStep && preStep({ ...value, appList: [] });
  };

  return (
    <Loading visible={isLoading}>
      <Form field={field}>
        <Form.Item required requiredMessage={intl('widget.outlier_ejection.select_effect_app')}>
          <EffectiveAppTranfer
            listStyle={{ width: 344, height: 300 }}
            namespaceId={value.namespaceId}
            regionId={value.regionId}
            rpcType={value.rpcType}
            name="appList"
            defaultValue={value.appList}
            handleChangeLoading={handleChangeLoading}
          />
        </Form.Item>
        <Form.Item>
          <Button type="normal" onClick={handlePreStep} style={{ marginRight: 8 }}>
            {intl('widget.common.pre_step')}
          </Button>
          <Form.Submit validate type="primary" onClick={handleSubmit}>
            {intl('widget.common.aliyun-widget_step')}
          </Form.Submit>
        </Form.Item>
      </Form>
      <Graphical />
    </Loading>
  );
};

EffectiveApp.propTypes = {
  nextStep: PropTypes.func,
  preStep: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
};

export default EffectiveApp;
