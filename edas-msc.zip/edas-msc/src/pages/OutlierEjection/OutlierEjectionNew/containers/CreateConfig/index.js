/**
 * Created by huangfushan on 2019-11-12
*/
import React from 'react';
import PropTypes from 'prop-types';
import { isEmpty } from 'lodash';
import { Form, Radio, Button, NumberPicker, BalloonIcon } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { RPC_TYPE } from 'pages/OutlierEjection/constants';
import RecoveryTimeline from '../../components/RecoveryTimeline';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.less';

const Config = (props) => {
  const field = Field.useField();
  const { value, preStep } = props;
  const intl = useIntl();
  const { init, validate, getValues } = field;

  const handleSubmit = () => {
    validate((errors, values) => {
      if (!isEmpty(errors)) return;
      const { nextStep } = props;
      nextStep && nextStep({ ...value, ...values });
    });
  };

  const getShouldCountBizErrorData = () => {
    const shouldCountBizErrorData = [
      { value: false, label: intl('widget.outlier_ejection.network_abnormal') },
      {
        value: true,
        label: (
          <React.Fragment>
            <If condition={value.rpcType === RPC_TYPE.DUBBO}>
              {intl('widget.outlier_ejection.dubbo_network_abnormal')}
            </If>
            <If condition={value.rpcType === RPC_TYPE.SPRING_CLOUD}>
              {intl('widget.outlier_ejection.spring_cloud_network_abnormal')}
            </If>
          </React.Fragment>
        ),
      },
    ];
    return shouldCountBizErrorData;
  };

  return (
    <React.Fragment>
      <Form field={field}>
        <If condition={value.rpcType === RPC_TYPE.DUBBO || value.rpcType === RPC_TYPE.SPRING_CLOUD}>
          <Form.Item label={intl('widget.outlier_ejection.exception_type')} required requiredMessage={intl('widget.outlier_ejection.select_exception_type')}>
            <Radio.Group
              {...init('shouldCountBizError', {
                initValue: value.shouldCountBizError,
              })}
              dataSource={getShouldCountBizErrorData()}
            />
          </Form.Item>
          <Form.Item
            label={
              <React.Fragment>
                <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.QPS_threshold')}</span>
                <BalloonIcon
                  text={intl('widget.outlier_ejection.QPS_threshold_hint')}
                />
              </React.Fragment>
            }
            required
          >
            <NumberPicker
              min={0}
              style={{ width: 608 }}
              {...init('requestThreshold', {
                initValue: value.requestThreshold,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.input_QPS_threshold'),
                  },
                ],
              })}
              placeholder={intl('widget.outlier_ejection.non_negative_integer')}
            />
            <span style={{ marginLeft: 8 }}>s</span>
          </Form.Item>
          <Form.Item
            label={
              <React.Fragment >
                <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.error_rate_threshold')}</span>
                <BalloonIcon text={intl('widget.outlier_ejection.error_rate_threshold_hint')} />
              </React.Fragment>
            }
            required
          >
            <NumberPicker
              min={0}
              max={100}
              style={{ width: 608 }}
              placeholder="0~100"
              {...init('errorRateThreshold', {
                initValue: value.errorRateThreshold,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.input_error_rate_threshold'),
                  },
                ],
              })}
            />
            <span style={{ marginLeft: 8 }}>%</span>
          </Form.Item>
          <Form.Item
            label={
              <React.Fragment>
                <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.remove_rate_threshold')}</span>
                <BalloonIcon text={intl('widget.outlier_ejection.remove_rate_threshold_hint')} />
              </React.Fragment>
            }
            required
          >
            <NumberPicker
              min={0}
              max={100}
              style={{ width: 608 }}
              placeholder="0~100"
              {...init('maxIsolationRate', {
                initValue: value.maxIsolationRate,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.input_remove_rate_threshold'),
                  },
                ],
              })}
            />
            <span style={{ marginLeft: 8 }}>%</span>
          </Form.Item>
          <div className={styles.strategyConfig}>
            <Form.Item label={intl('widget.outlier_ejection.recovery_unit_time')} required>
              <NumberPicker
                min={1}
                style={{ width: 608 }}
                placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
                {...init('isolationTime', {
                  initValue: value.isolationTime,
                  rules: [
                    {
                      required: true,
                      message: intl('widget.outlier_ejection.input_recovery_unit_time'),
                    },
                  ],
                })}
              />
              <span style={{ marginLeft: 8 }}>ms</span>
            </Form.Item>
            <Form.Item
              label={
                <React.Fragment>
                  <span style={{ marginRight: 8 }}>{intl('widget.outlier_ejection.not_restored_times')}</span>
                  <BalloonIcon text={intl('widget.outlier_ejection.not_restored_times_hint')} />
                </React.Fragment>
              }
              required
            >
              <NumberPicker
                min={1}
                style={{ width: 608 }}
                placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
                {...init('maxIsolationTimeMultiple', {
                  initValue: value.maxIsolationTimeMultiple,
                  rules: [
                    {
                      required: true,
                      message: intl('widget.outlier_ejection.input_not_restored_times'),
                    },
                  ],
                })}
              />
            </Form.Item>
            <Form.Item label=" ">
              <div className={styles.legend}>
                <p className={styles.title}>{intl('widget.outlier_ejection.removal_detect')}</p>
                <RecoveryTimeline value={getValues()} />
              </div>
            </Form.Item>
          </div>
        </If>
        <If condition={value.rpcType === RPC_TYPE.ISTIO}>
          <Form.Item label={intl('widget.outlier_ejection.exception_type')}>
            <div style={{ marginTop: 8 }}>{intl('widget.outlier_ejection.5xx_exception')}</div>
          </Form.Item>
          <Form.Item
            label={intl('widget.outlier_ejection.max_ejection_percent')}
            required
          >
            <NumberPicker
              min={0}
              max={100}
              style={{ width: 608 }}
              placeholder="0~100"
              {...init('maxEjectionPercent', {
                initValue: value.maxEjectionPercent,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.please_entry_max_ejection_percent'),
                  },
                ],
              })}
            />
            <span style={{ marginLeft: 8 }}>%</span>
          </Form.Item>
          <Form.Item label={intl('widget.outlier_ejection.recovery_unit_time')} required>
            <NumberPicker
              min={1}
              style={{ width: 608 }}
              placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
              {...init('isolationTime', {
                initValue: value.isolationTime,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.input_recovery_unit_time'),
                  },
                ],
              })}
            />
            <span style={{ marginLeft: 8 }}>ms</span>
          </Form.Item>
          <Form.Item
            label={intl('widget.outlier_ejection.continuou_error_times')}
            required
          >
            <NumberPicker
              min={1}
              style={{ width: 608 }}
              placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
              {...init('consecutiveErrors', {
                initValue: value.consecutiveErrors,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.please_continuou_error_times'),
                  },
                ],
              })}
            />
          </Form.Item>
          <Form.Item
            label={intl('widget.outlier_ejection.max_connections_times')}
            required
          >
            <NumberPicker
              min={1}
              style={{ width: 608 }}
              placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
              {...init('maxConnections', {
                initValue: value.maxConnections,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.please_intry_max_connections_times'),
                  },
                ],
              })}
            />
          </Form.Item>
          <Form.Item
            label={intl('widget.outlier_ejection.max_pending_request_times')}
            required
          >
            <NumberPicker
              min={1}
              style={{ width: 608 }}
              placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
              {...init('http1MaxPendingRequests', {
                initValue: value.http1MaxPendingRequests,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.please_entry_max_pending_request_times'),
                  },
                ],
              })}
            />
          </Form.Item>
          <Form.Item
            label={intl('widget.outlier_ejection.single_link_max_request_times')}
            required
          >
            <NumberPicker
              min={1}
              style={{ width: 608 }}
              placeholder={intl('widget.outlier_ejection.integer_greater_than_0')}
              {...init('maxRequestsPerConnection', {
                initValue: value.maxRequestsPerConnection,
                rules: [
                  {
                    required: true,
                    message: intl('widget.outlier_ejection.please_entry_single_link_max_request_times'),
                  },
                ],
              })}
            />
          </Form.Item>
        </If>
        <Form.Item>
          <Button type="normal" onClick={preStep} style={{ marginRight: 8 }}>
            {intl('widget.common.pre_step')}
          </Button>
          <Form.Submit validate type="primary" onClick={handleSubmit}>
            {intl('widget.common.aliyun-widget_step')}
          </Form.Submit>
        </Form.Item>
      </Form>
    </React.Fragment>
  );
};

Config.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  nextStep: PropTypes.func,
  preStep: PropTypes.func,
};

export default Config;
