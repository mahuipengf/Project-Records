/**
 * Created by huangfushan on 2019-11-13
*/
import React from 'react';
import PropTypes from 'prop-types';
import { isEmpty, map, find, get, join } from 'lodash';
import DataFields from 'components/DataFields';
import { Form, Switch, Button } from '@ali/cn-design';
import { RPC_TYPE_DATA, RPC_TYPE } from 'pages/OutlierEjection/constants';
import { Field } from '@alicloud/console-components';
import { MSC_WIDGET_CONSOLE_CONFIG, WIDGET_ID } from 'constants';
import services from 'services';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import ConfigInfo from 'pages/OutlierEjection/OutlierejectionList/components/OulierEjectionInfo/ConfigInfo';

const CreateComplete = (props) => {
  const field = Field.useField();
  const intl = useIntl();
  const { value, preStep, setIsConfirmLoading } = props;
  const { validate } = field;
  const [eventEmitter] = useGlobalState('eventEmitter');

  const handleSubmit = () => {
    validate((errors, values) => {
      if (!isEmpty(errors)) return;
      const params = {
        policyName: value.policyName,
        namespaceId: value.namespaceId,
        regionId: value.regionId,
        appList: value.appList,
        outlierConfig: {},
      };

      if (value.rpcType === RPC_TYPE.DUBBO || value.rpcType === RPC_TYPE.SPRING_CLOUD) {
        params.outlierConfig = {
          rpcType: value.rpcType,
          isOutlierEnabled: values.isOutlierEnabled,
          errorRateThreshold: value.errorRateThreshold / 100,
          source: value.source,
          shouldCountBizError: value.shouldCountBizError,
          requestThreshold: value.requestThreshold,
          maxIsolationRate: value.maxIsolationRate / 100,
          isolationTime: value.isolationTime,
          maxIsolationTimeMultiple: value.maxIsolationTimeMultiple,
        };
      }
      if (value.rpcType === RPC_TYPE.ISTIO) {
        params.outlierConfig = {
          source: value.source,
          rpcType: value.rpcType,
          isOutlierEnabled: values.isOutlierEnabled,
          maxEjectionPercent: value.maxEjectionPercent / 100,
          isolationTime: value.isolationTime,
          consecutiveErrors: value.consecutiveErrors,
          http1MaxPendingRequests: value.http1MaxPendingRequests,
          maxRequestsPerConnection: value.maxRequestsPerConnection,
          maxConnections: value.maxConnections,
        };
      }
      if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
        params.outlierConfigDO = params.outlierConfig;
      }
      pushData(params);
    });
  };

  // 创建
  const pushData = async (params) => {
    setIsConfirmLoading(true);
    await services.addOutlierEjection({
      data: params,
      customErrorHandle: (error, respongse, callback) => {
        setIsConfirmLoading(false);
        callback();
      }
    });
    setIsConfirmLoading(false);
    eventEmitter.emit(`${WIDGET_ID}:go-to-OutlierEjectionList`, {});
  };

  const appList = map(value.appList, n => n.appName);
  const namespaceName = get(value, 'namespaceName', '--');
  const regionName = get(value, 'regionName', '--');
  const rpcTypeObj = find(RPC_TYPE_DATA(intl, MSC_WIDGET_CONSOLE_CONFIG.productName), ['value', value.rpcType]) || {};
  const dataSource = {
    ...value,
    appList,
    namespaceName: `${regionName} / ${namespaceName}`,
    rpcLabel: rpcTypeObj.label,
  };

  const items = [
    { dataIndex: 'policyName', label: intl('widget.outlier_ejection.policy_name'), visible: true },
    { dataIndex: 'namespaceName', label: intl('widget.common.microservice_space'), visible: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' },
    { dataIndex: 'rpcLabel', label: intl('widget.outlier_ejection.use_frame'), visible: true },
    {
      dataIndex: 'appList',
      label: intl('widget.outlier_ejection.effect_app'),
      visible: true,
      render: val => join(val, ', '),
      span: 24
    }
  ];

  return (
    <Form field={field}>
      <div style={{ background: '#fafafa', padding: 16, marginBottom: 16 }}>
        <h1 style={{ margin: 0 }}>{intl('widget.outlier_ejection.create_policy_confirm')}</h1>
        <DataFields
          title={intl('widget.common.basic_info')}
          dataSource={dataSource}
          items={items}
        />
        <ConfigInfo value={dataSource} style={{ width: '100%' }} />
        <Form.Item label={intl('widget.outlier_ejection.default_state')} style={{ margin: '18px 0 0' }}>
          <Switch
            name="isOutlierEnabled"
            defaultChecked={value.isOutlierEnabled}
            defaultValue={value.isOutlierEnabled}
          />
        </Form.Item>
      </div>
      <Form.Item>
        <Button type="normal" onClick={preStep} style={{ marginRight: 8 }}>
          {intl('widget.common.pre_step')}
        </Button>
        <Form.Submit validate type="primary" onClick={handleSubmit}>
          {intl('widget.common.create')}
        </Form.Submit>
      </Form.Item>
    </Form>
  );
};

CreateComplete.propTypes = {
  preStep: PropTypes.func,
  setIsConfirmLoading: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
};

export default CreateComplete;
