import OutlierEjectionList from './OutlierejectionList';

export default OutlierEjectionList;
