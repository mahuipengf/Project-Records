import React from 'react';

import BasicPermission from './components/BasicPermission';
import GrantAuthorization from './components/GrantAuthorization';

const AppDetail = () => {
  return (
    <React.Fragment>
      {/* 当前详情 */}
      <div style={{ display: 'flex' }}>
        <div style={{ flex: 1, paddingRight: '15px' }}>
          <GrantAuthorization />
        </div>
        <div style={{ width: '384px', paddingLeft: '15px', background: '#fff', borderLeft: '1px solid #E3E4E6' }}>
          <BasicPermission />
        </div>
      </div>
    </React.Fragment>
  );
};

export default AppDetail;
