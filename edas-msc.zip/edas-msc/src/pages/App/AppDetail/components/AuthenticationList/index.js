import React, { useState } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, CopyContent, modelDecorator, Empty } from '@ali/cn-design';
import Status from 'components/Status/CommonStatus';
import Events from 'pages/Authentication/AuthenticationList/Events';
import AuthenticationInfo from 'pages/Authentication/AuthenticationInfo';
import { lowerFirstData } from 'utils/transfer-data';
import { WIDGET_ID } from 'constants';

function TableContainerExample(props) {
  const { toggleModal } = props;
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const [searchValues] = useGlobalState('searchValues');
  const intl = useIntl();
  const { regionId, namespaceId, appId } = searchValues;
  const [eventEmitter] = useGlobalState('eventEmitter');

  const protocol = {
    DUBBO: 'Dubbo',
    SPRING_CLOUD: 'Spring Cloud',
    istio: intl('widget.service.service_mesh'),
  };

  const fetchData = async (params) => {
    const res = await services.fetchAuthenticationList({
      data: {
        ...params,
        appId,
        regionId,
        namespaceId
      }
    });
    const { result: List, totalSize: TotalCount } = lowerFirstData(res) || {};
    return {
      Data: List,
      TotalCount,
    };
  };

  const columns = [
    {
      key: 'name',
      title: intl('widget.authentication.rule_name'),
      dataIndex: 'name',
      cell: (val, index, record) => (
        <CopyContent text={val}>
          <span className="link-primary" onClick={() => handleGoToInfo(record)}>{val}</span>
        </CopyContent>
      ),
    },
    {
      key: 'enable',
      title: intl('widget.common.state'),
      dataIndex: 'enable',
      cell: val => <Status value={val} intl={intl} />
    },
    {
      key: 'protocol',
      title: intl('widget.authentication.callee_protocol'),
      dataIndex: 'protocol',
      cell: val => (
        <Empty value={val}>
          {protocol[val] || '--'}
        </Empty>
      ),
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => <Events record={record} setFetchDataTime={setFetchDataTime} />,
    },
  ];

  const handleGoToInfo = (record) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl('widget.authentication.info'),
      content: (
        <AuthenticationInfo value={record} />
      ),
      onConfirm: null,
    });
  };

  const handleGoAuthenticationList = () => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-AuthenticationList`);
  };

  return (
    <TableContainer
      fetchData={fetchData}
      primaryKey="id"
      columns={columns}
      refreshIndex={fetchDataTime}
      emptyContent={
        <div >
          <span className="link-primary" onClick={handleGoAuthenticationList}>
            {intl('widget.app.app_info.no_data_go_authentication_list')}
          </span>
        </div>
      }
    />
  );
}

TableContainerExample.propTypes = {
  toggleModal: PropTypes.func,
};

export default modelDecorator(TableContainerExample);
