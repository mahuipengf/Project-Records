import React, { useEffect, useState, useRef } from 'react';
import SummaryChartsModel from '../SummaryChartsModel';
import moment from 'moment';
import styles from './index.css';
import { Loading } from '@alicloud/console-components';
import { getParams } from 'utils';
import { useInterval } from '@ali/sre-utils-hooks';
import { debounce } from 'lodash';
import services from 'services';

const DATA_OF_CHARTS_SHOW = {
  // cpu 相关
  'system.cpu.total': '总量',
  'system.cpu.iowait': '等待IO完成的CPU使用率',
  'system.cpu.user': '用户CPU使用率',
  'system.cpu.system': '系统CPU使用率',
  // load
  'system.load.1min': 'Load',
  // 物理内存相关
  'system.mem.total': '总量',
  'system.mem.free': '系统空闲内存量',
  'system.mem.used': '已使用内存量',
  'system.mem.cached': '系统PageCache内存量',
  'system.mem.buffers': '系统BufferCache内存量',
  // Network 相关
  'system.net.in.bytes': '网络接收流量大小',
  'system.net.out.bytes': '网络发送流量大小',
  'system.net.in.packets': '网络接收的报文数',
  'system.net.out.packets': '网络发送的报文数',
  'system.net.in.errs': '网络接收的错误数',
  'system.net.in.dropped': '网络丢弃报文数',
  // Disk 相关
  'system.disk.partition.total': '总量',
  'system.disk.partition.free': '磁盘空闲量',
  'system.disk.partition.used': '磁盘使用量',
  // jvm堆内存 相关
  'jvm.mem.heap.used': '使用总和',
  'jvm.mem.pools.old_gen.used': '老年代',
  'jvm.mem.pools.survivor_space.used': '年轻代Survivor区',
  'jvm.mem.pools.eden_space.used': '年轻代Eden区',

  // jvm非堆内存 相关
  'jvm.mem.non_heap.committed': '非堆内存commit字节数',
  'jvm.mem.non_heap.init': '非堆内存init字节数',
  'jvm.mem.non_heap.used': '非堆内存使用字节数',

  // jvm元空间 相关
  'jvm.mem.pools.metaspace.used': '元空间',
  // jvm线程数 相关
  'jvm.thread.count': '总和',
  'jvm.thread.deadlock.count': '死锁线程数',
  'jvm.thread.new.count': '新建线程数',
  'jvm.thread.blocked.count': '阻塞线程数',
  'jvm.thread.runnable.count': 'Runnable的线程数',
  'jvm.thread.terminated.count': '终结线程数',
  'jvm.thread.timed_waiting.count': 'Timed_Waiting的线程数',
  'jvm.thread.waiting.count': 'Waiting的线程数',
};

const SummarySystem = props => {
  // const { onTooltipChange, onPlotLeave, getG2Charts } = props;
  const { AppId, Region } = props;
  const metricStartTime = moment().valueOf() - 30 * 60 * 1000;
  const metricEndTime = moment().valueOf();
  const appName = getParams('appName') || '';
  const [ isLoading, setIsLoading ] = useState(true);
  const [ meticsOfSystem, setMeticsOfSystem ] = useState([[]]);
  const [ meticsOfNetwork, setMeticsOfNetwork ] = useState([[], []]);
  // 获取g2图表实例
  const charts = useRef({ current: {} });

  useEffect(() => {
    queryResourceList();
  }, [ ]);

  useInterval(() => {
    queryResourceList();
  }, 20000);

  async function queryResourceList() {
    const [
      load = [],
    ] = await Promise.all([
      getMetricOverview('system_load'), // load
      getNewApiMacMetricsOfResource('system_network'),
      // getNewApiMacMetricsOfResource('system_disk'),
    ]);

    setMeticsOfSystem([ load ]);
    setIsLoading(false);
  }

  // 请求剩余的图表数据
  async function getNewApiMacMetricsOfResource() {
    const Data = await services.QuerySystemResourceMetricOfGroup({
      params: { 
        appName: appName || 'spring-cloud-a',
        namespace: 'default',
        RegionId: Region,
        AhasRegionId: Region,
        Namespace: 'default',
        NameSpace: 'default',
        group: 'system_network',
        startTime: metricStartTime,
        endTime: metricEndTime,
      }
    });

    return initNewApicurMeticsData(Data);
  };

  // 处理新接口图表数据
  function initNewApicurMeticsData(curMetics) {
    const systemNetwork = [];

    if (!curMetics?.length) {
      setIsLoading(false);
      return;
    }

    curMetics.forEach((item) => {
      item.Val = Number(item.Val);
      let type = '';

      if (item.Resource === 'system.net.in.bytes') {
        type = '网络接收流量大小';
        systemNetwork.push({
          name: 'network',
          time: item.Time,
          type,
          count: item.Val,
          val: item.Resource,
        });
      }

      if (item.Resource === 'system.net.out.bytes') {
        type = '网络发送流量大小';
        systemNetwork.push({
          name: 'network',
          time: item.Time,
          type,
          count: item.Val,
          val: item.Resource,
        });
      }

    });

    setMeticsOfNetwork([ systemNetwork ]);
    setIsLoading(false);
  };

  // 请求load的图表数据
  async function getMetricOverview(resourceType) {
    const Data = await services.QuerySystemResourceMetricOfGroup({
      params: {
        // Resource: resourceType,
        group: resourceType,
        startTime: metricStartTime,
        EndTime: metricEndTime,
        AppName: appName || 'spring-cloud-a',
        namespace: 'default',
        RegionId: Region,
        AhasRegionId: Region,
        Namespace: 'default',
        NameSpace: 'default'
      }
    });
    return initcurMeticsData(Data);
  };

  // 构建load的图表数据
  function initcurMeticsData(curMetics) {
    const load = [];

    if (!curMetics || curMetics && !curMetics.length) {
      setIsLoading(false);
      return [];
    }

    curMetics.forEach((item) => {
      item.passedQps = Number(item.Val);

      load.push({
        time: item.Time,
        type: 'load',
        count: item.passedQps,
        val: 'system.load.1min',
      });
    });

    return load;
  };

  // 渲染Tooltip
  function onSystemTooltipChange(tooltips) {
    const { loadCharts, systemNetworkChart } = charts.current;

    const { x, y } = tooltips; // tooltip显示的项

    const pointData = {};

    // 面积图point会是个数组，数组取第一项的值
    function isAry(val) {
      return Object.prototype.toString.call(val) === '[object Array]';
    }

    if (isAry(x)) {
      pointData.x = x[0];
    } else {
      pointData.x = x;
    }

    if (isAry(y)) {
      pointData.y = y[0];
    } else {
      pointData.y = y;
    }

    loadCharts?.showTooltip(pointData);
    systemNetworkChart?.showTooltip(pointData);
  };

  const onTooltip = debounce(onSystemTooltipChange, 0);

  // 鼠标离开图标时，隐藏所有的tooltip
  function onPlotLeave(plot) {
    const { loadCharts, systemNetworkChart } = charts.current;

    const id = plot.toElement?.getAttribute('id');
    if (id && id?.indexOf('canvas') !== -1) {
      loadCharts?.hideTooltip();
      systemNetworkChart?.hideTooltip();
    }
  };

  function getG2Charts(type, chart) {
    switch (type) {
      case 'rt':
        charts.current.rtAndThread = chart;
        break;
      case 'cpu':
        charts.current.cpuCharts = chart;
        break;
      default:
        return;
    }
  };

  return (
    <>
      <Loading
        visible={isLoading}
        className={styles.loadingCover}
      >
        <SummaryChartsModel
          meticsOfData={meticsOfSystem.concat(meticsOfNetwork)}
          title={'system'}
          onTooltipChange={onTooltip}
          onPlotLeave={onPlotLeave}
          getG2Charts={getG2Charts}
        />
      </Loading>
    </>
  );
};

export default SummarySystem;
