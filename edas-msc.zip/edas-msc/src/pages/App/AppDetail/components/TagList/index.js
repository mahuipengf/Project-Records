import React, { useState } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, CopyContent, modelDecorator, Empty } from '@ali/cn-design';
import Status from 'components/Status/CommonStatus';
import Events from './Events';
import RouteInfo from 'containers/RouteInfo';
import { WIDGET_ID } from 'constants';

function TagList(props) {
  const { toggleModal } = props;
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const [searchValues] = useGlobalState('searchValues');
  const intl = useIntl();
  const { regionId, namespaceId, appId } = searchValues;
  const [eventEmitter] = useGlobalState('eventEmitter');

  const fetchData = async (params) => {
    const { Result = [], totalSize: TotalCount = 0 } = await services.getRoutePolicyList({
      params: {
        ...params,
        appId,
        Category: 0, // 1是金丝雀，0是标签路由
        regionId,
        namespaceId
      }
    });
    return {
      Data: Result,
      TotalCount,
    };
  };

  const columns = [
    {
      key: 'Name',
      title: intl('widget.route.name'),
      dataIndex: 'Name',
      cell: (val, index, record) => (
        <CopyContent text={val}>
          <span className="link-primary" onClick={() => handleOpenInfo(record)}>{val}</span>
        </CopyContent>
      ),
    },
    {
      key: 'Enable',
      title: intl('widget.common.state'),
      dataIndex: 'Enable',
      cell: val => <Status value={val} intl={intl} />
    },
    {
      key: 'Tag',
      title: intl('widget.app.tag'),
      dataIndex: 'Tag',
      cell: val => (
        <Empty value={val}>
          {val}
        </Empty>
      ),
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => <Events record={record} setFetchDataTime={setFetchDataTime} />,
    },
  ];

  const handleOpenInfo = (record) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl('widget.route.tag_info'),
      content: (
        <RouteInfo id={record.Id} />
      ),
      onConfirm: null,
    });
  };

  const handleGoTagList = () => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-RouteTagList`);
  };

  return (
    <TableContainer
      fetchData={fetchData}
      primaryKey="Id"
      columns={columns}
      refreshIndex={fetchDataTime}
      emptyContent={
        <div >
          <span className="link-primary" onClick={handleGoTagList}>
            {intl('widget.app.app_info.no_data_go_tag_list')}
          </span>
        </div>
      }
    />
  );
}

TagList.propTypes = {
  toggleModal: PropTypes.func,
};

export default modelDecorator(TagList);
