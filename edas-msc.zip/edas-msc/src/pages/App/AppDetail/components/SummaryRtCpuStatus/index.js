import OverviewCharts from '../common/OverviewCharts';
import React, { useEffect, useState, useRef } from 'react';
import styles from './index.css';
import services from 'services';
import { getParams } from 'utils';
import { useInterval } from '@ali/sre-utils-hooks';
import { debounce } from 'lodash';
import moment from 'moment';

const SUMMARY_RT_CPU_STATUS_TITLE = [
  {
    title: 'RT(ms)',
    width: '49.5%',
  },
  {
    title: 'CPU',
    width: '49.5%',
  }
];

const SUMMARY_RT_CPU_STATUS_TYPE = [
  'rt',
  'cpu',
  'statusCode',
];

const SUMMARY_RT_CPU_TITLE = [
  {
    title: 'RT(ms)',
    width: '49.5%',
  },
  {
    title: 'CPU',
    width: '49.5%',
  },
];

const SummaryRtCpuStatus = (props) => {
  // const { metricData, onTooltipChange, onPlotLeave, getG2Charts } = props;
  const { AppId, Region } = props;
  const isNginx = sessionStorage.getItem('isNginx') === 'true';
  const SUMMARY_TITLE = isNginx ? SUMMARY_RT_CPU_TITLE : SUMMARY_RT_CPU_STATUS_TITLE;
  const [ metricOfRtCpuStatus, setMetricOfRtCpuStatus ] = useState([[], []]); // rt、cpu
  const appName = getParams('appName') || '';
  const [ dataQpsDeta, setDataQpsDeta ] = useState([]);
  const metricStartTime = moment().valueOf() - 5 * 60 * 1000;
  const metricEndTime = moment().valueOf();
  // 获取g2图表实例
  const charts = useRef({ current: {} });

  useEffect(() => {
    queryResourceList();
  }, [ ]);

  useInterval(() => {
    queryResourceList();
  }, 20000);

  // 请求QPS、Rt数据
  async function getQpsRtData() {
    const { curMetics, passQps_5m = 0, blockQps_5m = 0, expQps_5m = 0, machineCount = 0 } = await services.QuerySentinelAppSummaryMetricOverview({
      params: {AppName: appName || 'spring-cloud-a', namespace: 'default', RegionId: Region, AhasRegionId: Region, Namespace: 'default', NameSpace: 'default'}
    });
    return initQpsRtThreadData(curMetics);
  }

  // 构建qps、rt.thread图表数据
  function initQpsRtThreadData(curMetics) {
    const allQps = [];
    const rt = [];
    const qpsData = [];

    !!curMetics &&
      curMetics.forEach((item) => {
        item.passedQps = Number(item.passedQps); // 通过QPS
        item.blockedQps = Number(item.blockedQps); // 拒绝QPS
        item.exception = Number(item.exception); // 异常QPS
        item.rt = Number(item.rt); // 平均RT
        qpsData.push({
          time: item.timestamp,
          type: '限流触发',
          count: item.flowRuleQPS,
        });
        qpsData.push({
          time: item.timestamp,
          type: '熔断触发',
          count: item.degradeRuleQPS,
        });
        qpsData.push({
          time: item.timestamp,
          type: '系统保护触发',
          count: item.systemRuleQPS,
        });
        qpsData.push({
          time: item.timestamp,
          type: '热点参数触发',
          count: item.paramRuleQPS,
        });
        qpsData.push({
          time: item.timestamp,
          type: '主动降级触发',
          count: item.manualDegradeRuleQPS,
        });
        allQps.push({
          time: item.timestamp || 0,
          type: '通过QPS',
          count: item.passedQps,
        });

        allQps.push({
          time: item.timestamp || 0,
          type: '拒绝QPS',
          count: item.blockedQps,
        });

        !isNginx && allQps.push({
          time: item.timestamp || 0,
          type: '异常QPS',
          count: item.exception,
        });

        rt.push({
          time: item.timestamp || 0,
          type: 'RT(ms)',
          count: item.rt,
        });
      });
    // setDataQpsDeta(qpsData);
    setDataQpsDeta(rt);
    // return [ allQps, rt ];
    return [ rt ];
  }

  // 请求cpu、load的图表数据
  async function getMetricOverview() {
    const Data = await services.QuerySentinelMetricsOfResource({
      params: {
        Resource: '__cpu_usage__',
        EndTime: metricEndTime,
        AppName: appName || 'spring-cloud-a',
        namespace: 'default',
        RegionId: Region,
        AhasRegionId: Region,
        Namespace: 'default',
        NameSpace: 'default'
      }
    });
    return initcurMeticsData(Data?.innerMetrics);
  }

  // 构建cpu、load的图表数据
  function initcurMeticsData(curMetics) {
    const cpu = [];

    if (!curMetics || curMetics && !curMetics.length) {
      return [];
    }

    curMetics.forEach((item) => {
      item.passedQps = Number(item.passedQps);
      cpu.push({
        time: item.timestamp,
        type: '用户CPU使用率',
        count: item.passedQps,
        val: 'system.cpu.user',
      });
    });

    return cpu;
  }

  // 请求各图表数据
  async function queryResourceList() {
    const [
      qpsRtData = [],
      cpu = [],
    ] = await Promise.all([
      getQpsRtData(), // qps、rt
      getMetricOverview(), // cpu
    ]);
    const [ rt = [] ] = qpsRtData;
    setMetricOfRtCpuStatus([ rt, cpu ]);
  }

  // 渲染Tooltip
  function onTooltipChange(tooltips) {
    const { rtAndThread, cpuCharts } = charts.current;

    const { x, y } = tooltips; // tooltip显示的项

    const pointData = {};

    // 面积图point会是个数组，数组取第一项的值
    function isAry(val) {
      return Object.prototype.toString.call(val) === '[object Array]';
    }

    if (isAry(x)) {
      pointData.x = x[0];
    } else {
      pointData.x = x;
    }

    if (isAry(y)) {
      pointData.y = y[0];
    } else {
      pointData.y = y;
    }

    // allQpsChart?.showTooltip(pointData);
    rtAndThread?.showTooltip(pointData);
    cpuCharts?.showTooltip(pointData);
    // systemMemoryChart?.showTooltip(pointData);
  }

  const onTooltip = debounce(onTooltipChange, 0);

  // 鼠标离开图标时，隐藏所有的tooltip
  function onPlotLeave(plot) {
    const { rtAndThread, cpuCharts } = charts.current;

    const id = plot.toElement?.getAttribute('id');
    if (id && id?.indexOf('canvas') !== -1) {
      // allQpsChart?.hideTooltip();
      rtAndThread?.hideTooltip();
      cpuCharts?.hideTooltip();
      // systemMemoryChart?.hideTooltip();
    }
  }

  function getG2Charts(type, chart) {
    switch (type) {
      case 'rt':
        charts.current.rtAndThread = chart;
        break;
      case 'cpu':
        charts.current.cpuCharts = chart;
        break;
      default:
        return;
    }
  }

  return (
    <div className={styles.content}>
      {SUMMARY_TITLE.map((item, index) => {
        return (
          <OverviewCharts
            curMeticsData={metricOfRtCpuStatus[index]}
            title={item.title}
            chartsType={SUMMARY_RT_CPU_STATUS_TYPE[index]}
            typeCharts={SUMMARY_RT_CPU_STATUS_TYPE[index]}
            chartDialogtitle={'machine'}
            importType
            pageType={'summary'}
            chartsWidth={item.width}
            onTooltipChange={onTooltip}
            onPlotLeave={onPlotLeave}
            getG2Charts={getG2Charts}
          />
        );
      })}
    </div>
  );
};

export default SummaryRtCpuStatus;
// export default RoleHoc(SummaryRtCpuStatus);
