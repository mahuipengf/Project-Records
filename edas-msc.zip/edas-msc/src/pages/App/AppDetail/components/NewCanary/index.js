import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { Button, Table, Balloon, Icon } from '@ali/cn-design';
import Dialog from 'components/Dialog';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { get, uniqueId, map, sum, size, forEach, find, isEmpty, forIn, filter, findIndex } from 'lodash';
import { mapConditions, setParams } from 'utils';
import { timeFmt } from 'utils/time';
import Step from 'components/Step';
import Drawer from './components/Drawer';
import ConditionList from 'containers/ConditionList';
import DataFields from 'components/DataFields';
import { WIDGET_ID } from 'constants';

const NewCanary = ({ value }) => {
  const intl = useIntl();
  const [searchValues] = useGlobalState('searchValues');
  const { regionId: Region, namespaceId: AppName, appId: AppId } = value;
  const [data, setData] = useState({ rules: [] });
  const [actives, setActives] = useState(false);
  const [enable, setEnable] = useState(false);
  const [flag, setFlag] = useState(true);
  const [visible, setVisible] = useState(false);
  const [tag, setTag] = useState();
  const [marked, setMarked] = useState('');
  const [showRule, setShowRule] = useState(false);
  const [proportional, setProportional] = useState(true);
  const [eventEmitter] = useGlobalState('eventEmitter');
  const columns = (n) => [
    {
      key: 'Tag',
      title: intl('widget.route.tag_n', { n }),
      dataIndex: 'Tag',
      cell: (val, index, record) => {
        const color = ['110, 132, 159', '117,100,164', '156, 116, 113', '161,154,109', '109,156,101'];
        const i = index % 5;
        return (
          <div >
            <If condition={record.Status === 0}>
              <span
                style={{
                  color: `rgba(${color[i]}, 0.9)`,
                  background: `rgba(${color[i]}, 0.1)`,
                  padding: '4px 8px',
                  borderRadius: 10,
                }}
              >
                {val === '_base' ? intl('widget.app.canary_no_tag') : val}
              </span>
            </If>
            <If condition={record.Status === 1}>
              <span
                style={{
                  color: `rgba(${color[i]}, 0.9)`,
                  background: `rgba(${color[i]}, 0.1)`,
                  padding: '4px 8px',
                  borderRadius: 10,
                }}
              >
                {val === '_base' ? intl('widget.app.canary_no_tag') : val}
              </span>
              <span> {intl('widget.common.brackets', { text: intl('widget.route.has_canary_rule') })}</span>
              <Balloon
                align="t"
                trigger={<Icon type="help" style={{ color: '#777', cursor: 'pointer' }} />}
                closable={false}
              >
                <span>{intl('widget.route.delete_canary_to_use_tag')}</span>
              </Balloon>
            </If>
            <If condition={record.Status === 2}>
              <span
                style={{
                  color: `rgba(${color[i]}, 0.9)`,
                  background: `rgba(${color[i]}, 0.1)`,
                  padding: '4px 8px',
                  borderRadius: 10,
                }}
              >
                {val === '_base' ? intl('widget.app.canary_no_tag') : val}
              </span>
              <span>{intl('widget.common.brackets', { text: intl('widget.common.error') })}</span>
              <Balloon
                align="t"
                trigger={<Icon type="help" style={{ color: '#777', cursor: 'pointer' }} />}
                closable={false}
              >
                <span>{intl('widget.route.data_error_contact_admin')}</span>
              </Balloon>
            </If>
            <If condition={record.Status === 3}>
              <span
                style={{
                  color: `rgba(${color[i]}, 0.9)`,
                  background: `rgba(${color[i]}, 0.1)`,
                  padding: '4px 8px',
                  borderRadius: 10,
                }}
              >
                {val === '_base' ? intl('widget.app.canary_no_tag') : val}
              </span>
              <span>{intl('widget.common.brackets', { text: intl('widget.common.deleted') })}</span>
              <Balloon
                align="t"
                trigger={<Icon type="help" style={{ color: '#777', cursor: 'pointer' }} />}
                closable={false}
              >
                <span>{intl('widget.route.deleted_tag_and_change_again')}</span>
              </Balloon>
            </If>
          </div>
        );
      },
    },
    {
      key: 'CarrData',
      title: intl('widget.route.link_delivery'),
      dataIndex: 'CarrData',
      cell: (val, index, record) => {
        if (record.old) return '--';
        const carryData = get(record, 'CarryData', false);
        return carryData ? intl('widget.common.yes') : intl('widget.common.no');
      }
    },
    {
      key: 'InstanceNum',
      title: intl('widget.app.instance_number_or_actural_proportion'),
      dataIndex: 'InstanceNum',
      cell: (val, index, record) => `${val}/${record.InstanceRate}%`,
    },
    {
      key: 'Rate',
      title: intl('widget.route.flow_rate'),
      dataIndex: 'Rate',
      cell: (val) => (
        <React.Fragment>
          <div style={{ lineHeight: '24px' }}>{`${val || 0}%`}</div>
        </React.Fragment>
      ),
    },
    {
      key: 'GmtModified',
      title: intl('widget.app.canary_remark_time'),
      dataIndex: 'GmtModified',
      cell: (val) => {
        const time = new Date(val);
        return time ? timeFmt(val, 'YYYY-MM-DD HH:mm:ss') : '--';
      }
    }
  ];


  useEffect(() => {
    ListApplicationsWithTagRules({ PageNumber: 1, PageSize: 10 });
  }, [actives]);
  const ListApplicationsWithTagRules = async({ PageNumber, PageSize }) => {
    const res = await services.ListApplicationsWithTagRules({
      params: {
        PageNumber,
        PageSize,
        Region,
        AppName,
        AppId,
      }
    });
    const TotalSize = get(res, 'TotalSize', 0);
    const Result = get(res, 'Result', []);
    const newData = {
      TotalSize,
      Result: map(Result, item => ({
        ...item,
        uid: uniqueId(),
        Region: item.Region || searchValues.regionId,
        RouteRules: mapRouteRules(item.RouteRules),
      }))
    };
    disabledButton(Result);
    const newTagItem = find(newData.Result[0].RouteRules, item => JSON.stringify(item.Rules) !== '{}') || {};
    const rules = get(newTagItem, 'Rules', []);
    const appName = get(Result[0], 'AppName', '$ {AppName}');
    if (isEmpty(newData.Result[0].RouteRules[0].Rules)) {
      setFlag(false);
    }
    setData({ dataSource: newData.Result[0].RouteRules, rules, appName, isRule: false });
  };
  const mapRouteRules = (list = []) => {
    const total = sum(map(list, item => item.InstanceNum || 0));
    let totalRate = 0;
    return map(list, (item, index) => {
      const springCloud = get(item, 'Rules.springcloud', []);
      const dubbo = get(item, 'Rules.dubbo', []);
      const ScRule = map(springCloud, child => ({
        ...child,
        uid: uniqueId(),
        conditions: mapConditions(child.restItems),
        protocol: 'springCloud',
      }));
      const dubboRule = map(dubbo, child => {
        const { serviceName = '', version = '', group = '', methodName = '', paramTypes = [] } = child;
        return ({
          ...child,
          method: `${serviceName}:${version}:${group}:${methodName}:${paramTypes}`,
          uid: uniqueId(),
          conditions: mapConditions(child.argumentItems),
          protocol: 'dubbo',
        });
      });
      const Rules = [...ScRule, ...dubboRule];
      if (index < list.length - 1) {
        const InstanceRate = item.InstanceRate === undefined ? Math.round(((item.InstanceNum || 0) * 100 / total)) : item.InstanceRate;
        totalRate += InstanceRate;
        return ({
          ...item,
          uid: uniqueId(),
          InstanceRate: total === 0 ? 0 : InstanceRate,
          Rules,
        });
      }
      return ({
        ...item,
        uid: uniqueId(),
        InstanceRate: item.InstanceNum === 0 ? 0 : 100 - totalRate,
        Rules,
      });
    });
  };
  const CONDITION = {
    OR: intl('widget.route.condition_or'),
    AND: intl('widget.route.condition_and')
  };
  const handleClickIntroductionFlow = (params) => setActives(params);
  const disabledButton = (Result) => {
    const filterTag = filter(Result[0].RouteRules, item => item.Tag !== '_base');
    const arr = [];
    const rule = [];
    forEach(filterTag, item => {
      if (item.Status !== 3 && item.Enable) {
        arr.push(item.Enable);
        rule.push(item.Rules);
      }
    });
    if (arr.length > 0) {
      setShowRule(true);
      rule.length > 0 ? setFlag(true) : setFlag(false);
    } else {
      setShowRule(false);
      setFlag(false);
    }
    if (Result[0].RouteStatus === 0) {
      setEnable(false);
    } else if (Result[0].RouteStatus === 1) {
      setEnable(true);
      setTag('oldEdition');
      setProportional(false);
    } else if (Result[0].RouteStatus === 11) {
      setEnable(true);
      setTag('noTag');
    } else if (Result[0].RouteStatus === 12) {
      setEnable(true);
      setTag('multipleTag');
    } else if (Result[0].RouteStatus === 13) {
      setEnable(true);
      setTag('onlyNoTag');
    } else if (Result[0].RouteStatus === 14) {
      setEnable(true);
      setTag('existence');
    }
  };
  const getItems = (item) => [
    {
      dataIndex: 'protocol',
      label: intl('widget.route.frame_type'),
      visible: true,
      render: (val) => {
        const protocol = {
          dubbo: 'Dubbo',
          springCloud: 'Spring Cloud',
          istio: intl('widget.service.service_mesh'),
        };
        return protocol[val];
      }
    },
    {
      dataIndex: 'condition',
      label: intl('widget.route.condition_mode'),
      visible: true,
    },
    {
      dataIndex: 'path',
      label: intl('widget.route.path'),
      visible: item.protocol === 'springCloud' || item.protocol === 'istio',
    },
    {
      dataIndex: 'service',
      label: intl('widget.app.service_method'),
      visible: item.protocol === 'dubbo',
      span: 24,
    },
    {
      dataIndex: 'restItems',
      label: intl('widget.route.condition_list'),
      visible: true,
      span: 24,
      render: (val) => <ConditionList value={val} show protocol={item.protocol} />
    },
  ];
  const mapDialog = {
    release: intl.html('widget.app.new_canary_release'),
    roll_back: intl.html('widget.app.new_canary_roll_back'),
  };
  const revertApplicationRoutePolicy = async () => {
    await setProportional(true);
    await services.RevertApplicationRoutePolicy({ params: { AppId, Region, } }).then(res => ListApplicationsWithTagRules({ PageNumber: 1, PageSize: 10 }));
  };
  const rule = (proportional && data.rules.length > 0 && !showRule);
  const goToRocketMQRoute = async () => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-fullLinkGrayscalekHome`);
  };
  return (
    <React.Fragment>
      <div style={{ marginBottom: '8px' }}>
        <Button type="primary" onClick={() => handleClickIntroductionFlow(true)} disabled={enable} >{intl('widget.app.new_canary_introduction_flow')}</Button>
        <Button style={{ margin: '0px 8px' }} onClick={() => { setMarked('release'); setVisible(true); }} disabled={enable || (rule && proportional)} >{intl('widget.app.canary.publish_finish')}</Button>
        <Button onClick={() => { setMarked('roll_back'); setVisible(true); }} disabled={enable || (rule && proportional)}>{intl('widget.app.canary.delete_gray_rule')}</Button>
        <span style={{ color: '#555', marginLeft: '32px' }}>{intl('widget.app.new_canary_support_full_link_msg')}<span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={() => goToRocketMQRoute()}>{intl('widget.app.new_canary_support.push_full_link_grayscale')}</span>。</span>
      </div>
      <Table dataSource={data.dataSource || []} hasBorder={false} >
        <For each="column" index="index" of={columns(size(data.dataSource || []))}>
          <Table.Column {...column} />
        </For>
      </Table>
      <If condition={enable}>
        <div style={{ marginTop: '24px', width: '100%', padding: '16px', border: '1px solid #d1d5d9', borderRadius: '4px', background: '#ff' }}>
          <Step dataSource={data.dataSource} enable={enable} tag={tag} appName={data.appName} />
        </div>
      </If>
      <If condition={!enable}>
        <div style={{ marginTop: '16px' }}>
          <Button.Group>
            <If condition={showRule && data.rules.length > 0}><Button onClick={() => setFlag(true)}>{intl('widget.route.business_flow')}</Button></If>
            <Button onClick={() => setFlag(false)}>{intl('widget.app.new_canary_instructions')}</Button>
          </Button.Group>
        </div>
        <If condition={flag}>
          <If condition={!isEmpty(data.rules)}>
            <For each="item" index="index" of={data.rules}>
              <div key={index} style={{ marginTop: '24px' }}>
                <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.app.flow_rule', { n: index + 1 })}</div>
                <DataFields
                  key={index}
                  dataSource={{
                    ...item,
                    condition: CONDITION[item.condition],
                    path: item.path,
                    service: `${item.serviceName || ''}:${item.version || ''}:${item.group || ''} / ${item.methodName || ''} (${item.paramTypes || ''})`,
                    restItems: item.conditions,
                    conditions: item.conditions || [],
                    protocol: item.protocol,
                  }}
                  items={getItems(item)}
                  style={{ padding: '8px 0', borderBottom: 0 }}
                />
              </div>
            </For>
          </If>
        </If>
        <If condition={!flag}>
          <div style={{ marginTop: '24px', width: '100%', padding: '16px', border: '1px solid #d1d5d9', borderRadius: '4px', background: '#ff' }}>
            <Step dataSource={data.dataSource} handleClickIntroductionFlow={handleClickIntroductionFlow} enable={enable} appName={data.appName} />
          </div>
        </If>
      </If>
      <Drawer setFlag={setFlag} dataSource={data.dataSource} handleClickIntroductionFlow={handleClickIntroductionFlow} actives={actives} />
      <Dialog
        title={intl('widget.common.tips')}
        visible={visible}
        onOk={() => { revertApplicationRoutePolicy(); setVisible(false); }}
        onCancel={() => setVisible(false)}
        onClose={() => setVisible(false)}
        style={{ width: 324 }}
      >{mapDialog[marked]}</Dialog>
    </React.Fragment>
  );
};

NewCanary.propTypes = {
  toggleModal: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
};

export default NewCanary;
