import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Message, Radio, Field, NumberPicker, Switch, Balloon, Icon } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { NNAME_PATTERN } from 'constants';
import SlidePanel from 'components/SlidePanel';
import { get, split } from 'lodash';
import IconBack from 'components/IconBack';
import AppSelector from 'containers/AppSelector';
import TagSelector from '../../FaultInjection/TabSelector';

const TimeoutEdit = (props) => {
  const [loading, setLoading] = useState(false);
  const { value, visible, onClose, onOk } = props;
  const intl = useIntl();
  const field = Field.useField();
  const { init, validate, getValue, setValues, reset, setValue } = field;
  useEffect(() => {
    const Name = get(value, 'Name', '');
    const Region = get(value, 'Region', '');
    if (value.Id) {
      const Tag = get(value, 'Tag');
      const SourceType = get(value, 'RouteRules[0].sourceType');
      const SourceAppId = SourceType === 'all' ? [] : get(value, 'RouteRules[0].sourceAppId');
      const SourceAppName = SourceType === 'all' ? [] : get(value, 'RouteRules[0].sourceAppName');
      const Timeout = get(value, 'RouteRules[0].timeout');
      const Protocol = get(value, 'Protocol');
      const Enable = get(value, 'Enable');
      setValues({
        Name,
        Region,
        Tag,
        SourceType,
        SourceAppId,
        SourceAppName,
        Timeout,
        Protocol,
        Enable,
        Namespaces: { regionId: Region },
      });
    } else {
      setValues({
        Region,
        Namespaces: { regionId: Region },
      });
    }
  }, [value]);
  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const params = {
        Protocol: 'istio',
        AppId: value.AppId,
        Id: value.Id,
        Region: values.Region,
        Name: values.Name,
        Enable: values.Enable,
        Tag: values.Tag,
        Rules: {
          SourceType: values.SourceType, // "all" or "specific"
          SourceAppName: values.SourceType === 'all' ? ['*'] : values.SourceAppName,
          sourceAppId: values.SourceType === 'all' ? ['*'] : values.SourceAppId,
          Timeout: values.Timeout,
        }
      };
      editPoliry(params);
    });
  };

  // 创建
  const editPoliry = async (params) => {
    setLoading(true);
    params.Id
      ? await services.UpdateTimeoutRule({
        params,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      })
      : await services.CreateTimeoutRule({
        params,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      });
    setLoading(false);
    onOk();
    reset();
    Message.success(intl(value.Id ? 'widget.common.update_successful' : 'widget.common.add_successful'));
  };

  const handleClose = () => {
    setLoading(false);
    reset();
    onClose();
  };

  return (
    <SlidePanel
      title={
        <IconBack goBack={onClose}>{intl(value.Id ? 'widget.common.edit' : 'widget.msc.create_timeout')}</IconBack>
      }
      processingText={intl('widget.common.ok')}
      isShowing={visible}
      onOk={handleSubmit}
      onClose={handleClose}
      onCancel={handleClose}
      isProcessing={loading}
      width={780}
    >
      <Form field={field}>
        <Form.Item label={intl('widget.authentication.rule_name')} required>
          <Input
            style={{ width: 'calc(100% - 32px)' }}
            maxLength={64}
            showLimitHint
            placeholder={intl('widget.common.name_pattern')}
            {...init('Name', {
              rules: [
                {
                  required: true,
                  message: intl('widget.common.name_pattern'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.common.name_pattern'),
                },
              ],
            })}
            disabled={!!value.Id}
          />
        </Form.Item>
        <Form.Item
          label={
            <React.Fragment>
              <span>{intl('widget.app.tag')}</span>
              <Balloon align="t" trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />} closable={false}>
                {intl.html('widget.app.tag_hint')}
              </Balloon>
            </React.Fragment>
          }
          required
        >
          <TagSelector
            {...init('Tag', {
              rules: [
                {
                  required: true,
                  message: intl('widget.common.select_tag'),
                },
              ],
            })}
            disabled={value.Id}
            AppId={value.AppId}
            namespaces={getValue('Namespaces')}
            placeholder={intl('widget.common.select_tag')}
          />
        </Form.Item>
        <Form.Item label={intl('widget.route.frame_type')} required >
          <Radio.Group
            {...init('Protocol', {
              initValue: 'istio',
              rules: [
                {
                  required: true,
                  message: intl('widget.route.frame_type_errorr'),
                },
              ],
            })}
            dataSource={[{ value: 'istio', label: intl('widget.service.service_mesh') }]}
            disabled={!!value.Id}
          />
        </Form.Item>
        <Form.Item label={intl('widget.msc.source_type')} required>
          <Radio.Group
            {...init('SourceType', {
              initValue: 'all',
              rules: [
                {
                  required: true,
                },
              ],
            })}
            dataSource={[
              { value: 'all', label: intl('widget.msc.all_app') },
              { value: 'specific', label: intl('widget.msc.some_app') },
            ]}
          />
        </Form.Item>
        <If condition={getValue('SourceType') === 'specific'}>
          <Form.Item label={intl('widget.msc.some_app')} required>
            <AppSelector
              {...init('SourceAppId', {
                rules: [
                  {
                    required: true,
                    message: intl('widget.common.select_app'),
                  },
                ],
                props: {
                  onChange: (ids, names) => {
                    setValue('SourceAppName', names);
                  }
                }
              })}
              mode="multiple"
              namespaces={getValue('Namespaces')}
            />
          </Form.Item>
        </If>
        <Form.Item
          label={
            <React.Fragment>
              <span>{intl('widget.msc.timeout_time')}</span>
              <Balloon align="t" trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />} closable={false}>
                {intl.html('widget.msc.timeout_time_hint')}
              </Balloon>
            </React.Fragment>
          }
          required
        >
          <NumberPicker
            min={0}
            style={{ width: 'calc(100% - 32px)' }}
            {...init('Timeout', {
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.please_enter_timeout_time')
                },
              ],
            })}
            placeholder={intl('widget.msc.please_enter_timeout_time')}
          />
          <span style={{ marginLeft: 8 }}>ms</span>
        </Form.Item>
        <Form.Item label={intl('widget.outlier_ejection.default_state')} style={{ margin: '18px 0 0' }}>
          <Switch
            {...init('Enable', {
              initValue: true,
              valueName: 'checked'
            })}
          />
        </Form.Item>
      </Form>
    </SlidePanel>
  );
};

TimeoutEdit.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
};

export default TimeoutEdit;
