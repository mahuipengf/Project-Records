// todo未完待续

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { CopyContent, Empty } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import SlidePanel from 'components/SlidePanel';
import { get, join, split } from 'lodash';
import DataFields from 'components/DataFields';
import Status from 'components/Status/CommonStatus';
import IconBack from 'components/IconBack';
import { timeFmt } from 'utils';

const TimeoutInfo = (props) => {
  const { value, visible, onClose } = props;
  const [currentData, setCurrentData] = useState(value);
  const intl = useIntl();

  useEffect(() => {
    if (!value.Id || !visible) return;
    fetchData(value);
  }, [value]);

  const fetchData = async (params) => {
    // 列表数据已经全部拿到，可以不调用接口
    // const Data = await services.GetLoadBalancePolicyInfo({
    //   params: { PolicyId: params.PolicyId, Region: params.Region }
    // });
    const Data = params;
    setCurrentData(Data);
  };

  const items = [
    {
      dataIndex: 'Name',
      label: intl('widget.authentication.rule_name'),
      render: val => {
        return (
          <CopyContent text={val}>
            {val}
          </CopyContent>
        );
      },
      visible: true
    },
    {
      dataIndex: 'Enable',
      label: intl('widget.common.state'),
      render: val => <Status value={val} />,
      visible: true,
    },
    {
      dataIndex: 'Protocol',
      label: intl('widget.outlier_ejection.facing_this_frame'),
      render: (val) => {
        const protocol = {
          DUBBO: 'Dubbo',
          SPRING_CLOUD: 'Spring Cloud',
          istio: intl('widget.service.service_mesh'),
        };
        return protocol[val] || '--';
      },
      visible: true
    },
    {
      label: intl('widget.app.tag'),
      dataIndex: 'Tag',
    },
    {
      label: intl('widget.msc.source_type'),
      dataIndex: 'SourceAppName',
      render: (val, record) => {
        const sourceAppName = get(record, 'RouteRules[0].sourceAppName', []);
        if (sourceAppName[0] === '*') return intl('widget.msc.all_app');
        return join(sourceAppName, ', ');
      },
      visible: true
    },
    {
      label: intl('widget.msc.fault_type'),
      dataIndex: 'FaultType',
      render: (val, record) => {
        const type = {
          abort: intl('widget.msc.fault_type_abort'),
          delay: intl('widget.msc.fault_type_delay'),
        };
        return type[get(record, 'RouteRules[0].faultType')] || '--';
      },
      visible: true
    },
    {
      label: intl('widget.route.streaming_percentage'),
      dataIndex: 'Percentage',
      render: (val, record) => {
        const percentage = get(record, 'RouteRules[0].percentage');
        if (percentage) return `${percentage}%`;
        return '--';
      },
      visible: true
    },
    {
      label: intl('widget.msc.config'),
      dataIndex: 'Config',
      render: (val, record) => {
        const config = get(record, 'RouteRules[0].config');
        const faultType = get(record, 'RouteRules[0].faultType');
        const type = {
          abort: intl('widget.msc.fault_type_abort_config', { config }),
          delay: intl('widget.msc.fault_type_delay_config', { config: split(config, ':')[1] / 1000 }),
        };
        return type[faultType] || '--';
      },
      visible: true
    },
    {
      label: intl('widget.msc.update_time'),
      dataIndex: 'GmtModified',
      render: val => <Empty value={value}>{timeFmt(val, 'YYYY/MM/DD HH:mm')}</Empty>,
      visible: true
    },
  ];

  return (
    <SlidePanel
      title={
        <IconBack goBack={onClose}>{intl('widget.outlier_ejection.info')}</IconBack>
      }
      isShowing={visible}
      footer={false}
      onClose={onClose}
      width={780}
    >
      <DataFields
        title={intl('widget.common.basic_info')}
        dataSource={currentData}
        items={items}
      />
      {/* <ConfigInfo value={value} handleEditConfig={handleEditConfig} /> */}
    </SlidePanel>
  );
};

TimeoutInfo.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
};

export default TimeoutInfo;
