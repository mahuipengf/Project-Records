import React from 'react';
import DataFields from 'components/DataFields';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import { Empty, CopyContent } from '@ali/cn-design';
import { join, map, get, isEmpty } from 'lodash';

const rpcTypeData = {
  dubbo: 'Dubbo',
  springCloud: 'Spring Cloud',
  istio: 'Istio',
};

const Info = ({ data = {} }) => {
  const intl = useIntl();

  const items = [
    {
      dataIndex: 'AppId',
      label: intl('widget.app.id'),
      visible: true,
      span: 24,
      render: (value) => (
        <Empty value={value} >
          <CopyContent text={value}>
            {value}
          </CopyContent>
        </Empty>
      ),
    },
    {
      dataIndex: 'AppName',
      label: intl('widget.app.name'),
      visible: true,
      render: (value) => (
        <Empty value={value} >
          <CopyContent text={value}>
            {value}
          </CopyContent>
        </Empty>
      ),
      span: 24,
    },
    {
      dataIndex: 'Source',
      label: intl('widget.app.access_type'),
      visible: true,
      render: value => {
        const newValue = value === 'edasmsc' ? intl('widget.common.standard') : value;
        return <Empty value={newValue}>{newValue}</Empty>;
      },
      span: 24,
    },
    {
      dataIndex: 'ExtraInfo',
      label: intl('widget.app.framework'),
      visible: true,
      render: (value) => {
        const rpcTypes = get(value, 'rpcTypes', []);
        return (
          <React.Fragment>
            <If condition={!isEmpty(rpcTypes)}>
              {join(map(rpcTypes, item => rpcTypeData[item]), ', ')}
            </If>
            <If condition={isEmpty(rpcTypes)}>--</If>
          </React.Fragment>
        );
      },
      span: 24,
    },
  ];
  return (
    <React.Fragment>
      <DataFields
        dataSource={data}
        items={items}
        style={{ padding: '8px 0', borderBottom: '1px solid #eee', flexDirection: 'column' }}
        title={intl('widget.app.app_info')}
      />
    </React.Fragment>
  );
};

Info.propTypes = {
  data: PropTypes.objectOf(PropTypes.any),
};

export default Info;
