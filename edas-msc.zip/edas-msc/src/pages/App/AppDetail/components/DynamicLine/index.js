import React, { useEffect, useState } from 'react';
import { TableContainer, CopyContent, Icon, Balloon, Message } from '@ali/cn-design';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import Status from 'components/Status/CommonStatusLine';
import services from 'services';
import { filter, isEmpty } from 'lodash';
import DialogAlert from 'components/DialogAlert';

const triggerIcon = <Icon type="help" className="lossless-app-list-icon" />;
const DyncamicLine = (props) => {
  const { Region, AppId } = props;
  const [isCanRefresh] = useState(true);
  const [refreshIndex, setRefreshIndex] = useState(Date.now());
  const [searchValues] = useGlobalState('searchValues');
  const intl = useIntl();

  useEffect(() => {
    setRefreshIndex(Date.now());
    let interval;
    if (!interval) {
      interval = setInterval(() => {
        setRefreshIndex(Date.now());
      }, 5 * 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, []);
  const columns = [
    {
      key: 'Ip',
      title: (<span>
        {intl('widget.app.dynamicline_instance_name')}
        <Balloon trigger={triggerIcon} align="b" closable={false}>
          {intl('widget.app.dynamicline_instance_name_ip_pid')}
        </Balloon></span>),
      dataIndex: 'Ip',
      cell: (value, index, record) => {
        const podNameArr = (record.PodName && record.PodName.split('-')) || [];
        const podName = (podNameArr.length && podNameArr.slice(0, podNameArr.length - 2).join('-')) || '';
        const triggerHref = <span>（<a href={`https://cs.console.aliyun.com/#/k8s/cluster/${record.k8sClusterId}/v2/workload/deployment/detail/${record.PodNamespace}/${podName}/pods?type=deployment`} target="_blank">{record.PodNamespace}/{record.PodName}</a>）</span>;
        return (
          <div style={{ width: '420px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {/* <CopyContent text={value}> */}
            {`${value}-${record.Pid}`}
            <If condition={podName !== ''}>
              <Balloon trigger={triggerHref} align="b" closable={false}>
                {`${value}-${record.Pid}`}{triggerHref}
              </Balloon>
            </If>
            {/* </CopyContent> */}
          </div>
        );
      },
    },
    {
      key: 'Tags',
      title: intl('widget.app.tag'),
      dataIndex: 'Tags',
      cell: value => {
        const tagList = filter(value, item => item.Type === 'tag');
        const cananryList = filter(value, item => item.Type === 'canary');
        const otherList = filter(value, item => (item.Type !== 'tag') && (item.Type !== 'canary'));
        return (
          <React.Fragment>
            <If condition={!isEmpty(value)}>
              <For index="index" each="item" of={tagList}>
                <i tab={item} style={{ color: '#7a94a9', marginRight: 4, padding: '4px 8px', borderRadius: 10, background: '#ecf2f6', fontStyle: 'normal' }}>{item.Tag || '--'}</i>
              </For>
              <For index="index" each="item" of={cananryList}>
                <span tab={item} style={{ color: '#8979a9', marginRight: 4, padding: '4px 8px', borderRadius: 10, background: '#8979a92e', fontStyle: 'normal' }}>{intl('widget.app.instance.canary', { n: item.Tag })}</span>
              </For>
              <For index="index" each="item" of={otherList}>
                <span tab={item} tyle={{ color: '#a57374', marginRight: 4, padding: '4px 8px', borderRadius: 10, background: '#f7eded', fontStyle: 'normal' }}>{item.Tag || '--'}</span>
              </For>
            </If>
            <If condition={isEmpty(value)}><span style={{ color: '#7a94a9', marginRight: 4, padding: '4px 8px', borderRadius: 10, background: '#ecf2f6', fontStyle: 'normal' }}>{intl('widget.app.canary_no_tag')}</span></If>
          </React.Fragment>
        );
      },
    },
    {
      key: 'RegisterStatus',
      title: intl('widget.app.dynamicline.microservice.status'),
      dataIndex: 'RegisterStatus',
      cell: (value, index, record) => (
        <div style={{ cursor: 'pointer' }}>
          <Status value={value} intl={intl} />
        </div>)
    },
    {
      key: 'operate',
      title: (<div>{intl('widget.common.operating')}<Balloon trigger={triggerIcon} align="t" closable={false}>
        {intl.html('widget.app.dynamicline_instance_help_document')}
      </Balloon></div>),
      dataIndex: 'operate',
      cell: (value, index, record) => (
        <div>
          <If condition={record.RegisterStatus === 0}>
            <div style={{ cursor: 'pointer', color: '#0070cc' }}>
              <span onClick={() => operateRegisterStatsu(record)}>{intl('widget.app.dynamicline.services.online')}</span>
              <span style={{ color: '#3333', margin: '0px 6px' }}>|</span>
              <span onClick={() => handleCreateSnapshot(record)}>{intl('widget.app.dynamicline_create_snapshot')}</span>
              {/* <a href={`https://arms.console.aliyun.com/apm?pid=${AppId}&regionId=${Region}#/${AppId}/apps/{"tabs":"jvm"}`} target="_blank">{intl('widget.app.dynamicline_create_snapshot')}</a> */}
            </div>
          </If>
          <If condition={record.RegisterStatus === 1} >
            <div style={{ cursor: 'pointer', color: '#0070cc' }} onClick={() => operateRegisterStatsu(record)}>
              {intl('widget.app.dynamicline.services_offline')}
            </div>
          </If>
          <If condition={record.RegisterStatus === 2}>
            <div style={{ cursor: 'pointer', color: '#ccc' }} >
              {intl('widget.app.dynamicline.services_offline')}
            </div>
          </If>
          <If condition={record.RegisterStatus === 3}>
            <div style={{ cursor: 'pointer', color: '#ccc' }} >
              {intl('widget.app.dynamicline.services.online')}
            </div>
          </If>
        </div>
      )
    },
  ];
  const searchs = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.fault_injection.tag'),
          value: 'Tags',
          placeholder: intl('widget.fault_injection.tag')
        },
        {
          label: intl('widget.app.address'),
          value: 'Ip',
          placeholder: intl('widget.app.address')
        }
      ],
      defaultValue: 'Tags',
    },
    isCanRefresh,
  };
  const fetchData = async(params) => {
    const res = await services.GetApplicationInstances({
      params: {
        ...params,
        ...searchValues,
      }
    });
    const { Result = [], TotalSize = 0 } = res || {};
    return {
      Data: Result,
      TotalCount: TotalSize,
    };
  };
  const updateInstanceRegisterStatus = async(record) => {
    const { Ip, Pid, RegisterStatus } = record;
    let status;
    if (RegisterStatus === 0) {
      status = 3;
    } else if (RegisterStatus === 1) {
      status = 2;
    }
    await services.UpdateInstanceRegisterStatus({
      params: {
        ...searchValues,
        Ip: Ip || '',
        Pid: Pid || '',
        RegisterStatus: status || 0,
      }
    }).then((res) => {
      if (res) {
        Message.success(intl('widget.common.operate.success'));
      }
    }).catch((err) => {
      Message.success(intl('widget.common.operate.error'));
    });

    setRefreshIndex(Date.now());
  };
  const operateRegisterStatsu = (record) => {
    DialogAlert({
      title: record.RegisterStatus ? intl('widget.app.dynamicline.microservice.services.offline') : intl('widget.app.dynamicline.microservice.services.online'),
      // eslint-disable-next-line jsx-control-statements/jsx-use-if-tag
      content: record.RegisterStatus ? (intl.html('widget.app.dynamicline.instance_message_offline', { Ip: record.Ip })) : intl.html('widget.app.dynamicline.instance_message_online', { Ip: record.Ip }),
      onOk: () => {
        updateInstanceRegisterStatus(record);
      },
      okProps: { children: intl('widget.common.ok') },
      cancelProps: { children: intl('widget.common.cancel') },
      footerActions: ['ok', 'cancel']
    });
  };
  const handleCreateSnapshot = (record) => {
    DialogAlert({
      title: intl('widget.common.tips'),
      // eslint-disable-next-line jsx-control-statements/jsx-use-if-tag
      content: <div>{intl.html('widget.app.dynamicline_create_snapshot_tips_document')}<div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: 16 }}><img width={400} src="https://img.alicdn.com/imgextra/i3/O1CN01OK7qYR1iNhpxRQN6n_!!6000000004401-2-tps-2524-1284.png" /></div></div>,
      onOk: () => { window.open(`https://arms.console.aliyun.com/apm?pid=${AppId}&regionId=${Region}#/${AppId}/apps/{"tabs":"jvm","ip":"${record.Ip}"}/showDump`); },
      okProps: { children: intl('widget.common.ok') },
      cancelProps: { children: intl('widget.common.cancel') },
      footerActions: ['ok', 'cancel'],
      width: '400px',
    });
  };
  return (
    <div>
      <TableContainer
        fetchData={fetchData}
        // search={searchs}
        loading={false}
        primaryKey="Id"
        columns={columns}
        refreshIndex={refreshIndex}
        followTrigger
        pagination={{ shape: 'no-border', type: 'simple', pageSize: '10', pageSizeSelector: false }}
      />
    </div>
  );
};

export default DyncamicLine;
