import OverviewCharts from '../common/OverviewCharts';
import React from 'react';
import styles from './index.css';

const SummaryChartsModel = props => {
  const { meticsOfData = [[], [], []], title, onTooltipChange, onPlotLeave, getG2Charts } = props;
  const SUMMARY_CHARTS_SYSTEM_TITLE = [
    'Load',
    '网络流量',
  ];
  
  const SUMMARY_CHARTS_SYSTEM_TYPE = [
    'load',
    'system_network',
  ];

  // 标题
  const renderTitle = (type) => {
    let titleTips = '系统';
    let chartsTitle = SUMMARY_CHARTS_SYSTEM_TITLE;
    let chartsType = SUMMARY_CHARTS_SYSTEM_TYPE;
    switch (title) {
      case 'system' :
        titleTips = '系统';
        chartsTitle = SUMMARY_CHARTS_SYSTEM_TITLE;
        chartsType = SUMMARY_CHARTS_SYSTEM_TYPE;
        break;
      default :
        titleTips = '系统';
        chartsTitle = SUMMARY_CHARTS_SYSTEM_TITLE;
        chartsType = SUMMARY_CHARTS_SYSTEM_TYPE;
    }

    if (type === 'title') {
      return titleTips;
    } else if (type === 'chartsTitle') {
      return chartsTitle;
    } else if (type === 'chartsType') {
      return chartsType;
    }
  };

  // const modelTitle: any = renderTitle('title');
  const mapChartsTitle = renderTitle('chartsTitle') || SUMMARY_CHARTS_SYSTEM_TITLE;
  const mapChartsType = renderTitle('chartsType') || SUMMARY_CHARTS_SYSTEM_TYPE;

  return (
    <div className={styles.content}>
      {/* <div className={styles.contentTitle}>{modelTitle}</div> */}
      <div className={styles.contentCharts}>
        {mapChartsTitle.map((item, index) => {
          return (
            <OverviewCharts
              curMeticsData={meticsOfData[index]}
              title={item}
              chartsType={mapChartsType[index]}
              typeCharts={mapChartsType[index]}
              // pageType={'summary'}
              chartsWidth={'49.5%'}
              chartDialogtitle={'machine'}
              onTooltipChange={onTooltipChange}
              onPlotLeave={onPlotLeave}
              getG2Charts={getG2Charts}
            />
          );
        })}
        <div className={styles.placeCont}></div>
        <div className={styles.placeCont}></div>
      </div>
    </div>
  );
};

export default SummaryChartsModel;
