import ActiveDemoteRulesTab from './ActiveDemoteRulesTab';
import AddRulesGroup from './AddRulesGroup';
// import AutoRetryRulesTab from './AutoRetryRulesTab';
import CopyRules from './CopyRules';
import DowngradeRulesTab from './DowngradeRulesTab';
import FlowControlTab from './FlowControlTab';
import HotspotRulesTab from './HotspotRulesTab';
import React, { useEffect, useMemo, useRef, useState } from 'react';
// import SystemRulesTab from './SystemRulesTab';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.css';
import { Balloon, Button, Dialog, Icon, Message, Switch, Tab } from '@alicloud/console-components';
import {
  PROMPT,
  RULES_SET_TAB_ITEM,
} from '../common/config/constants/flow';
import { pushUrl, removeParams } from '@ali/sre-utils';
import { getParams, setParams } from 'utils';
// import { useDispatch } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';
import services from 'services';

const SetRules = props => {
  const history = useHistory();
  const intl = useIntl();
  // const dispatch = useDispatch();
  const { pageType = 'guardApp' } = props;
  const isGateWay = pageType === 'gateWay';
  const containerRef = useRef(null);
  const activeType = getParams('activeType') || 'flow_control';
  const appName = getParams('appName') || 'spring-cloud-a';
  const rulesGroup = Number(getParams('rulesGroup')) || 0;
  const [ tabIdx, setTabIdx ] = useState(activeType ? activeType : 'flow_control');
  const [ dialogGroup, setDialogGroup ] = useState(false);
  const [ groupType, setGroupType ] = useState('add');
  const [ modelList, setModelList ] = useState([]);
  const [ selectNewModel, setSelectNewModel ] = useState(0);
  const [ takeEffectModel, setTakeEffectModel ] = useState(-1);
  const [ copyItem, setCopyItem ] = useState({});
  const [ selectModel, setSelectModel ] = useState(rulesGroup);
  const [ selectModelName, setSelectModelName ] = useState('');
  const [ selectModelEnable, setSelectModelEnable ] = useState(false);
  const [ switchStatus, setSwitchStatus ] = useState(false);
  const [ rulesCounts, setRulesCounts ] = useState(0);
  const [ isShowRules, setIsShowRules ] = useState(false);
  const dialogGroupTitle = groupType === 'add' ? intl('ahas_sentinel.systemGuard.flowControl.Newplan') : intl('ahas_sentinel.systemGuard.flowControl.Copyrules');


  useEffect(() => {
    // 请求方案list
    getModelList();
  }, []);

  // 请求方案list
  async function getModelList() {
    const Data = await services.SentinelGetModelList({
      params: {
        AppName: appName,
        namespace: 'default',
      }
    });
    const selectModelArr = Data.length && Data.filter(val => val.Enable);
    const sortSelectModel = Data.length && Data.filter(val => !val.Enable);
    let selectModelId = -1;
    if (selectModelArr?.length) {
      const { Model, ModelName, Enable } = selectModelArr[0];
      selectModelId = Model;
      setSelectModelName(ModelName);
      setSelectModelEnable(Enable);
      setSelectModel(Model);
      setTakeEffectModel(Model);
      setSwitchStatus(true);
      sortSelectModel.unshift(selectModelArr[0]);
    } else if (sortSelectModel?.length) {
      const { Model, ModelName, Enable } = sortSelectModel[0];
      selectModelId = Model;
      setSelectModelName(ModelName);
      setSelectModelEnable(Enable);
      setSelectModel(Model);
      setTakeEffectModel(-1);
    }
    setIsShowRules(true);
    setModelList(Data);
    setSelectNewModel(selectModelId);
  }

  // 设置选中方案下规则数
  function setSelectModelOfRulesCounts(ruleCounts) {
    setRulesCounts(ruleCounts);
  }

  // 确认切换方案提示
  async function onSelTagChange(newModelId, checked) {
    const openModelItem = modelList.filter((val) => val.Id === selectModel || val.Model === selectModel);
    const dialogType = checked ? intl('ahas_sentinel.systemGuard.flowControl.Turnon') : intl('ahas_sentinel.systemGuard.flowControl.shutdown');
    let contentText = '';
    if (rulesCounts) {
      contentText = <span>
        {`${intl('ahas_sentinel.systemGuard.flowControl.Areyousure')} ${dialogType} `}
        <span style={{ color: '#0070CC', fontSize: '14px' }}>{openModelItem[0].ModelName}</span>
        { intl('ahas_sentinel.systemGuard.flowControl.under') }
        <span style={{ color: '#0070CC', fontSize: '14px' }}>{RULES_SET_TAB_ITEM(intl)[tabIdx]}</span>
        {' 的 '}
        <span style={{ color: '#0070CC', fontSize: '14px' }}>{rulesCounts}</span>
        {checked ? intl('ahas_sentinel.systemGuard.flowControl.programs') : intl('ahas_sentinel.systemGuard.flowControl.Rules')}
      </span>;
    } else if (!rulesCounts) {
      contentText = <span>
        {`${intl('ahas_sentinel.systemGuard.flowControl.Areyousure')} ${dialogType} ${intl('ahas_sentinel.systemGuard.flowControl.Program')} `}
        <span style={{ color: '#0070CC', fontSize: '14px' }}>{openModelItem[0].ModelName}</span>
        {' ？'}
      </span>;
    }
    Dialog.confirm({
      title: PROMPT(intl),
      content: contentText,
      onOk: () => getSentinelChangeModel(newModelId),
    });
  }

  // 变更方案并生效规则
  async function getSentinelChangeModel(newModelId) {
    const newId = checkDefaultModelId(newModelId);
    const oldrulesList = modelList.length && modelList.filter(val => val.Id !== newId) || [];
    const oldValueId = oldrulesList.map(x => { return x.Model; });
    const params = {
      AppName: appName,
      OldModel: JSON.stringify(oldValueId),
      NewModel: newId,
    };
    const { Success = false, Code = '', Message: msgPointText = '' } = await dispatch.flowAppModel.getSentinelChangeModel(params);
    handleMessAge(Code, msgPointText, Success, newModelId);
  }

  // 校验默认方案id
  function checkDefaultModelId(val) {
    let modelId = val;
    let defaultModel = [];
    if (val === 0) {
      defaultModel = modelList.filter(val => val.Model === 0);
      modelId = defaultModel[0].Id;
    }
    return modelId;
  }
  function handleGoClusterProtection() {
    pushUrl(history, '/flowProtection/systemGuard/systemGuardClusterProtection', {
      appName,
    });
  }
  // 返回提示
  function handleMessAge(Code, msgPointText, Success, newModelId) {
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheckDialog(msgPointText);
    } else if (Code === 'sentinel.rule.forbidden') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.again')); // 当前 UID 校验不通过，请重试
      return;
    } else if (Code === 'sentinel.cluster.app.level.illegal') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.advanced')); // 应用需开启高级防护才能使用集群限流功能
      return;
    } else if (Code === 'sentinel.cluster.commercial.noBelonging') {
      // Message.warning(intl('ahas_sentinel.systemGuard.flowControl.correspondingexisting')); // 该应用没有对应的集群，请先创建对应的集群或在现有集群中指定该应用
      Message.help(<span style={{ cursor: 'pointer', color: '#0070cc' }} onClick={handleGoClusterProtection}>
      该应用没有对应的集群，请先创建对应的集群或在现有集群中指定该应用(点击跳转)
      </span>);
      return;
    } else if (Code === 'sentinel.cluster.commercial.quota.insufficient') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.maximum')); // 该应用所在集群的 QPS 总量不足，请调整集群最大 QPS
      return;
    } else if (Code === 'sentinel.rule.flow.estimatedMaxClusterQps.tooLarge') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.totalQPS')); // 接口集群总 QPS过大，请确认输入是否正确
    } else if (Code === 'sentinel.rule.ids.blank') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.scheme')); // 该方案下无可生效规则，请在该方案添加可生效规则后再进行方案切换
    } else if (Code === 'flowrule.disable.forbidden') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.effectiveunder')); // 该方案下无可生效规则，请在该方案添加可生效规则后再进行方案切换
    } else if (Code === 'sentinel.rule.ids.tooMany') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.than200')); // 规则数大于200条，请关闭部分无用规则
    } else if (Code === 'sentinel.rulecount.exceed') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.exceeds')); // 规则数超出当前层级最大值
    } else if (Success) {
      Message.success(intl('ahas_sentinel.systemGuard.flowControl.switched'));
      getModelList();
      setSelectModel(newModelId);
      setSelectNewModel(newModelId);
      setTakeEffectModel(newModelId);
      setSwitchStatus(!switchStatus);
    } else {
      Message.error(intl('ahas_sentinel.systemGuard.flowControl.Failedswitch')); // 切换方案失败，请重试
    }
  }

  // 规则Tab切换
  function handleTab(key) {
    setParams('activeType', String(key));
    removeParams('searchKey');
    setTabIdx(String(key));
  }

  // 打开/关闭新建方案弹窗
  function handleOpenOrCloseAddRulesGroup(type, item) {
    type && setGroupType(type);
    item && setCopyItem(item);
    setDialogGroup(!dialogGroup);
    !type && getModelList();
  }

  // 规则tab选择
  function handleSelectTab(key) {
    const selTabList = modelList.filter(item => item.Model === Number(key))[0];
    handleSelectTag(selTabList);
  }

  // 选择tag
  function handleSelectTag(record) {
    const { Model, ModelName, Enable } = record;
    setSelectModelName(ModelName);
    setSelectModelEnable(Enable);
    setSelectModel(Model);
    setSwitchStatus(takeEffectModel === Model);
    setParams('rulesGroup', Model);
  }

  // 删除tab确认弹窗
  function handleCloseTab(key) {
    const { Id, Model, ModelName } = modelList.filter(item => item.Model === Number(key))[0];
    handleDeleTagDialog(Id, Model, ModelName);
  }

  // 删除tag确认弹窗
  function handleDeleTagDialog(id, modelId, modelName) {
    Dialog.alert({
      visible: true,
      title: <span>{intl('ahas_sentinel.systemGuard.flowControl.Confirmdeletionplan')}&nbsp;<span style={{ color: '#0070CC' }}>{modelName}</span>&nbsp;{intl('ahas_sentinel.systemGuard.flowControl.ma')}</span>,
      content: intl('ahas_sentinel.systemGuard.flowControl.restored'),
      onOk: () => handleDeleTag(id, modelId),
      footerActions: [ 'ok', 'cancel' ],
      okProps: {
        children: intl('ahas_sentinel.systemGuard.flowControl.confirmdeletion'),
      },
    });
    return false;
  }

  // 删除方案
  async function handleDeleTag(id, modelId) {
    const { Success = false, Code = '' } = await dispatch.flowAppModel.getSentinelDeleteMultiModel({ ModelId: modelId, Id: id });
    if (Code === 'model.rules.notEmpty') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.Pleasedelete')); // 当前方案下存在限流规则，请删除规则后重新删除此方案
    } else if (Code === 'sentinel.delete.model.forbidden') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.Plerulesanddeleteasedelete')); // 当前方案下存在规则，请删除规则后重新删除此方案
    } else if (Code === 'delete.defaultModel.forbidden') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.cannot')); // 默认方案不可删除
    } else if (Code === 'sentinel.forbidden') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.cannot')); // 无权限操作
    } else if (Code === 'delete.enabled.model.forbidden') {
      Message.warning(intl('ahas_sentinel.systemGuard.flowControl.planisineffect')); // 方案生效中，不可删除
    } else if (Success) {
      Message.success(intl('ahas_sentinel.systemGuard.flowControl.Successfullydeletedplan')); // 删除方案成功
      if (modelId === selectModel) {
        removeParams('rulesGroup');
        setSelectModel(0);
      }
      getModelList();
    } else {
      Message.error(intl('ahas_sentinel.systemGuard.flowControl.Failedtodeleteplan')); // 删除方案失败，请重试
    }
  }

  // 触发校验
  function handleRuleCheckDialog(val) {
    if (containerRef.current.handleRuleCheck) {
      containerRef.current.handleRuleCheck(val);
    }
  }

  // 当前方案状态改变
  function onSwitchChange(checked) {
    onSelTagChange(selectModel, checked);
  }

  // 渲染方案tab
  const renderProgramTab = useMemo(() => {
    return <>
      <div style={{ position: 'relative' }}>
        {modelList?.length > 0 && <Tab
          activeKey={selectModel}
          onChange={handleSelectTab}
          onClose={handleCloseTab}
          shape='wrapped'
          className={styles.programTabBox}
        >
          {
            modelList.map(item => {
              const titleActive = (
                <span className={styles.takeEffectTab}>
                  <Icon type="safety-certificate" />
                  {item.ModelName}
                </span>
              );
              const titleContent = takeEffectModel === item.Model ? titleActive : item.ModelName;
              return (
                <Tab.Item
                  title={titleContent}
                  key={item.Model}
                  closeable={item.Model !== 0}
                >
                  <></>
                </Tab.Item>
              );
            })
          }
        </Tab>}
        <div className={styles.statusOfModel}>
          {modelList?.length > 0 && <div className={styles.takeEffectTag}>
            <span style={{ color: '#555555' }}>
              {intl('ahas_sentinel.systemGuard.flowControl.Currentplan')}
              <span style={{ color: '#111111', fontWeight: 'bold' }}>{` (${selectModelName}) `}</span>
            </span>

            <span style={{ color: '#555555', margin: '0 8px' }}>
              {switchStatus ? intl('ahas_sentinel.systemGuard.flowControl.Hastakeneffect') : intl('ahas_sentinel.systemGuard.flowControl.RuleClosed')}
            </span>

            <Switch
              checked={takeEffectModel === selectModel}
              onChange={onSwitchChange}
              size='small'
            />
          </div>}
          <Button
            type="primary"
            onClick={() => handleOpenOrCloseAddRulesGroup('add')}
          >
            {intl('ahas_sentinel.systemGuard.flowControl.Newplan')}
          </Button>
        </div>
      </div>
    </>;
  }, [ modelList, switchStatus, selectModelName, selectModel, selectNewModel, takeEffectModel, rulesGroup, handleSelectTab, handleCloseTab, handleOpenOrCloseAddRulesGroup, onSwitchChange ]);

  // 流控规则组件、集群流控规则组件
  const renderFlowRules = (
    <FlowControlTab
      key={takeEffectModel || selectModel}
      activeType={'flow'}
      isGateWay={isGateWay}
      wrapRef={containerRef}
      selectModel={selectModel}
      selectModelEnable={selectModelEnable}
      modelList={modelList}
      copyRulesGroup={handleOpenOrCloseAddRulesGroup}
      setRulesCount={setSelectModelOfRulesCounts}
    />
  );

  // 隔离规则组件
  const renderIsolateRules = (
    <FlowControlTab
      key={takeEffectModel || selectModel}
      activeType={'isolate'}
      wrapRef={containerRef}
      selectModel={selectModel}
      selectModelEnable={selectModelEnable}
      modelList={modelList}
      copyRulesGroup={handleOpenOrCloseAddRulesGroup}
      setRulesCount={setSelectModelOfRulesCounts}
    />
  );

  // 熔断规则组件
  const renderLevelRules = (
    <DowngradeRulesTab
      selectModel={selectModel}
      selectModelEnable={selectModelEnable}
      modelList={modelList}
      wrapRef={containerRef}
      copyRulesGroup={handleOpenOrCloseAddRulesGroup}
      setRulesCount={setSelectModelOfRulesCounts}
    />
  );

  // 主动降级规则
  const renderActiveDemote = (
    <ActiveDemoteRulesTab
      selectModel={selectModel}
      selectModelEnable={selectModelEnable}
      modelList={modelList}
      wrapRef={containerRef}
    />
  );

  // 热点规则组件
  const renderHotSpotRules = (
    <HotspotRulesTab
      resource={''}
      selectModel={selectModel}
      selectModelEnable={selectModelEnable}
      modelList={modelList}
      wrapRef={containerRef}
      copyRulesGroup={handleOpenOrCloseAddRulesGroup}
      setRulesCount={setSelectModelOfRulesCounts}
    />
  );

  return (
    <div className={styles.rulesTabContent}>
      {false && renderProgramTab}
      {isShowRules && <Tab
        activeKey={tabIdx}
        onChange={handleTab}
      >
        <Tab.Item
          title={isGateWay ? intl('ahas_sentinel.systemGuard.flowControl.ClusterFlowControlRules') : intl('ahas_sentinel.systemGuard.flowControl.Flowcontrolrules')} //流控规则
          key='flow_control'
          style={{ background: '#FFF' }}
        >
          {tabIdx === 'flow_control' ? <div>{renderFlowRules}</div> : <div></div>}
        </Tab.Item>
        <Tab.Item
          title={'隔离规则'} // 隔离规则、并发规则
          key='quarantine'
          style={{ background: '#FFF' }}
        >
          {tabIdx === 'quarantine' ? <div>{renderIsolateRules}</div> : <div></div>}
        </Tab.Item>
        <Tab.Item
          title={intl('ahas_sentinel.systemGuard.flowControl.Fuserules')} // 熔断规则
          key='downGrade'
          style={{ background: '#FFF' }}
        >
          {tabIdx === 'downGrade' ? <div>{renderLevelRules}</div> : <div></div>}
        </Tab.Item>
        <Tab.Item
          title={intl('ahas_sentinel.systemGuard.flowControl.ActiveDemotion')} // 主动降级规则
          key='activeDemote'
          style={{ background: '#FFF' }}
        >
          {tabIdx === 'activeDemote' ? <div>{renderActiveDemote}</div> : <div></div>}
        </Tab.Item>
        <Tab.Item
          title={intl('ahas_sentinel.systemGuard.flowControl.Hotspotrules')} // 热点规则
          key='hotSpot'
          style={{ background: '#FFF' }}
        >
          {tabIdx === 'hotSpot' ? <div>{renderHotSpotRules}</div> : <div></div>}
        </Tab.Item>
      </Tab>}

      {/* 新建规则方案/复制规则弹窗 */}
      <Dialog
        closeable={true}
        visible={dialogGroup}
        footer={<span></span>}
        onClose={handleOpenOrCloseAddRulesGroup}
        title={dialogGroupTitle}
      >
        {groupType === 'add' ?
          <AddRulesGroup
            onCloseDialog={handleOpenOrCloseAddRulesGroup}
          /> :
          <CopyRules
            activeTabIdx={tabIdx}
            record={copyItem}
            handleRuleCheck={handleRuleCheckDialog}
            onCloseDialog={handleOpenOrCloseAddRulesGroup}
          />}
      </Dialog>
    </div>
  );
};

export default SetRules;
