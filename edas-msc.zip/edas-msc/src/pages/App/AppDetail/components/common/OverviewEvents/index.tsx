import ChartsDialog from '../ChartsDialog';
import React, { FC, useState } from 'react';
import moment from 'moment';
import styles from './index.css';
import { Balloon } from '@alicloud/console-components';
import { getParams, pushUrl } from '@ali/sre-utils';
import { useDispatch } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';

interface IDataSource {
  app: string;
  gmtCreate: number;
  gmtModified: number;
  resource: string;
  eventType: number;
}
interface EventsProps {
  appEvents: IDataSource[];
}

const OverviewEvents: FC<EventsProps> = props => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { appEvents } = props;
  const appName = getParams('edasAppId') || getParams('appName') || null;
  const ns = getParams('ns') || null;
  const region = getParams('region') || null;
  const [ visible, setVisible ] = useState(false);
  const [ resources, setResources ] = useState('');
  const [ endTime, setEndTime ] = useState(Date.parse(new Date().toString()));
  const [ startTime, setStartTime ] = useState(Date.parse(new Date().toString()) - (1000 * 60 * 30));
  const [ dialogTitle, setDialogTitle ] = useState('接口名');

  // 渲染事件类型
  function renderEventType(type: number) {
    switch (type) {
      case 0 :
        return '[限流]';
      case 1 :
        return '[调用异常]';
      case 2 :
        return '[CPU利用率过高]';
      case 3 :
        return '[熔断]';
      case 4 :
        return '[系统保护]';
      case 5 :
        return '[热点流控]';
      case 6 :
        return '[主动降级]';
      default:
        return '[--]';
    }
  }

  // 打开历史弹窗
  function handleOpenDialog(resources: string, startTime: number, endTime: number) {
    setResources(resources);
    setStartTime(startTime);
    setEndTime(endTime);
    setVisible(true);
    setDialogTitle(resources);
  }

  // 关闭历史弹窗
  function handleHiddin() {
    setVisible(false);
  }

  // 历史数据请求接口
  function getApi() {
    return dispatch.flowAppModel.getQuerySentinelMetricsOfResource;
  }

  // 跳转至事件中心
  function handleGoEventsCenter() {
    window.goldlog.record('/ahas-flow.guard_api_details.browse_events_center', 'CLK', '', 'GET');
    pushUrl(history, '/flowProtection/systemGuard/systemGuardGeneral', {
      appName,
      ns,
      region,
      tabKey: 2,
    });
  }

  return (
    <>
      <div className={styles.content}>
        <div className={styles.contentEventsTitle}>
          防护事件
          <Balloon
            trigger={
              <i
                className={'iconfont icon-Ahas_chakanquanbushijian'}
                onClick={handleGoEventsCenter}
              />
            }
            closable={false}
          >
            查看事件中心
          </Balloon>
        </div>
        <ul className={styles.contentEventsBox}>
          {
            appEvents.length > 0 ? (appEvents.map((item, index) => {
              return (
                <li key={index}>
                  <span>{renderEventType(item.eventType)}</span>
                  <span>{moment(new Date(item.gmtModified)).format('YYYY-MM-DD HH:mm:ss')}</span>
                  <span
                    onClick={() => handleOpenDialog(item.resource, item.gmtCreate, item.gmtModified)}
                  >{item.resource}</span>
                </li>
              );
            })) : (
              <div className={styles.contentEventsNoData}>暂无数据</div>
            )
          }
        </ul>
      </div>
      <ChartsDialog
        dialogTitle={dialogTitle}
        visible={visible}
        typeCharts={'all'}
        handleHiddin={handleHiddin}
        getApi={getApi}
        resource={resources}
        startTime={startTime}
        endTime={endTime}
        title={'api'}
      />
    </>
  );
};

export default OverviewEvents;
