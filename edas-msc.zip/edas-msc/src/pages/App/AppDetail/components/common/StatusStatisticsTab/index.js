import ChartsDialog from '../ChartsDialog';
import LineChart from '../LineChart';
import React, { useEffect, useState } from 'react';
import VersionTab from '../VersionTab';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.css';
import { Badge, Balloon, Icon, Loading } from '@alicloud/console-components';
import { compare } from 'utils/util';
import { debounce } from 'lodash';
import { pushUrl } from '@ali/sre-utils';
import { getParams } from 'utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';
import { useInterval } from '@ali/sre-utils-hooks';

const StatusStatisticsTab = props => {
  const intl = useIntl();
  const endTime = new Date().getTime();
  const startTime = endTime - 5 * 60 * 1000;
  const topStartTime = endTime - 1 * 60 * 1000;
  const appName = getParams('appName') || '';
  const dispatch = useDispatch();
  const history = useHistory();
  const appVersion = useSelector(({ flowAppModel }) => flowAppModel.appVersion);

  const [ errorCodeChartData, setErrorCodeChartData ] = useState([]);
  const [ statusCodeChartData, setStatusCodeChartData ] = useState([]);
  const [ isLoading, setIsLoading ] = useState(false);
  const [ topStatusData, setTopStatusData ] = useState([]);
  const [ visible, setVisible ] = useState(false);
  const [ dialogTitle, setDialogTitle ] = useState();
  const [ typeCharts, setTypeCharts ] = useState('errorCode');
  // 获取g2图表实例
  const [ errorCodeChart, setErrorCodeChart ] = useState();
  const [ statusCodeChart, setStatusCodeChart ] = useState();

  const { tabType, resource = '', StatusStatistics } = props;
  const hasLegend = tabType === 'statusOfNode';

  const fixedSDKVersion = intl('ahas_sentinel.SystemGuardMachineDetails.java.sdk.version');
  const fixedAGENTVersion = intl('ahas_sentinel.SystemGuardMachineDetails.java.agent.version');

  let javaSdk,
    javaAgent;
  if (appVersion) {
    const { JAVA_SDK, JAVA_AGENT } = appVersion;
    javaSdk = JAVA_SDK;
    javaAgent = JAVA_AGENT;
  }

  useEffect(() => {
    if (tabType === 'statusStatistics' || tabType === 'statusOfNode') {
      setIsLoading(true);
      togetherQuery();
    }
  }, [ tabType, resource ]);

  useInterval(() => {
    // 轮询请求接口
    togetherQuery();
  }, 10000);

  async function togetherQuery() {
    const [ statusData, topStatusData ] = await Promise.all([
      doQueryStatusCode(),
      doQueryTopStatusCode(),
    ]);
    initChartData(statusData);
    initTopStatusData(topStatusData);
  }

  function initTopStatusData(data) {
    let topStatusData = [];
    // 将值为0的数据过滤掉
    topStatusData = data?.filter((item) => item.Val !== 0);
    // 只取前五条数据
    topStatusData = topStatusData.slice(0, 5);

    setTopStatusData(topStatusData);
    writeSessionStorage(topStatusData);
  }

  // 数据写入sessionStorage
  function writeSessionStorage(data) {
    if (!sessionStorage.getItem('topStatusApi')) {
      const topStatusApiAry = [];
      !!data && data.forEach((item, index) => {
        topStatusApiAry[index] = item.Key;
      });
      topStatusApiAry[data.length] = 'flag';
      sessionStorage.setItem('topStatusApi', topStatusApiAry.join());
    }
  }

  // 查询TopN错误码数据
  async function doQueryTopStatusCode() {
    if (resource) return [];
    const Params = {
      AppName: appName,
      StartTime: topStartTime,
      EndTime: endTime,
    };

    const topStatusData = await dispatch.flowAppModel.getQueryStatusTopOfApplication(
      Params,
    );

    return await topStatusData;
  }

  // 查询状态码图表数据
  async function doQueryStatusCode() {
    const Params = {
      AppName: appName,
      StartTime: startTime,
      EndTime: endTime,
    };

    if (resource) {
      Params.Resource = resource;
    }

    let statusData = [];

    if (resource) {
      statusData = await dispatch.flowAppModel.queryStatusNotFineOfResource(
        Params,
      );
    } else {
      statusData = await dispatch.flowAppModel.getQueryStatusNotFineOfApplication(
        Params,
      );
    }

    setIsLoading(false);
    return await statusData;
  }

  // 构建状态码图表数据
  function initChartData(statusData) {
    const errorCadeChartData = [];
    const statusCodeChartData = [];

    !!statusData && statusData.forEach((item) => {
      errorCadeChartData.push({
        time: item.Time,
        type: '错误状态码数',
        count: item.ErrorNum,
      });

      statusCodeChartData.push({
        time: item.Time,
        type: '200',
        count: item.Is200,
      });
      statusCodeChartData.push({
        time: item.Time,
        type: '2xx',
        count: item.Like2xx,
      });
      statusCodeChartData.push({
        time: item.Time,
        type: '3xx',
        count: item.Like3xx,
      });
      statusCodeChartData.push({
        time: item.Time,
        type: '4xx',
        count: item.Like4xx,
      });
      statusCodeChartData.push({
        time: item.Time,
        type: '5xx',
        count: item.Like5xx,
      });
      if (tabType !== 'statusOfNode') {
        statusCodeChartData.push({
          time: item.Times,
          type: '4xx + 5xx',
          count: item.ErrorNum,
        });
      }
    });

    setErrorCodeChartData(errorCadeChartData);
    setStatusCodeChartData(statusCodeChartData);
  }

  function handelViewApi(value) {
    const activeResourceName = value;
    dispatch.flowAppModel.setApiActiveName({
      activeResourceName,
      favorite: false,
      hasRule: false,
      type: 0,
    });
    pushUrl(history, '/flowProtection/systemGuard/SystemGuardApiDetails', {
      appName,
    });

    const topStatusApiAry = sessionStorage.getItem('topStatusApi')?.split(',').filter(item => value !== item) || [];

    sessionStorage.setItem('topStatusApi', topStatusApiAry.join());
  }

  function renderApiName(item) {
    const topStatusApiAry = sessionStorage.getItem('topStatusApi')?.split(',');

    if (topStatusApiAry?.indexOf(item.Key) !== -1) {
      return (
        <Badge dot>
          <a onClick={() => handelViewApi(item.Key)} style={{ cursor: 'pointer' }}>{item.Key}</a>
        </Badge>
      );
    }
    return <a onClick={() => handelViewApi(item.Key)} style={{ cursor: 'pointer' }}>{item.Key}</a>;
  }

  function handleHistoryOpen(title, typeCharts) {
    setDialogTitle(title);
    setTypeCharts(typeCharts);
    setVisible(true);
  }

  function handleChartHidden() {
    setVisible(false);
  }

  function getApi() {
    if (resource) {
      return dispatch.flowAppModel.queryStatusNotFineOfResource;
    }
    return dispatch.flowAppModel.getQueryStatusNotFineOfApplication;
  }

  function onTooltipChange(tooltips) {
    const { x, y } = tooltips; // tooltip显示的项

    const point = {};

    // 面积图point会是个数组，数组取第一项的值
    function isAry(val) {
      return Object.prototype.toString.call(val) === '[object Array]';
    }

    if (isAry(x)) {
      point.x = x[0];
    } else {
      point.x = x;
    }

    if (isAry(y)) {
      point.y = y[0];
    } else {
      point.y = y;
    }

    errorCodeChart?.showTooltip(point);
    statusCodeChart?.showTooltip(point);
  }

  const onTooltip = debounce(onTooltipChange, 0);

  // 鼠标离开图标时，隐藏所有的tooltip
  function onPlotLeave() {
    if (errorCodeChart && statusCodeChart) {
      errorCodeChart.hideTooltip();
      statusCodeChart.hideTooltip();
    }
  }

  function getG2Charts(type, chart) {
    switch (type) {
      case 'errorCode':
        setErrorCodeChart(chart);
        break;
      case 'statusCode':
        setStatusCodeChart(chart);
        break;
      default:
        return;
    }
  }

  function renderContentBody() {
    if ((javaSdk && compare(javaSdk, fixedSDKVersion)) || (javaAgent && compare(javaAgent, fixedAGENTVersion))) {
      return renderContent();
    }

    return <VersionTab
      sdkVersion={ javaSdk }
      agentVersion={ javaAgent}
    />;
  }

  function renderContent() {
    return (
      <div className={resource ? styles.styleOfResource : styles.styleOfSummary}>
        <div className={styles.resourceitem}>
          <div className={styles.topHead}>
            <div className={styles.topLeft}>
              <span className={resource ? styles.tableTitleOfResource : styles.tableTitleOfSummary}>错误数</span>
              <Balloon align='t' trigger={<Icon type='help' size='xs' className={styles.helpIcon}/>} closable={false}>
                  默认错误码为非2xx 3xx的状态码统计，后续将提供自定义错误功能。
              </Balloon>
            </div>

            <div>
              <a style={{ cursor: 'pointer' }} onClick={() => handleHistoryOpen('错误码统计', 'errorCode')}>历史记录</a>
            </div>
          </div>

          <div className={styles.chartsPanel}>
            {errorCodeChartData?.length ? <LineChart
              chartData={errorCodeChartData}
              type='errorCode'
              height={StatusStatistics ? 250 : 125}
              hasLegend={hasLegend}
              onTooltipChange={onTooltip}
              onPlotLeave={onPlotLeave}
              getG2Charts={getG2Charts}
            /> : (
              <div
                className={styles.contentNoData}
                style={StatusStatistics ? { height: '250px', lineHeight: '250px' } : { height: '125px', lineHeight: '125px' }}
              >暂无数据</div>
            )}
          </div>
        </div>

        <div className={styles.resourceitem}>
          <div className={styles.topHead}>
            <div className={resource ? styles.tableTitleOfResource : styles.tableTitleOfSummary}>
                HTTP-状态码统计
            </div>
            <div>
              <a style={{ cursor: 'pointer' }} onClick={() => handleHistoryOpen('HTTP-状态码统计', 'statusCode')}>历史记录</a>
            </div>
          </div>
          <div className={styles.chartsPanel}>
            {statusCodeChartData?.length ? <LineChart
              chartData={statusCodeChartData}
              type='statusCode'
              height={StatusStatistics ? 250 : 125}
              hasLegend={hasLegend}
              onTooltipChange={onTooltip}
              onPlotLeave={onPlotLeave}
              getG2Charts={getG2Charts}
            /> : (
              <div
                className={styles.contentNoData}
                style={StatusStatistics ? { height: '250px', lineHeight: '250px' } : { height: '125px', lineHeight: '125px' }}
              >暂无数据</div>
            )}
          </div>
        </div>

        {!resource &&
            <div className={styles.resourceitem}>
              <div style={{ marginBottom: 16 }}>
                <span className={styles.tableTitleOfSummary}>
                  错误数TOP5接口
                </span>
                <span className= {styles.tableRight}>
                  以下统计为
                  <span style={{ color: '#428bca' }}>&nbsp;最近一次统计值</span>
                </span>
              </div>

              <div>
                {!!topStatusData && topStatusData.length ? (
                  <ul className={styles.topLsit}>
                    {topStatusData.map((item, index) => (
                      <li key={index}>
                        {renderApiName(item)}
                        <span className={styles.number}>{item.Val}</span>
                      </li>
                    ))}
                  </ul>) : (
                  <div
                    className={styles.contentNoData}
                    style={StatusStatistics ? { height: '250px', lineHeight: '250px' } : { height: '125px', lineHeight: '125px' }}
                  >暂无数据</div>
                )}
              </div>
            </div>
        }
      </div>
    );
  }

  return (
    <>
      <Loading visible={isLoading} style={{ width: '100%' }}>
        {!resource && <span className={styles.cardTitle}>状态统计</span>}
        {renderContentBody()}
      </Loading>

      {/* 查看区间信息 */}
      <ChartsDialog
        typeCharts={typeCharts}
        visible={visible}
        dialogTitle={dialogTitle}
        handleHiddin={handleChartHidden}
        getApi={getApi}
        apiNew={true}
        style={{
          minWidth: 960,
        }}
        resource={resource}
      />
    </>
  );
};

export default StatusStatisticsTab;
