import ConfigurationDialog from '../../../SystemGuard/common/ConfigurationDialog';
import React, { FC, useImperativeHandle, useState } from 'react';
// import SystemGuardGwFlowRuleAdd from '../common/SystemGuardGwFlowRuleAdd';
// import SytemGuardGwChildTable from './SytemGuardGwChildTable';
import styles from './index.css';
import { Dialog } from '@alicloud/console-components';
import { useDispatch } from '@ali/sre-utils-dva';

interface IModelList {
  AppName: string;
  Model: number;
  Enable: boolean;
  ModelName: string;
  Namespace: string;
}

interface IProps {
  resource?: string;
  showHead?: boolean; // 是否展示面包屑和title部分东西
  isGateWay?: boolean;
  setRulesCount?: (val: number) => void;
  updateRulesList?: () => void;
  selectModel?: number;
  selectModelEnable?: boolean;
  modelList?: IModelList[];
  isScene?: boolean;
  wrapRef: any;
}

const DialogForConfiguration: FC<IProps> = props => {
  const { wrapRef, resource = '', isGateWay = true, selectModel, selectModelEnable, updateRulesList } = props;
  const dispatch = useDispatch();
  const [ configurationVisible, setConfigurationVisible ] = useState(false);
  const [ gurationRecord, setGurationRecord ] = useState<any>();

  /* 将子组件的方法暴露给父组件 */
  useImperativeHandle(wrapRef, () => ({
    onOpenConfigurationDialog,
  }));

  // 新建、编辑规则
  function onOpenConfigurationDialog(record?: any) {
    const stepOneDate = {
      resources: resource || '',
      protectionType: 4,
    };
    if (record) {
      const { resource, fallbackObject = '' } = record;
      const ruleObject = record && JSON.stringify(record); // 规则信息
      const fallbackObjectItem = fallbackObject && JSON.parse(fallbackObject) || {}; // 行为信息
      const { appName: AppName = '', id = 0 } = fallbackObjectItem;
      stepOneDate.resources = resource;
      const stepThreeDate = {
        AppName,
        FallbackId: id || 0,
        Resource: resource,
        TargetType: -1,
      };
      dispatch.flowAppModel.setFlowRuleOptionsDataStepTwo(ruleObject);
      dispatch.flowAppModel.setActionDataStepThree(JSON.stringify(stepThreeDate));
    }
    dispatch.flowAppModel.setProtectionSceneDataStepOne(JSON.stringify(stepOneDate));
    setGurationRecord(record);
    setConfigurationVisible(!configurationVisible);
  }

  const ruleType = isGateWay ? '请求分组流控规则' : 'Web 防护规则';
  const dialogTitle = !gurationRecord ? `新增 ${ruleType}`
    : `编辑 ${ruleType}`;

  return (
    <>
      {/* 流程化配置弹窗 */}
      <Dialog
        title={dialogTitle}
        visible={configurationVisible}
        onClose={() => onOpenConfigurationDialog()}
        footer={<></>}
        shouldUpdatePosition={true}
        className={styles.addOrEditDialog}
      >
        <ConfigurationDialog
          record={gurationRecord}
          onCancel={onOpenConfigurationDialog}
          updateRulesList={updateRulesList}
          isGwRules
          isWebParamsRule={!isGateWay}
          selectModel={selectModel}
          selectModelEnable={selectModelEnable}
        />
      </Dialog>
    </>
  );
};

export default DialogForConfiguration;
