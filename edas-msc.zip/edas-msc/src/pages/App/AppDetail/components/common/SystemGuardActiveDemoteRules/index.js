import ActionRulesDialog from '../ActionRulesDialog';
import React, { useEffect, useImperativeHandle, useRef, useState } from 'react';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.css';
import { Balloon, Button, Field, Form, Icon, Input, Message, Select, Switch } from '@alicloud/console-components';
import { compare } from 'utils/util';
import { pushUrl } from '@ali/sre-utils';
import { getParams } from 'utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';

import {
  CANCEL,
  CE_SUCCESS,
  INTER_NAME,
  NEW,
  NEW_AND_SEE,
  NOT_NULL,
  PLEASE_NAME,
  SAVE,
  SAVE_SUCCESS,
  WHETHER_TO_OPEN,
} from '../../common/config/constants/flow';
import { useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import Cookie from 'js-cookie';
const Option = Select.Option;

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

const SystemGuardActiveDemoteRules = props => {
  const intl = useIntl();
  const fixedSDKVersion = intl('ahas_sentinel.SystemGuardPreview.appNewVersion');
  const fixedAgentVersion = intl('ahas_sentinel.SystemGuardPreview.appAgentVersion');
  const history = useHistory();
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const field = Field.useField();
  // const disPatch = useDispatch();
  const containerRef = useRef(null);
  // const appVersion = useSelector(({ flowAppModel }) => flowAppModel.appVersion);
  const [ appVersion, setAppVersion ] = useState({JAVA_SDK: '1.11.2', JAVA_AGENT: '1.11.2'});
  const [ seleId, setSeleId ] = useState(0);
  const [ switchEnableStatus, setSwitchEnableStatus ] = useState(true);
  const { record, onCloseDialog, resource, handleRuleCheck, noRederict = false, isProtection = false, wrapRef } = props;
  const [ webActionRules, setWebActionRules ] = useState([]);
  const [ version, setVersion ] = useState(false);
  const [ javaSdk, setJavaSdk ] = useState('');
  const [ javaAgent, setJavaAgent ] = useState('');
  const [ searchValues, setSearchValues ] = useGlobalState('searchValues');

  useImperativeHandle(wrapRef, () => ({
    handleCheckRuleInput,
  }));

  useEffect(() => {
    // 版本号
    if (appVersion) {
      const { JAVA_SDK = '1.11.2', JAVA_AGENT = '1.11.2' } = appVersion;
      if (compare(fixedSDKVersion, JAVA_SDK) && compare(fixedAgentVersion, JAVA_AGENT)) {
        setVersion(true);
        setJavaSdk(JAVA_SDK);
        setJavaAgent(JAVA_AGENT);
      }
      const Data = services.GetSentinelClientVersionOfApp({
        params: {
          AppName: appName,
          namespace: 'default',
        }
      });
      setAppVersion(Data?.VersionMap);
    }
  }, [appVersion]);

  useEffect(() => {
    if (record?.AppName) {
      field.setValue('resource', record.Resource);
      field.setValue('id', record.id);
      if (record?.FallbackConfig) {
        setSeleId(record.FallbackConfig.id);
      } else {
        setSeleId(0);
      }
      setSwitchEnableStatus(record.Enabled);
    } else {
      setSeleId(0);
    }
    queryActionList();
  }, []);

  // 请求行为list
  async function queryActionList() {
    const params = {
      AppName: appName,
      ClassificationSet: '[1]',
      ResourceClassification: 1,
      RegionId: region || 'cn-hangzhou',
      AhasRegionId: region || 'cn-hangzhou',
      namespace: 'default',
      SourceType: 'MSE',
    };
    const Data = await services.ListSentinelBlockFallbackDefinitions({params});
    Data.unshift({
      AppName: '',
      FallbackBehavior: {},
      Id: 0,
      Name: intl('ahas_sentinel.systemGuard.FuseRules.DefaultBehavior'),
      Namespace: '',
      ResourceClassification: 1,
    });
    if (Data?.length) {
      setWebActionRules(Data);
    }
  }

  // 新增行为弹窗
  function handleAddActionRules() {
    if (containerRef.current.handleActionDialogChange) {
      containerRef.current.handleActionDialogChange();
    }
  }

  // 选择行为
  function onSeleIdChange(id) {
    setSeleId(id);
  }

  // 是否开启
  function handleClickSwitch(value) {
    setSwitchEnableStatus(value);
  }

  function toLowerCase(jsonObj) {
    if (typeof (jsonObj) === 'object') {
      for (const key in jsonObj) {
        jsonObj[key.substring(0, 1).toLowerCase() + key.substring(1)] = jsonObj[key];
        delete (jsonObj[key]);
      }
      return jsonObj;
    }
  }

  // 表单提交校验
  function handleCheckRuleInput() {
    const isAddRule = !record;
    return handleAddRule(isAddRule);
  }

  // 表单提交
  function handleAddRule(isAddRule, viev) {
    let isValid = false;
    if (appVersion) {
      const { JAVA_SDK = '1.11.2', JAVA_AGENT = '1.11.2' } = appVersion;
      if (compare(JAVA_SDK, fixedSDKVersion) || compare(JAVA_AGENT, fixedAgentVersion)) {
        const fieldNeedValidate = [
          'resource',
        ];

        field.validate(fieldNeedValidate, (errors, value) => {
          if (!errors) {

            const submitData = {
              Id: isProtection && !isAddRule && field.getValue('id'),
              AppName: appName,
              Resource: value.resource,
              Enabled: switchEnableStatus,
              FallbackId: seleId,
            };
            if (isProtection) {
              // disPatch.flowAppModel.setFlowRuleOptionsDataStepTwo(JSON.stringify(toLowerCase(submitData)));
              setSearchValues({...searchValues, flowRuleOptionsDataStepTwo: JSON.stringify(toLowerCase(submitData))})
              isValid = true;
            } else {
              fetchUpdateData(submitData, isAddRule, viev);
            }
          }
        });
      } else {
        let warnTips = '应用版本过低，请升级当前应用版本';
        if (compare(fixedSDKVersion, JAVA_SDK) && compare(fixedAgentVersion, JAVA_AGENT)) {
          warnTips = `${intl('ahas_sentinel.systemGuard.FuseRules.versionmore')} ${fixedSDKVersion} ${intl('ahas_sentinel.systemGuard.FuseRules.orAgentVersion')} ${fixedAgentVersion} ${intl('ahas_sentinel.systemGuard.FuseRules.AHASJavaSDK')}: ${JAVA_SDK} ${intl('ahas_sentinel.systemGuard.FuseRules.nowAgentVersion')}: ${JAVA_AGENT}`;
        } else if (compare(fixedSDKVersion, JAVA_SDK)) {
          warnTips = `${intl('ahas_sentinel.systemGuard.FuseRules.versionmore')} ${fixedSDKVersion} ${intl('ahas_sentinel.systemGuard.FuseRules.AHASJavaSDK')}: ${JAVA_SDK}`;
        } else if (compare(fixedAgentVersion, JAVA_AGENT)) {
          warnTips = `${intl('ahas_sentinel.systemGuard.FuseRules.versionAgentmore')} ${fixedSDKVersion} ${intl('ahas_sentinel.systemGuard.FuseRules.AHASJavaAgent')}: ${JAVA_AGENT}`;
        }
        Message.warning(warnTips);
      }
    } else {
      Message.warning(`${intl('ahas_sentinel.systemGuard.FuseRules.versionmore')} ${fixedSDKVersion} ${intl('ahas_sentinel.systemGuard.FuseRules.orAgentVersion')} ${fixedAgentVersion}  ${intl('ahas_sentinel.systemGuard.FuseRules.CanOnlyBeUsed')}`);
    }
    return isValid;
  }

  // 新建、保存规则请求
  async function fetchUpdateData(
    submitData,
    isAddRule,
    viev,
  ) {
    let resData = {};
    let msgTips = '';
    if (isAddRule) {
      msgTips = CE_SUCCESS(intl);
      resData = await services.CreateSentinelManualDegradeRule({
        ...submitData,
      });
    } else {
      submitData.Id = record.Id;
      msgTips = SAVE_SUCCESS(intl);
      resData = await services.UpdateSentinelManualDegradeRule({
        ...submitData,
      });
    }

    console.log(resData, 'resData');

    const {
      Success = false,
      Code,
      Message: msgPointText = '',
    } = resData;

    if (Success) {
      onCloseDialog && onCloseDialog('1');
      viev && addAndViewRules();
      Message.success(msgTips);
    } else {
      handleMessAge(Code, msgPointText);
    }
  }

  // 跳转
  function addAndViewRules() {
    pushUrl(history, '/flowProtection/systemGuard/setRules', {
      appName,
      activeType: 'activeDemote',
    });
  }

  // 返回提示
  function handleMessAge(Code, msgPointText = intl('ahas_sentinel.systemGuard.FuseRules.tryAgain')) {
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msgPointText);
      onCloseDialog && onCloseDialog('0');
    } else if (Code === 'sentinel.rule.manualDegrade.resourceDuplicate') {
      Message.warning(intl('ahas_sentinel.systemGuard.FuseRules.Onlyone'));
    } else {
      Message.error(msgPointText);
    }
  }

  function renderBehavioralInformation() {
    for (const obj of webActionRules) {
      if (obj.Id === seleId) {
        const fallbackBehavior = obj.FallbackBehavior;
        const { webFallbackMode = 0, webRedirectUrl = '', webRespMessage = '', webRespStatusCode = 429, webRespContentType = 0 } = fallbackBehavior;
        if (webFallbackMode) {
          return `${intl('ahas_sentinel.systemGuard.FuseRules.JumpToLink')} ${webRedirectUrl}`;
        }
        if (webRespContentType) {
          return `${intl('ahas_sentinel.systemGuard.FuseRules.JSONString')} ${webRespStatusCode} ${intl('ahas_sentinel.systemGuard.FuseRules.ReturnContent')} = ${webRespMessage}`;
        }
        return `${intl('ahas_sentinel.systemGuard.FuseRules.normalText')} ${webRespStatusCode} ${intl('ahas_sentinel.systemGuard.FuseRules.ReturnContent')} = ${webRespMessage}`;
      }
    }
  }

  const hintLayout = (
    <Icon
      type="prompt"
      size="small"
      style={{ marginLeft: '5px', color: 'rgb(136, 136, 136)' }}
    />
  );

  const { getValue, init } = field;

  return (
    <div className={styles.contentBox}>
      {!isProtection && <Message style={{ marginBottom: '8px' }} type="notice">
        <span>
          {intl('ahas_sentinel.systemGuard.FuseRules.downgrade')}
          {/* <a href={LEVE_RULE} target="_block">
            查看详情
          </a> */}
        </span>
      </Message>}
      {version && (
        <Message style={{ marginBottom: '8px' }} type="warning">
          <span>
            {`${intl('ahas_sentinel.systemGuard.FuseRules.versionmore')} ${fixedSDKVersion} ${intl('ahas_sentinel.systemGuard.FuseRules.OrAgen')} ${fixedAgentVersion} ${intl('ahas_sentinel.systemGuard.FuseRules.CanOnlyBeUsed')}`}
            {javaSdk && `${intl('ahas_sentinel.systemGuard.FuseRules.currentAHAS')} ${javaSdk}`}
            {javaAgent && '、'}
            {javaAgent && `${intl('ahas_sentinel.systemGuard.FuseRules.AgentVersion')} ${javaAgent}`}
          </span>
        </Message>
      )}
      <Form field={field} size={getValue('size')}>
        <Form.Item required {...formItemLayout} label={INTER_NAME(intl)}>
          <Input
            placeholder={PLEASE_NAME(intl)}
            disabled={resource || record ? true : !!record}
            {...init('resource', {
              initValue: resource || (record && record.resource),
              rules: {
                required: true,
                message: NOT_NULL(intl),
              },
            })}
          />
        </Form.Item>
        <Form.Item required {...formItemLayout} label={
          <span style={{ whiteSpace: 'nowrap' }}>
            {intl('ahas_sentinel.systemGuard.FuseRules.Downgrade')}
            <Balloon
              className={styles.ballonBackColor}
              align="t"
              type="primary"
              trigger={hintLayout}
              closable
            >
              <div>
                <p>
                  {intl('ahas_sentinel.systemGuard.FuseRules.behavior')}
                </p>
              </div>
            </Balloon>
          </span>
        }>
          <Select
            style={{ width: '100%' }}
            value={seleId}
            onChange={onSeleIdChange}
          >
            {webActionRules?.length > 0 && webActionRules.map(item => {
              return <Option value={item.Id}>{item.Name}</Option>;
            })}
          </Select>
          <p
            className={styles.addAction}
            onClick={handleAddActionRules}
          >{intl('ahas_sentinel.systemGuard.FuseRules.NewBehavior')}</p>
          {seleId !== 0 && <p className={styles.bgColor} style={{ marginTop: '30px', wordBreak: 'break-all' }}>
            <div>{intl('ahas_sentinel.systemGuard.FuseRules.BehaviorDescription')}</div>
            <div>
              {renderBehavioralInformation()}
            </div>
          </p>}
        </Form.Item>

        <Form.Item {...formItemLayout} label={WHETHER_TO_OPEN(intl)}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <Switch
              checked={switchEnableStatus}
              onChange={handleClickSwitch}
              style={{ marginTop: '3px' }}
              disabled={!!record}
            />
            <span className={styles.to_open} style={{ margin: '5px 0 0 10px' }}>
              {switchEnableStatus
                ? intl('ahas_sentinel.systemGuard.flowControl.ruleIsOpened')
                : intl('ahas_sentinel.systemGuard.FuseRules.ruleIsClosed')}
            </span>
          </div>
        </Form.Item>

        {!isProtection && <div style={{ float: 'right', marginBottom: '16px' }}>
          {record === undefined ? (
            <span>
              {noRederict && (
                <Form.Submit
                  type="primary"
                  onClick={() => {
                    handleAddRule(true, 'viev');
                  }}
                >
                  {NEW_AND_SEE(intl)}
                </Form.Submit>
              )}
              <Form.Submit
                style={{ marginLeft: '8px' }}
                type="primary"
                onClick={() => {
                  handleAddRule(true);
                }}
              >
                {NEW(intl)}
              </Form.Submit>
            </span>
          ) : (
            <Form.Submit
              type="primary"
              onClick={() => {
                handleAddRule(false);
              }}
            >
              {SAVE(intl)}
            </Form.Submit>
          )}
          <Button
            style={{ marginLeft: '8px' }}
            onClick={() => {
              onCloseDialog && onCloseDialog('0');
            }}
          >
            {CANCEL(intl)}
          </Button>
        </div>}
      </Form>

      <ActionRulesDialog
        wrapRef={containerRef}
        fetchData={queryActionList}
      />
    </div>
  );
};

export default SystemGuardActiveDemoteRules;
