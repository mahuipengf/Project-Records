import React, { useEffect, useImperativeHandle, useMemo, useState } from 'react';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.css';
import { APACHE_HTTP_CLIENT, RETRY_RULES_URL } from '../config/constants/flow';
import { Balloon, Button, Dialog, Field, Form, Icon, Input, Message, Radio, Switch, Tag } from '@alicloud/console-components';
import { getParams } from 'utils';
import { useDispatch } from '@ali/sre-utils-dva';

const { Group: TagGroup, Closeable: ClosableTag } = Tag;

const formItemLayout = {
  labelCol: { span: 7 },
  wrapperCol: { span: 17 },
};

const SystemGuardAutoRetryRuleAdd = props => {
  const appName = getParams('appName') || 'spring-cloud-a';
  const field = Field.useField();
  const disPatch = useDispatch();
  const intl = useIntl();
  const [ switchEnableStatus, setSwitchEnableStatus ] = useState(true);
  const [ retryStrategy, setRetryStrategy ] = useState(0);
  const [ retryPredicateStrategy, setRetryPredicateStrategy ] = useState(0);
  const [ closableTagList, setClosableTagList ] = useState([]);
  const [ closableTagShow, setClosableTagShow ] = useState([]);
  const [ visibleTag, setVisibleTag ] = useState(false);
  const [ predicateItem, setPredicateItem ] = useState('');
  const { record, onCloseDialog, resource, handleRuleCheck, isProtection = false, wrapRef } = props;
  const fixedSDKVersion = intl('ahas_sentinel.AutoRetryRulesTab.java.sdk.version');

  useImperativeHandle(wrapRef, () => ({
    handleCheckRuleInput,
  }));

  useEffect(() => {
    if (record) {
      const dateRecord = record.Resource ? record : toUpperCase(record);
      field.setValue('id', dateRecord.Id);
      setRetryStrategy(dateRecord.RetryStrategy);
      setRetryStrategy(dateRecord.RetryStrategy);
      field.setValue('retryBaseIntervalMs', dateRecord.RetryBaseIntervalMs);
      field.setValue('maxRetryTimes', dateRecord.MaxRetryTimes);
      setRetryPredicateStrategy(dateRecord.RetryPredicateStrategy);
      let dataExceptionPredicates = dateRecord.ExceptionPredicates;
      if (typeof dataExceptionPredicates === 'string') {
        dataExceptionPredicates = JSON.parse(dataExceptionPredicates);
      }
      setClosableTagList(dataExceptionPredicates);
      setClosableTagShow(dataExceptionPredicates);
      field.setValue('errorRatioUpperBound', dateRecord.ErrorRatioUpperBound * 100);
      setSwitchEnableStatus(dateRecord.Enable);
    } else {
      setRetryStrategy(0);
      setRetryPredicateStrategy(0);
      setSwitchEnableStatus(true);
    }
  }, []);

  function toUpperCase(jsonObj) {
    if (typeof (jsonObj) === 'object') {
      for (const key in jsonObj) {
        jsonObj[key.substring(0, 1).toUpperCase() + key.substring(1)] = jsonObj[key];
        delete (jsonObj[key]);
      }
      return jsonObj;
    }
  }

  // 是否开启
  function handleClickSwitch(value) {
    setSwitchEnableStatus(value);
  }

  function toLowerCase(jsonObj) {
    if (typeof (jsonObj) === 'object') {
      for (const key in jsonObj) {
        jsonObj[key.substring(0, 1).toLowerCase() + key.substring(1)] = jsonObj[key];
        delete (jsonObj[key]);
      }
      return jsonObj;
    }
  }

  // 表单提交校验
  function handleCheckRuleInput() {
    const isAddRule = !record;
    return handleAddRule(isAddRule);
  }

  // 表单提交
  function handleAddRule(isAddRule) {
    let isValid = false;

    const fieldNeedValidate = [ 'resource', 'retryStrategy', 'retryBaseIntervalMs', 'maxRetryTimes', 'retryPredicateStrategy', 'exceptionPredicates' ];

    if (!closableTagList?.length) {
      Message.warning('异常名单不可为空');
      return;
    }

    field.validate(fieldNeedValidate, (errors, value) => {

      if (!errors) {
        const submitData = {
          Id: isProtection && !isAddRule && field.getValue('id'),
          AppName: appName,
          Resource: value.resource || resource,
          RetryStrategy: retryStrategy,
          RetryBaseIntervalMs: value.retryBaseIntervalMs,
          MaxRetryTimes: value.maxRetryTimes,
          RetryPredicateStrategy: retryPredicateStrategy,
          ExceptionPredicates: JSON.stringify(closableTagList),
          // ErrorRatioUpperBound: value.errorRatioUpperBound / 100,
          ErrorRatioUpperBound: 1.0,
          Enable: switchEnableStatus,
        };

        if (isProtection) {
          disPatch.flowAppModel.setFlowRuleOptionsDataStepTwo(JSON.stringify(toLowerCase(submitData)));
          isValid = true;
        } else {
          fetchUpdateData(submitData, isAddRule);
        }
      }
    });
    return isValid;
  }

  async function fetchUpdateData(submitData, isAddRule) {
    let resData = {};
    if (isAddRule) {
      resData = await disPatch.flowAppModel.getCreateSentinelRetryRule({
        ...submitData,
      });
    } else {
      submitData.Id = field.getValue('id');
      resData = await disPatch.flowAppModel.getUpdateSentinelRetryRule({
        ...submitData,
      });
    }

    const { Success = false, Code = '', Message: msgPointText = '' } = resData;

    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msgPointText);
      onCloseDialog && onCloseDialog('0');
    } else if (Success) {
      onCloseDialog && onCloseDialog('1');
      Message.success(isAddRule ? '新建成功' : '保存成功');
    } else {
      Message.error(msgPointText);
    }
  }

  // 重试策略选择
  function radioRetryStrategy(value) {
    setRetryStrategy(Number(value));
  }

  // 重试条件选择
  function radioRetryPredicateStrategy(value) {
    if (Number(value) !== record?.RetryPredicateStrategy) {
      setClosableTagList([]);
    } else {
      setClosableTagList(closableTagShow);
    }
    setRetryPredicateStrategy(Number(value));
  }

  // 白名单/黑名单tag关闭
  function handleCloseTag(tag) {
    const showTagList = closableTagList.filter(item => item !== tag);
    setClosableTagList(showTagList);
    setClosableTagShow(showTagList);
    return true;
  }

  // 新增异常名单
  function handleAddTag() {
    if (!predicateItem) {
      Message.warning('异常名单不可为空');
      return;
    } else if (closableTagList.includes(predicateItem)) {
      Message.warning('异常名单不可重复添加');
      return;
    }
    closableTagList.push(predicateItem);
    onChangeTagDialog();
  }

  // 开启、关闭异常名单弹窗
  function onChangeTagDialog() {
    setVisibleTag(!visibleTag);
  }

  const renderClosableTag = useMemo(() => {
    return (
      <TagGroup className={styles.tagGroup}>
        {
          closableTagList && closableTagList.length > 0 && closableTagList.map(item => {
            return (
              <ClosableTag
                key={item}
                onClose={() => handleCloseTag(item)}
              >
                {item}
              </ClosableTag>
            );
          })
        }
        <Balloon
          align={'r'}
          type={'primary'}
          closable={false}
          trigger={
            <Icon
              type="add"
              onClick={onChangeTagDialog}
            />
          }
        >
          <div style={{ color: '#555' }}>
            新增异常名单
          </div>
        </Balloon>
      </TagGroup>
    );
  }, [ closableTagList, handleCloseTag ]);

  // 输入异常名单
  function handleAddRetryPredicate(value) {
    setPredicateItem(value);
  }

  const hintLayout = (
    <Icon
      type="help"
      size="small"
      className={styles.tipsIcon}
    />
  );

  const { getValue, init } = field;

  return (
    <div className={styles.contentBox}>
      {!isProtection && <Message style={{ marginBottom: '8px' }} type="notice">
        <span>
          自动重试规则仅支持 AHAS Java SDK {fixedSDKVersion} 及以上版本，且仅支持注解方式或 SentinelWrapper 自定义埋点，以及
          <a href={APACHE_HTTP_CLIENT}> Apache HttpClient/OkHttp </a>
          适配生效。
          <a href={RETRY_RULES_URL} target="_block">
            查看详情
          </a>
        </span>
      </Message>}
      <Form field={field} size={getValue('size')}>
        {!isProtection && <Form.Item required {...formItemLayout} label={'资源名称'}>
          <Input
            placeholder="请输入资源名称"
            trim
            disabled={resource || record ? true : !!record}
            {...init('resource', {
              initValue: resource || (record && record.Resource),
              rules: {
                required: true,
                message: '不能为空',
              },
            })}
          />
        </Form.Item>}

        <Form.Item
          {...formItemLayout}
          label={
            <span>
              重试策略
              <Balloon align={'r'} type={'primary'} trigger={hintLayout} closable>
                <div style={{ color: '#555' }}>
                  <p>
                    固定间隔重试：即每次重试之间的时间间隔固定（按照基准重试间隔）。
                  </p>
                  <p>
                    指数间隔重试：即每次重试之间的时间间隔成倍数增长（如基准 1000ms，则每次重试间隔按 1000、2000、3000 这样的趋势递增）。
                  </p>
                </div>
              </Balloon>
            </span>
          }
        >
          <Radio.Group onChange={radioRetryStrategy} value={retryStrategy}>
            <Radio id={'fixed'} value={0}>
              {'固定间隔重试'}
            </Radio>
            <Radio id={'exponential'} value={1}>
              {'指数间隔重试'}
            </Radio>
          </Radio.Group>
        </Form.Item>

        <Form.Item {...formItemLayout} label={'基准重试间隔'} required>
          <Input
            placeholder="基准重试间隔（取值范围：1～10000）"
            trim
            addonTextAfter={<span>ms</span>}
            {...init('retryBaseIntervalMs', {
              initValue: record?.RetryBaseIntervalMs || 500,
              rules: [
                {
                  required: true,
                  message: '不能为空',
                },
                {
                  pattern: /^([1-9]\d{0,3}|10000)$/,
                  message: '请输入 1～10000 内的数字',
                },
              ],
            })}
          />
        </Form.Item>

        <Form.Item {...formItemLayout} label={'最大重试次数'} required>
          <Input
            placeholder="最大重试次数（取值范围：1～10）"
            trim
            {...init('maxRetryTimes', {
              initValue: record?.maxRetryTimes || 3,
              rules: [
                {
                  required: true,
                  message: '不能为空',
                },
                {
                  pattern: /^([1-9]|10)$/,
                  message: '请输入 1～10 内的数字',
                },
              ],
            })}
          />
        </Form.Item>

        <Form.Item
          {...formItemLayout}
          label={
            <span>
              重试条件策略
              <Balloon align={'r'} type={'primary'} trigger={hintLayout} closable>
                <div style={{ color: '#555' }}>
                  <p>
                    异常白名单：即只有在白名单列表内的异常触发时才会重试。
                  </p>
                  <p>
                    异常黑名单：即在黑名单列表里的异常触发时不会进行重试，其余异常都会进行重试。
                  </p>
                </div>
              </Balloon>
            </span>
          }
        >
          <Radio.Group onChange={radioRetryPredicateStrategy} value={retryPredicateStrategy}>
            <Radio id={'whitelist'} value={0}>
              {'异常白名单'}
            </Radio>
            <Radio id={'blacklist'} value={1}>
              {'异常黑名单'}
            </Radio>
          </Radio.Group>
        </Form.Item>

        <Form.Item {...formItemLayout} label={retryPredicateStrategy === 0 ? '白名单异常' : '黑名单异常'} required>
          {renderClosableTag}
        </Form.Item>

        {false && <Form.Item
          {...formItemLayout}
          required
          label={
            <span>
              异常比率容许上界
              <Balloon align={'r'} type={'primary'} trigger={hintLayout} closable>
                <span style={{ color: '#555' }}>
                  当秒级异常比率超过该上限时不再进行重试
                </span>
              </Balloon>
            </span>
          }
        >
          <Input
            placeholder="当秒级异常比率超过 xx% 时不进行重试"
            trim
            addonTextAfter={'%'}
            {...init('errorRatioUpperBound', {
              initValue: record && record.errorRatioUpperBound * 100,
              rules: [
                {
                  required: true,
                  message: '不能为空',
                },
                {
                  pattern: /^(\d|[1-9]\d|100)$/,
                  message: '取值范围 0-100',
                },
              ],
            })}
          />
        </Form.Item>}

        <Form.Item {...formItemLayout} label="是否开启">
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <Switch
              checked={switchEnableStatus}
              onChange={handleClickSwitch}
              style={{ marginTop: '3px' }}
              disabled={!!record?.id}
            />
            <span className={styles.to_open} style={{ margin: '5px 0 0 10px' }}>
              {switchEnableStatus
                ? '该规则打开，创建后即生效'
                : '该规则关闭，不生效'}
            </span>
          </div>
        </Form.Item>

        {!isProtection && <div style={{ float: 'right', marginBottom: '16px' }}>
          {record === undefined ? (
            <span>
              <Form.Submit
                style={{ marginLeft: '8px' }}
                type="primary"
                onClick={() => {
                  handleAddRule(true);
                }}
              >
                新建
              </Form.Submit>
            </span>
          ) : (
            <Form.Submit
              type="primary"
              onClick={() => {
                handleAddRule(false);
              }}
            >
              保存
            </Form.Submit>
          )}
          <Button
            style={{ marginLeft: '8px' }}
            onClick={() => {
              onCloseDialog && onCloseDialog('0');
            }}
          >
            取消
          </Button>
        </div>}
      </Form>

      {/* 新增异常名单 */}
      <Dialog
        title='添加异常名单'
        visible={visibleTag}
        onOk={handleAddTag}
        onCancel={onChangeTagDialog}
        onClose={onChangeTagDialog}
        style={{ width: '400px' }}
      >
        <ul className={styles.addTag}>
          <li>
            {retryPredicateStrategy === 0 ? '白名单异常' : '黑名单异常'}
          </li>
          <li>
            <Input
              placeholder="请输入异常名单"
              trim
              onChange={handleAddRetryPredicate}
            />
          </li>
        </ul>
      </Dialog>
    </div>
  );
};

export default SystemGuardAutoRetryRuleAdd;
