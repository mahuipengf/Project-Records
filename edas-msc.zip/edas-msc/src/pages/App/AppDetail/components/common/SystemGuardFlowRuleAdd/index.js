// import ClusterTollDialog from '../ClusterTollDialog';
import React, { useEffect, useImperativeHandle, useState } from 'react';
import _ from 'lodash';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.less';
import {
  BULK_REQUEST,
  CANCEL,
  C_THRES,
  EVERY_REQUEST,
  FLOW_EFFECT,
  FLOW_RULE,
  HIDE_AD_OP,
  HOUR,
  INTER_NAME,
  MILLISSECOND,
  MINUTE,
  NEW,
  NEW_AND_SEE,
  NGINX_FLOW_RULE,
  NOTE,
  NOT_NULL,
  PLEASE_ENTER,
  PLEASE_NAME,
  PLEASE_NUMBER,
  QUARA_RULE,
  SAVE,
  SECOND,
  SEE_DETAILS,
  SHOW_AD_OP,
  SOURCE_APPLICATION,
  STA_DIME,
  STH_QPS,
  THRESSHOULD,
  WHETHER_TO_OPEN,
} from '../../common/config/constants/flow';
import {
  Balloon,
  Button,
  Field,
  Form,
  Icon,
  Input,
  Message,
  Radio,
  Select,
  Switch,
} from '@alicloud/console-components';
import { compare } from 'utils/util';
import { pushUrl } from '@ali/sre-utils';
import { getParams } from 'utils';
// import { useDispatch } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';
import { useGlobalState } from '@ali/widget-hooks';
import Cookie from 'js-cookie';

const Option = Select.Option;

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

const SystemGuardFlowRuleAdd = porps => {
  const { onCloseDialog, updateRulesList, resource, record, activeType, handleRuleCheck, noRederict = false, refresh, selectModel, selectModelEnable, isQuote = false, isGateWay = false, isProtection = false, wrapRef } = porps;
  const history = useHistory();
  const intl = useIntl();
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const regionId = getParams('region');
  const field = Field.useField();
  // const disPatch = useDispatch();
  const [ switchEnableStatus, setSwitchEnableStatus ] = useState(false);
  const [ clusterMode, setClusterMode ] = useState(isGateWay);
  const [ strategy, setStrategy ] = useState(0);
  const [ controlBehavior, setControlBehavior ] = useState(0);
  const [ clusterThresholdType, setClusterThresholdType ] = useState(1);
  const [ clusterRequestMode, setClusterRequestMode ] = useState(0);
  const [ fallbackToLocalWhenFail, setFallbackToLocalWhenFail ] = useState(true);
  const [ timeType, setTimeType ] = useState('second');
  const [ statIntervalMs, setStatIntervalMs ] = useState(1);
  const [ advShow, setAdvShow ] = useState(true);
  const [ machineNum, setMachineNum ] = useState(0);
  const [ aplList, setAplList ] = useState([]);
  const isNginx = sessionStorage.getItem('isNginx') === 'true';
  const isNewVersio = sessionStorage.getItem('isNewVersion') === 'true';
  const DATUM_VERSION = intl('ahas_sentinel.SystemGuardPreview.appNewVersion');
  const [ autoAdjustFallbackThresholdEnabled, setAutoAdjustFallbackThresholdEnabled ] = useState(false);
  // const isAutoToll = sessionStorage.getItem('isAutoToll') !== 'true';
  // const [ tollDialogVisible, setTollDialogVisible ] = useState(false);
  const [ searchValues, setSearchValues ] = useGlobalState('searchValues');

  /* 将子组件的方法暴露给父组件 */
  useImperativeHandle(wrapRef, () => ({
    handleCheckRuleInput,
  }));

  useEffect(() => {
    if (record) {
      const { windowIntervalMs } = record;
      field.setValue('id', record.id);
      setControlBehavior(record.controlBehavior);
      setStrategy(record.strategy);
      setClusterMode(record.clusterMode);
      setClusterThresholdType(clusterThresholdType);
      setFallbackToLocalWhenFail(record.fallbackToLocalWhenFail);
      setSwitchEnableStatus(record.enable);
      setClusterRequestMode(record.clusterRequestMode);
      setAutoAdjustFallbackThresholdEnabled(record.autoAdjustFallbackThresholdEnabled);
      setStatIntervalMs(chackStatIntervalMs(windowIntervalMs));
      field.setValue('WindowIntervalMs', chackStatIntervalMs(windowIntervalMs));
      if (record.controlBehavior !== 0 || record.strategy !== 0) {
        setAdvShow(false);
      }
      if (record.clusterMode) {
        querySentinelAppMachineList();
      }
    } else {
      isNginx && setClusterRequestMode(1);
      setSwitchEnableStatus(selectModelEnable || false);
      isNginx && queryApiDefinitionsListForApp();
    }
  }, []);

  // 是否开启
  function handleClickSwitch(value) {
    setSwitchEnableStatus(value);
  }

  // 校验统计时长
  function chackStatIntervalMs(windowIntervalMs) {
    let statIntervalMs = 0;
    if (
      windowIntervalMs % 60000 !== 0 ||
      (windowIntervalMs > 0 && windowIntervalMs < 60000)
    ) {
      statIntervalMs = windowIntervalMs / 1000;
      setTimeType('second');
    } else if (windowIntervalMs >= 60000 && windowIntervalMs < 3600000) {
      statIntervalMs = windowIntervalMs / (1000 * 60);
      setTimeType('minute');
    } else {
      statIntervalMs = windowIntervalMs / (1000 * 60 * 60);
      setTimeType('hour');
    }
    if (statIntervalMs % 1 !== 0) {
      statIntervalMs = _.floor(statIntervalMs, 2);
    }
    return statIntervalMs;
  }

  // 退化阈值自动调整是否开启
  function handleClickAutoConfigSwitch(value) {
    if (isNewVersio) {
      setAutoAdjustFallbackThresholdEnabled(value);
    } else {
      Message.warning(`${intl('ahas_sentinel.systemGuard.flowControl.sdkVersion')}${DATUM_VERSION} ${intl('ahas_sentinel.systemGuard.flowControl.useVersion')}`);
    }
  }

  // 获取机器数
  async function querySentinelAppMachineList() {
    const { Data = {}, Success = false } = await services.SentinelAppMachineList({ AppName: String(appName) });
    if (Success && Data?.length) {
      const healthArr = Data.filter((item) => item.health === true);
      setMachineNum(healthArr.length);
    }
  }

  // 获取api配置列表
  async function queryApiDefinitionsListForApp() {
    const { Data = {}, Success = false } = await services.SentinelHttpApiMatchQueryForApp({
      AppName: appName,
    });
    const { apiList = [] } = Data;
    let selectApiList = [];
    if (Success && apiList.length) {
      selectApiList = apiList.map((item) => item.apiName);
    }
    setAplList(selectApiList);
  }

  function handleGoClusterProtection() {
    pushUrl(history, '/flowProtection/systemGuard/systemGuardClusterProtection', {
      appName,
    });
  }

  // 表单提交校验
  function handleCheckRuleInput() {
    const isAddRule = !record;
    return handleAddRule(isAddRule);
  }

  function toLowerCase(jsonObj) {
    if (typeof (jsonObj) === 'object') {
      for (const key in jsonObj) {
        jsonObj[key.substring(0, 1).toLowerCase() + key.substring(1)] = jsonObj[key];
        delete (jsonObj[key]);
      }
      return jsonObj;
    }
  }

  // 表单提交
  function handleAddRule(isAddRule, viev) {
    let isValid = false;
    field.validate((errors, value) => {
      if (!errors) {
        let timeMs = Number(value.WindowIntervalMs);
        if (timeType === 'second') {
          timeMs = timeMs * 1000;
        } else if (timeType === 'minute') {
          timeMs = timeMs * 1000 * 60;
        } else {
          timeMs = timeMs * 1000 * 60 * 60;
        }
        if (timeMs > 86400000) {
          Message.warning(intl('ahas_sentinel.systemGuard.24h')); // 统计窗口时长不可超过 24 小时，请重新输入
          return;
        }

        const submitData = {
          Id: isProtection && !isAddRule && field.getValue('id'),
          AppName: appName,
          Resource: value.resource || resource,
          LimitApp: value.limitApp || 'default',
          Grade: !activeType ? 1 : 0,
          Count: value.count || '',
          Strategy: strategy,
          RefResource: value.refResource || '',
          ControlBehavior: controlBehavior,
          WarmUpPeriodSec: value.warmUpPeriodSec || '',
          MaxQueueingTimeMs: value.maxQueueingTimeMs || '',
          ClusterMode: clusterMode,
          ClusterThresholdType: clusterThresholdType,
          FallbackToLocalWhenFail: fallbackToLocalWhenFail,
          SampleCount: 1,
          WindowIntervalMs: timeMs || 1000,
          Enable: switchEnableStatus,
          EstimatedMaxClusterQps: value.estimatedMaxClusterQps || '', // 接口集群总 QPS
          ClusterFallbackThreshold: autoAdjustFallbackThresholdEnabled ? value.fallbackThresholdAdjustMargin : (fallbackToLocalWhenFail
            ? value.clusterFallbackThreshold || ''
            : value.count || ''), // 单机退化阈值
          ClusterRequestMode: clusterRequestMode, // 通信请求模式
          Model: selectModel || 0,
          AutoAdjustFallbackThresholdEnabled: autoAdjustFallbackThresholdEnabled,
          FallbackThresholdAdjustMargin: value.fallbackThresholdAdjustMargin,
        };
        if (isProtection) {
          // window.flowRuleOptionsDataStepTwo = JSON.stringify(toLowerCase(submitData));
          setSearchValues({...searchValues, flowRuleOptionsDataStepTwo: JSON.stringify(toLowerCase(submitData))})
          isValid = true;
        } else {
          fetchUpdateData(submitData, isAddRule, viev);
        }
      }
    });
    return isValid;
  }
  async function fetchUpdateData(
    submitData,
    isAddRule,
    viev,
  ) {
    let resData = {};
    if (isAddRule) {
      resData = await services.SentinelFlowRuleNew({ ...submitData });
    } else {
      submitData.id = field.getValue('id');
      resData = await services.SentinelFlowRuleEdit({
        params: {
          ...submitData,
          RegionId: region,
          AhasRegionId: region,
          namespace: 'default',
          Namespace: 'default',
          NameSpace: 'default',
        }
      });
    }

    const {
      Success = false,
      Code,
      Message: msgPointText = '',
    } = resData;
    handleMessAge(Code, msgPointText, Success, isAddRule);
    if (Success) {
      onCloseDialog && onCloseDialog('1');
      updateRulesList && updateRulesList();
      isAddRule && viev && addAndViewRules();
    }
  }

  // 跳转
  function addAndViewRules() {
    const typeKey = activeType ? 'quarantine' : 'flow_control';
    pushUrl(history, '/flowProtection/systemGuard/setRules', {
      appName,
      activeType: typeKey,
    });
  }

  // 返回提示
  function handleMessAge(Code, msgPointText, success, isAddRule) {
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msgPointText);
      onCloseDialog && onCloseDialog('0');
    } else if (Code === 'sentinel.cluster.app.level.illegal') {
      Message.warning(intl('ahas_sentinel.systemGuard.currentLim')); // 应用需开启高级防护才能使用集群限流功能
      return;
    } else if (Code === 'sentinel.cluster.commercial.noBelonging') {
      // Message.warning(intl('ahas_sentinel.systemGuard.noBelonging')); // 该应用没有对应的集群，请先创建对应的集群或在现有集群中指定该应用
      Message.help(<span style={{ cursor: 'pointer', color: '#0070cc' }} onClick={handleGoClusterProtection}>
        该应用没有对应的集群，请先创建对应的集群或在现有集群中指定该应用(点击跳转)
      </span>);
      return;
    } else if (Code === 'sentinel.cluster.commercial.quota.insufficient') {
      Message.warning(intl('ahas_sentinel.systemGuard.insufficient')); // '该应用所在集群的 QPS 总量不足，请调整集群最大 QPS'
      return;
    } else if (Code === 'sentinel.rule.flow.estimatedMaxClusterQps.tooLarge') {
      Message.warning(intl('ahas_sentinel.systemGuard.tooLarge')); // 接口集群总 QPS过大，请确认输入是否正确'
    } else if (Code === 'sentinel.cluster.still.disabled') {
      Message.warning(intl('ahas_sentinel.systemGuard.disabled')); // '请开启集群后创建流控规则'
    } if (success) {
      Message.success(isAddRule ? intl('ahas_sentinel.systemGuard.cucesss') : intl('ahas_sentinel.systemGuard.savesuccess'));
    }
  }

  // 集群流控商业化收费详情弹窗
  // function handleChangeTollDialog() {
  //   setTollDialogVisible(!tollDialogVisible);
  // }

  const { getValue, init } = field;
  const countType = clusterMode
    ? clusterThresholdType === 1
      ? C_THRES(intl)
      : STH_QPS(intl)
    : STH_QPS(intl);

  // 校验 Nginx 应用是否可以开启集群流控
  function checkNginxAppForOpenCluster() {
    const sdkVersion = sessionStorage.getItem('sdkVersion') || '1.0.0';
    const nginxAppVersion = intl('ahas_sentinel.SystemGuardFlowRuleAdd.nginxAppVersion'); // 1.9.4
    const isPassSdkVersion = compare(sdkVersion, nginxAppVersion);

    if (!isPassSdkVersion) {
      Message.warning(`开启集群流控功能需当前应用 SDK Version >= ${nginxAppVersion}，当前应用 SDK Version ：${sdkVersion}，请升级 SDK Version 后再进行此操作。`);
      return false;
    }
    return true;
  }

  function switchClusterMode(value) {
    if (value && isNginx && !checkNginxAppForOpenCluster()) {
      return;
    }
    if (value) {
      querySentinelAppMachineList();
      // isAutoToll && handleChangeTollDialog();
    }
    refresh && refresh();
    setClusterMode(value);
    setAdvShow(true);
  }

  function switchStrategy(value) {
    setStrategy(Number(value));
  }

  function radioControlBehavior(value) {
    setControlBehavior(Number(value));
  }

  // function radioClusterThresholdType(value: ReactNode) {
  //   setClusterThresholdType(Number(value));
  // }

  function radioClusterRequestMode(value) {
    setClusterRequestMode(Number(value));
  }

  function radioFallbackToLocalWhenFail(value) {
    setFallbackToLocalWhenFail(value);
    setAutoAdjustFallbackThresholdEnabled(false);
  }

  function renderThresholdWarning() {
    return (
      <div className={styles['recommendBox']}>
        <div><span style={{ color: 'red' }}>{intl('ahas_sentinel.systemGuard.caveat')}</span>{intl('ahas_sentinel.systemGuard.risk0')}</div>
      </div>
    );
  }

  // 统计窗口时长
  function onTimeTypeChange(value) {
    setTimeType(value);
  }

  // 高级选项显示/隐藏
  function handleAdvShow() {
    refresh && refresh();
    setAdvShow(!advShow);
  }

  function reset() {
    setStrategy(0);
    setControlBehavior(0);
  }

  let statisticsText = '';
  let flowControlText = '';
  // let clusterText = '';
  switch (strategy) {
    case 0:
      statisticsText =
        intl('ahas_sentinel.systemGuard.statisticsText0');
      break;
    case 1:
      statisticsText =
        intl('ahas_sentinel.systemGuard.statisticsText1');
      break;
    case 2:
      statisticsText =
        intl('ahas_sentinel.systemGuard.statisticsText2');
      break;
    default:
      break;
  }
  switch (controlBehavior) {
    case 0:
      flowControlText =
        intl('ahas_sentinel.systemGuard.statisticsText3');
      break;
    case 1:
      flowControlText =
        intl('ahas_sentinel.systemGuard.statisticsText4');
      break;
    case 2:
      flowControlText =
        intl('ahas_sentinel.systemGuard.statisticsText5');
      break;
    default:
      break;
  }
  // switch (clusterThresholdType) {
  //   case 0:
  //     clusterText = '即以单机作为整体来查看阈值。';
  //     break;
  //   case 1:
  //     clusterText = '即以集群作为整体来查看阈值。';
  //     break;
  //   default:
  //     break;
  // }

  const hintLayout = (
    <Icon
      type="prompt"
      size="small"
      style={{ marginLeft: '5px', color: 'rgb(136, 136, 136)' }}
    />
  );
  const showRegionId =
    regionId === 'cn-hangzhou' ||
    regionId === 'cn-beijing' ||
    regionId === 'cn-shenzhen' ||
    regionId === 'cn-shanghai' ||
    regionId === 'cn-zhangjiakou';

  const fallbackRadioGroupTips = fallbackToLocalWhenFail ? intl('ahas_sentinel.systemGuard.fallbackToLocalWhenFail') : intl('ahas_sentinel.systemGuard.fallbackToLocalWhensu');

  return (
    <div className={styles['contentBox']}>
      {!isProtection && <Message style={{ marginBottom: '8px' }} type="notice">
        {!activeType ? (
          <span>
            {intl('ahas_sentinel.systemGuard.realQPS')}
            <a href={isNginx ? NGINX_FLOW_RULE : FLOW_RULE} target="_block">
              {SEE_DETAILS(intl)}
            </a>
          </span>
        ) : (
          <span>
            {intl('ahas_sentinel.systemGuard.byCon')}
            <a href={QUARA_RULE} target="_block">
              {SEE_DETAILS(intl)}
            </a>
          </span>
        )}
      </Message>}
      <Form field={field} size={getValue('size')}>
        {!isProtection && <Form.Item required {...formItemLayout} label={INTER_NAME(intl)}>
          {!isNginx ? <Input
            placeholder={PLEASE_NAME(intl)}
            trim
            disabled={resource || record ? true : !!record}
            {...init('resource', {
              initValue: resource || (record && record.resource),
              rules: [
                {
                  required: true,
                  message: NOT_NULL(intl),
                },
                {
                  pattern: /^[^\u4e00-\u9fa5]+$/,
                  message: intl('ahas_sentinel.systemGuard.messageName'),
                },
              ],
            })}
          /> :
            <Select.AutoComplete
              hasClear={true}
              disabled={(resource || record) ? true : !!record }
              dataSource={aplList}
              filterLocal={false}
              trim
              style={{ width: '100%' }}
              placeholder={intl('ahas_sentinel.systemGuard.PleaseInterfaceName')} // '请选择自定义API名称或手动输入接口名称'
              {...init('resource', {
                initValue: resource || (record && record.resource) || '',
                rules: [
                  {
                    required: true,
                    message: NOT_NULL(intl),
                  },
                ],
              })}
            />
          }
        </Form.Item>}
        {!isGateWay && !activeType && sessionStorage.getItem('CurrentAppType') !== '2' && (
          <Form.Item
            {...formItemLayout}
            // label={'是否集群流控'}
            label={
              <span>
                {intl('ahas_sentinel.systemGuard.isFlowCon')}
                {/* <Balloon
                  className={styles.ballonBackColor}
                  align="r"
                  type="primary"
                  trigger={hintLayout}
                  closable
                >
                  <div>
                    <p>
                      {intl('ahas_sentinel.systemGuard.isOpenCluster')}
                    </p>
                    <p>
                      {intl('ahas_sentinel.systemGuard.from')}<span style={{ color: '#0070cc' }}>&nbsp;{intl('ahas_sentinel.systemGuard.March222021')}&nbsp;</span>
                      {intl('ahas_sentinel.systemGuard.thePublic')}&nbsp;
                      <a
                        style={{ color: '#0070cc', cursor: 'pointer' }}
                        onClick={handleChangeTollDialog}
                      >{intl('ahas_sentinel.systemGuard.DetailsChar')}</a>
                    </p>
                  </div>
                </Balloon> */}
              </span>
            }
          >
            <Switch onChange={switchClusterMode} checked={clusterMode} />
          </Form.Item>
        )}

        {!advShow && (
          <Form.Item {...formItemLayout} label={intl('ahas_sentinel.systemGuard.WhetherTo0pen')}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <Switch
                checked={isQuote || selectModelEnable ? switchEnableStatus : false}
                // style={{ marginTop: '3px' }}
                onChange={handleClickSwitch}
                disabled={isQuote ? false : (!!record?.id || !selectModelEnable)}
              />
              <span className={styles['to_open']}>
                {switchEnableStatus
                  ? intl('ahas_sentinel.systemGuard.opRules')
                  : intl('ahas_sentinel.systemGuard.cloneRule')}
              </span>
            </div>
          </Form.Item>
        )}

        {!clusterMode && (
          <div>
            {!advShow && sessionStorage.getItem('CurrentAppType') !== '2' && (
              <>
                <Form.Item required {...formItemLayout} label={SOURCE_APPLICATION(intl)}>
                  <Input
                    placeholder={PLEASE_ENTER(intl)}
                    trim
                    maxLength={100}
                    {...init('limitApp', {
                      initValue: (record && record.limitApp) || 'default',
                      rules: {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                    })}
                  />
                </Form.Item>

                <Form.Item
                  {...formItemLayout}
                  className={styles['rao_space']}
                  label={
                    <span>
                      {STA_DIME(intl)} {/** 统计维度 */}
                      <Balloon
                        className={styles['ballonBackColor']}
                        align="r"
                        type="primary"
                        trigger={hintLayout}
                        closable
                      >
                        <div>
                          <p>{intl('ahas_sentinel.systemGuard.Introduction')}</p>
                          <p>
                            {intl('ahas_sentinel.systemGuard.direct')}
                          </p>
                          <p>{intl('ahas_sentinel.systemGuard.Associate')}</p>
                          <p>
                            {intl('ahas_sentinel.systemGuard.Link')}
                          </p>
                        </div>
                      </Balloon>
                    </span>
                  }
                >
                  <Radio.Group
                    onChange={switchStrategy}
                    value={strategy}
                    // {...init('strategy', {})}
                  >
                    <Radio id={'direct'} value={0}>
                      {intl('ahas_sentinel.systemGuard.flowControl.CurrentInterface') /* 当前接口*/}
                    </Radio>
                    <Radio id={'link'} value={1}>
                      {intl('ahas_sentinel.systemGuard.flowControl.AssociatedInterface') /* 关联接口*/}
                    </Radio>
                    <Radio id={'chain'} value={2}>
                      {intl('ahas_sentinel.systemGuard.flowControl.LinkEntry') /* 链路入口*/}
                    </Radio>
                  </Radio.Group>
                  <p className={styles['bgColor']}>{statisticsText}</p>
                </Form.Item>
              </>
            )}

            {strategy === 1 && (
              <div>
                <Form.Item required {...formItemLayout} label={intl('ahas_sentinel.systemGuard.assInterName')}>
                  <Input
                    placeholder={intl('ahas_sentinel.systemGuard.PleaseExactly')}
                    trim
                    {...init('refResource', {
                      initValue: (record && record.refResource) || '',
                      rules: {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                    })}
                  />
                </Form.Item>

                <Form.Item required {...formItemLayout} label={intl('ahas_sentinel.systemGuard.assInterThr')}>
                  <Input
                    placeholder={intl('ahas_sentinel.systemGuard.PleaseThr')}
                    trim
                    {...init('count', {
                      initValue: (record && record.count) || '',
                      rules: [
                        {
                          required: true,
                          message: NOT_NULL(intl),
                        },
                        {
                          pattern: /^[0-9|.]*$/,
                          message: intl('ahas_sentinel.systemGuard.PleaseNumber'),
                        },
                      ],
                    })}
                  />
                  {field.getValue('count') !== '' && Number(field.getValue('count')) === 0 && renderThresholdWarning()}
                </Form.Item>
              </div>
            )}

            {strategy === 2 && (
              <Form.Item required {...formItemLayout} label={intl('ahas_sentinel.systemGuard.callstackEntrance')}>
                <Input
                  placeholder={intl('ahas_sentinel.systemGuard.EntryResources')}
                  trim
                  {...init('refResource', {
                    initValue: (record && record.refResource) || '',
                    rules: {
                      required: true,
                      message: NOT_NULL(intl),
                    },
                  })}
                />
              </Form.Item>
            )}

            {!field.getValue('clusterMode') && (
              <div style={{ position: 'relative' }}>
                {strategy !== 1 && (
                  <Form.Item
                    required
                    {...formItemLayout}
                    label={!activeType ? countType : intl('ahas_sentinel.systemGuard.ConcurrencyThreshold')}
                  >
                    <Input
                      placeholder={THRESSHOULD(intl)}
                      trim
                      {...init('count', {
                        initValue: (record && record.count) || '',
                        rules: [
                          {
                            required: true,
                            message: NOT_NULL(intl),
                          },
                          {
                            pattern: /^[0-9|.]*$/,
                            message: intl('ahas_sentinel.systemGuard.PleaseNumber'),
                          },
                        ],
                      })}
                    />
                    {field.getValue('count') !== '' && Number(field.getValue('count')) === 0 && renderThresholdWarning()}
                  </Form.Item>
                )}
              </div>
            )}
            {!activeType && !advShow && (
              <Form.Item
                {...formItemLayout}
                className={styles['rao_space']}
                label={
                  <span>
                    {FLOW_EFFECT(intl)}
                    <Balloon
                      className={styles['ballonBackColor']}
                      align="r"
                      type="primary"
                      trigger={hintLayout}
                      closable
                    >
                      <div>
                        <p>{intl('ahas_sentinel.systemGuard.controleffect')}</p>
                        <p>{intl('ahas_sentinel.systemGuard.immediately')}</p>
                        <p>{intl('ahas_sentinel.systemGuard.WarmUp')}</p>
                        <p>{intl('ahas_sentinel.systemGuard.Waiting')}</p>
                      </div>
                    </Balloon>
                  </span>
                }
              >
                <Radio.Group
                  onChange={radioControlBehavior}
                  value={controlBehavior}
                  // {...init('controlBehavior', {})}
                >
                  <Radio id={'quick-fail'} value={0}>
                    {intl('ahas_sentinel.systemGuard.Failfast')}
                  </Radio>
                  {sessionStorage.getItem('CurrentAppType') !== '2' && <Radio id={'warm-up'} value={1}>
                    {intl('ahas_sentinel.systemGuard.Warm-upStart')}
                  </Radio>}
                  {sessionStorage.getItem('CurrentAppType') !== '2' && <Radio id={'queue-wait'} value={2}>
                    {intl('ahas_sentinel.systemGuard.WaitingInline')}
                  </Radio>}
                </Radio.Group>
                <p className={styles['bgColor']}>{flowControlText}</p>
              </Form.Item>
            )}

            {controlBehavior === 1 && (
              <Form.Item {...formItemLayout} label={intl('ahas_sentinel.systemGuard.PreheatTime')}>
                <Input
                  placeholder={SECOND(intl)}
                  trim
                  addonTextAfter={<span>s</span>}
                  {...init('warmUpPeriodSec', {
                    initValue: (record && record.warmUpPeriodSec) || '',
                    rules: [
                      {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                      {
                        pattern: /^[0-9]*$/,
                        message: PLEASE_NUMBER(intl),
                      },
                    ],
                  })}
                />
              </Form.Item>
            )}

            {controlBehavior === 2 && (
              <Form.Item {...formItemLayout} label={intl('ahas_sentinel.systemGuard.overtimeTime')}>
                <Input
                  placeholder={MILLISSECOND(intl)}
                  trim
                  addonTextAfter={<span>ms</span>}
                  {...init('maxQueueingTimeMs', {
                    initValue: (record && record.maxQueueingTimeMs) || '',
                    rules: [
                      {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                      {
                        pattern: /^[0-9]*$/,
                        message: PLEASE_NUMBER(intl),
                      },
                    ],
                  })}
                />
              </Form.Item>
            )}
          </div>
        )}

        {advShow && (
          <Form.Item {...formItemLayout} label={WHETHER_TO_OPEN(intl)}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <Switch
                checked={isQuote || selectModelEnable ? switchEnableStatus : false}
                // style={{ marginTop: '3px' }}
                onChange={handleClickSwitch}
                disabled={isQuote ? false : (!!record?.id || !selectModelEnable)}
              />
              <span className={styles['to_open']}>
                {switchEnableStatus
                  ? intl('ahas_sentinel.systemGuard.flowControl.creaRule')
                  : intl('ahas_sentinel.systemGuard.flowControl.notakeEffect')}
              </span>
            </div>
          </Form.Item>
        )}

        {clusterMode && (
          <div>
            {/* <Form.Item
              {...formItemLayout}
              required
              label={
                <span>
                  {'接口集群总 QPS'}
                  <Balloon
                    className={styles.ballonBackColor}
                    align="r"
                    type="primary"
                    trigger={hintLayout}
                    closable
                  >
                    <div>
                      <p>
                        该接口预估的集群最大
                        QPS（代表可能到来的最大流量），用于为 token server
                        自动分配提供参考。注意预估总 QPS
                        不要配置太小，流量超出该值的部分会退化到单机模式。
                      </p>
                    </div>
                  </Balloon>
                </span>
              }
            >
              <Input
                placeholder="请输入"
                {...init('estimatedMaxClusterQps', {
                  initValue: (record && record.estimatedMaxClusterQps) || '',
                  rules: {
                    required: true,
                    message: '不能为空',
                  },
                })}
              />
            </Form.Item> */}

            {/* <Form.Item
              {...formItemLayout}
              className={styles.rao_space}
              label={
                <span>
                  {'阈值模式'}
                  <Balloon
                    className={styles.ballonBackColor}
                    align="r"
                    type="primary"
                    trigger={hintLayout}
                    closable
                  >
                    <div>
                      <p>
                        单机均摊模式下配置的阈值等同于单机能够承受的限额，Token
                        Server 会根据连接数来计算总的阈值（比如独立模式下有 3 个
                        client 连接到了 token server，然后配的单机均摊阈值为
                        10，则计算出的集群总量就为
                        30）；而全局模式下配置的阈值等同于整个集群的总阈值。
                      </p>
                    </div>
                  </Balloon>
                </span>
              }
            >
              <Radio.Group
                onChange={radioClusterThresholdType}
                value={clusterThresholdType}
                // {...init('clusterThresholdType', {})}
              >
                <Radio id={'global'} value={1}>
                  {'集群阈值'}
                </Radio>
                <Radio id={'avg'} value={0}>
                  {'单机阈值'}
                </Radio>
              </Radio.Group>
              <p className={styles.bgColor}>{clusterText}</p>
            </Form.Item> */}

            <Form.Item {...formItemLayout} label={countType} required>
              <Input
                placeholder={THRESSHOULD(intl)}
                trim
                {...init('count', {
                  initValue: (record && record.count) || '',
                  rules: [
                    {
                      required: true,
                      message: NOT_NULL(intl),
                    },
                    {
                      pattern: /^[0-9|.]*$/,
                      message: PLEASE_NUMBER(intl),
                    },
                  ],
                })}
              />
              {field.getValue('count') !== '' && Number(field.getValue('count')) === 0 && renderThresholdWarning()}
            </Form.Item>

            {!isNginx && showRegionId && clusterThresholdType === 1 && (
              <Form.Item {...formItemLayout} label={intl('ahas_sentinel.systemGuard.flowControl.stawindur')} required>
                <Input
                  style={{ width: '300px', float: 'left' }}
                  trim
                  placeholder={intl('ahas_sentinel.systemGuard.flowControl.stawindur')}
                  {...init('WindowIntervalMs', {
                    initValue: (record && statIntervalMs) || 1,
                    rules: [
                      {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                      {
                        pattern: /^[1-9]\d*$/,
                        message: PLEASE_NUMBER(intl),
                      },
                    ],
                  })}
                />
                <Select
                  style={{ minWidth: '35px' }}
                  value={timeType}
                  onChange={onTimeTypeChange}
                >
                  <Option value="second">{SECOND(intl)}</Option>
                  <Option value="minute">{MINUTE(intl)}</Option>
                  <Option value="hour">{HOUR(intl)}</Option>
                </Select>
              </Form.Item>
            )}

            <Form.Item
              {...formItemLayout}
              className={styles['rao_space']}
              label={
                <span>
                  {intl('ahas_sentinel.systemGuard.flowControl.FailureStra')}
                  <Balloon
                    className={styles['ballonBackColor']}
                    align="r"
                    type="primary"
                    trigger={hintLayout}
                    closable
                  >
                    <div>
                      <p>
                        {intl('ahas_sentinel.systemGuard.flowControl.TokenServer')}
                      </p>
                    </div>
                  </Balloon>
                </span>
              }
            >
              <Radio.Group
                onChange={radioFallbackToLocalWhenFail}
                value={fallbackToLocalWhenFail}
                // {...init('fallbackToLocalWhenFail', {})}
              >
                <Radio id={'global'} value={true}>
                  {intl('ahas_sentinel.systemGuard.flowControl.Degraded')}
                </Radio>
                <Radio id={'avg'} value={false}>
                  {intl('ahas_sentinel.systemGuard.flowControl.PassDirectly')}
                </Radio>
              </Radio.Group>
              <p className={styles['bgColor']}>{fallbackRadioGroupTips}</p>
            </Form.Item>

            <Form.Item {...formItemLayout} label={intl('ahas_sentinel.systemGuard.flowControl.Automatic')}>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <Switch
                  checked={autoAdjustFallbackThresholdEnabled}
                  onChange={handleClickAutoConfigSwitch}
                  disabled={!fallbackToLocalWhenFail}
                />
                <span className={styles['to_open']}>
                  {autoAdjustFallbackThresholdEnabled
                    ? intl('ahas_sentinel.systemGuard.flowControl.adjustment')
                    : intl('ahas_sentinel.systemGuard.flowControl.takeEffect')}
                </span>
              </div>
            </Form.Item>

            {!autoAdjustFallbackThresholdEnabled && fallbackToLocalWhenFail && (
              <Form.Item
                {...formItemLayout}
                required
                label={
                  <span>
                    {intl('ahas_sentinel.systemGuard.flowControl.machine')}
                    <Balloon
                      className={styles['ballonBackColor']}
                      align="r"
                      type="primary"
                      trigger={hintLayout}
                      closable
                    >
                      <div>
                        <p>
                          {intl('ahas_sentinel.systemGuard.flowControl.etc')}
                        </p>
                      </div>
                    </Balloon>
                  </span>
                }
              >
                <Input
                  placeholder={THRESSHOULD(intl)}
                  trim
                  {...init('clusterFallbackThreshold', {
                    initValue:
                      (record && record.clusterFallbackThreshold) || '',
                    rules: [
                      {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                      {
                        pattern: /^[0-9|.]*$/,
                        message: PLEASE_NUMBER(intl),
                      },
                    ],
                  })}
                />
                {/* 输入时提醒用户阈值为0时有风险，此处需要区分空和0，空走必填逻辑，0走提醒逻辑 */}
                {field.getValue('clusterFallbackThreshold') !== '' && Number(field.getValue('clusterFallbackThreshold')) === 0 && renderThresholdWarning()}
                {/* 编辑模式下展示当前机器、流量信息 */}
                {Number(field.getValue('count')) > 0 && machineNum > 0 && <div className={styles['recommendBox']}>
                  <ul className={styles['recommendValue']}>
                    <li>{intl('ahas_sentinel.systemGuard.flowControl.NumberOfOnline')}<span>{machineNum}</span></li>
                    <li>{intl('ahas_sentinel.systemGuard.flowControl.singlemachine')}<span className={styles['recommendNum']}>{Math.ceil(Number(field.getValue('count')) / machineNum)}</span></li>
                  </ul>
                  <div><span style={{ color: 'red' }}>{NOTE(intl)}</span>{intl('ahas_sentinel.systemGuard.flowControl.210QPS')}</div>
                </div>}
              </Form.Item>
            )}

            {false && !advShow && showRegionId && clusterThresholdType === 1 && (
              <Form.Item
                {...formItemLayout}
                className={styles['rao_space']}
                label={
                  <span>
                    {intl('ahas_sentinel.systemGuard.flowControl.requestMode')} {/** 通信请求模式 */}
                    <Balloon
                      className={styles['ballonBackColor']}
                      align="r"
                      type="primary"
                      trigger={hintLayout}
                      closable
                    >
                      <div>
                        <p>
                          <span style={{ color: '#0066cc' }}>
                            {intl('ahas_sentinel.systemGuard.flowControl.EachRequestMode')} {/** 每次请求模式 */}
                          </span>
                          {
                            intl('ahas_sentinel.systemGuard.flowControl.EachClusterFlow')
                          }
                          <br />
                          <span style={{ color: '#0066cc' }}>
                            {intl('ahas_sentinel.systemGuard.flowControl.BatchRequestMode')}
                          </span>
                          {
                            intl('ahas_sentinel.systemGuard.flowControl.AHASwill')
                          }
                          <br />
                          <span style={{ color: '#0066cc' }}>
                            {
                              intl('ahas_sentinel.systemGuard.flowControl.recommended')
                            }
                          </span>
                        </p>
                      </div>
                    </Balloon>
                  </span>
                }
              >
                <Radio.Group
                  onChange={radioClusterRequestMode}
                  value={clusterRequestMode}
                >
                  <Radio id={'each'} value={0}>
                    {EVERY_REQUEST(intl)}
                  </Radio>
                  <Radio id={'batch'} value={1}>
                    {BULK_REQUEST(intl)}
                  </Radio>
                </Radio.Group>
              </Form.Item>
            )}

            {
              autoAdjustFallbackThresholdEnabled && <Form.Item
                required {...formItemLayout}
                label={
                  <span>
                    {intl('ahas_sentinel.systemGuard.flowControl.Automatically')}
                    <Balloon
                      className={styles['ballonBackColor']}
                      align="r"
                      type="primary"
                      trigger={hintLayout}
                      closable
                    >
                      <div>
                        <p>
                          {intl('ahas_sentinel.systemGuard.flowControl.automaticAdjustment')}
                        </p>
                      </div>
                    </Balloon>
                  </span>
                }
              >
                <Input
                  placeholder={intl('ahas_sentinel.systemGuard.flowControl.PleaseEnterThreshold')}
                  {...init('fallbackThresholdAdjustMargin', {
                    initValue: (record && record.fallbackThresholdAdjustMargin) || '',
                    rules: [
                      {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                      {
                        pattern: /^[0-9|.]*$/,
                        message: PLEASE_NUMBER(intl),
                      },
                    ],
                  })}
                />
                {/* 输入时提醒用户阈值为0时有风险，此处需要区分空和0，空走必填逻辑，0走提醒逻辑 */}
                {field.getValue('clusterFallbackThreshold') !== '' && Number(field.getValue('clusterFallbackThreshold')) === 0 && renderThresholdWarning()}
                {/* 编辑模式下展示当前机器、流量信息 */}
                {Number(field.getValue('count')) > 0 && machineNum > 0 && <div className={styles['recommendBox']}>
                  <ul className={styles['recommendValue']}>
                    <li>{intl('ahas_sentinel.systemGuard.flowControl.NumberOfOnline')}<span>{machineNum}</span></li>
                    <li>{intl('ahas_sentinel.systemGuard.flowControl.singlemachine')}<span className={styles['recommendNum']}>{Math.ceil(Number(field.getValue('count')) / machineNum)}</span></li>
                  </ul>
                  <div><span style={{ color: 'red' }}>{NOTE(intl)}</span>{intl('ahas_sentinel.systemGuard.flowControl.from2to10')}</div>
                </div>}
              </Form.Item>
            }
          </div>
        )}

        <div>
          {!clusterMode && !isNginx && (
            <div className={styles['advanced']} onClick={handleAdvShow}>
              {advShow ? (
                <i className={'iconfont icon-xiangxiazhankai'}></i>
              ) : (
                <i className={'iconfont icon-xiangshangshouqi'}></i>
              )}
              <a style={{ marginLeft: 8 }} onClick={reset}>
                {advShow ? SHOW_AD_OP(intl) : HIDE_AD_OP(intl)}
              </a>
            </div>
          )}

          {!isProtection && <div style={{ float: 'right' }}>
            {record === undefined ? (
              <span>
                {noRederict && (
                  <Form.Submit
                    type="primary"
                    onClick={() => {
                      handleAddRule(true, 'viev');
                    }}
                  >
                    {NEW_AND_SEE(intl)}
                  </Form.Submit>
                )}
                <Form.Submit
                  style={{ marginLeft: '8px' }}
                  type="primary"
                  onClick={() => {
                    handleAddRule(true);
                  }}
                >
                  {NEW(intl)}
                </Form.Submit>
              </span>
            ) : (
              <Form.Submit
                type="primary"
                onClick={() => {
                  handleAddRule(false);
                }}
              >
                {SAVE(intl)}
              </Form.Submit>
            )}
            <Button
              style={{ marginLeft: '8px' }}
              onClick={() => {
                onCloseDialog && onCloseDialog('0');
              }}
            >
              {CANCEL(intl)}
            </Button>
          </div>}
        </div>
      </Form>
      {/* {footer} */}

      {/* 集群流控商业化说明弹窗 */}
      {/* <ClusterTollDialog
        tollDialogVisible={tollDialogVisible}
        handleDialogHidden= {handleChangeTollDialog}
      /> */}
    </div>
  );
};

export default SystemGuardFlowRuleAdd;
