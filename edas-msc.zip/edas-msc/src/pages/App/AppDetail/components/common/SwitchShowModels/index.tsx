import React, { FC } from 'react';
import styles from './index.css';
import { Switch } from '@alicloud/console-components';
import { setParams } from '@ali/sre-utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';

const SwitchShowModels: FC = () => {
  const dispatch = useDispatch();
  const showModelstype = useSelector(({ flowAppModel }) => flowAppModel.showModelstype);
  // 展示模式改变
  function handleShowModelsChange(checked: boolean) {
    setParams('showModels', checked);
    window.goldlog.record('/ahas-flow.guard_api_details.show_models_type', 'CLK', '', 'GET');
    window.goldlog.record('/ahas-flow.guard_machine_details.machine_show_type', 'CLK', '', 'GET');
    dispatch.flowAppModel.setShowModelstype(checked);
  }

  return (
    <>
      <Switch
        className={styles.showModels}
        checked={showModelstype}
        checkedChildren="节点对比"
        unCheckedChildren="集群统计"
        onChange={handleShowModelsChange}
      />
    </>
  );
};

export default SwitchShowModels;
