import QuantileTable from './QuantileTable';
import React, { FC } from 'react';
import styles from './index.css';
import { Tab } from '@alicloud/console-components';

const DetailsQuantile: FC = () => {

  function renderContent() {
    return (
      <div className={styles.contentTabBox}>
        <span className={styles.contentTabTitle}>分位统计</span>
        <Tab shape="capsule" size="small">
          <Tab.Item title="IP统计"><QuantileTable /></Tab.Item>
          <Tab.Item title="接口统计"><QuantileTable /></Tab.Item>
        </Tab>
      </div>
    );
  }

  return (
    <div className={styles.content}>
      {renderContent()}
    </div>
  );
};

export default DetailsQuantile;
