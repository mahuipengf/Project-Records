import React, { FC, useState } from 'react';
import ServiceStressPanel from './ServiceStressPanel';
import intl from '@alicloud/console-components-intl-core';
import styles from './index.css';
import { Button, Dialog, Loading, Message } from '@alicloud/console-components';
import { compare } from 'utils/util';
import { getParams, pushUrl } from '@ali/sre-utils';
import { useDispatch } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';
interface IStressProps {
  resourceName: string;
}

const ServiceStressIcon: FC<IStressProps> = props => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { resourceName } = props;
  const appName = getParams('appName') || '';
  const ahasAppName = getParams('ahasAppName') || '';
  const isNginx = getParams('isNginx') || 'false';
  const sdkVersion = sessionStorage.getItem('sdkVersion') || '1.0.0';
  const agentVersion = sessionStorage.getItem('agentVersion') || '1.0.0';
  const stressSdkVersion = intl('ahas_sentinel.SystemGuardPreview.stressVersion');
  const stressAgentVersion = intl('ahas_sentinel.SystemGuardPreview.stressAgentVersion');
  const isPassSdkVersion = compare(sdkVersion, stressSdkVersion);
  const isPassAgentVersion = compare(agentVersion, stressAgentVersion);
  const isPassLevel = sessionStorage.getItem('currentLevel') === '0';
  const [ activePanel, setActivePanel ] = useState(false);
  const [ securityInfo, setSecurityInfo ] = useState();
  const [ isLoading, setIsLoading ] = useState(false);

  // 获取接口相关安全组信息
  async function querySecurityInfoList() {
    setIsLoading(true);
    const { Data = [], Success = false } = await dispatch.flowAppModel.getSentinelMachineSecurityInfoList({
      AppName: appName,
    });
    if (Success && Data.length) {
      setSecurityInfo(Data[0]);
      setActivePanel(true);
      setIsLoading(false);
    } else {
      setIsLoading(false);
      Message.warning('暂无安全组信息，请稍后重试');
    }
  }

  // // 获取应用防护级别
  // async function getSentinelQueryAppPriceLevel() {
  //   const {
  //     Data: result = {},
  //   } = await dispatch.flowAppModel.getSentinelQueryAppPriceLevel({
  //     AppName: appName,
  //   });
  //   const { CurrentLevel = 1 } = result; // 0 高级防护 1 入门级防护
  //   return CurrentLevel === 0;
  // }

  // 滑动面板状态改变
  function handleSlidePanelChange() {
    window.goldlog.record(
      '/ahas-flow.ahas-flow.pts.ahas-flow.pts.config',
      'CLK',
      '',
      'GET',
    );
    if (!activePanel) {
      if (isPassLevel) {
        if (isPassSdkVersion || isPassAgentVersion) {
          queryDescribeScenarioRecordsForAhas();
        } else {
          popupAlert(
            <span className={styles.popupAlertText}>
              {`当前应用 SDK 版本号（${sdkVersion}）及 Agent 版本号（${agentVersion}）过低，请升级应用 `}
              <span>{'SDK 版本 >= '}{stressSdkVersion}</span>
              {' 或 '}
              <span>{'Agent 版本 >= '}{stressAgentVersion}</span>
              {' 后启用此功能。'}
            </span>,
          );
        }
      } else {
        popupAlert('当前应为防护等级为入门级，请修改防护等级为高级后启用此功能');
      }
    } else {
      setActivePanel(!activePanel);
    }
  }

  // 获取当前接口是否存在压测中场景
  async function queryDescribeScenarioRecordsForAhas() {
    setIsLoading(true);
    const {
      Data = [],
    } = await dispatch.flowAppModel.queryDescribeScenarioRecordsForAhas({
      AppName: appName,
      PageNumber: 1,
      PageSize: 10,
      Source: 'ahas',
      ScenarioName: resourceName,
    });

    if (Data?.length) {
      const stressList = Data.filter((item: any) => {
        return item.Status === 'STARTING' || item.Status === 'RUNNING' || item.Status === 'APPLY_AGENT';
      });

      if (stressList?.length) {
        setIsLoading(false);
        dialogTips();
      } else {
        querySecurityInfoList();
      }
    } else {
      querySecurityInfoList();
    }
  }

  // 确认弹窗
  function dialogTips() {
    const dialog = Dialog.confirm({
      title: '温馨提示',
      content: (
        <div>该接口当前有正在进行中的压测场景，是否继续新建压测场景？</div>
      ),
      footer: (
        <>
          <Button
            type='primary'
            onClick={() => {
              querySecurityInfoList();
              dialog.hide();
            }}
          >新建压测</Button>
          <Button onClick={() => {
            handlePushUrl();
            dialog.hide();
          }}>查看已有场景</Button>
        </>
      ),
    });
  }

  // 跳转至应用压测记录
  function handlePushUrl() {
    pushUrl(history, '/flowProtection/systemGuard/systemServiceStress', {
      appName,
      ahasAppName,
      isNginx,
    });
  }

  // 提示弹窗
  const popupAlert = (content: any) => {
    Dialog.alert({
      title: '提示',
      content,
      onOk: () => console.log('ok'),
    });
  };

  return (
    <>
      {/* <Balloon
        trigger={
          // <Icon
          //   type='display-code'
          //   onClick={handleSlidePanelChange}
          // />
          <i
            className={'iconfont icon-sliders'}
            style={{ color: '#0070cc', cursor: 'pointer', marginTop: '5px' }}
            onClick={handleSlidePanelChange}
          ></i>
        }
        closable={false}
        offset={[ 6, 0 ]}
      >
        服务压测
      </Balloon> */}
      <span
        className={styles.stressEntryBtn}
        onClick={handleSlidePanelChange}
      >
        压测
      </span>

      <Loading
        className={styles.loading}
        visible={isLoading}
        fullScreen={true}
        tip='压测准备中...'
      >
      </Loading>

      {/* 滑动面板 */}
      <ServiceStressPanel
        resourceName={resourceName}
        activePanel={activePanel}
        securityInfo={securityInfo}
        handleSlidePanelChange={handleSlidePanelChange}
      />
    </>
  );
};

export default ServiceStressIcon;
