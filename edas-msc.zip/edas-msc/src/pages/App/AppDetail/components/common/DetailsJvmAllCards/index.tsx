import OverviewJvmAllCharts from './OverviewJvmAllCharts';
import React, { FC, useEffect, useMemo, useState } from 'react';
import styles from './index.css';
import { Loading, Pagination } from '@alicloud/console-components';
import { getParams } from '@ali/sre-utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';
import { useInterval } from '@ali/sre-utils-hooks';

interface AllCardsProps {
  resourceType?: number;
  tabType?: string;
  nodeShowType?: any;
}

interface IDataSource {
  type: number;
  resource: string;
  hasRule: boolean;
  favorite: boolean;
  processConfigurationId?: string;
}

interface IMachineData {
  privateIp: string;
  processConfigurationId: string;
  pid: number;
  parentIp: string;
  vpcId: string;
  resource: string;
  quotaList: any;
  hostname: string;
}

const DetailsAllCards: FC<AllCardsProps> = props => {
  const { resourceType, nodeShowType } = props;
  const dispatch = useDispatch();
  const appName = getParams('edasAppId') || getParams('appName') || '';
  const detailsJvmChildTabIdx = Number(getParams('detailsJvmChildTabIdx'));
  const [ topListArr, setTopListArr ] = useState([]);
  const [ totalCount, setTotalCount ] = useState(0);
  const [ pageIndex, setPageIndext ] = useState(1);
  const [ lastTime, setLastTime ] = useState(0);
  const [ isLoading, setIsLoading ] = useState(true);
  const { backTime } = useSelector(({ flowAppModel }) => flowAppModel.apiShowTime);
  const { sortIndex, descType } = useSelector(({ flowAppModel }) => flowAppModel.sortDesc);
  const { fullScreenApi, fullScreenMac } = useSelector(({ flowAppModel }) => flowAppModel.fullScreen);
  const fullScreen = fullScreenApi || fullScreenMac;
  const pageSizeCount = fullScreen ? 12 : 6;

  useEffect(() => {
    setIsLoading(true);
    setLastTime(1);
    getMacTopList();
  }, [ resourceType, pageIndex, backTime, sortIndex, descType, fullScreenApi, fullScreenMac, detailsJvmChildTabIdx, nodeShowType ]);

  useInterval(() => {
    // 轮询请求接口charts数据
    getMacTopList();
    setLastTime(lastTime + 1);
  }, 10000);

  // 请求全部机器
  async function getMacTopList() {
    const endTime = new Date().getTime();
    const { totalCount: totalCountNum = 0, macMetrics: listTopData = [] } = await dispatch.flowAppModel.getSentinelResourceTopNMacs({
      AppName: appName,
      PageIndex: pageIndex,
      PageSize: pageSizeCount,
      SearchKey: '',
      OrderBy: sortIndex,
      Desc: descType,
      AhasTimestamp: backTime || endTime,
      Resource: '__app_summary_metric_resource_name__',
    });
    if (listTopData.length > 0) {
      setTotalCount(totalCountNum);
      setTopListArr(listTopData);
    } else {
      setTotalCount(0);
      setTopListArr([]);
    }
    setIsLoading(false);
  }

  // 渲染api卡片
  const renderJvmCards = useMemo(() => {
    const emptyElementName = fullScreen ? styles.emptyElementFull : styles.emptyElement;
    const apiTopListNone = fullScreen ? styles.apiTopListNoneFull : styles.apiTopListNone;
    return (
      topListArr.length > 0 ? <>
        {
          topListArr.map((item: IDataSource, index: number) => {
            return (
              <OverviewJvmAllCharts
                key={index}
                lastTime={lastTime}
                dataSource={item}
                chartDialogtitle={'machine'}
                renderMachineName={renderMachineName}
              />
            );
          })
        }
        <span className={emptyElementName}></span>
        <span className={emptyElementName}></span>
        <span className={emptyElementName}></span>
      </> : <div className={apiTopListNone}>暂无数据，请确认应用上是否有请求流量</div>
    );
  }, [ topListArr, lastTime, resourceType, nodeShowType ]);

  function initMachineAllName() {
    const allMachineName:Array<string> = [];

    !!topListArr && topListArr?.forEach((item: IMachineData) => {
      item.privateIp !== '_all' && allMachineName.push(item.privateIp);
    });

    return allMachineName;
  }

  function countOccurences(ary: Array<string>, value: string) {
    return ary.reduce((a, v) => (v === value ? a + 1 : a + 0), 0);
  }

  function renderMachineName(data: IMachineData) {
    const allMachineName = initMachineAllName();
    if (countOccurences(allMachineName, data.privateIp) > 1) {
      return (
        <div className={styles.machineTitle}>
          <span>
            {data.privateIp}
          </span>
          <span className={styles.pidNum}>
            进程号:{data.pid}
          </span>
        </div>
      );
    }

    return (
      <div className={styles.textEllipsis}>
        {nodeShowType === 'hostName' ? data.hostname : data.privateIp}
      </div>
    );
  }

  // 翻页
  function handlePageIndexChange(current: number) {
    setPageIndext(current);
  }

  // 渲染排序分页
  function renderSortPagination() {
    return (
      <Pagination
        className={fullScreen ? styles.sortPaginationFull : styles.sortPagination}
        onChange= {handlePageIndexChange}
        current={pageIndex}
        total={totalCount}
        pageSize={pageSizeCount}
        shape="normal"
        type="normal"
        totalRender={totalCount => `共有${totalCount}条`}
      />
    );
  }

  return (
    <div className={styles.content}>
      <Loading
        visible={isLoading}
        className={styles.loadingCover}
      >
        {renderJvmCards}
      </Loading>
      {!!totalCount && renderSortPagination()}
    </div>
  );
};

export default DetailsAllCards;
