import ChartsDialog from '../ChartsDialog';
import DataSet from '@antv/data-set';
import React, { useEffect, useState } from 'react';
import RuleCharts from '../RuleCharts';
import SubDetailsDialog from '../SubDetailsDialog';
import moment from 'moment';
import styles from './index.less';
import { Badge, Balloon, Dialog } from '@alicloud/console-components';
import { intlNumberUnit } from '@ali/sre-utils';
import services from 'services';
import { getParams } from 'utils';
import Cookie from 'js-cookie';

const OverviewCharts = props => {
  const { curMeticsData, title, chartsType = 'qps', typeCharts, chartDialogtitle, activeMacMetric, activeApiMetric = '', nodeName, importType = false, onTooltipChange, onPlotLeave, getG2Charts, pageType = 'charts', chartsWidth = '', reqsCount = null, machineCount = 0, isInterface = '', dataQpsDeta = [], isHotSpotMonitor = false, isScene = false } = props;
  const [ component, setComponent ] = useState(null);
  const [ visible, setVisible ] = useState(false);
  // const { activeResourceName } = useSelector(({ flowAppModel }) => flowAppModel.apiDetails);
  // const { backTime } = useSelector(({ flowAppModel }) => flowAppModel.apiShowTime);
  // const { processConfigurationId, privateIp, pid } = useSelector(({ flowAppModel }) => flowAppModel.machineDetails);
  const apiDetails = {
    activeResourceName: '_all',
    favorite: false,
    hasRule: false,
    type: 0,
  };
  const apiShowTime = {
    backTime: undefined,
    statisticsEndTime: undefined,
  };
  const machineDetails = {
    privateIp: '_all',
    parentIp: '',
    pid: -1,
    processConfigurationId: '',
    vpcId: '',
    resource: '',
  };
  const [ newApiVisibleChart, setNewApiVisibleChart ] = useState(false);
  const [ group, setGroup ] = useState('');
  const [ dialogType, setDialogType ] = useState('');
  const [ visibleSubDetails, setVisibleSubDetails ] = useState(false);
  const isPage = pageType !== 'summary';
  const isNginx = sessionStorage.getItem('isNginx') === 'true';
  const [ visibleQps, setVisibleQps ] = useState(false);
  const { DataView } = DataSet;
  const resourceName = activeApiMetric ? activeApiMetric : apiDetails.activeResourceName === '_all' ? '' : apiDetails.activeResourceName;
  const chartsColor = initChartsLineColor(typeCharts);
  const dialogChartsTitle = chartDialogtitle === 'api' ? resourceName : machineDetails.privateIp === '_all' ? '' : `${machineDetails.privateIp}:${machineDetails.pid}`;
  const metricStartTime = moment().valueOf() - 30 * 60 * 1000;
  const metricEndTime = moment().valueOf();
  const appName = getParams('appName') || '';
  const Region = Cookie.get('currentRegionId') || 'cn-hangzhou';

  // bizchart 将近2MB，按需加载之
  useEffect(() => {
    (async function() {
      const bizcharts = await import(/* webpackChunkName: "bizcharts" */'bizcharts'/* webpackPrefetch: true */);
      setComponent(bizcharts);
    })();
  }, []);

  useEffect(() => {
    isPage && writeSessionStorage();
  }, []);

  if (!component) {
    return null;
  }

  function onGetG2Instance(c) {
    const chart = c;
    if (chart) {
      getG2Charts && getG2Charts(typeCharts, chart);
    }
  }

  const { Chart, Geom, Axis, Tooltip, Legend } = component;
  const dv = new DataView();
  dv.source(curMeticsData);

  function renderCols() {
    if (
      typeCharts === 'cpu' ||
      typeCharts === 'system_cpu' ||
      typeCharts === 'system_memory'
    ) {
      return {
        count: {
          min: 0,
          max: 100,
          tickCount: 5,
        },
        time: {
          alias: '时间',
          type: 'time',
          mask: 'HH:mm',
          tickCount: 5,
        },
      };
    }

    return {
      count: {
        min: 0,
        tickCount: 5,
        formatter: (val) => {
          return intlNumberUnit(Number(val).toFixed(2), 1);
        },
      },
      time: {
        alias: '时间',
        type: 'time',
        mask: 'HH:mm',
        tickCount: 5,
      },
    };
  }

  // 打开历史弹窗
  function handleOpenDialog() {
    setVisible(true);
  }

  // 关闭历史弹窗
  function handleHiddin() {
    setVisible(false);
  }

  // 打开指标详情弹窗
  function handleOpenSubDetailsDialog(typeCharts) {
    if (typeCharts) {
      const machineChartsAry = sessionStorage.getItem('machineCharts')?.split(',').filter(item => typeCharts !== item) || [];

      sessionStorage.setItem('machineCharts', machineChartsAry.join());
    }

    setVisibleSubDetails(true);
  }

  // 关闭指标详情弹窗
  function handleHiddenSubDetailsDialog() {
    setVisibleSubDetails(false);
  }

  function renderResource() {
    if (typeCharts === 'rt') {
      return '__app_summary_metric_resource_name__';
    }
    if (typeCharts === 'cpu') {
      return '__cpu_usage__';
    }
    if (typeCharts === 'load') {
      return '__system_load__';
    }
  }

  // 历史数据请求接口
  function getApi(queryHistoryMetricParams) {
    if(!queryHistoryMetricParams)return;
    if (chartDialogtitle === 'api') {
      return services.QuerySentinelMetricsOfResource({
        params: {
          // Resource: renderResource(),
          // StartTime: metricStartTime,
          // EndTime: metricEndTime,
          // AppName: appName || 'spring-cloud-a',
          // namespace: 'default',
          // RegionId: Region,
          // AhasRegionId: Region,
          // Namespace: 'default',
          // NameSpace: 'default',
          ...queryHistoryMetricParams
        }
      });
    } else if (chartDialogtitle === 'machine') {
      if (machineDetails.privateIp !== '_all') {
        return services.QuerySentinelMacMetricsOfResource();
      }
      return services.QuerySentinelMetricsOfResource({
        params: { 
          // Resource: renderResource(),
          // StartTime: metricStartTime,
          // EndTime: metricEndTime,
          // AppName: appName || 'spring-cloud-a',
          // namespace: 'default',
          // RegionId: Region,
          // AhasRegionId: Region,
          // Namespace: 'default',
          // NameSpace: 'default',
          ...queryHistoryMetricParams
        }
      });
    }
  }

  // 初始化charts图表线条配色
  function initChartsLineColor(typeCharts) {
    switch (typeCharts) {
      case 'allQps' : return [ '#0070cc', '#FECB00', '#FF7D51' ];
      case 'rt' : return [ '#826AF9' ];
      case 'thread' : return [ '#5B6E90' ];
      case 'cpu' : return [ '#6CB4F0' ];
      case 'system_memory' : return [ '#6DC8EC', '#9270CA', '#FF9D4D', '#32C5FF' ];
      case 'system_load' : return [ '#63B0F9' ];
      case 'statusCode' : return [ '#479F67', '#A3CA50', '#E1B35E', '#F1772E', '#C75C59' ];
      default : return [ '#2775F5', '#7ACBBB', '#E2BA47', '#9479FC', '#32C5FF', '#6DC8EC', '#9270CA', '#FF9D4D' ];
    }
  }

  function renderGeomType() {
    switch (typeCharts) {
      case 'cpu':
      case 'system_cpu':
      // case 'system_memory':
        return 'area';
      default:
        return 'line';
    }
  }

  function handleClick() {
    switch (typeCharts) {
      case 'allQps':
      case 'rt':
      // case 'load':
      case 'thread':
      // case 'cpu':
      // case 'system_cpu':
        handleOpenDialog();
        return;
      default:
        handleChangeDialog();
        return;
    }
  }

  function handleChangeDialog() {
    switch (typeCharts) {
      case 'load':
        setGroup('system_load');
        setDialogType('system_load');
        break;
      case 'cpu':
        setGroup('system_cpu');
        setDialogType('system_cpu');
        break;
      case 'system_memory':
        setGroup('system_memory');
        setDialogType('system_memory');
        break;
      case 'system_disk':
        setGroup('system_disk');
        setDialogType('system_disk');
        break;
      case 'system_network':
        setGroup('system_network');
        setDialogType('system_network');
        break;
      case 'system_network_data_pack':
        setGroup('system_network');
        setDialogType('system_network_data_pack');
        break;
      case 'statusCode':
        setGroup('statusCode');
        setDialogType('statusCode');
        break;
      case 'jvm_gc':
        setGroup('jvm_gc');
        setDialogType('jvm_gc');
        break;
      case 'jvm_gc_time' :
        setGroup('jvm_gc');
        setDialogType('jvm_gc_time');
        break;
      case 'jvm_heap' :
        setGroup('jvm_heap');
        setDialogType('jvm_heap');
        break;
      case 'jvm_none_heap' :
        setGroup('jvm_none_heap');
        setDialogType('jvm_none_heap');
        break;
      case 'jvm_meta_space' :
        setGroup('jvm_meta_space');
        setDialogType('jvm_meta_space');
        break;
      case 'jvm_thread_count':
        setGroup('jvm_thread_count');
        setDialogType('jvm_thread_count');
        break;
      default:
        return;
    }

    setNewApiVisibleChart(true);
  }

  // 关闭新接口历史弹窗
  function handleChangeHiddin() {
    setNewApiVisibleChart(false);
  }

  // 新接口历史数据请求接口
  function getNewApi(queryHistoryMetricParams) {
    if(!queryHistoryMetricParams)return;
    if (machineDetails.privateIp === '_all') {
      return services.QuerySystemResourceMetricOfGroup({
        params: {
          // group: group,
          // startTime: metricStartTime,
          // endTime: metricEndTime,
          // appName: appName || 'spring-cloud-a',
          // namespace: 'default',
          // RegionId: Region,
          // AhasRegionId: Region,
          // Namespace: 'default',
          // NameSpace: 'default',
          ...queryHistoryMetricParams,
        }
      });
    }
    return services.querySystemResourceMetricOfGroupOnNode();
  }

  // 数据写入sessionStorage
  function writeSessionStorage() {
    const chartsAry = [ 'cpu', 'load', 'system_memory', 'system_disk', 'system_network', 'system_network_data_pack' ];

    if (!sessionStorage.getItem('machineCharts')) {
      const machineChartsAry = [];
      chartsAry.forEach((item, index) => {
        machineChartsAry[index] = item;
      });
      machineChartsAry[chartsAry.length] = 'flag';
      sessionStorage.setItem('machineCharts', machineChartsAry.join());
    }
  }

  function renderRightBtn() {
    if (title) {
      if (typeCharts !== 'allQps' && typeCharts !== 'rt' && typeCharts !== 'thread') {
        const machineChartsAry = sessionStorage.getItem('machineCharts')?.split(',');

        if (machineChartsAry?.indexOf(typeCharts) !== -1) {
          return (
            <Badge dot>
              <span
                className={styles['badgeDot']}
                onClick={() => handleOpenSubDetailsDialog(typeCharts)}
              >指标详情</span>
            </Badge>
          );
        }
        return (
          <span
            className={styles['badgeDot']}
            onClick={() => handleOpenSubDetailsDialog(typeCharts)}
          >指标详情</span>
        );
      }
    }
  }

  // 渲染请求数
  const renderReqsCount = () => {
    return (
      <ul className={styles['reqsCount']}>
        {reqsCount && reqsCount.map((item, index) => {
          return isNginx && item.content === '异常请求数' ? <></> : (
            <li key={index}>
              <div className={styles['chartsNum']}>
                <Balloon trigger={item.balloonNum} closable={false}>
                  {item.num}
                </Balloon>
              </div>
              <div className={styles['chartsText']} style={{ color: '#c1c1c1' }}>
                {item.content}
              </div>
            </li>
          );
        })}
      </ul>
    );
  };

  // 拒绝QPS详情
  function handleQpsDetail() {
    setVisibleQps(!visibleQps);
  }

  function handleColesQps() {
    setVisibleQps(false);
  }
  function flowFormat(size) {
    if (!size) { return '0B'; }

    const num = 1024.00; // byte

    if (size < num) { return size + 'B'; }
    if (size < Math.pow(num, 2)) { return (size / num).toFixed(2) + 'KB'; } // kb
    if (size < Math.pow(num, 3)) { return (size / Math.pow(num, 2)).toFixed(2) + 'MB'; } // M
    if (size < Math.pow(num, 4)) { return (size / Math.pow(num, 3)).toFixed(2) + 'GB'; } // G
    return (size / Math.pow(num, 4)).toFixed(2) + 'TV'; // T
  }
  return (
    <>
      <div className={(!isPage && importType) ? styles['contentLarge'] : (!isPage && !importType) ? styles['contentSmall'] : styles['content']}
        style={{ width: chartsWidth }}
      >
        <div className={styles['contentChartsTitle']}>
          <span>
            {title}
            {/* {reqsCount && <span>
              <span className={styles.title}>时间周期：5 分钟</span>
              <span className={styles.title}>
                节点总数：{machineCount}
              </span>
              <span className={styles.title}>
                应用概览中涉及到的QPS/RT/并发线程均为应用入口接口的统计，不包括应用内部方法调用的统计。
              </span>
            </span>} */}
            {reqsCount && <span className={styles['title']}>
              {`( 时间周期：5 分钟，节点总数：${machineCount}，应用概览中涉及到的 QPS / RT 均为应用入口接口的统计，不包括应用内部方法调用的统计。)`}
            </span>}
          </span>
          <div style={{ display: 'flex', justifyContent: 'space-around' }}>
            {isInterface === 'interfaceQps' && (typeCharts === 'allQps' || typeCharts === 'all') && !reqsCount && <span>
              <span onClick={handleQpsDetail} className={styles['qpsDetal']}>拒绝QPS详情</span>
            </span>}
            <span>
              {!isScene && isPage && machineDetails.privateIp === '_all' && renderRightBtn()}
              {!isHotSpotMonitor && <span onClick={handleClick} className={styles['qpsDetal']}>历史数据</span>}
            </span>
          </div>
        </div>
        {/* {isInterface === 'interfaceQps' && reqsCount && <div className={styles.reqsCountQps}>
          <span onClick={handleQpsDetail}>拒绝QPS详情</span>
        </div>} */}
        <div className={styles['chartsContent']}>
          {reqsCount && renderReqsCount()}
          <div className={styles['chartsCanvas']}>
            {curMeticsData && curMeticsData.length ? <Chart
              height={250}
              data={dv}
              scale={renderCols()}
              padding="auto"
              forceFit
              onTooltipChange={onTooltipChange}
              onGetG2Instance={onGetG2Instance}
              onPlotLeave={onPlotLeave}
            >
              <Axis name="time" />
              <Axis name="count" />
              <Legend
                position='bottom-center'
              />
              <Tooltip />
              <Geom
                type={renderGeomType()}
                adjustType="stack"
                position="time*count"
                color={[ 'type', chartsColor ]}
                tooltip={[ 'time*count*type*name', (time, count, type, name) => {
                  if (name === 'network') {
                    return {
                      name: type,
                      title: moment(new Date(time)).format('YYYY-MM-DD HH:mm:ss'),
                      value: flowFormat(count),
                    };
                  }
                  return {
                    name: type,
                    title: moment(new Date(time)).format('YYYY-MM-DD HH:mm:ss'),
                    value: count,
                  };
                } ]}
              />
            </Chart> : (
              <div className={styles['chartsNoData']}>
                <p>
                  <i className={'iconfont icon-wushuju'}></i>
                  <span>暂无数据</span>
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
      {visible && <ChartsDialog
        dialogTitle={activeApiMetric + (dialogChartsTitle ? `${title} : ${dialogChartsTitle}` : nodeName ? `${title}: ${nodeName}` : title)}
        visible={visible}
        typeCharts={typeCharts}
        handleHiddin={handleHiddin}
        getApi={getApi}
        resource={resourceName}
        endTime={apiShowTime.backTime}
        ProcessConfigurationId={machineDetails.processConfigurationId || activeMacMetric}
        title={chartDialogtitle}
        isInterface={isInterface}
        dataQpsDeta={dataQpsDeta}
      />}

      {/* 查看新接口区间信息 */}
      {newApiVisibleChart && <ChartsDialog
        dialogTitle={title}
        visible={newApiVisibleChart}
        typeCharts={dialogType}
        handleHiddin={handleChangeHiddin}
        getApi={getNewApi}
        endTime={apiShowTime.backTime}
        apiNew={true}
        group={group}
        processConfigurationId={machineDetails.processConfigurationId}
      />}

      {/* 指标详情 */}
      <Dialog
        visible={visibleSubDetails}
        onClose={handleHiddenSubDetailsDialog}
        onCancel={handleHiddenSubDetailsDialog}
        title={`${title}指标详情`}
        footerActions={[ 'cancel' ]}
        style={{ width: '800px', minHeight: '550px' }}
        shouldUpdatePosition={true}
      >
        <SubDetailsDialog
          type={chartsType}
          curMeticsData={curMeticsData}
          onClose={handleHiddenSubDetailsDialog}
        />
      </Dialog>
      {visibleQps && <RuleCharts
        dataSource={dataQpsDeta}
        visibleQps={visibleQps}
        // handleOpenQps={handleOpenQps}
        handleColesQps={handleColesQps}
      />}
    </>
  );
};

export default OverviewCharts;
