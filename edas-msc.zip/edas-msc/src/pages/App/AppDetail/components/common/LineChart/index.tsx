import DataSet from '@antv/data-set';
import React, { FC, useEffect, useState } from 'react';
import { IChartDataSource } from 'config/interfaces';
import { intlNumberUnit } from '@ali/sre-utils';

interface LineChartProps {
  chartData: IChartDataSource[];
  type: string;
  height?: number;
  hasLegend?: boolean;
  onTooltipChange?: (tooltips: any) => void;
  onPlotLeave?: (plot: any) => void;
  getG2Charts?: (type: string, chart: any) => void;
}

const LineChart: FC<LineChartProps> = props => {
  const { chartData, type, height, hasLegend = false, onTooltipChange, onPlotLeave, getG2Charts } = props;
  const chartsColor = initChartsLineColor(type);

  const [ component, setComponent ] = useState<any>(null);

  useEffect(() => {
    (async function() {
      const bizcharts = await import('bizcharts');
      setComponent(bizcharts);
    })();
  }, []);

  if (!component) {
    return null;
  }

  const { Chart, Geom, Axis, Tooltip, Legend } = component;

  function renderCols() {
    if (type === 'system_cpu') {
      return {
        count: {
          min: 0,
          max: 100,
          tickCount: 5,
        },
        time: {
          alias: '时间',
          type: 'time',
          mask: 'HH:mm',
          tickCount: 5,
        },
      };
    }
    return {
      count: {
        min: 0,
        tickCount: 5,
      },
      time: {
        alias: '时间',
        type: 'time',
        mask: 'HH:mm',
        tickCount: 5,
      },
    };
  }

  // 初始化charts图表线条配色
  function initChartsLineColor(typeCharts: string) {
    switch (typeCharts) {
      case 'system_cpu' : return [ '#6CB4F0' ];
      case 'system_memory' : return [ '#6DC8EC', '#9270CA', '#FF9D4D', '#32C5FF' ];
      case 'system_load' : return [ '#63B0F9' ];
      case 'errorCode' : return [ '#D93026' ];
      case 'statusCode' : return [ '#479F67', '#A3CA50', '#E1B35E', '#F1772E', '#C75C59' ];
      default : return [ '#63B0F9' ];
    }
  }

  const { DataView } = DataSet;

  const dv = new DataView();
  dv.source(chartData);

  function onGetG2Instance(c: any) {
    const chart = c;
    if (chart) {
      getG2Charts ? getG2Charts(type, chart) : null;
    }
  }

  return (
    <>
      <Chart
        height={height || 120}
        data={dv}
        scale={renderCols()}
        padding="auto"
        forceFit={true}
        onTooltipChange={onTooltipChange ? onTooltipChange : null}
        onPlotLeave={onPlotLeave ? onPlotLeave : null}
        onGetG2Instance={onGetG2Instance}
      >
        <Axis
          name="time"
          line={{
            lineWidth: 1,
            stroke: '#ccc',
          }}
          tickLine={{
            lineWidth: 1,
            stroke: '#ccc',
          }}
        />
        <Axis
          name="count"
          label={{
            formatter: (val: string) => {
              return intlNumberUnit(Number(val).toFixed(2), 1);
            },
          }}
        />
        {hasLegend && <Legend
          position='bottom-center'
        />}
        <Tooltip />
        <Geom
          type={(type === 'system_cpu' || type === 'system_memory') ? 'area' : 'line'}
          position="time*count"
          color={[ 'type', chartsColor ]}
        />
      </Chart>
    </>
  );
};

export default LineChart;
