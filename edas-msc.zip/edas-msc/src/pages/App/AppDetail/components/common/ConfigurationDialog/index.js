import ActionStepThree from './ActionStepThree';
// import AlarmRulesStepFour from './AlarmRulesStepFour';
import ConfigurationPreview from './ConfigurationPreview';
import FlowRulesSceneStepTwo from './FlowRulesSceneStepTwo';
import ProtectionSceneStepOne from './ProtectionSceneStepOne';
import React, { useEffect, useRef, useState } from 'react';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import styles from './index.less';
import { Button, Dialog, Message, Step } from '@alicloud/console-components';
import { FLOW_RULES_SCENE_STEPTWO, PROTECTION_MANAGEMENT_STEPS, PROTECTION_MANAGEMENT_STEPS_ACTIVE } from '../config/constants/flow';
import { compare } from 'utils/util';
import { pushUrl } from '@ali/sre-utils';
import { getParams } from 'utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';
import services from 'services';
import Cookie from 'js-cookie';
import { isEmpty } from 'lodash';

const { Item: StepItem } = Step;
const { Group: ButtonGroup } = Button;

const ConfigurationDialog = props => {
  const { record, onCancel, updateRulesList, handleRuleCheck, selectModel, selectModelEnable, activeType = 1, resource: isApiDetails = '', isGwRules = false, isWebParamsRule = false } = props;
  // const dispatch = useDispatch();
  const intl = useIntl();
  const containerRef = useRef(null);
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const resType = Number(getParams('resType')) || -1;
  const [ currentStep, setCurrentStep ] = useState(0);
  const [ visible, setVisible ] = useState(false);
  const [ searchValues, setSearchValues ] = useGlobalState('searchValues');
  const protectionSceneDataStepOne = JSON.parse(searchValues.protectionSceneDataStepOne); // 选择防护场景数据
  const flowRuleOptionsDataStepTwo = searchValues?.flowRuleOptionsDataStepTwo ? JSON.parse(searchValues?.flowRuleOptionsDataStepTwo) : {}; // 配置防护规则数据
  const actionDataStepThree = JSON.parse(searchValues.actionDataStepThree); // 关联的行为数据
  const { protectionType = 1, resources = '' } = protectionSceneDataStepOne;
  const ruleId = flowRuleOptionsDataStepTwo.id || 0;
  const STEP_ITEM = checkStepsItem(protectionType);
  const STEPS_COUNT = STEP_ITEM.length;
  const isEdit = !!record;
  const sdkVersion = sessionStorage.getItem('sdkVersion') || '1.0.0';
  const fixedSDKVersion = '1.9.8';
  const agentVersion = sessionStorage.getItem('agentVersion') || '1.0.0';
  const fixedAgentVersion = '1.10.4';
  const isPassVersion = compare(sdkVersion, fixedSDKVersion) || compare(agentVersion, fixedAgentVersion);
  const isNeedUpdateWebVersion = FLOW_RULES_SCENE_STEPTWO[protectionType] === 'hotspot' && isGwRules && isWebParamsRule && !isPassVersion;

  useEffect(() => {
    isApiDetails && setStepOneData();
  }, [ isApiDetails ]);

  function setStepOneData() {
    const stepOneDate = {
      resources: isApiDetails,
      protectionType: activeType,
    };
    setSearchValues({...searchValues, protectionSceneDataStepOne: JSON.stringify(stepOneDate)});
    // dispatch.flowAppModel.setProtectionSceneDataStepOne(JSON.stringify(stepOneDate));
  }

  useEffect(() => {
    if (record || isApiDetails) {
      const { resource = '' } = record;
      const resourceName = resource ? resource : isApiDetails;
      querySentinelGetResourceFallback(resourceName);
      setCurrentStep(1);
    }
    return () => {
      // 清除store
      // dispatch.flowAppModel.clear('protectionSceneDataStepOne');
      // dispatch.flowAppModel.clear('flowRuleOptionsDataStepTwo');
      // dispatch.flowAppModel.clear('actionDataStepThree');
    };
  }, []);

  useEffect(() => {
    resources && querySentinelGetResourceFallback(resources);
  }, [ resources ]);

  // 查询当前接口所属接口类型
  async function querySentinelGetResourceFallback(resourceName) {
    const defaultApiType = (resType === 1 || resType === 2) ? resType : -1;
    // const { Data = {}, Success = false } = await services.SentinelGetResourceFallback({
    const Data = await services.SentinelGetResourceFallback({
      params: {
        AppName: appName,
        Resource: protectionType === 3 ? '__system_block_exception_resource__' : resourceName,
        BlockType: protectionType ? isWebParamsRule ? 11 : protectionType : 1,
        RegionId: region,
        AhasRegionId: region,
        namespace: 'default',
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    let apiType = defaultApiType;
    let fallbackId = 0;
    if (Data) {
      const { ResourceClassification = defaultApiType, Id = 0 } = Data;
      apiType = ResourceClassification;
      fallbackId = Id;
    }
    actionDataStepThree.TargetType = apiType;
    actionDataStepThree.FallbackId = fallbackId;
    setSearchValues({...searchValues, actionDataStepThree: JSON.stringify(actionDataStepThree)});
    // dispatch.flowAppModel.setActionDataStepThree(JSON.stringify(actionDataStepThree));
  }

  // 校验步骤
  function checkStepsItem(type) {
    switch (type) {
      case 0 : case 1 : case 2 : case 3 : case 4 :
        return PROTECTION_MANAGEMENT_STEPS;
      case 5 : return PROTECTION_MANAGEMENT_STEPS_ACTIVE;
      case 6 : return PROTECTION_MANAGEMENT_STEPS.slice(0, 2);
      default : return PROTECTION_MANAGEMENT_STEPS;
    }
  }

  // 步骤标题
  const steps = STEP_ITEM.map((item, index) => (
    <StepItem key={index} title={item.title}/>
  ));

  // 触发校验
  function handleRuleCheckDialog() {
    let allNext = false;
    if (containerRef.current.handleCheckRuleInput) {
      allNext = containerRef.current.handleCheckRuleInput();
    }
    return allNext;
  }

  // 下一步
  function handleNextStep() {
    if (handleRuleCheckDialog()) {
      const nextStep = currentStep + 1;
      setCurrentStep(nextStep > STEPS_COUNT ? STEPS_COUNT : nextStep);
    }
  }

  // 上一步
  function handlePrevStep() {
    const prevStep = currentStep - 1;
    setCurrentStep(prevStep < 0 ? 0 : prevStep);
  }

  // 校验规则种类
  function checkRulesType() {
    switch (FLOW_RULES_SCENE_STEPTWO[protectionType]) {
      case 'flow': return fetchFlowRules;
      case 'isolate': return fetchFlowRules;
      case 'fuse': return fetchFuseRules;
      case 'system': return fetchSystemRules;
      case 'hotspot': return isGwRules ? isWebParamsRule ? fetchWebParamsRules : fetchGwFlowRules : fetchHotspotRules;
      case 'activeDemote': return fetchActiveDemoteRules;
      case 'autoRetry': return fetchAutoRetryRules;
      default : return fetchFlowRules;
    }
  }

  // 新增、编辑防护规则
  function handleAddProtectionRules() {
    if (isNeedUpdateWebVersion) {
      Message.warning(<div>
        {`当前应用版本：${sdkVersion} 过低，该功能需 SDK Version >= ${fixedSDKVersion} 方可使用，请升级版本号。`}
      </div>);
    } else {
      checkRulesType()();
    }
  }

  // 单独步骤保存规则
  function handleEditProtectionRulesAnyStep() {
    console.log(flowRuleOptionsDataStepTwo, 'flowRuleOptionsDataStepTwo222-data9999');
    console.log(actionDataStepThree, 'actionDataStepThree-data000000');
    if (handleRuleCheckDialog()) {
      // checkRulesType()();
    }
  }

  // 新增/更新流控、隔离规则
  async function fetchFlowRules() {
    let resData = {};
    if (!isEdit) {
      resData = await services.SentinelFlowRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await services.SentinelFlowRuleEdit({
        params: {
          ...flowRuleOptionsDataStepTwo,
          RegionId: region,
          AhasRegionId: region,
          namespace: 'default',
          Namespace: 'default',
          NameSpace: 'default',
        }
      });
    }
    if(resData){
      onBindSentinelBlockFallbackDefinition();
    }
    const { Code, Success = false, Message: msg = '操作失败' } = resData;
    false && handleMessAge(Code, msg, Success);
  }

  // 查看集群配置
  function handleGoClusterProtection() {
    pushUrl(history, '/flowProtection/systemGuard/systemGuardClusterProtection', {
      appName,
    });
  }

  // 流控、隔离规则返回提示校验
  function handleMessAge(Code, msgPointText, success) {
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msgPointText);
      onCancel();
    } else if (Code === 'sentinel.cluster.app.level.illegal') {
      Message.warning(intl('ahas_sentinel.systemGuard.currentLim')); // 应用需开启高级防护才能使用集群限流功能
    } else if (Code === 'sentinel.cluster.commercial.noBelonging') {
      Message.help(<span style={{ cursor: 'pointer', color: '#0070cc' }} onClick={handleGoClusterProtection}>
        该应用没有对应的集群，请先创建对应的集群或在现有集群中指定该应用(点击跳转)
      </span>);
    } else if (Code === 'sentinel.cluster.commercial.quota.insufficient') {
      Message.warning(intl('ahas_sentinel.systemGuard.insufficient')); // '该应用所在集群的 QPS 总量不足，请调整集群最大 QPS'
    } else if (Code === 'sentinel.rule.flow.estimatedMaxClusterQps.tooLarge') {
      Message.warning(intl('ahas_sentinel.systemGuard.tooLarge')); // 接口集群总 QPS过大，请确认输入是否正确'
    } else if (Code === 'sentinel.cluster.still.disabled') {
      Message.warning(intl('ahas_sentinel.systemGuard.disabled')); // '请开启集群后创建流控规则'
    } if (success) {
      onBindSentinelBlockFallbackDefinition();
    }
  }

  // 新增/更新熔断规则
  async function fetchFuseRules() {
    let resData = {};
    if (!isEdit) {
      resData = await services.SentinelDegradeRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await services.SentinelDegradeRuleEdit({
        params: {
          ...flowRuleOptionsDataStepTwo,
          RegionId: region,
          AhasRegionId: region,
          namespace: 'default',
          Namespace: 'default',
          NameSpace: 'default',
        }
      });
    }
    if(resData){
      onBindSentinelBlockFallbackDefinition();
    }
    // const { Code, Success = false, Message: msg = '操作失败' } = resData;
    // if (!isEmpty(resData)) {
    //   handleRuleCheck && handleRuleCheck('操作成功');
    //   onCancel();
    //   onBindSentinelBlockFallbackDefinition();
    // } else {
    //   Message.error('操作失败');
    // }
  }

  // 新增/更新系统规则
  async function fetchSystemRules() {
    let resData = {};
    if (!isEdit) {
      resData = await services.SentinelSystemRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await services.SentinelSystemRuleEdit(flowRuleOptionsDataStepTwo);
    }
    const { Code, Success = false, Message: msg = '操作失败' } = resData;
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msg);
      onCancel();
    } else if (Code === 'sentinel.rule.system.duplicate') {
      handleRuleCheck && handleRuleCheck(msg);
      onCancel();
    } else if (Success) {
      onBindSentinelBlockFallbackDefinition();
    } else {
      Message.error(msg);
    }
  }

  // 新增/更新热点规则
  async function fetchHotspotRules() {
    let resData = {};
    if (!isEdit) {
      resData = await services.AddSentinelHotParamRule(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await services.EditSentinelHotParamRule({
        params: {
          ...flowRuleOptionsDataStepTwo,
          RegionId: region,
          AhasRegionId: region,
          namespace: 'default',
          Namespace: 'default',
          NameSpace: 'default',
        }
      });
    }
    if(resData){
      onBindSentinelBlockFallbackDefinition();
    }
    // const { Code, Success = false, Message: msg = '操作失败' } = resData;
    // if (!isEmpty(resData)) {
    //   handleRuleCheck && handleRuleCheck('操作成功');
    //   onCancel();
    //   onBindSentinelBlockFallbackDefinition();
    // } else {
    //   Message.error('操作失败');
    // }
  }

  // 新增/更新主动降级规则
  async function fetchActiveDemoteRules() {
    const { AppName, Resource, FallbackId, Id, Enabled = false } = actionDataStepThree;
    const submitData = {
      AppName,
      Resource,
      Enabled,
      FallbackId,
    };
    let resData = {};
    if (!isEdit) {
      resData = await services.CreateSentinelManualDegradeRule(submitData);
    } else {
      submitData.Id = Id;
      resData = await services.UpdateSentinelManualDegradeRule({
        params: {
          ...submitData,
          RegionId: region,
          AhasRegionId: region,
          namespace: 'default',
          Namespace: 'default',
          NameSpace: 'default',
        }
      });
    }
    const msgTips = isEdit ? '保存' : '新增';
    // const { Code, Success = false, Message: msg = '' } = resData;
    if (resData) {
      Message.success(msgTips + '成功');
      updateRulesList && updateRulesList();
    } else {
      Message.error(msgTips + '失败，请重试');
    }
    onCancel();
  }

  // 新增/更新自动重试规则
  async function fetchAutoRetryRules() {
    let resData = {};
    if (!isEdit) {
      resData = await services.CreateSentinelRetryRule(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await services.UpdateSentinelRetryRule(flowRuleOptionsDataStepTwo);
    }
    const msgTips = isEdit ? '保存' : '新增';
    const { Code, Success = false, Message: msg = '' } = resData;
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msg);
    } else if (Success) {
      Message.success(msgTips + '成功');
      updateRulesList && updateRulesList();
    } else {
      Message.error(msgTips + '失败，请重试');
    }
    onCancel();
  }

  // 新增/更新API流控规则
  async function fetchGwFlowRules() {
    let resData = {};
    if (!isEdit) {
      resData = await services.SentinelGatewayFlowRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await services.SentinelGatewayFlowRuleEdit(flowRuleOptionsDataStepTwo);
    }
    const { Success = false, Message: msg = '' } = resData;
    if (Success) {
      onBindSentinelBlockFallbackDefinition();
    } else {
      Message.error(msg);
    }
  }

  // 新增/更新web参数限流规则
  async function fetchWebParamsRules() {
    let resData = {};
    if (!isEdit) {
      resData = await services.SentinelWebFlowRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await services.SentinelWebFlowRuleEdit(flowRuleOptionsDataStepTwo);
    }
    const { Success = false, Message: msg = '' } = resData;
    if (Success) {
      onBindSentinelBlockFallbackDefinition();
    } else {
      Message.error(msg);
    }
  }

  // 绑定限流行为
  async function onBindSentinelBlockFallbackDefinition() {
    const submitData = { ...actionDataStepThree };
    submitData.TargetType = protectionType ? isWebParamsRule ? 11 : protectionType : 1;
    if (protectionType === 3) {
      submitData.Resource = '__system_block_exception_resource__';
    }

    const msgTips = isEdit ? '保存' : '新增';
    const Success = await services.BindSentinelBlockFallbackDefinition({
      params: {
        ...submitData,
        RegionId: region,
        AhasRegionId: region,
        namespace: 'default',
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    if (Success) {
      Message.success(msgTips + '成功');
    } else {
      Message.error(msgTips + '失败，请重试');
    }
    updateRulesList && updateRulesList();
    onCancel();
  }

  // 配置预览
  function handleConfigurationPreview() {
    setVisible(!visible);
  }

  return (
    <div className={styles['content']}>
      <div className={styles['stepTitle']}>
        <Step
          current={currentStep}
          direction='ver'
          shape='circle'
          readOnly
          animation={true}
        >
          {steps}
        </Step>
      </div>
      <div className={styles['stepItem']}>
        <div className={styles['configurationContent']}>
          {currentStep === 0 && <ProtectionSceneStepOne
            isEdit={isEdit}
            record={protectionSceneDataStepOne}
            wrapRef={containerRef}
            isGwRules={isGwRules}
            isWebParamsRule={isWebParamsRule}
          />}
          {currentStep === 1 && (protectionType === 5 ? <ActionStepThree
            isEdit={isEdit}
            record={actionDataStepThree}
            wrapRef={containerRef}
            isGwRules={isGwRules}
            isWebParamsRule={isWebParamsRule}
          /> : <FlowRulesSceneStepTwo
            record={flowRuleOptionsDataStepTwo}
            wrapRef={containerRef}
            handleRuleCheck={handleRuleCheck}
            selectModel={selectModel}
            selectModelEnable={selectModelEnable}
            isGwRules={isGwRules}
            isWebParamsRule={isWebParamsRule}
          />)}
          {currentStep >= 2 && (protectionType !== 6 && <ActionStepThree
            isEdit={isEdit}
            record={actionDataStepThree}
            wrapRef={containerRef}
            isGwRules={isGwRules}
            isWebParamsRule={isWebParamsRule}
          />)}
        </div>

        <ButtonGroup>
          {false && <Button onClick={handleConfigurationPreview} type="primary" disabled={currentStep === 0}> 规则预览</Button>}
          <Button onClick={handlePrevStep} type="primary" disabled={currentStep === 0}>上一步</Button>
          <Button onClick={handleNextStep} type="primary" disabled={currentStep === STEPS_COUNT}>下一步</Button>
          {false && isEdit && (currentStep < STEPS_COUNT) && <Button onClick={() => handleEditProtectionRulesAnyStep()} type="primary">保存</Button>}
          {currentStep === STEPS_COUNT && <Button onClick={() => handleAddProtectionRules()} type="primary">{isEdit ? '保存' : '新增'}</Button>}
          <Button onClick={() => onCancel()} type='normal'>取消</Button>
        </ButtonGroup>
      </div>
      {/* 配置预览弹窗 */}
      <Dialog
        title={'规则配置预览'}
        visible={visible}
        onClose={handleConfigurationPreview}
        footer={<></>}
        shouldUpdatePosition={true}
        className={styles['addOrEditDialog']}
      >
        <ConfigurationPreview />
      </Dialog>
    </div>
  );
};

export default ConfigurationDialog;
