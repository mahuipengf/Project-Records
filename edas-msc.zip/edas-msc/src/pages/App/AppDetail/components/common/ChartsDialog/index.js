import React, { useEffect, useState } from 'react';
import { useIntl } from '@ali/widget-hooks';
import {
  Button,
  Dialog,
  Loading,
  Message,
  Tab,
} from '@alicloud/console-components';
import {
  CHART_CONTRAST_TYPE,
  CHART_COUNT,
  CHART_TYPE,
  DATA_OF_CHARTS_SHOW,
  RESET,
} from '../config/constants/flow';
import { getParams } from 'utils';

import styles from './index.less';

import ComparedCard from './ComparedCard';
import IntervalCard from './IntervalCard';
import Cookie from 'js-cookie';

const ChartsDialog = props => {
  const intl = useIntl();
  // const dispatch = useDispatch();
  const appName = getParams('appName') || '';
  const Region = Cookie.get('currentRegionId') || 'cn-hangzhou';
  const ahasProEnable = true;
  const {
    handleHiddin,
    visible,
    typeCharts,
    getApi,
    resource,
    startTime,
    endTime,
    ProcessConfigurationId,
    Loop,
    dialogTitle,
    hiddenTab,
    apiNew,
    group,
    processConfigurationId,
    systemLoadResource,
    fromType,
    isInterface,
    dataQpsDeta,
    eventCenter = ''
  } = props;

  const [ dataSource, setDataSource ] = useState([]);
  const [ loading, setLoading ] = useState(false);
  const [ tabIdx, setTabIdx ] = useState('0');
  const [ radioValue, setRadioValue ] = useState('halfHourMetric');
  const [ radioYdValue, setRadioYdValue ] = useState('ydMetric');
  const [ datePickerView, setDatePickerView ] = useState(false);
  const [ datePickerYdView, setDatePickerYdView ] = useState(false);
  const [ hidden, setHidden ] = useState(true);

  const [ passQpsChartsData, setPassQpsChartsData ] = useState([]);
  const [ blockedQpsChartsData, setBlockedQpsChartsData ] = useState([]);
  const [ exceptionQpsChartsData, setExceptionQpsChartsData ] = useState([]);
  const [ rtChartsData, setRtChartsData ] = useState([]);
  const [ threadChartsData, setThreadChartsData ] = useState([]);
  const [ cpuChartsData, setCpuChartsData ] = useState([]);
  const [ loadChartsData, setLoadChartsData ] = useState([]);
  const [ exceptionChartsData, setExceptionChartsData ] = useState([]);
  const [ flowRuleQPS, setFlowRuleQPS ] = useState([]);
  const [ degradeRuleQPS, setDegradeRuleQPS ] = useState([]);
  const [ systemRuleQPS, setSystemRuleQPS ] = useState([]);
  const [ paramRuleQPS, setParamRuleQPS ] = useState([]);
  const [ manualDegradeRuleQPS, setManualDegradeRuleQPS ] = useState([]);

  useEffect(() => {
    if (visible === true) {
      if (startTime && endTime) {
        queryHistoryMetric(new Date(startTime), new Date(endTime));
      } else if (!startTime && endTime) {
        queryHistoryMetric(null, new Date(endTime));
      } else {
        queryHistoryMetric();
      }
    }
  }, [ visible ]);

  useEffect(() => {
    initChartsDataGroup();
  }, [
    passQpsChartsData,
    blockedQpsChartsData,
    exceptionQpsChartsData,
    rtChartsData,
    threadChartsData,
    cpuChartsData,
    loadChartsData,
    exceptionChartsData,
    flowRuleQPS,
    degradeRuleQPS,
    systemRuleQPS,
    paramRuleQPS,
    manualDegradeRuleQPS,
  ]);

  // useEffect(() => {
  //   dispatch.homeModel.getGlobals();
  // }, []);

  // 构建图标数据函数
  function initChartsData(
    innerMetrics,
    type,
    dateSpan,
  ) {
    const chartData = [];
    const span = dateSpan ? dateSpan : 1;

    !!innerMetrics &&
      innerMetrics.length &&
      innerMetrics.forEach((item) => {
        item[CHART_COUNT[type]] = Number(item[CHART_COUNT[type]]);
        if (type === 'exception') {
          chartData.push({
            time: item.time || 0,
            type: '异常次数',
            count: item.count,
          });
        } else if (item.listType === 'contrast') {
          chartData.push({
            time: item.timestamp
              ? item.timestamp + 1000 * 60 * 60 * 24 * span
              : 0,
            type: CHART_CONTRAST_TYPE(intl)[type],
            count: item[CHART_COUNT[type]],
          });
        } else {
          chartData.push({
            time: item.timestamp || 0,
            type: CHART_TYPE(intl)[type],
            count: item[CHART_COUNT[type]],
          });
        }
      });

    return chartData;
  }

  // 构建单一图表数据
  function initSingleChartsData(
    innerMetrics,
    type,
    dateSpan,
  ) {
    const singleChartsData = initChartsData(innerMetrics, type, dateSpan);
    switch (type) {
      case 'passQps':
        setPassQpsChartsData(singleChartsData);
        break;
      case 'flowRuleQPS':
        setFlowRuleQPS(singleChartsData);
        break;
      case 'degradeRuleQPS':
        setDegradeRuleQPS(singleChartsData);
        break;
      case 'systemRuleQPS':
        setSystemRuleQPS(singleChartsData);
        break;
      case 'paramRuleQPS':
        setParamRuleQPS(singleChartsData);
        break;
      case 'manualDegradeRuleQPS':
        setManualDegradeRuleQPS(singleChartsData);
        break;
      case 'blockedQps':
        setBlockedQpsChartsData(singleChartsData);
        break;
      case 'exceptionQps':
        setExceptionQpsChartsData(singleChartsData);
        break;
      case 'rt':
        setRtChartsData(singleChartsData);
        break;
      case 'thread':
        setThreadChartsData(singleChartsData);
        break;
      case 'cpu':
        setCpuChartsData(singleChartsData);
        break;
      case 'load':
        setLoadChartsData(singleChartsData);
        break;
      case 'exception':
        setExceptionChartsData(singleChartsData);
        break;
      default:
        return;
    }
  }

  // 通过图表类型将单一图表数据合并为目标数据
  function initChartsDataGroup() {
    switch (typeCharts) {
      case 'allQps':
        setDataSource([
          ...passQpsChartsData,
          ...blockedQpsChartsData,
          ...exceptionQpsChartsData,
          ...flowRuleQPS,
          ...degradeRuleQPS,
          ...systemRuleQPS,
          ...paramRuleQPS,
          ...manualDegradeRuleQPS,
        ]);
        break;
      case 'rtAndThread':
        setDataSource([ ...rtChartsData, ...threadChartsData ]);
        break;
      case 'rt':
        setDataSource(rtChartsData);
        break;
      case 'thread':
        setDataSource(threadChartsData);
        break;
      case 'all':
        setDataSource([
          ...passQpsChartsData,
          ...blockedQpsChartsData,
          ...exceptionQpsChartsData,
          ...rtChartsData,
          ...threadChartsData,
          ...flowRuleQPS,
          ...degradeRuleQPS,
          ...systemRuleQPS,
          ...paramRuleQPS,
          ...manualDegradeRuleQPS,
        ]);
        break;
      case 'cpu':
        setDataSource(cpuChartsData);
        break;
      case 'load':
        setDataSource(loadChartsData);
        break;
      case 'exception':
        setDataSource(exceptionChartsData);
        break;
      default:
        return;
    }
  }

  // 弹窗头部标题
  function renderTitle() {
    if (dialogTitle) {
      return <div>{dialogTitle}</div>;
    }
    return <div>{appName}</div>;
  }

  function handleClose() {
    handleHiddin();
    setTabIdx('0');
    setRadioValue('halfHourMetric');
    setDatePickerView(false);
  }

  // 查询图表历史数据
  function queryHistoryMetric(
    startTime,
    endTime,
    contStartTime,
    contEndTime,
    lineType,
    dateSpan,
  ) {
    const span = dateSpan ? dateSpan : 1;
    let metricStartTime,
      metricEndTime,
      contrastStartTime,
      contrastEndTime;
    const type = lineType || 'interval';

    if (contStartTime == null || contEndTime == null) {
      contEndTime = new Date().getTime() - 60 * 60 * 1000 * 24;
      contrastEndTime = contEndTime;
      contrastStartTime = contEndTime - 30 * 60 * 1000;
    } else {
      contrastStartTime = contStartTime.getTime();
      contrastEndTime = contEndTime.getTime();
    }
    if (startTime == null && endTime != null) {
      metricEndTime = endTime.getTime();
      metricStartTime = endTime.getTime() - 30 * 60 * 1000;
    }

    if (startTime != null && endTime == null) {
      endTime = new Date();
      metricEndTime = endTime.getTime();
      metricStartTime = startTime.getTime();
    }

    if (startTime == null && endTime == null) {
      endTime = new Date();
      metricEndTime = endTime.getTime();
      metricStartTime = endTime.getTime() - 30 * 60 * 1000;
    }

    if (startTime != null && endTime != null) {
      metricEndTime = endTime.getTime();
      metricStartTime = startTime.getTime();
    }

    if (startTime > endTime || contStartTime > contEndTime) {
      Message.show({
        type: 'error',
        content: intl('ahas_sentinel.systemGuard.FuseRules.greater'),
        duration: 3000,
      });
      return;
    }
    setDataSource([]);

    let ArrNow;
    if (apiNew) {
      ArrNow = doQueryNewApi(metricStartTime, metricEndTime);
    } else {
      ArrNow = doQuery(metricStartTime, metricEndTime);
    }
    let Arrcont;
    if (type === 'compared') {
      if (apiNew) {
        Arrcont = doQueryNewApi(contrastStartTime, contrastEndTime);
      } else {
        Arrcont = doQuery(contrastStartTime, contrastEndTime);
      }
    }
    const histroyArr = type === 'interval' ? [ ArrNow ] : [ ArrNow, Arrcont ];
    let dataList = [];
    Promise.all(histroyArr).then(val => {
      if (val.indexOf(undefined) !== -1) {
        return null;
      }
      if (type === 'compared') {
        val[1].forEach(item => {
          item.listType = 'contrast'; // 标记为同比数据
        });
      }
      dataList = Array.prototype.concat.apply([], val);

      if (apiNew) {
        initNewApiChartsData(dataList);
        return;
      }
      switch (typeCharts) {
        case 'allQps':
          initSingleChartsData(dataList, 'passQps', span);
          initSingleChartsData(dataList, 'blockedQps', span);
          initSingleChartsData(dataList, 'exceptionQps', span);
          initSingleChartsData(dataList, 'flowRuleQPS', span);
          initSingleChartsData(dataList, 'degradeRuleQPS', span);
          initSingleChartsData(dataList, 'systemRuleQPS', span);
          initSingleChartsData(dataList, 'paramRuleQPS', span);
          initSingleChartsData(dataList, 'manualDegradeRuleQPS', span);
          break;
        case 'rtAndThread': {
          initSingleChartsData(dataList, 'rt', span);
          initSingleChartsData(dataList, 'thread', span);
          break;
        }
        case 'rt':
          initSingleChartsData(dataList, 'rt', span);
          break;
        case 'thread':
          initSingleChartsData(dataList, 'thread', span);
          break;
        case 'all':
          initSingleChartsData(dataList, 'passQps', span);
          initSingleChartsData(dataList, 'blockedQps', span);
          initSingleChartsData(dataList, 'exceptionQps', span);
          initSingleChartsData(dataList, 'rt', span);
          initSingleChartsData(dataList, 'thread', span);
          initSingleChartsData(dataList, 'flowRuleQPS', span);
          initSingleChartsData(dataList, 'degradeRuleQPS', span);
          initSingleChartsData(dataList, 'systemRuleQPS', span);
          initSingleChartsData(dataList, 'paramRuleQPS', span);
          initSingleChartsData(dataList, 'manualDegradeRuleQPS', span);
          break;
        case 'cpu':
          initSingleChartsData(dataList, 'cpu', span);
          break;
        case 'load':
          initSingleChartsData(dataList, 'load', span);
          break;
        case 'jvm_gc':
          initSingleChartsData(dataList, 'jvmGc', span);
          break;
        case 'jvm_gc_time':
          initSingleChartsData(dataList, 'jvmGcTime', span);
          break;
        case 'system_network':
          initSingleChartsData(dataList, 'systemNetwork', span);
          break;
        case 'system_network_data_pack':
          initSingleChartsData(dataList, 'systemNetworkDataPack', span);
          break;
        case 'exception':
          initSingleChartsData(dataList, 'exception', span);
          break;
        default:
          return;
      }
    });
  }

  // 接口函数
  async function doQuery(startTime, endTime) {
    let resourceParams = '';
    if (resource) {
      // 处理传入的情况
      resourceParams = resource;
    } else {
      // 处理不传的情况
      if (typeCharts === 'cpu') {
        resourceParams = '__cpu_usage__';
      } else if (typeCharts === 'load') {
        resourceParams = '__system_load__';
      } else {
        resourceParams = '__app_summary_metric_resource_name__';
      }
    }


    setLoading(true);
    let queryHistoryMetricParams;

    queryHistoryMetricParams = {
      appName: appName || 'spring-cloud-a',
      resource: resourceParams,
      startTime: startTime,
      endTime: endTime,
      namespace: 'default',
      RegionId: Region,
      AhasRegionId: Region,
      Namespace: 'default',
      NameSpace: 'default',
    };

    if (fromType === 'machine') {
      queryHistoryMetricParams.Node = processConfigurationId;
    }

    if (Loop && ProcessConfigurationId) {
      queryHistoryMetricParams = {
        ...queryHistoryMetricParams,
        Loop,
        ProcessConfigurationId,
      };
    } else if (!Loop && ProcessConfigurationId) {
      queryHistoryMetricParams = {
        ...queryHistoryMetricParams,
        ProcessConfigurationId,
      };
    }


    let innerMetrics = [];
    if (typeCharts === 'exception') {
      const { Data = [] } = await getApi(queryHistoryMetricParams);
      const systemNetwork = [];
      Data?.length && Data.forEach(item => {
        systemNetwork.push({
          time: item.Timestamp,
          count: item.Count,
        });
      });
      innerMetrics = systemNetwork;
    } else {
      const Data = await getApi(queryHistoryMetricParams);
      innerMetrics = Data?.innerMetrics;
    }

    setLoading(false);
    return await innerMetrics;
  }

  // 新版接口函数
  async function doQueryNewApi(startTime, endTime) {
    setLoading(true);

    const newApiParams = {
      AppName: appName || 'spring-cloud-a',
      startTime,
      endTime,
      group: group ? group : typeCharts,
      namespace: 'default',
      Namespace: 'default',
      NameSpace: 'default',
    };

    if (resource) {
      newApiParams.resource = resource;
    }

    if (processConfigurationId) {
      newApiParams.processConfigurationId = processConfigurationId;
    }


    const newApiData = await getApi(newApiParams);
    const Data = newApiData;

    setLoading(false);
    if (Data) {
      return await Data;
    }
    return await newApiData;
  }

  // 构建新接口图表数据函数
  function initNewApiChartsData(newApiData, dateSpan) {

    // if (!systemLoadResource) {
    //   newApiData = newApiData.filter((val: any) => val.Resource && val.Resource.indexOf('.total') === -1);
    // }

    const curMeticsData = [];
    const span = dateSpan ? dateSpan : 1;

    if (newApiData && !newApiData.length) {
      setDataSource([]);
      return;
    }

    if (typeCharts === 'errorCode') {
      newApiData.forEach(item => {
        if (item.listType === 'contrast') {
          curMeticsData.push({
            time: item.Time
              ? item.Time + 1000 * 60 * 60 * 24 * span
              : 0,
            type: intl('ahas_sentinel.systemGuard.FuseRules.statusCodes'),
            count: +Number(item.ErrorNum).toFixed(0),
          });
        } else {
          curMeticsData.push({
            time: item.Time,
            type: intl('ahas_sentinel.systemGuard.FuseRules.NumberCodes'),
            count: +Number(item.ErrorNum).toFixed(0),
          });
        }
      });
      setDataSource(curMeticsData);
      return;
    }

    if (typeCharts === 'statusCode') {
      newApiData.forEach(item => {
        if (item.listType === 'contrast') {
          curMeticsData.push({
            time: item.Time
              ? item.Time + 1000 * 60 * 60 * 24 * span
              : 0,
            type: intl('ahas_sentinel.systemGuard.FuseRules.Yearonyear200'),
            count: item.Is200,
          });

          curMeticsData.push({
            time: item.Time
              ? item.Time + 1000 * 60 * 60 * 24 * span
              : 0,
            type: intl('ahas_sentinel.systemGuard.FuseRules.Yearonyear2xx'),
            count: item.Like2xx,
          });

          curMeticsData.push({
            time: item.Time
              ? item.Time + 1000 * 60 * 60 * 24 * span
              : 0,
            type: intl('ahas_sentinel.systemGuard.FuseRules.Yearonyear3xx'),
            count: item.Like3xx,
          });

          curMeticsData.push({
            time: item.Time
              ? item.Time + 1000 * 60 * 60 * 24 * span
              : 0,
            type: intl('ahas_sentinel.systemGuard.FuseRules.Yearonyear4xx'),
            count: item.Like4xx,
          });

          curMeticsData.push({
            time: item.Time
              ? item.Time + 1000 * 60 * 60 * 24 * span
              : 0,
            type: intl('ahas_sentinel.systemGuard.FuseRules.Yearonyear5xx'),
            count: item.Like5xx,
          });

          curMeticsData.push({
            time: item.Time
              ? item.Time + 1000 * 60 * 60 * 24 * span
              : 0,
            type: `${intl('ahas_sentinel.systemGuard.FuseRules.Yearonyear4xx')} + ${intl('ahas_sentinel.systemGuard.FuseRules.Yearonyear5xx')}`,
            count: item.ErrorNum,
          });
        } else {
          curMeticsData.push({
            time: item.Time,
            type: '200',
            count: item.Is200,
          });

          curMeticsData.push({
            time: item.Time,
            type: '2xx',
            count: item.Like2xx,
          });

          curMeticsData.push({
            time: item.Time,
            type: '3xx',
            count: item.Like3xx,
          });

          curMeticsData.push({
            time: item.Time,
            type: '4xx',
            count: item.Like4xx,
          });

          curMeticsData.push({
            time: item.Time,
            type: '5xx',
            count: item.Like5xx,
          });

          curMeticsData.push({
            time: item.Times,
            type: '4xx + 5xx',
            count: item.ErrorNum,
          });
        }
      });
      setDataSource(curMeticsData);
      return;
    }

    if (typeCharts === 'jvm_gc') {
      newApiData.forEach(item => {
        if (item.listType === 'contrast') {

          if (item.Resource === 'jvm.gc.old.count') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('ahas_sentinel.systemGuard.FuseRules.FullGC'),
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'jvm.gc.young.count') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('ahas_sentinel.systemGuard.FuseRules.YoungGC'),
              count: item.Val,
              val: item.Resource,
            });
          }
        } else {
          if (item.Resource === 'jvm.gc.old.count') {
            curMeticsData.push({
              time: item.Time,
              type: intl('ahas_sentinel.systemGuard.FuseRules.FullGCTimes'),
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'jvm.gc.young.count') {
            curMeticsData.push({
              time: item.Time,
              type: intl('ahas_sentinel.systemGuard.FuseRules.YoungGC'),
              count: item.Val,
              val: item.Resource,
            });
          }
        }
      });

      setDataSource(curMeticsData);
      return;
    }

    if (typeCharts === 'jvm_gc_time') {
      newApiData.forEach((item) => {
        if (item.listType === 'contrast') {

          if (item.Resource === 'jvm.gc.old.time') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('ahas_sentinel.systemGuard.FuseRules.consuming') + '(ms)',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'jvm.gc.young.time') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('YoungGCtime-consuming') + '(ms)',
              count: item.Val,
              val: item.Resource,
            });
          }
        } else {
          if (item.Resource === 'jvm.gc.old.time') {
            curMeticsData.push({
              time: item.Time,
              type: intl('FullGCTimeConsuming-consuming') + '(ms)',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'jvm.gc.young.time') {
            curMeticsData.push({
              time: item.Time,
              type: intl('ahas_sentinel.systemGuard.FuseRules.YoungGCTimeConsuming') + '(ms)',
              count: item.Val,
              val: item.Resource,
            });
          }
        }
      });

      setDataSource(curMeticsData);
      return;
    }

    if (typeCharts === 'system_network') {
      newApiData.forEach((item) => {
        if (item.listType === 'contrast') {
          if (item.Resource === 'system.net.in.bytes') {
            curMeticsData.push({
              name: 'network',
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: '网络接收流量大小',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'system.net.out.bytes') {
            curMeticsData.push({
              name: 'network',
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: '网络发送流量大小',
              count: item.Val,
              val: item.Resource,
            });
          }
        } else {
          if (item.Resource === 'system.net.in.bytes') {
            curMeticsData.push({
              name: 'network',
              time: item.Time,
              type: '网络接收流量大小',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'system.net.out.bytes') {
            curMeticsData.push({
              name: 'network',
              time: item.Time,
              type: '网络发送流量大小',
              count: item.Val,
              val: item.Resource,
            });
          }
        }
      });

      setDataSource(curMeticsData);
      return;
    }

    if (typeCharts === 'system_network_data_pack') {
      newApiData.forEach((item) => {
        if (item.listType === 'contrast') {

          if (item.Resource === 'system.net.in.packets') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('ahas_sentinel.systemGuard.FuseRules.Compared') + '(个)',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'system.net.out.packets') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('ahas_sentinel.systemGuard.FuseRules.period') + '(个)',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'system.net.in.errs') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('ahas_sentinel.systemGuard.FuseRules.errorsReceived') + '(个)',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'system.net.in.dropped') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('ahas_sentinel.systemGuard.FuseRules.networkDiscarded') + '(个)',
              count: item.Val,
              val: item.Resource,
            });
          }
        } else {
          if (item.Resource === 'system.net.in.packets') {
            curMeticsData.push({
              time: item.Time,
              type: intl('ahas_sentinel.systemGuard.FuseRules.Numberreceived') + '(个)',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'system.net.out.packets') {
            curMeticsData.push({
              time: item.Time,
              type: intl('ahas_sentinel.systemGuard.FuseRules.packets') + '(个)',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'system.net.in.errs') {
            curMeticsData.push({
              time: item.Time,
              type: intl('ahas_sentinel.systemGuard.FuseRules.NumberOfErrorsReceived') + '(个)',
              count: item.Val,
              val: item.Resource,
            });
          }
          if (item.Resource === 'system.net.in.dropped') {
            curMeticsData.push({
              time: item.Time,
              type: intl('ahas_sentinel.systemGuard.FuseRules.NumberOfDiscarded') + '(个)',
              count: item.Val,
              val: item.Resource,
            });
          }
        }
      });

      setDataSource(curMeticsData);
      return;
    }

    newApiData.forEach((item) => {
      if (systemLoadResource) {
        if (item.Resource === systemLoadResource) {
          item.Val = Number(item.Val);
          const type = DATA_OF_CHARTS_SHOW[item.Resource];

          if (item.listType === 'contrast') {
            curMeticsData.push({
              time: item.Time
                ? item.Time + 1000 * 60 * 60 * 24 * span
                : 0,
              type: intl('ahas_sentinel.systemGuard.FuseRules.YearOnYear') + type,
              count: item.Val,
              val: item.Resource,
            });
          } else {
            curMeticsData.push({
              time: item.Time,
              type,
              count: item.Val,
              val: item.Resource,
            });
          }
        }
      } else {
        item.Val = Number(item.Val);
        const type = DATA_OF_CHARTS_SHOW[item.Resource];
        const unit = (typeCharts === 'system_memory' || typeCharts === 'system_disk') ? '(G)' : (typeCharts === 'jvm_heap' || typeCharts === 'jvm_none_heap') ? '(/M)' : '';
        if (item.listType === 'contrast') {
          curMeticsData.push({
            time: item.Time
              ? item.Time + 1000 * 60 * 60 * 24 * span
              : 0,
            type: intl('ahas_sentinel.systemGuard.FuseRules.YearOnYear') + type + unit,
            count: item.Val,
            val: item.Resource,
          });
        } else {
          curMeticsData.push({
            time: item.Time,
            type: type + unit,
            count: item.Val,
            val: item.Resource,
          });
        }
      }
    });
    setDataSource(curMeticsData);
  }

  // radio切换图表数据重新请求逻辑
  function handleQueryMetric(idx, lineType) {
    let startTime,
      contrastStartTime;
    const endTime = new Date(); // 当前时间
    const currentEndTime = endTime.getTime() - 1000 * 60 * 60 * 24; // 昨日同比结束时间
    const contrastEndTime = new Date(currentEndTime);
    if (idx === 1) {
      startTime = new Date(endTime.getTime() - 1000 * 60 * 30); // 半小时
    } else if (idx === 2) {
      startTime = new Date(endTime.getTime() - 1000 * 60 * 60 * 3); // 3小时
    } else if (idx === 3) {
      startTime = new Date(endTime.getTime() - 1000 * 60 * 60 * 12); // 12小时
    } else if (idx === 4) {
      startTime = new Date(endTime.getTime() - 1000 * 60 * 60 * 24); // 1天
    } else if (idx === 5) {
      startTime = new Date(endTime.getTime() - 1000 * 60 * 30);
      contrastStartTime = new Date(contrastEndTime.getTime() - 1000 * 60 * 30);
    }
    queryHistoryMetric(
      startTime,
      endTime,
      contrastStartTime,
      contrastEndTime,
      lineType,
    );
  }

  // 标签页切换函数
  function handleTabChange(idx) {
    setTabIdx(idx);
    if (idx === '0') {
      setRadioValue('halfHourMetric');
      handleQueryMetric(1);
      setDatePickerView(false);
    } else if (idx === '1') {
      setRadioYdValue('ydMetric');
      handleQueryMetric(5, 'compared');
      setDatePickerYdView(false);
    }
  }

  // 区间查看radio控制
  function changeRadioValue(value) {
    setRadioValue(value);
  }

  // 时间对比radio控制
  function changeRadioYdValue(value) {
    setRadioYdValue(value);
  }

  // 区间查看模块时间选择器控制
  function handleDatePickerYdView() {
    setDatePickerYdView(true);
  }

  function handleDatePickerYdHidden() {
    setDatePickerYdView(false);
  }

  // 时间对比模块时间选择器控制
  function handleDatePickerView() {
    setDatePickerView(true);
  }

  function handleDatePickerHidden() {
    setDatePickerView(false);
  }

  // 框选后重置
  function handleReset() {
    if (tabIdx === '0') {
      switch (radioValue) {
        case 'halfHourMetric':
          handleQueryMetric(1);
          break;
        case '3hourMetric':
          handleQueryMetric(2);
          break;
        case '12hourMetric':
          handleQueryMetric(3);
          break;
        case '1dayMetric':
          handleQueryMetric(4);
          break;
        case 'customMetric':
          setRadioValue('halfHourMetric');
          handleQueryMetric(1);
          handleDatePickerHidden();
          break;
        default: {
          return;
        }
      }
    } else if (tabIdx === '1') {
      handleQueryMetric(5, 'compared');
      setRadioYdValue('ydMetric');
      handleDatePickerYdHidden();
    }
    setHidden(true);
  }

  // 重置按钮显示隐藏
  function showResetBtn(sum) {
    if (tabIdx === '0') {
      switch (radioValue) {
        case 'halfHourMetric':
          if (sum < 1000 * 60 * 30) {
            setHidden(false);
          }
          break;
        case '3hourMetric':
          if (sum < 1000 * 60 * 60 * 3) {
            setHidden(false);
          }
          break;
        case '12hourMetric':
          if (sum < 1000 * 60 * 60 * 12) {
            setHidden(false);
          }
          break;
        case '1dayMetric':
          if (sum < 1000 * 60 * 60 * 24) {
            setHidden(false);
          }
          break;
        case 'customMetric':
          setHidden(false);
          break;
        default: {
          return;
        }
      }
    } else if (tabIdx === '1') {
      if (sum < 1000 * 60 * 30) {
        setHidden(false);
      }
    }
  }

  return (
    <>
      <Dialog
        visible={visible}
        className={styles['panle']}
        title={renderTitle()}
        footer={false}
        onClose={handleClose}
        closeable={true}
      >
        {false && hidden && <Button
          type="primary"
          text
          className={`${styles['reset-btn']}`}
          onClick={handleReset}
        >
          {RESET(intl)}
        </Button>}
        <div className={styles['loading-body']} style={{ marginTop: eventCenter === 'eventCenter' && -12 }}>
          <Loading visible={loading}>
            {hiddenTab ? (
              <IntervalCard
                dataSource={dataSource}
                queryHistoryMetric={queryHistoryMetric}
                disabled={!ahasProEnable}
                handleQueryMetric={handleQueryMetric}
                radioValue={radioValue}
                changeRadioValue={changeRadioValue}
                datePickerView={datePickerView}
                typeCharts={typeCharts}
                handleDatePickerView={handleDatePickerView}
                handleDatePickerHidden={handleDatePickerHidden}
                startTime={startTime}
                endTime={endTime}
                showResetBtn={showResetBtn}
                tabIdx={tabIdx}
              />
            ) : (
              <Tab
                shape={'wrapped'}
                activeKey={tabIdx}
                onClick={handleTabChange}
              >
                <Tab.Item title={intl('ahas_sentinel.systemGuard.FuseRules.IntervalVew')} key={0}>
                  <IntervalCard
                    dataSource={dataSource}
                    queryHistoryMetric={queryHistoryMetric}
                    disabled={!ahasProEnable}
                    handleQueryMetric={handleQueryMetric}
                    typeCharts={typeCharts}
                    radioValue={radioValue}
                    changeRadioValue={changeRadioValue}
                    datePickerView={datePickerView}
                    handleDatePickerView={handleDatePickerView}
                    handleDatePickerHidden={handleDatePickerHidden}
                    startTime={startTime}
                    endTime={endTime}
                    showResetBtn={showResetBtn}
                    tabIdx={tabIdx}
                    dataQpsDeta={dataQpsDeta}
                    isInterface={isInterface}
                  />
                </Tab.Item>
                <Tab.Item title={intl('ahas_sentinel.systemGuard.FuseRules.TimeComparison')} key={1} disabled={!ahasProEnable}>
                  <ComparedCard
                    dataSource={dataSource}
                    queryHistoryMetric={queryHistoryMetric}
                    disabled={!ahasProEnable}
                    handleQueryMetric={handleQueryMetric}
                    typeCharts={typeCharts}
                    radioYdValue={radioYdValue}
                    changeRadioYdValue={changeRadioYdValue}
                    datePickerYdView={datePickerYdView}
                    handleDatePickerYdView={handleDatePickerYdView}
                    handleDatePickerYdHidden={handleDatePickerYdHidden}
                    showResetBtn={showResetBtn}
                    tabIdx={tabIdx}
                  />
                </Tab.Item>
              </Tab>
            )}
          </Loading>
        </div>
      </Dialog>
    </>
  );
};

export default ChartsDialog;
