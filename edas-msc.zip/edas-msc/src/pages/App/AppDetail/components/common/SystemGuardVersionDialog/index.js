import React, { useEffect, useState } from 'react';
import { useIntl } from '@ali/widget-hooks';
import { Button, Dialog, Grid, Icon } from '@alicloud/console-components';
// import { useDispatch } from '@ali/sre-utils-dva';
const { Row, Col } = Grid;
import {
  ON_OK,
  PROMPT,
} from '../config/constants/flow';
import { compare } from 'utils/util';
import services from 'services';
import Cookie from 'js-cookie';

const SystemGuardVersionDialog = props => {
  // const dispatch = useDispatch();
  const intl = useIntl();
  const { appName } = props;
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const [ visible, setVisible ] = useState(false);
  const [ javaSdk, setJavaSdk ] = useState('');
  const [ javaAgent, setJavaAgent ] = useState('');
  const referVersion = '1.5.0'; // 版本号

  useEffect(() => {
    (async function() {
      const { VersionMap = {} } = await services.GetSentinelClientVersionOfApp({
        params: {
          AppName: appName,
          namespace: 'default',
          RegionId: region || 'cn-hangzhou',
          AhasRegionId: region || 'cn-hangzhou',
        }
      });
      if (VersionMap && JSON.stringify(VersionMap) !== '{}') {
        const { JAVA_SDK = '', JAVA_AGENT = '' } = VersionMap;
        setJavaAgent(JAVA_AGENT);
        setJavaSdk(JAVA_SDK);
        if ((JAVA_SDK && !compare(JAVA_SDK, referVersion)) || (JAVA_AGENT && !compare(JAVA_AGENT, referVersion))) {
          setVisible(true);
        }
      }
    })();
  }, []);

  function onClose() {
    setVisible(false);
  }

  return (
    <div>
      <Dialog
        title={PROMPT(intl)}
        footer={
          <Button type="primary" onClick={onClose}>
            {ON_OK(intl)}
          </Button>
        }
        visible={visible}
        onClose={onClose}
        style={{ width: '450px' }}
      >
        <Row>
          <Col>
            <Icon
              type="prompt"
              style={{
                width: '50px',
                marginRight: '10px',
                color: '#ffce03',
                fontSize: '32px',
              }}
            />
          </Col>
          <Row>
            <Col>
              <p>
                {intl('ahas_sentinel.systemGuard.flowControl.requirements')}
              </p>
              <p>
                {intl('ahas_sentinel.systemGuard.flowControl.AHASSentinel')} &gt;={' '}
                <span style={{ color: '#00c1de' }}>{referVersion}</span>
								&nbsp;&nbsp;{intl('ahas_sentinel.systemGuard.flowControl.or')}&nbsp; {intl('ahas_sentinel.systemGuard.flowControl.AgentVersion')} &gt;={' '}
                <span style={{ color: '#00c1de' }}>{referVersion}</span>
              </p>
              {!!javaSdk && (
                <p className="price-model-item">
                  {intl('ahas_sentinel.systemGuard.flowControl.SDKVersion')}<span style={{ color: 'red' }}>{javaSdk}</span>
                </p>
              )}
              {javaAgent && (
                <p>
                  {intl('ahas_sentinel.systemGuard.flowControl.currentAgentversion')}<span style={{ color: 'red' }}>{javaAgent}</span>
                </p>
              )}
            </Col>
          </Row>
        </Row>
      </Dialog>
    </div>
  );
};

export default SystemGuardVersionDialog;
