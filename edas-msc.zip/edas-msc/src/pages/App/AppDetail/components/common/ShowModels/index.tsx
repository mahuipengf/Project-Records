import React, { FC, useState } from 'react';
import styles from './index.css';
import { setParams } from '@ali/sre-utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';

const ShowModels: FC = () => {
  const dispatch = useDispatch();
  const showModelstype = useSelector(({ flowAppModel }) => flowAppModel.showModelstype);
  const [ mode, setMode ] = useState(Number(!showModelstype));
  // 展示模式改变

  function handleModeChange(val: number) {
    window.goldlog?.record('/ahas-flow.guard_api_details.show_models_type', 'CLK', '', 'GET');
    window.goldlog?.record('/ahas-flow.guard_machine_details.machine_show_type', 'CLK', '', 'GET');

    if (val === 1) {
      setParams('showModels', 'false');
      dispatch.flowAppModel.setShowModelstype(false);
    } else {
      setParams('showModels', 'true');
      dispatch.flowAppModel.setShowModelstype(true);
    }

    setMode(val);
  }

  return (
    <>
      <span
        className={styles.modeBtn}
        style={{
          color: mode === 0 ? '#0070cc' : '#555',
          borderColor: mode === 0 ? '#0070cc' : '#dedede',
          borderRightWidth: mode === 0 ? 1 : 0,
          marginLeft: 16,
        }}
        onClick={() => handleModeChange(0)}
      >
        节点对比
      </span>

      <span
        className={styles.modeBtn}
        style={{
          color: mode === 1 ? '#0070cc' : '#555',
          borderColor: mode === 1 ? '#0070cc' : '#dedede',
          borderLeftWidth: mode === 1 ? 1 : 0,
        }}
        onClick={() => handleModeChange(1)}
      >
        集群统计
      </span>
    </>
  );
};

export default ShowModels;
