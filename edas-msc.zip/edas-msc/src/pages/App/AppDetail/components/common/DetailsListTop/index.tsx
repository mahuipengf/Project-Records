import React, { FC, useEffect, useMemo, useState } from 'react';
import styles from './index.css';
import { Balloon, Input, Loading, Pagination, Select } from '@alicloud/console-components';
import { SORT_TAB } from 'config/constants/flow';
import { getParams, removeParams, setParams } from '@ali/sre-utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';

const Option = Select.Option;

interface ListTopProps {
  resourceType: number;
  detailsType?: string;
  pageType?: string;
  changeNodeShowType?: any;
}

interface IQuotaList {
  value: number;
  idx: number;
}

interface IApiActived {
  resource: string;
  favorite: boolean;
  hasRule: boolean;
  type: number;
  passedQps: number;
  blockedQps: number;
  exception: number;
  rt: number;
  quotaList?: Array<IQuotaList>;
}

interface IMachineActived {
  privateIp: string;
  processConfigurationId: string;
  pid: number;
  parentIp: string;
  vpcId: string;
  resource: string;
  quotaList: any;
  hostname: string;
}

const DetailsListTop: FC<ListTopProps> = props => {
  const { resourceType, detailsType, pageType, changeNodeShowType } = props;
  const dispatch = useDispatch();
  const appName = getParams('edasAppId') || getParams('appName');
  const [ sortDefultIndex, setSortDefultIndex ] = useState(0);
  const [ apiTopList, setApiTopList ] = useState([]);
  const [ machineTopList, setMachineTopList ] = useState([]);
  const [ totalCount, setTotalCount ] = useState(0);
  const [ pageIndex, setPageIndext ] = useState(1);
  const [ sortType, setSortType ] = useState(true);
  const [ searchKey, setSearchKey ] = useState('');
  const [ isLoading, setIsLoading ] = useState(true);
  const [ searchState, setSearchState ] = useState<any>(undefined);
  const { backTime } = useSelector(({ flowAppModel }) => flowAppModel.apiShowTime);
  const { activeResourceName: apiActived } = useSelector(({ flowAppModel }) => flowAppModel.apiDetails);
  const { privateIp, pid } = useSelector(({ flowAppModel }) => flowAppModel.machineDetails);
  let lastTime: any = -1;
  const machineActived = `${privateIp}-${pid}`;
  const pageSize = (detailsType === 'api' && apiActived !== '_all') ? 35 : 25;
  const isNginx = sessionStorage.getItem('isNginx') === 'true';
  const trafficType = (pageType === 'guardApp' && resourceType === -1 && !isNginx) ? '1' : '';
  const isCloudNative = getParams('isCloudNative') === 'true' || sessionStorage.getItem('isCloudNative') === 'true';
  const [ nodeShowType, setNodeShowType ] = useState<any>('hostIP');

  useEffect(() => {
    setIsLoading(true);
    detailsType === 'api' ? getApiTopList() : getMachineTopList();
  }, [ pageIndex, sortDefultIndex, sortType, resourceType, searchKey, backTime, detailsType ]);

  // 请求接口Top列表数据
  async function getApiTopList() {
    const endTime = new Date().getTime();
    const { totalCount = 0, metrics: listTopData = [] } = await dispatch.flowAppModel.getSentinelMetricListTopNResourceName({
      AppName: appName,
      PageIndex: pageIndex,
      PageSize: pageSize,
      SearchKey: searchKey,
      OrderBy: sortDefultIndex,
      Desc: sortType,
      AhasTimestamp: backTime || endTime,
      ResourceType: resourceType,
      TrafficType: trafficType,
    });
    if (listTopData.length > 0) {
      listTopData.unshift({
        resource: '_all',
      });
      listTopData.forEach((item: IApiActived) => {
        item.quotaList = [
          {
            value: item.passedQps,
            idx: 0,
          },
          {
            value: item.blockedQps,
            idx: 1,
          },
          {
            value: item.exception,
            idx: 2,
          },
          {
            value: item.rt,
            idx: 4,
          },
        ];
      });
      setTotalCount(totalCount);
      setApiTopList(listTopData);
    } else {
      setTotalCount(0);
      setApiTopList([]);
    }
    setIsLoading(false);
    setSearchState(undefined);
  }

  // 请求机器Top列表数据
  async function getMachineTopList() {
    const endTime = new Date().getTime();
    const { totalCount = 0, macMetrics: machineTopData = [] } = await dispatch.flowAppModel.getSentinelResourceTopNMacs({
      AppName: appName,
      PageIndex: pageIndex,
      PageSize: pageSize,
      OrderBy: sortDefultIndex,
      Desc: sortType,
      AhasTimestamp: backTime || endTime,
      Resource: '__app_summary_metric_resource_name__',
      SearchKey: searchKey,
    });
    if (machineTopData.length > 0) {
      machineTopData.unshift({
        privateIp: '_all',
        pid: -1,
      });
      machineTopData.forEach((item: any) => {
        item.quotaList = [
          {
            value: item.passedQps,
            idx: 0,
          },
          {
            value: item.blockedQps,
            idx: 1,
          },
          {
            value: item.exception,
            idx: 2,
          },
          {
            value: item.rt,
            idx: 4,
          },
        ];
      });
      setTotalCount(totalCount);
      setMachineTopList(machineTopData);
    } else {
      setTotalCount(0);
      setMachineTopList([]);
    }
    setIsLoading(false);
    setSearchState(undefined);
  }


  function handleChangeSortDefultIndex(value: number) {
    setSortDefultIndex(value);
    dispatch.flowAppModel.setSortDesc({
      sortIndex: value,
      descType: sortType,
    });
  }

  function handleChangeSortType() {
    setSortType(!sortType);
    dispatch.flowAppModel.setSortDesc({
      sortIndex: sortDefultIndex,
      descType: !sortType,
    });
  }

  const onChangeNodeShowType = function(value: any) {
    setNodeShowType(value);
    changeNodeShowType(value);
  };

  // 渲染头部排序
  const renderSortHeader = useMemo(() => {
    return (
      <div className={styles.sortContent}>
        <div>
          {isCloudNative ? <span>{detailsType === 'api' ? isCloudNative ? '路由名称' : '接口名称' : '节点名称'}</span> :
            detailsType === 'api' ? '接口名称' : <Select onChange={onChangeNodeShowType} defaultValue={nodeShowType}>
              <Option value="hostName">节点名称</Option>
              <Option value="hostIP">节点IP</Option>
            </Select>}
        </div>
        <div className={styles.sortItem}>
          <ul className={styles.sortList}>
            {renderSortHeaderItem()}
          </ul>
          <i
            onClick={() => handleChangeSortType()}
            className={sortType ? styles.sortIconReverse : styles.sortIconPositive}
          />
        </div>
      </div>
    );
  }, [ sortDefultIndex, sortType ]);

  function renderSortHeaderItem() {
    return (
      SORT_TAB.map((item, index) => {
        return (
          <li
            className={
              item.value === sortDefultIndex ? styles.metriclistsortactive : styles.metriclistsort
            }
            key={index}
            onClick={() => handleChangeSortDefultIndex(item.value)}
          >
            {item.title}
          </li>
        );
      })
    );
  }

  function renderItem(item: any, index: number) {
    return (
      <li
        key={index}
        className={renderApiActived(item.resource)}
        onClick={() => handleChangeSelectApi(item)}
      >
        <Balloon
          trigger={<span>
            {item.resource}
          </span>}
          closable={false}
          align='t'
        >
          {item.resource}
        </Balloon>
        {<ul>
          {item.quotaList.map((list: IQuotaList, index: number) => {
            return (
              <li
                key={index}
                className={
                  sortDefultIndex === list.idx ? styles.resourceActiveQuota : styles.resourceQuota
                }
              >
                {list.value}
              </li>
            );
          })}
        </ul>}
      </li>
    );
  }

  // 渲染Api Top列表
  const renderSortList = useMemo(() => {
    return (
      <ul className={styles.apiSortbox}>
        {detailsType === 'api' ? (
          <>
            <li
              className={renderApiActived('_all')}
              onClick={() => handleChangeSelectApi(apiTopList[0])}
            >
              <span>
                {isCloudNative ? '全部路由' : '全部接口'}
              </span>
            </li>

            {
              apiTopList.length > 0 ? apiTopList.map((item: any, index) => {
                return item.resource !== '_all' && renderItem(item, index);
              }) : (
                <div className={styles.apiTopListNoData}>暂无数据</div>
              )
            }
          </>
        ) : (
          <>
            {
              machineTopList.length > 0 ? machineTopList.map((item: IMachineActived, index) => {
                return (
                  <li
                    key={index}
                    className={renderMachineActived(`${item.privateIp}-${item.pid}`)}
                    onClick={() => handleChangeSelectMachine(item)}
                  >
                    <div className={styles.machineName}>
                      {`${item.privateIp}-${item.pid}` === '_all--1' ? '全部节点' : renderMachineName(item)}
                    </div>
                    {item.privateIp !== '_all' && <ul>
                      {item.quotaList.map((list: IQuotaList, index: number) => {
                        return (
                          <li
                            key={index}
                            className={
                              sortDefultIndex === list.idx ? styles.resourceActiveQuota : styles.resourceQuota
                            }
                          >
                            {list.value}
                          </li>
                        );
                      })}
                    </ul>}
                  </li>
                );
              }) : (
                <div className={styles.apiTopListNoData}>暂无数据</div>
              )
            }
          </>
        )}
      </ul>
    );
  }, [ apiTopList, machineTopList, apiActived, machineActived, nodeShowType ]);

  // 渲染排序分页
  function renderSortPagination() {
    return (
      <Pagination
        className={styles.sortPagination}
        onChange= {handlePageIndexChange}
        current={pageIndex}
        total={totalCount}
        pageSize={pageSize}
        showJump={false}
        shape="arrow-only"
        type="simple"
      />
    );
  }

  // 将所有机器名构建进数组
  function initMachineAllName() {
    const allMachineName:Array<string> = [];

    !!machineTopList && machineTopList?.forEach((item: IMachineActived) => {
      item.privateIp !== '_all' && allMachineName.push(item.privateIp);
    });

    return allMachineName;
  }

  // 累加出相同ip出现次数
  function countOccurences(ary: Array<string>, value: string) {
    return ary.reduce((a, v) => (v === value ? a + 1 : a + 0), 0);
  }

  // 根据相同ip出现次数选择是否展示pid
  function renderMachineName(data: IMachineActived) {
    const allMachineName = initMachineAllName();
    if (countOccurences(allMachineName, data.privateIp) > 1) {
      return (
        <>
          <div>
            {data.privateIp}
          </div>
          <div className={styles.pidNum}>
            进程号:{data.pid}
          </div>
        </>
      );
    }

    return (
      <div>
        <Balloon
          trigger={
            <div className={styles.textEllipsis}>
              {nodeShowType === 'hostName' ? data.hostname : data.privateIp}
            </div>
          }
          closable={false}
          align={'t'}
        >
          {nodeShowType === 'hostName' ? data.hostname : data.privateIp}
        </Balloon>
        {/* {nodeShowType === 'hostName' ? data.hostname : data.privateIp} */}
      </div>
    );
  }

  // 渲染选中api名称
  function renderApiActived(resourceName: string) {
    return resourceName === apiActived ? styles.apiSortListActive : styles.apiSortList;
  }

  // 渲染选中机器名称
  function renderMachineActived(resourceName: string) {
    return resourceName === machineActived ? styles.apiSortListActive : styles.apiSortList;
  }

  // 切换api
  function handleChangeSelectApi(value: IApiActived) {
    const { resource: activeResourceName, favorite, hasRule, type } = value;
    setParams('activeResourceName', activeResourceName);
    dispatch.flowAppModel.setApiActiveName({ activeResourceName, favorite, hasRule, type });
    dispatch.flowAppModel.setExceptionTime(0);
  }

  // 切换机器
  function handleChangeSelectMachine(value: IMachineActived) {
    const { privateIp, pid, processConfigurationId, parentIp, vpcId, resource } = value;
    setParams('privateIp', privateIp);
    setParams('pid', pid);
    if (privateIp === '_all') {
      removeParams('processId');
      removeParams('parentIp');
      removeParams('vpcId');
      removeParams('resource');
    } else {
      setParams('processId', processConfigurationId);
      setParams('parentIp', parentIp);
      setParams('vpcId', vpcId);
      setParams('resource', resource);
    }
    removeParams('detailsTabIdx');
    removeParams('detailsChildTabIdx');
    removeParams('detailsJvmChildTabIdx');
    dispatch.flowAppModel.setMachineActiveName({ privateIp, parentIp, pid, processConfigurationId, vpcId, resource });
    dispatch.flowAppModel.setExceptionTime(0);
  }

  // 翻页
  function handlePageIndexChange(current: number) {
    setPageIndext(current);
  }

  // 搜索
  function handleSearchKeyChange(value: string) {
    clearTimeout(lastTime);
    lastTime = setTimeout(() => {
      setSearchKey(value);
      setSearchState('loading');
    }, 300);
  }

  const inputTips = detailsType === 'api' ? '请输入资源名称' : '请输入节点名称';

  return (
    <div className={styles.content}>
      <Input
        className={styles.searchInput}
        trim
        placeholder={inputTips}
        state={searchState}
        onChange={handleSearchKeyChange}
      />
      {renderSortHeader}
      <Loading
        visible={isLoading}
        className={styles.loadingCover}
      >
        {renderSortList}
      </Loading>
      {!!totalCount && renderSortPagination()}
    </div>
  );
};

export default DetailsListTop;
