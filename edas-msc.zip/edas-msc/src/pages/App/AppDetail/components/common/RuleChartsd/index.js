import DataSet from '@antv/data-set';
import React, { FC, useEffect, useState } from 'react';
import moment from 'moment';
// import { Button, Dialog } from '@alicloud/console-components';
import { intlNumberUnit } from '@ali/sre-utils';
const { DataView } = DataSet;
const RuleChartsd = props => {
  const [ component, setComponent ] = useState<any>(null);
  const { dataSource } = props;
  // bizchart 将近2MB，按需加载之
  useEffect(() => {
    (async function() {
      const bizcharts = await import(/* webpackChunkName: "bizcharts" */'bizcharts'/* webpackPrefetch: true */);
      setComponent(bizcharts);
    })();
  }, []);
  function flowFormat(size) {
    if (!size) { return '0B'; }

    const num = 1024.00; // byte

    if (size < num) { return size + 'B'; }
    if (size < Math.pow(num, 2)) { return (size / num).toFixed(2) + 'KB'; } // kb
    if (size < Math.pow(num, 3)) { return (size / Math.pow(num, 2)).toFixed(2) + 'MB'; } // M
    if (size < Math.pow(num, 4)) { return (size / Math.pow(num, 3)).toFixed(2) + 'GB'; } // G
    return (size / Math.pow(num, 4)).toFixed(2) + 'TV'; // T
  }
  if (!component) {
    return null;
  }

  const renderCols = {
    time: {
      alias: '时间',
      type: 'time',
      mask: 'HH:mm',
      tickCount: 5,
    },
    count: {
      tickCount: 5,
      formatter: (val) => {
        return intlNumberUnit(Number(val).toFixed(2), 1);
      },
    },
  };
  const { Chart, Geom, Axis, Tooltip, Legend } = component;
  const dv = new DataView();
  dv.source(dataSource);
  return (
    <div >
      <Chart
        // key={chartsFilter.length}
        height={250}
        data={dv}
        scale={renderCols}
        padding="auto"
        forceFit
      >
        <Axis
          name="time"
          line={{
            stroke: '#C4CFF3',
          }}
          tickLine={{
            stroke: '#C4CFF3',
          }}
          label={{
            textStyle: {
              fill: '#555',
            },
          }}
        />
        <Axis
          name="count"
          grid={null}
          label={{
            textStyle: {
              fill: '#555',
            },
            // formatter: (val: string) => {
            //   return intlNumberUnit(Number(val).toFixed(2), 1);
            // },
          }}
        />
        <Legend
          position='bottom-center'
        />
        <Tooltip />
        <Legend textStyle={{
          fill: '#9b9b9b', // 文本的颜色
        }} />
        <Geom
          type="line"
          position="time*count"
          color={[ 'type', [ '#0070cc', '#FECB00', '#FF7D51', '#826AF9', '#5B6E90' ]]}
          tooltip={[ 'time*count*type*name', (time, count, type, name) => {
            if (name === 'network') {
              return {
                name: type,
                title: moment(new Date(time)).format('YYYY-MM-DD HH:mm:ss'),
                value: flowFormat(count),
              };
            }
            return {
              name: type,
              title: moment(new Date(time)).format('YYYY-MM-DD HH:mm:ss'),
              value: count,
            };
          } ]}
        />
      </Chart>
    </div>
  );
};

export default RuleChartsd;
