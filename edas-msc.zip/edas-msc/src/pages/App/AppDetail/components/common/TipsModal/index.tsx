import React, { ReactNode } from 'react';
import styles from './index.css';
import { Button } from '@alicloud/console-components';

interface ITipsModalProps {
  handleTipsDialog: (value: string) => void;
  alertMessage: ReactNode;
  showUpgradeBtn: boolean;
}

const TipsModal = (props: ITipsModalProps) => {
  const { handleTipsDialog, alertMessage, showUpgradeBtn } = props;

  function footer() {
    return (
      <div className={styles.messagesFooter}>
        {showUpgradeBtn && <span className={styles.onOK}>
          <Button
            type="primary"
            onClick={() => handleTipsDialog('SystemGuard')}
            component={'a'}
            href= { window.ALIYUN_CONSOLE_CONFIG?.CHANNEL_LINKS?.post_buy ? window.ALIYUN_CONSOLE_CONFIG.CHANNEL_LINKS.post_buy : 'https://common-buy.aliyun.com/?commodityCode=ahas_post#/buy'}
            target='_black'
          >
            升级到专业版
          </Button>
        </span>}
        <span className={styles.onOK}>
          <Button
            type="normal"
            onClick={() => handleTipsDialog('SystemGuard')}
          >
            {showUpgradeBtn ? '我再考虑一下' : '确定'}
          </Button>
        </span>
      </div>
    );
  }

  return (
    <div>
      <div className={styles.messagesText}>{alertMessage}</div>
      {footer()}
    </div>
  );
};

export default TipsModal;
