import React, { useEffect, useImperativeHandle, useState } from 'react';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.css';
import {
  Balloon,
  Button,
  Field,
  Form,
  Icon,
  Input,
  Message,
  NumberPicker,
  Radio,
  Select,
  Switch,
} from '@alicloud/console-components';
import {
  CANCEL,
  CAVEAT,
  CE_SUCCESS,
  GREATER_THAN_0,
  HIDE_AD_OP,
  INTER_NAME,
  MINUTE,
  NEW,
  NEW_AND_SEE,
  NOT_NULL,
  PLEASE_NAME,
  PLEASE_NUMBER,
  SAVE,
  SAVE_SUCCESS,
  SECOND,
  SEE_DETAILS,
  SHOW_AD_OP,
  THRESSHOULD_TYPE,
  WHETHER_TO_OPEN,
} from '../config/constants/flow/index';
import { FUSE_RULE } from '../config/constants/flow/index';
import { compare } from '../../../../../../utils/util';
import { pushUrl } from '@ali/sre-utils';
import { getParams } from 'utils';
// import { useDispatch } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';
import services from 'services';
import { useGlobalState } from '@ali/widget-hooks';
import Cookie from 'js-cookie';

const Option = Select.Option;

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};

const SystemGuardLevelRules = props => {
  const intl = useIntl();
  const history = useHistory();
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const field = Field.useField();
  // const disPatch = useDispatch();
  const [ timeType, setTimeType ] = useState('second');
  const [ switchEnableStatus, setSwitchEnableStatus ] = useState(true);
  const [ grade, setGrade ] = useState(0);
  const [ statIntervalMs, setStatIntervalMs ] = useState(20);
  const [ javaSdk, setJavaSdk ] = useState('');
  const [ javaAgent, setJavaAgent ] = useState('');
  const [ version, setVersion ] = useState(false);
  const {
    record,
    onCloseDialog,
    resource,
    handleRuleCheck,
    upDataList,
    noRederict = false,
    selectModel,
    selectModelEnable,
    isProtection,
    wrapRef,
    isDefaultFuse = false,
  } = props;
  const [ advShow, setAdvShow ] = useState(true);
  const [ restore, setRestore ] = useState(0);
  const fixedSDKVersion = '1.6.0';
  const fixedAgentVersion = '1.7.5';
  const [ searchValues, setSearchValues ] = useGlobalState('searchValues');

  /* 将子组件的方法暴露给父组件 */
  useImperativeHandle(wrapRef, () => ({
    handleCheckRuleInput,
  }));

  useEffect(() => {
    // 版本号
    (async function() {
      const {
        VersionMap = {},
      } = await services.GetSentinelClientVersionOfApp({
        params: {
          AppName: appName,
          RegionId: region,
          AhasRegionId: region,
          namespace: 'default',
          Namespace: 'default',
          NameSpace: 'default',
        }
      });
      if (VersionMap && JSON.stringify(VersionMap) !== '{}') {
        const { JAVA_SDK = '', JAVA_AGENT = '' } = VersionMap;
        setJavaAgent(JAVA_AGENT);
        setJavaSdk(JAVA_SDK);
        if ((JAVA_SDK && !compare(JAVA_SDK, fixedSDKVersion)) || (JAVA_AGENT && !compare(JAVA_AGENT, fixedAgentVersion))) {
          setVersion(true);
        }
      }
    })();
  }, []);

  useEffect(() => {
    if (record) {
      field.setValue('id', record.id);
      setGrade(record.grade);
      setRestore(1);
      if (
        record.statIntervalMs % 60000 !== 0 ||
        (record.statIntervalMs > 0 && record.statIntervalMs < 60000)
      ) {
        const statIntervalMs = record.statIntervalMs / 1000;
        setStatIntervalMs(statIntervalMs);
        field.setValue('statIntervalMs', statIntervalMs);
        setTimeType('second');
      } else if (record.statIntervalMs >= 60000) {
        const statIntervalMs = record.statIntervalMs / (1000 * 60);
        setStatIntervalMs(statIntervalMs);
        field.setValue('statIntervalMs', statIntervalMs);
        setTimeType('minute');
      }
      setSwitchEnableStatus(record.enable);

      if (
        record.halfOpenBaseAmountPerStep === 1 &&
        record.halfOpenRecoveryStepNum === 1
      ) {
        setRestore(0);
      } else {
        setRestore(1);
      }
    } else {
      setRestore(0);
      setSwitchEnableStatus(selectModelEnable || false);
    }
  }, []);

  // 统计窗口时长
  function onTimeTypeChange(value) {
    setTimeType(value);
  }

  // 是否开启
  function handleClickSwitch(value) {
    setSwitchEnableStatus(value);
  }

  function toLowerCase(jsonObj) {
    if (typeof (jsonObj) === 'object') {
      for (const key in jsonObj) {
        jsonObj[key.substring(0, 1).toLowerCase() + key.substring(1)] = jsonObj[key];
        delete (jsonObj[key]);
      }
      return jsonObj;
    }
  }

  // 表单提交校验
  function handleCheckRuleInput() {
    const isAddRule = !record;
    return handleAddRule(isAddRule);
  }

  // 表单提交
  function handleAddRule(isAddRule, viev) {
    let isValid = false;
    const fieldNeedValidate = [
      'countNum',
      'minRequestAmount',
      'statIntervalMs',
      'timeWindow',
      'count',
    ];

    if (!isDefaultFuse) {
      fieldNeedValidate.push('resource');
    }

    if (grade === 0) {
      fieldNeedValidate.push('slowRatioThreshold');
    }

    if (grade === 1) {
      fieldNeedValidate.push('countAbnormal');
    }

    if (restore === 1) {
      fieldNeedValidate.push('halfOpenBaseAmountPerStep');
      fieldNeedValidate.push('halfOpenRecoveryStepNum');
    }

    field.validate(fieldNeedValidate, (errors, value) => {
      if (!errors) {
        let timeMs = value.statIntervalMs;
        if (timeType === 'second') {
          timeMs = timeMs * 1000;
        } else {
          timeMs = timeMs * 1000 * 60;
        }

        if (timeMs >= 7200000) {
          Message.warning(intl('ahas_sentinel.systemGuard.FuseRules.duration'));
          return;
        }

        const submitData = {
          Id: isProtection && !isAddRule && field.getValue('id'),
          AppName: appName,
          Resource: value.resource || resource,
          Grade: grade,
          Count: grade ? value.countAbnormal / 100 : value.count,
          TimeWindow: value.timeWindow || 10,
          SlowRatioThreshold: grade ? 0.8 : value.slowRatioThreshold / 100,
          StatIntervalMs: timeMs,
          MinRequestAmount: value.minRequestAmount || 10,
          Enable: switchEnableStatus,
          HalfOpenRecoveryStepNum: restore
            ? Number(value.halfOpenRecoveryStepNum)
            : 1,
          HalfOpenBaseAmountPerStep: restore
            ? Number(value.halfOpenBaseAmountPerStep)
            : 1,
          Model: selectModel || 0,
        };

        if (isProtection) {
          // disPatch.flowAppModel.setFlowRuleOptionsDataStepTwo(JSON.stringify(toLowerCase(submitData)));
          setSearchValues({...searchValues, flowRuleOptionsDataStepTwo: JSON.stringify(toLowerCase(submitData))})
          isValid = true;
        } else {
          fetchUpdateData(submitData, isAddRule, viev);
        }
      }
    });
    return isValid;
  }

  async function fetchUpdateData(
    submitData,
    isAddRule,
    viev,
  ) {
    let resData = {};
    if (isAddRule) {
      if (isDefaultFuse) {
        resData = await services.CreateSentinelDefaultCircuitBreakerRule({
          ...submitData,
        });
      } else {
        resData = await services.SentinelDegradeRuleNew({
          ...submitData,
        });
      }
    } else {
      submitData.id = field.getValue('id');
      if (isDefaultFuse) {
        resData = await services.EditSentinelDefaultCircuitBreakerRule({
          ...submitData,
        });
      } else {
        resData = await services.SentinelDegradeRuleEdit({
          ...submitData,
        });
      }
    }

    const {
      Success = false,
      Code,
      Message: msg = '',
    } = resData;

    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msg);
      onCloseDialog && onCloseDialog('0');
    } else if (Code === 'sentinel.rule.defaultCircuitBreaker.duplicate') {
      Message.warning('同种类型熔断规则只可配置一条');
    } else if (Success) {
      onCloseDialog && onCloseDialog('1');
      isAddRule && viev && addAndViewRules();
      Message.success(isAddRule ? CE_SUCCESS(intl) : SAVE_SUCCESS(intl));
      isDefaultFuse && upDataList && upDataList();
    } else {
      Message.error(msg);
    }
  }

  // 跳转
  function addAndViewRules() {
    pushUrl(history, '/flowProtection/systemGuard/setRules', {
      appName,
      activeType: 'downGrade',
    });
  }

  // 阔值类型
  function radioGrade(value) {
    setGrade(Number(value));
  }

  // 高级选项显示/隐藏
  function handleAdvShow() {
    setAdvShow(!advShow);
  }

  // 初始值校验
  function handleRestore(value) {
    setRestore(Number(value));
    if (
      Number(value) &&
      record && record.halfOpenBaseAmountPerStep === 1 &&
      record.halfOpenRecoveryStepNum === 1
    ) {
      field.setValue('halfOpenBaseAmountPerStep', 5);
      field.setValue('halfOpenRecoveryStepNum', 1);
    }
  }

  const hintLayout = (
    <Icon
      type="prompt"
      size="small"
      style={{ marginLeft: '5px', color: 'rgb(136, 136, 136)' }}
    />
  );
  const { getValue, init } = field;

  return (
    <div className={styles.contentBox}>
      {!isDefaultFuse && !isProtection && <Message style={{ marginBottom: '8px' }} type="notice">
        <span>
          {intl('ahas_sentinel.systemGuard.FuseRules.generally')}
          <a href={FUSE_RULE} target="_block">
            {SEE_DETAILS(intl)}
          </a>
        </span>
      </Message>}
      {isDefaultFuse && <Message style={{ marginBottom: '8px' }} type="warning">
        <span>
          该规则作用于所有资源，但是如果有资源单独配置了熔断规则，那么该默认熔断规则对该资源不生效。
        </span>
      </Message>}
      {version && (
        <Message style={{ marginBottom: '8px' }} type="notice">
          <p>
            {intl('ahas_sentinel.systemGuard.FuseRules.SomeConfiguration')} &gt;{intl('ahas_sentinel.systemGuard.FuseRules.AgentVersion')} &gt;= 1.7.5 才能生效
            {javaSdk && intl('ahas_sentinel.systemGuard.FuseRules.TheCurrentSDK')}
            <span>{javaSdk}</span>
            {javaAgent && intl('ahas_sentinel.systemGuard.FuseRules.TheCurrentAgent')}
            <span>{javaAgent}</span>
          </p>
        </Message>
      )}
      <Form field={field} size={getValue('size')}>
        {!isDefaultFuse && !isProtection && <Form.Item required {...formItemLayout} label={INTER_NAME(intl)}>
          <Input
            placeholder={PLEASE_NAME(intl)}
            trim
            disabled={isProtection ? !isProtection : resource || record ? true : !!record}
            {...init('resource', {
              initValue: resource || (record && record.resource),
              rules: {
                required: true,
                message: NOT_NULL(intl),
              },
            })}
          />
        </Form.Item>}
        <Form.Item required {...formItemLayout} label={intl('ahas_sentinel.systemGuard.FuseRules.StatisticsWindowDuration')}>
          <Input
            style={{ width: 'calc(100% - 100px)', float: 'left' }}
            trim
            placeholder={intl('ahas_sentinel.systemGuard.FuseRules.StatisticsWindowDuration')}
            {...init('statIntervalMs', {
              initValue: field.getValue('statIntervalMs') || statIntervalMs,
              rules: [
                {
                  required: true,
                  message: NOT_NULL(intl),
                },
                {
                  pattern: /^[1-9]\d*$/,
                  message: PLEASE_NUMBER(intl),
                },
              ],
            })}
          />
          <Select
            value={timeType}
            onChange={onTimeTypeChange}
          >
            <Option value="second">{SECOND(intl)}</Option>
            <Option value="minute">{MINUTE(intl)}</Option>
          </Select>
        </Form.Item>

        <Form.Item {...formItemLayout} label={THRESSHOULD_TYPE(intl)}>
          <Radio.Group onChange={radioGrade} value={grade}>
            <Radio id={'rt'} value={0}>
              {intl('ahas_sentinel.systemGuard.FuseRules.SlowCallRati')}
            </Radio>
            <Radio id={'exception'} value={1}>
              {intl('ahas_sentinel.systemGuard.FuseRules.Abnormal')}
            </Radio>
          </Radio.Group>
        </Form.Item>
        {grade === 0 && (
          <Form.Item {...formItemLayout} label={intl('ahas_sentinel.systemGuard.FuseRules.RT')} required>
            <Input
              placeholder={intl('ahas_sentinel.systemGuard.FuseRules.responseTime')}
              addonTextAfter={<span>ms</span>}
              trim
              {...init('count', {
                initValue: record?.count,
                rules: [
                  {
                    required: true,
                    message: NOT_NULL(intl),
                  },
                  {
                    pattern: /^\d+(\.\d+)?$/,
                    message: PLEASE_NUMBER(intl),
                  },
                ],
              })}
            />
          </Form.Item>
        )}

        <Form.Item
          {...formItemLayout}
          required
          label={
            <span>
              {intl('ahas_sentinel.systemGuard.FuseRules.DowngradeThreshold')}
              <Balloon
                className={styles.ballonBackColor}
                align="r"
                type="primary"
                trigger={hintLayout}
                closable
              >
                <div>
                  <p>
                    {intl('ahas_sentinel.systemGuard.FuseRules.representing')}
                  </p>
                </div>
              </Balloon>
            </span>
          }
        >
          {grade ? (
            <Input
              placeholder={intl('ahas_sentinel.systemGuard.FuseRules.representing')}
              addonTextAfter={'%'}
              trim
              {...init('countAbnormal', {
                initValue: (record && Math.floor(record.count * 100)) || 80,
                rules: [
                  {
                    required: true,
                    message: NOT_NULL(intl),
                  },
                  {
                    pattern: /^(\d|[1-9]\d|100)$/,
                    message: intl('ahas_sentinel.systemGuard.FuseRules.ValueRange'),
                  },
                ],
              })}
            />) : (
            <Input
              placeholder={intl('ahas_sentinel.systemGuard.FuseRules.representing')}
              addonTextAfter={'%'}
              trim
              {...init('slowRatioThreshold', {
                initValue: (record && Math.floor(record.slowRatioThreshold * 100)) || 80,
                rules: [
                  {
                    required: true,
                    message: NOT_NULL(intl),
                  },
                  {
                    pattern: /^(\d|[1-9]\d|100)$/,
                    message: intl('ahas_sentinel.systemGuard.FuseRules.ValueRange'),
                  },
                ],
              })}
            />
          )}

          {(grade === 1 && field.getValue('count') !== '' && Number(field.getValue('count')) === 0) || (grade === 0 && field.getValue('slowRatioThreshold') !== '' && Number(field.getValue('slowRatioThreshold')) === 0) && <div className={styles.recommendBox}>
            <div><span style={{ color: 'red' }}>{CAVEAT(intl)}</span>{intl('ahas_sentinel.systemGuard.FuseRules.risk')}</div>
          </div>}
        </Form.Item>

        <Form.Item required {...formItemLayout} label={intl('ahas_sentinel.systemGuard.FuseRules.FusingTime')}>
          <NumberPicker
            type="inline"
            {...init('timeWindow', {
              initValue: (record && record.timeWindow) || 10,
              rules: [
                {
                  required: true,
                  message: NOT_NULL(intl),
                },
                {
                  pattern: /^[1-9]\d*$/,
                  message: intl('ahas_sentinel.systemGuard.FuseRules.greaterThan'),
                },
              ],
            })}
          />
          <span style={{ marginLeft: '20px' }}>{SECOND(intl)}</span>
          <p className={styles.bgColor} style={{ marginTop: '8px' }}>
            {intl('ahas_sentinel.systemGuard.FuseRules.quickly')}
          </p>
        </Form.Item>

        <Form.Item {...formItemLayout} label={WHETHER_TO_OPEN(intl)}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <Switch
              checked={selectModelEnable ? switchEnableStatus : false}
              onChange={handleClickSwitch}
              style={{ marginTop: '3px' }}
              disabled={!!record?.id || !selectModelEnable}
            />
            <span className={styles.to_open} style={{ margin: '5px 0 0 10px' }}>
              {switchEnableStatus
                ? intl('ahas_sentinel.systemGuard.flowControl.ruleIsOpened')
                : intl('ahas_sentinel.systemGuard.FuseRules.ruleIsClosed')}
            </span>
          </div>
        </Form.Item>

        {!advShow && (
          <Form.Item
            {...formItemLayout}
            required
            label={
              <span>
                {intl('ahas_sentinel.systemGuard.FuseRules.Minimum')}
                <Balloon
                  className={styles.ballonBackColor}
                  align="r"
                  type="primary"
                  trigger={hintLayout}
                  closable
                >
                  <div>
                    <p>
                      {intl('ahas_sentinel.systemGuard.FuseRules.trigger')}
                    </p>
                  </div>
                </Balloon>
              </span>
            }
          >
            <Input
              placeholder={intl('ahas_sentinel.systemGuard.FuseRules.Minimum')}
              trim
              {...init('minRequestAmount', {
                initValue: (record && record.minRequestAmount) || 10,
                rules: [
                  {
                    required: true,
                    message: NOT_NULL(intl),
                  },
                  {
                    pattern: /^\+?[1-9]\d*$/,
                    message: PLEASE_NUMBER(intl),
                  },
                ],
              })}
            />
          </Form.Item>
        )}

        {!advShow && (
          <div>
            <Form.Item
              {...formItemLayout}
              label={
                <span>
                  {intl('ahas_sentinel.systemGuard.FuseRules.strategy')}
                  <Balloon
                    className={styles.ballonBackColor}
                    align="r"
                    type="primary"
                    trigger={hintLayout}
                    closable
                  >
                    <div>
                      <p>
                        {intl('ahas_sentinel.systemGuard.FuseRules.expectations')}
                      </p>
                      <p>
                        {intl('ahas_sentinel.systemGuard.FuseRules.gradually')}
                      </p>
                    </div>
                  </Balloon>
                </span>
              }
            >
              <Radio.Group onChange={handleRestore} value={restore}>
                <Radio id={'single'} value={0}>
                  {intl('ahas_sentinel.systemGuard.FuseRules.SingleProbeRecovery')}
                </Radio>
                <Radio id={'progressive'} value={1}>
                  {intl('ahas_sentinel.systemGuard.FuseRules.ProgressiveRecovery')}
                </Radio>
              </Radio.Group>
            </Form.Item>

            {restore === 1 && (
              <Form.Item {...formItemLayout} label={intl('ahas_sentinel.systemGuard.FuseRules.NumberOfRecoveryStages')} required>
                <Input
                  style={{ width: '200px' }}
                  trim
                  placeholder={GREATER_THAN_0(intl)}
                  {...init('halfOpenRecoveryStepNum', {
                    initValue: (record && record.halfOpenRecoveryStepNum) || 1,
                    rules: [
                      {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                      {
                        pattern: /^[1-9]\d*$/,
                        message: GREATER_THAN_0(intl),
                      },
                    ],
                  })}
                />
              </Form.Item>
            )}

            {restore === 1 && (
              <Form.Item
                {...formItemLayout}
                label={intl('ahas_sentinel.systemGuard.FuseRules.Minimumstep')}
                required
              >
                <Input
                  style={{ width: '200px' }}
                  trim
                  placeholder={GREATER_THAN_0(intl)}
                  {...init('halfOpenBaseAmountPerStep', {
                    initValue:
                      (record && record.halfOpenBaseAmountPerStep) || 5,
                    rules: [
                      {
                        required: true,
                        message: NOT_NULL(intl),
                      },
                      {
                        pattern: /^[1-9]\d*$/,
                        message: GREATER_THAN_0(intl),
                      },
                    ],
                  })}
                />
              </Form.Item>
            )}
          </div>
        )}
        <div>
          <div className={styles.advanced} onClick={handleAdvShow}>
            {advShow ? (
              <i className={'iconfont icon-xiangxiazhankai'}></i>
            ) : (
              <i className={'iconfont icon-xiangshangshouqi'}></i>
            )}
            <a style={{ marginLeft: 8 }}>
              {advShow ? SHOW_AD_OP(intl) : HIDE_AD_OP(intl)}
            </a>
          </div>
          {!isProtection && <div style={{ float: 'right', marginBottom: '16px' }}>
            {record === undefined ? (
              <span>
                {noRederict && (
                  <Form.Submit
                    type="primary"
                    onClick={() => {
                      handleAddRule(true, 'viev');
                    }}
                  >
                    {NEW_AND_SEE(intl)}
                  </Form.Submit>
                )}
                <Form.Submit
                  style={{ marginLeft: '8px' }}
                  type="primary"
                  onClick={() => {
                    handleAddRule(true);
                  }}
                >
                  {NEW(intl)}
                </Form.Submit>
              </span>
            ) : (
              <Form.Submit
                type="primary"
                onClick={() => {
                  handleAddRule(false);
                }}
              >
                {SAVE(intl)}
              </Form.Submit>
            )}
            <Button
              style={{ marginLeft: '8px' }}
              onClick={() => {
                onCloseDialog && onCloseDialog('0');
              }}
            >
              {CANCEL(intl)}
            </Button>
          </div>}
        </div>
      </Form>
      {/* {footer} */}
    </div>
  );
};

export default SystemGuardLevelRules;
