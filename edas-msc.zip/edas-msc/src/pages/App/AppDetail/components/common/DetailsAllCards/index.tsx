import OverviewAllCharts from './OverviewAllCharts';
import React, { FC, useEffect, useMemo, useState } from 'react';
import styles from './index.css';
import { Loading, Pagination } from '@alicloud/console-components';
import { MACHINE_RESOURCE_ARR } from 'config/constants/flow';
import { getParams } from '@ali/sre-utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';
import { useInterval } from '@ali/sre-utils-hooks';

interface AllCardsProps {
  pageType: string;
  resourceType?: number;
  tabType?: string;
  qpsType?: string;
  nodeShowType?: string;
  isCloudNativeGateway?: boolean;
  routeName?: string;
}

interface IDataSource {
  type: number;
  resource: string;
  hasRule: boolean;
  favorite: boolean;
  processConfigurationId?: string;
}

interface IMachineData {
  privateIp: string;
  processConfigurationId: string;
  pid: number;
  parentIp: string;
  vpcId: string;
  resource: string;
  quotaList: any;
  hostname: string;
}

const DetailsAllCards: FC<AllCardsProps> = props => {
  const { pageType, resourceType, tabType, qpsType, isCloudNativeGateway, routeName, nodeShowType } = props;
  const dispatch = useDispatch();
  const appName = getParams('edasAppId') || getParams('appName');
  const detailsChildTabIdx = Number(getParams('detailsChildTabIdx'));
  const [ topListArr, setTopListArr ] = useState([]);
  const [ totalCount, setTotalCount ] = useState(0);
  const [ pageIndex, setPageIndext ] = useState(1);
  const [ lastTime, setLastTime ] = useState(0);
  const [ isLoading, setIsLoading ] = useState(true);
  const { backTime } = useSelector(({ flowAppModel }) => flowAppModel.apiShowTime);
  const { sortIndex, descType } = useSelector(({ flowAppModel }) => flowAppModel.sortDesc);
  const { fullScreenApi, fullScreenMac } = useSelector(({ flowAppModel }) => flowAppModel.fullScreen);
  const fullScreen = fullScreenApi || fullScreenMac;
  const pageSizeCount = fullScreen ? 12 : 6;
  const isNginx = sessionStorage.getItem('isNginx') === 'true';
  const trafficType = (tabType === 'guardApp' && Number(resourceType) === -1 && !isNginx) ? '1' : '';

  useEffect(() => {
    setIsLoading(true);
    setLastTime(1);
    pageType === 'api' ? getApiTopList() : getMacTopList();
  }, [ resourceType, pageIndex, backTime, sortIndex, descType, fullScreenApi, fullScreenMac, detailsChildTabIdx, nodeShowType ]);

  useInterval(() => {
    // 轮询请求接口charts数据
    pageType === 'api' ? getApiTopList() : getMacTopList();
    setLastTime(lastTime + 1);
  }, 10000);

  // 请求全部接口
  async function getApiTopList() {
    const endTime = new Date().getTime();
    const { totalCount: totalCountNum = 0, metrics: listTopData = [] } = await dispatch.flowAppModel.getSentinelMetricListTopNResourceName({
      AppName: appName,
      PageIndex: 1,
      PageSize: pageSizeCount,
      SearchKey: routeName || '',
      OrderBy: sortIndex,
      Desc: descType,
      AhasTimestamp: backTime || endTime,
      ResourceType: Number(resourceType),
      TrafficType: trafficType,
    });
    if (listTopData.length > 0) {
      setTotalCount(totalCountNum);
      setTopListArr(listTopData);
    } else {
      setTotalCount(0);
      setTopListArr([]);
    }
    setIsLoading(false);
  }

  // 请求全部机器
  async function getMacTopList() {
    const endTime = new Date().getTime();
    const { totalCount: totalCountNum = 0, macMetrics: listTopData = [] } = await dispatch.flowAppModel.getSentinelResourceTopNMacs({
      AppName: appName,
      PageIndex: 1,
      PageSize: pageSizeCount,
      SearchKey: '',
      OrderBy: sortIndex,
      Desc: descType,
      AhasTimestamp: backTime || endTime,
      Resource: MACHINE_RESOURCE_ARR[detailsChildTabIdx] || '__app_summary_metric_resource_name__',
    });
    if (listTopData.length > 0) {
      setTotalCount(totalCountNum);
      setTopListArr(listTopData);
    } else {
      setTotalCount(0);
      setTopListArr([]);
    }
    setIsLoading(false);
  }

  // 渲染api卡片
  const renderApiCards = useMemo(() => {
    const emptyElementName = fullScreen ? styles.emptyElementFull : styles.emptyElement;
    const apiTopListNone = fullScreen ? styles.apiTopListNoneFull : styles.apiTopListNone;
    return (
      topListArr.length > 0 ? <>
        {
          topListArr.map((item: IDataSource) => {
            return (
              <OverviewAllCharts
                key={pageType === 'api' ? item.resource : item.processConfigurationId}
                lastTime={lastTime}
                dataSource={item}
                chartDialogtitle={pageType === 'api' ? 'api' : 'machine'}
                renderMachineName={renderMachineName}
                RefuseQps={'show'}
                qpsType={qpsType}
                isCloudNativeGateway={isCloudNativeGateway}
              />
            );
          })
        }
        <span className={emptyElementName}></span>
        <span className={emptyElementName}></span>
        <span className={emptyElementName}></span>
      </> : <div className={apiTopListNone}>暂无数据，请确认应用上是否有请求流量</div>
    );
  }, [ topListArr, lastTime, resourceType, nodeShowType ]);

  function initMachineAllName() {
    const allMachineName:Array<string> = [];

    !!topListArr && topListArr?.forEach((item: IMachineData) => {
      item.privateIp !== '_all' && allMachineName.push(item.privateIp);
    });

    return allMachineName;
  }

  function countOccurences(ary: Array<string>, value: string) {
    return ary.reduce((a, v) => (v === value ? a + 1 : a + 0), 0);
  }

  function renderMachineName(data: IMachineData) {
    const allMachineName = initMachineAllName();
    if (countOccurences(allMachineName, data.privateIp) > 1) {
      return (
        <div className={styles.machineTitle}>
          <span>
            {data.privateIp}
          </span>
          <span className={styles.pidNum}>
            进程号:{data.pid}
          </span>
        </div>
      );
    }

    return (
      <div className={styles.textEllipsis}>
        {nodeShowType === 'hostName' ? data.hostname : data.privateIp}
      </div>
    );
  }

  // 翻页
  function handlePageIndexChange(current: number) {
    setPageIndext(current);
  }

  // 渲染排序分页
  function renderSortPagination() {
    return (
      <Pagination
        className={fullScreen ? styles.sortPaginationFull : styles.sortPagination}
        onChange= {handlePageIndexChange}
        current={pageIndex}
        total={totalCount}
        pageSize={pageSizeCount}
        shape="normal"
        type="normal"
        totalRender={totalCount => `共有${totalCount}条`}
      />
    );
  }

  return (
    <div className={styles.content}>
      <Loading
        visible={isLoading}
        className={styles.loadingCover}
      >
        {renderApiCards}
      </Loading>
      {!isCloudNativeGateway && !!totalCount && renderSortPagination()}
    </div>
  );
};

export default DetailsAllCards;
