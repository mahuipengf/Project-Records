import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Message, Radio, Field, NumberPicker, Switch, Checkbox, Balloon, Icon, TreeSelect } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { NNAME_PATTERN } from 'constants';
import SlidePanel from 'components/SlidePanel';
import { get, join, split } from 'lodash';
import IconBack from 'components/IconBack';
import AppSelector from 'containers/AppSelector';
import TagSelector from '../../FaultInjection/TabSelector';

const RetryEdit = (props) => {
  const [loading, setLoading] = useState(false);
  const [showImg, setShowImg] = useState(false);
  const { value, visible, onClose, onOk } = props;
  const intl = useIntl();
  const field = Field.useField();
  const { init, validate, getValue, setValues, reset, setValue } = field;
  useEffect(() => {
    const Name = get(value, 'Name', '');
    const Region = get(value, 'Region', '');
    if (value.Id) {
      const Tag = get(value, 'Tag');
      const SourceType = get(value, 'RouteRules[0].sourceType');
      const SourceAppId = SourceType === 'all' ? [] : get(value, 'RouteRules[0].sourceAppId');
      const SourceAppName = SourceType === 'all' ? [] : get(value, 'RouteRules[0].sourceAppName');
      const Attempts = get(value, 'RouteRules[0].attempts');
      const PerTryTimeout = get(value, 'RouteRules[0].perTryTimeout');
      const RetryOn = split(get(value, 'RouteRules[0].retryOn'), ',');
      const Protocol = get(value, 'Protocol');
      const Enable = get(value, 'Enable');
      setValues({
        Name,
        Region,
        Tag,
        SourceType,
        SourceAppId,
        SourceAppName,
        Attempts,
        RetryOn,
        PerTryTimeout,
        Protocol,
        Namespaces: { regionId: Region },
        Enable,
      });
    } else {
      setValues({
        Region,
        Namespaces: { regionId: Region },
      });
    }
  }, [value]);
  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const params = {
        Protocol: 'istio',
        AppId: value.AppId,
        Id: value.Id,
        Region: values.Region,
        Name: values.Name,
        Enable: values.Enable,
        Tag: values.Tag,
        Rules: {
          SourceType: values.SourceType, // "all" or "specific"
          SourceAppName: values.SourceType === 'all' ? ['*'] : values.SourceAppName,
          sourceAppId: values.SourceType === 'all' ? ['*'] : values.SourceAppId,
          PerTryTimeout: values.PerTryTimeout,
          Attempts: values.Attempts,
          RetryOn: join(values.RetryOn, ','),
        }
      };
      editPoliry(params);
    });
  };

  // 创建
  const editPoliry = async (params) => {
    setLoading(true);
    params.Id
      ? await services.UpdateRetryRule({
        params,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      })
      : await services.CreateRetryRule({
        params,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      });
    setLoading(false);
    onOk();
    reset();
    Message.success(intl(value.Id ? 'widget.common.update_successful' : 'widget.common.add_successful'));
  };

  const handleClose = () => {
    setLoading(false);
    reset();
    onClose();
  };

  return (
    <SlidePanel
      title={
        <IconBack goBack={onClose}>{intl(value.Id ? 'widget.common.edit' : 'widget.mse.create_retry_rule')}</IconBack>
      }
      processingText={intl('widget.common.ok')}
      isShowing={visible}
      onOk={handleSubmit}
      onClose={handleClose}
      onCancel={handleClose}
      isProcessing={loading}
      width={780}
    >
      <Form field={field}>
        <Form.Item label={intl('widget.authentication.rule_name')} required>
          <Input
            style={{ width: 'calc(100% - 32px)' }}
            maxLength={64}
            showLimitHint
            placeholder={intl('widget.common.name_pattern')}
            {...init('Name', {
              rules: [
                {
                  required: true,
                  message: intl('widget.common.name_pattern'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.common.name_pattern'),
                },
              ],
            })}
            disabled={!!value.Id}
          />
        </Form.Item>
        <Form.Item
          label={
            <React.Fragment>
              <span>{intl('widget.app.tag')}</span>
              <Balloon align="t" trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />} closable={false}>
                {intl.html('widget.app.tag_hint')}
              </Balloon>
            </React.Fragment>
          }
          required
        >
          <TagSelector
            {...init('Tag', {
              rules: [
                {
                  required: true,
                  message: intl('widget.common.select_tag'),
                },
              ],
            })}
            disabled={!!value.Id}
            AppId={value.AppId}
            namespaces={getValue('Namespaces')}
            placeholder={intl('widget.common.select_tag')}
          />
        </Form.Item>
        <Form.Item label={intl('widget.route.frame_type')} required >
          <Radio.Group
            {...init('Protocol', {
              initValue: 'istio',
              rules: [
                {
                  required: true,
                  message: intl('widget.route.frame_type_errorr'),
                },
              ],
            })}
            dataSource={[{ value: 'istio', label: intl('widget.service.service_mesh') }]}
            disabled={!!value.Id}
          />
        </Form.Item>
        <Form.Item label={intl('widget.msc.source_type')} required>
          <Radio.Group
            {...init('SourceType', {
              initValue: 'all',
              rules: [
                {
                  required: true,
                },
              ],
            })}
            dataSource={[
              { value: 'all', label: intl('widget.msc.all_app') },
              { value: 'specific', label: intl('widget.msc.some_app') },
            ]}
          />
        </Form.Item>
        <If condition={getValue('SourceType') === 'specific'}>
          <Form.Item label={intl('widget.msc.some_app')} required>
            <AppSelector
              {...init('SourceAppId', {
                rules: [
                  {
                    required: true,
                    message: intl('widget.common.select_app'),
                  },
                ],
                props: {
                  onChange: (ids, names) => {
                    console.log(ids, names)
                    setValue('SourceAppName', names);
                  }
                }
              })}
              mode="multiple"
              namespaces={getValue('Namespaces')}
            />
          </Form.Item>
        </If>
        <Form.Item label={intl('widget.msc.retry_condition')} required >
          <TreeSelect
            {...init('RetryOn', {
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.please_select_retry_condition'),
                },
              ],
            })}
            style={{ width: 'calc(100% - 32px)' }}
            treeDefaultExpandAll
            treeCheckable
            multiple
            dataSource={[
              {
                value: '5xx',
                label: '5xx',
                key: '5xx',
                children: [
                  { value: 'gateway-error', label: 'gateway-erro', key: 'gateway-error', },
                  { value: 'rest', label: 'rest', key: 'rest', },
                  { value: 'connect-failure', label: 'connect-failure', key: 'connect-failure', },
                  { value: 'refused-stream', label: 'refused-stream', key: 'refused-stream', },
                ]
              },
              { value: 'retriable-4xx', label: 'retriable-4xx' },
            ]}

          />
          {/* <Checkbox.Group
            {...init('RetryOn', {
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.please_select_retry_condition'),
                },
              ],
            })}
            dataSource={[
              { value: '5xx', label: '5xx' },
              { value: 'gateway-error', label: 'gateway-erro' },
              { value: 'rest', label: 'rest' },
              { value: 'connect-failure', label: 'connect-failure' },
              { value: 'refused-stream', label: 'refused-stream' },
              { value: 'retriable-4xx', label: 'retriable-4xx' },
            ]}
          /> */}
        </Form.Item>
        <Form.Item
          label={
            <React.Fragment>
              <span>{intl('widget.msc.retry_times')}</span>
              <Balloon align="t" trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />} closable={false}>
                {intl.html('widget.msc.retry_times_hint')}
              </Balloon>
            </React.Fragment>
          }
          required
        >
          <NumberPicker
            min={0}
            style={{ width: 'calc(100% - 32px)' }}
            {...init('Attempts', {
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.please_enter_retry_times')
                },
              ],
            })}
            placeholder={intl('widget.msc.please_enter_retry_times')}
          />
        </Form.Item>
        <Form.Item
          label={
            <React.Fragment>
              <span>{intl('widget.msc.try_timeout_time')}</span>
              <Balloon align="t" trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />} closable={false}>
                {intl.html('widget.msc.try_timeout_time_retry_hint')}
              </Balloon>
            </React.Fragment>
          }
          required
        >
          <NumberPicker
            min={0}
            style={{ width: 'calc(100% - 32px)' }}
            {...init('PerTryTimeout', {
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.please_enter_try_timeout_time')
                },
              ],
            })}
            placeholder={intl('widget.msc.please_enter_try_timeout_time')}
          />
          <span style={{ marginLeft: 8 }}>ms</span>
        </Form.Item>
        <Form.Item label={intl('widget.outlier_ejection.default_state')} style={{ margin: '18px 0 0' }}>
          <Switch
            {...init('Enable', {
              initValue: true,
              valueName: 'checked'
            })}
          />
        </Form.Item>
      </Form>
      <Form.Item>
        <span onClick={() => setShowImg(true)} className="link-primary" style={{ marginBottom: 8 }}>{intl('widget.msc.config.service_rule_timeout')}</span>
        <If condition={showImg}>
          <img src="https://img.alicdn.com/imgextra/i4/O1CN01Cjbxbj1OBWwpETnNv_!!6000000001667-0-tps-2598-1080.jpg" style={{ width: '100%' }} />
        </If>
      </Form.Item>
    </SlidePanel>
  );
};

RetryEdit.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
};

export default RetryEdit;
