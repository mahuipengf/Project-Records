import React, { useState } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { TableContainer, CopyContent, Empty, Button, Message } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import Status from 'components/Status/CommonStatus';
import { upperFirstData1 } from 'utils/transfer-data';
import RetryEdit from './RetryEdit';
import { get, join, split } from 'lodash';
import { timeFmt } from 'utils';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import RetryInfo from './RetryInfo';

function Retry(props) {
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const intl = useIntl();
  const { Region, AppId, tableUniqueKey } = props;
  const [isEditShow, setIsEditShow] = useState(false);
  const [isInfoShow, setIsInfoShow] = useState(false);
  const [currentValue, setCurrentValue] = useState({});

  const protocol = {
    DUBBO: 'Dubbo',
    SPRING_CLOUD: 'Spring Cloud',
    istio: intl('widget.service.service_mesh'),
  };

  const fetchData = async (params) => {
    const { result: List, totalSize: TotalCount } = await services.GetRetryRule({
      params: {
        ...params,
        protocol: 'istio',
        AppId,
        Region,
      }
    });
    return {
      Data: upperFirstData1(List),
      TotalCount,
    };
  };

  const columns = [
    {
      key: 'Name',
      title: intl('widget.authentication.rule_name'),
      dataIndex: 'Name',
      cell: (val, index, record) => (
        <CopyContent text={val}>
          {val}
        </CopyContent>
      ),
    },
    {
      key: 'Enable',
      title: intl('widget.common.state'),
      dataIndex: 'Enable',
      cell: val => <Status value={val} intl={intl} />
    },
    {
      key: 'Protocol',
      title: intl('widget.route.frame_type'),
      dataIndex: 'Protocol',
      cell: val => (
        <Empty value={val}>
          {protocol[val] || '--'}
        </Empty>
      ),
    },
    {
      key: 'Tag',
      title: intl('widget.app.tag'),
      dataIndex: 'Tag',
    },
    {
      key: 'SourceAppName',
      title: intl('widget.msc.source_type'),
      dataIndex: 'SourceAppName',
      cell: (val, index, record) => {
        const sourceAppName = get(record, 'RouteRules[0].sourceAppName', []);
        if (sourceAppName[0] === '*') return intl('widget.msc.all_app');
        return join(sourceAppName, ', ');
      }
    },
    {
      key: 'RetryOn',
      title: intl('widget.msc.retry_condition'),
      dataIndex: 'RetryOn',
      cell: (val, index, record) => {
        const retryOn = get(record, 'RouteRules[0].retryOn');
        return retryOn;
      }
    },
    {
      key: 'Attempts',
      title: intl('widget.msc.retry_times'),
      dataIndex: 'Attempts',
      cell: (val, index, record) => {
        const Attempts = get(record, 'RouteRules[0].attempts');
        return Attempts || '--';
      }
    },
    {
      key: 'PerTryTimeout',
      title: intl('widget.msc.try_timeout_time'),
      dataIndex: 'RetryOn',
      cell: (val, index, record) => {
        const perTryTimeout = get(record, 'RouteRules[0].perTryTimeout');
        if (perTryTimeout) return `${perTryTimeout}ms`;
        return '--';
      }
    },
    {
      key: 'GmtModified',
      title: intl('widget.msc.update_time'),
      dataIndex: 'GmtModified',
      cell: value => <Empty value={value}>{timeFmt(value, 'YYYY/MM/DD HH:mm')}</Empty>,
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => (
        <Actions expandTriggerType="hover">
          <LinkButton key="1" onClick={() => handleEdit(record)}>{intl('widget.common.edit')}</LinkButton>
          <If condition={record.Enable}>
            <LinkButton key="3" onClick={() => handleClose(record)}>{intl('widget.common.close1')}</LinkButton>
          </If>
          <If condition={!record.Enable}>
            <LinkButton key="2" onClick={() => handleOpen(record)}>{intl('widget.common.open1')}</LinkButton>
          </If>
          <LinkButton key="4" onClick={() => handleDelete(record)}>{intl('widget.common.delete')}</LinkButton>
        </Actions>
      ),
      visible: true,
    },
  ];

  // 删除
  const handleDelete = (record) => {
    DialogAlert({
      title: intl('widget.common.delete'),
      content: intl.html('widget.common.delete_confirm', { name: record.Name }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.DeleteRetryRule({
          params: { Id: record.Id, Region: record.Region },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.delete_successful'));
        setFetchDataTime(Date.now());
      })
    });
  };

  const handleClose = (record) => {
    DialogAlert({
      title: intl('widget.common.close1'),
      content: intl.html('widget.common.close_confirm', { name: record.Name }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.UpdateRetryRule({
          params: {
            Protocol: record.Protocol,
            Enable: !record.Enable,
            AppId: record.AppId,
            Id: record.Id,
            Region: record.Region,
            Name: record.Name,
            Tag: record.Tag,
            Rules: get(record, 'RouteRules[0]')
          },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.close_successful'));
        setFetchDataTime(Date.now());
      })
    });
  };
  const handleOpen = (record) => {
    DialogAlert({
      title: intl('widget.common.open1'),
      content: intl.html('widget.common.open_confirm', { name: record.Name }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.UpdateRetryRule({
          params: {
            Protocol: record.Protocol,
            Enable: !record.Enable,
            AppId: record.AppId,
            Id: record.Id,
            Region: record.Region,
            Name: record.Name,
            Tag: record.Tag,
            Rules: get(record, 'RouteRules[0]')
          },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.open_successful'));
        setFetchDataTime(Date.now());
      })
    });
  };

  const openInfo = (record) => {
    setCurrentValue({ ...record });
    setIsInfoShow(true);
  };

  const handleEdit = (record = { Region, AppId }) => {
    setCurrentValue({ ...record });
    setIsEditShow(true);
  };

  const search = {
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };
  return (
    <React.Fragment>
      <TableContainer
        // style={{ marginTop: 16 }}
        fetchData={fetchData}
        primaryKey="Id"
        columns={columns}
        search={search}
        refreshIndex={fetchDataTime}
        operation={() => (
          <Button type="primary" onClick={() => handleEdit()}>
            {intl('widget.authentication.create_rule')}
          </Button>
        )}
        emptyContent={
          <div >
            <span className="link-primary" onClick={() => handleEdit()}>
              {intl('widget.route.no_data_go_create')}
            </span>
          </div>
        }
      />
      <RetryEdit
        visible={isEditShow}
        onClose={() => setIsEditShow(false)}
        onOk={() => {
          setIsEditShow(false);
          setFetchDataTime(Date.now());
        }}
        value={currentValue}
      />
      <RetryInfo
        visible={isInfoShow}
        value={currentValue}
        onClose={() => setIsInfoShow(false)}
      />
    </React.Fragment>
  );
}

Retry.propTypes = {
  Region: PropTypes.string,
  AppId: PropTypes.string,
};

export default Retry;
