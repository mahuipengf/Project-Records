import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import styles from '../../../../../components/Step/index.less';


const Step = ({ enable, appName }) => {
  const intl = useIntl();
  const map = {
    oldEdition: intl('widget.app.step_oldEdition'),
    noTag: intl('widget.app.step_noTag'),
    multipleTag: intl('widget.app.step_multipleTag'),
    onlyNoTag: intl('widget.app.step_onlyNoTag'),
    existence: intl('widget.app.step_existence'),

  };
  // useEffect(() => {}, [tag]);
  const dl = '$';
  return (
    <React.Fragment>
      <div className={styles['step-content']}>
        <div className={styles['step-explain']}>{intl.html('widget.app.new_canary_instructions')}</div>
        <div style={{ display: 'flex' }}>
          <span className={styles['step-title']} style={{ width: 90 }}>STEP 1</span>
          <span className={styles['step-circular']} style={{ marginTop: 5 }} />
          <div style={{ flex: 1 }}>
            {intl.html('widget.app.rocketmq_step_one_check_server1', { params: `${dl}{${intl('widget.app.rocketmq_step_one_check_server1.params.name')}}_${dl}{${intl('widget.app.rocketmq_step_one_check_server1.params.tag')}}` })}
          </div>
        </div>
        <div style={{ display: 'flex' }}>
          {intl.html('widget.app.mq_step_one_msg')}
          <span className={styles['step-line1']} style={{ height: 120, marginTop: -2 }} />
          {intl.html('widget.app.rocketmq_step_one_check_group1')}
        </div>
        <div style={{ display: 'flex' }}>
          <span className={styles['step-title']} style={{ width: 90 }}>STEP 2</span>
          <span className={styles['step-circular']} style={{ marginTop: 5 }} />
          <div style={{ flex: 1 }}>
            {intl.html('widget.app.rocketmq_step_two_open_gray')}
          </div>
        </div>
        <div style={{ display: 'flex' }}>
          {intl.html('widget.app.mq_step_two_msg')}
          <span className={styles['step-line2']} style={{ height: 74, marginTop: -2 }} />
          {intl.html('widget.app.rocketmq_step_two_both_open_gray')}
        </div>
        <div style={{ display: 'flex' }}>
          <span className={styles['step-title']} style={{ width: 90 }}>STEP 3</span>
          <span className={`${enable ? styles['step-circular-err'] : styles['step-circular']}`} style={{ marginTop: 5 }} />
          <div style={{ flex: 1 }}>
            {intl.html('widget.app.rocketmq_step_third_consumer_intro')}
          </div>
        </div>
        <div style={{ display: 'flex' }}>
          <span>{intl.html('widget.app.mq_step_third_msg')}</span>
          <span style={{ width: '44px' }} />
          {/* <span className={`${enable ? styles['step-enable'] : styles['step-line1']}`} /> */}
          <div style={{ flex: 1 }}>
            {intl.html('widget.app.rocketmq_step_third_exclude_tag')}
          </div>
        </div>
        {/* <div>
          <span className={styles['step-title']} style={{ width: 90 }}>STEP 4</span>
          <span className={`${enable ? styles['step-circular-err'] : styles['step-circular']}`} />
          {intl.html('widget.app.step_four_vilidate_roll_back')}
        </div>
        <div style={{ display: 'flex' }}>
          {intl.html('widget.app.step_four_msg')}
          <span className={styles['step-line3']} />
          <div className={styles['step-font']}>
            {intl.html('widget.app.rocketmq_step_third_exclude_tag')}
          </div>
        </div> */}
      </div>
    </React.Fragment>
  );
};
Step.propTypes = {
  enable: PropTypes.bool,
  appName: PropTypes.string,
};

export default Step;
