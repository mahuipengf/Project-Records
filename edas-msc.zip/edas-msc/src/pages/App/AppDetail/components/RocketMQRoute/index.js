import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Message, Field, Select, Radio, Switch, Button, Balloon, Icon } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { get, map } from 'lodash';
import { upperFirstData1 } from 'utils/transfer-data';
import Step from './Step';

const RocketMQRoute = (props) => {
  const [loading, setLoading] = useState(false);
  const [isUpdate, setIsUpdate] = useState(false);
  const { Region, AppId, AppName } = props;
  const intl = useIntl();
  const field = Field.useField();
  const { init, validate, setValues } = field;
  const [dataSource, setDataSource] = useState([]);
  const [data, setData] = useState({});
  const [isShowGrayscale, setIsShowGrayscale] = useState(false);

  const initMessageQueueFilterSide = [{
    value: 'Client',
    label: (<span>
      <Balloon trigger={<span>{intl('widget.msc.message.grayscale.client.filter')}<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} /></span>} closable={false} >{intl('widget.msc.message.grayscale.client.filter.tips')}</Balloon></span>)
  }, {
    value: 'Server',
    label: (<span><Balloon trigger={<span>{intl('widget.msc.message.grayscale.service.filter')}<Icon type="help" size="xs" style={{ color: '#888888', marginLeft: '4px' }} />{intl('widget.msc.message.grayscale.recommend')}</span>} closable={false} >{intl('widget.msc.message.grayscale.service.filter.tips')}</Balloon></span>)
  }];

  useEffect(() => {
    fetchData();
  }, []);


  const fetchData = async () => {
    const Data = await services.GetAppMessageQueueRoute({
      params: { Region, AppId, AppName }
    });
    const res = await services.GetApplicationTags({
      params: { Region, AppId }
    });
    const Threshold = get(upperFirstData1(Data), 'Tags', []);
    const Enable = get(upperFirstData1(Data), 'Enable', false);
    const FilterSide = get(upperFirstData1(Data), 'FilterSide', 'Client');
    // Threshold: Threshold * 100,
    const newTags = map(res, items => ({ label: items.Tag, value: items.Tag }));
    setValues({ Threshold, Enable, FilterSide });
    setData({ Threshold, Enable, FilterSide });
    setDataSource(newTags);
    setIsShowGrayscale(Enable);
  };

  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const params = {
        AppId,
        Region,
        Enable: values.Enable,
        Tags: values.Threshold,
        FilterSide: values.FilterSide,
        AppName,
      };
      setLoading(true);
      await services.UpdateMessageQueueRoute({
        params,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      }).then(() => {
        fetchData();
      });
      setLoading(false);
      setIsUpdate(false);
      Message.success(intl('widget.common.update_successful'));
    });
  };

  const formItemLayout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 10 }
  };
  return (
    <Form field={field} {...formItemLayout} style={{ marginTop: 16, padding: 16, border: '1px solid #eee' }}>
      <Form.Item
        label={
          <React.Fragment>
            <span style={{ lineHeight: '32px' }}>{intl('widget.msc.rocketmq_tags_setting')}</span>
          </React.Fragment>
        }
      >
        <Select
          maxTagCount={10}
          mode="tag"
          dataSource={dataSource}
          style={{ width: 200 }}
          {...init('Threshold', {
            rules: [
              {
                required: false,
                message: intl('widget.msc.rocketmq_tags_setting')
              },
            ],
          })}
          disabled={!isUpdate}
          placeholder={intl('widget.route.condition.list_placeholder')}
        />
        <Icon type="edit" style={{ color: '#0077cc', cursor: 'pointer', marginLeft: 16 }} onClick={() => setIsUpdate(true)}>{intl('widget.common.edit')}</Icon>
      </Form.Item>
      <Form.Item
        label={
          <React.Fragment>
            <span style={{ lineHeight: '32px' }}>{intl('widget.msc.rocketmq_open_setting_hint')}</span>
          </React.Fragment>
        }
        style={{ margin: '18px 0 0' }}
        required
      >
        <div style={{ display: 'flex', alignItems: 'center', height: 32 }}>
          <Switch
            disabled={!isUpdate}
            {...init('Enable', {
              initValue: false,
              valueName: 'checked',
              props: {
                onChange: (val) => {
                  setIsShowGrayscale(val);
                },
              },
            })}
          />
          <Icon type="edit" style={{ color: '#0077cc', cursor: 'pointer', marginLeft: 16 }} onClick={() => setIsUpdate(true)}>{intl('widget.common.edit')}</Icon>
        </div>
      </Form.Item>
      <If condition={isShowGrayscale}>
        <Form.Item label={<span style={{ lineHeight: '32px' }}>{intl('widget.msc.message.grayscale.filter_test')}</span>} >
          <Radio.Group
            {...init('FilterSide', {
              initValue: 'Client',
              // valueName: 'checked',
            })}
            disabled={!isUpdate}
            dataSource={initMessageQueueFilterSide}
          />
        </Form.Item>
      </If>
      <If condition={isUpdate}>
        <Form.Item style={{ marginTop: 16 }}>
          <Button type="normal" style={{ marginRight: 8 }} onClick={() => { setIsUpdate(false); setValues(data); }}>
            {intl('widget.common.cancel')}
          </Button>
          <Form.Submit validate type="primary" onClick={handleSubmit} loading={loading}>
            {intl('widget.common.ok')}
          </Form.Submit>
        </Form.Item>
      </If>
      <Step />
    </Form>
  );
};

RocketMQRoute.propTypes = {
  AppId: PropTypes.string,
  Region: PropTypes.string,
  AppName: PropTypes.string,
};

export default RocketMQRoute;
