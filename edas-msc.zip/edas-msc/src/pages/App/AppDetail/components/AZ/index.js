import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Message, Field, NumberPicker, Switch, Button, Balloon, Icon } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { get } from 'lodash';
import { upperFirstData1 } from 'utils/transfer-data';
import { getParams } from 'utils';

const AZ = (props) => {
  const [loading, setLoading] = useState(false);
  const [isUpdate, setIsUpdate] = useState(false);
  const { Region, AppId } = props;
  const intl = useIntl();
  const field = Field.useField();
  const { init, validate, setValues } = field;

  useEffect(() => {
    fetchData();
  }, []);


  const fetchData = async () => {
    const Data = await services.GetLocalityRule({
      params: { Region, AppId }
    });
    const Threshold = get(upperFirstData1(Data), 'RouteRules[0].threshold', 0);
    const Enable = get(upperFirstData1(Data), 'Enable', false);
    setValues({ Threshold: Threshold * 100, Enable });
  };

  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const params = {
        AppId,
        Region,
        Enable: values.Enable,
        Rules: JSON.stringify({
          threshold: values.Threshold / 100
        })
      };
      setLoading(true);
      await services.UpdateLocalityRule({
        params,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      });
      setLoading(false);
      setIsUpdate(false);
      Message.success(intl('widget.common.update_successful'));
    });
  };

  const formItemLayout = {
    labelCol: { span: 4 },
    wrapperCol: { span: 10 }
  };
  return (
    <Form field={field} {...formItemLayout} style={{ marginTop: 16, padding: 16, border: '1px solid #eee' }}>
      <Form.Item
        // label={<span style={{ lineHeight: '32px' }}>{intl('widget.msc.threshold_setting')}</span>}
        label={
          <React.Fragment>
            <span style={{ lineHeight: '32px' }}>{intl('widget.msc.threshold_setting')}
              <Balloon
                align="t"
                trigger={<Icon type="help" size="xs" style={{ color: '#777', cursor: 'pointer', marginLeft: 4 }} />}
                closable={false}
              >
                {intl('widget.msc.threshold_setting_tips')}
              </Balloon>
            </span>
            <If condition={getParams('accessType') === 'ASM'}>
              <Balloon align="t" trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />} closable={false}>
                {intl.html('widget.msc.threshold_setting_hint')}
              </Balloon>
            </If>
          </React.Fragment>
        }
        required
      >
        <NumberPicker
          min={0}
          max={100}
          style={{ width: 200 }}
          {...init('Threshold', {
            rules: [
              {
                required: true,
                message: intl('widget.msc.please_enter_threshold_setting')
              },
            ],
          })}
          disabled={!isUpdate}
          placeholder="0-100"
        />
        <span style={{ marginLeft: 4 }}>%</span>
        <Icon type="edit" style={{ color: '#0077cc', cursor: 'pointer', marginLeft: 16 }} onClick={() => setIsUpdate(true)}>{intl('widget.common.edit')}</Icon>
      </Form.Item>
      <Form.Item
        // label={<span style={{ lineHeight: '32px' }}>{intl('widget.msc.open_setting')}</span>}
        label={
          <React.Fragment>
            <span style={{ lineHeight: '32px' }}>{intl('widget.msc.open_setting')}
              <Balloon
                align="t"
                trigger={<Icon type="help" size="xs" style={{ color: '#777', cursor: 'pointer', marginLeft: 4 }} />}
                closable={false}
              >
                {intl('widget.msc.open_setting_tips')}
              </Balloon>
            </span>
            <If condition={getParams('accessType') === 'ASM'}>
              <Balloon align="t" trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />} closable={false}>
                {intl.html('widget.msc.open_setting_hint')}
              </Balloon>
            </If>
          </React.Fragment>
        }
        style={{ margin: '18px 0 0' }}
        required
      >
        <div style={{ display: 'flex', alignItems: 'center', height: 32 }}>
          <Switch
            disabled={!isUpdate}
            {...init('Enable', {
              initValue: false,
              valueName: 'checked'
            })}
          />
          <Icon type="edit" style={{ color: '#0077cc', cursor: 'pointer', marginLeft: 16 }} onClick={() => setIsUpdate(true)}>{intl('widget.common.edit')}</Icon>
        </div>
      </Form.Item>
      <If condition={isUpdate}>
        <Form.Item style={{ marginTop: 16 }}>
          <Button type="normal" style={{ marginRight: 8 }} onClick={() => setIsUpdate(false)}>
            {intl('widget.common.cancel')}
          </Button>
          <Form.Submit validate type="primary" onClick={handleSubmit} loading={loading}>
            {intl('widget.common.ok')}
          </Form.Submit>
        </Form.Item>
      </If>
    </Form>
  );
};

AZ.propTypes = {
  AppId: PropTypes.string,
  Region: PropTypes.string,
};

export default AZ;
