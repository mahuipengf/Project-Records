import React, { useState, useEffect } from 'react';
import { useIntl } from '@ali/widget-hooks';
import { Select, Icon } from '@ali/cn-design';
import { head, find, isEmpty, filter, map, get } from 'lodash';
import PropTypes from 'prop-types';
import services from 'services';

const TagSelector = (props) => {
  const { value, onChange, namespaces = {}, AppId, showAll, ...reset } = props;
  const [tagList, setTagList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const intl = useIntl();
  const { regionId, namespaceId } = namespaces;

  useEffect(() => {
    if (isEmpty(namespaces) || !regionId) return;
    ListApplicationsWithTagRules({ pageNumber: 1, pageSize: 50 });
  }, [namespaces, AppId]);

  // 这个是分页接口，但是需要拿到全部数据
  const ListApplicationsWithTagRules = async ({ pageNumber, pageSize }) => {
    setIsLoading(true);
    const { Result = [] } = await services.ListApplicationsWithTagRules({
      params: {
        Region: regionId,
        Namespace: namespaceId,
        PageNumber: pageNumber,
        PageSize: pageSize,
        AppId,
      }
    });
    setIsLoading(false);
    let { RouteRules = [] } = head(Result) || {};
    RouteRules = filter(RouteRules, item => (!isEmpty(get(item, 'Rules.springcloud')) || !isEmpty(get(item, 'Rules.dubbo')) || !isEmpty(get(item, 'Rules.istio'))));
    const TagList = [{ value: 'default', label: intl('widget.msc.default') }, ...map(RouteRules, item => ({ value: item.Tag, label: item.Tag }))];
    setTagList(TagList);
    if (!value || !find(TagList, item => item.value === value)) {
      const firstItem = head(TagList) || {};
      handleChangeApp(firstItem.value);
    }
  };

  const handleChangeApp = (id) => {
    const item = find(tagList, { value: id }) || {};
    onChange && onChange(id, item.label);
  };

  return (
    <React.Fragment>
      <Select
        state={isLoading ? 'loading' : ''}
        showSearch
        style={{ width: 'calc(100% - 32px)' }}
        dataSource={tagList}
        value={value}
        onChange={(id) => handleChangeApp(id)}
        placeholder={intl('widget.common.select_app')}
        {...reset}
      />
      <Icon type="refresh" style={{ marginLeft: 8, cursor: 'pointer' }} onClick={() => ListApplicationsWithTagRules({ pageNumber: 1, pageSize: 50 })} />
    </React.Fragment>
  );
};

TagSelector.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.number,
  showAll: PropTypes.arrayOf(PropTypes.any),
  namespaces: PropTypes.objectOf(PropTypes.any),
};

export default TagSelector;
