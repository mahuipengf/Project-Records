import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { TableContainer, CopyContent, Message, Loading } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import Status from 'components/Status/CommonStatus';
import LoadBalanceEdit from './LoadBalanceEdit';
import LoadBalanceInfo from './LoadBalanceInfo';
import { map, get, isEmpty, head, filter } from 'lodash';
import Actions, { LinkButton } from '@alicloud/console-components-actions';


const LoadingComp = () => {
  const [show, setShow] = useState(0);

  useEffect(() => {
    setTimeout(() => {
      setShow(true);
    }, 300);
  });
  return (
    <If condition={show}>
      <Loading visible style={{ width: '100%', marginTop: 32 }} />
    </If>
  );
};

function LoadBalance(props) {
  const { Region, AppId } = props;
  const [isEditShow, setIsEditShow] = useState(false);
  const [isInfoShow, setIsInfoShow] = useState(false);
  const [currentValue, setCurrentValue] = useState({});
  const [refreshIndex, setRefreshIndex] = useState(0);
  const intl = useIntl();
  const [TableData, setTableData] = useState();

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    setRefreshIndex(Date.now());
  }, [TableData]);

  const fetchData = async () => {
    const { Result = [], totalSize: TotalCount = 0 } = await services.ListLoadBalancePolicy({
      params: {
        AppId,
        Region,
        Protocol: 'istio',
        PageNumber: 1,
        PageSize: 10,
      },
      customErrorHandle: (error, respongse, callback) => {
        setTableData({
          Result: [],
          TotalCount: 0,
          columns: filter(mapColumns({}), item => item.visible),
        });
        callback();
      }
    });
    const NewResult = map(Result, item => {
      const Data = { ...item, Region: item.RegionId || Region };
      switch (Data.ConsistHashType) {
        case 'http_cookie':
          Data.LoadBalanceConfig = JSON.parse(Data.LoadBalanceConfig);
          Data.CookieName = get(Data, 'LoadBalanceConfig.CookieName');
          Data.CookiePath = get(Data, 'LoadBalanceConfig.CookiePath');
          Data.Ttl = get(Data, 'LoadBalanceConfig.Ttl');
          break;
        case 'use_source_ip':
          Data.use_source_ip = get(Data, 'LoadBalanceConfig');
          break;
        case 'http_header_name':
          Data.http_header_name = get(Data, 'LoadBalanceConfig');
          break;
        case 'http_qurey_parameter_name':
          Data.http_qurey_parameter_name = get(Data, 'LoadBalanceConfig');
          break;
        default:
          break;
      }
      return Data;
    });
    const firstData = head(NewResult) || {};
    const columns = filter(mapColumns(firstData), item => item.visible);
    setTableData({
      Result: NewResult,
      TotalCount,
      columns,
    });
  };

  const fetchTableData = () => {
    const { Result = [], TotalCount = 0 } = TableData;
    return {
      Data: Result,
      TotalCount,
    };
  };

  const mapColumns = (currentData) => [
    {
      key: 'PolicyName',
      title: intl('widget.common.name'),
      dataIndex: 'PolicyName',
      cell: (val, index, record) => (
        <CopyContent text={val}>
          {val}
        </CopyContent>
      ),
      visible: true,
    },
    {
      key: 'LoadBalanceType',
      title: intl('widget.msc.type'),
      dataIndex: 'LoadBalanceType',
      cell: val => {
        const type = {
          Simple: intl('widget.msc.easy'),
          ConsistentHash: intl('widget.msc.consistent_hash')
        };
        return type[val];
      },
      visible: true,
    },
    {
      key: 'LoadBalanceConfig',
      dataIndex: 'LoadBalanceConfig',
      title: intl('widget.msc.config'),
      cell: val => {
        const type = {
          random: intl('widget.msc.random'),
          round_robin: intl('widget.msc.polling'),
          least_conn: intl('widget.msc.least_conn')
        };
        return type[val] || '--';
      },
      visible: currentData.LoadBalanceType === 'Simple',
    },
    {
      key: 'ConsistHashType',
      dataIndex: 'ConsistHashType',
      title: intl('widget.msc.hash_type'),
      cell: (val) => {
        const type = {
          use_source_ip: intl('widget.msc.use_source_ip_hash'),
          http_header_name: intl('widget.msc.header_hash'),
          http_cookie: intl('widget.msc.cookie_hash'),
          http_qurey_parameter_name: intl('widget.msc.query_hash'),
        };
        return type[val] || '--';
      },
      visible: currentData.LoadBalanceType === 'ConsistentHash',
    },
    {
      key: 'CookieName',
      dataIndex: 'CookieName',
      title: intl('widget.msc.cookie_name'),
      visible: currentData.ConsistHashType === 'http_cookie',
    },
    {
      key: 'CookiePath',
      dataIndex: 'CookiePath',
      title: intl('widget.msc.cookie_path'),
      visible: currentData.ConsistHashType === 'http_cookie',
    },
    {
      key: 'Ttl',
      dataIndex: 'Ttl',
      title: intl('widget.msc.cookie_timeout'),
      visible: currentData.ConsistHashType === 'http_cookie',
    },
    {
      key: 'use_source_ip',
      dataIndex: 'use_source_ip',
      title: intl('widget.msc.use_source_ip'),
      visible: currentData.ConsistHashType === 'use_source_ip',
    },
    {
      key: 'http_header_name',
      dataIndex: 'http_header_name',
      title: 'Header',
      visible: currentData.ConsistHashType === 'http_header_name',
    },
    {
      key: 'http_qurey_parameter_name',
      dataIndex: 'http_qurey_parameter_name',
      title: intl('widget.msc.query'),
      visible: currentData.ConsistHashType === 'http_qurey_parameter_name',
    },
    {
      key: 'Enable',
      title: intl('widget.common.state'),
      dataIndex: 'Enable',
      cell: val => <Status value={val} intl={intl} />,
      visible: true,
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => (
        <Actions expandTriggerType="hover">
          <LinkButton key="1" onClick={() => balanceEdit(record)}>{intl('widget.common.edit')}</LinkButton>
          <If condition={record.Enable}>
            <LinkButton key="3" onClick={() => handleClose(record)}>{intl('widget.common.close1')}</LinkButton>
          </If>
          <If condition={!record.Enable}>
            <LinkButton key="2" onClick={() => handleOpen(record)}>{intl('widget.common.open1')}</LinkButton>
          </If>
          <LinkButton key="4" onClick={() => handleDelete(record)}>{intl('widget.common.delete')}</LinkButton>
        </Actions>
      ),
      visible: true,
    },
  ];


  const handleOpenInfo = (record = {}) => {
    setCurrentValue({ ...record });
    setIsInfoShow(true);
  };

  const handleClose = (record) => {
    DialogAlert({
      title: intl('widget.common.close1'),
      content: intl.html('widget.common.close_confirm', { name: record.PolicyName }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.UpdateLoadBalanceConfig({
          params: { ...record, Enable: !record.Enable },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.close_successful'));
        fetchData();
      })
    });
  };
  const handleOpen = (record) => {
    DialogAlert({
      title: intl('widget.common.open1'),
      content: intl.html('widget.common.open_confirm', { name: record.PolicyName }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.UpdateLoadBalanceConfig({
          params: { ...record, Enable: !record.Enable },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.open_successful'));
        fetchData();
      })
    });
  };
  // 删除
  const handleDelete = (record) => {
    DialogAlert({
      title: intl('widget.common.delete'),
      content: intl.html('widget.common.delete_confirm', { name: record.PolicyName }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.RemoveLoadBalancePolicy({
          params: { PolicyId: record.PolicyId, Region: record.Region },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.delete_successful'));
        fetchData();
      })
    });
  };

  const balanceEdit = (record = { Region, AppId }) => {
    setCurrentValue({ ...record });
    setIsEditShow(true);
  };

  if (isEmpty(TableData)) {
    return <LoadingComp />;
  }
  return (
    <React.Fragment>
      <TableContainer
        style={{ marginTop: 16 }}
        fetchData={fetchTableData}
        primaryKey="PolicyId"
        columns={TableData.columns || []}
        refreshIndex={refreshIndex}
        emptyContent={
          <div >
            <span className="link-primary" onClick={() => balanceEdit()}>
              {intl('widget.route.no_data_go_create')}
            </span>
          </div>
        }
      />
      <LoadBalanceEdit
        visible={isEditShow}
        onClose={() => setIsEditShow(false)}
        onOk={() => {
          setIsEditShow(false);
          fetchData();
        }}
        value={currentValue}
      />
      <LoadBalanceInfo
        visible={isInfoShow}
        value={currentValue}
        onClose={() => setIsInfoShow(false)}
      />
    </React.Fragment>
  );
}

LoadBalance.propTypes = {
  Region: PropTypes.string,
  AppId: PropTypes.string,
};

export default LoadBalance;

