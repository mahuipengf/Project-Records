import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Message, Radio, Field, NumberPicker, Switch } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { NNAME_PATTERN } from 'constants';
import SlidePanel from 'components/SlidePanel';
import { get } from 'lodash';
import IconBack from 'components/IconBack';

const LoadBalanceEdit = (props) => {
  const [loading, setLoading] = useState(false);
  const { value, visible, onClose, onOk } = props;
  const intl = useIntl();
  const field = Field.useField();
  const { init, validate, getValue, setValues, reset } = field;
  useEffect(() => {
    const PolicyName = get(value, 'PolicyName', '');
    const Region = get(value, 'Region', '');
    if (value.PolicyId) {
      setValues({
        PolicyName,
        Region,
        ...value,
      });
    } else {
      setValues({
        Region,
      });
    }
  }, [value]);
  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const params = {
        Protocol: 'istio',
        AppId: value.AppId,
        PolicyId: value.PolicyId,
        Region: values.Region,
        PolicyName: values.PolicyName,
        LoadBalanceType: values.LoadBalanceType,
        ConsistHashType: values.ConsistHashType,
        Enable: values.Enable,
        PolicyDescription: values.PolicyDescription,
      };
      if (values.LoadBalanceType === 'Simple') {
        params.LoadBalanceConfig = values.LoadBalanceConfig;
      }
      if (values.LoadBalanceType === 'ConsistentHash') {
        switch (values.ConsistHashType) {
          case 'use_source_ip':
            params.LoadBalanceConfig = values.use_source_ip;
            break;
          case 'http_header_name':
            params.LoadBalanceConfig = values.http_header_name;
            break;
          case 'http_cookie':
            params.LoadBalanceConfig = {
              CookieName: values.CookieName,
              CookiePath: values.CookiePath,
              Ttl: values.Ttl,
            };
            break;
          case 'http_qurey_parameter_name':
            params.LoadBalanceConfig = values.http_qurey_parameter_name;
            break;
          default:
            break;
        }
      }
      editLoadBalancePolicy(params);
    });
  };

  // 创建
  const editLoadBalancePolicy = async (params) => {
    setLoading(true);
    value.Id
      ? await services.UpdateLoadBalanceConfig({
        params,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      })
      : await services.AddLoadBalancePolicy({
        params,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      });
    setLoading(false);
    onOk();
    reset();
    Message.success(intl(value.Id ? 'widget.common.update_successful' : 'widget.common.add_successful'));
  };

  const handleClose = () => {
    setLoading(false);
    reset();
    onClose();
  };

  return (
    <SlidePanel
      title={
        <IconBack goBack={onClose}>{intl(getValue('uid') ? 'widget.common.edit' : 'widget.common.create')}</IconBack>
      }
      processingText={intl('widget.common.ok')}
      isShowing={visible}
      onOk={handleSubmit}
      onClose={handleClose}
      onCancel={handleClose}
      isProcessing={loading}
      width={780}
    >
      <Form field={field}>
        <Form.Item label={intl('widget.common.name')} required>
          <Input
            style={{ width: 'calc(100% - 32px)' }}
            maxLength={64}
            showLimitHint
            placeholder={intl('widget.common.name_pattern')}
            {...init('PolicyName', {
              rules: [
                {
                  required: true,
                  message: intl('widget.common.name_pattern'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.common.name_pattern'),
                },
              ],
            })}
            disabled={!!value.PolicyId}
          />
        </Form.Item>
        <Form.Item label={intl('widget.route.description')}>
          <Input.TextArea
            {...init('PolicyDescription', {
            })}
            placeholder={intl('widget.route.description_placecholder')}
            maxLength={64}
            style={{ width: 'calc(100% - 32px)' }}
            showLimitHint
            autoHeight={
              {
                minRows: 1,
                maxRows: 3
              }
            }
          />
        </Form.Item>
        <Form.Item label={intl('widget.msc.type')} required >
          <Radio.Group
            {...init('LoadBalanceType', {
              initValue: 'Simple',
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.please_select_type')
                },
              ],
            })}
            dataSource={[
              { value: 'Simple', label: intl('widget.msc.easy') },
              { value: 'ConsistentHash', label: intl('widget.msc.consistent_hash') }
            ]}
          />
        </Form.Item>
        <If condition={getValue('LoadBalanceType') === 'Simple'}>
          <Form.Item label={intl('widget.msc.config')} required>
            <Radio.Group
              {...init('LoadBalanceConfig', {
                initValue: 'random',
                rules: [
                  {
                    required: true,
                    message: intl('widget.msc.please_select_config')
                  },
                ],
              })}
              dataSource={[
                { value: 'random', label: intl('widget.msc.random') },
                { value: 'round_robin', label: intl('widget.msc.polling') },
                { value: 'least_conn', label: intl('widget.msc.least_conn') },
              ]}
            />
          </Form.Item>
        </If>
        <If condition={getValue('LoadBalanceType') === 'ConsistentHash'}>
          <div >
            <Form.Item
              label={intl('widget.msc.hash_type')}
              required
            >
              <Radio.Group
                {...init('ConsistHashType', {
                  initValue: 'use_source_ip',
                  rules: [
                    {
                      required: true,
                      message: intl('widget.msc.please_select_hash_type')
                    }
                  ]
                })}
                dataSource={[
                  { value: 'use_source_ip', label: intl('widget.msc.use_source_ip_hash') },
                  { value: 'http_header_name', label: intl('widget.msc.header_hash') },
                  { value: 'http_cookie', label: intl('widget.msc.cookie_hash') },
                  { value: 'http_qurey_parameter_name', label: intl('widget.msc.query_hash') },
                ]}
              />
            </Form.Item>
            <If condition={getValue('ConsistHashType') === 'use_source_ip'}>
              <Form.Item
                label={intl('widget.msc.use_source_ip')}
                required
              >
                <Radio.Group
                  {...init('use_source_ip', {
                    initValue: 'true',
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_select_use_source_ip')
                      }
                    ]
                  })}
                  dataSource={[
                    { value: 'true', label: intl('widget.common.yes') },
                    { value: 'false', label: intl('widget.common.no') },
                  ]}
                />
              </Form.Item>
            </If>
            <If condition={getValue('ConsistHashType') === 'http_header_name'}>
              <Form.Item
                label="Header"
                required
              >
                <Input
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('http_header_name', {
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_enter_header_hash')
                      },
                    ],
                  })}
                  placeholder={intl('widget.msc.please_enter_header_hash')}
                />
              </Form.Item>
            </If>
            <If condition={getValue('ConsistHashType') === 'http_cookie'}>
              <Form.Item
                label={intl('widget.msc.cookie_name')}
                required
              >
                <Input
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('CookieName', {
                    rules: [
                      {
                        required: true,
                        message: intl('widget.common.name_pattern'),
                      },
                      {
                        pattern: NNAME_PATTERN,
                        message: intl('widget.common.name_pattern'),
                      },
                    ],
                  })}
                  placeholder={intl('widget.common.name_pattern')}
                />
              </Form.Item>
              <Form.Item
                label={intl('widget.msc.cookie_path')}
                required
              >
                <Input
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('CookiePath', {
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_enter_cookie_path'),
                      },
                    ],
                  })}
                  placeholder={intl('widget.msc.please_enter_cookie_path')}
                />
              </Form.Item>
              <Form.Item
                label={intl('widget.msc.cookie_timeout')}
                required
              >
                <NumberPicker
                  min={0}
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('Ttl', {
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_enter_cookie_timeout')
                      },
                    ],
                  })}
                  placeholder={intl('widget.msc.please_enter_cookie_timeout')}
                />
                <span style={{ marginLeft: 8 }}>s</span>
              </Form.Item>
            </If>
            <If condition={getValue('ConsistHashType') === 'http_qurey_parameter_name'}>
              <Form.Item
                label={intl('widget.msc.query')}
                required
              >
                <Input
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('http_qurey_parameter_name', {
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_enter_query')
                      },
                    ],
                  })}
                  placeholder={intl('widget.msc.please_enter_query')}
                />
              </Form.Item>
            </If>
          </div>
        </If>
        <Form.Item label={intl('widget.outlier_ejection.default_state')} style={{ margin: '18px 0 0' }}>
          <Switch
            {...init('Enable', {
              initValue: true,
              valueName: 'checked'
            })}
          />
        </Form.Item>
      </Form>
    </SlidePanel>
  );
};

LoadBalanceEdit.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
  k8sData: PropTypes.objectOf(PropTypes.any),
};

export default LoadBalanceEdit;
