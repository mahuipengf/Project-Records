import React, { useState, useEffect } from 'react';
import Info from '../Info';
import OverView from '../BasicOveriew';
import ServicesList from '../ServicesList';
import { useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import { get, replace } from 'lodash';
import { jsonParse } from 'utils/transfer-data';

const BasicPermission = () => {
  const [searchValues] = useGlobalState('searchValues');
  const [data, setData] = useState({});

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const res = await services.GetApplicationDetail({
      params: searchValues
    });
    const ExtraInfo = get(res, 'ExtraInfo');
    setData({
      ...res,
      AppName: unescape(replace(replace(res.AppName, /&#x/g, '%u'), /;/g, '')),
      ExtraInfo: jsonParse(ExtraInfo)
    });
  };

  const rpcTypes = get(data, 'ExtraInfo.rpcTypes');

  return (
    <React.Fragment>
      <Info data={data} />
      {/* <OverView /> */}
      <ServicesList rpcTypes={rpcTypes} />
    </React.Fragment>
  );
};

export default BasicPermission;
