import React, { useEffect, useState } from 'react';
import { Tab, Badge } from '@ali/cn-design';
import { map, filter, get, head } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import AuthenticationList from '../AuthenticationList';
// import TagList from './TagList';
import NewCanary from '../NewCanary';
import { getParams, aliyunSite } from 'utils';
import NewRouteTagList from 'pages/RouteManage/NewRouteTagList';
import RocketMQRoute from '../RocketMQRoute';
import { changeQuery } from 'utils/query';
import LoadBalance from '../LoadBalance';
import AZ from '../AZ';
import FaultInjection from '../FaultInjection';
import Timeout from '../Timeout';
import Retry from '../Retry';
import Observability from '../Observability';
import PushAirProtection from '../PushAirProtection';
import RoleHoc from 'containers/RoleHoc';
import DataFields from 'pages/Lossless/LosslessLineList/components/DataFields';
import DyncamicLine from '../DynamicLine';
import services from 'services';
import SummaryRtCpuStatus from '../SummaryRtCpuStatus';
import SummarySystem from '../SummarySystem';
// import SummaryNetWork from '../SummaryNetWork';
import SetRules from '../SystemGuardRulesManagement';

const GrantAuthorization = () => {
  const type = getParams('type') || 'canary';
  const intl = useIntl();
  const [searchValues] = useGlobalState('searchValues');
  const [tag, setTag] = useState(type);
  const [rowData, setRowData] = useState({});
  useEffect(() => fetchData(), []);
  const tabs = [
    {
      tab: 'widget.app.sevice_dynameic_line',
      key: 'dynameic_line',
      visible: aliyunSite !== 'INTL',
    },
    {
      tab: 'widget.app.canary',
      key: 'canary',
      visible: true,
    },
    {
      tab: 'widget.app.tag_route',
      key: 'tag',
      visible: true,
    },
    {
      tab: 'widget.app.mq_tag_route',
      key: 'mq_tag',
      visible: true,
    },
    {
      tab: 'widget.msc_lossless_name',
      key: 'lossless',
      visible: true,
    },
    {
      tab: 'widget.app.authentication',
      key: 'authentication',
      visible: true,
    },
    {
      tab: 'widget.app.push_air_protection',
      key: 'push_air',
      visible: aliyunSite !== 'INTL',
    },
    {
      tab: '限流降级',
      key: 'reduce',
      visible: aliyunSite !== 'INTL',
    },
    {
      tab: 'widget.mse.load_balance',
      key: 'load_balance',
      visible: getParams('accessType') === 'ASM',
    },
    {
      tab: 'widget.mse.fault_injection',
      key: 'fault_injection',
      visible: getParams('accessType') === 'ASM',
    },
    {
      tab: 'widget.mse.service_timeout',
      key: 'service_timeout',
      visible: getParams('accessType') === 'ASM',
    },
    {
      tab: 'widget.mse.retry',
      key: 'retry',
      visible: getParams('accessType') === 'ASM',
    },
    {
      tab: getParams('accessType') === 'ASM' ? 'widget.msc.AZ_istio' : 'widget.msc.AZ_java',
      key: 'AZ',
      visible: getParams('accessType') === 'ASM',
    },
  ];
  const fetchData = async () => {
    const res = await services.FetchLosslessRuleList({
      params: {
        AppId: searchValues.appId,
        pageNumber: 1,
        pageSize: 10,
        RegionId: searchValues.regionId,
        IsLossless: true,
      },
    });
    const result = head(get(res, 'Results', []));
    setRowData(result);
  };
  const updateStatus = () => fetchData();
  const tabComp = {
    dynameic_line: <DyncamicLine Region={searchValues.regionId} AppId={searchValues.appId} />,
    canary: <NewCanary value={searchValues} />,
    tag: <NewRouteTagList isShowMessage />,
    mq_tag: <RocketMQRoute Region={searchValues.regionId} AppId={searchValues.appId} AppName={searchValues.appName} />,
    authentication: <AuthenticationList />,
    load_balance: <LoadBalance Region={searchValues.regionId} AppId={searchValues.appId} />,
    AZ: <AZ Region={searchValues.regionId} AppId={searchValues.appId} />,
    fault_injection: <FaultInjection Region={searchValues.regionId} AppId={searchValues.appId} />,
    service_timeout: <Timeout Region={searchValues.regionId} AppId={searchValues.appId} />,
    retry: <Retry Region={searchValues.regionId} AppId={searchValues.appId} />,
    lossless: <DataFields rowData={rowData} updateStatus={updateStatus} details="details" />,
    push_air: <PushAirProtection />,
    reduce: <SetRules isCloudNativeGateway={true} pageType = 'guardApp'/>,
  };

  const changeUrl = (value) => {
    setTag(value);
    changeQuery({ type: value });
  };
  return (
    <React.Fragment>
      <Observability Region={searchValues.regionId} AppId={searchValues.appId} />
      <If condition={aliyunSite !== 'INTL'}>
        {/* RT与CPU图表 */}
        <SummaryRtCpuStatus Region={searchValues.regionId} AppId={searchValues.appId} />
        {/* Load与网络流量 */}
        <SummarySystem Region={searchValues.regionId} AppId={searchValues.appId} />
      </If>
      {/* <SummaryNetWork Region={searchValues.regionId} AppId={searchValues.appId} /> */}
      {/* defaultActiveKey={getParams('type') || 'tag'} */}
      <Tab className="service-relation-tab" shape="pure" defaultActiveKey={type} style={{ marginBottom: 16 }}>
        {map(filter(tabs, item => item.visible), n => {
          if (n.key === 'dynameic_line' || n.key === 'push_air') {
            return (<Tab.Item
              title={<div><Badge
                content={intl('widget.msc.public_beta')}
                style={{
                  backgroundColor: '#f54743',
                  color: '#fff',
                  borderRadius: '10px',
                  top: -10,
                  right: -40,
                }}
              >
                {intl(n.tab)}
              </Badge></div>}
              key={n.key}
              onClick={() => changeUrl(n.key)}
            />);
          }
          return <Tab.Item title={intl(n.tab)} key={n.key} onClick={() => changeUrl(n.key)} />;
        })}
      </Tab>
      {tabComp[tag]}
    </React.Fragment>
  );
};

export default RoleHoc(GrantAuthorization);
