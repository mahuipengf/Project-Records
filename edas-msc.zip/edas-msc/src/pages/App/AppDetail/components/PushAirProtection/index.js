import React, { useState, useEffect } from 'react';
import services from 'services';
import { Form, Field, Switch, Card, Collapse, Balloon, Icon, Empty } from '@ali/cn-design';
import { get, filter } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { lowerFirstData } from 'utils/transfer-data';
import { WIDGET_ID } from 'constants';
import { timeFmt } from 'utils';
import './index.less';

const PushAirProtection = () => {
  const field = Field.useField();
  const { init, setValues, getValue } = field;
  const [searchValues] = useGlobalState('searchValues');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const { regionId, appId } = searchValues;
  const [dataSource, setDataSource] = useState([]);
  const [curData, setCurData] = useState({});

  const intl = useIntl();

  useEffect(() => {
    queryEmptyPushSetting();
    fetchData();
    getAppList();
  }, []);
  const queryEmptyPushSetting = async () => {
    const res = await services.QueryEmptyPushSetting({
      params: {
        RegionId: regionId,
        AppId: appId
      }
    });
    setValues({ Enabled: res.Enabled });
  };
  const formItemLayout = {
    labelCol: { span: 4 },
  };
  const handleEmptyPushSettingChange = async(bol) => {
    const res = await services.CreateOrUpdateEmptyPushSetting({
      params: {
        RegionId: regionId,
        AppId: appId,
        Enabled: bol,
      }
    });
    if (res) {
      queryEmptyPushSetting();
    }
  };
  const getExtraInfo = (record) => {
    const isolationTimeTotal = get(record, 'extraInfo.isolationTime', 0) * get(record, 'extraInfo.isolationTimeMultiple', 0);
    const extraInfo = {
      service: get(record, 'service', ''),
      appName: get(record, 'appName', ''),
      timeStamp: timeFmt(get(record, 'timeStamp', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      consumerEndpoint: get(record, 'extraInfo.consumerEndpoint', ''),
      requestThreshold: get(record, 'extraInfo.requestThreshold', 0),
      errorRate: get(record, 'extraInfo.errorRate', 0) * 100,
      errorRateThreshold: get(record, 'extraInfo.errorRateThreshold', 0) * 100,
      maxIsolationRate: get(record, 'extraInfo.maxIsolationRate', 0) * 100,
      upStreamAppName: get(record, 'extraInfo.upStreamAppName', ''),
      providerEndpoint: get(record, 'extraInfo.providerEndpoint', 'provider'),
      isolationTime: get(record, 'extraInfo.isolationTime', 0) / 1000,
      isolationTimeMultiple: get(record, 'extraInfo.isolationTimeMultiple', 0),
      qps: get(record, 'extraInfo.qps', 0),
      recoverTime: timeFmt(get(record, 'extraInfo.recoverTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      isolationTimeTotal: get(record, 'extraInfo.isolationTime', 0) * get(record, 'extraInfo.isolationTimeMultiple', 0) / 1000,
      losslessTime: timeFmt(get(record, 'extraInfo.losslessTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      ip: get(record, 'extraInfo.ip', ''),
      result: get(record, 'extraInfo.result', false),
      upstreamAllServerCount: get(record, 'extraInfo.upstreamAllServerCount', 0),
      isolationServerCount: get(record, 'extraInfo.isolationServerCount', 0),
      ejectionTime: timeFmt(get(record, 'extraInfo.recoverTime', '') - isolationTimeTotal, 'YYYY-MM-DD HH:mm:ss'),
      offlineTime: timeFmt(get(record, 'extraInfo.offlineTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      readOnlyEventTime: timeFmt(get(record, 'extraInfo.readOnlyEventTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      unregisterTime: timeFmt(get(record, 'extraInfo.unregisterTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      killTime: timeFmt(get(record, 'extraInfo.killTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      readOnlyEventResult: get(record, 'extraInfo.readOnlyEventResult', false),
      unregisterResult: get(record, 'extraInfo.unregisterResult', ''),
      protocol: get(record, 'protocol', ''),
      success: get(record, 'extraInfo.success', false),
      emptyProtectionCount: get(record, 'extraInfo.count', 0),
      emptyProtectionTime: timeFmt(get(record, 'extraInfo.timestamp', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      emptyProtectionTime3Minute: timeFmt(get(record, 'extraInfo.timestamp', '') + (3 * 60 * 1000), 'YYYY-MM-DD HH:mm:ss') || '--',
      emptyProtectionServiceNameList: JSON.parse(get(record, 'extraInfo.serviceNameList', '[]')).join(),
    };
    return extraInfo;
  };
  const fetchData = async () => {
    const res = await services.ListEventsPage({
      params: { AppId: appId, Region: regionId, PageNumber: 1, PageSize: 10, EventType: 'ACTIVE_TRACE_Empty_Protection' }
    });
    const { result = [] } = lowerFirstData(res) || {};
    setDataSource(result);
  };
  const getAppList = async() => {
    const res = await services.GetAppList({
      params: {
        regionId,
        pageNumber: 1,
        pageSize: 300,
      }
    });
    const result = get(res, 'Result', []);
    const [rowData] = filter(result, items => items.AppId === appId);
    setCurData(rowData);
  };
  const handleGoToEventCenter = () => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-AppEventCenter`, curData);
  };
  return (
    <React.Fragment>
      <div style={{ display: 'flex', marginTop: 16, marginBottom: 16, width: '100%' }}>
        <div style={{ width: 'auto', flex: 1 }}>
          <Card contentHeight={'auto'} >
            <Form field={field} {...formItemLayout}>
              <Form.Item label={<span style={{ lineHeight: '20px' }}>{intl('widget.app.push.air.protection')}</span>}>
                <Switch
                  {
                      ...init('Enabled', {
                        initValue: false,
                        valueName: 'checked',
                        props: {
                          onChange: (v) => {
                            handleEmptyPushSettingChange(v);
                          }
                        }

                      })
                  }
                />
              </Form.Item>
              <div style={{ width: '100%', marginBottom: 16 }}>
                <ul style={{ lineHeight: '18px' }}>
                  {/* {intl.html('widget.app.push.air.protection.title')} */}
                  {intl.html('widget.app.push.air.protection.message_one')}
                  {/* {intl.html('widget.app.push.air.protection.message_two')} */}

                </ul>
              </div>
            </Form>
            <div>
              <Collapse>
                <Collapse.Panel title={intl('widget.app.push.air.protection')}>
                  <div style={{ display: 'flex' }}>
                    <img style={{ width: '400px' }} src="https://img.alicdn.com/imgextra/i1/O1CN01iLQRxd1yOC6x7USQA_!!6000000006568-2-tps-582-522.png" />
                  </div>
                </Collapse.Panel>
              </Collapse>
            </div>
          </Card>
        </div>
        <div className="card-air">
          <Card contentHeight={'auto'} title={intl('widget.app.push.air.protection_event')} extra={<span style={{ cursor: 'pointer' }} onClick={handleGoToEventCenter}>{intl('widget.app.push.air.protection_event_query')}</span>} showTitleBullet={false} showHeadDivider={false}>
            <div style={{ height: '240px', overflowY: 'scroll', overflowX: 'hidden' }}>
              <Empty showIcon value={dataSource} style={{ minHeight: '220px !important' }}>
                <For each="items" index="index" of={dataSource}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                    <div>{intl.html('widget.msc.event_center_abstract_empty_protection', getExtraInfo(items))}</div>
                    <Balloon trigger={(<div style={{ color: '#0070cc', cursor: 'pointer' }}>{intl.html('widget.common.detail')}</div>)} align="r">
                      {intl.html('widget.msc.event_center_detail_empty_protection', getExtraInfo(items))}{getExtraInfo(items).emptyProtectionServiceNameList && intl.html('widget.msc.event_center_detail_empty_protection_services', getExtraInfo(items))}
                    </Balloon>
                  </div>
                </For>
              </Empty>
            </div>
          </Card>
        </div>
      </div>
    </React.Fragment>
  );
};
export default PushAirProtection;
