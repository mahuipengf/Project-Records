import React, { useEffect, useState } from 'react';
import BasicInfo from './components/BasicInfo';
import Instances from './components/Instances';
import ServiceList from './components/ServiceList';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import { get, replace } from 'lodash';
import { jsonParse } from 'utils/transfer-data';
import { Collapse } from '@alicloud/console-components';

const { Panel } = Collapse;

const AppInfo = () => {
  const [searchValues] = useGlobalState('searchValues');
  const [data, setData] = useState({});
  const intl = useIntl();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const res = await services.GetApplicationDetail({
      params: searchValues
    });
    const ExtraInfo = get(res, 'ExtraInfo');
    setData({
      ...res,
      AppName: unescape(replace(replace(res.AppName, /&#x/g, '%u'), /;/g, '')),
      ExtraInfo: jsonParse(ExtraInfo)
    });
  };

  const rpcTypes = get(data, 'ExtraInfo.rpcTypes');

  return (
    <div style={{ paddingBottom: 16 }}>
      <Collapse defaultExpandedKeys={['0']}>
        <Panel title={intl('widget.common.basic_info')}>
          <BasicInfo data={data} />
        </Panel>
      </Collapse>
      <Instances />
      <If condition={rpcTypes}>
        <ServiceList rpcTypes={rpcTypes} />
      </If>
    </div>
  );
};

export default AppInfo;
