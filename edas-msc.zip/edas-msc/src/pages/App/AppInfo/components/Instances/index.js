import React, { useState } from 'react';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, Empty } from '@ali/cn-design';
import { filter, isEmpty } from 'lodash';
import { Collapse } from '@alicloud/console-components';

const { Panel } = Collapse;

const Instances = (props) => {
  const [searchValues] = useGlobalState('searchValues');
  const [totalSize, setTotalSize] = useState(0);
  const intl = useIntl();

  const fetchData = async (params) => {
    const Data = await services.GetApplicationInstances({
      params: {
        ...params,
        ...searchValues,
      }
    });
    const { Result = [], TotalSize = 0 } = Data || {};
    setTotalSize(TotalSize);
    return {
      Data: Result,
      TotalCount: TotalSize,
    };
  };

  const columns = [
    {
      key: 'Ip',
      title: intl('widget.app.address'),
      dataIndex: 'Ip',
      cell: (value) => <Empty value={value}>{`${value || ''}`}</Empty>,
    },
    {
      key: 'Tags',
      title: intl('widget.app.tag'),
      dataIndex: 'Tags',
      cell: value => {
        const tagList = filter(value, item => item.Type === 'tag');
        const cananryList = filter(value, item => item.Type === 'canary');
        const otherList = filter(value, item => (item.Type !== 'tag') && (item.Type !== 'canary'));
        return (
          <React.Fragment>
            <If condition={!isEmpty(value)}>
              <For index="index" each="item" of={tagList}>
                <i tab={item} style={{ color: '#7a94a9', marginRight: 4, padding: '4px 8px', borderRadius: 10, background: '#ecf2f6', fontStyle: 'normal' }}>{item.Tag || '--'}</i>
              </For>
              <For index="index" each="item" of={cananryList}>
                <span tab={item} style={{ color: '#8979a9', marginRight: 4, padding: '4px 8px', borderRadius: 10, background: '#8979a92e', fontStyle: 'normal' }}>{intl('widget.app.instance.canary', { n: item.Tag })}</span>
              </For>
              <For index="index" each="item" of={otherList}>
                <span tab={item} tyle={{ color: '#a57374', marginRight: 4, padding: '4px 8px', borderRadius: 10, background: '#f7eded', fontStyle: 'normal' }}>{item.Tag || '--'}</span>
              </For>
            </If>
            <If condition={isEmpty(value)}>--</If>
          </React.Fragment>
        );
      },
    },
  ];

  const searchs = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.app.tag'),
          value: 'tag',
          placeholder: intl('widget.app.tab_placeholder')
        },
        {
          label: intl('widget.app.address'),
          value: 'address',
          placeholder: intl('widget.app.address_placeholder')
        },
      ],
      defaultValue: 'tag',
    },
    isCanMultipleSearch: true,
    tableUniqueKey: true,
    isCanRefresh: true,
  };

  return (
    <React.Fragment>
      <Collapse defaultExpandedKeys={['0']}>
        <Panel title={intl('widget.app.instances_oveview', { n: totalSize })}>
          <TableContainer
            fetchData={fetchData}
            search={searchs}
            primaryKey="Id"
            columns={columns}
            followTrigger
          />
        </Panel>
      </Collapse>
    </React.Fragment>
  );
};

export default Instances;
