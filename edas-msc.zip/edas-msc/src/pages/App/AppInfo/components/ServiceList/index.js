import React, { useState } from 'react';
import { Tab } from '@ali/cn-design';
import { map, forEach, includes, head } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import ServiceList from 'containers/ServiceList';
import PropTypes from 'prop-types';
import { Collapse } from '@alicloud/console-components';

const { Panel } = Collapse;

const ServiceListComp = (props) => {
  const { rpcTypes = [] } = props;
  const [searchValues] = useGlobalState('searchValues');
  const intl = useIntl();
  const [scToalSize, setScTotalSize] = useState(0);
  const [dubboToalSize, setDubboTotalSize] = useState(0);
  const [isTioToalSize, setIstioTotalSize] = useState(0);
  const [currentTab, setCurrentTab] = useState(undefined);

  const { regionId, namespaceId, appId } = searchValues;

  const tabs = [
    {
      tab: 'Spring Cloud',
      key: 'springCloud',
      content: <ServiceList
        style={{ marginTop: 8 }}
        onCall={(totalSize) => setScTotalSize(totalSize)}
        condition={{
          serviceType: 'springCloud',
          side: 'provider',
          appId,
          regionId,
          namespaceId,
          origin,
        }}
      />
    },
    {
      tab: 'Dubbo',
      key: 'dubbo',
      content: <ServiceList
        style={{ marginTop: 8 }}
        onCall={(totalSize) => setDubboTotalSize(totalSize)}
        condition={{
          serviceType: 'dubbo',
          side: 'provider',
          appId,
          regionId,
          namespaceId,
          origin,
        }}
      />
    },
    {
      tab: 'Istio',
      key: 'istio',
      content: <ServiceList
        style={{ marginTop: 8 }}
        onCall={(totalSize) => setIstioTotalSize(totalSize)}
        condition={{
          serviceType: 'istio',
          side: 'provider',
          appId,
          regionId,
          namespaceId,
          origin,
        }}
      />
    },
  ];

  const getTabs = () => {
    const newTabs = [];
    forEach(tabs, tab => {
      if (includes(rpcTypes, tab.key)) {
        newTabs.push(tab);
      }
    });
    return newTabs;
  };

  const totalObj = {
    dubbo: dubboToalSize,
    springCloud: scToalSize,
    istio: isTioToalSize,
  };
  const firstTab = head(getTabs());

  return (
    <If condition={firstTab}>
      <Collapse defaultExpandedKeys={['0']}>
        <Panel title={intl('widget.app.service_list', { n: currentTab ? totalObj[currentTab] : totalObj[firstTab.key] })}>
          <Tab shape="wrapped" onChange={(tab) => setCurrentTab(tab)}>
            {map(getTabs(), n => (
              <Tab.Item title={n.tab} key={n.key}>
                {n.content}
              </Tab.Item>
            ))}
          </Tab>
        </Panel>
      </Collapse>
    </If>
  );
};

ServiceListComp.propTypes = {
  rpcTypes: PropTypes.arrayOf(PropTypes.any),
};

export default ServiceListComp;
