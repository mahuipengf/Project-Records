import React, { useState, useEffect } from 'react';
import services from 'services';
import PropTypes from 'prop-types';
import Wline from 'containers/Chart/Wline';
import { forIn, forEach, find, isEmpty, replace, keys, get } from 'lodash';
import { Loading, Empty } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';

const mapNumber = (value) => {
  if (typeof value === 'number') {
    if (value >= 1000) return `${Math.round(value / 100) / 10}k`;
    else return value;
  } else {
    return value;
  }
};

const mapPercent = (value, total) => {
  return `${Math.round(value / total * 1000) / 10}%`;
};

const Observability = (props) => {
  const [loading, setLoading] = useState(false);
  const [currentData, setCurrentData] = useState([]);
  const intl = useIntl();
  const { AppId, Region } = props;
  useEffect(() => {
    setLoading(true);
    fetchData();
    let interval;
    if (!interval) {
      interval = setInterval(() => {
        fetchData();
      }, 10000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    const Data = await services.QueryAppSummaryMetricsOverview({
      params: {
        AppId,
        Region
      }
    });

    const WlineData = [
      { name: intl('widget.home.total_count'), key: 'Qps', data: [] },
      { name: intl('widget.msc.throw_name', { name: 'QPS' }), key: 'ExpQps', data: [] },
    ];
    forEach(Data.CurMetrics || [], d => {
      const Time = d.Timestamp;
      forIn(d.TagValues || {}, (tag, key) => {
        if (!find(WlineData, { key })) {
          WlineData.push({ name: key === 'null' ? intl('widget.app.canary_no_tag') : key, key, data: [] });
          WlineData.push({ name: intl('widget.msc.throw_name', { name: key }), key: `exp_${intl('widget.app.canary_no_tag')}`, data: [] });
        }
      });
      forEach(WlineData, item => {
        if (d[item.key] === 0 || d[item.key] || d[item.key] === null) {
          if (d[item.key] === -1) return item.data.push([Time, undefined]);
          else return item.data.push([Time, Number(d[item.key])]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[item.key])) {
          if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.TagValues[item.key].qps)]);
          else return item.data.push([Time, d.TagValues[item.key].qps]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[replace(item.key, 'exp_', '')])) {
          if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.TagValues[replace(item.key, 'exp_', '')].expQps)]);
          else return item.data.push([Time, d.TagValues[replace(item.key, 'exp_', '')].expQps]);
        }
      });
    });
    // console.log('WlineData', WlineData);

    const CurMetricsFm = {
      ExpQps: mapNumber(get(Data, 'CurMetricsFm.ExpQps')),
      Qps: mapNumber(get(Data, 'CurMetricsFm.Qps')),
      TagValues: get(Data, 'CurMetricsFm.TagValues', {}),
    };
    setCurrentData({
      WlineData,
      CurMetricsFm,
    });
    setLoading(false);
  };
  return (
    <Loading visible={loading} style={{ width: '100%' }}>
      <div style={{ border: '1px solid #eee', boxShadow: '0 0 5px #eee', padding: '8px 16px 0 16px' }}>
        <div>
          <span style={{ lineHeight: '32px', fontWeight: 500 }}>{intl('widget.msc.qps_data')}</span>
          <span>{intl('widget.app_qps_time_period_five_minutes')}</span>
        </div>
        <div style={{ display: 'flex', }}>
          <div style={{ borderRight: '1px solid #eee', width: 160, minWidth: 160, marginRight: 16, marginBottom: 8, padding: '8px 16px 0 0' }}>
            <div style={{ color: '#777', marginBottom: 8 }}>{intl('widget.home.error_count_total_count')}</div>
            <span style={{ fontSize: 18, paddingRight: 2, color: get(currentData, 'CurMetricsFm.ExpQps', 0) === 0 ? '' : 'red' }}>{get(currentData, 'CurMetricsFm.ExpQps', 0) === -1 ? 0 : get(currentData, 'CurMetricsFm.ExpQps', 0)}</span>
            /
            <span style={{ paddingLeft: 2 }}>{get(currentData, 'CurMetricsFm.Qps', 0)}</span>
          </div>
          <div style={{ display: 'flex', padding: '8px 16px 0 0', overflowX: 'scroll', }}>
            <If condition={!isEmpty(get(currentData, 'CurMetricsFm.TagValues', {}))}>
              <For index="index" each="item" of={keys(get(currentData, 'CurMetricsFm.TagValues', {}))}>
                <div key={index} style={{ display: 'inline-block', width: 100, minWidth: 100 }}>
                  <div style={{ color: '#777', marginBottom: 8 }}>{item === 'null' ? intl('widget.app.canary_no_tag') : item}</div>
                  <span style={{ fontSize: 18, paddingRight: 2, color: mapNumber(currentData.CurMetricsFm.TagValues[item].expQps) === 0 ? '' : 'red' }}>{mapNumber(currentData.CurMetricsFm.TagValues[item].expQps || 0)}</span>
                  /
                  <span style={{ paddingLeft: 2 }}>{mapNumber(currentData.CurMetricsFm.TagValues[item].qps)}</span>
                </div>
              </For>
            </If>
            <If condition={isEmpty(get(currentData, 'CurMetricsFm.TagValues', {}))}>
              <div style={{ textAlign: 'center' }}>{intl('widget.common.no_data')}</div>
            </If>
          </div>
        </div>
      </div>

      <Wline
        data={currentData.WlineData || []}
        height={200}
        style={{ padding: '16px 0' }}
        option={{
          legend: {
            position: 'bottom',
            align: 'center',
          },
          padding: [12, 16, 48, 32],
          tooltip: {
            valueFormatter: (value, data, index, rawData) => {
              if (index === 0) return value || 0;
              const item = find(rawData, { name: intl('widget.home.total_count') });
              if (!item) {
                return value || 0;
              }
              return `${value} (${mapPercent(value || 0, item.value || 0)})`;
            },
          }
        }}
      />
    </Loading>
  );
};
Observability.propTypes = {
  AppId: PropTypes.string,
  Region: PropTypes.string,
};

export default Observability;
