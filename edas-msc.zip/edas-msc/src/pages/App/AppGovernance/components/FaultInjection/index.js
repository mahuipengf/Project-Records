import React, { useState } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { TableContainer, CopyContent, Empty, Button, Message, Balloon, Icon } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import Status from 'components/Status/CommonStatus';
import { upperFirstData1 } from 'utils/transfer-data';
import FaultInjectionEdit from './FaultInjectionEdit';
import { get, join, split } from 'lodash';
import { timeFmt } from 'utils';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import FaultInjectionInfo from './FaultInjectionInfo';

function FaultInjection(props) {
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const intl = useIntl();
  const { Region, AppId, tableUniqueKey } = props;
  const [isEditShow, setIsEditShow] = useState(false);
  const [isInfoShow, setIsInfoShow] = useState(false);
  const [currentValue, setCurrentValue] = useState({});

  const protocol = {
    DUBBO: 'Dubbo',
    SPRING_CLOUD: 'Spring Cloud',
    istio: intl('widget.service.service_mesh'),
  };

  const fetchData = async (params) => {
    const { result: List, totalSize: TotalCount } = await services.GetFaultInjectionRule({
      params: {
        ...params,
        protocol: 'istio',
        AppId,
        Region,
      }
    });
    return {
      Data: upperFirstData1(List),
      TotalCount,
    };
  };

  const columns = [
    {
      key: 'Name',
      title: intl('widget.authentication.rule_name'),
      dataIndex: 'Name',
      cell: (val, index, record) => (
        <CopyContent text={val}>
          {val}
        </CopyContent>
      ),
    },
    {
      key: 'Enable',
      title: intl('widget.common.state'),
      dataIndex: 'Enable',
      cell: val => <Status value={val} intl={intl} />
    },
    {
      key: 'Protocol',
      title: intl('widget.route.frame_type'),
      dataIndex: 'Protocol',
      cell: val => (
        <Empty value={val}>
          {protocol[val] || '--'}
        </Empty>
      ),
    },
    {
      key: 'Tag',
      title: intl('widget.app.tag'),
      dataIndex: 'Tag',
      cell: val => val === 'default' ? intl('widget.msc.default') : val,
    },
    {
      key: 'SourceAppName',
      title: intl('widget.msc.source_type'),
      dataIndex: 'SourceAppName',
      cell: (val, index, record) => {
        const sourceAppName = get(record, 'RouteRules[0].sourceAppName', []);
        if (sourceAppName[0] === '*') return intl('widget.msc.all_app');
        return join(sourceAppName, ', ');
      }
    },
    {
      key: 'FaultType',
      title: intl('widget.msc.fault_type'),
      dataIndex: 'FaultType',
      cell: (val, index, record) => {
        const type = {
          abort: intl('widget.msc.fault_type_abort'),
          delay: intl('widget.msc.fault_type_delay'),
        };
        return type[get(record, 'RouteRules[0].faultType')] || '--';
      },
    },
    {
      key: 'Percentage',
      title: (
        <React.Fragment>
          <span>{intl('widget.route.streaming_percentage')}</span>
          <Balloon align="t" trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />} closable={false}>
            {intl.html('widget.msc.percent_hint')}
          </Balloon>
        </React.Fragment>
      ),
      dataIndex: 'Percentage',
      cell: (val, index, record) => {
        const percentage = get(record, 'RouteRules[0].percentage');
        if (percentage) return `${percentage}%`;
        return '--';
      }
    },
    {
      key: 'Config',
      title: intl('widget.msc.config'),
      dataIndex: 'Config',
      cell: (val, index, record) => {
        const config = get(record, 'RouteRules[0].config');
        const faultType = get(record, 'RouteRules[0].faultType');
        const type = {
          abort: intl('widget.msc.fault_type_abort_config', { config }),
          delay: intl('widget.msc.fault_type_delay_config', { config: split(config, ':')[1] / 1000 }),
        };
        return type[faultType] || '--';
      }
    },
    {
      key: 'GmtModified',
      title: intl('widget.msc.update_time'),
      dataIndex: 'GmtModified',
      cell: value => <Empty value={value}>{timeFmt(value, 'YYYY/MM/DD HH:mm')}</Empty>,
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (val, index, record) => (
        <Actions expandTriggerType="hover">
          <LinkButton key="1" onClick={() => handleEdit(record)}>{intl('widget.common.edit')}</LinkButton>
          <If condition={record.Enable}>
            <LinkButton key="3" onClick={() => handleClose(record)}>{intl('widget.common.close1')}</LinkButton>
          </If>
          <If condition={!record.Enable}>
            <LinkButton key="2" onClick={() => handleOpen(record)}>{intl('widget.common.open1')}</LinkButton>
          </If>
          <LinkButton key="4" onClick={() => handleDelete(record)}>{intl('widget.common.delete')}</LinkButton>
        </Actions>
      ),
      visible: true,
    },
  ];

  const handleClose = (record) => {
    DialogAlert({
      title: intl('widget.common.close1'),
      content: intl.html('widget.common.close_confirm', { name: record.Name }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.UpdateFaultInjectionRule({
          params: {
            Protocol: record.Protocol,
            Enable: !record.Enable,
            AppId: record.AppId,
            Id: record.Id,
            Region: record.Region,
            Name: record.Name,
            Tag: record.Tag,
            Rules: get(record, 'RouteRules[0]')
          },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.close_successful'));
        setFetchDataTime(Date.now());
      })
    });
  };
  const handleOpen = (record) => {
    DialogAlert({
      title: intl('widget.common.open1'),
      content: intl.html('widget.common.open_confirm', { name: record.Name }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.UpdateFaultInjectionRule({
          params: {
            Protocol: record.Protocol,
            Enable: !record.Enable,
            AppId: record.AppId,
            Id: record.Id,
            Region: record.Region,
            Name: record.Name,
            Tag: record.Tag,
            Rules: get(record, 'RouteRules[0]')
          },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.open_successful'));
        setFetchDataTime(Date.now());
      })
    });
  };

  // 删除
  const handleDelete = (record) => {
    DialogAlert({
      title: intl('widget.common.delete'),
      content: intl.html('widget.common.delete_confirm', { name: record.Name }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.DeleteFaultInjectionRule({
          params: { Id: record.Id, Region: record.Region },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        resolve();
        Message.success(intl('widget.common.delete_successful'));
        setFetchDataTime(Date.now());
      })
    });
  };

  const openInfo = (record) => {
    setCurrentValue({ ...record });
    setIsInfoShow(true);
  };

  const handleEdit = (record = { Region, AppId }) => {
    setCurrentValue({ ...record });
    setIsEditShow(true);
  };

  const search = {
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };
  return (
    <React.Fragment>
      <TableContainer
        // style={{ marginTop: 16 }}
        fetchData={fetchData}
        primaryKey="Id"
        columns={columns}
        search={search}
        refreshIndex={fetchDataTime}
        operation={() => (
          <Button type="primary" onClick={() => handleEdit()}>
            {intl('widget.authentication.create_rule')}
          </Button>
        )}
        emptyContent={
          <div >
            <span className="link-primary" onClick={() => handleEdit()}>
              {intl('widget.route.no_data_go_create')}
            </span>
          </div>
        }
      />
      <FaultInjectionEdit
        visible={isEditShow}
        onClose={() => setIsEditShow(false)}
        onOk={() => {
          setIsEditShow(false);
          setFetchDataTime(Date.now());
        }}
        value={currentValue}
      />
      <FaultInjectionInfo
        visible={isInfoShow}
        value={currentValue}
        onClose={() => setIsInfoShow(false)}
      />
    </React.Fragment>
  );
}

FaultInjection.propTypes = {
  Region: PropTypes.string,
  AppId: PropTypes.string,
};

export default FaultInjection;
