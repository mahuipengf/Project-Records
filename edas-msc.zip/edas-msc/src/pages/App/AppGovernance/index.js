import React, { useEffect, useState } from 'react';
import { Tab } from '@ali/cn-design';
import { map, filter } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import AuthenticationList from './components/AuthenticationList';
// import TagList from './TagList';
import CanaryInfo from 'pages/App/AppList/components/CanaryInfo';
import { getParams } from 'utils';
import NewRouteTagList from 'pages/RouteManage/NewRouteTagList';
import { changeQuery } from 'utils/query';
import LoadBalance from './components/LoadBalance';
import AZ from './components/AZ';
import FaultInjection from './components/FaultInjection';
import Timeout from './components/Timeout';
import Retry from './components/Retry';
import Observability from './components/Observability';
import RoleHoc from 'containers/RoleHoc';

const AppGovernance = () => {
  const intl = useIntl();
  const [searchValues] = useGlobalState('searchValues');
  const [tag, setTag] = useState(getParams('type'));
  const tabs = [
    {
      tab: 'widget.app.tag_route',
      key: 'tag',
      visible: true,
    },
    {
      tab: 'widget.app.authentication',
      key: 'authentication',
      visible: true,
    },
    {
      tab: 'widget.app.canary',
      key: 'canary',
      visible: true,
    },
    {
      tab: 'widget.mse.load_balance',
      key: 'load_balance',
      visible: getParams('accessType') === 'ASM',
    },
    {
      tab: 'widget.mse.fault_injection',
      key: 'fault_injection',
      visible: getParams('accessType') === 'ASM',
    },
    {
      tab: 'widget.mse.service_timeout',
      key: 'service_timeout',
      visible: getParams('accessType') === 'ASM',
    },
    {
      tab: 'widget.mse.retry',
      key: 'retry',
      visible: getParams('accessType') === 'ASM',
    },
    {
      tab: getParams('accessType') === 'ASM' ? 'widget.msc.AZ_istio' : 'widget.msc.AZ_java',
      key: 'AZ',
      visible: true,
    },
  ];

  const tabComp = {
    tag: <NewRouteTagList />,
    authentication: <AuthenticationList />,
    canary: <CanaryInfo value={searchValues} />,
    load_balance: <LoadBalance Region={searchValues.regionId} AppId={searchValues.appId} />,
    AZ: <AZ Region={searchValues.regionId} AppId={searchValues.appId} />,
    fault_injection: <FaultInjection Region={searchValues.regionId} AppId={searchValues.appId} />,
    service_timeout: <Timeout Region={searchValues.regionId} AppId={searchValues.appId} />,
    retry: <Retry Region={searchValues.regionId} AppId={searchValues.appId} />,
  };

  const changeUrl = (value) => {
    setTag(value);
    changeQuery({ type: value });
  };

  return (
    <React.Fragment>
      <Observability Region={searchValues.regionId} AppId={searchValues.appId} />
      <Tab className="service-relation-tab" shape="capsule" defaultActiveKey={getParams('type') || 'tag'} style={{ marginBottom: 16 }}>
        {map(filter(tabs, item => item.visible), n => {
          return <Tab.Item title={intl(n.tab)} key={n.key} onClick={() => changeUrl(n.key)} />;
        })}
      </Tab>
      {tabComp[tag]}
    </React.Fragment>
  );
};

export default RoleHoc(AppGovernance);
