import AppList from './AppList';

export default AppList;
