import React, { useState } from 'react';
import PropTypes from 'prop-types';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { Message, Balloon, Button, Icon } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import Dialog from 'components/Dialog';
import services from 'services';
import { WIDGET_ID, IS_SAU_BUSINESS } from 'constants';
import Cookie from 'js-cookie';


const Events = (props) => {
  const intl = useIntl();
  const { record, setRefreshIndex } = props;
  const { appName, appId, regionId } = record;
  const [eventEmitter] = useGlobalState('eventEmitter');
  const [mscAccount] = useGlobalState('mscAccount');
  const [visible, setVisible] = useState(false);
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';
  let openHref = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn';
  let rechargeHref = 'https://usercenter2.aliyun.com/finance/fund-management/recharge';
  // const openEnterpriseHref = `https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn&orderType=UPGRADE&instanceId=synthetic_post_${mscAccount.UserId}`;
  if (aliyunSite === "INTL") {
    openHref =
      "https://common-buy-intl.alibabacloud.com/?commodityCode=mse_basic_public_intl";
    rechargeHref =
      "https://usercenter2-intl.aliyun.com/renew/manual?spm=5176.mse-ops.top-nav.ditem-ren.36c3142fCQOCud&expiresIn=&commodityCode=";
  }
  const handleDelete = () => {
    DialogAlert({
      title: intl('widget.common.delete'),
      content: intl.html('widget.app.has_instance_hint', { appName }),
      onOk: () => services.RemoveApplication({
        params: { appId, regionId }
      }).then((res) => {
        if (res) {
          Message.success(intl('widget.common.delete_successful'));
          setRefreshIndex(Date.now());
        } else {
          DialogAlert({
            title: intl('widget.common.tips'),
            content: intl('widget.app.has_instance_can_not_delete'),
          });
        }
      }),
      footerActions: ['ok', 'cancel']
    });
  };

  const handleGoToAppGovernance = () => {
    if (!((mscAccount.Status === 0 && mscAccount.TimeLeft > 0) || mscAccount.Status === 2)) {
      setVisible(true);
      return;
    }
    eventEmitter.emit(`${WIDGET_ID}:go-to-AppGovernance`, { ...record, type: 'canary' });
  };

  return (
    <Actions expandTriggerType="hover">
      <LinkButton key="3" onClick={handleGoToAppGovernance}>{intl('widget.app.canary')}</LinkButton>
      <If condition={!!record.instancesNumber}>
        <LinkButton key="4" onClick={handleDelete} disabled>
          <Balloon
            align="t"
            trigger={intl('widget.common.delete')}
            triggerType="hover"
          >
            {intl('widget.app.has_instance_can_not_delete')}
          </Balloon>

        </LinkButton>
      </If>
      <If condition={!record.instancesNumber}>
        <LinkButton key="4" onClick={handleDelete} >{intl('widget.common.delete')}</LinkButton>
      </If>
      <Dialog
        title={
          <div>
            <Icon type="warning" style={{ color: '#ffc440', marginRight: 8 }} />
            {intl('widget.common.tips')}
          </div>
        }
        visible={visible}
        onClose={() => setVisible(false)}
        style={{ width: 520 }}
        footer={[
          <React.Fragment>
            <If condition={mscAccount.Status === 0}>
              <Button type="primary">
                {intl.html('widget.msc.public_beta_to_commercialization_button')}
              </Button>
            </If>
            <If condition={mscAccount.Status === 1}>
              <Button type="primary">
                {intl.html('widget.msc.open_official_version', { openHref })}
              </Button>
            </If>
            <If condition={mscAccount.Status === 3} >
              <Button type="primary" style={{ padding: 0 }}>
                {intl.html('widget.msc.open_again', { rechargeHref })}
              </Button>
            </If>
          </React.Fragment>, <Button onClick={() => setVisible(false)}>{intl('widget.msc.think_again')}</Button>]}
      >
        <If condition={mscAccount.Status === 0 && mscAccount.TimeLeft === 0}>
          <div style={{ lineHeight: '24px' }}>{intl.html('widget.msc.account_status_0')}</div>
        </If>
        {/* 新用户 */}
        <If condition={mscAccount.Status === 1}>
          <div style={{ lineHeight: '24px' }}>{intl.html('widget.msc.account_status_1')}</div>
        </If>
        {/* 停用 */}
        <If condition={mscAccount.Status === 3}>
          <div style={{ lineHeight: '24px' }}>{intl.html('widget.msc.account_status_3', { rechargeHref })}</div>
        </If>
      </Dialog>
    </Actions >
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  setRefreshIndex: PropTypes.func,
};

export default Events;
