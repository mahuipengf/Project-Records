import React, { useImperativeHandle, forwardRef, useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { Form, Message, Loading, Switch, Balloon, Icon, Button } from '@ali/cn-design';
import confirm from 'components/Confirm';
import { Field } from '@alicloud/console-components';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { forEach, filter, sum, map, get, uniqueId, trim, assign, split, size, find, sumBy, isEmpty } from 'lodash';
import Rules from './Rules';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';
import TagTable from 'pages/App/AppList/components/CanaryInfo/TagTable';
import { mapConditions, mapConditionsFormData } from 'utils';

const CanaryEdit = (props, ref) => {
  const field = Field.useField();
  const { value = {}, setRefreshIndex, toggleModal } = props;
  const intl = useIntl();
  const { init, validate, setValues, getValue, getValues } = field;
  const [searchValues] = useGlobalState('searchValues');
  const [appServiceData, setAppServiceData] = useGlobalState('appServiceData');
  const [isLoading, setLoading] = useState(false);
  const [okLoading, setOkLoading] = useState(false);
  const rulesRef = useRef();
  const { appId, regionId, namespaceId } = assign({}, searchValues, value);
  const [serviceLoading, setServiceLoading] = useState(false);
  const [disableButton, setDisableButton] = useState(false);
  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (value.appId) {
      setServiceLoading(true);
      Promise.all([fetchDubboServiceList(value.appId), SpringCloudfetchServiceList(value.appId), fetchIstioServiceList(value.appId)]).then((res) => {
        setAppServiceData({
          dubbo: res[0],
          springCloud: res[1],
          istio: res[2],
        });
        setServiceLoading(false);
      });
    }
  }, [value.appId]);

  const fetchData = async () => {
    if (!appId) return;
    setLoading(true);
    const res = await services.GetCanaryStatus({
      params: { appId, regionId },
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        setDisableButton(true);
        callback();
      }
    });
    setLoading(false);
    let newRes = lowerFirstData(res) || [];
    const total = sum(map(newRes, item => size(item.instanceInfoList)));
    let totalRate = 0;
    // 处理实例比例
    newRes = map(newRes, (item, index) => {
      const instanceNum = size(item.instanceInfoList);
      if (index < newRes.length - 1) {
        const instanceRate = item.instanceRate === undefined ? Math.round((instanceNum * 100 / total)) : item.instanceRate;
        totalRate += instanceRate;
        return ({
          ...item,
          uid: uniqueId(),
          instanceRate,
          instanceNum,
        });
      }
      return ({
        ...item,
        uid: uniqueId(),
        instanceRate: 100 - totalRate,
        instanceNum,
      });
    });
    const newTagItem = find(newRes, item => !item.old) || {};
    const carryData = get(newTagItem, 'routePolicy.carryData', false);
    setValues({
      appId,
      tagList: newRes,
      rules: getRules(newRes),
      carryData
    });
  };

  // 处理路由规则
  const getRules = (data) => {
    const newTagItem = find(data, item => !item.old) || {};
    const scRules = get(newTagItem, 'routePolicy.scRules', []);
    const dubboArgRules = get(newTagItem, 'routePolicy.dubboArgRules', []);
    const istioRules = get(newTagItem, 'routePolicy.istioRules', []);
    const ScRule = map(scRules, item => ({
      ...item,
      uid: uniqueId(),
      conditions: mapConditions(item.restItems),
      protocol: 'springCloud'
    }));
    const IstioRule = map(istioRules, item => ({
      ...item,
      uid: uniqueId(),
      conditions: mapConditions(item.istioItems),
      protocol: 'istio'
    }));
    const dubboRule = map(dubboArgRules, item => {
      const { serviceName = '', version = '', group = '', methodName = '', paramTypes = [] } = item;
      return {
        ...item,
        method: `${serviceName}:${version}:${group}:${methodName}:${paramTypes}`,
        uid: uniqueId(),
        conditions: mapConditions(item.argumentItems),
        protocol: 'dubbo'
      };
    });
    const rules = [...ScRule, ...dubboRule, ...IstioRule];
    if (isEmpty(rules)) {
      setDisableButton(true);
    } else {
      setDisableButton(false);
    }
    return rules;
  };

  const fetchDubboServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: namespaces.regionId || regionId,
      namespace: namespaces.namespaceId || namespaceId,
      serviceType: 'dubbo',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || regionId,
        namespace: namespaces.namespaceId || namespaceId,
        ...namespaces,
        serviceType: 'dubbo',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    const newData = map(data || [], item => {
      const newMethods = map(item.methods, child => {
        return ({
          ...child,
          key: `${child.name}:${child.parameterTypes}`,
          value: `${child.name}:${child.parameterTypes}`,
          label: `${child.name}(${child.parameterTypes || []})`,
        });
      });
      return ({
        ...item,
        methods: newMethods,
        value: `${item.serviceName}:${item.version}:${item.group}`,
        key: `${item.serviceName}:${item.version}:${item.group}`,
        label: `${item.serviceName}:${item.version}:${item.group}`,
      });
    });
    return newData;
  };

  const SpringCloudfetchServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: namespaces.regionId || regionId,
      namespace: namespaces.namespaceId || namespaceId,
      serviceType: 'springCloud',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || regionId,
        namespace: namespaces.namespaceId || namespaceId,
        ...namespaces,
        serviceType: 'springCloud',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    return data;
  };

  const fetchIstioServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: searchValues.regionId,
      namespace: searchValues.namespaceId,
      serviceType: 'istio',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || searchValues.regionId,
        namespace: namespaces.namespaceId || searchValues.namespaceId,
        serviceType: 'istio',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    return data;
  };

  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        console.log(errors, values);
        if (errors) return reject(errors);
        const newTagItem = find(values.tagList, item => !item.old) || {};
        const newTagRate = get(newTagItem, 'rate');
        const newTagVersion = get(newTagItem, 'version') === '_base' ? intl('widget.app.canary_no_tag') : get(newTagItem, 'version');
        if (newTagRate === 100 && !isEmpty(values.rules)) {
          Message.error(intl.html('widget.app.new_tag_100_cant_add_rule', { tag: newTagVersion || '--' }));
          reject();
          return;
        } else if (!isEmpty(values.rules)) {
          const { errors: Errors } = await rulesRef.current.validator();
          if (Errors) return reject();
        }
        const { namespaces = {} } = values;
        let params = {
          regionId,
          namespaceId,
          ...namespaces,
          appId: values.appId,
          tagList: values.tagList,
          carryData: values.carryData,
        };

        const ScRulesJson = filter(values.rules || [], item => item.protocol === 'springCloud');
        const DubboArgRulesJson = filter(values.rules || [], item => item.protocol === 'dubbo');
        const IstioRulesJson = filter(values.rules || [], item => item.protocol === 'istio');
        params = {
          ...params,
          ScRulesJson: map(ScRulesJson, item => ({
            ...item,
            triggerPolicy: values.triggerPolicy,
            restItems: mapConditionsFormData(item.conditions || [], item.protocol)
          })),
          DubboArgRulesJson: map(DubboArgRulesJson, item => {
            const [serviceName, version, group, methodName, paramTypes = ''] = split(item.method, ':');
            return {
              ...item,
              triggerPolicy: values.triggerPolicy,
              serviceName,
              version,
              group,
              methodName,
              paramTypes: split(paramTypes, ','),
              argumentItems: mapConditionsFormData(item.conditions || [], item.protocol),
            };
          }),
          IstioRulesJson: map(IstioRulesJson, item => ({
            ...item,
            triggerPolicy: values.triggerPolicy,
            istioItems: mapConditionsFormData(item.conditions || [], item.protocol)
          }))
        };
        const newParams = {
          regionId,
          namespaceId,
          ...namespaces,
          appId: values.appId,
          rules: handleTranslateData(params) // 需要转换数据为指定格式
        };
        setOkLoading(true);
        await services.ApplyCanaryPolicy({
          data: newParams,
          customErrorHandle: (err, response, callback) => {
            reject();
            setOkLoading(false);
            callback();
          }
        });

        Message.success(intl('widget.common.update_successful'));
        resolve();
        setOkLoading(false);
        onCloseModal();
        setRefreshIndex(Date.now());
      });
    });
  };

  const handleTranslateData = (params, bool) => {
    const newParams = {};
    forEach(params.tagList, item => {
      newParams[item.version] = {
        rate: item.rate,
        carryData: !item.old ? params.carryData : undefined,
        remove: bool && !item.old ? true : undefined,
        rules: !item.old
          ? {
            dubbo: params.DubboArgRulesJson || [],
            springcloud: params.ScRulesJson || [],
            istio: params.IstioRulesJson || [],
          }
          : undefined,
      };
    });
    return newParams;
  };

  // 针对springCloud，dubbo, istio需要区分判断数据
  const handleValidatorRules = (rule, val, callback) => {
    forEach(val, item => {
      if (!item.condition || isEmpty(item.conditions)) {
        callback(intl('widget.route.rule_not_complete'));
        return;
      }
      forEach(item.conditions, child => {
        if (item.protocol === 'istio') {
          if (!child.type || !child.name || !child.cond || (!child.value && child.value !== 0)) {
            callback(intl('widget.route.condition.rule_not_complete'));
            return;
          }
        }
        if (item.protocol === 'springCloud') {
          if (!child.type || !child.name || !child.cond || (!child.value && child.value !== 0)) {
            callback(intl('widget.route.condition.rule_not_complete'));
            return;
          }
        }
        if (item.protocol === 'dubbo') {
          if (!(child.index >= 0) || !child.cond || (!child.value && child.value !== 0)) {
            callback(intl('widget.route.condition.rule_not_complete'));
          }
        }
      });
    });
    callback();
  };

  const handleValidatorTagList = (rule, val, callback) => {
    if (find(val, item => (!item.rate && item.rate !== 0))) {
      callback(intl('widget.route_tag.tag_table_no_complete'));
    }
    const total = sumBy(val, 'rate');
    if (total !== 100) {
      callback(intl('widget.route_tag.tag_table_must_100'));
    }
    const newTagItem = find(val, { old: false, rate: 100 }) || {};
    if (total === 100 && !isEmpty(newTagItem) && !disableButton) {
      const newTagVersion = get(newTagItem, 'version') === '_base' ? intl('widget.app.canary_no_tag') : get(newTagItem, 'version');
      Message.error(intl.html('widget.app.new_tag_100_cant_add_rule', { tag: newTagVersion || '--' }));
    }
    callback();
  };

  const onCloseModal = () => toggleModal({ visible: false });

  const openFinishModal = () => {
    const newTagItem = find(getValue('tagList'), { old: false }) || {};
    const newTagVersion = get(newTagItem, 'version') === '_base' ? intl('widget.app.canary_no_tag') : get(newTagItem, 'version');
    confirm({
      title: intl('widget.common.tips'),
      content: intl.html('widget.app.canary.gray_100_clear_rules', { tag: newTagVersion || '--' }),
      onOk: async () => {
        const tagList = map(getValue('tagList'), item => !item.old ? { ...item, rate: 100, remove: true } : { ...item, rate: 0 });
        const params = {
          appId: value.appId,
          rules: handleTranslateData({ tagList }, true),
          regionId,
          namespaceId,
        };
        await services.ApplyCanaryPolicy({
          data: params,
          customErrorHandle: (err, response, callback) => {
            callback();
          }
        });
        onCloseModal();
        setRefreshIndex(Date.now());
      }
    });
  };

  const openDeleteGrayModal = () => {
    const newTagItem = find(getValue('tagList'), { old: false }) || {};
    const newTagVersion = get(newTagItem, 'version') === '_base' ? intl('widget.app.canary_no_tag') : get(newTagItem, 'version');
    confirm({
      title: intl('widget.common.tips'),
      content: intl.html('widget.app.canary.gray_0_clear_rules', { tag: newTagVersion || '--' }),
      onOk: async () => {
        const tagList = map(getValue('tagList'), item => !item.old ? { ...item, rate: 0, remove: true } : { ...item, rate: 100 });
        const params = {
          appId: value.appId,
          rules: handleTranslateData({ tagList }, true),
          regionId,
          namespaceId,
        };
        await services.ApplyCanaryPolicy({
          data: params,
          customErrorHandle: (err, response, callback) => {
            callback();
          }
        });
        onCloseModal();
        setRefreshIndex(Date.now());
      }
    });
  };

  const total = size(map(getValues().tagList || [], item => size(item.instanceInfoList)));

  return (
    <React.Fragment>
      <div className="config_list_editform" style={{ marginBottom: 64 }}>
        <Loading visible={isLoading} style={{ width: '100%' }}>
          <Form field={field} labelAlign="left">
            <Form.Item
              label={intl('widget.route.app_instance_n', { n: total })}
            >
              <TagTable
                {...init('tagList', {
                  initValue: [],
                  rules: [
                    {
                      required: true,
                      message: intl('widget.route_tag.app_no_tag'),
                    },
                    {
                      validator: handleValidatorTagList
                    }
                  ],
                })}
                carryData={getValue('carryData')}
              />
            </Form.Item>
            <Form.Item label={intl('widget.route.business_flow')} required>
              <Rules
                {...init('rules', {
                  initValue: [],
                  rules: [
                    {
                      required: true,
                      message: intl('widget.route.flow_rule_error'),
                    },
                    {
                      validator: handleValidatorRules
                    }
                  ],
                })}
                tag={getValue('tag')}
                ruleId={value.id}
                ref={rulesRef}
                serviceLoading={serviceLoading}
              />
            </Form.Item>
            {/* 服务网格不支持 */}
            <If condition={!isEmpty(appServiceData.springCloud) || !isEmpty(appServiceData.dubbo)}>
              <Form.Item
                label={
                  <React.Fragment>
                    <span>{intl('widget.route.link_delivery')}</span>
                    <span style={{ color: '#777' }}>{intl('widget.app.canary.link_delivery_info')}</span>
                    <If condition={searchValues.protocol === 'SPRING_CLOUD'}>
                      <Balloon trigger={<Icon type="help" />} closable={false}>
                        {intl.html('widget.route.sc_link_delivery_hint')}
                      </Balloon>
                    </If>
                    <If condition={searchValues.protocol === 'DUBBO'}>
                      <Balloon trigger={<Icon type="help" />} closable={false}>
                        {intl.html('widget.route.dubbo_link_delivery_hint')}
                      </Balloon>
                    </If>
                  </React.Fragment>
                }
              >
                <Switch
                  {...init('carryData', {
                    initValue: false,
                    valueName: 'checked',
                  })}
                />
              </Form.Item>
            </If>
          </Form>
        </Loading>
      </div>
      <div className="modal_slidepanel__footer" style={{ zIndex: 100 }}>
        <Button type="primary" style={{ marginRight: 8 }} onClick={handleSubmit} loading={okLoading}>
          {intl('widget.common.ok')}
        </Button>
        {/* <Button type="secondary" style={{ marginRight: 8 }} onClick={openFinishModal} disabled={disableButton}>
          {intl('widget.app.canary.publish_finish')}
        </Button>
        <Button type="normal" warning style={{ marginRight: 8 }} onClick={openDeleteGrayModal} disabled={disableButton}>
          {intl('widget.app.canary.delete_gray_rule')}
        </Button> */}
        <Button type="normal" onClick={onCloseModal}>
          {intl('widget.common.cancel')}
        </Button>
      </div>
    </React.Fragment>
  );
};

const RefEditForm = forwardRef(CanaryEdit);

CanaryEdit.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  setRefreshIndex: PropTypes.number,
  toggleModal: PropTypes.func,
};

export default RefEditForm;
