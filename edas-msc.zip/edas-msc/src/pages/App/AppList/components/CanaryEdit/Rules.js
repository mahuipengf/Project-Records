import React, { useState, useEffect, useImperativeHandle, useRef, forwardRef } from 'react';
import { uniqueId, map, filter } from 'lodash';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import { Icon } from '@ali/cn-design';
import CommonEvent from 'components/CommonEvent';
import RouteForm from 'pages/RouteManage/components/RouteForm';

const RulesRef = (props, ref) => {
  const { value = [], onChange, ruleId, serviceLoading } = props;
  const intl = useIntl();
  const [list, setList] = useState(value);
  const rulesRef = useRef();
  const formRef = useRef();

  useEffect(() => {
    setList(value);
  }, [value]);

  useImperativeHandle(ref, () => ({
    validator
  }));

  const handleAdd = () => {
    const newList = [...list, { uid: -uniqueId(), condition: 'AND' }];
    onChange(newList);
  };

  const handleDelete = (uid) => {
    const newList = filter(list, item => item.uid !== uid);
    onChange(newList);
  };

  const validator = async () => {
    const res = formRef.current && await formRef.current.handleSubmit();
    return res;
  };

  const handleChange = (val) => {
    const newList = map(list, item => item.uid === val.uid ? val : item);
    onChange(newList);
  };

  return (
    <div ref={rulesRef}>
      <For each="item" index="index" of={list}>
        <div className="common-box" key={index} style={{ paddingBottom: 0 }}>
          <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between' }}>
            <span>{intl('widget.app.flow_rule', { n: index + 1 })}</span>
            <Icon type="close" size="xs" className="common-icon" onClick={() => handleDelete(item.uid)} />
          </div>
          <RouteForm value={item} key={item.uid} ref={formRef} onChange={handleChange} ruleId={ruleId} serviceLoading={serviceLoading} style={{ paddingTop: 16 }} />
        </div>
      </For>
      <div className="common-box" style={{ padding: 16 }}>
        <CommonEvent onClick={handleAdd} text={intl('widget.route.add_new_flow_rule')} />
      </div>
    </div>
  );
};

const RefRules = forwardRef(RulesRef);

RulesRef.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  tag: PropTypes.string,
  onChange: PropTypes.func,
  ruleId: PropTypes.number,
  serviceLoading: PropTypes.bool,
};

export default RefRules;
