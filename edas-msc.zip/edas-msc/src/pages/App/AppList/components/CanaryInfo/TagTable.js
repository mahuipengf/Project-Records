import React, { useState, useEffect } from 'react';
import { useIntl } from '@ali/widget-hooks';
import { Table, NumberPicker } from '@ali/cn-design';
import { map, get } from 'lodash';
import PropTypes from 'prop-types';
import { timeFmt } from 'utils';

const TagTable = (props) => {
  const { value, onChange, show } = props;
  const [tagList, setTagList] = useState(value);
  const intl = useIntl();

  useEffect(() => {
    setTagList(value || []);
  }, [value]);

  const handleChange = (uid, obj) => {
    const newData = map(tagList, item => item.uid === uid ? ({ ...item, ...obj }) : item);
    onChange && onChange(newData);
  };

  const rateRender = (val, index, record) => (
    <React.Fragment>
      <If condition={show}>{val}</If>
      <If condition={!show}>
        <NumberPicker
          value={val || 0}
          onChange={(v) => handleChange(record.uid, { rate: v || 0 })}
          max={100}
          min={0}
          style={{ width: '100%' }}
        />
      </If>
    </React.Fragment>
  );

  return (
    <Table
      dataSource={tagList}
    >
      <Table.Column
        title={intl('widget.route.tag')}
        dataIndex="version"
        cell={(val, index, record) => (
          <span>
            <span style={{ marginRight: 4 }}>{val === '_base' ? intl('widget.app.canary_no_tag') : val}</span>
            <If condition={record.status}>{intl('widget.common.brackets', { text: record.status })}</If>
          </span>
        )}
      />
      <Table.Column
        title={intl('widget.route.link_delivery')}
        dataIndex="carryData"
        cell={(val, index, record) => {
          if (record.old) return '--';
          const carryData = get(record, 'routePolicy.carryData', false);
          return carryData ? intl('widget.common.yes') : intl('widget.common.no');
        }}
      />
      <Table.Column title={intl('widegt.route_tag.instance_number')} dataIndex="instanceNum" />
      <Table.Column title={intl('widget.app.instance_rate')} dataIndex="instanceRate" />
      <Table.Column
        title={intl('widget.app.canary_remark_time')}
        dataIndex="updateTime"
        cell={(val, index, record) => {
          if (record.old) return '--';
          return val ? timeFmt(val, 'YYYY-MM-DD HH:mm:ss') : '--';
        }}
      />
      <Table.Column
        title={intl('widget.route.flow_rate1', { n: '%' })}
        dataIndex="rate"
        cell={rateRender}
      />
    </Table>
  );
};

TagTable.propTypes = {
  onChange: PropTypes.func,
  show: PropTypes.bool,
  value: PropTypes.arrayOf(PropTypes.any),
};

export default TagTable;
