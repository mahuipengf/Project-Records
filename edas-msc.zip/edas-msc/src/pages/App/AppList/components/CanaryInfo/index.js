import React, { useEffect, useState, useRef } from 'react';
import services from 'services';
import TagTable from './TagTable';
import { map, size, uniqueId, find, get, isEmpty, forEach, sum } from 'lodash';
import { lowerFirstData } from 'utils/transfer-data';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import CommonEvent from 'components/CommonEvent';
import ConditionList from 'containers/ConditionList';
import DataFields from 'components/DataFields';
import { Empty, modelDecorator, Loading, Button } from '@ali/cn-design';
import confirm from 'components/Confirm';
import CanaryEdit from 'pages/App/AppList/components/CanaryEdit';
import { mapConditions } from 'utils';

const CanaryInfo = ({ value = {}, toggleModal }) => {
  const editForm = useRef(null);
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [disableButton, setDisableButton] = useState(false);

  const intl = useIntl();
  useEffect(() => {
    fetchCanaryStatus();
  }, []);

  const fetchCanaryStatus = async () => {
    const { appId, regionId } = value;
    if (!appId) return;
    setLoading(true);
    const res = await services.GetCanaryStatus({
      params: { appId, regionId },
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        setDisableButton(true);
        const code = get(err, 'code');
        const Message = get(err, 'response.Message');
        if (Number(code) === 400) {
          setMessage(Message);
          throw new Error();
        } else {
          callback();
        }
      }
    });
    setLoading(false);
    let newRes = lowerFirstData(res) || [];
    const total = sum(map(newRes, item => size(item.instanceInfoList)));
    let totalRate = 0;
    newRes = map(newRes, (item, index) => {
      const instanceNum = size(item.instanceInfoList);
      if (index < newRes.length - 1) {
        const instanceRate = item.instanceRate === undefined ? Math.round((instanceNum * 100 / total)) : item.instanceRate;
        totalRate += instanceRate;
        return ({
          ...item,
          uid: uniqueId(),
          instanceRate,
          instanceNum,
        });
      }
      return ({
        ...item,
        uid: uniqueId(),
        instanceRate: 100 - totalRate,
        instanceNum,
      });
    });
    const newTagItem = find(newRes, item => !item.old) || {};
    const carryData = get(newTagItem, 'routePolicy.carryData', false);
    setData({ tagList: newRes, rules: getRules(newRes), carryData });
  };

  const handleEdit = () => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'xl',
      title: intl('widget.route.canary.edit'),
      content: (
        <CanaryEdit
          ref={editForm}
          value={value}
          toggleModal={toggleModal}
          setRefreshIndex={() => fetchCanaryStatus()}
        />
      ),
      onConfirm: null,
    });
  };

  const total = size(map(data.tagList || [], item => size(item.instanceInfoList)));
  const getRules = (newRes) => {
    const newTagItem = find(newRes, item => !item.old) || {};
    const scRules = get(newTagItem, 'routePolicy.scRules', []);
    const newScRules = map(scRules, item => ({
      ...item,
      restItems: mapConditions(item.restItems),
      protocol: 'springCloud'
    }));
    const dubboArgRules = get(newTagItem, 'routePolicy.dubboArgRules', []);
    const newDubboRules = map(dubboArgRules, item => ({
      ...item,
      restItems: mapConditions(item.argumentItems),
      protocol: 'dubbo'
    }));
    const istioRules = get(newTagItem, 'routePolicy.istioRules', []);
    const newIstioRules = map(istioRules, item => ({
      ...item,
      restItems: mapConditions(item.istioItems),
      protocol: 'istio',
    }));
    const rules = [...newScRules, ...newDubboRules, ...newIstioRules];
    if (isEmpty(rules)) {
      setDisableButton(true);
    } else {
      setDisableButton(false);
    }
    return rules;
  };
  const CONDITION = {
    OR: intl('widget.route.condition_or'),
    AND: intl('widget.route.condition_and')
  };
  const getItems = (item) => [
    {
      dataIndex: 'protocol',
      label: intl('widget.route.frame_type'),
      visible: true,
      render: (val) => {
        const protocol = {
          dubbo: 'Dubbo',
          springCloud: 'Spring Cloud',
          istio: intl('widget.service.service_mesh'),
        };
        return protocol[val];
      }
    },
    {
      dataIndex: 'condition',
      label: intl('widget.route.condition_mode'),
      visible: true,
    },
    {
      dataIndex: 'path',
      label: intl('widget.route.path'),
      visible: item.protocol === 'springCloud' || item.protocol === 'istio',
    },
    {
      dataIndex: 'service',
      label: intl('widget.app.service_method'),
      visible: item.protocol === 'dubbo',
      span: 24,
    },
    {
      dataIndex: 'restItems',
      label: intl('widget.route.condition_list'),
      visible: true,
      span: 24,
      render: (val) => <ConditionList value={val} show protocol={item.protocol} />
    },
  ];

  const openFinishModal = () => {
    const newTagItem = find(data.tagList || [], { old: false }) || {};
    const newTagVersion = get(newTagItem, 'version') === '_base' ? intl('widget.app.canary_no_tag') : get(newTagItem, 'version');
    confirm({
      title: intl('widget.common.tips'),
      content: intl.html('widget.app.canary.gray_100_clear_rules', { tag: newTagVersion || '--' }),
      onOk: async () => {
        const tagList = map(data.tagList || [], item => !item.old ? { ...item, rate: 100, remove: true } : { ...item, rate: 0 });
        const { appId, regionId } = value;
        const params = {
          appId,
          regionId,
          rules: handleTranslateData({ tagList }, true),
        };
        await services.ApplyCanaryPolicy({
          data: params,
          customErrorHandle: (err, response, callback) => {
            callback();
          }
        });
        fetchCanaryStatus();
      }
    });
  };

  const openDeleteGrayModal = () => {
    const newTagItem = find(data.tagList || [], { old: false }) || {};
    const newTagVersion = get(newTagItem, 'version') === '_base' ? intl('widget.app.canary_no_tag') : get(newTagItem, 'version');
    confirm({
      title: intl('widget.common.tips'),
      content: intl.html('widget.app.canary.gray_0_clear_rules', { tag: newTagVersion || '--' }),
      onOk: async () => {
        const tagList = map(data.tagList || [], item => !item.old ? { ...item, rate: 0, remove: true } : { ...item, rate: 100 });
        const { appId, regionId } = value;
        const params = {
          appId,
          regionId,
          rules: handleTranslateData({ tagList }, true),
        };
        await services.ApplyCanaryPolicy({
          data: params,
          customErrorHandle: (err, response, callback) => {
            callback();
          }
        });
        fetchCanaryStatus();
      }
    });
  };

  const handleTranslateData = (params, bool) => {
    const newParams = {};
    forEach(params.tagList, item => {
      newParams[item.version] = {
        rate: item.rate,
        carryData: !item.old ? params.carryData : undefined,
        remove: bool && !item.old ? true : undefined,
        rules: !item.old
          ? {
            dubbo: params.DubboArgRulesJson || [],
            springcloud: params.ScRulesJson || []
          }
          : undefined,
      };
    });
    return newParams;
  };

  return (
    <Loading visible={loading} style={{ width: '100%' }}>
      <If condition={isEmpty(data) && !!message}>
        {/* <Empty showIcon emptyMessage={<a target="_blank" href="https://help.aliyun.com/document_detail/184785.html">{intl('widget.route.see_how_to_use_tag_route_to_implement_canary')}</a>} /> */}
        <Empty showIcon emptyMessage={<div style={{ marginTop: 16 }}>{message}</div>} />
      </If>
      <If condition={isEmpty(data) && !message}>
        <Empty showIcon emptyMessage={<div style={{ marginTop: 16 }}>{intl.html('widget.route.see_how_to_use_tag_route_to_implement_canary')}</div>} />
      </If>
      <If condition={!isEmpty(data) && !message}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <h4 className="common-title" style={{ marginTop: 8, marginRight: 8 }}>{intl('widget.route.app_instance_n', { n: total })}</h4>
            <If condition={handleEdit}>
              <CommonEvent type="edit" text={intl('widget.common.edit')} onClick={handleEdit} />
            </If>
          </div>
          <div>
            <Button type="primary" style={{ marginRight: 8 }} onClick={openFinishModal} disabled={disableButton}>
              {intl('widget.app.canary.publish_finish')}
            </Button>
            <Button type="normal" warning style={{ marginRight: 8 }} onClick={openDeleteGrayModal} disabled={disableButton}>
              {intl('widget.app.canary.delete_gray_rule')}
            </Button>
          </div>
        </div>
        <TagTable show value={data.tagList || []} carryData={data.carryData} />
        <h4 className="common-title" style={{ width: 144, marginTop: 16 }}>{intl('widget.route.business_flow')}</h4>
        <If condition={!isEmpty(data.rules)}>
          <For each="item" index="index" of={data.rules}>
            <div key={index} className="common-box">
              <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.app.flow_rule', { n: index + 1 })}</div>
              <DataFields
                key={index}
                dataSource={{
                  condition: CONDITION[item.condition],
                  path: item.path,
                  service: `${item.serviceName || ''}:${item.version || ''}:${item.group || ''} / ${item.methodName || ''} (${item.paramTypes || ''})`,
                  restItems: item.restItems || [],
                  protocol: item.protocol,
                }}
                items={getItems(item)}
                style={{ padding: '8px 0', borderBottom: 0 }}
              />
            </div>
          </For>
        </If>
        <If condition={isEmpty(data.rules)}>
          <Empty showIcon emptyMessage={intl('widget.common.no_data')} />
        </If>
      </If>
    </Loading>
  );
};
CanaryInfo.propTypes = {
  toggleModal: PropTypes.func,
  value: PropTypes.arrayOf(PropTypes.any),
};
export default modelDecorator(CanaryInfo);
