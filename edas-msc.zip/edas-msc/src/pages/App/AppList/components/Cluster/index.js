import React from 'react';
import PropTypes from 'prop-types';
import { get } from 'lodash';
import { Ecs, Acs } from 'components/Icon';

const Cluster = ({ value, intl }) => {
  const statusMap = {
    Ecs: {
      icon: <Ecs />,
      cluster: intl('widget.app.cluster_ecs'),
    },
    Acs: {
      icon: <Acs />,
      cluster: intl('widget.app.cluster_k8s'),
    },
    none: {
      cluster: '--',
    },
  };
  const obj = get(statusMap, value, statusMap.none);
  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <If condition={obj.icon}>
        {obj.icon}
      </If>
      <span>{obj.cluster}</span>
    </div>
  );
};

Cluster.propTypes = {
  value: PropTypes.bool,
  intl: PropTypes.func,
};

export default Cluster;
