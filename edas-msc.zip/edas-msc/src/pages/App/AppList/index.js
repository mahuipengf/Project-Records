import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, modelDecorator, Empty, CopyContent, Button, Message } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
// import Cluster from './components/Cluster';
import { WIDGET_ID } from 'constants';
import Events from './Events';
import { lowerFirstData } from 'utils/transfer-data';
import { replace, map, forEach } from 'lodash';

function AppList(props) {
  const { tableUniqueKey, toggleModal } = props;
  const [isCanCustomColumns] = useState(true);
  const [isCanMultipleSearch] = useState(true);
  const [isCanRefresh] = useState(true);
  const [searchValues] = useGlobalState('searchValues');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const [autoFetch, setAutoFetch] = useState(false);
  const [refreshIndex, setRefreshIndex] = useState(undefined);
  const intl = useIntl();
  const { regionId } = searchValues;

  useEffect(() => {
    setAutoFetch(true);
  }, []);

  const fetchData = async (params) => {
    const Data = await services.GetAppList({
      params: {
        ...params,
        regionId,
      }
    });
    const { result = [], totalSize = 0 } = lowerFirstData(Data) || {};
    return {
      Data: map(result, item => ({ ...item, appName: unescape(replace(replace(item.appName, /&#x/g, '%u'), /;/g, '')) })), // utf8 -> 中文
      TotalCount: totalSize,
    };
  };

  const handleGToAccessType = () => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-AppAccessType`, {});
  };

  const handleGoToAppInfo = (record) => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-AppInfo`, record);
  };

  const columns = [
    {
      key: 'appName',
      title: intl('widget.app.name'),
      dataIndex: 'appName',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <span className="link-primary" onClick={() => handleGoToAppInfo(record)}>{value}</span>
        </CopyContent>
      ),
    },
    // {
    //   key: 'Protocol',
    //   title: intl('widget.route.frame_type'),
    //   dataIndex: 'Protocol',
    //   cell: value => (
    //     <Empty value={value}>
    //       <div style={{ display: 'flex' }}>
    //         {ICON[value]}
    //         <span>{PROTOCOL_DATA3[value]}</span>
    //       </div>
    //     </Empty>
    //   ),
    // },
    {
      key: 'source',
      title: (
        <React.Fragment>
          <span>{intl('widget.app.access_type')}</span>
          <span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={handleGToAccessType}>{intl('widget.app.see_access_type')}</span>
        </React.Fragment>
      ),
      dataIndex: 'source',
      cell: value => {
        const newValue = value === 'edasmsc' ? intl('widget.common.standard') : value;
        return <Empty value={newValue}>{newValue}</Empty>;
      },
    },
    {
      key: 'instancesNumber',
      title: intl('widget.app.instance_number'),
      dataIndex: 'instancesNumber',
      cell: value => <Empty value={value}>{value}</Empty>,
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => <Events record={record} setRefreshIndex={setRefreshIndex} toggleModal={toggleModal} />,
    },
  ];

  const searchs = {
    // typeInfo: {
    //   types: [
    //     {
    //       label: intl('widget.app.cluster_type_all'),
    //       value: '',
    //     },
    //     {
    //       label: intl('widget.app.cluster_ecs'),
    //       value: 'ecs',
    //     },
    //     {
    //       label: intl('widget.app.cluster_k8s'),
    //       value: 'k8s',
    //     },
    //   ],
    //   defaultValue: '',
    //   value: 'type',
    //   multiple: true,
    // },
    filterInfo: {
      filters: [
        {
          label: intl('widget.app.name'),
          value: 'appName',
          placeholder: intl('widget.app.name_placeholder'),
        },
      ],
      defaultValue: 'appName',
    },
    isCanCustomColumns,
    isCanMultipleSearch,
    tableUniqueKey,
    isCanRefresh,
  };
  const handleDelete = (appId, data) => {
    const appName = [];
    forEach(data, i => {
      forEach(appId, t => {
        if (t === i.appId) {
          appName.push(i.appName);
        }
      });
    });
    DialogAlert({
      title: intl('widget.common.delete'),
      content: <div style={{ maxWidth: 400 }}>{intl.html('widget.app.has_instance_hint', { appName })}</div>,
      onOk: () => services.RemoveApplications({
        params: { AppIds: appId, regionId }
      }).then((res) => {
        if (res) {
          Message.success(intl('widget.common.delete_successful'));
          setRefreshIndex(Date.now());
        } else {
          DialogAlert({
            title: intl('widget.common.tips'),
            content: intl('widget.app.has_instance_can_not_delete'),
          });
        }
      }),
      footerActions: ['ok', 'cancel']
    });
  };
  return (
    <React.Fragment>
      <TableContainer
        autoFetch={autoFetch}
        fetchData={fetchData}
        primaryKey="appId"
        columns={columns}
        search={searchs}
        isUseStorage
        affixActionBar
        refreshIndex={refreshIndex}
        rowSelection
        selection={value => (
          <Button type="primary" onClick={() => handleDelete(value.selectedRowKeys, value.dataSource)}>
            {intl('widget.app.list_batch_delete')}
          </Button>
        )}
        operation={() => (
          <Button type="primary" onClick={handleGToAccessType}>
            {intl('widget.app.app_access')}
          </Button>
        )}
        emptyContent={
          <span className="link-primary" onClick={handleGToAccessType}>{intl('widget.app.no_data_go_accessType')}</span>
        }
      />
    </React.Fragment>
  );
}

AppList.propTypes = {
  tableUniqueKey: PropTypes.string,
  toggleModal: PropTypes.func,
};

export default modelDecorator(AppList);
