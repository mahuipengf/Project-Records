import React from 'react';
import { useIntl } from '@ali/widget-hooks';

const Ase = () => {
  const intl = useIntl();
  return (
    <div >
      <h1 style={{ fontSize: 16, marginBottom: 10 }}>{intl('widget.app.sae.title_one')}</h1>
      <div style={{ fontSize: 14, maxWidth: 1000, lineHeight: '20px', color: '#404040' }}>
        {intl.html('widget.app.sae.title_one_message')}
      </div>
      <h1 style={{ fontSize: 16, marginBottom: 0 }}>
        {intl('widget.app.sae.title_two')}
      </h1 >
      <div style={{ fontSize: 14, maxWidth: 1000, lineHeight: '20px', color: '#404040' }}>
        {intl.html('widget.app.sae.title_two_message')}
      </div>
    </div>
  );
};

export default Ase;
