import React, { useEffect, useState } from 'react';
import { split } from 'lodash';
import PropTypes from 'prop-types';
import services from 'services';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { WIDGET_ID } from 'constants';
import { Message, CopyContent } from '@ali/cn-design';
import './index.less';

const LocalDevelopment = ({ regionId = 'cn-hangzhou' }) => {
  const intl = useIntl();
  const [licenseKey, setLicenseKey] = useState('');
  const [eventEmitter] = useGlobalState('eventEmitter');
  useEffect(() => {
    fetchKey();
  }, []);

  const fetchKey = async () => {
    const data = await services.CreateLicenseKey({ params: { regionId } });
    setLicenseKey(data);
  };

  const handleGoToAppList = (record) => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-AppList`, record);
  };

  return (
    <div className="ecs">
      <Message type="notice" style={{ color: '#f68300', margin: '16px 0 8px' }}>
        本地开发应用接入MSE微服务治理
      </Message>
      <div>
        在微服务应用的本地开发流程中，我们可以将测试环境的部分流量引入本地应用，来实现快速验证开发的效果。
      </div>
      <h1>{intl('widget.msc.ecs_access')}</h1>
      <h2>{intl('widget.msc.ecs_access_step_one')}</h2>
      <div className="ecs-step">
        <h5 className="ecs-step-h5">
          {intl('widget.msc.ecs_access_step_one.mssage1')}
          <span style={{ color: 'rgb(151, 154, 156)', marginLeft: 24 }}> {intl('widget.msc.ecs_access_step_one.mssage2')}</span>
        </h5>
        <div className="ecs-step-content">
          <p>{intl('widget.msc.ecs_access_step_one.mssage3')}</p>
          <pre>
            <CopyContent text={`wget -O- http://mse-${regionId}.oss-${regionId}.aliyuncs.com/install.sh | sh`}>
              <span className="color-red">wget</span>
              {` -O- http://mse-${regionId}.oss-${regionId}.aliyuncs.com/install.sh | sh`}
            </CopyContent>
          </pre>
          <p> {intl('widget.msc.ecs_access_step_one.mssage4')}</p>
          <pre>
            <CopyContent text={`wget -O- http://mse-${regionId}.oss-${regionId}-internal.aliyuncs.com/install.sh | sh`}>
              <span className="color-red">wget</span>
              {` -O- http://mse-${regionId}.oss-${regionId}-internal.aliyuncs.com/install.sh | sh`}
            </CopyContent>
          </pre>
        </div>
      </div>
      <h2>{intl('widget.msc.ecs_access_step_two')}</h2>
      <div className="ecs-step">
        <h5 className="ecs-step-h5">{intl('widget.msc.ecs_access_step_two.message1')}</h5>
        <div className="ecs-step-content">
          <pre>
            <CopyContent text="unzip MseAgent.zip -d /{user.workspace}/">
              <span className="color-red">unzip</span>{' MseAgent.zip -d /{user.workspace}/'}
            </CopyContent>
          </pre>
          <p className="color-red">{intl('widget.msc.ecs_access_step_two.message2', { workspace: 'user.workspace' })}</p>
        </div>
        <h5 className="ecs-step-h5">{intl('widget.msc.ecs_access_step_two.message3')}</h5>
        <div className="ecs-step-content">
          <h5 className="ecs-step-content-h5">
            {intl('widget.msc.ecs_access_step_two.message4')}
          </h5>
          <pre>
            <CopyContent text="-javaagent:/{user.workspace}/MseAgent/mse-bootstrap-1.7.0-SNAPSHOT.jar">
              <span>{'-javaagent:/{user.workspace}/MseAgent/mse-bootstrap-1.7.0-SNAPSHOT.jar'}</span>
            </CopyContent>
            <CopyContent text={`-Dmse.licenseKey=${licenseKey || ''}`}>
              -Dmse.<span className="color-red">licenseKey</span>{`=${licenseKey || ''}`}（<span className="color-red">{intl('widget.msc.ecs_access_step_two.message5')}</span>）
            </CopyContent>
            <CopyContent text="-Dmse.appName=Demo-Service">
              -Dmse.<span className="color-red">appName</span>=Demo-Service {intl('widget.msc.ecs_access_step_two.message6')}
            </CopyContent>
            <CopyContent text="-Dmse.enable=true">
              -Dmse.<span className="color-red">enable</span>=true
            </CopyContent>
          </pre>
          <p className="color-red">{intl('widget.msc.ecs_access_step_two.message7')}</p>
          <h5 className="ecs-step-content-h5">{intl('widget.msc.ecs_access_step_two.message8')}</h5>
          <div>
            <span style={{ color: '#777' }}>{intl('widget.msc.ecs_access_step_two.message9')}</span>
          </div>
        </div>
      </div>
      <h2>{intl('widget.msc.ecs_access_step_three')}</h2>
      <div className="ecs-step" >
        <p style={{ margin: '0 16px' }}>
          {intl('widget.msc.ecs_access_step_three.message1')}&nbsp;&nbsp;
          <span className="link-primary" onClick={handleGoToAppList}>{intl('widget.msc.ecs_access_step_three.message2')}</span>
          {intl('widget.msc.ecs_access_step_three.message3')}</p>
      </div>
    </div>
  );
};

LocalDevelopment.propTypes = {
  regionId: PropTypes.string,
};

export default LocalDevelopment;
