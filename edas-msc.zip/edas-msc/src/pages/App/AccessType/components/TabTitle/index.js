import React from 'react';
import PropTypes from 'prop-types';
import { get } from 'lodash';
import { Ecs, Acs, Edas, Istio, Sae } from 'components/Icon';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.less';
import { Badge } from '@ali/cn-design';

const TabTitle = ({ value, tab, onClick }) => {
  const intl = useIntl();
  const iconMap = {
    Ecs: {
      icon: <Ecs style={{ minWidth: 20, width: 20, marginRight: 4 }} />,
      title: intl('widget.app.cluster_ecs'),
      // badge: true,
    },
    Acs: {
      icon: <Acs style={{ minWidth: 24, width: 24, marginRight: 4 }} />,
      title: intl('widget.app.cluster_k8s'),
    },
    Sae: {
      icon: <Sae style={{ minWidth: 24, width: 24, marginRight: 4, height: 24 }} />,
      title: intl('widget.app.cluster_sae')
    },
    Edas: {
      icon: <Edas style={{ minWidth: 24, width: 24, marginRight: 4 }} />,
      title: intl('widget.app.cluster_edas'),
    },
    // Istio: {
    //   icon: <Istio style={{ minWidth: 24, width: 24, marginRight: 4, fill: '#0077cc' }} />,
    //   title: intl('widget.app.cluster_istio'),
    // },
    // Local: {
    //   icon: <Ecs style={{ minWidth: 20, width: 20, marginRight: 4 }} />,
    //   title: intl('widget.app.cluster_local'),
    // }
  };
  const obj = get(iconMap, tab, {});
  return (
    <React.Fragment>
      <If condition={obj.badge}>
        <Badge dot style={{ right: 0 }}>
          <div className={value === tab ? styles['tab-title-active'] : styles['tab-title']} onClick={onClick}>
            {obj.icon}
            <span>{obj.title}</span>
          </div>
        </Badge>
      </If>
      <If condition={!obj.badge}>
        <div className={value === tab ? styles['tab-title-active'] : styles['tab-title']} onClick={onClick}>
          {obj.icon}
          <span>{obj.title}</span>
        </div>
      </If>
    </React.Fragment>
  );
};

TabTitle.propTypes = {
  value: PropTypes.string,
  tab: PropTypes.string,
  onClick: PropTypes.func,
};

export default TabTitle;
