import React from 'react';

const ISTIO = () => {
  return (
    <div>
      <h1 style={{ fontSize: '28px' }}>
        Multilingual microservice application access MSE Governance Center
      </h1>
      <p>You can connect multilingual microservice applications to MSE microservice governance center and use a series of service governance capabilities provided by MSE, including service query, label routing and other functions, so as to greatly improve the stability and development efficiency of online microservices.</p>
      <div style={{ fontSize: '24px', fontWeight: '600', margin: '20px 0px' }}>
        prerequisite
      </div>
      <ul style={{ padding: '10px' }}>
        <li style={{ margionTop: '8px' }}>· Prerequisite ASM instance created. For details, see Creating ASM instances.</li>
        <li style={{ margionTop: '8px' }}>· ACK cluster created. For details, see creating a kubernetes managed cluster.</li>
        <li style={{ margionTop: '8px' }}>· Add cluster to ASM instance. For specific operations, see adding a cluster to an ASM instance.</li>
        <li style={{ margionTop: '8px' }}>· Click function settings at the top right of the grid management details page</li>
        <li style={{ margionTop: '8px' }}>· In the function settings update panel, click expand advanced options, select enable MSE microservice governance component, and then click OK.</li>
      </ul>
      <div style={{ fontSize: '24px', fontWeight: '600', margin: '20px 0px' }}>
        results of enforcement
      </div>
      <p>After deploying the application, you can view the relevant application data in the MSE governance center.</p>
      <div style={{ fontSize: '24px', fontWeight: '600', margin: '20px 0px' }}>
        Next steps
      </div>
      <ul style={{ padding: '10px' }}>
        <li style={{ margionTop: '8px' }}>· Query application list</li>
        <li style={{ margionTop: '8px' }}>· Query service</li>
        <li style={{ margionTop: '8px' }}>· Configure label routing</li>
        <li style={{ margionTop: '8px' }}>· Configure service authentication</li>
        <li style={{ margionTop: '8px' }}>· Testing multilingual services</li>
        <li style={{ margionTop: '8px' }}>· Pressure measurement multilingual service</li>
        <li style={{ margionTop: '8px' }}>· Patrol multilingual service</li>
        <li style={{ margionTop: '8px' }}>· Automated regression multilingual service test cases</li>
        <li style={{ margionTop: '8px' }}>· Automated regression multilingual service test case set</li>
        <li style={{ margionTop: '8px' }}>· Canary release</li>
      </ul>
    </div>);
};
export default ISTIO;