import React from 'react';

const ACS = () => {
  return (
    <div >
      <h1 style={{ fontSize: '28px' }}>ACK microservice application access MSE Governance Center</h1>
      <p>You can connect microservice applications such as spring cloud and Dubbo deployed in kubernetes (ACK) container service to MSE governance center and use a series of service governance capabilities provided by MSE to greatly improve the stability and development efficiency of online microservices</p>
      <div style={{ fontSize: '24px', fontWeight: '600', marginTop: '20px' }}>
        prerequisite
      </div>
      <div style={{ fontSize: '24px', fontWeight: '600', margin: '20px 0px' }}>
        Access process
      </div>
      <div>
        <div>
          Connecting the application in ack to MSE governance center includes the following steps:
        </div>
        <div>
          <p>1. Install the MSE governance center component in the container service ack cluster</p>
          <p>2. Enable microservice governance for applications according to your business needs</p>
        </div>
      </div>
      <div style={{ fontSize: '24px', fontWeight: '600', margin: '20px 0px' }}>
        Install MSE governance center component in ACK
      </div>
      <div>
        In ACK, install the MSE governance center component ack one pilot for the target cluster, and the applications deployed in the cluster can access the MSE governance center.
      </div>
      <div>
        If you use ask or ECI, please give ECI permission to access MSE first
      </div>
      <div style={{ padding: '10px' }}>
        <div style={{ margionTop: '8px' }}>1. Log in to the container services console. </div>
        <div style={{ margionTop: '8px' }}>2. On the left navigation bar, click markets > apply markets.</div>
        <div style={{ margionTop: '8px' }}>3. On the application market page, click the application directory tab, and then search and click</div>
        <div style={{ margionTop: '8px' }}>4. You can select the container service new or old application directory to install components</div>
      </div>
      <div style={{ fontSize: '24px', fontWeight: '600', margion: '20px 0px' }}>
        Enable MSE microservice governance for applications in ack namespace
      </div>
      <div style={{ padding: '10px' }}>
        <div style={{ margionTop: '8px' }}>1. Log in to MSE governance center console.</div>
        <div style={{ margionTop: '8px' }}>2. Select microservice governance center > k8s cluster list in the left navigation bar.</div>
        <div style={{ margionTop: '8px' }}>3. Select the cluster name or cluster ID in the search box list on the k8s cluster list page, then enter the corresponding keyword and click the search icon.</div>
        <div style={{ margionTop: '8px' }}>4. Click Manage in the target cluster operations column.</div>
      </div>
    </div>);
};
export default ACS;
