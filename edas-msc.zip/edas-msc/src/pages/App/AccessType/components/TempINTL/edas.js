import React from 'react';

const EDAS = () => {
  return (
    <div>
      <h3 style={{ }}>
        Enterprise distributed application service (EDAs) is a PAAS platform for application hosting and micro service management, which provides full stack solutions such as application development, deployment, monitoring, operation and maintenance.
      </h3>
      <h3 style={{ marginTop: '20px' }}>
        The micro service function of EDAs completely includes the functions of the micro service center, and is deeply integrated with the development, deployment, monitoring, operation and maintenance of applications. You can directly jump to the EDAs console for operation. 
      </h3>
    </div>);
};
export default EDAS;