import React, { useEffect, useState } from 'react';
import { split, get } from 'lodash';
import PropTypes from 'prop-types';
import services from 'services';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { WIDGET_ID } from 'constants';
import { Message, CopyContent, Input } from '@ali/cn-design';
import './index.less';
import { getParams } from 'utils';

const EcsAccess = ({ regionId = 'cn-hangzhou' }) => {
  const intl = useIntl();
  const [licenseKey, setLicenseKey] = useState('');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const [mscAccount] = useGlobalState('mscAccount');
  const Status = get(mscAccount, 'Status'); // 是否开通 1未开通 2 开通
  const Version = get(mscAccount, 'Version'); // 开通版本
  const ns = getParams('ns') || 'default';
  const [appName, setAppName] = useState('Demo-Service');

  useEffect(() => {
    fetchKey();
  }, []);

  const fetchKey = async () => {
    const data = await services.CreateLicenseKey({ params: { regionId } });
    setLicenseKey(data);
  };

  const handleGoToAppList = (record) => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-AppList`, record);
  };

  const renderMseVersion = () => {
    if (!Version) {
      return '-Dprofiler.micro.service.mse.version=base';
    }
    if (Version === 1) {
      return '-Dprofiler.micro.service.mse.version=pro';
    }
    if (Version === 2) {
      return '-Dprofiler.micro.service.mse.version=ent';
    }
    return '-Dprofiler.micro.service.mse.version=base';
  };

  const handleChangeAppName = (val) => {
    setAppName(val);
  };

  return (
    <div className="ecs">
      <h1>{intl('widget.msc.ecs_access')}</h1>
      <h2>{intl('widget.msc.ecs_access_step_one')}</h2>
      <Message type="notice" style={{ color: '#f68300', margin: '16px 0 16px' }}>
        {intl('widget.msc.ecs_access_msg1')}
      </Message>
      <div className="ecs-step">
        <h5 className="ecs-step-h5">
          {intl('widget.msc.ecs_access_step_one.mssage1')}
          <span style={{ color: 'rgb(151, 154, 156)', marginLeft: 24 }}> {intl('widget.msc.ecs_access_step_one.mssage2')}</span>
        </h5>
        <Message type="notice" style={{ color: '#f68300', margin: '16px 0 0px' }}>
          {intl('widget.msc.ecs_access_msg2')}
        </Message>
        <div className="ecs-step-content">
          <p>{intl('widget.msc.ecs_access_step_one.mssage3')}</p>
          <pre>
            <CopyContent text={`wget http://arms-apm-${regionId}.oss-${regionId}.aliyuncs.com/ms/AliyunJavaAgent.zip \ -O AliyunJavaAgent.zip`}>
              <span className="color-red">wget</span>
              {` http://arms-apm-${regionId}.oss-${regionId}.aliyuncs.com/ms/AliyunJavaAgent.zip \ -O AliyunJavaAgent.zip`}
            </CopyContent>
          </pre>
          <p> {intl('widget.msc.ecs_access_step_one.mssage4')}</p>
          <pre>
            <CopyContent text={`wget http://arms-apm-${regionId}.oss-${regionId}-internal.aliyuncs.com/ms/AliyunJavaAgent.zip \ -O AliyunJavaAgent.zip`}>
              <span className="color-red">wget</span>
              {` http://arms-apm-${regionId}.oss-${regionId}-internal.aliyuncs.com/ms/AliyunJavaAgent.zip \ -O AliyunJavaAgent.zip`}
            </CopyContent>
          </pre>
        </div>
      </div>
      <h2>{intl('widget.msc.ecs_access_step_two')}</h2>
      <div className="ecs-step">
        <h5 className="ecs-step-h5">{intl('widget.msc.ecs_access_step_two.message1')}</h5>
        <div className="ecs-step-content">
          <pre>
            <CopyContent text="unzip AliyunJavaAgent.zip -d /{user.workspace}/">
              <span className="color-red">unzip</span>{' AliyunJavaAgent.zip -d /{user.workspace}'}
            </CopyContent>
          </pre>
          <p className="color-red">{intl('widget.msc.ecs_access_step_two.message2', { workspace: 'user.workspace' })}</p>
        </div>
        <h5 className="ecs-step-h5">{intl('widget.msc.ecs_access_step_two.message3')}</h5>
        <div className="ecs-step-content">
          <h5 className="ecs-step-content-h5">
            {intl('widget.msc.ecs_access_step_two.message4')}
          </h5>
          <div style={{ marginBottom: 8 }}>
            {intl('widget.msc.ecs_access_appname')}<Input value={appName} onChange={handleChangeAppName} placeholder={intl('widget.msc.ecs_access_appname_please')} />
          </div>
          <pre>
            <div>
              <CopyContent style={{ display: 'block' }} text={`-javaagent:/{user.workspace}/AliyunJavaAgent/aliyun-java-agent.jar -Dmse.licenseKey=${licenseKey || ''} -Dmse.appName=${appName} -Dmse.namespace=${ns} -Dmse.enable=true ${renderMseVersion()}`}>
                <div>{'-javaagent:/{user.workspace}/AliyunJavaAgent/aliyun-java-agent.jar'}</div>
                <div>-Dmse.<span className="color-red">licenseKey</span>{`=${licenseKey || ''}`}（<span className="color-red">{intl('widget.msc.ecs_access_step_two.message5')}</span>）</div>
                <div>-Dmse.<span className="color-red">appName</span>={appName} {intl('widget.msc.ecs_access_step_two.message6')}</div>
                <div>{`-Dmse.namespace=${ns}`}</div>
                <div>-Dmse.<span className="color-red">enable</span>=true</div>
                <div>{renderMseVersion()}</div>
              </CopyContent>
            </div>
          </pre>
          <p className="color-red">{intl('widget.msc.ecs_access_step_two.message7')}</p>
          <h5 className="ecs-step-content-h5">{intl('widget.msc.ecs_access_explain')}</h5>
          <div className={'ecs-explain-pulic'}>
            <span>{intl('widget.msc.ecs_access_explain_tips1')}</span>
          </div>
          <div className={'ecs-explain-pulic'}>
            <span>{intl('widget.msc.ecs_access_explain_tips2')}</span>
          </div>
          <div className={'ecs-explain-pulic'}>
            <span>{intl('widget.msc.ecs_access_explain_tips3')}</span>
          </div>
          <div className={'ecs-explain-pulic'}>
            <span>{intl('widget.msc.ecs_access_explain_tips4')}</span>
          </div>
          <div className={'ecs-explain-pulic'}>
            <span>{intl('widget.msc.ecs_access_explain_tips5', { workspace: '{user.workspace}' })}</span>
          </div>
          <div className={'ecs-explain-pulic'}>
            <span>{intl('widget.msc.ecs_access_explain_tips6')}</span>
          </div>
          <h5 className="ecs-step-content-h5" style={{ margin: '8px 0px' }}>{intl('widget.msc.ecs_access_step_two.message8')}</h5>
          <div>
            <span style={{ color: '#777' }}>{intl('widget.msc.ecs_access_step_two.message9')}</span>
          </div>
        </div>
      </div>
      <h2>{intl('widget.msc.ecs_access_step_three')}</h2>
      <div className="ecs-step" >
        <p style={{ margin: '0 16px' }}>
          {intl('widget.msc.ecs_access_step_three.message1')}&nbsp;&nbsp;
          <span className="link-primary" onClick={handleGoToAppList}>{intl('widget.msc.ecs_access_step_three.message2')}</span>
          {intl('widget.msc.ecs_access_step_three.message3')}</p>
      </div>
    </div>
  );
};

EcsAccess.propTypes = {
  regionId: PropTypes.string,
};

export default EcsAccess;
