import React, { useState } from 'react';
import ReactMarkdown from 'components/Markdown';
import TabTitle from './components/TabTitle';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import { get } from 'lodash';
import Iframe from 'components/Iframe';
import EcsAccess from './components/Ecs';
import Ase from './components/Ase';
// import Locale from './components/Local';
import Cookie from 'js-cookie';
import EDAS from './components/TempINTL/edas';
import ISTIO from './components/TempINTL/istio';
import ACS from './components/TempINTL/acs';


const AppAccessType = () => {
  const [tab, setTab] = useState('Acs');
  const [searchValues] = useGlobalState('searchValues');
  const intl = useIntl();
  const aliyunLang = Cookie.get('aliyun_lang') || 'zh';
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';

  const handleClicck = (value) => {
    setTab(value);
  };

  const fetchData = async (method) => {
    const res = services[method] && await services[method]();
    const data = get(res, 'data');
    return { data };
  };
  // 'Istio' 服务网格隐藏
  const arr = ['Acs', 'Ecs', 'Edas']; // 'Sae', // , 'Local'本地应用接入暂时不支持
  if (aliyunSite !== 'INTL') {
    arr.splice(2, 0, 'Sae');
  }
  return (
    <div style={{ paddingBottom: 32 }}>
      <h4 style={{ marginTop: 0 }}>{intl('widget.app.access_type.env_type')}</h4>
      <div style={{ display: 'flex', marginBottom: 16, position: 'relative' }}>
        <For each="item" of={arr}>
          <TabTitle tab={item} value={tab} key={item} onClick={() => handleClicck(item)} />
        </For>
      </div>
      <If condition={tab === 'Ecs'}>
        <EcsAccess regionId={searchValues.regionId} />
      </If>
      <If condition={tab === 'Acs'}>
        <If condition={aliyunLang === 'en'}>
          <ACS />
        </If>
        <If condition={aliyunLang !== 'en'}>
          <Iframe src="//aliware-images.oss-cn-hangzhou.aliyuncs.com/console-embedded/mse-microservice-access-k8s-instruction.zh-cn.html" height="5080" style={{ marginTop: -36 }} />
        </If>
      </If>
      <If condition={tab === 'Sae'}>
        <Ase />
      </If>
      <If condition={tab === 'Edas'}>
        <If condition={aliyunLang === 'en'}>
          <EDAS />
        </If>
        <If condition={aliyunLang !== 'en'}>
          <ReactMarkdown fetchData={() => fetchData('getEdasMarkdown')} />
        </If>
      </If>
      {/* <If condition={tab === 'Istio'}>
        <If condition={aliyunLang === 'en'}>
          <ISTIO />
        </If>
        <If condition={aliyunLang !== 'en'}>
          <Iframe src="//aliware-images.oss-cn-hangzhou.aliyuncs.com/console-embedded/mse-microservice-access-asm-instruction.zh-cn.html" height="5080" style={{ marginTop: -36 }} />
        </If>
      </If> */}
      {/* <If condition={tab === 'Local'}>
        <Locale />
      </If> */}
    </div>
  );
};

export default AppAccessType;
