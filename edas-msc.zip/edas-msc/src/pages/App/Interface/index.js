import React, { useEffect, useState } from 'react';
import { Tab } from '@ali/cn-design';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { getParams } from 'utils';
import { changeQuery } from 'utils/query';
import ScTable from './components/ScTable';
import DubboTable from './components/DubboTable';

const Interface = () => {
  const intl = useIntl();
  const [tag, setTag] = useState(getParams('interface'));
  const [searchValues] = useGlobalState('searchValues');
  const { appId, regionId } = searchValues;

  const tabs = [
    {
      tab: 'Spring Cloud',
      key: 'springCloud',
      content: <ScTable AppId={appId} Region={regionId} />
    },
    {
      tab: 'Dubbo',
      key: 'dubbo',
      content: <DubboTable AppId={appId} Region={regionId} />
    },
  ];


  const changeUrl = (value) => {
    setTag(value);
    changeQuery({ interface: value });
  };

  return (
    <React.Fragment>
      <Tab shape="wrapped" defaultActiveKey={tag || 'springCloud'}>
        <For index="index" each="item" of={tabs}>
          <Tab.Item title={item.tab} key={item.key} onClick={() => changeUrl(item.key)}>
            {item.content}
          </Tab.Item>
        </For>
      </Tab>
    </React.Fragment>
  );
};

export default Interface;
