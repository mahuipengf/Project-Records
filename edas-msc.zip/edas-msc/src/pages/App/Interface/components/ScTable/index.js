import React, { useEffect, useState } from 'react';
import Cookie from 'js-cookie';
import { TableContainer, Input, Empty, Table, Balloon, CopyContent } from '@ali/cn-design';
import { get, isEmpty, uniqueId, map, join, includes, head } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import PropTypes from 'prop-types';
import './index.less';
import InterfaceTabs from '../InterfaceTabs';

const ScTable = (props) => {
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [scService, setScService] = useState({});
  const { AppId, Region } = props;
  const [rowData, setRowData] = useState({});
  const [loading, setLoading] = useState(false);
  const intl = useIntl();
  const aliyunLang = Cookie.get('aliyun_lang') || 'zh';


  useEffect(() => {
    fetchScService();
  }, []);

  useEffect(() => {
    setRefreshIndex(Date.now());
  }, [scService]);

  const fetchScService = async () => {
    const params = {
      ServiceType: 'springCloud',
      AppId,
      PageNumber: 1,
      PageSize: 10,
      Region,
    };
    setLoading(true);
    const Data = await services.fetchServicesList({ data: params });
    const ScService = get(Data, 'Result', []);
    const NewScService = map(ScService, (item) => ({
      ...item,
      Region: ScService.Region || Region,
      AppId: ScService.AppId || AppId,
      Protocol: 'springCloud',
      Uid: uniqueId(),
    }));

    setScService(head(NewScService)); // sc 一个应用只会有一个服务
  };

  const fetchData = async (params) => {
    if (isEmpty(scService)) {
      setLoading(false);
      return {
        Data: [],
        TotalCount: 0,
      };
    }
    const data = {
      AppId,
      ServiceType: 'springCloud',
      Region,
      ServiceName: scService.ServiceName,
      ServiceVersion: scService.Version,
      ServiceGroup: scService.Group,
      PageSize: params.pageSize,
      PageNumber: params.pageNumber,
      Path: params.Path,
    };
    setLoading(true);
    const Data = await services.getServiceMethodPage({
      data,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      },
    });
    setLoading(false);
    const { TotalSize = 0, Result = [] } = Data || {};
    if (isEmpty(Result)) {
      return {
        totalSize: 0,
        Data: [],
      };
    } else {
      Result.unshift({ Paths: ['/mseAll'], RequestMethods: ['ALL'] });
      const NewResult = map(Result, (item) => ({
        ...item,
        Uid: uniqueId(),
        AppId: item.AppId || AppId,
        Region: item.Region || Region,
      }));
      if (isEmpty(rowData) && head(NewResult)) {
        setRowData(head(NewResult));
      }

      return {
        TotalCount: TotalSize + 1,
        Data: NewResult,
      };
    }
    /**
     * 判断 isEmpty(a),   return { TotalCount:0, Data: [] }
     * 非空，Result.unshift({}), TotalSize +=1,
     */
  };

  const search = {
    filterInfo: {
      filters: [
        // {
        //   label: intl('widget.service.belong_type'),
        //   value: 'MethodController',
        // },
        {
          label: intl('widget.service.path_name'),
          value: 'Path',
          width: 120,
        },
        // {
        //   label: intl('widget.service.method_name'),
        //   value: 'Name',
        // },
      ],
      defaultValue: 'Path',
      style: { width: `${aliyunLang === 'en' ? '130px' : '110px'}` },
    },
    isCanRefresh: true,
  };

  const columns = [
    {
      key: 'RequestMethods',
      title: intl('widget.service.httpMethods'),
      dataIndex: 'RequestMethods',
      cell: (value) => {
        const trigger = (<div
          style={{
            background: `rgb(${color(value)})`,
            width: 60,
            padding: '8px 8px',
            borderRadius: 4,
            textAlign: 'center',
            color: '#fff',
          }}
        >
          {value[0]}
        </div>);
        return (
          <Empty value={value}>
            <If condition={value.length === 1}>
              {trigger}
            </If>
            <If condition={value.length > 1}>
              <Balloon trigger={trigger} closable={false}>
                <CopyContent text={join(value)}>{join(value)}</CopyContent>
              </Balloon>
            </If>
          </Empty>);
      },
    },
    {
      key: 'Paths',
      title: intl('widget.service.path_name'),
      dataIndex: 'Paths',
      cell: (val, index, record) => (
        <React.Fragment>
          <For each="item" index="index" of={val || []}>
            <div className="table-columns">
              <If condition={item === '/mseAll'}>
                {intl('widget.authentication.all_interface')}
              </If>
              <If condition={item !== '/mseAll'}>{item}</If>
            </div>
          </For>
        </React.Fragment>
      ),
    },
  ];

  const color = (methods) => {
    const method = head(methods);
    switch (method) {
      case 'POST':
        return '113 200 148';
      case 'PATCH':
        return '123 225 195';
      case 'DELETE':
        return '229 79 72';
      case 'GET':
        return '115 174 248';
      case 'PUT':
        return '239 164 73';
      case 'ALL':
        return '168 193 224';
      default:
        return '115 174 248';
    }
  };

  return (
    <div style={{ display: 'flex', marginTop: 16 }}>
      <div
        style={{
          flex: 1,
          border: '1px solid #eee',
          borderRadius: '4px 0 0 4px',
          padding: '8px 16px',
          overflow: 'auto',
        }}
        className="sc-table"
      >
        <TableContainer
          loading={loading}
          refreshIndex={refreshIndex}
          fetchData={fetchData}
          primaryKey="Uid"
          columns={columns}
          cellProps={(rowIndex, colIndex, dataIndex, record) => ({
            style: {
              width: colIndex === 0 ? 100 : undefined,
              cursor: 'pointer',
            },
          })}
          rowProps={(record) => ({
            className: `${
              `${record.Name}:${record.RequestMethods}` ===
              `${rowData.Name}:${rowData.RequestMethods}`
                ? 'table-active'
                : ''
            } ${record.Uid}`,
            style: {
              position: 'relative',
            },
          })}
          search={search}
          // hasBorder={false}
          onRowClick={(record) => setRowData(record)}
          hasHeader={false}
          pagination={{ pageSizeSelector: false, type: 'simple' }}
          followTrigger
        />
      </div>
      <InterfaceTabs serviceData={scService} rowData={rowData} />
    </div>
  );
};

ScTable.propTypes = {
  AppId: PropTypes.string,
  Region: PropTypes.string,
};

export default ScTable;
