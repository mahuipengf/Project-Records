import React, { useState } from 'react';
import { Tab } from '@ali/cn-design';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import Overview from './Overview';
import Info from './Info';
import { find } from 'lodash';
// import Comparison from './Comparison';
import Details from './Details';

const InterfaceTabs = ({ serviceData = {}, rowData = {} }) => {
  const intl = useIntl();
  const [tab, setTab] = useState('Overview');

  const tabs = [
    {
      key: 'Overview',
      title: intl('widget.msc.interface_overview'),
      component: (
        <React.Fragment>
          <Info serviceData={serviceData} rowData={rowData} />
          <Overview serviceData={serviceData} rowData={rowData} />
        </React.Fragment>
      )
    },
    {
      key: 'Details',
      title: intl('widget.msc.interface_details'),
      component: (
        <React.Fragment>
          <Details serviceData={serviceData} rowData={rowData} />
        </React.Fragment>
      )
    },
    // {
    //   key: 'Comparison',
    //   title: intl('widget.msc.interface_comparison'),
    //   component: (
    //     <React.Fragment>
    //       <Comparison serviceData={serviceData} rowData={rowData} />
    //     </React.Fragment>
    //   )
    // }
  ];

  return (
    <div style={{ flex: 2, border: '1px solid #eee', borderRadius: '0 4px 4px 0', padding: 16, overflow: 'auto' }}>
      <div>
        <Tab>
          <For index="index" each="item" of={tabs}>
            <Tab.Item title={item.title} onClick={() => setTab(item.key)} />
          </For>
        </Tab>
        <If condition={find(tabs, { key: tab })}>
          {find(tabs, { key: tab }).component}
        </If>
      </div>
    </div >
  );
};


InterfaceTabs.propTypes = {
  serviceData: PropTypes.objectOf(PropTypes.any),
  rowData: PropTypes.objectOf(PropTypes.any),
};
export default InterfaceTabs;
