import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Select, Empty, Pagination } from '@ali/cn-design';
import { Wcontainer, Wline, Wplaceholder } from '@alife/aisc-widgets';
import services from 'services';
import { isEmpty, forEach, forIn, find, replace, map, get, filter, isArray } from 'lodash';
import { useIntl } from '@ali/widget-hooks';

const mapNumber = (value) => {
  if (typeof value === 'number') {
    if (value >= 1000) return `${Math.round(value / 100) / 10}k`;
    else return value;
  } else {
    return value;
  }
};
const mapPercent = (value, total) => `${Math.round(value / total * 1000) / 10}%`;
const Details = ({ serviceData, rowData }) => {
  const { AppId, Paths } = rowData;
  const [ipList, setIpList] = useState([]);
  const [upData, setUpData] = useState([]);
  const [total, setTotal] = useState(6);
  const [loading, setLoading] = useState(false);
  const [selIp, setSelIp] = useState([]);
  const [page, setPage] = useState();
  const intl = useIntl();
  // 图标显示
  useEffect(() => {
    Paths && queryAppTopNMacs(Paths[0]);
  }, [Paths]);
  // 查询Ip
  const queryAppTopNMacs = async (RpcName) => {
    setLoading(true);
    const list = [];
    const QueryAppTopNMacsList = await services.QueryAppTopNMacs({
      params: {
        AppId,
        RpcName,
        EndTime: Date.now(),
      }
    });
    const macsList = map(QueryAppTopNMacsList.Result, item => {
      if (item.Pid) {
        list.push(item.PrivateIp.concat('-', item.Pid));
        return {
          value: item.PrivateIp.concat('-', item.Pid),
          label: item.PrivateIp.concat('-', item.Pid),
        };
      } else {
        return false;
      }
    }).filter(item => item);
    QueryAppTopNMacsList.ip = list;
    await queryAppRPCMacMetrics(Paths[0], list.join());
    QueryAppTopNMacsList.macsList = macsList;
    setIpList(QueryAppTopNMacsList);
    setSelIp(list);
  };
  const queryAppRPCMacMetrics = async (RpcName, InstanceIpList = [], PageNumber = 1) => {
    const res = await services.QueryAppRPCMacMetrics({
      params: {
        AppId,
        RpcName,
        InstanceIpList,
        PageNumber,
        PageSize: 2,
        EndTime: Date.now(),
      }
    });
    if (res) {
      const curData = [];
      forIn(res.CurMacMetricsMap || {}, (val) => {
        const WlineData = [
          { name: intl('widget.home.total_count'), key: 'qps', data: [] },
          { name: intl('widget.msc.throw_name', { name: 'QPS' }), key: 'expQps', data: [] },
        ];
        forEach(val.curMetrics || [], d => {
          forIn(d.tagValues || {}, (tag, key) => {
            if (!find(WlineData, { key })) {
              WlineData.push({ name: key === 'null' ? intl('widget.app.canary_no_tag') : key, key, data: [] });
              WlineData.push({ name: intl('widget.msc.throw_name', { name: key }), key: `exp_${intl('widget.app.canary_no_tag')}`, data: [] });
            }
          });
          const Time = d.timestamp;
          forEach(WlineData, item => {
            if (d[item.key] === 0 || d[item.key] || d[item.key] === null) {
              if (d[item.key] === -1) return item.data.push([Time, undefined]);
              else return item.data.push([Time, Number(d[item.key])]);
            } else if (!isEmpty(d.tagValues) && !isEmpty(d.tagValues[item.key])) {
              if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.tagValues[item.key].qps)]);
              else return item.data.push([Time, d.tagValues[item.key].qps]);
            } else if (!isEmpty(d.tagValues) && !isEmpty(d.tagValues[replace(item.key, 'exp_', '')])) {
              if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.tagValues[replace(item.key, 'exp_', '')].expQps)]);
              else return item.data.push([Time, d.tagValues[replace(item.key, 'exp_', '')].expQps]);
            }
          });
        });
        curData.push({ WlineData, Ip: `${val.privateIp}-${val.pid}` });
      });
      setTotal(res.TotalSize);
      setUpData(curData);
      setPage(PageNumber);
      setLoading(false);
    } else {
      setUpData([]);
    }
  };

  const options = {
    xAxis: {
      mask: 'HH:mm:ss',
    },
    yAxis: [
      {
        min: 0,
        labelFormatter: (value) => {
          if (value >= 1000) return `${(value / 1000).toFixed(1)}k`;
          else return value;
        }
      },
    ],
    legend: {
      position: 'bottom',
      align: 'center',
    },
    // padding: [12, 16, 48, 32],
    tooltip: {
      valueFormatter: (value, data, index, rawData) => {
        if (index === 0) return value || 0;
        const item = find(rawData, { name: intl('widget.home.total_count') });
        if (!item) {
          return value || 0;
        }
        return `${value} (${mapPercent(value || 0, item.value || 0)})`;
      },
    }
  };
  const handleChange = async(val) => {
    await setSelIp(val);
    await queryAppRPCMacMetrics(Paths[0], val.join());
  };
  const currentPage = async (current) => {
    await queryAppRPCMacMetrics(Paths[0], selIp.join(), current);
  };
  return (
    <React.Fragment>
      <If condition={!isEmpty(ipList.macsList)} >
        <div style={{ marginTop: 50, marginBottom: 30 }} key={selIp.length + new Date().getTime()} >
          <span >{intl('widget.app.filter_node')}</span>
          <Select defaultValue={selIp} mode="tag" onChange={handleChange} dataSource={ipList.macsList} style={{ width: 400, marginLeft: 10 }} followTrigger useVirtual popupStyle={{ maxHeight: '200px' }} maxTagCount={4} />
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between' }}>
          <If condition={loading}>
            <Wplaceholder
              loading
              style={{ transform: 'scale(3)' }}
              locale={{ loading: 'loading...', error: '数据异常' }}
              height={300}
            />
          </If>
          <If condition={!loading}>
            <If condition={!isEmpty(upData)}>
              <For index="index" each="item" of={upData}>
                <div
                  style={{ padding: 16, margin: '8px 8px 8px 0px', borderRadius: 4, border: '1px solid #eee', width: '100%' }}
                >
                  <div style={{ marginLeft: 10, fontSize: 16, fontStyle: 'blob', marginBottom: -10 }}>{item.Ip}</div>
                  <Wcontainer title={intl('widget.msc.qps_data_s')}>
                    <Wline
                      height={300}
                      config={options}
                      data={item.WlineData}
                    />
                  </Wcontainer>
                </div>
              </For>
            </If>
            <If condition={isEmpty(upData)} >
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', width: '100%' }}>
                <Empty showIcon />
              </div>
            </If>
          </If>
        </div>
      </If>
      <If condition={isEmpty(ipList.macsList)} >
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', width: '100%' }}>
          <Empty showIcon />
        </div>
      </If>
      <If condition={!isEmpty(upData)}>
        <Pagination onChange={currentPage} currentPage={page} pageSize={2} total={total} key={Paths} />
      </If>
    </React.Fragment>
  );
};

Details.propTypes = {
  serviceData: PropTypes.objectOf(PropTypes.any),
  rowData: PropTypes.objectOf(PropTypes.any),
};

export default Details;
