import React from 'react';
import { isEmpty, join, get } from 'lodash';
import { Tab, Empty, modelDecorator } from '@ali/cn-design';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import NewMethodTest from '../../../../../ServiceTest/components/MethodTest';
import DataFields from 'components/DataFields';
import Cookie from 'js-cookie';


const Info = ({ serviceData, rowData, toggleModal }) => {
  const intl = useIntl();
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';
  const handleMethodTest = () => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'xl',
      title: intl('widget.service.select_test_method'),
      content: (
        <NewMethodTest
          value={{
            serviceType: serviceData.Protocol,
            regionId: serviceData.Region,
            namespaceId: serviceData.Namespace,
            appId: serviceData.AppId,
            serviceGroup: serviceData.Group,
            serviceVersion: serviceData.Version,
            serviceName: serviceData.ServiceName,
            serviceId: serviceData.ServiceId,
          }}
          rowData={rowData}
        />
      ),
    });
  };

  const getItems = (item) => [
    {
      dataIndex: 'MethodController',
      label: intl('widget.mse.class_name'),
      visible: serviceData.Protocol === 'springCloud',
    },
    {
      dataIndex: 'Name',
      label: intl('widget.msc.method'),
      visible: true,
      render: (val) => (
        <div>
          <span>{val ? `${val}(${join(rowData.ParameterTypes, ', ')})` : '--'}</span>
          <If condition={rowData.NameDetail}>
            <div style={{ color: '#777' }}>{rowData.NameDetail}</div>
          </If>
        </div>
      )
    },
    {
      dataIndex: 'ParameterDefinitions',
      label: intl('widget.msc.params'),
      visible: true,
      render: (val) => (
        <React.Fragment>
          <If condition={!isEmpty(val)}>
            <For index="index" each="item" of={val}>
              <div key={index}>{`${item.Type} ${item.Description || ''}`}</div>
            </For>
          </If>
          <If condition={isEmpty(val)}>
            --
          </If>
        </React.Fragment>
      )

    },
    {
      dataIndex: 'ReturnType',
      label: intl('widget.msc.return_type'),
      visible: true,
    },
  ];

  return (
    <React.Fragment>
      <If condition={isEmpty(rowData)}>
        <div style={{ border: '1px solid #eee', margin: '8px 0px', padding: '8px 16px 0 16px', borderRadius: 4, height: 200, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Empty showIcon />
        </div>
      </If>
      <If condition={!isEmpty(rowData)}>
        <div style={{ position: 'relative', background: 'rgb(250, 250, 250)', border: '1px solid #eee', margin: '8px 0px', padding: '16px 16px 0 16px', borderRadius: 4 }}>
          <If condition={aliyunSite !== 'INTL'}>
            <span className="link-primary" style={{ position: 'absolute', right: 8, top: 8, zIndex: 1 }} onClick={handleMethodTest}>{intl('widget.service.test')}</span>
          </If>
          <DataFields
            dataSource={rowData}
            items={getItems()}
            style={{ wordBreak: 'break-word', border: 0 }}
          />
        </div>
      </If>
    </React.Fragment>
  );
};


Info.propTypes = {
  serviceData: PropTypes.objectOf(PropTypes.any),
  rowData: PropTypes.objectOf(PropTypes.any),
  toggleModal: PropTypes.func,
};
export default modelDecorator(Info);
