import React, { useState, useEffect, useCallback } from 'react';
// import { Wcontainer, Wline } from '@alife/aisc-widgets';
import { useIntl } from '@ali/widget-hooks';
import { Empty, Icon } from '@ali/cn-design';
import Wline from 'containers/Chart/Wline';
import services from 'services';
import PropTypes from 'prop-types';
import { isEmpty, forEach, find, forIn, replace, get, filter, findIndex } from 'lodash';

let dataSource = [];
const Comparison = ({ serviceData = {}, rowData = {} }) => {
  const intl = useIntl();
  const { AppId, Region, ServiceName, Protocol } = serviceData;
  const { Paths, RequestMethods, Uid } = rowData;
  const [curData, setCurData] = useState([{ loading: true }]);
  const [loading, setLoading] = useState(false);
  const [nail, setNail] = useState(false);
  const mapNumber = (value) => {
    if (value >= 1000) return `${Math.round(value / 100) / 10}k`;
    else return value;
  };
  useEffect(() => {
    Paths && getData(Paths[0]);
  }, [AppId, Paths, Uid]);
  // 数据源
  const getData = async(RpcName) => {
    setLoading(true);
    const test = await services.QueryAppMethodMetrics({
      params: {
        AppId,
        Region,
        RpcName,
        EndTime: Date.now()
      }
    });
    const WlineData = [
      { name: 'Qps', key: 'Qps', data: [] },
      { name: 'ExpQps', key: 'ExpQps', data: [] },
    ];
    forEach(get(test, 'CurMetrics', []), d => {
      forIn(d.TagValues || {}, (tag, key) => {
        if (!find(WlineData, { key })) {
          WlineData.push({ name: key === 'null' ? intl('widget.app.canary_no_tag') : key, key, data: [] });
          WlineData.push({ name: intl('widget.msc.throw_name', { name: key }), key: `exp_${intl('widget.app.canary_no_tag')}`, data: [] });
        }
      });
      const Time = d.Timestamp;
      forEach(WlineData, item => {
        if (d[item.key] === 0 || d[item.key] || d[item.key] === null) {
          if (d[item.key] === -1) return item.data.push([Time, undefined]);
          else return item.data.push([Time, Number(d[item.key])]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[item.key])) {
          if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.TagValues[item.key].qps)]);
          else return item.data.push([Time, d.TagValues[item.key].qps]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[replace(item.key, 'exp_', '')])) {
          if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.TagValues[replace(item.key, 'exp_', '')].expQps)]);
          else return item.data.push([Time, d.TagValues[replace(item.key, 'exp_', '')].expQps]);
        }
      });
    });
    if (dataSource.length === 0) {
      dataSource.push({ WlineData, Uid, Paths, RequestMethods, loading, nail: false });
    } else {
      const i = findIndex(dataSource, (item) => item.Uid === Uid);
      if (i === -1) dataSource.push({ WlineData, Uid, Paths, RequestMethods, loading: false });
    }
    setCurData(dataSource);
    setLoading(false);
  };
  // console.log('curData', curData);
  // console.log('dataSource', dataSource);
  // console.log('rowData', rowData);
  // console.log('serviceData', serviceData);
  const options = {
    xAxis: {
      mask: 'HH:mm:ss',
    },
    polar: true,
    legend: {
      position: 'bottom',
      align: 'center',
      style: {
        transform: 'translate(24px, 0)',
      },
    },
    yAxis: [
      {
        min: 0,
        labelFormatter: (value) => {
          if (value >= 1000) return `${(value / 1000).toFixed(1)}k`;
          else return value;
        }
      }
    ]
  };
  const handleDelete = (uId) => {
    dataSource = filter(dataSource, (item) => {
      return item.Uid !== uId;
    });
    setCurData(dataSource);
  };

  const fixingNail = (status, id) => {
    const i = findIndex(dataSource, (item) => item.Uid === id);
    if (status) {
      forEach(dataSource, (item, index) => { if (index === i) { item.nail = true; } else { item.nail = false; } console.log('item ', item); });
      const data = dataSource[i];
      dataSource.splice(i, 1);
      dataSource.unshift(data);
    } else {
      dataSource[i].nail = status;
    }
    setCurData(dataSource);
    setNail(new Date());
  };
  return (
    <React.Fragment>
      <For index="index" each="item" of={curData}>
        <div style={{ background: '#fff', border: '1px solid #d1d5d9', borderRadius: '4px', marginTop: '16px', padding: '16px 0px' }} >
          <Wline
            data={item.WlineData}
            height={239}
            option={options}
            loading={item.loading}
            paths={item.Paths && item.Paths[0]}
            requestMethods={item.RequestMethods && item.RequestMethods[0]}
            handleDelete={handleDelete}
            uId={item.Uid}
            fixingNail={fixingNail}
            nail={item.nail}
          />
        </div>
      </For>
    </React.Fragment>);
};
Comparison.propTypes = {
  serviceData: PropTypes.objectOf(PropTypes.any),
  rowData: PropTypes.objectOf(PropTypes.any),
};
export default Comparison;
