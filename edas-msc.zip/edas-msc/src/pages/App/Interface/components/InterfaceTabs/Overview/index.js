import React, { useEffect, useState } from 'react';
import services from 'services';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import Wline from 'containers/Chart/Wline';
import { forIn, forEach, find, isEmpty, replace, get, join, filter } from 'lodash';
import { Util } from '@alife/aisc-widgets';
import RoleHoc from 'containers/RoleHoc';

const mapPercent = (value, total) => {
  return `${Math.round(value / total * 1000) / 10}%`;
};

const chart = [];

const Overview = (props) => {
  const [loading, setLoading] = useState(false);
  const [currentData, setCurrentData] = useState([]);
  const { Paths = [], Name = '' } = get(props, 'rowData', {});
  const { AppId, Region, Protocol, ServiceName = '' } = get(props, 'serviceData', {});
  const intl = useIntl();

  useEffect(() => {
    if (Protocol === 'springCloud') {
      if (!AppId || isEmpty(Paths) || !Region) return;
      fetchData(join(Paths, ','));
    } else if (Protocol === 'dubbo') {
      if (!AppId || !ServiceName || !Name || !Region) return;
      fetchData(`${ServiceName}@${Name}`);
    }
  }, [AppId, Paths]);

  const fetchData = async (RpcName) => {
    setLoading(true);
    const Data = await services.QueryAppMethodMetrics({
      params: {
        AppId,
        Region,
        RpcName,
        EndTime: Date.now()
      }
    });

    const WlineData = [
      { name: intl('widget.home.total_count'), key: 'Qps', data: [], type: 'qps' },
      // { name: intl('widget.msc.throw_name', { name: 'QPS' }), key: 'ExpQps', data: [], type: 'qps' },
      { name: intl('widget.home.total_count'), key: 'Rt', data: [], type: 'rt' },
    ];
    forEach(get(Data, 'CurMetrics', []), d => {
      const Time = d.Timestamp;
      forIn(d.TagValues || {}, (tag, key) => {
        if (!find(WlineData, { key })) {
          WlineData.push({ name: key === 'null' ? intl('widget.app.canary_no_tag') : key, key, data: [], type: 'qps' });
          // WlineData.push({ name: intl('widget.msc.throw_name', { name: key }), key: `exp_${key}`, data: [], type: 'qps' });
          WlineData.push({ name: key === 'null' ? intl('widget.app.canary_no_tag') : key, key: `rt_${key}`, data: [], type: 'rt' });
        }
      });
      forEach(WlineData, item => {
        if (d[item.key] === 0 || d[item.key] || d[item.key] === null) {
          if (d[item.key] === -1) return item.data.push([Time, undefined]);
          else return item.data.push([Time, Number(d[item.key])]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[item.key])) {
          item.data.push([Time, Number(d.TagValues[item.key].qps || 0)]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[replace(item.key, 'exp_', '')])) {
          // item.data.push([Time, Number(d.TagValues[replace(item.key, 'exp_', '')].expQps)]);
        } else if (!isEmpty(d.TagValues) && !isEmpty(d.TagValues[replace(item.key, 'rt_', '')])) {
          item.data.push([Time, Number(d.TagValues[replace(item.key, 'rt_', '')].rt || 0)]);
        }
      });
    });
    setCurrentData({
      WlineData,
    });
    // new Util.Connect(chart); // 图表联动，需要在图表渲染之后才能配置
    setLoading(false);
  };


  return (
    <React.Fragment>
      <Wline
        data={filter(currentData.WlineData || [], item => item.type === 'qps')}
        height={200}
        title={intl('widget.msc.qps_data_s')}
        style={{ padding: 16, margin: '8px 8px 8px 0', borderRadius: 4, border: '1px solid #eee' }}
        option={{
          legend: {
            position: 'bottom',
            align: 'center',
          },
          padding: [12, 32, 48, 48],
          tooltip: {
            valueFormatter: (value, data, index, rawData) => {
              if (index === 0) return value || 0;
              const item = find(rawData, { name: intl('widget.home.total_count') });
              if (!item) return value || 0;
              return `${value} (${mapPercent(value, item.value || 0)})`;
            },
          }
        }}
        getChartInstance={c => {
          chart[0] = c;
          new Util.Connect(chart)
        }}
        loading={loading}
      />
      <Wline
        data={filter(currentData.WlineData || [], item => item.type === 'rt')}
        height={200}
        title={intl('widget.msc.rt_data_s')}
        style={{ padding: 16, margin: '8px 8px 8px 0', borderRadius: 4, border: '1px solid #eee' }}
        option={{
          legend: {
            position: 'bottom',
            align: 'center',
          },
          padding: [12, 32, 48, 48],
          tooltip: {
            valueFormatter: (value) => {
              return Math.round((value || 0) * 100) / 100;
            },
          }
        }}
        getChartInstance={c => {
          chart[1] = c;
          new Util.Connect(chart)
        }}
        loading={loading}
      />
    </React.Fragment>
  );
};
Overview.propTypes = {
};

export default RoleHoc(Overview, false);
