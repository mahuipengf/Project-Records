import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { Empty, Table } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import { get, isEmpty, uniqueId, map, join, head } from 'lodash';

const Expanded = ({ record, onRowClick, rowData = {} }) => {
  const [dubboService, setDubboService] = useState({});
  const [loading, setLoading] = useState(false);
  const intl = useIntl();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const params = {
      Region: record.Region,
      ServiceType: 'dubbo',
      AppId: record.AppId,
      ServiceGroup: record.Group,
      ServiceVersion: record.Version,
      ServiceName: record.ServiceName,
    };

    setLoading(true);
    const Data = await services.fetchServiceBasicInfo({
      data: params,
      customErrorHandle: (err, response, callback) => {
        callback();
      }
    });
    setLoading(false);
    setDubboService({
      ...Data,
      Methods: map(Data.Methods, item => ({ ...item, Uid: uniqueId() }))
    });
  };

  const column = [
    {
      key: 'Name',
      title: intl('widget.service.method_name'),
      dataIndex: 'Name',
      cell: value => <div style={{ wordBreak: 'break-all', }}><Empty value={value}>{value}</Empty></div>,
    },
  ];

  return (
    <Table
      style={{ margin: 4 }}
      dataSource={dubboService.Methods}
      hasBorder={false}
      loading={loading}
      hasHeader={false}
      onRowClick={(value) => onRowClick({ ...record, rowData: value })}
      cellProps={() => ({ style: { border: 0 } })}

      rowProps={rowRecord => ({
        className: `dubbo-table-expanded ${`${rowRecord.Name}:${rowRecord.ReturnType}` === `${rowData.Name}:${rowData.ReturnType}` ? 'dubbo-table-expanded-active' : ''} }`,
        style: {
          cursor: 'pointer'
        }
      })}
    >
      <For
        each="item"
        of={column}
      >
        <Table.Column {...item} />
      </For>
    </Table>
  );
};

Expanded.propTypes = {
  record: PropTypes.objectOf(PropTypes.any),
  onRowClick: PropTypes.func,
  rowData: PropTypes.objectOf(PropTypes.any),
};
export default Expanded;
