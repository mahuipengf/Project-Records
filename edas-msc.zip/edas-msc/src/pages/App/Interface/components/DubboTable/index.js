import React, { useEffect, useState } from 'react';
import Cookie from 'js-cookie';
import { TableContainer, CopyContent, Button, Tab } from '@ali/cn-design';
import { get, isEmpty, uniqueId, map, join } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import PropTypes from 'prop-types';
import Expanded from './Expanded';
import InterfaceTabs from '../InterfaceTabs';
import './index.less';

const DubboTable = (props) => {
  const { AppId, Region } = props;
  const [dubboService, setDubboService] = useState({});
  const [loading, setLoading] = useState(false);
  const intl = useIntl();
  const aliyunLang = Cookie.get('aliyun_lang') || 'zh';

  const fetchDubboService = async (params) => {
    const data = {
      ServiceType: 'dubbo',
      AppId,
      PageNumber: params.pageNumber,
      PageSize: params.pageSize,
      ServiceName: params.ServiceName,
      SearchType: 'service',
      Region
    };
    setLoading(true);
    const Data = await services.fetchServicesList({
      data,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      }
    });
    setLoading(false);
    const { TotalSize, Result } = Data || {}; // dubbo 一个应用会有多个服务
    return {
      TotalCount: TotalSize,
      Data: map(Result, item => ({
        ...item,
        Uid: uniqueId(),
        Region: item.Region || Region,
        AppId: item.AppId || AppId,
        Protocol: 'dubbo',
      }))
    };
  };


  const expandedRowRender = record => {
    return <Expanded record={record} onRowClick={setDubboService} rowData={dubboService.rowData} />;
  };

  const search = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.service.service_name'),
          value: 'ServiceName',
          width: aliyunLang === 'en' ? 130 : 120,
        },
      ],
      defaultValue: 'ServiceName',
      style: { width: aliyunLang === 'en' ? 140 : 80 },
    },
    isCanRefresh: true,
  };

  const columns = [
    {
      key: 'ServiceName',
      title: intl('widget.service.httpMethods'),
      dataIndex: 'ServiceName',
    },
  ];

  return (

    <div style={{ display: 'flex', marginTop: 16 }}>
      <div style={{ flex: 1, border: '1px solid #eee', borderRadius: '4px 0 0 4px', padding: '8px 16px', overflow: 'auto', }} className="dubbo-table">
        <TableContainer
          loading={loading}
          fetchData={fetchDubboService}
          primaryKey="Uid"
          columns={columns}
          expandedRowRender={expandedRowRender}
          cellProps={() => ({ style: { padding: '8px 0' } })}
          hasHeader={false}
          rowProps={() => ({
            style: { borderTopWidth: 0 }
          })}
          search={search}
          pagination={{ pageSizeSelector: false }}
          followTrigger
        />
      </div>
      <InterfaceTabs
        serviceData={dubboService}
        rowData={dubboService.rowData}
      />
    </div>
  );
};


DubboTable.propTypes = {
  AppId: PropTypes.string,
  Region: PropTypes.string,
};

export default DubboTable;

