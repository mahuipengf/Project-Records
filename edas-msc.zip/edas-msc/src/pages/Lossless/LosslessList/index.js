import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, modelDecorator, Empty } from '@ali/cn-design';
import Cluster from 'pages/App/AppList/components/Cluster';
import Status from 'components/Status/CommonStatus';
import Events from './Events';

function AppList(props) {
  const { tableUniqueKey } = props;
  const [isCanCustomColumns] = useState(true);
  const [isCanMultipleSearch] = useState(true);
  const [isCanRefresh] = useState(true);
  const [searchValues] = useGlobalState('searchValues');
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const [autoFetch, setAutoFetch] = useState(false);

  const intl = useIntl();
  const { regionId } = searchValues;

  useEffect(() => {
    setAutoFetch(true);
  }, []);

  const fetchData = async (params) => {
    const Data = await services.GetAppList({
      params: {
        ...params,
        regionId,
      }
    });
    const { Result = [], TotalSize = 0 } = Data || {};
    return {
      Data: Result,
      TotalCount: TotalSize,
    };
  };

  const columns = [
    {
      key: 'AppName',
      title: intl('widget.app.name'),
      dataIndex: 'AppName',
      cell: value => <Empty value={value}>{value}</Empty>,
    },
    {
      key: 'Source',
      title: intl('widget.app.cluster_type'),
      dataIndex: 'Source',
      cell: value => <Cluster value={value} intl={intl} />
    },
    {
      key: 'Enable',
      title: intl('widget.common.state'),
      dataIndex: 'Enable',
      cell: value => <Status value={value} intl={intl} />
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => <Events record={record} handleEdit={() => handleEdit(record)} setFetchDataTime={setFetchDataTime} />,
    },
  ];

  const searchs = {
    typeInfo: {
      types: [
        {
          label: intl('widget.app.cluster_type_all'),
          value: '',
        },
        {
          label: intl('widget.app.cluster_ecs'),
          value: 'ecs',
        },
        {
          label: intl('widget.app.cluster_k8s'),
          value: 'k8s',
        },
      ],
      defaultValue: '',
      value: 'type',
    },
    filterInfo: {
      filters: [
        {
          label: intl('widget.app.name'),
          value: 'appName',
        },
      ],
      defaultValue: 'appName',
    },
    isCanCustomColumns,
    isCanMultipleSearch,
    tableUniqueKey,
    isCanRefresh,
  };

  return (
    <React.Fragment>
      <TableContainer
        autoFetch={autoFetch}
        fetchData={fetchData}
        primaryKey="AppId"
        columns={columns}
        search={searchs}
        affixActionBar
        isUseStorage
        refreshIndex={fetchDataTime}
      />
    </React.Fragment>
  );
}

AppList.propTypes = {
  tableUniqueKey: PropTypes.string,
};

export default modelDecorator(AppList);
