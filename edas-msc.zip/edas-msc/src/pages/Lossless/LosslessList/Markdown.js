import React from 'react';
import ReactMarkdown from 'components/Markdown';
import services from 'services';
import { get } from 'lodash';

const AppAccessType = () => {
  const fetchData = async () => {
    const res = await services.getlosslessMarkdown();
    const data = get(res, 'data');
    return { data };
  };

  return (
    <div style={{ paddingBottom: 32 }}>
      <ReactMarkdown fetchData={() => fetchData()} />
    </div>
  );
};

export default AppAccessType;
