import React from 'react';
import PropTypes from 'prop-types';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { useIntl } from '@ali/widget-hooks';

const Events = (props) => {
  const intl = useIntl();
  const { record, setFetchDataTime } = props;
  const { id, appName, enable } = record;

  const handleOpen = () => {
    // confirm({
    //   title: intl('widget.lower_limit.list.open'),
    //   content: intl('widget.lower_limit.list.open_confirm', { name: appName }),
    //   onOk: () => services.updatePolicy({ id, enable: true }).then(res => {
    //     Message.success(intl('widget.common.open_successful'));
    //     setFetchDataTime(Date.now());
    //   }),
    // });
  };

  const handleClose = () => {
    // confirm({
    //   title: intl('widget.lower_limit.list.close'),
    //   content: intl('widget.lower_limit.list.close_confirm', { name: appName }),
    //   onOk: () => services.updatePolicy({ id, enable: false }).then(res => {
    //     Message.success(intl('widget.common.close_successful'));
    //     setFetchDataTime(Date.now());
    //   }),
    // });
  };

  return (
    <Actions expandTriggerType="hover">
      <If condition={enable}>
        <LinkButton key="3" onClick={handleClose}>{intl('widget.lossless.list.close')}</LinkButton>
      </If>
      <If condition={!enable}>
        <LinkButton key="2" onClick={handleOpen}>{intl('widget.lossless.list.open')}</LinkButton>
      </If>
    </Actions>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  setFetchDataTime: PropTypes.func,
};

export default Events;
