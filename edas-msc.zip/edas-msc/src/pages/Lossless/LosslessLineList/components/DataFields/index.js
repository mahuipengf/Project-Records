import React, { useState, useEffect } from 'react';
import DataFields from '@alicloud/console-components-data-fields';
import { Icon, Switch, Balloon, Form, Field, Empty } from '@ali/cn-design';
import Dialog from 'components/Dialog';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import styles from './index.less';
import services from 'services';
import LosslessConfiguration from '../LosslessConfiguration';
import { isEmpty } from 'lodash';
import Cookie from 'js-cookie';

const triggerIcon = <Icon type="help" className="lossless-app-list-icon" />;

const DataFieldsAssembly = ({ rowData = {}, updateStatus, details, RegionId }) => {
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';
  const [show, setShow] = useState(false);
  const [visible, setVisible] = useState(false);
  const field = Field.useField();
  const { init, validate, setValues } = field;
  const intl = useIntl();
  useEffect(() => {
    !isEmpty(rowData) && setValues({ ...rowData, LosslessConfiguration: rowData, Enable: rowData.Enable });
  }, [rowData, show]);
  const items = [
    {
      dataIndex: 'WarmupTime',
      label: intl('widget.msc_lossless_preheating_time'),
      style: {
        color: '#000',
        fontWeiget: 'bold'
      }
    },
    {
      dataIndex: 'FuncType',
      label: <span>{intl('widget.msc_lossless_preheating_curve')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl.html('widget.msc_lossless_preheating_curve_tips_info')}</Balloon></span>,
    },
    {
      dataIndex: 'DelayTime',
      label: <span>{intl('widget.msc_lossless_delay_register_time')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl('widget.msc_lossless_config_register_delay')}</Balloon></span>,
      style: {
        color: 'red'
      }
    },
    {
      dataIndex: 'Senior',
      span: 24,
      style: {
        width: '40px !important',
        color: '#0070CC',
      },
      render: () => (
        <div
          className={styles['graphical-senior']}
        >
          <span onClick={() => handleClick()}>
            {intl('widget.msc_lossless_senior')}
            <If condition={show}>
              <Icon type="arrow-up" size="xxs" style={{ marginLeft: 4 }} />
            </If>
            <If condition={!show}>
              <Icon type="arrow-down" size="xxs" style={{ marginLeft: 4 }} />
            </If>
          </span>
        </div>
      ),
    },
  ];
  const itemsCopy = [
    {
      dataIndex: 'WarmupTime',
      label: intl('widget.msc_lossless_preheating_time'),
      style: {
        color: '#000',
      }
    },
    {
      dataIndex: 'FuncType',
      label: <span>{intl('widget.msc_lossless_preheating_curve')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl.html('widget.msc_lossless_preheating_curve_tips_info')}</Balloon></span>,
    },
    {
      dataIndex: 'DelayTime',
      label: <span>{intl('widget.msc_lossless_delay_register_time')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl('widget.msc_lossless_config_register_delay')}</Balloon></span>,
    },
    {
      dataIndex: 'Senior',
      span: 24,
      style: {
        width: '40px !important',
        color: '#0070CC',
      },
      render: () => (
        <div
          className={styles['graphical-senior']}
        >
          <span onClick={() => handleClick()}>
            {intl('widget.msc_lossless_senior')}
            <If condition={show}>
              <Icon type="arrow-up" size="xxs" style={{ marginLeft: 4 }} />
            </If>
            <If condition={!show}>
              <Icon type="arrow-down" size="xxs" style={{ marginLeft: 4 }} />
            </If>
          </span>
          <If condition={show}>
            <If condition={aliyunSite !== 'INTL'}>
              <span style={{ marginLeft: '16px' }}>
                <span style={{ color: '#000' }}>{intl('widget.msc.lossless.prompt.information.survival.check1')}</span>
                <span onClick={() => (window.open(
                  'https://help.aliyun.com/document_detail/196145.html',
                  '_blank'
                ))}
                >
                  {intl('widget.msc.lossless.prompt.information.survival.check2')}
                </span>
                <span style={{ color: '#000' }}>{intl('widget.msc.lossless.prompt.information.survival.check3')}</span>
              </span>
            </If>
          </If>
        </div>
      ),
    },
    {
      dataIndex: 'Aligned',
      label: <span>{intl.html('widget.msc_lossless_service_k8s_inspect')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl.html('widget.msc_lossless_service_k8s_inspect_tips_info')}</Balloon></span>,
      render: (val) => (
        <div>
          <Switch
            {
              ...init('Aligned', {
                initValue: false,
                valueName: 'checked'
              })
            }
            disabled
          />
        </div>
      ),
    },
    {
      dataIndex: 'Related',
      label: <span>{intl.html('widget.msc_lossless_service_preheating_publish')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl.html('widget.msc_lossless_service_preheating_publish_tips_info')}</Balloon></span>,
      render: (val) => (
        <div>
          <Switch
            {
              ...init('Related', {
                initValue: false,
                valueName: 'checked'
              })
            }
            disabled
          />
        </div>
      ),
    },
  ];
  const handleClick = () => {
    if (show) {
      setShow(false);
    } else {
      setShow(true);
    }
  };
  const onOk = () => {
    setVisible(true);
    // validate &&
      validate(async(errors, values) => {
        if (values.DelayTime !== undefined && values.FuncType !== undefined && values.WarmupTime !== undefined ) {
          await services.ModifyLosslessRule({
            params: {
              ...values,
              Enable: values.Enable,
              RegionId,
              // Aligned: values.LosslessConfiguration.Aligned,
              // DelayTime: values.LosslessConfiguration.DelayTime,
              // FuncType: values.LosslessConfiguration.FuncType,
              // Related: values.LosslessConfiguration.Related,
              // WarmupTime: values.LosslessConfiguration.WarmupTime,
            },
          }).then((res) => {
            setVisible(false);
            updateStatus(Date.now());
  
          });
        } else {
          return;
        }
      });
  };
  const handleControlStatus = (v) => {
    const Enable = v;
    validate(async (errors, values) => {
      await services.ModifyLosslessRule({
        params: {
          ...values,
          Enable,
          RegionId,
          Aligned: values.LosslessConfiguration.Aligned,
          DelayTime: values.LosslessConfiguration.DelayTime,
          FuncType: values.LosslessConfiguration.FuncType,
          Related: values.LosslessConfiguration.Related,
          WarmupTime: values.LosslessConfiguration.WarmupTime,
        },
      }).then((res) => {
        updateStatus(Date.now());
      });
    });
  };
  const triggerInfo = (
    <Switch
      {...init('Enable', {
        initValue: false,
        valueName: 'checked',
        props: {
          onChange: v => handleControlStatus(v),
        }
      })}
    />
  );
  return (
    <Form field={field}>
      <Empty showIcon value={rowData}>
        <div className={styles['graphical-configuration']}>
          <div>
            {intl('widget.msc_lossless_online_app_config')}
            <span className={styles['graphical-edit']} onClick={() => setVisible(true)}>
              <Icon
                type="edit"
              /> {intl('widget.common.edit')}
            </span>
          </div>
          <div className={`${details === 'details' ? styles['graphical-enable-detailes'] : styles['graphical-enable']}`}>
            <Balloon trigger={triggerInfo} align="b" closable={false}>
              {`${!isEmpty(rowData) && rowData.Enable ? intl('widget.msc_lossless_switch_off_info') : intl('widget.msc_lossless_switch_open_info')}`}
            </Balloon>
          </div>
        </div>
        <DataFields dataSource={rowData} items={show ? itemsCopy : items} style={{ marginLeft: 20 }} />
        <Dialog
          title={intl('widget.msc_lossless_online_app_config')}
          visible={visible}
          onOk={() => onOk()}
          onCancel={() => setVisible(false)}
          onClose={() => setVisible(false)}
        >
          <LosslessConfiguration
            {...init('LosslessConfiguration', {
              initValue: {},
            })}
            field={field}
          />
        </Dialog>
      </Empty>
    </Form>
  );
};
DataFieldsAssembly.propTypes = {
  rowData: PropTypes.objectOf(PropTypes.any),
  updateStatus: PropTypes.func,
  details: PropTypes.string,
};
export default DataFieldsAssembly;
