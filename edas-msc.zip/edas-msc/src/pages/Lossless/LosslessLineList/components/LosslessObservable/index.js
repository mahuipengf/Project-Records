import React, { useState, useEffect } from 'react';
import { Icon, DatePicker } from '@ali/cn-design';
import PropTypes from 'prop-types';
import styles from './index.less';
import services from 'services';
// import { Wcontainer, Wline, Wbar } from '@alife/aisc-widgets';
import { useIntl } from '@ali/widget-hooks';
import { forEach, forIn, find, isEmpty, replace, map } from 'lodash';
import { timeFmt } from 'utils';
import { Interval } from 'components/Charts';

const mapPercent = (value, total) => `${Math.round(value / total * 1000) / 10}%`;
const LosslessObservable = ({ rowData, Region, initTime, fetchTime }) => {
  const { AppId } = rowData;
  const RpcName = '/mseAll';
  const [time, setTime] = useState();
  const [barData, setBarData] = useState([]);
  const intl = useIntl();
  useEffect(() => {
    fetchData();
  }, [rowData, initTime]);
  const fetchData = async() => {
    if (!isEmpty(rowData)) {
      // await queryAppTopNMacs(initTime);
      await queryEventOverview(initTime, 24 * 60 * 60 * 1000);
    } else {
      setBarData(eventData);
    }
  };
  const queryAppTopNMacs = async (EndTime) => {
    const list = [];
    const QueryAppTopNMacsList = await services.QueryAppTopNMacs({
      params: {
        AppId,
        RpcName,
        EndTime,
        StartTime: EndTime - 86400000,
      }
    });
    const macsList = map(QueryAppTopNMacsList.Result, item => {
      if (item.Pid) {
        list.push(item.PrivateIp.concat('-', item.Pid));
        return {
          value: item.PrivateIp.concat('-', item.Pid),
          label: item.PrivateIp.concat('-', item.Pid),
        };
      } else {
        return false;
      }
    }).filter(item => item);
    QueryAppTopNMacsList.ip = list;
    // await queryAppRPCMacMetrics(list.join(), EndTime);
    QueryAppTopNMacsList.macsList = macsList;
  };
  const queryAppRPCMacMetrics = async (InstanceIpList = [], EndTime, PageNumber = 1, PageSize = 1) => {
    const res = await services.QueryAppRPCMacMetrics({
      params: {
        AppId,
        RpcName,
        InstanceIpList,
        PageNumber,
        PageSize,
        EndTime: EndTime || Date.now(),
        StartTime: EndTime - 86400000,
      }
    });
    if (res) {
      const curData = [];
      forIn(res.CurMacMetricsMap || {}, (val) => {
        const WlineData = [
          { name: intl('widget.home.total_count'), key: 'qps', data: [] },
          { name: intl('widget.msc.throw_name', { name: 'QPS' }), key: 'expQps', data: [] },
        ];
        forEach(val.curMetrics || [], d => {
          forIn(d.tagValues || {}, (tag, key) => {
            if (!find(WlineData, { key })) {
              WlineData.push({ name: key === 'null' ? intl('widget.app.canary_no_tag') : key, key, data: [] });
              WlineData.push({ name: intl('widget.msc.throw_name', { name: key }), key: `exp_${intl('widget.app.canary_no_tag')}`, data: [] });
            }
          });
          const Time = d.timestamp;
          forEach(WlineData, item => {
            if (d[item.key] === 0 || d[item.key] || d[item.key] === null) {
              if (d[item.key] === -1) return item.data.push([Time, undefined]);
              else return item.data.push([Time, Number(d[item.key])]);
            } else if (!isEmpty(d.tagValues) && !isEmpty(d.tagValues[item.key])) {
              if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.tagValues[item.key].qps)]);
              else return item.data.push([Time, d.tagValues[item.key].qps]);
            } else if (!isEmpty(d.tagValues) && !isEmpty(d.tagValues[replace(item.key, 'exp_', '')])) {
              if (typeof d[item.key] === 'number' || typeof d[item.key] === 'string') return item.data.push([Time, Number(d.tagValues[replace(item.key, 'exp_', '')].expQps)]);
              else return item.data.push([Time, d.tagValues[replace(item.key, 'exp_', '')].expQps]);
            }
          });
        });
        curData.push({ WlineData, Ip: `${val.privateIp}-${val.pid}` });
      });
    }
  };
  const eventData = [
    { name: intl('widget.msc_lossless_service_register_success'), key: 'ACTIVE_TRACE_Registration_Finish', data: [], value: 0 },
    { name: intl('widget.msc_lossless_Readiness_check_passed'), key: 'ACTIVE_TRACE_Readiness_Finish', data: [], value: 0 },
    { name: intl('widget.msc_lossless_preheating_start'), key: 'ACTIVE_TRACE_Warmup_Start', data: [], value: 0 },
    { name: intl('widget.msc_lossless_preheating_end'), key: 'ACTIVE_TRACE_Warmup_End', data: [], value: 0 },
    { name: intl('widget.msc_lossless_offline_success'), key: 'ACTIVE_TRACE_Graceful_Shutdown', data: [], value: 0 },
  ];
  const queryEventOverview = async (EndTime = Date.now(), TimeDifference) => {
    const res = await services.QueryEventOverview({
      params: {
        AppId,
        Region,
        IsLossless: true,
        EndTime,
        StartTime: EndTime - TimeDifference,
      },
    });
    forEach(eventData, item => {
      if (!isEmpty(res) || res[item.key] >= 0) {
        item.data.push([item.name, res[item.key]]);
        item.value = res[item.key];
      }
    });
    setBarData(eventData);
  };
  const options = {
    xAxis: {
      mask: 'HH:mm:ss',
      tickCount: 5,
    },
    yAxis: [
      {
        min: 0,
        labelFormatter: (value) => {
          if (value >= 1000) return `${(value / 1000).toFixed(1)}k`;
          else return value;
        }
      },
    ],
    legend: {
      position: 'bottom',
      align: 'center',
    },
    // padding: [12, 16, 48, 32],
    tooltip: {
      valueFormatter: (value, data, index, rawData) => {
        if (index === 0) return value || 0;
        const item = find(rawData, { name: intl('widget.home.total_count') });
        if (!item) {
          return value || 0;
        }
        return `${value} (${mapPercent(value || 0, item.value || 0)})`;
      },
    }
  };
  const handleClickChangeTime = async val => {
    const Time = new Date(val).getTime();
    await setTime(Time);
  };
  const onOk = () => { queryEventOverview(time, 24 * 60 * 60 * 1000); fetchTime(time); };
  const disabledDate = (date) => date.valueOf() > Date.now();
  const triggerIcon = <Icon type="help" className="lossless-app-list-icon" />;
  return (
    <div className={styles['observable-content']}>
      <div className={styles['observable-configuration']}>
        <div className={styles['observable-title']}>{intl('widget.msc_lossless_app_event_statistics')}</div>
        <div className={styles['observable-enable']}>
          <span>{intl('widget.msc_lossless_end_time')}</span>
          <DatePicker
            format="YYYY/MM/DD"
            defaultValue={timeFmt(initTime, 'YYYY/MM/DD HH:mm:ss')}
            disabledDate={disabledDate}
            onOk={onOk}
            onChange={handleClickChangeTime}
            showTime={{ format: 'HH:mm:ss' }}
            style={{ marginLeft: 6 }}
            key={initTime}
            // followTrigger
          />
        </div>
      </div>
      {/* <Empty showIcon value={isValue}>
        <For index="index" each="item" of={upData}>
          <Wcontainer >
            <Wbar
              data={barData}
              height={170}
            />
          </Wcontainer>
        </For>
      </Empty> */}
      <Interval data={barData} axis="name" yxis="value" lossless="lossless" />

    </div>
  );
};
LosslessObservable.propTypes = {
  rowData: PropTypes.objectOf(PropTypes.any),
  Region: PropTypes.string,
  initTime: PropTypes.number,
  fetchTime: PropTypes.func,
};
export default LosslessObservable;
