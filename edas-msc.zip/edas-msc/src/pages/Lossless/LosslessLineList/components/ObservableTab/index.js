import React from 'react';
import { Tab } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import NodeTable from './components/NodeTable';

const ObservableTab = () => {
  const intl = useIntl();
  const Tabs = [
    {
      tab: intl('widget.msc.interface_details'),
      key: 'datails',
      content: <NodeTable />
    }
  ];

  return (
    <div>
      <Tab>
        <For index="index" each="items" of={Tabs} >
          <Tab.Item title={items.tab} key={items.key} >
            {items.content}
          </Tab.Item>
        </For>
      </Tab>
    </div>
  );
};

export default ObservableTab;