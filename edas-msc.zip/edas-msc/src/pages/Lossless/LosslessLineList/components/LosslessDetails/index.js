import React, { useEffect, useState } from 'react';
import { TableContainer, Empty, Balloon } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import { get, isEmpty, head } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import PropTypes from 'prop-types';
import NodeTable from '../ObservableTab/components/NodeTable';
import { timeFmt } from 'utils';
import './index.less';

const LosslessDetails = ({ val, initTime }) => {
  const { AppId } = val;
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [rowData, setRowData] = useState({});
  const { searchValues } = useGlobalState();
  const { regionId: Region } = searchValues;
  const intl = useIntl();
  useEffect(() => {
    setRefreshIndex(Date.now());
  }, [val, initTime]);
  const fetchData = async(params) => {
    const res = await services.ListEventsPage({
      params: {
        PageNumber: 1,
        ...params,
        AppId,
        Region,
        PageSize: 5,
        IsDistinct: true,
        IsLossless: true,
        EndTime: initTime,
        StartTime: initTime - 24 * 60 * 60 * 1000,
      }
    });
    const Data = get(res, 'Result', []);
    const TotalCount = get(res, 'TotalSize', 0);
    if (!isEmpty(val) && head(Data)) setRowData(head(Data));
    else setRowData({});
    return { Data, TotalCount };
  };
  const search = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.msc_lossless_node_name'),
          value: 'InstanceId',
          width: 150,
        },
      ],
      defaultValue: 'InstanceId',
      placeholder: intl('widget.msc_lossless_search_content'),
      style: { width: 110 },
    },
    isCanRefresh: true,
    isCanMultipleSearch: true,
    tableUniqueKey: true,
  };
  // EventType 事件类型
  const eventType = {
    ACTIVE_TRACE_Graceful_Shutdown: intl('widget.msc_lossless_offline_success'),
    ACTIVE_TRACE_Warmup_Start: intl('widget.msc_lossless_preheating_start'),
    ACTIVE_TRACE_Warmup_End: intl('widget.msc_lossless_preheating_end'),
    ACTIVE_TRACE_Readiness_Finish: intl('widget.msc_lossless_Readiness_check_passed'),
    ACTIVE_TRACE_Registration_Finish: intl('widget.msc_lossless_service_register_success'),

  };
  const columns = [
    {
      key: 'InstanceId',
      title: intl('widget.msc_lossless_node_name'),
      dataIndex: 'InstanceId',
      width: 130,
      cell: (value, index, record) => (
        <Empty value={record.ExtraInfo && record.ExtraInfo.ip}>
          {/* {record.ExtraInfo.ip}-{record.ExtraInfo.pid} */}
          <div style={{ fontFamily: 'PingFangSC-Regular', fontSize: 12, padding: '9px 0px', color: '#0070cc', cursor: 'pointer', width: 100, textOverflow: 'ellipsis', whiteSpace: 'nowrap', overflow: 'hidden' }}>
            <Balloon trigger={`${record.ExtraInfo.pid ? `${record.ExtraInfo.ip}-${record.ExtraInfo.pid}` : record.ExtraInfo.ip}`} align="t" closable={false}>
              {`${record.ExtraInfo.pid ? `${record.ExtraInfo.ip}-${record.ExtraInfo.pid}` : record.ExtraInfo.ip}`}
            </Balloon>
          </div>
        </Empty>
      ),
    },
    {
      key: 'EventType',
      title: intl('widget.msc_lossless_status_time'),
      dataIndex: 'EventType ',
      style: {
        textAlign: 'right'
      },
      cell: (val, index, record) => (
        <div style={{ textAlign: 'right', display: 'flex', justifyContent: 'flex-end', width: '170px' }}>
          <span style={{ width: '105px', textOverflow: 'ellipsis', whiteSpace: 'nowrap', overflow: 'hidden' }}>
            <Balloon trigger={eventType[record.EventType]} align="t" closable={false}>
              {eventType[record.EventType]}
            </Balloon>
          </span>
          <span className="lossless-observable-table-clearance">/</span>
          <span>{timeFmt(record.TimeStamp, 'HH:mm:ss')}</span>
        </div>
      ),
    },
  ];
  // const fetchData = async() => {
  //   return {
  //     Data: dataSource,
  //     TotalCount: 2,
  //   };
  // };
  const NoPidAlertTips = () => {
    DialogAlert({
      title: intl('widget.msc_lossless_tips'),
      content: <div style={{ width: '300px', lineHeight: '18px' }}>{intl.html('widget.msc_lossless_record_extraInfo_no_pip')}</div>,
    });
  };
  return (
    <Empty showIcon value={val}>
      <div
        style={{
          display: 'flex',
          marginBottom: 16,
          border: '1px solid #D1D5D9',
          borderRadius: '4px 0 0 4px',
          overflow: 'hidden',
        }}
      >
        <div
          style={{
            minWidth: '345px',
            padding: '15px 9px'
          }}
          className="sc-table"
        >
          <TableContainer
            refreshIndex={refreshIndex}
            fetchData={fetchData}
            columns={columns}
            cellProps={(rowIndex, colIndex, dataIndex, record) => ({
              style: {
                width: colIndex === 0 ? 100 : undefined,
                cursor: 'pointer',
              },
            })}
            rowProps={(record) => ({
              className: `${
                `${record.TimeStamp}:${record.AppName}:${record.AppId}:${rowData.ExtraInfo && record.ExtraInfo.ip}` ===
                `${rowData.TimeStamp}:${rowData.AppName}:${rowData.AppId}:${rowData.ExtraInfo && rowData.ExtraInfo.ip}`
                  ? 'table-active'
                  : ''
              } ${record.Uid}`,
              style: {
                position: 'relative',
                cursor: 'pointer',
              },
            })}
            search={search}
            onRowClick={(record) => {
              setRowData(record);
              if (!record.ExtraInfo.ip || !record.ExtraInfo.pid) NoPidAlertTips();
            }
            }
            pagination={{
              shape: 'no-border',
              type: 'simple',
              pageSize: '5',
              pageSizeSelector: false,
            }}
          />
        </div>
        <div style={{ flex: 2, borderLeft: '1px solid #D1D5D9' }}>
          <NodeTable rowData={rowData} Region={Region} />
        </div>
      </div>
    </Empty>

  );
};

LosslessDetails.propTypes = {
  val: PropTypes.objectOf(PropTypes.any),
  initTime: PropTypes.number,
};

export default LosslessDetails;
