import React, { useState, useEffect } from 'react';
import styles from './index.less';
import DataFields from '../DataFields';
import LosslessDetails from '../LosslessDetails';
import LosslessObservable from '../LosslessObservable';
import { useGlobalState } from '@ali/widget-hooks';
import PropTypes from 'prop-types';

const Graphical = ({ rowData, updateStatus }) => {
  const { searchValues } = useGlobalState();
  const { regionId: Region } = searchValues;
  const [initTime, setInitTIme] = useState(0);
  const fetchTime = (time) => setInitTIme(time);
  useEffect(() => setInitTIme(Date.now()), [rowData]);
  return (
    <div className={styles['graphical-content']}>
      <div className={styles['graphical-container']}>
        <DataFields rowData={rowData} updateStatus={updateStatus} RegionId={Region} />
        <hr />
        <LosslessObservable rowData={rowData} Region={Region} initTime={initTime} fetchTime={fetchTime} />
        <LosslessDetails val={rowData} initTime={initTime} />
      </div>
    </div>
  );
};

Graphical.propTypes = {
  rowData: PropTypes.objectOf(PropTypes.any),
  updateStatus: PropTypes.func,
};

export default Graphical;
