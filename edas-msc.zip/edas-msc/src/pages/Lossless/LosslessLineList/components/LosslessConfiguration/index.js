import React, { useEffect, useState } from 'react';
import { Form, NumberPicker, Switch, Grid, Icon, Balloon } from '@ali/cn-design';
import styles from '../DataFields/index.less';
import PropTypes from 'prop-types';
import { isEmpty } from 'lodash';
import { useIntl } from '@ali/widget-hooks';
import Cookie from 'js-cookie';

const { Row, Col } = Grid;
const LosslessConfiguration = ({ value = {}, field, onChange }) => {
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';
  const { init, setValues } = field;
  const [show, setShow] = useState(false);
  const intl = useIntl();
  useEffect(() => {
    !isEmpty(value) && setValues(value);
  }, [value]);
  const triggerIcon = <Icon type="help" className="lossless-app-list-icon" />;
  return (
    <React.Fragment>
      <Form field={field} style={{ width: '550px' }}>
        <Row>
          <Col span={11}>
            <Form.Item label={intl('widget.msc_lossless_preheating_time')} required>
              <NumberPicker
                {...init('WarmupTime', {
                  props: {
                    onChange: (v) => v,
                  },
                  rules: [
                    {
                      required: true,
                      message: intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 }),
                      validator: (rule, val, callback) => {
                        //  callBack('m')
                        if (val < 0) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 }));
                        } else if (val > 24 * 60 * 60) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 }));
                        } else if (val === undefined) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 }));
                        } else {
                          callback();
                        }
                        // callback();
                      },
                    },
                  ],
                })}
                min={0}
                max={24 * 60 * 60}
                style={{ width: '100%' }}
                placeholder={intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 })}
              />
            </Form.Item>
          </Col>
          <Col span={11} offset={1}>
            <Form.Item
              required
              label={
                <span >{intl.html('widget.msc_lossless_preheating_curve')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl.html('widget.msc_lossless_preheating_curve_tips_info')}</Balloon></span>
              }
            >
              <NumberPicker
                {...init('FuncType', {
                  props: {
                    onChange: (v) => v,
                  },
                  rules: [
                    {
                      required: true,
                      message: intl('widget.common.min_max.num', { min: 0, max: 20 }),
                      validator: (rule, val, callback) => {
                        //  callBack('m')
                        if (val < 0) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 20 }));
                        } else if (val > 20) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 20 }));
                        } else if (val === undefined) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 20 }));
                        } else {
                          callback();
                        }
                      },
                    },
                  ],
                })}
                min={0}
                max={20}
                style={{ width: '100%' }}
                placeholder={intl('widget.common.min_max.num', { min: 0, max: 20 })}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row>
          <Col span={11}>
            <Form.Item label={<span>{intl.html('widget.msc_lossless_delay_register_time')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl('widget.msc_lossless_config_register_delay')}</Balloon></span>} required>
              <NumberPicker
                {...init('DelayTime', {
                  props: {
                    onChange: (v) => {
                      onChange(v);
                    },
                  },
                  rules: [
                    {
                      required: true,
                      message: intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 }),
                      validator: (rule, val, callback) => {
                        //  callBack('m')
                        if (val < 0) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 }));
                        } else if (val > 24 * 60 * 60) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 }));
                        } else if (val === undefined) {
                          callback(intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 }));
                        } else {
                          callback();
                        }
                      },
                    },
                  ],
                })}
                min={0}
                max={24 * 60 * 60}
                style={{ width: '100%' }}
                placeholder={intl('widget.common.min_max.num', { min: 0, max: 24 * 60 * 60 })}
              />
            </Form.Item>
          </Col>
        </Row>
        <Row>
          <div
            className={styles['graphical-senior']}
          >
            <span onClick={() => {
              show ? setShow(false) : setShow(true);
            }}
            >
              {intl('widget.msc_lossless_senior')}
              <If condition={!show}>
                <Icon type="arrow-up" size="xxs" style={{ marginLeft: 4 }} />
              </If>
              <If condition={show}>
                <Icon type="arrow-down" size="xxs" style={{ marginLeft: 4 }} />
              </If>
            </span>
            <If condition={show}>
              <If condition={aliyunSite !== 'INTL'}>
                <div style={{ marginTop: '8px' }}>
                  <span style={{ color: '#000' }}>{intl('widget.msc.lossless.prompt.information.survival.check1')}</span>
                  <span onClick={() => (window.open(
                    'https://help.aliyun.com/document_detail/196145.html',
                    '_blank'
                  ))}
                  >
                    {intl('widget.msc.lossless.prompt.information.survival.check2')}
                  </span>
                  <span style={{ color: '#000' }}>{intl('widget.msc.lossless.prompt.information.survival.check3')}</span>
                </div>
              </If>
            </If>
          </div>
        </Row>
        <If condition={show}>
          <Row>
            <Col span={11}>
              <Form.Item
                label={<span style={{ display: 'flex', justifyContent: 'flex-start', flexDirection: 'row', lineHeight: '30px', }}>
                  {intl.html('widget.msc_lossless_service_k8s_inspect_tips_info_edit')}
                  <Balloon trigger={triggerIcon} align="t" closable={false}>{intl.html('widget.msc_lossless_service_k8s_inspect_tips_info')}</Balloon>
                </span>
                }
              >
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <Switch
                    style={{ marginTop: '6px' }}
                    {...init('Aligned', {
                      initValue: false,
                      valueName: 'checked',
                      props: {
                        onChange: (v) => {
                          onChange(v);
                        },
                      },
                    })}
                  />
                </div>
              </Form.Item>
            </Col>
            <Col span={11} offset={1}>
              <Form.Item
                label={<span style={{ lineHeight: '30px' }}>{intl('widget.msc_lossless_service_preheating_publish_tips_info_edit')}<Balloon trigger={triggerIcon} align="t" closable={false}>{intl.html('widget.msc_lossless_service_preheating_publish_tips_info')}</Balloon></span>}
              >
                <Switch
                  style={{ marginTop: '6px' }}
                  {...init('Related', {
                    initValue: false,
                    valueName: 'checked',
                    props: {
                      onChange: (v) => {
                        onChange(v);
                      },
                    },
                  })}
                />
              </Form.Item>
            </Col>
          </Row>
        </If>
      </Form>
    </React.Fragment>
  );
};
LosslessConfiguration.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  field: PropTypes.objectOf(PropTypes.any),
  onChange: PropTypes.func,
};

export default LosslessConfiguration;
