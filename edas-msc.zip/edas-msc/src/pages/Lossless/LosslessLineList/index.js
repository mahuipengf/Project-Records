import React, { useState, useEffect } from 'react';
import { TableContainer, Balloon, Icon } from '@ali/cn-design';
import Graphical from './components/Graphical';
import services from 'services';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { get, head, isEmpty } from 'lodash';
import Status from 'components/Status/CommonStatus';
import './index.less';

const triggerInfo = (val, record) => (
  <div
    style={{
      fontFamily: 'PingFangSC-Regular',
      fontSize: 12,
      padding: '9px 0px',
      color: '#0070cc',
      cursor: 'pointer',
    }}
  >
    <div
      style={{
        display: 'inline-block',
        width: 100,
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
      }}
    >
      {`${val}`}
    </div>
    <span style={{ verticalAlign: 'top' }}>{`（${record.Count}）`}</span>
  </div>
);

const LosslessLineList = () => {
  const { searchValues } = useGlobalState();
  const { regionId: RegionId } = searchValues; // appId: AppId,
  const [rowData, setRowData] = useState({});
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [data, setData] = useState({});
  const [recordIndex, setRecordIndex] = useState(0);
  const intl = useIntl();
  useEffect(() => {
    fetchData();
    setRefreshIndex(Date.now());
  }, []);

  const columns = [
    {
      key: 'AppName',
      title: intl('widget.msc_lossless_app_name_num'),
      dataIndex: 'AppName',
      cell: (val, index, record) => (
        <div style={{ fontFamily: 'PingFangSC-Regular', fontSize: 12, padding: '9px 0px', color: '#0070cc', cursor: 'pointer' }}>
          <Balloon trigger={triggerInfo(val, record)} align="t" closable={false}>
            {`${val}（${record.Count}）`}
          </Balloon>
        </div>
      )
    },
    {
      key: 'Enable',
      title: intl('widget.msc_lossless_status_time_func'),
      dataIndex: 'Enable',
      width: 130,
      cell: (val, index, record) => (
        <div style={{ fontFamily: 'PingFangSC-Regular', fontSize: 12, color: '#000' }}>
          <Status value={val} intl={intl} />
        </div>)
    },
  ];
  const search = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.service.app_name'),
          value: 'AppName',
          width: '170px',
        },
      ],
      defaultValue: 'AppName',
      placeholder: intl('widget.msc_lossless_search_content'),
      style: {
        width: 80,
      }
    },
    isCanRefresh: true,
    isCanMultipleSearch: true,
    tableUniqueKey: true,
  };
  const fetchData = async (params) => {
    const res = await services.FetchLosslessRuleList({
      params: {
        pageNumber: 1,
        pageSize: 10,
        ...params,
        RegionId,
        IsLossless: true,
      }
    });
    const TotalCount = get(res, 'TotalSize', 0);
    const Data = get(res, 'Results', []);
    if (head(Data) && isEmpty(data)) setRowData(head(Data));
    else setRowData(Data[recordIndex] || {});
    setData({ Data, TotalCount });
    return {
      Data,
      TotalCount,
    };
  };
  const updateStatus = (time) => setRefreshIndex(time);
  const triggerIcon = <Icon type="help" className="lossless-app-list-icon" />;
  return (
    <div style={{ display: 'flex', overflow: 'hidden' }} className="lossless-border">
      <div style={{ borderRight: '1px solid #D1D5D9', paddingRight: '16px', minWidth: 367, overflow: 'hidden' }}>
        <div className="Lossless-app-list">
          {intl('widget.msc_lossless_app_list')}
          <Balloon trigger={triggerIcon} align="b" closable={false}>
            {intl('widget.msc_lossless_app_list_mse_tips')}
          </Balloon>
        </div>
        <TableContainer
          width={350}
          fetchData={fetchData}
          refreshIndex={refreshIndex}
          columns={columns}
          search={search}
          rowProps={(record) => ({
            className: `${
              `${record.AppName}:${record.Count}:${record.AppId}` ===
              `${rowData.AppName}:${rowData.Count}:${rowData.AppId}`
                ? 'table-active'
                : ''
            } ${record.Uid}`,
            style: {
              position: 'relative',
              cursor: 'pointer',
            },
          })}
          onRowClick={(record, i) => { setRowData(record); setRecordIndex(i); }}
          pagination={{
            shape: 'no-border',
            type: 'simple',
            pageSize: '10',
            recordCurrent: true,
            pageSizeSelector: false,
            // hideOnlyOnePage: true,
          }}
        />
      </div>
      <div style={{ flex: 1 }}>
        <Graphical rowData={rowData} updateStatus={updateStatus} />
      </div>
    </div>
  );
};
export default LosslessLineList;
