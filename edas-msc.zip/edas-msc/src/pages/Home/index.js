import React, { useEffect, useState } from 'react';
import services from 'services';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { jsonParse } from 'utils/transfer-data';
import { Interval, Pie, PieChart, CircleChart } from 'components/Charts';
import CommonCard from 'components/CommonCard';
import { WIDGET_ID } from 'constants';
import { Loading } from '@alicloud/console-components';
import Hot from 'containers/Hot';
import _ from 'lodash';
import { aliyunSite } from 'utils';
import { relative } from 'path';

const Home = () => {
  const [searchValues] = useGlobalState('searchValues');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const [data, setDaata] = useState({});
  const [chartData, setChartData] = useState([]);
  const [intervalData, setIntervalData] = useState([]);
  const [ruleData, setRuleData] = useState({});
  const [switchData, setSwitchData] = useState({});
  const [loading, setLoading] = useState(false);
  const intl = useIntl();
  const endTime = new Date().getTime();
  const startTime = endTime - 30 * 60 * 1000;

  useEffect(() => {
    fetchStatistics();
  }, []);

  const fetchStatistics = async () => {
    setLoading(true);
    const res = await services.GetOverview({
      params: { regionId: searchValues.regionId, period: 30 },
      data: { regionId: searchValues.regionId, period: 30 },
    });
    const SentinelRuleInfo = await services.QuerySentinelRuleInfo({
      params: { namespace: 'default', SourceType: 'MSE' },
      ignoreError: true,
    });
    const SwitchOverviewData = await services.getSwitchOverview({
      params: { namespace: 'default', SourceType: 'MSE', NameSpace: 'default' },
      ignoreError: true,
    });
    const AppProtectionEvent = await services.QueryAppProtectionInfo({
      params: { namespace: 'default', SourceType: 'MSE', NameSpace: 'default', StartTime: startTime, EndTime: endTime, Simple: true },
      ignoreError: true,
    });
    setLoading(false);
    const Res = jsonParse(res);
    const newChartData = [
      { name: intl('widget.app.authentication'), value: Res.AuthRulesSize || 0, },
      { name: intl('widget.app.tag_route'), value: Res.TagRoutePolicySize || 0, },
      { name: intl('widget.home.outlier_ejection'), value: Res.OutlierEjectionConfigSize || 0, },
    ];
    const newIntervalData = [
      { name: intl('widget.home.lossless'), value: Res.GracefulShutdownTimes || 0, },
      { name: intl('widget.home.outlier_ejection'), value: Res.OutlierEjectionTimes || 0, },
    ];
    if (aliyunSite !== 'INTL') {
      newIntervalData.push({ name: '流量防护', value: AppProtectionEvent?.Total || 0, });
    }
    const ruleList = _.map(SentinelRuleInfo.AllRules, (i, itm) => {
      const effeftCount = _.filter(SentinelRuleInfo.EffectRules, (j, item) => itm === item)[0];
      const RuleName = {
        FLOW: '流控规则',
        ISOLATE: '隔离规则',
        DEGRADE: '降级规则',
        CIRCUIT: '熔断规则',
        PARAM: '热点规则',
        RETRY: '重试规则',
        SYSTEM: '系统规则',
      };
      return ({
        item: '' + RuleName[itm],
        count: i,
        effeftCount: effeftCount,
        percent: effeftCount,
      });
    });
    const newRuleData = {
      AllRulesCount: SentinelRuleInfo.AllRulesCount,
      EffectRulesCount: SentinelRuleInfo.EffectRulesCount,
      ruleList: ruleList,
    };
    setIntervalData(newIntervalData);
    setChartData(newChartData);
    setDaata(Res);
    setRuleData(newRuleData);
    setSwitchData(SwitchOverviewData);
  };

  const handleChangePage = (val) => {
    eventEmitter.emit(`${WIDGET_ID}:${val}`, {});
  };

  return (
    <div style={{ display: 'flex' }}>
      <Loading visible={loading} style={{ width: 'calc(100% - 336px)' }}>
        <div style={{ display: 'flex', marginBottom: 16 }}>
          <CommonCard
            title={intl('widget.home.app')}
            value={<span className="link-primary" onClick={() => handleChangePage('go-to-AppList')}>{data.ApplicationSize || 0}</span>}
          />
          <CommonCard
            title={intl('widget.home.instance')}
            value={<span className="link-primary" onClick={() => handleChangePage('go-to-AppList')}>{data.InstancesSize || 0}</span>}
          />
          <CommonCard
            title={intl('widget.home.service')}
            value={<span className="link-primary" onClick={() => handleChangePage('go-to-ServiceList')}>{(data.SpringCloudServiceSize || 0) + (data.DubboServiceSize || 0)}</span>}
          />
          <CommonCard
            title={intl('widget.app.tag')}
            value={<span className="link-primary" onClick={() => handleChangePage('go-to-RouteTagList')}>{data.TagSize || 0}</span>}
            unit={intl('widget.home.item')}
          />
        </div>
        <div style={{ display: 'flex', marginBottom: 16 }}>
          <div style={{ width: 'calc(50% - 8px)', borderRadius: '1px solid #eee', boxShadow: '0 0 10px #eee', padding: 16, marginRight: 16 }}>
            <span className="common-title" style={{ color: '#777', fontSize: 14 }}>{intl('widget.home.authentication')}</span>
            <div style={{ padding: 16 }}>
              <Pie data={chartData} axis="name" yxis="value" />
            </div>
          </div>
          <div style={{ width: 'calc(50% - 8px)', borderRadius: '1px solid #eee', boxShadow: '0 0 10px #eee', padding: 16, }}>
            <span className="common-title" style={{ color: '#777', fontSize: 14 }}>{intl('widget.home.statistics')}</span>
            <div style={{ padding: 16 }}>
              <Interval data={intervalData} axis="name" yxis="value" />
            </div>
          </div>
        </div>
        <If condition={aliyunSite !== 'INTL'}>
          <div style={{ display: 'flex', marginBottom: 16 }}>
            <div style={{ width: 'calc(50% - 8px)', borderRadius: '1px solid #eee', boxShadow: '0 0 10px #eee', padding: 16, marginRight: 16 }}>
              <span className="common-title" style={{ color: '#777', fontSize: 14 }}>流量防护</span>
              <div style={{ padding: 16 }}>
                <PieChart ruleData={ruleData} axis="name" yxis="value" />
              </div>
            </div>
            <div style={{ width: 'calc(50% - 8px)', borderRadius: '1px solid #eee', boxShadow: '0 0 10px #eee', padding: 16, }}>
              <span className="common-title" style={{ color: '#777', fontSize: 14 }}>应用配置</span>
              <div style={{ display: 'flex', padding: 16, justifyContent: 'space-around', position: 'relative', top: 'calc(50% - 70px)' }}>
                <CircleChart data={switchData.SwitchCount} size={120} title='接入开关数' key='event1'/>
                <CircleChart data={switchData.NameSpaceCount} size={120} title='Switch命名空间数' key='event2'/>
                <CircleChart data={switchData.MachineCount} size={120} title='接入机器数' key='event3'/>
              </div>
            </div>
          </div>
        </If>
      </Loading>
      <div style={{ width: 320, minWidth: 320, marginLeft: 16, color: '#555' }}>
        <Hot />
      </div>
    </div>
  );
};

export default Home;
