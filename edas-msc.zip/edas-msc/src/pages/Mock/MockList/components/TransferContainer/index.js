import React, { useState, useEffect } from 'react';
import { map, filter, includes, differenceBy, head, isEmpty, assign } from 'lodash';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import { Transfer, Loading } from '@ali/cn-design';
import services from 'services';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const TransferContainer = (props) => {
  const intl = useIntl();
  const {
    onChange,
    value = [],
    consumerList = [],
    Region,
    Namespace,
  } = props;
  const [loading, setLoading] = useState(false);
  // const [appList] = useGlobalState('appList');
  const [appList, setAppList] = useState([]);
  const currentAppList = [];

  useEffect(() => {
    if (!Region) return;
    fetchAppList({ pageNumber: 1, pageSize: 50 });
  }, [Region, Namespace]);

  // 这个是分页接口，但是需要拿到全部数据
  const fetchAppList = async ({ pageNumber, pageSize }) => {
    setLoading(true);
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      let { data = [] } = await services.GetAppList({ params: { regionId: Region, namespaceId: Namespace } });
      data = filter(data, item => (item.regionId === Namespace || item.appId === '*'));
      const newData = map(data, item => ({
        ...item,
        key: item.appId,
        value: item.appId,
        label: item.appName,
      }));
      onChange && onChange([]);
      setAppList(newData);
      setLoading(false);
      return;
    }
    const { Result = [] } = await services.GetAppList({ params: { regionId: Region, namespaceId: Namespace, pageNumber, pageSize } });
    const newData = map(Result, item => ({
      ...item,
      appId: item.AppId,
      key: item.AppId,
      value: item.AppId,
      label: item.AppName,
    }));
    currentAppList.push(...newData);
    if (Result.length && Result.length === pageSize) {
      fetchAppList({ pageNumber: pageNumber + 1, pageSize });
    } else {
      onChange && onChange([]);
      setLoading(false);
      setAppList(currentAppList);
    }
  };

  const handleChange = (list) => {
    const selectedAppList = filter(appList, n => includes(list, n.value));
    onChange && onChange(selectedAppList);
  };

  return (
    <Loading visible={loading}>
      <Transfer
        listStyle={{ width: 295, height: 250 }}
        notFoundContent={intl('widget.outlier_ejection.not_fount_content')}
        showSearch
        value={map(value, n => n.value)}
        dataSource={differenceBy(appList, consumerList, 'appId')}
        onChange={handleChange}
        titles={[intl('widget.degradation.no_degradation_app'), intl('widget.degradation.begin_degradation_app')]}
      />
    </Loading>
  );
};

TransferContainer.propTypes = {
  onChange: PropTypes.func,
  consumerList: PropTypes.arrayOf(PropTypes.any),
  value: PropTypes.arrayOf(PropTypes.any),
  Namespace: PropTypes.string,
  Region: PropTypes.string,
};

export default TransferContainer;
