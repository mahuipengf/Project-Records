import React, { useState, useEffect, useImperativeHandle, useRef, forwardRef } from 'react';
import { uniqueId, map, filter, get } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import { Icon } from '@ali/cn-design';
import CommonEvent from 'components/CommonEvent';
import RouteForm from './Item';

const RulesRef = (props, ref) => {
  const { value = [], onChange, PolicyId, serviceLoading } = props;
  const intl = useIntl();
  const [list, setList] = useState([]);
  const rulesRef = useRef();
  const formRef = useRef();
  const [appServiceData] = useGlobalState('appServiceData');
  const springCloudData = get(appServiceData, 'springCloud', []);
  const dubboData = get(appServiceData, 'dubbo', []);

  const protocol = () => {
    if ((springCloudData.length && dubboData.length) || (!springCloudData.length && !dubboData.length)) {
      return 'springCloud'; // 两者都有，或者不存在节点
    } else if (springCloudData.length > 0 && !dubboData.length) {
      return 'springCloud';
    } else if (dubboData.length > 0 && !springCloudData.length) {
      return 'dubbo';
    } else {
      return 'springCloud';
    }
  };

  useEffect(() => {
    setList(value);
    onChange(value);
  }, [value]);

  useEffect(() => {
    const newList = map(list, item => item.Uid > 0 ? item : ({ ...item, Protocol: protocol() }));
    onChange(newList);
  }, [protocol()]);

  useImperativeHandle(ref, () => ({
    validator
  }));

  const handleAdd = () => {
    const newList = [...list, {
      Uid: -uniqueId(),
      ExecuteCondition: 'force',
      DubboMethod: undefined,
      ScMethod: undefined,
      Oper: 'return+null',
      Protocol: protocol(),
      Value: undefined,
      Method: undefined,
    }];
    onChange(newList);
  };

  const handleDelete = (Uid) => {
    const newList = filter(list, item => item.Uid !== Uid);
    onChange(newList);
  };

  const validator = async () => {
    const res = formRef.current && await formRef.current.handleSubmit();
    return res;
  };

  const handleChange = (val) => {
    const newList = map(list, item => item.Uid === val.Uid ? val : item);
    onChange(newList);
  };

  return (
    <div ref={rulesRef}>
      <For each="item" index="index" of={list}>
        <div className="common-box" key={index} style={{ paddingBottom: 0 }}>
          <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between' }}>
            <span>{intl('widget.mock.service_rule_n', { n: index + 1 })}</span>
            <Icon type="close" size="xs" className="common-icon" onClick={() => handleDelete(item.Uid)} />
          </div>
          <RouteForm value={item} key={item.Uid} ref={formRef} onChange={handleChange} PolicyId={PolicyId} serviceLoading={serviceLoading} />
        </div>
      </For>
      <div className="common-box" style={{ padding: 16 }}>
        <CommonEvent onClick={handleAdd} text={intl('widget.degradation.add_new_service')} />
      </div>
    </div>
  );
};

const RefRules = forwardRef(RulesRef);

RulesRef.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  onChange: PropTypes.func,
  PolicyId: PropTypes.number,
  serviceLoading: PropTypes.bool,
};

export default RefRules;
