/**
 * sc 方法选择
 */
import React, { useEffect, useState } from 'react';
import { isEmpty, split, find, head, get, filter, includes, map, union, forEach } from 'lodash';
import { Select } from '@ali/cn-design';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';

const ScPathSelector = ({ onChange, value, fetchData, dataSource: scData = [], hasDefault = true }) => {
  const intl = useIntl();
  const [dataSource, setDataSource] = useState([]);
  useEffect(() => {
    if (!fetchData) return;
    fetchData();
  }, []);

  useEffect(() => {
    if (!hasDefault) return;
    const newData = map(scData, item => {
      const methods = get(item, 'methods', []);
      const paths = map(methods, method => method.paths || []);
      const newPaths = union(...paths);
      const pathMethods = {};
      forEach(newPaths, path => {
        pathMethods[path] = getMethodList(path, methods);
      });
      return {
        value: item.serviceName,
        label: item.serviceName,
        serviceName: item.serviceName,
        methods,
        paths: newPaths,
        pathMethods
      };
    });
    setDataSource(newData);
  }, [scData]);

  useEffect(() => {
    if (!value && !isEmpty(dataSource)) {
      const first = head(dataSource);
      if (!isEmpty(first)) {
        const serviceName = get(first, 'serviceName', '');
        const path = get(first, 'paths[0]', '');
        const pathMethods = get(first, 'pathMethods', {});
        onChange(`${serviceName}:${path}`, pathMethods[path]);
      }
    }
    if (value && !isEmpty(dataSource)) {
      handleChange(value);
    }
  }, [dataSource]);

  const handleChange = (val) => {
    const [serviceName = '', path = ''] = split(val, ':');
    const ServiceNameItem = find(dataSource, { serviceName });
    const pathMethods = get(ServiceNameItem, 'pathMethods', {});
    onChange(val, pathMethods[path]);
  };

  const handleChangeServiceName = (val) => {
    const ServiceNameItem = find(dataSource, { serviceName: val });
    const path = get(ServiceNameItem, 'paths[0]', []);
    const pathMethods = get(ServiceNameItem, 'pathMethods', {});
    onChange(`${val}:${path}`, pathMethods[path]);
  };

  const getMethodList = (path, serviceMethod) => {
    const pathMethods = filter(serviceMethod, item => includes(item.paths, path));
    const requestMethods = map(pathMethods, item => item.requestMethods || []);
    const newRequestMethods = union(...requestMethods);
    return newRequestMethods;
  };

  const [serviceName = '', path = ''] = split(value, ':');

  return (
    <React.Fragment>
      <Select
        showSearch
        style={{ width: 'calc(50% - 4px)', marginRight: 8 }}
        onChange={(val) => handleChangeServiceName(val)}
        dataSource={dataSource}
        value={serviceName}
        followTrigger
        placeholder={intl('widget.authentication.service_placeholder')}

      />
      <Select
        showSearch
        style={{ width: 'calc(50% - 4px)' }}
        onChange={(val) => handleChange(`${serviceName}:${val}`)}
        dataSource={find(dataSource, { value: serviceName })?.paths}
        value={path}
        placeholder={intl('widget.degradation.path_placeholder')}
        followTrigger
      />
    </React.Fragment>
  );
};

ScPathSelector.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.arrayOf(PropTypes.object),
  fetchData: PropTypes.func,
  dataSource: PropTypes.arrayOf(PropTypes.object),
  hasDefault: PropTypes.bool
};

export default ScPathSelector;
