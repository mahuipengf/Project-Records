import React, { useImperativeHandle, forwardRef, useEffect, useState } from 'react';
import { Radio, Form, Loading, Select, Input, Balloon, Icon } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { head, get } from 'lodash';
import PropTypes from 'prop-types';
import DubboMethod from 'containers/DubboMethod';
import ScPathSelector from './ScPathSelector';
import MonacoEditor from 'components/MonacoEditor';
import { validateContent } from 'utils';

const FormItem = Form.Item;

const RouteForm = (props, ref) => {
  const field = Field.useField();
  const intl = useIntl();
  const { init, validate, getValues, getValue, setValue } = field;
  const { value = {}, onChange, PolicyId, serviceLoading = false } = props;
  const [appServiceData] = useGlobalState('appServiceData');
  const springCloudData = get(appServiceData, 'springCloud', []);
  const dubboData = get(appServiceData, 'dubbo', []);
  const [methodList, setMethodList] = useState([]);

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  const handleChange = () => {
    onChange({ ...value, ...getValues() });
  };

  const handleSubmit = () => {
    return new Promise((resolve) => {
      validate((errors, values) => {
        resolve({ errors, values });
      });
    });
  };

  const protocol = () => {
    if ((springCloudData.length && dubboData.length) || (!springCloudData.length && !dubboData.length)) {
      return [{ value: 'springCloud', label: 'Spring Cloud' }, { value: 'dubbo', label: 'Dubbo' }]; // 两者都有，或者不存在节点
    } else if (springCloudData.length > 0 && !dubboData.length) {
      if (!PolicyId) {
        getValue('Protocol') !== 'springCloud' && setValue('Protocol', 'springCloud');
      }
      return [{ value: 'springCloud', label: 'Spring Cloud' }];
    } else if (dubboData.length > 0 && !springCloudData.length) {
      if (!PolicyId) {
        getValue('Protocol') !== 'dubbo' && setValue('Protocol', 'dubbo');
      }
      return [{ value: 'dubbo', label: 'Dubbo' }];
    } else {
      return [{ value: 'springCloud', label: 'Spring Cloud' }, { value: 'dubbo', label: 'Dubbo' }];
    }
  };

  const handleMonacoChange = (rule, val, callback) => {
    if (val) {
      const isValidate = validateContent.validate({
        content: val,
        type: 'json',
      });
      if (isValidate) {
        callback();
      } else {
        callback(intl('widget.service.service_test_error'));
      }
      return;
    }
    callback();
  };

  return (
    <Form field={field} labelAlign="left" style={{ paddingTop: 16 }}>
      <FormItem label={intl('widget.route.frame_type')} required>
        <Loading visible={serviceLoading}>
          <Radio.Group
            {...init('Protocol', {
              initValue: value.Protocol || (head(protocol()) && head(protocol()).value),
              rules: [
                {
                  required: true,
                  message: intl('widget.route.frame_type_errorr'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            dataSource={protocol()}
            disabled={!!PolicyId && value.Uid > 0}
          />
        </Loading>
      </FormItem>
      <If condition={getValue('Protocol') === 'dubbo'}>
        <FormItem label={intl('widget.app.service_method')} required={getValue('Protocol') === 'dubbo'}>
          <DubboMethod
            {...init('DubboMethod', {
              initValue: value.DubboMethod,
              rules: [
                {
                  required: getValue('Protocol') === 'dubbo',
                  message: intl('widget.route.service_method_error'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            dataSource={dubboData}
          />
        </FormItem>
      </If>
      <If condition={getValue('Protocol') === 'springCloud'}>
        <FormItem label={intl('widget.degradation.degradation_service_path')} required={getValue('Protocol') === 'springCloud'}>
          <ScPathSelector
            {...init('ScMethod', {
              initValue: value.ScMethod,
              rules: [
                {
                  required: getValue('Protocol') === 'springCloud',
                  message: intl('widget.degradation.please_select_degradation_service_path'),
                },
              ],
              props: {
                onChange: (val, methods) => {
                  setMethodList(methods);
                  const first = head(methods);
                  setValue('Method', first);
                  handleChange(val);
                },
                // getMemthod: (methods) => {
                //   setMethodList(methods);
                // }
              }
            })}
            dataSource={springCloudData}
          />
        </FormItem>
        <FormItem label={intl('widget.service.httpMethods')} required={getValue('Protocol') === 'springCloud'}>
          <Select
            {...init('Method', {
              initValue: value.Method,
              rules: [
                {
                  required: getValue('Protocol') === 'springCloud',
                  message: intl('widget.mock.please_select_method'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            followTrigger
            style={{ width: '100%' }}
            dataSource={methodList}
          />
        </FormItem>
      </If>
      <FormItem label={intl('widget.ddegradation.executeCondition')} required>
        <Radio.Group
          {...init('ExecuteCondition', {
            initValue: value.ExecuteCondition,
            rules: [
              {
                required: true,
                message: intl('widget.ddegradation.please_select_executeCondition'),
              },
            ],
            props: {
              onChange: handleChange
            }
          })}
          dataSource={[
            { value: 'force', label: intl('widget.ddegradation.executeCondition_all') },
            { value: 'exception', label: intl('widget.ddegradation.executeCondition_warning') },
          ]}
        />
      </FormItem>
      <FormItem
        label={intl('widget.ddegradation.ddegradation_policy')}
        required
      >
        <Select
          {...init('Oper', {
            initValue: value.Oper || 'return+null',
            props: {
              onChange: handleChange
            }
          })}
          style={{ width: '100%', marginBottom: 8 }}
          dataSource={[
            { value: 'return+null', label: intl('widget.mock.return_null') },
            { value: 'throw', label: intl('widget.mock.return_excention_error') },
            { value: 'return+json', label: intl('widget.mock.return_customize_json') },
            { value: 'return+callback', label: intl('widget.mock.return_customize_callback') },
          ]}
          followTrigger

        />
      </FormItem>
      <If condition={getValue('Oper') === 'return+json'}>
        <FormItem
          label={intl('widget.mock.json_data')}
          required={getValue('Oper') === 'return+json'}
        >
          <MonacoEditor
            {...init('Value', {
              initValue: value.Value,
              rules: [
                {
                  required: true,
                  message: intl('widget.mock.content_cannot_be_empty'),
                },
                // {
                //   validator: handleMonacoChange
                // }
              ],
              props: {
                onChange: handleChange
              }
            })}
            isEnableMaximize={false}
            width="100%"
            height={200}
            // language="json"
            minimap={false}
          />
        </FormItem>
      </If>
      <If condition={getValue('Oper') === 'throw'}>
        <FormItem
          label={intl('widget.mock.force_name')}
        >
          <Input
            {...init('ExceptionClassName', {
              initValue: value.ExceptionClassName,
              props: {
                onChange: handleChange
              }
            })}
            placeholder={intl('widget.mock.please_input_force_name')}
            maxLength={64}
            minLength={1}
            showLimitHint
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem
          label={intl('widget.mock.force_message')}
        >
          <Input
            {...init('ExceptionMessage', {
              initValue: value.ExceptionMessage,
              props: {
                onChange: handleChange
              }
            })}
            placeholder={intl('widget.mock.please_input_force_message')}
            maxLength={64}
            minLength={1}
            showLimitHint
            style={{ width: '100%' }}
          />
        </FormItem>
      </If>
      <If condition={getValue('Oper') === 'return+callback'}>
        <FormItem
          required
          label={
            <React.Fragment>
              <span style={{ marginRight: 8 }}>{intl('widget.mse.class_name')}</span>
              <Balloon align="t" trigger={<Icon type="help" />} closable={false}>
                {intl('widget.mse.class_name_help')}
              </Balloon>
            </React.Fragment>
          }
        >
          <Input
            {...init('ClazzName', {
              initValue: value.ClazzName,
              props: {
                onChange: handleChange
              }
            })}
            placeholder={intl('widget.mse.please_enter_class_name')}
            maxLength={128}
            minLength={1}
            showLimitHint
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem
          label={intl('widget.mse.callback_method')}
          required
        >
          <Input
            {...init('DegradeServiceName', {
              initValue: value.DegradeServiceName,
              props: {
                onChange: handleChange
              }
            })}
            placeholder={intl(getValue('Protocol') === 'springCloud' ? 'widget.mse.please_enter_callback_method_sc' : 'widget.mse.please_enter_callback_method_dubbo')}
            maxLength={128}
            minLength={1}
            showLimitHint
            style={{ width: '100%' }}
          />
        </FormItem>
      </If>
    </Form >
  );
};

const RefRouteForm = forwardRef(RouteForm);

RouteForm.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
  Uid: PropTypes.number,
  serviceLoading: PropTypes.bool,
  Id: PropTypes.string,
};

export default RefRouteForm;

