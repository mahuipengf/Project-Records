import React, { useImperativeHandle, forwardRef, useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Message, Switch, Select, Loading } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { find, forEach, filter, map, split, get, uniqueId } from 'lodash';
import { NNAME_PATTERN, MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';
import AppSelector from 'containers/AppSelector';
import { Namespace } from '@ali/mamba-namespace';
import TransferContainer from '../TransferContainer';
import Rules from '../RuleItems';

const FormItem = Form.Item;

const AddForm = (props, ref) => {
  const field = Field.useField();
  const { value = {}, setRefreshIndex } = props;
  const intl = useIntl();
  const { init, validate, getValue, setValues } = field;
  const [appServiceData, setAppServiceData] = useGlobalState('appServiceData');
  const rulesRef = useRef();
  const [serviceLoading, setServiceLoading] = useState(false);
  const [consumerList, setConsumerList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (value.Id) {
      fetchData();
    } else {
      setValues({
        Namespaces: { regionId: value.Region, namespaceId: value.Namespace },
        Region: value.Region,
        Namespace: value.Namespace
      });
    }
  }, [value]);

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  const fetchData = async () => {
    const params = {
      Region: value.Region,
      Namespace: value.Namespace,
      Id: value.Id,
    };
    setIsLoading(true);
    const Data = await services.GetMockRuleById({
      params,
      customErrorHandle: (err, response, callback) => {
        setIsLoading(false);
        callback();
      }
    }) || {};
    setIsLoading(false);
    const ScRules = get(Data, 'ScMockItems', []);
    const ScMockItems = map(ScRules, item => {
      const ScMethod = `${item.ServiceName || ''}:${item.Path || ''}`;
      return { ...item, Uid: uniqueId(), ScMethod, Protocol: 'springCloud' };
    });
    const DubboArgRules = get(Data, 'DubboMockItems', []);
    const DubboMockItems = map(DubboArgRules, item => {
      const { ServiceName = '', Version = '', Group = '', MethodName = '', ParamTypes = [] } = item;
      return {
        ...item,
        DubboMethod: `${ServiceName}:${Version}:${Group}:${MethodName}:${ParamTypes}`,
        Uid: uniqueId(),
        Protocol: 'dubbo'
      };
    });
    const Description = get(Data, 'ExtraJson.description');
    const newValues = {
      ...Data,
      Region: value.Region,
      Namespace: value.Namespace,
      Namespaces: { regionId: value.Region, namespaceId: value.Namespace },
      Description,
      Rules: [...ScMockItems, ...DubboMockItems]
    };
    setValues(newValues);
  };

  useEffect(() => {
    if (getValue('ProviderAppId')) {
      if (!getValue('Region')) return;
      setServiceLoading(true);
      Promise.all([fetchDubboServiceList(getValue('ProviderAppId')), SpringCloudfetchServiceList(getValue('ProviderAppId')), GetMockRuleByProviderAppId(getValue('ProviderAppId'))]).then((res) => {
        setAppServiceData({
          dubbo: res[0] || [],
          springCloud: res[1] || [],
        });
        setServiceLoading(false);
      });
    }
  }, [getValue('ProviderAppId')]);

  const fetchDubboServiceList = async (AppId) => {
    let params = {
      Region: getValue('Region'),
      ServiceType: 'dubbo',
      AppId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: getValue('Region'),
        namespace: getValue('Namespace'),
        serviceType: 'dubbo',
        searchType: 'app',
        searchValue: AppId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    const newData = map(data || [], item => {
      const newMethods = map(item.methods, child => {
        return ({
          ...child,
          key: `${child.name}:${child.parameterTypes}`,
          value: `${child.name}:${child.parameterTypes}`,
          label: `${child.name}(${child.parameterTypes || []})`,
        });
      });
      return ({
        ...item,
        methods: newMethods,
        value: `${item.serviceName}:${item.version}:${item.group}`,
        key: `${item.serviceName}:${item.version}:${item.group}`,
        label: `${item.serviceName}:${item.version}:${item.group}`,
      });
    });
    return newData;
  };

  const SpringCloudfetchServiceList = async (AppId) => {
    let params = {
      Region: getValue('Region'),
      ServiceType: 'springCloud',
      AppId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: getValue('Region'),
        namespace: getValue('Namespace'),
        serviceType: 'springCloud',
        searchType: 'app',
        searchValue: AppId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    return data;
  };

  // 应用相关的所有规则，然后每个规则里都有可以拿到 consumerAppId
  const GetMockRuleByProviderAppId = async (appId) => {
    const params = {
      Region: getValue('Region'),
      Namespace: getValue('Namespace'),
      ProviderAppId: appId,
    };
    const res = await services.GetMockRuleByProviderAppId({ params });
    const data = lowerFirstData(res) || [];
    const newData = map(data, item => ({ ...item, appId: item.consumerAppId }));
    setConsumerList(newData);
    return newData;
  };

  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        console.log(values)
        if (errors) return reject(errors);
        console.log('handleSubmit', values);
        const params = {
          Id: value.Id,
          Region: values.Region,
          Namespace: values.Namespace,
          Name: values.Name,
          ProviderAppId: values.ProviderAppId,
          ProviderAppName: values.ProviderAppName,
          ExtraJson: { description: values.Description },
          Enable: values.Enable,
        };
        const ConsumerAppsJson = map(values.ConsumerAppsJson, item => ({
          appId: item.value,
          appName: item.label,
        }));
        const ScRulesJson = filter(values.Rules, item => item.Protocol === 'springCloud');
        const DubboArgRulesJson = filter(values.Rules, item => item.Protocol === 'dubbo');
        const ScMockItemJson = map(ScRulesJson, item => {
          const [ServiceName = '', Path = ''] = split(item.ScMethod, ':');
          return {
            executeCondition: item.ExecuteCondition,
            oper: item.Oper,
            serviceName: ServiceName,
            path: Path,
            value: item.Value,
            method: item.Method,
            exceptionClassName: item.ExceptionClassName || 'java.lang.RuntimeException',
            exceptionMessage: item.ExceptionMessage,
            degradeServiceName: item.DegradeServiceName,
            clazzName: item.ClazzName,
          };
        });
        const DubboMockItemJson = map(DubboArgRulesJson, item => {
          const [ServiceName, Version, Group, MethodName, ParamTypes = ''] = split(item.DubboMethod, ':');
          return {
            executeCondition: item.ExecuteCondition,
            oper: item.Oper,
            value: item.Value,
            serviceName: ServiceName,
            version: Version,
            group: Group,
            methodName: MethodName,
            paramTypes: split(ParamTypes, ','),
            exceptionClassName: item.ExceptionClassName || 'java.lang.RuntimeException',
            exceptionMessage: item.ExceptionMessage,
            degradeServiceName: item.DegradeServiceName,
            clazzName: item.ClazzName,
          };
        });
        if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
          params.ScMockItemJson = ScMockItemJson;
          params.DubboMockItemJson = DubboMockItemJson;
          params.ConsumerAppsJson = ConsumerAppsJson;
        } else {
          params.ScMockItems = ScMockItemJson;
          params.DubboMockItems = DubboMockItemJson;
          params.ConsumerAppIds = ConsumerAppsJson;
        }
        value.Id
          ? await services.UpdateMockRule({
            params,
            customErrorHandle: (err, response, callback) => {
              reject();
              callback();
            }
          })
          : await services.AddMockRule({
            params,
            customErrorHandle: (err, response, callback) => {
              reject();
              callback();
            }
          });
        value.Id ? Message.success(intl('widget.common.update_successful')) : Message.success(intl('widget.common.add_successful'));
        resolve();
        setRefreshIndex(Date.now());
      });
    });
  };

  // 针对springCloud，dubbo需要区分判断数据
  const handleValidatorRules = (rule, val, callback) => {
    const dubboEmpty = find(val, { DubboMethod: undefined, Protocol: 'dubbo' });
    const scEmpty = find(val, { ScMethod: undefined, Protocol: 'springCloud' });
    if (dubboEmpty || scEmpty) {
      callback(intl('widget.degradation.degradation_service_can_not_empty'));
    }

    forEach(val, item => {
      if (item.Oper === 'return+json' && !item.Value) {
        callback(intl('widget.degradation.degradation_policy_can_not_empty'));
      }
      if (item.Oper === 'return+callback') {
        if (!item.ClazzName) {
          callback(intl('widget.mse.please_enter_class_name'));
        }
        if (!item.DegradeServiceName) {
          callback(intl('widget.mse.callback_method_sc_error'));
        }
      }
    });
    callback();
  };

  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  const fetchNamespaces = async (region) => {
    const { data = [] } = await services.fetchNamespaces({ params: { regionId: region } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  return (
    <Loading visible={isLoading} style={{ width: '100%' }}>
      <Form field={field} labelAlign="left">
        <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
          <FormItem label={intl('widget.common.microservice_space')} required>
            <If condition={!value.Id}>
              <Namespace
                {...init('Namespaces', {
                  initValue: { regionId: value.Region, namespaceId: value.Namespace },
                  rules: [
                    {
                      required: true,
                      message: intl('widget.common.please_select_microservice_space'),
                    },
                  ],
                  props: {
                    onChange: (v) => {
                      setValues({
                        Region: v.regionId,
                        Namespace: v.namespaceId,
                        ConsumerAppsJson: [],
                        ProviderAppId: undefined,
                        ProviderAppName: undefined,
                      });
                    },
                  }
                })}
                style={{ width: '47%' }}
                fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
                fetchNamespaces={fetchNamespaces}
              />
            </If>
            <If condition={value.Id}>
              {getValue('Namespace')}
            </If>
          </FormItem>
        </If>
        <FormItem label={intl('widget.authentication.rule_name')} required>
          <Input
            {...init('Name', {
              initValue: value.Name,
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.rule_name_placeholder'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.common.name_pattern'),
                },
              ],
            })}
            placeholder={intl('widget.authentication.rule_name_placeholder')}
            maxLength={64}
            minLength={1}
            showLimitHint
            disabled={value.Id}
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem label={intl('widget.route.description')}>
          <Input
            {...init('Description', {
              initValue: value.ExtraJson && value.ExtraJson.description,
            })}
            placeholder={intl('widget.route.description_placecholder')}
            maxLength={64}
            showLimitHint
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem
          label={intl('widget.mock.service_provider_application')}
          required
        >
          <AppSelector
            {...init('ProviderAppId', {
              rules: [
                {
                  required: true,
                  message: intl('widget.mock.intro_provider_placeholder'),
                },
              ],
              props: {
                onChange: (id, name) => {
                  setValues({
                    ProviderAppName: name,
                    Rules: []
                  });
                }
              }
            })}
            followTrigger
            namespaces={getValue('Namespaces')}
            disabled={value.Id}
          />
        </FormItem>
        <If condition={!value.Id}>
          <FormItem
            label={intl('widget.degradation.degradation_app')}
            required
          >
            <TransferContainer
              {...init('ConsumerAppsJson', {
                initValue: [],
                rules: [
                  {
                    required: true,
                    message: intl('widget.degradation.please_select_degradation_app'),
                  },
                ],
                props: {
                  onChange: val => console.log(val)
                }
              })}
              consumerList={consumerList}
              Region={getValue('Region')}
              Namespace={getValue('Namespace')}
            />
          </FormItem>
        </If>
        <If condition={value.Id}>
          <FormItem
            label={intl('widget.degradation.degradation_app')}
            required
          >
            <Select
              {...init('ConsumerAppId', {
                initValue: value.ConsumerAppId,
              })}
              disabled={value.Id}
              dataSource={[
                {
                  value: value.ConsumerAppId,
                  label: value.ConsumerAppName,
                }
              ]}
              style={{
                width: '100%'
              }}
              followTrigger
            />
          </FormItem>
        </If>
        <FormItem label={intl('widget.mock.service_rule_list')} required>
          <Rules
            {...init('Rules', {
              rules: [
                {
                  required: true,
                  message: intl('widget.mock.please_add_service_rule'),
                },
                {
                  validator: handleValidatorRules
                }
              ],
            })}
            PolicyId={value.Id}
            ref={rulesRef}
            serviceLoading={serviceLoading}
          />
        </FormItem>
        <If condition={!value.Id}>
          <FormItem label={intl('widget.authentication.default_state')}>
            <Switch
              {...init('Enable', {
                initValue: !!value.Enable,
                valueName: 'checked',
              })}
            />
          </FormItem>
        </If>
      </Form >
    </Loading>
  );
};

const RefAddForm = forwardRef(AddForm);

AddForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  setRefreshIndex: PropTypes.number,
};

export default RefAddForm;
