import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { CopyContent, Loading } from '@ali/cn-design';
import DataFields from 'components/DataFields';
import { useIntl } from '@ali/widget-hooks';
import DescEdit from 'components/DescEdit';
import services from 'services';
import CommonEvent from 'components/CommonEvent';
import Status from 'components/Status/CommonStatus';
import { map, get, uniqueId, isEmpty, join } from 'lodash';
import ItemInfo from './ItemInfo';

const RouteInfoComp = (props) => {
  const { value = {}, handleEdit } = props;
  const [MockIdData, setMockIdData] = useState(value);
  const intl = useIntl();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (value.Id) {
      fetchData();
    }
  }, [value.Id]);

  const handleChangeDetail = async (params, params2) => {
    const newParams = {
      ...MockIdData,
      ExtraJson: params,
      DubboMockItemJson: MockIdData.DubboMockItems,
      ScMockItemJson: MockIdData.ScMockItems,
    };
    await services.UpdateMockRule({
      params: newParams,
      params2
    });
  };

  const fetchData = async () => {
    const params = {
      Region: value.Region,
      Namespace: value.Namespace,
      Id: value.Id,
    };
    setLoading(true);
    const Data = await services.GetMockRuleById({
      params,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      }
    }) || {};
    setLoading(false);
    const ScRules = get(Data, 'ScMockItems', []);
    const ScMockItems = map(ScRules, item => {
      const { ServiceName = '', Path = '' } = item;
      const ScMethod = `${ServiceName}:${Path}`;
      return { ...item, Uid: uniqueId(), ScMethod, Protocol: 'springCloud' };
    });
    const DubboArgRules = get(Data, 'DubboMockItems', []);
    const DubboMockItems = map(DubboArgRules, item => {
      const { ServiceName = '', Version = '', Group = '', MethodName = '', ParamTypes = [] } = item;
      return {
        ...item,
        DubboMethod: `${ServiceName}:${Version}:${Group}:${MethodName}:${ParamTypes}`,
        Uid: uniqueId(),
        Protocol: 'dubbo'
      };
    });
    const newValues = { ...Data, Rules: [...ScMockItems, ...DubboMockItems] };
    setMockIdData(newValues);
  };

  const items = [
    {
      label: intl('widget.authentication.rule_name'),
      dataIndex: 'Name',
      visible: true,
      render: val => <CopyContent text={value}>{val}</CopyContent>
    },
    {
      label: intl('widget.mock.service_provider_application'),
      dataIndex: 'ProviderAppName',
      visible: true,
      render: val => <CopyContent text={value}>{val}</CopyContent>
    },
    {
      label: intl('widget.degradation.degradation_app'),
      dataIndex: 'ConsumerAppName',
      visible: true,
      render: val => <CopyContent text={value}>{val}</CopyContent>
    },
    {
      label: intl('widget.app.framework'),
      visible: true,
      dataIndex: 'Protocol',
      render: () => {
        const arr = [];
        if (!isEmpty(MockIdData.ScMockItems)) {
          arr.push('Spring Cloud');
        }
        if (!isEmpty(MockIdData.DubboMockItems)) {
          arr.push('Dubbo');
        }
        return (
          <React.Fragment>
            <If condition={!isEmpty(arr)}>
              {join(arr, ', ')}
            </If>
            <If condition={isEmpty(arr)}>--</If>
          </React.Fragment>
        );
      }
    },
    {
      label: intl('widget.common.state'),
      dataIndex: 'Enable',
      visible: true,
      render: val => <Status value={val} intl={intl} />
    },
    {
      dataIndex: 'ExtraJson',
      label: intl('widget.route.description'),
      visible: true,
      render: (val) => (
        <DescEdit
          name="description"
          value={val && val.description}
          handleSubmit={handleChangeDetail}
          onChange={(ExtraJson) => setMockIdData({ ...MockIdData, ExtraJson })}
        />
      ),
      span: 24,
    },
  ];

  return (
    <Loading visible={loading} style={{ width: '100%' }}>
      <DataFields
        dataSource={MockIdData}
        items={items}
        title={intl('widget.common.basic_info')}
      />
      <div style={{ display: 'flex', alignItems: 'center', marginTop: 16 }}>
        <h4 className="common-title" style={{ width: 144, marginTop: 8 }}>{intl('widget.mock.service_rule_list')}</h4>
        <If condition={handleEdit}>
          <CommonEvent type="edit" text={intl('widget.common.edit')} onClick={() => handleEdit && handleEdit(value)} />
        </If>
      </div>
      <ItemInfo value={MockIdData.Rules} />
    </Loading>
  );
};

RouteInfoComp.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  handleEdit: PropTypes.func,
};

export default RouteInfoComp;
