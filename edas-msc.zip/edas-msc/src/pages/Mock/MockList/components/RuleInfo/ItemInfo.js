import React from 'react';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import { isEmpty } from 'lodash';
import DataFields from 'components/DataFields';
import { Empty } from '@ali/cn-design';
import MonacoEditor from 'components/MonacoEditor';

const ItemInfo = (props) => {
  const { style, value = {} } = props;
  const intl = useIntl();

  const dataSource = {
    force: intl('widget.ddegradation.executeCondition_all'),
    exception: intl('widget.ddegradation.executeCondition_warning')
  };

  const operData = {
    'return+null': intl('widget.mock.return_null'),
    throw: intl('widget.mock.return_excention_error'),
    'return+json': intl('widget.mock.return_customize_json'),
    'return+callback': intl('widget.mock.return_customize_callback'),
  };

  const getItems = (item) => [
    {
      dataIndex: 'Protocol',
      label: intl('widget.route.frame_type'),
      visible: true,
      render: val => {
        const Protocol = { springCloud: 'Spring Cloud', dubbo: 'Dubbo' };
        return Protocol[val] || '--';
      },
    },
    {
      dataIndex: 'ExecuteCondition',
      label: intl('widget.ddegradation.executeCondition'),
      visible: true,
      render: val => dataSource[val] || '--'
    },
    {
      dataIndex: 'ServiceName',
      label: intl('widget.degradation.service'),
      visible: item.Protocol === 'springCloud',
    },
    {
      dataIndex: 'Path',
      label: 'Path',
      visible: item.Protocol === 'springCloud',
    },
    {
      dataIndex: 'Service',
      label: intl('widget.app.service_method'),
      visible: item.Protocol === 'dubbo',
      span: 24,
    },
    {
      dataIndex: 'Oper',
      label: intl('widget.ddegradation.ddegradation_policy'),
      visible: true,
      render: val => operData[val] || '--'
    },
    {
      dataIndex: 'Method',
      label: intl('widget.service.httpMethods'),
      visible: item.Protocol === 'springCloud',
    },
    {
      dataIndex: 'ExceptionClassName',
      label: intl('widget.mock.force_name'),
      visible: item.Oper === 'throw',
    },
    {
      dataIndex: 'ExceptionMessage',
      label: intl('widget.mock.force_message'),
      visible: item.Oper === 'throw',
    },
    {
      dataIndex: 'ClazzName',
      label: intl('widget.mse.class_name'),
      visible: item.Oper === 'return+callback',
    },
    {
      dataIndex: 'DegradeServiceName',
      label: intl('widget.mse.callback_method'),
      visible: item.Oper === 'return+callback',
    },
    {
      dataIndex: 'Value',
      label: intl('widget.mock.policy_content'),
      visible: item.Oper === 'return+json',
      span: 24,
      render: (val) => (
        <MonacoEditor
          isEnableMaximize={false}
          width="100%"
          height={200}
          language="json"
          value={val}
          readOnly
          minimap={false}
        />
      )
    },
  ];

  return (
    <div style={{ width: '100%', ...style }}>
      <If condition={isEmpty(value)}>
        <Empty showIcon emptyMessage={intl('widget.common.no_data')} />
      </If>
      <If condition={!isEmpty(value)}>
        <For each="item" index="index" of={value}>
          <div key={index} className="common-box">
            <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.mock.service_rule_n', { n: index + 1 })}</div>
            <DataFields
              key={index}
              dataSource={{
                ...item,
                Service: `${item.ServiceName || ''}:${item.Version || ''}:${item.Group || ''} / ${item.MethodName || ''} (${item.ParamTypes || ''})`,
              }}
              items={getItems(item)}
              style={{ padding: '8px 0', borderBottom: 0 }}
            />
          </div>
        </For>
      </If>
    </div>
  );
};

ItemInfo.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  style: PropTypes.objectOf(PropTypes.any),
};

export default ItemInfo;
