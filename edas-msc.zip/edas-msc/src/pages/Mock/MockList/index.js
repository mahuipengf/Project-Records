import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import Events from './Events';
import { TableContainer, CopyContent, modelDecorator, Empty, Button, Message } from '@ali/cn-design';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import Status from 'components/Status/CommonStatus';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE } from 'constants';
import { map, isEmpty } from 'lodash';
import AddForm from './components/AddForm';
import RuleInfo from './components/RuleInfo';
import { Dubbo, SpringCloud } from 'components/Icon';

const PROTOCOL = {
  DUBBO: 'Dubbo',
  SPRING_CLOUD: 'Spring Cloud',
};

const ICON = {
  DUBBO: <Dubbo />,
  SPRING_CLOUD: <SpringCloud />,
};

function MockList(props) {
  const { tableUniqueKey, toggleModal } = props;
  const [isCanCustomColumns] = useState(true);
  const [isCanMultipleSearch] = useState(true);
  const [isCanRefresh] = useState(true);
  const [isAutoAddSorted] = useState(true);
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const [searchValues] = useGlobalState('searchValues');
  const addForm = useRef(null);
  const intl = useIntl();
  const { regionId, namespaceId } = searchValues;
  const defaultValue = {
    Protocol: searchValues.protocol || 'SPRING_CLOUD',
    Enable: true,
    Region: searchValues.regionId,
    Namespace: searchValues.namespaceId,
  };

  const fetchData = async ({ pageNumber, pageSize, Protocol, Name, ProviderAppName, ConsumerAppName }) => {
    let params = {
      Region: regionId,
      PageNumber: pageNumber,
      PageSize: pageSize,
      Protocol,
      Name,
      ProviderAppName,
      ConsumerAppName,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        ...params,
        Namespace: namespaceId
      };
    }
    const Data = await services.GetAccountMockRule({
      params
    });
    const { Result = [], TotalSize = 0 } = Data || {};
    return {
      Data: map(Result, item => ({ ...item, Region: item.Region || regionId, Namespace: item.Namespace || namespaceId })),
      TotalCount: TotalSize,
    };
  };

  const columns = [
    {
      key: 'Name',
      title: intl('widget.authentication.rule_name'),
      dataIndex: 'Name',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <span className="link-primary" onClick={() => handleGoToInfo(record)}>{value}</span>
        </CopyContent>
      ),
    },
    {
      key: 'ProviderAppName',
      title: intl('widget.mock.service_provider_application'),
      dataIndex: 'ProviderAppName',
      cell: value => (
        <CopyContent text={value}>
          {value}
        </CopyContent>
      )
    },
    {
      key: 'ConsumerAppName',
      title: intl('widget.degradation.degradation_app'),
      dataIndex: 'ConsumerAppName',
      cell: value => (
        <CopyContent text={value}>
          {value}
        </CopyContent>
      )
    },
    {
      key: 'Protocol',
      title: intl('widget.app.framework'),
      dataIndex: 'Protocol',
      cell: (value, index, record) => {
        const arr = [];
        if (!isEmpty(record.ScMockItems)) {
          arr.push('SPRING_CLOUD');
        }
        if (!isEmpty(record.DubboMockItems)) {
          arr.push('DUBBO');
        }
        return (
          <React.Fragment>
            <Empty value={!arr.length && undefined}>
              <For each="item" index="index" of={arr}>
                <div style={{ display: 'flex' }} key={index}>
                  {ICON[item]}
                  <span>{PROTOCOL[item]}</span>
                </div>
              </For>
            </Empty>
          </React.Fragment>
        );
      }
    },
    {
      key: 'Enable',
      title: intl('widget.common.state'),
      dataIndex: 'Enable',
      cell: val => <Status value={val} intl={intl} />
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => <Events record={record} handleEdit={() => handleEdit(record)} setFetchDataTime={setFetchDataTime} />,
    },
  ];

  const searchs = {
    typeInfo: {
      types: [
        { value: '', label: intl('widget.authentication.all_frame') },
        { value: 'SPRING_CLOUD', label: 'Spring Cloud' },
        { value: 'DUBBO', label: 'Dubbo' },
      ],
      defaultValue: searchValues.protocol || '',
      value: 'Protocol',
    },
    filterInfo: {
      filters: [
        {
          label: intl('widget.authentication.rule_name'),
          value: 'Name',
          placeholder: intl('widget.authentication.rule_name_placeholder')
        },
        {
          label: intl('widget.outlier_ejection.intro_provider'),
          value: 'ProviderAppName',
          placeholder: intl('widget.mock.please_input_intro_provider')
        },
        {
          label: intl('widget.outlier_ejection.intro_consumer'),
          value: 'ConsumerAppName',
          placeholder: intl('widget.mock.please_input_intro_consumer')
        },
      ],
      defaultValue: 'Name',
    },
    isCanCustomColumns,
    isCanMultipleSearch,
    tableUniqueKey,
    isCanRefresh,
  };

  const handleGoToInfo = (record) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl('widget.authentication.info'),
      content: (
        <RuleInfo value={{ ...record }} handleEdit={() => handleEdit(record)} />
      ),
      onConfirm: null,
    });
  };

  const handleEdit = (record = defaultValue) => {
    toggleModal({
      size: 'large',
      type: 'slide',
      visible: true,
      title: intl('widget.mock.edit_rule'),
      content: (
        <AddForm
          ref={addForm}
          value={{ ...record }}
          setRefreshIndex={setFetchDataTime}
        />
      ),
      onConfirm: () => addForm.current.handleSubmit(),
    });
  };

  const handleAdd = (record = defaultValue) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl('widget.degradation.create_rule'),
      content: (
        <AddForm
          ref={addForm}
          value={{ ...record }}
          setRefreshIndex={setFetchDataTime}
        />
      ),
      onConfirm: () => addForm.current.handleSubmit(),
    });
  };

  return (
    <React.Fragment>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && !IS_ENV_PRIVATE}>
        <Message type="warning" style={{ marginBottom: 16 }}>
          {intl.html('widget.degradation.label')}
        </Message>
      </If>
      <TableContainer
        fetchData={fetchData}
        primaryKey="id"
        columns={columns}
        search={searchs}
        refreshIndex={fetchDataTime}
        affixActionBar
        followTrigger
        isUseStorage={MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas'}
        sortConfig={{
          isAutoAddSorted,
        }}
        operation={() => (
          <Button type="primary" onClick={() => handleAdd()}>
            {intl('widget.degradation.create_rule')}
          </Button>
        )}
        emptyContent={
          <div >
            <Actions expandTriggerType="hover" style={{ justifyContent: 'center' }}>
              <LinkButton key="1" onClick={() => handleAdd()}>{intl('widget.authentication.no_data_go_create')}</LinkButton>
            </Actions>
          </div>
        }
      />
    </React.Fragment>
  );
}

MockList.propTypes = {
  toggleModal: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default modelDecorator(MockList);
