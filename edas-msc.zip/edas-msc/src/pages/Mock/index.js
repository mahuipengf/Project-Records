import MockList from './MockList';

export default MockList;
