import EventCenterList from './EventCenterList';

export default EventCenterList;
