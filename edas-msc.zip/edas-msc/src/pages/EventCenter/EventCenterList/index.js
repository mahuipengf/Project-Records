import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, CopyContent, Balloon } from '@ali/cn-design';
import { map, get } from 'lodash';
import { lowerFirstData } from 'utils/transfer-data';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { Dubbo, SpringCloud, Ons } from 'components/Icon';
import { timeFmt, aliyunSite, getParams } from 'utils';
import ChartsDialog from 'pages/App/AppDetail/components/common/ChartsDialog';
import styles from './index.less';
import moment from 'moment';

const ICON = {
  DUBBO: <Dubbo />,
  SPRING_CLOUD: <SpringCloud />,
  ONS: <Ons />
};

const WWidth = window.innerWidth;
const Loading = () => {
  const [show, setShow] = useState(0);

  useEffect(() => {
    setTimeout(() => {
      setShow(true);
    }, 300);
  });
  return show ? 'Loading' : '';
};

function EventCenterList(props) {
  const Tooltip = Balloon.Tooltip;
  const [mscAccount] = useGlobalState('mscAccount');
  const Version = get(mscAccount, 'Version'); // 开通版本
  const { rowSelection, selectionProps, tableUniqueKey } = props;
  const [appList, setAppList] = useGlobalState('appList');
  const [searchValues] = useGlobalState('searchValues');
  const [autoFetch, setAutoFetch] = useState(false);
  const [ahasFlowRule, setAhasFlowRule] = useState(false);
  const [startTime, setStartTime] = useState();
  const [endTime, setEndTime] = useState();
  const [dialogTitle, setDialogTitle] = useState();
  const [visible, setVisible] = useState(false);
  const [resource, setResource] = useState('');

  const intl = useIntl();
  const { regionId, namespaceId, appId, flowEvent = '' } = searchValues;
  const appName = getParams('appName');
  const currentAppList = [];

  const EVENT_TYPE = {
    ACTIVE_TRACE_Outlier_Ejection: intl('widget.event_center.outlier_ejection'),
    ACTIVE_TRACE_Outlier_Recover: intl('widget.event_center.outlier_recover'),
    ACTIVE_TRACE_Graceful_Shutdown: intl('widget.home.lossless'),
    ACTIVE_TRACE_Service_Auth: intl('widget.app.authentication'),
    // ACTIVE_TRACE_Empty_Protection: intl('widget.msc.event_center_name_empty_protection'),
    // ACTIVE_TRACE_APP_MANUAL_ONLINE: intl('widget.msc.event_center_name_manual_online'),
    // ACTIVE_TRACE_APP_MANUAL_OFFLINE: intl('widget.msc.event_center_name_manual_offline'),
  };
  if (aliyunSite !== 'INTL') {
    EVENT_TYPE.ACTIVE_TRACE_Empty_Protection = intl('widget.msc.event_center_name_empty_protection');
    EVENT_TYPE.ACTIVE_TRACE_APP_MANUAL_ONLINE = intl('widget.msc.event_center_name_manual_online');
    EVENT_TYPE.ACTIVE_TRACE_APP_MANUAL_OFFLINE = intl('widget.msc.event_center_name_manual_offline');
    EVENT_TYPE.TRAFFIC_BLOCK = intl('ahas_sentinel.systemGuard.flowControl.Trafficprotection');
  }

  useEffect(() => {
    setAhasFlowRule(false);
    fetchAppList({ regionId, namespaceId, pageNumber: 1, pageSize: 50 });
  }, []);

  const fetchAppList = async ({ regionId: RegionId, namespaceId: NamespaceId, pageNumber, pageSize }) => {
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      const { data = [] } = await services.GetAppList({
        params: { regionId: RegionId, namespaceId: NamespaceId }
      });
      const newData = map(data, item => ({
        ...item,
        key: item.appId,
        value: item.appId,
        label: item.appName,
      }));
      setAppList(newData);
      if (!autoFetch) {
        setAutoFetch(true);
      }
      return;
    }
    // 这个是分页接口，但是需要拿到全部数据
    const res = await services.GetAppList({
      params: { regionId: RegionId, pageNumber, pageSize }
    });
    const { result = [] } = lowerFirstData(res) || {};
    const newData = map(result, item => ({
      ...item,
      key: item.appId,
      value: item.appId,
      label: item.appName,
    }));
    currentAppList.push(...newData);
    if (result.length && result.length === pageSize) {
      fetchAppList({ regionId, pageNumber: pageNumber + 1, pageSize });
    } else {
      setAppList(currentAppList);
      if (!autoFetch) {
        setAutoFetch(true);
      }
    }
  };

  const fetchData = async (params) => {
    setAhasFlowRule(false);
    const res = await services.ListEventsPage({
      params: { ...params, ...searchValues }
    });
    const { result = [], totalSize: TotalCount = 0 } = lowerFirstData(res) || {};
    return {
      Data: result,
      TotalCount,
    };
  };

  const PROTOCOL_DATA = {
    DUBBO: 'Dubbo',
    SPRING_CLOUD: 'Spring Cloud',
    ONS: intl('widget.event_center.osc_message_list')
  };

  const getExtraInfo = (record) => {
    const isolationTimeTotal = get(record, 'extraInfo.isolationTime', 0) * get(record, 'extraInfo.isolationTimeMultiple', 0);
    const extraInfo = {
      service: get(record, 'service', ''),
      appName: get(record, 'appName', ''),
      timeStamp: timeFmt(get(record, 'timeStamp', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      consumerEndpoint: get(record, 'extraInfo.consumerEndpoint', ''),
      requestThreshold: get(record, 'extraInfo.requestThreshold', 0),
      errorRate: get(record, 'extraInfo.errorRate', 0) * 100,
      errorRateThreshold: get(record, 'extraInfo.errorRateThreshold', 0) * 100,
      maxIsolationRate: get(record, 'extraInfo.maxIsolationRate', 0) * 100,
      upStreamAppName: get(record, 'extraInfo.upStreamAppName', ''),
      providerEndpoint: get(record, 'extraInfo.providerEndpoint', 'provider'),
      isolationTime: get(record, 'extraInfo.isolationTime', 0) / 1000,
      isolationTimeMultiple: get(record, 'extraInfo.isolationTimeMultiple', 0),
      qps: get(record, 'extraInfo.qps', 0),
      recoverTime: timeFmt(get(record, 'extraInfo.recoverTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      isolationTimeTotal: get(record, 'extraInfo.isolationTime', 0) * get(record, 'extraInfo.isolationTimeMultiple', 0) / 1000,
      losslessTime: timeFmt(get(record, 'extraInfo.losslessTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      ip: get(record, 'extraInfo.ip', ''),
      result: get(record, 'extraInfo.result', false),
      upstreamAllServerCount: get(record, 'extraInfo.upstreamAllServerCount', 0),
      isolationServerCount: get(record, 'extraInfo.isolationServerCount', 0),
      ejectionTime: timeFmt(get(record, 'extraInfo.recoverTime', '') - isolationTimeTotal, 'YYYY-MM-DD HH:mm:ss'),
      offlineTime: timeFmt(get(record, 'extraInfo.offlineTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      readOnlyEventTime: timeFmt(get(record, 'extraInfo.readOnlyEventTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      unregisterTime: timeFmt(get(record, 'extraInfo.unregisterTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      killTime: timeFmt(get(record, 'extraInfo.killTime', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      readOnlyEventResult: get(record, 'extraInfo.readOnlyEventResult', false),
      unregisterResult: get(record, 'extraInfo.unregisterResult', ''),
      protocol: get(record, 'protocol', ''),
      success: get(record, 'extraInfo.success', false),
      emptyProtectionCount: get(record, 'extraInfo.count', 0),
      emptyProtectionTime: timeFmt(get(record, 'extraInfo.timestamp', ''), 'YYYY-MM-DD HH:mm:ss') || '--',
      emptyProtectionTime3Minute: timeFmt(get(record, 'extraInfo.timestamp', '') + (3 * 60 * 1000), 'YYYY-MM-DD HH:mm:ss') || '--',
      emptyProtectionServiceNameList: JSON.parse(get(record, 'extraInfo.serviceNameList', '[]')).join(),
      ruleId: get(record, 'extraInfo.ruleId', 0),
      blockInfo: get(record, 'extraInfo.blockInfo', 'FlowRule'),
      resource: get(record, 'extraInfo.resource', ''),
    };
    return extraInfo;
  };
  const search = {
    typeInfo: {
      types: [
        // { value: '', label: intl('widget.authentication.all_frame') },
        // { value: 'SPRING_CLOUD', label: 'Spring Cloud' },
        // { value: 'DUBBO', label: 'Dubbo' },
        { label: intl('widget.event_center.type_title', { label: intl('widget.event_center.all') }), value: '' },
        {
          value: 'ACTIVE_TRACE_Outlier_Ejection',
          label: intl('widget.event_center.type_title', { label: intl('widget.event_center.outlier_ejection') })
        },
        {
          value: 'ACTIVE_TRACE_Outlier_Recover',
          label: intl('widget.event_center.type_title', { label: intl('widget.event_center.outlier_recover') })
        },
        {
          value: 'ACTIVE_TRACE_Graceful_Shutdown',
          label: intl('widget.event_center.type_title', { label: intl('widget.home.lossless') })
        },
        // {
        //   value: 'ACTIVE_TRACE_Empty_Protection',
        //   label: intl('widget.event_center.type_title', { label: intl('widget.msc.event_center_name_empty_protection') })
        // },
        // {
        //   value: 'ACTIVE_TRACE_APP_MANUAL_ONLINE',
        //   label: intl('widget.event_center.type_title', { label: intl('widget.msc.event_center_name_manual_online') })
        // },
        // {
        //   value: 'ACTIVE_TRACE_APP_MANUAL_OFFLINE',
        //   label: intl('widget.event_center.type_title', { label: intl('widget.msc.event_center_name_manual_offline') })
        // },
      ],
      defaultValue: searchValues.eventType || '',
      value: 'eventType',
    },
    filterInfo: appId ? {} : {
      filters: [
        {
          label: intl('widget.app.name'),
          value: 'appId',
          mode: 'select',
          dataSource: [
            { label: intl('widget.service.all_app'), value: '' },
            ...appList
          ],
        },
      ],
      defaultValue: 'appId',
    },
    isCanCustomColumns: true,
    tableUniqueKey,
    isCanRefresh: true,
    isCanMultipleSearch: true,
  };
  const ACTIVE_TRACE_Empty_Protection = {
    value: 'ACTIVE_TRACE_Empty_Protection',
    label: intl('widget.event_center.type_title', { label: intl('widget.msc.event_center_name_empty_protection') })
  };
  const ACTIVE_TRACE_APP_MANUAL_ONLINE = {
    value: 'ACTIVE_TRACE_APP_MANUAL_ONLINE',
    label: intl('widget.event_center.type_title', { label: intl('widget.msc.event_center_name_manual_online') })
  };
  const ACTIVE_TRACE_APP_MANUAL_OFFLINE = {
    value: 'ACTIVE_TRACE_APP_MANUAL_OFFLINE',
    label: intl('widget.event_center.type_title', { label: intl('widget.msc.event_center_name_manual_offline') })
  };
  // ahas事件功能
  const ACTIVE_AHAS_Flow_control_rules = {
    value: 'TRAFFIC_BLOCK',
    label: intl('widget.event_center.type_title', { label: intl('ahas_sentinel.systemGuard.flowControl.Trafficprotection') }),
  };
  if (aliyunSite !== 'INTL') {
    search.typeInfo.types.push(ACTIVE_TRACE_Empty_Protection);
    search.typeInfo.types.push(ACTIVE_TRACE_APP_MANUAL_ONLINE);
    search.typeInfo.types.push(ACTIVE_TRACE_APP_MANUAL_OFFLINE);
    Version === 2 && search.typeInfo.types.push(ACTIVE_AHAS_Flow_control_rules);// 企业版增加流量防护
  }
  const columns = [
    {
      key: 'eventType',
      title: intl('widget.event_center.type'),
      dataIndex: 'eventType',
      cell: value => EVENT_TYPE[value] || '--',
    },
    {
      key: 'appName',
      title: intl('widget.event_center.source'),
      dataIndex: 'appName',
      cell: (value) => (
        <CopyContent text={value}>
          {value || '--'}
        </CopyContent>
      ),
    },
    {
      key: 'protocol',
      title: intl('widget.route.frame_type'),
      dataIndex: 'protocol',
      cell: value => (
        <React.Fragment>
          <If condition={value}>
            <div style={{ display: 'flex' }}>
              {ICON[value]}
              <span>{PROTOCOL_DATA[value]}</span>
            </div>
          </If>
          <If condition={!value}>--</If>
        </React.Fragment>
      ),
    },
    {
      key: 'timeStamp',
      title: intl('widget.event_center.create_time'),
      dataIndex: 'timeStamp',
      cell: value => value ? timeFmt(value, 'YYYY-MM-DD HH:mm:ss') : '--'
    },
    {
      key: 'sub',
      title: intl('widget.widget.event_center.abstract'),
      dataIndex: 'extraInfo',
      cell: (val, index, record) => {
        const extraInfo = getExtraInfo(record);
        if (record.protocol === 'ONS') {
          extraInfo.result = extraInfo.success;
        }
        const arr = {
          ACTIVE_TRACE_Outlier_Ejection: intl.html('widget.event_type.subscribe_outlier_ejection', extraInfo),
          ACTIVE_TRACE_Outlier_Recover: intl.html('widget.event_type.subscribe_outlier_recover', extraInfo),
          ACTIVE_TRACE_Graceful_Shutdown: extraInfo.result ? intl.html('widget.event_type.subscribe_lossless_cuccess', extraInfo) : intl.html('widget.event_type.subscribe_lossless_fail', extraInfo),
          ACTIVE_TRACE_Service_Auth: '',
          ACTIVE_TRACE_Empty_Protection: intl.html('widget.msc.event_center_abstract_empty_protection', extraInfo),
          ACTIVE_TRACE_APP_MANUAL_ONLINE: intl.html('widget.msc.event_center_abstract_manual_online', extraInfo),
          ACTIVE_TRACE_APP_MANUAL_OFFLINE: intl.html('widget.msc.event_center_abstract_manual_offline', extraInfo),
          TRAFFIC_BLOCK: intl.html('widget.msc.event_center_abstract_manual_offline_traffic_block', extraInfo),
        };
        return <Balloon closable={false} trigger={<div style={{ textOverflow: 'ellipsis', overflow: 'hidden', maxWidth: '300px', whiteSpace: 'nowrap', cursor: 'pointer' }}>{arr[record.eventType]}</div>}>{arr[record.eventType]}</Balloon>;
      },
    },
    {
      key: 'extraInfo',
      title: intl('widget.common.operating'),
      dataIndex: 'extraInfo',
      cell: (value, index, record) => {
        const extraInfo = {
          ...getExtraInfo(record),
          readOnlyEventResult: get(value, 'readOnlyEventResult', false) ? intl('widgt.common.success') : intl('widgt.common.fail'),
          result: get(value, 'result', false) ? intl('widgt.common.success') : intl('widgt.common.fail'),
          success: get(value, 'success', false) ? intl('widgt.common.success') : intl('widgt.common.fail'),
          onsResult: get(value, 'result', ''),
        };
        const arr = {
          ACTIVE_TRACE_Outlier_Ejection: {
            label: 'widget.event_type.centent_outlier_ejection',
            value: extraInfo,
          },
          ACTIVE_TRACE_Outlier_Recover: {
            label: 'widget.event_type.centent_outlier_recover',
            value: extraInfo,
          },
          ACTIVE_TRACE_Graceful_Shutdown: {
            label: 'widget.event_type.centent_lossless',
            value: extraInfo,
          },
          ACTIVE_TRACE_Empty_Protection: {
            label: 'widget.msc.event_center_detail_empty_protection',
            value: extraInfo,
          },
          ACTIVE_TRACE_APP_MANUAL_ONLINE: {
            label: 'widget.msc.event_center_detail_manual_online',
            value: extraInfo,
          },
          ACTIVE_TRACE_APP_MANUAL_OFFLINE: {
            label: 'widget.msc.event_center_detail_manual_offline',
            value: extraInfo,
          },
          TRAFFIC_BLOCK: {
            label: 'widget.msc.event_center_detail_manual_traffic_block',
            value: extraInfo,
          },
          // ACTIVE_TRACE_Service_Auth: '',
        };
        if (record.protocol === 'ONS') {
          arr.ACTIVE_TRACE_Graceful_Shutdown = {
            label: 'widget.event_type.centent_lossless_ons',
            value: extraInfo,
          };
        }
        const obj = arr[record.eventType] || { label: 'widget.common.no_data' };
        return (
          <Balloon trigger={<span className="link-primary">{intl('widget.event_center.see_content')}</span>} triggerType="click" align="l">
            {/* {intl.html(obj.label, obj.value)}{obj.value.emptyProtectionServiceNameList && intl.html('widget.msc.event_center_detail_empty_protection_services', obj.value)} */}
            {intl.html(obj.label, obj.value)}{intl.html('widget.msc.event_center_detail_empty_protection_services', obj.value)}
          </Balloon>
        );
      }
    },
  ];
  if (!autoFetch) {
    return <Loading />;
  }
  function renderEventLevel(value) {
    return (
      <span>
        {value ? (
          <span style={{ color: '#f54743' }}>ERROR</span>
        ) : (
          <span style={{ color: '#ffce03' }}>WARNING</span>
        )}
      </span>
    );
  }
  function renderType(type) {
    switch (type) {
      case 0:
        return '限流';
      case 1:
        return '异常';
      case 2:
        return 'CPU';
      case 3:
        return '熔断';
      case 4:
        return '系统保护';
      case 5:
        return '热点参数';
      case 6:
        return '主动降级';
      default:
        break;
    }
    return <span>{type === 0 ? '限流' : type === 1 ? '异常' : 'CPU'}</span>;
  }
  function initWidth() {
    if (WWidth * 0.1389 > 200) {
      return WWidth * 0.1389;
    }
    return 200;
  }
  function renderResource(value) {
    const val = value !== 'null' ? value : '--';
    return <div className={styles.apiName}>{val}</div>;
  }
  function renderRuleIds(value, index, record) {
    const { eventDetails = '' } = record;
    return <Tooltip trigger={<div style={{ cursor: 'pointer' }}>{value}</div>} align="b" >{eventDetails}</Tooltip>;
  }
  const rendergmtCreate = (time) => moment(time).format('YYYY-MM-DD HH:mm:ss');
  function renderEndTiem(value, index, record) {
    const nowDate = new Date().getTime();
    const { gmtModified } = record;
    const TimeDiff = nowDate - gmtModified;
    if (TimeDiff <= 60) {
      return '未结束';
    }
    return moment(gmtModified).format('YYYY-MM-DD HH:mm:ss');
  }
  function renderOpenDetail(value, index, record) {
    return (
      <a
        className={styles.viewDetailsBtn}
        onClick={() => {
          handleOpen(record);
        }}
        style={{ color: '#0070cc', cursor: 'pointer' }}
      >
        查看详情
      </a>
    );
  }
  const handleOpen = (record) => {
    const { resource, gmtCreate, gmtModified } = record;
    setStartTime(gmtCreate);
    setEndTime(gmtModified);
    setResource(resource);
    setDialogTitle(`监控详情：${resource}`);
    setVisible(true);
  };
  const flowCloumns = [
    {
      key: 'eventLevel',
      title: '级别',
      dataIndex: 'eventLevel',
      width: '200px',
      align: 'center',
      cell: renderEventLevel,
    },
    {
      key: 'eventType',
      title: '类型',
      dataIndex: 'eventType',
      width: '200px',
      align: 'center',
      cell: renderType,
    },
    {
      key: 'resource',
      title: '信息',
      dataIndex: 'resource',
      width: initWidth(),
      cell: renderResource,
    },
    {
      key: 'ruleIds',
      title: '详情',
      dataIndex: 'ruleIds',
      align: 'center',
      cell: renderRuleIds,
    },
    {
      key: 'gmtCreate',
      title: '开始时间',
      dataIndex: 'gmtCreate',
      align: 'center',
      cell: rendergmtCreate,
    },
    {
      key: 'gmtModified',
      title: '结束时间',
      dataIndex: 'gmtModified',
      align: 'center',
      cell: renderEndTiem,
    },
    {
      key: 'userId',
      title: '操作',
      dataIndex: 'userId',
      align: 'center',
      width: '150px',
      cell: renderOpenDetail
    },
  ];
  function handleHiddin() {
    setVisible(false);
  }
  async function getApi(params) {
    return await services.QuerySentinelMetricsOfResource({ params: { ...params, Namespace: 'default' } });
  }
  return (
    <React.Fragment>
      <If condition={autoFetch}>
        <TableContainer
          fetchData={fetchData} //
          primaryKey="appId"
          rowSelection={rowSelection}
          selectionProps={selectionProps}
          columns={columns}
          search={search}
          affixActionBar
          isUseStorage={MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas' && !searchValues.appId}
          sortConfig={{
            isAutoAddSorted: true,
          }}
          followTrigger
        />
      </If>
      <ChartsDialog
        handleHiddin={handleHiddin}
        visible={visible}
        typeCharts={'allQps'}
        getApi={getApi}
        resource={resource}
        startTime={startTime}
        endTime={endTime}
        dialogTitle={dialogTitle}
        hiddenTab
        eventCenter={'eventCenter'}

      />
    </React.Fragment>
  );
}

EventCenterList.propTypes = {
  rowSelection: PropTypes.shape(),
  selectionProps: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default EventCenterList;
