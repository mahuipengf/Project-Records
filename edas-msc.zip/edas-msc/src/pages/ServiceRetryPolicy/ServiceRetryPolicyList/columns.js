import React from "react"
import { CopyContent, Empty } from "@ali/cn-design"
import Status from "components/Status/CommonStatus"
import { Dubbo, SpringCloud, Istio } from "components/Icon"
import { timeFmt } from "utils"
import Events from "./Events"

const ICON = {
  DUBBO: <Dubbo />,
  SPRING_CLOUD: <SpringCloud />,
  istio: <Istio />,
}

const columns = (intl, handleEdit, setFetchDataTime) => {
  const PROTOCOL_TYPE = {
    istio: intl("widget.service.service_mesh"),
  }

  //   const FAULT_TYPE = {
  //     'abort': intl('widget.service_retry.abort_type'),
  //     'delay': intl('widget.service_retry.delay_type')
  //   };

  return [
    {
      key: "name",
      title: intl("widget.service_retry.rule_name"),
      dataIndex: "name",
      width: 120,
      cell: (value) => (
        <CopyContent text={value}>
          <Empty value={value || '--'}>{value || '--'}</Empty>
        </CopyContent>
      ),
    },
    {
      key: "enable",
      title: intl("widget.common.state"),
      dataIndex: "enable",
      width: 80,
      cell: (value) => <Status value={value} intl={intl} />,
    },
    {
      key: "protocol",
      title: intl("widget.service_retry.protocol_type"),
      dataIndex: "protocol",
      width: 100,
      cell: (value) => (
        <Empty value={value}>
          <div style={{ display: "flex" }}>
            {ICON[value]}
            <span>{PROTOCOL_TYPE[value]}</span>
          </div>
        </Empty>
      ),
    },
    {
      key: "appName",
      title: intl("widget.service_retry.app"),
      dataIndex: "appName",
      width: 120,
      cell: (value) => <Empty value={value}>{value}</Empty>,
    },
    {
      key: "tag",
      title: intl("widget.service_retry.tag"),
      dataIndex: "tag",
      width: 60,
      cell: (value) => <Empty value={value}>{value}</Empty>,
    },
    {
      key: 'sourceLabels',
      title: intl('widget.service_retry.traffic_sources'),
      dataIndex: 'rules',
      width: 120,
      cell: value => {
        const text = value && value.sourceLabels ? value.sourceLabels.join() : undefined;
        return (
          <Empty value={text}>{text}</Empty>
        );
      },
    },
    {
      key: "attempts",
      title: intl("widget.service_retry.max_retry_times"),
      dataIndex: "rules",
      width: 120,
      cell: (value) => <Empty value={value.attempts}>{value.attempts}</Empty>,
    },
    {
      key: "perTryTimeout",
      title: intl("widget.service_retry.timeout_response_time"),
      dataIndex: "rules",
      width: 120,
      cell: (value) => (
        <Empty value={value.perTryTimeout}>{value.perTryTimeout}ms</Empty>
      ),
    },
    {
      key: 'retryOn',
      title: intl('widget.service_retry.trigger_condition'),
      dataIndex: 'rules',
      width: 160,
      cell: value => (
        <Empty value={value.retryOn}>{value.retryOn}</Empty>
      ),
    },
    {
      key: "gmtModified",
      title: intl("widget.service_retry.modified_date"),
      dataIndex: "gmtModified",
      width: 160,
      cell: (value) => (
        <Empty value={value}>{timeFmt(value, "YYYY-MM-DD HH:mm:ss")}</Empty>
      ),
    },
    {
      key: "operations",
      title: intl("widget.common.operating"),
      width: 100,
      cell: (value, index, record) => (
        <Events
          record={record}
          handleEdit={() => handleEdit(record)}
          setFetchDataTime={setFetchDataTime}
        />
      ),
    },
  ]
}

export default columns
