import ServiceRetryPolicyList from './ServiceRetryPolicyList';

export default ServiceRetryPolicyList;
