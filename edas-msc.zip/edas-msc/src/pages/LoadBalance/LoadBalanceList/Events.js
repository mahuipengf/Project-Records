import React from 'react';
import PropTypes from 'prop-types';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';

const Events = (props) => {
  const intl = useIntl();
  const { handleEdit, handleDelete } = props;

  return (
    <Actions expandTriggerType="hover">
      <If condition={handleEdit}>
        <LinkButton key="1" onClick={handleEdit}>{intl('widget.common.edit')}</LinkButton>
      </If>
      <LinkButton key="4" onClick={handleDelete}>{intl('widget.common.delete')}</LinkButton>
    </Actions>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  handleEdit: PropTypes.func,
  handleDelete: PropTypes.func,
};

export default Events;
