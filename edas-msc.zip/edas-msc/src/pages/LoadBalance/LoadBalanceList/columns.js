import React from 'react';
import { CopyContent, Empty } from '@ali/cn-design';
import Status from 'components/Status/CommonStatus';
import { Dubbo, SpringCloud, Istio } from 'components/Icon';
import Events from './Events';

const ICON = {
  DUBBO: <Dubbo />,
  SPRING_CLOUD: <SpringCloud />,
  istio: <Istio />,
};

const columns = (intl, appList, handleEdit, handleDelete) => {

  const PROTOCOL_TYPE = {
    'istio': intl('widget.service.service_mesh')
  };

  return [
    {
      key: 'policyName',
      title: intl('widget.msc.rule_name'),
      dataIndex: 'policyName',
      width: 120,
      cell: value => (
        <CopyContent text={value}>
          <Empty value={value}>{value}</Empty>
        </CopyContent>
      ),
    },
    {
      key: 'enable',
      title: intl('widget.common.state'),
      dataIndex: 'enable',
      width: 80,
      cell: value => <Status value={value} intl={intl} />
    },
    {
      key: 'protocol',
      title: intl('widget.msc.protocol_type'),
      dataIndex: 'protocol',
      width: 100,
      cell: value => (
        <Empty value={value}>
          <div style={{ display: 'flex' }}>
            {ICON[value]}
            <span>{PROTOCOL_TYPE[value]}</span>
          </div>
        </Empty>
      ),
    },
    {
      key: 'appName',
      title: intl('widget.msc.app'),
      dataIndex: 'appId',
      width: 120,
      cell: value => {
        const appItem = appList.find(item => item.appId === value) || {};
        return <Empty value={appItem.appName}>{appItem.appName}</Empty>;
      },
    },
    {
      key: 'LoadBalanceType',
      title: intl('widget.msc.type'),
      dataIndex: 'loadBalanceType',
      width: 120,
      cell: value => {
        const type = {
          Simple: intl('widget.msc.easy'),
          ConsistentHash: intl('widget.msc.consistent_hash')
        };
        return type[value];
      },
    },
    {
      key: 'LoadBalanceConfig',
      dataIndex: 'loadBalanceConfig',
      title: intl('widget.msc.config'),
      width: 120,
      cell: (value, index, record) => {
        const type = {
          random: intl('widget.msc.random'),
          round_robin: intl('widget.msc.polling'),
          least_conn: intl('widget.msc.least_conn')
        };
        return record.loadBalanceType === 'Simple' && type[value] || "--";
      },
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      width: 80,
      cell: (value, index, record) => (
        <Events
          handleEdit={() => handleEdit(record)}
          handleDelete={() => handleDelete(record)}
        />
      ),
    },
  ];
};

export default columns;