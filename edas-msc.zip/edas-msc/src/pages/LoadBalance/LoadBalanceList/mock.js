export const listRes = {
    "code":200,
    "data":{
        "currentPage":1,
        "pageSize":10,
        "result":[
            {
                "appId":"fc86c7e7-5dd0-444c-a6ab-7c5cd77ad782",
                "appName":"productpage",
                "enable":true,
                "id":151,
                "loadBalanceConfig":"round_robin",
                "loadBalanceType":"Simple",
                "namespaceId":"cn-hangzhou",
                "policyName":"test",
                "protocol":"istio",
                "regionId":"cn-hangzhou",
                "status":0,
                "userId":"f0e3f448-4d0c-43a3-83d5-b5fc3c0ec586"
            }
        ],
        "totalSize":1
    },
    "httpStatusCode":200,
    "message":"fetchPolicyInfo success",
    "requestId":"",
    "success":true
}