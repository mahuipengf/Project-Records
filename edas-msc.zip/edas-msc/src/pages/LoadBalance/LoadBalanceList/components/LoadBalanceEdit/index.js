import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Message, Radio, Field, NumberPicker, Switch, RemoteSelect } from '@ali/cn-design';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { NNAME_PATTERN } from 'constants';
import SlidePanel from 'components/SlidePanel';
import { get, map, head, filter } from 'lodash';
import IconBack from 'components/IconBack';
import { Namespace } from '@ali/mamba-namespace';

const LoadBalanceEdit = (props) => {
  const [loading, setLoading] = useState(false);
  const [fetchAppTime, setFetchAppTime] = useState(undefined);
  const [searchValues] = useGlobalState('searchValues');
  const { value, visible, onClose, onOk } = props;
  const intl = useIntl();
  const field = Field.useField();
  const { init, validate, getValue, setValues, reset, getValues, setValue } = field;

  useEffect(() => {
    const policyName = get(value, 'policyName', '');
    const region = get(value, 'region', '');
    if (value.id) {
      setValues({
        policyName,
        region,
        ...value,
      });
    } else {
      setValues({
        region,
      });
    }
  }, [value]);

  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const params = {
        protocol: 'istio',
        appId: values.appId,
        region: values.region,
        policyName: values.policyName,
        loadBalanceType: values.loadBalanceType,
        consistHashType: values.consistHashType,
        enable: values.enable,
        policyDescription: values.policyDescription,
        source: "EDAS"
      };
      if (!values.id) {
        params.region = values.namespaces.regionId || searchValues.regionId;
        params.namespaceId = values.namespaces.namespaceId || searchValues.namespaceId;
      } else {
        params.id = values.id;
        params.namespaceId = values.namespaceId;
      }
      if (values.loadBalanceType === 'Simple') {
        params.loadBalanceConfig = values.loadBalanceConfig;
      }
      if (values.loadBalanceType === 'ConsistentHash') {
        switch (values.consistHashType) {
          case 'use_source_ip':
            params.loadBalanceConfig = values.use_source_ip;
            break;
          case 'http_header_name':
            params.loadBalanceConfig = values.http_header_name;
            break;
          case 'http_cookie':
            params.loadBalanceConfig = {
              cookieName: values.cookieName,
              cookiePath: values.cookiePath,
              ttl: values.ttl,
            };
            break;
          case 'http_qurey_parameter_name':
            params.loadBalanceConfig = values.http_qurey_parameter_name;
            break;
          default:
            break;
        }
      }
      editLoadBalancePolicy(params);
    });
  };

  // 创建
  const editLoadBalancePolicy = async (data) => {
    // console.log("params", params);
    // return;
    setLoading(true);
    if (value.id) {
      await services.updateLoadBalancePolicy({
        data,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      })
    } else {
      await services.addLoadBalancePolicy({
        data,
        customErrorHandle: (error, respongse, callback) => {
          setLoading(false);
          callback();
        }
      });
    }
    setLoading(false);
    onOk();
    reset();
    Message.success(intl(value.id ? 'widget.common.update_successful' : 'widget.common.add_successful'));
  };

  const handleClose = () => {
    setLoading(false);
    reset();
    onClose();
  };

  // 命名空间 -> 微服务空间
  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  // 命名空间 -> 微服务空间
  const fetchNamespaces = async (regionId) => {
    const { data = [] } = await services.fetchNamespaces({ params: { regionId } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  const fetchAppList = async () => {
    const { namespaces = {} } = getValues();
    const currentNamespaceId = namespaces.namespaceId || searchValues.namespaceId;
    const currentRegionId = namespaces.regionId || searchValues.regionId;
    const { data = [] } = await services.GetAppList({
      params: {
        regionId: currentRegionId,
        namespaceId: currentNamespaceId,
      }
    });
    let Data = map(data, item => ({
      ...item,
      key: item.appId,
      value: item.appId,
      label: item.appName,
    }));
    if (currentNamespaceId) {
      Data = filter(Data, item => item.regionId === currentNamespaceId); // 过滤掉命名空间不一致的应用，因为在默认命名空间下，会拿到所有的数据
    }
    const firstItem = head(Data);
    if (firstItem && !getValue('appId')) {
      setValue('appId', firstItem.value);
    }
    return { Data };
  };

  return (
    <SlidePanel
      title={
        <IconBack goBack={onClose}>
          {intl(value.id ? 'widget.msc.edit_rule_title' : 'widget.msc.create_rule_title')}
        </IconBack>
      }
      processingText={intl('widget.common.ok')}
      isShowing={visible}
      onOk={handleSubmit}
      onClose={handleClose}
      onCancel={handleClose}
      isProcessing={loading}
      width={780}
    >
      <Form field={field}>
        <If condition={!value.id}>
          <Form.Item label={intl('widget.common.microservice_space')} required>
            <Namespace
              {...init('namespaces', {
                initValue: { regionId: searchValues.regionId, namespaceId: searchValues.namespaceId },
                rules: [
                  {
                    required: true,
                    message: intl('widget.common.please_select_microservice_space'),
                  },
                ],
                props: {
                  onChange: () => {
                    setValue('appId', undefined);
                    setFetchAppTime(Date.now());
                  }
                }
              })}
              fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
              fetchNamespaces={fetchNamespaces}
            />
          </Form.Item>
        </If>
        <Form.Item label={intl('widget.msc.rule_name')} required>
          <Input
            {...init('policyName', {
              initValue: value.policyName,
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.name_input_error'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.msc.name_pattern'),
                },
              ],
            })}
            disabled={!!value.id}
            placeholder={intl('widget.msc.name_placeholder')}
            maxLength={64}
            minLength={1}
            showLimitHint
            style={{ width: '100%' }}
          />
        </Form.Item>
        <Form.Item label={intl('widget.msc.app')} required>
          <RemoteSelect
            {...init('appId', {
              initValue: value.appId,
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.app_error'),
                },
              ],
            })}
            disabled={!!value.id}
            style={{ width: '95%' }}
            showIcon
            refreshIndex={fetchAppTime}
            fetchData={fetchAppList}
            placeholder={intl('widget.msc.app_placeholder')}
          />
        </Form.Item>
        <Form.Item label={intl('widget.route.description')}>
          <Input.TextArea
            {...init('policyDescription', {
              initValue: value.policyDescription || '',
            })}
            placeholder={intl('widget.route.description_placecholder')}
            maxLength={64}
            style={{ width: 'calc(100% - 32px)' }}
            showLimitHint
            autoHeight={
              {
                minRows: 1,
                maxRows: 3
              }
            }
          />
        </Form.Item>
        <Form.Item label={intl('widget.msc.type')} required >
          <Radio.Group
            {...init('loadBalanceType', {
              initValue: value.loadBalanceType || 'Simple',
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.please_select_type')
                },
              ],
            })}
            dataSource={[
              { value: 'Simple', label: intl('widget.msc.easy') },
              { value: 'ConsistentHash', label: intl('widget.msc.consistent_hash') }
            ]}
          />
        </Form.Item>
        <If condition={getValue('loadBalanceType') === 'Simple'}>
          <Form.Item label={intl('widget.msc.config')} required>
            <Radio.Group
              {...init('loadBalanceConfig', {
                initValue: value.loadBalanceConfig || 'random',
                rules: [
                  {
                    required: true,
                    message: intl('widget.msc.please_select_config')
                  },
                ],
              })}
              dataSource={[
                { value: 'random', label: intl('widget.msc.random') },
                { value: 'round_robin', label: intl('widget.msc.polling') },
                { value: 'least_conn', label: intl('widget.msc.least_conn') },
              ]}
            />
          </Form.Item>
        </If>
        <If condition={getValue('loadBalanceType') === 'ConsistentHash'}>
          <div >
            <Form.Item
              label={intl('widget.msc.hash_type')}
              required
            >
              <Radio.Group
                {...init('consistHashType', {
                  initValue: value.consistHashType || 'use_source_ip',
                  rules: [
                    {
                      required: true,
                      message: intl('widget.msc.please_select_hash_type')
                    }
                  ]
                })}
                dataSource={[
                  { value: 'use_source_ip', label: intl('widget.msc.use_source_ip_hash') },
                  { value: 'http_header_name', label: intl('widget.msc.header_hash') },
                  { value: 'http_cookie', label: intl('widget.msc.cookie_hash') },
                  { value: 'http_qurey_parameter_name', label: intl('widget.msc.query_hash') },
                ]}
              />
            </Form.Item>
            <If condition={getValue('consistHashType') === 'use_source_ip'}>
              <Form.Item
                label={intl('widget.msc.use_source_ip')}
                required
              >
                <Radio.Group
                  {...init('use_source_ip', {
                    initValue: value.use_source_ip || 'true',
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_select_use_source_ip')
                      }
                    ]
                  })}
                  dataSource={[
                    { value: 'true', label: intl('widget.common.yes') },
                    { value: 'false', label: intl('widget.common.no') },
                  ]}
                />
              </Form.Item>
            </If>
            <If condition={getValue('consistHashType') === 'http_header_name'}>
              <Form.Item
                label="Header"
                required
              >
                <Input
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('http_header_name', {
                    initValue: value.http_header_name || '',
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_enter_header_hash')
                      },
                    ],
                  })}
                  placeholder={intl('widget.msc.please_enter_header_hash')}
                />
              </Form.Item>
            </If>
            <If condition={getValue('consistHashType') === 'http_cookie'}>
              <Form.Item
                label={intl('widget.msc.cookie_name')}
                required
              >
                <Input
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('cookieName', {
                    initValue: value.cookieName || '',
                    rules: [
                      {
                        required: true,
                        message: intl('widget.common.name_pattern'),
                      },
                      {
                        pattern: NNAME_PATTERN,
                        message: intl('widget.common.name_pattern'),
                      },
                    ],
                  })}
                  placeholder={intl('widget.common.name_pattern')}
                />
              </Form.Item>
              <Form.Item
                label={intl('widget.msc.cookie_path')}
                required
              >
                <Input
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('cookiePath', {
                    initValue: value.cookiePath || '',
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_enter_cookie_path'),
                      },
                    ],
                  })}
                  placeholder={intl('widget.msc.please_enter_cookie_path')}
                />
              </Form.Item>
              <Form.Item
                label={intl('widget.msc.cookie_timeout')}
                required
              >
                <NumberPicker
                  min={0}
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('ttl', {
                    initValue: value.ttl || '',
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_enter_cookie_timeout')
                      },
                    ],
                  })}
                  placeholder={intl('widget.msc.please_enter_cookie_timeout')}
                />
                <span style={{ marginLeft: 8 }}>s</span>
              </Form.Item>
            </If>
            <If condition={getValue('consistHashType') === 'http_qurey_parameter_name'}>
              <Form.Item
                label={intl('widget.msc.query')}
                required
              >
                <Input
                  style={{ width: 'calc(100% - 32px)' }}
                  {...init('http_qurey_parameter_name', {
                    initValue: value.http_qurey_parameter_name || '',
                    rules: [
                      {
                        required: true,
                        message: intl('widget.msc.please_enter_query')
                      },
                    ],
                  })}
                  placeholder={intl('widget.msc.please_enter_query')}
                />
              </Form.Item>
            </If>
          </div>
        </If>
        <Form.Item label={intl('widget.outlier_ejection.default_state')} style={{ margin: '18px 0 0' }}>
          <Switch
            {...init('enable', {
              initValue: value.enable || true,
              valueName: 'checked'
            })}
          />
        </Form.Item>
      </Form>
    </SlidePanel>
  );
};

LoadBalanceEdit.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
  k8sData: PropTypes.objectOf(PropTypes.any),
};

export default LoadBalanceEdit;
