import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { CopyContent } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import SlidePanel from 'components/SlidePanel';
import { get } from 'lodash';
import DataFields from 'components/DataFields';
import Status from 'components/Status/CommonStatus';
import DescEdit from 'components/DescEdit';
import IconBack from 'components/IconBack';

const LoadBalanceInfo = (props) => {
  const { value, visible, onClose } = props;
  const [currentData, setCurrentData] = useState(value);
  const intl = useIntl();

  useEffect(() => {
    if (!value.PolicyId || !visible) return;
    fetchData(value);
  }, [value]);

  const fetchData = async (params) => {
    // 列表数据已经全部拿到，可以不调用接口
    // const Data = await services.GetLoadBalancePolicyInfo({
    //   params: { PolicyId: params.PolicyId, Region: params.Region }
    // });
    const Data = params;
    switch (Data.ConsistHashType) {
      case 'http_cookie':
        Data.CookieName = get(JSON.parse(Data.LoadBalanceConfig), 'CookieName');
        Data.CookiePath = get(JSON.parse(Data.LoadBalanceConfig), 'CookiePath');
        Data.Ttl = get(JSON.parse(Data.LoadBalanceConfig), 'Ttl');
        break;
      case 'use_source_ip':
        Data.use_source_ip = get(Data, 'LoadBalanceConfig');
        break;
      case 'http_header_name':
        Data.http_header_name = get(Data, 'LoadBalanceConfig');
        break;
      case 'http_qurey_parameter_name':
        Data.http_qurey_parameter_name = get(Data, 'LoadBalanceConfig');
        break;
      default:
        break;
    }
    setCurrentData(Data);
  };


  const handleChangeDetail = async (params, customError) => {
    const newParams = {
      ...value,
      PolicyDescription: params.PolicyDescription,
    };
    await services.updateLoadBalancePolicy({
      params: newParams,
      customError
    });
    // value.PolicyDescription = params.PolicyDescription;
  };

  const items = [
    {
      dataIndex: 'PolicyName',
      label: intl('widget.outlier_ejection.policy_name'),
      render: val => {
        return (
          <CopyContent text={val}>
            {val}
          </CopyContent>
        );
      },
      visible: true
    },
    {
      dataIndex: 'Protocol',
      label: intl('widget.outlier_ejection.facing_this_frame'),
      render: () => 'Istio',
      visible: true
    },
    {
      dataIndex: 'PolicyDescription',
      label: intl('widget.route.description'),
      visible: true,
      render: (val) => (
        <DescEdit
          name="PolicyDescription"
          value={val && val.description}
          handleSubmit={handleChangeDetail}
        // onChange={(val) => setMockIdData({ ...value, PolicyDescription: val })}
        />
      ),
    },
    {
      dataIndex: 'Enable',
      label: intl('widget.common.state'),
      render: val => <Status value={val} />,
      visible: true,
    },
    {
      dataIndex: 'LoadBalanceType',
      label: intl('widget.msc.type'),
      visible: true,
      render: (val) => {
        const type = {
          Simple: intl('widget.msc.easy'),
          ConsistentHash: intl('widget.msc.consistent_hash')
        };
        return type[val] || '--';
      },
    },
    {
      dataIndex: 'LoadBalanceConfig',
      label: intl('widget.msc.config'),
      visible: currentData.LoadBalanceType === 'Simple',
    },
    {
      dataIndex: 'ConsistHashType',
      label: intl('widget.msc.hash_type'),
      visible: currentData.LoadBalanceType === 'ConsistentHash',
      render: (val) => {
        const type = {
          use_source_ip: intl('widget.msc.use_source_ip_hash'),
          http_header_name: intl('widget.msc.header_hash'),
          http_cookie: intl('widget.msc.cookie_hash'),
          http_qurey_parameter_name: intl('widget.msc.query_hash'),
        };
        return type[val] || '--';
      }
    },
    {
      dataIndex: 'CookieName',
      label: intl('widget.msc.cookie_name'),
      visible: currentData.ConsistHashType === 'http_cookie',
    },
    {
      dataIndex: 'CookiePath',
      label: intl('widget.msc.cookie_path'),
      visible: currentData.ConsistHashType === 'http_cookie',
    },
    {
      dataIndex: 'Ttl',
      label: intl('widget.msc.cookie_timeout'),
      visible: currentData.ConsistHashType === 'http_cookie',
    },
    {
      dataIndex: 'use_source_ip',
      label: intl('widget.msc.use_source_ip'),
      visible: currentData.ConsistHashType === 'use_source_ip',
    },
    {
      dataIndex: 'http_header_name',
      label: 'Header',
      visible: currentData.ConsistHashType === 'http_header_name',
    },
    {
      dataIndex: 'http_qurey_parameter_name',
      label: intl('widget.msc.query'),
      visible: currentData.ConsistHashType === 'http_qurey_parameter_name',
    }
  ];

  return (
    <SlidePanel
      title={
        <IconBack goBack={onClose}>{intl('widget.outlier_ejection.info')}</IconBack>
      }
      isShowing={visible}
      footer={false}
      onClose={onClose}
      width={780}
    >
      <DataFields
        title={intl('widget.common.basic_info')}
        dataSource={currentData}
        items={items}
      />
      {/* <ConfigInfo value={value} handleEditConfig={handleEditConfig} /> */}
    </SlidePanel>
  );
};

LoadBalanceInfo.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
};

export default LoadBalanceInfo;
