import LoadBalanceList from './LoadBalanceList';

export default LoadBalanceList;
