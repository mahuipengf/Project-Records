import React from 'react';
import PropTypes from 'prop-types';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { Message } from '@ali/cn-design';
import confirm from 'components/Confirm';
import services from 'services';

const Events = (props) => {
  const intl = useIntl();
  const { record, handleEdit, setFetchDataTime } = props;
  const [searchValues] = useGlobalState('searchValues');
  const { regionId, namespaceId } = searchValues;
  const { id, name } = record;

  const handleDelete = () => {
    confirm({
      title: intl('widget.common.delete'),
      content: intl('widget.service_timeout.list.delete_rule_confirm', { name }),
      onOk: () => services.removeServiceTimeoutPolicy({
        data: { id }
      }).then(() => {
        Message.success(intl('widget.common.delete_successful'));
        setFetchDataTime(Date.now());
      }),
    });
  };

  return (
    <Actions expandTriggerType="hover">
      <If condition={handleEdit}>
        <LinkButton key="1" onClick={handleEdit}>{intl('widget.common.edit')}</LinkButton>
      </If>
      <LinkButton key="4" onClick={handleDelete}>{intl('widget.common.delete')}</LinkButton>
    </Actions>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  handleEdit: PropTypes.func,
  setFetchDataTime: PropTypes.func,
};

export default Events;
