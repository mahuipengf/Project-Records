import React, {
  useImperativeHandle,
  forwardRef,
  useEffect,
  useMemo,
  useState,
} from "react"
import PropTypes from "prop-types"
import {
  Form,
  Input,
  Radio,
  Switch,
  Message,
  Loading,
  Select,
  Balloon,
  Icon,
  TreeSelect,
  NumberPicker
} from "@ali/cn-design"
import { Field } from "@alicloud/console-components"
import { RemoteSelect, BalloonIcon } from "@ali/cn-design"
import services from "services"
import { useIntl, useGlobalState } from "@ali/widget-hooks"
import { MSC_WIDGET_CONSOLE_CONFIG, NNAME_PATTERN } from "constants"
import {
  map,
  head,
  find,
  isEmpty,
  filter,
  cloneDeep
} from "lodash"
import { Namespace } from "@ali/mamba-namespace"
import TagSelector from "containers/TagSelector"

const FormItem = Form.Item

const EditForm = (props, ref) => {
  const field = Field.useField({ parseName: true })
  const { value, setRefreshIndex } = props
  const intl = useIntl()
  const { init, validate, getValue, setValue, setValues, remove, getValues } =
    field
  const [searchValues] = useGlobalState("searchValues")
  const [fetchAppTime, setFetchAppTime] = useState(undefined)
  const [appList, setAppList] = useGlobalState("appList")
  const [isLoading, setIsLoading] = useState(false)
  const [serviceLoading, setServiceLoading] = useState(false)
  const [appServiceData, setAppServiceData] = useGlobalState("appServiceData")
  const currentAppList = []

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }))

  useEffect(() => {
    if (value.id) {
      const { routeRules, ...restValue } = cloneDeep(value);
      restValue.rules = routeRules && routeRules[0] ? routeRules[0] : {};
      setValues({ ...restValue })
    }
  }, [value])

  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        console.log({
          errors,
          values,
        })
        if (errors) return reject(errors)

        const {
          id,
          name,
          protocol,
          appId,
          enable,
          namespaces = {},
          tag,
          rules: { tags, ...restRules },
        } = values
        const paramsRule = JSON.stringify({ ...restRules })
        if (id) {
          const params = {
            id,
            enable,
            rules: paramsRule
          }
          await services.updateServiceTimeoutPolicy({
            data: params,
            customErrorHandle: (err, response, callback) => {
              reject();
              callback();
            }
          })
        } else {
          const params = {
            name,
            appId,
            tag,
            protocol,
            enable,
            rules: paramsRule,
            region: namespaces.regionId || searchValues.regionId,
            namespaceId: namespaces.namespaceId || searchValues.namespaceId,
          }
          await services.addServiceTimeoutPolicy({
            data: params,
            customErrorHandle: (err, response, callback) => {
              reject();
              callback();
            }
          });
        }
        id
          ? Message.success(intl("widget.common.update_successful"))
          : Message.success(intl("widget.common.add_successful"))
        resolve()
        setRefreshIndex(Date.now())
      })
    })
  }

  // 命名空间 -> 微服务空间
  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions()
    const newData = map(data, (item) =>
      item.regionName &&
        item.regionName.indexOf(intl("widget.common.namespace")) > -1
        ? {
          ...item,
          regionName: item.regionName.replace(
            intl("widget.common.namespace"),
            intl("widget.common.microservice_space")
          ),
        }
        : item
    )
    return newData
  }

  // 命名空间 -> 微服务空间
  const fetchNamespaces = async (regionId) => {
    const { data = [] } = await services.fetchNamespaces({
      params: { regionId },
    })
    const newData = map(data, (item) =>
      item.namespaceName &&
        item.namespaceName.indexOf(intl("widget.common.namespace")) > -1
        ? {
          ...item,
          namespaceName: item.namespaceName.replace(
            intl("widget.common.namespace"),
            intl("widget.common.microservice_space")
          ),
        }
        : item
    )
    return newData
  }

  const fetchAppList = async () => {
    const { namespaces = {} } = getValues()
    const currentNamespaceId =
      namespaces.namespaceId || searchValues.namespaceId
    const currentRegionId = namespaces.regionId || searchValues.regionId
    const { data = [] } = await services.GetAppList({
      params: {
        regionId: currentRegionId,
        namespaceId: currentNamespaceId,
      },
    })
    let Data = map(data, (item) => ({
      ...item,
      key: item.appId,
      value: item.appId,
      label: item.appName,
    }))
    if (currentNamespaceId) {
      Data = filter(Data, (item) => item.regionId === currentNamespaceId) // 过滤掉命名空间不一致的应用，因为在默认命名空间下，会拿到所有的数据
    }
    const firstItem = head(Data)
    if (firstItem && !getValue("appId")) {
      setValue("appId", firstItem.value)
    }
    setAppList(Data)
    return { Data }
  }

  const sourcesList = useMemo(() => {
    const parentNode = { value: "*", label: "ALL", children: [] }
    if (appList && appList.length) {
      const childrenNodes = appList.map((item) => ({
        ...item,
        value: item.label,
      }))
      parentNode.children = childrenNodes;
    }
    return [parentNode]
  }, [appList])


  const PROTOCOL_DATA = () => {
    const arr = [{ value: "istio", label: intl("widget.service.service_mesh") }]
    const firstItem = head(arr) || {}
    const currentItem = find(arr, { value: getValue("protocol") })
    if (!value.id && isEmpty(currentItem)) {
      setValue("protocol", firstItem.value)
    }
    return arr
  }

  return (
    <Loading visible={isLoading} style={{ width: "100%" }}>
      <Form field={field} labelAlign="left">
        <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === "Edas"}>
          <If condition={!value.id}>
            <FormItem label={intl("widget.common.microservice_space")} required>
              <Namespace
                {...init("namespaces", {
                  initValue: {
                    regionId: searchValues.regionId,
                    namespaceId: searchValues.namespaceId,
                  },
                  rules: [
                    {
                      required: true,
                      message: intl(
                        "widget.common.please_select_microservice_space"
                      ),
                    },
                  ],
                  props: {
                    onChange: () => {
                      setValue("appId", undefined)
                      setValue("tag", undefined)
                      setFetchAppTime(Date.now())
                    },
                  },
                })}
                fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
                fetchNamespaces={fetchNamespaces}
              />
            </FormItem>
          </If>
        </If>
        <FormItem label={intl("widget.service_timeout.rule_name")} required>
          <Input
            {...init("name", {
              // initValue: value.name,
              rules: [
                {
                  required: true,
                  message: intl("widget.service_timeout.name_input_error"),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl("widget.service_timeout.name_pattern"),
                },
              ],
            })}
            disabled={!!value.id}
            placeholder={intl("widget.service_timeout.name_placeholder")}
            maxLength={64}
            minLength={1}
            showLimitHint
            style={{ width: "100%" }}
          />
        </FormItem>
        <FormItem label={intl("widget.service_timeout.app")} required>
          <RemoteSelect
            {...init("appId", {
              initValue: value.appId,
              rules: [
                {
                  required: true,
                  message: intl("widget.service_timeout.app_error"),
                },
              ],
              props: {
                onChange: () => {
                  setValue("tag", undefined)
                  remove("tag")
                },
              },
            })}
            style={{ width: "95%" }}
            showIcon
            refreshIndex={fetchAppTime}
            fetchData={fetchAppList}
            placeholder={intl("widget.service_timeout.app_placeholder")}
          />
        </FormItem>
        <FormItem label={intl("widget.service_timeout.tag")} required>
          <TagSelector
            {...init('tag', {
              initValue: value.tag,
              rules: [
                {
                  required: true,
                  message: intl('widget.common.select_tag'),
                },
              ],
            })}
            appId={getValue('appId')}
            namespaces={getValue('namespaces')}
            disabled={!!value.id}
          />
        </FormItem>
        <FormItem label={intl("widget.service_timeout.state")} required>
          <Switch
            {...init("enable", {
              initValue: !!value.enable,
            })}
            defaultChecked={!!value.enable}
            style={{ marginTop: 4 }}
          />
        </FormItem>
        <FormItem label={intl("widget.service_timeout.protocol")} required>
          <Loading visible={serviceLoading}>
            <Radio.Group
              dataSource={PROTOCOL_DATA()}
              {...init("protocol", {
                // initValue: value.protocol,
                rules: [
                  {
                    required: true,
                    message: intl("widget.service_timeout.protocol_error"),
                  },
                ],
              })}
              disabled={!!value.id}
            />
          </Loading>
        </FormItem>
        <FormItem
          label={intl("widget.service_timeout.traffic_sources")}
          required
        >
          <Loading visible={serviceLoading}>
            <TreeSelect
              treeCheckable
              dataSource={sourcesList}
              {...init("rules.sourceLabels", {
                rules: [
                  {
                    required: true,
                    message: intl(
                      "widget.service_timeout.traffic_sources_error"
                    ),
                  },
                ],
              })}
              style={{ width: 200 }}
            />
          </Loading>
        </FormItem>

        <FormItem
          label={
            <span>
              {intl("widget.service_timeout.timeout_response_time")}
              <BalloonIcon type="info-circle" text={intl('widget.service_timeout.timeout_response_time_remind')} size="small" style={{ marginLeft: 5 }} />
            </span>
          }
          required
        >
          <NumberPicker
            {...init("rules.timeout", {
              rules: [
                {
                  required: true,
                  message: intl(
                    "widget.service_timeout.timeout_response_time_error"
                  ),
                },
              ],
            })}
            min={0}
            addonTextAfter="ms"
            style={{ width: 200 }}
            placeholder={intl("widget.service_timeout.timeout_response_time_placeholder")}
          />
        </FormItem>
      </Form>
    </Loading>
  )
}

const RefEditForm = forwardRef(EditForm)

EditForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  setRefreshIndex: PropTypes.number,
}

export default RefEditForm
