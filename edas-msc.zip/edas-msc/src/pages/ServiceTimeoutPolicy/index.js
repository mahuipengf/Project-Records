import ServiceTimeoutPolicyList from './ServiceTimeoutPolicyList';

export default ServiceTimeoutPolicyList;
