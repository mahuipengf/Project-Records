import React from 'react';
import { Tab, Message } from '@ali/cn-design';
import { map } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import AppServiceList from 'containers/ServiceList';
import { DUBBO, SPRING_CLOUD, HSF } from '../constants';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE } from 'constants';

const SERVICE_TYPE = {
  springCloud: 'Spring Cloud',
  dubbo: 'Dubbo',
  hsf: 'HSF',
};

const Comp = props => {
  return (
    <React.Fragment>
      <AppServiceList condition={{ ...props, serviceType: DUBBO }} title={SERVICE_TYPE[DUBBO]} />
      <AppServiceList condition={{ ...props, serviceType: SPRING_CLOUD }} title={SERVICE_TYPE[SPRING_CLOUD]} />
      <AppServiceList condition={{ ...props, serviceType: HSF }} title={SERVICE_TYPE[HSF]} />
    </React.Fragment>
  );
};

const AppSerivceList = () => {
  const intl = useIntl();
  const [searchValues] = useGlobalState('searchValues');
  const [component] = useGlobalState('component');
  const { appId, regionId, namespaceId, origin } = searchValues;

  const tabs = [
    {
      tab: intl('widget.service.provider_services'),
      key: 'provider',
      content: (
        <Comp
          serviceType="dubbo"
          side="provider"
          appId={appId}
          regionId={regionId}
          namespaceId={namespaceId}
          origin={origin}
        />
      )
    },
    {
      tab: intl('widget.service.consumer_services'),
      key: 'consumer',
      content: (
        <Comp
          serviceType="dubbo"
          side="consumer"
          appId={appId}
          regionId={regionId}
          namespaceId={namespaceId}
          origin={origin}
        />
      )
    },
  ];

  return (
    <React.Fragment>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && component === 'ServiceList' && !IS_ENV_PRIVATE}>
        <Message type="notice" style={{ margin: '16px 0' }}>
          {intl.html('widget.service.app_service_label')}
        </Message>
      </If>
      <div style={{ margin: '16px 0', fontSize: 28 }}>{intl('widget.service.service_list')}</div>
      <Tab shape="wrapped">
        {map(tabs, n => (
          <Tab.Item title={n.tab} key={n.key}>
            {n.content}
          </Tab.Item>
        ))}
      </Tab>
    </React.Fragment>
  );
};

export default AppSerivceList;
