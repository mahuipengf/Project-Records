import React, { useState, useEffect } from 'react';
import Cookie from 'js-cookie';
import PropTypes from 'prop-types';
import { Message, TableContainer, BalloonIcon } from '@ali/cn-design';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { map } from 'lodash';
import { lowerFirstData } from 'utils/transfer-data';
import columns from './columns';
import { SPRING_CLOUD, DUBBO, REGISTRY, AGENT, IP_PATTERN } from '../constants';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE, WIDGET_ID } from 'constants';
import MySelect from './components/MySelect';

function ServiceList(props) {
  const { rowSelection, selectionProps, tableUniqueKey } = props;
  const [isCanCustomColumns] = useState(true);
  const [isCanRefresh] = useState(true);
  const [isAutoAddSorted] = useState(true);
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const [appList, setAppList] = useGlobalState('appList');
  const [searchValues, setSearchValues] = useGlobalState('searchValues');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const [autoFetch, setAutoFetch] = useState(false);
  const aliyunLang = Cookie.get('aliyun_lang') || 'zh';

  const intl = useIntl();
  const { regionId, namespaceId, serviceType, origin } = searchValues;
  const currentAppList = [];

  useEffect(() => {
    fetchAppList({ regionId, namespaceId, pageNumber: 1, pageSize: 50 });
  }, []);

  const fetchAppList = async ({ regionId: RegionId, namespaceId: NamespaceId, pageNumber, pageSize }) => {
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      const { data = [] } = await services.GetAppList({
        params: { regionId: RegionId, namespaceId: NamespaceId }
      });
      const newData = map(data, item => ({
        ...item,
        key: item.appId,
        value: item.appId,
        label: item.appName,
      }));
      setAppList(newData);
      if (!autoFetch) {
        setAutoFetch(true);
      }
      return;
    }
    // 这个是分页接口，但是需要拿到全部数据
    const res = await services.GetAppList({
      params: { regionId: RegionId, pageNumber, pageSize }
    });
    const { result = [] } = lowerFirstData(res) || {};
    const newData = map(result, item => ({
      ...item,
      key: item.appId,
      value: item.appId,
      label: item.appName,
    }));
    currentAppList.push(...newData);
    if (result.length && result.length === pageSize) {
      fetchAppList({ regionId, pageNumber: pageNumber + 1, pageSize });
    } else {
      setAppList(currentAppList);
      if (!autoFetch) {
        setAutoFetch(true);
      }
    }
  };

  const fetchData = async (params) => {
    const defaultParams = { serviceName: undefined, ip: undefined, appId: undefined, };
    setSearchValues({ ...searchValues, ...defaultParams, ...params });
    const newParams = {
      ...searchValues,
      ...defaultParams,
      ...params,
    };
    if (newParams.ip && !IP_PATTERN.test(newParams.ip)) {
      Message.warning(intl('widget.service.input_correct_ip'));
      return;
    }
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      const valueObj = {
        app: newParams.appId,
        service: newParams.serviceName,
        providerIp: newParams.ip,
      };
      const searchType = newParams.serviceName ? 'service' : (newParams.ip ? 'providerIp' : 'app');
      const Params = {
        page: newParams.pageNumber - 1,
        size: newParams.pageSize,
        serviceType,
        searchType,
        searchValue: valueObj[searchType] || '',
        region: regionId,
        namespace: namespaceId,
        origin: newParams.origin,
      };
      const { totalElements = 0, content = [] } = await services.fetchServicesList({ data: Params });
      return {
        Data: content,
        TotalCount: totalElements,
      };
    }
    const res = await services.fetchServicesList({ data: newParams });
    const { result = [], totalSize: TotalCount = 0 } = lowerFirstData(res) || {};
    return {
      Data: result,
      TotalCount,
    };
  };

  const handleChangeOrigin = () => {
    const newOrigin = searchValues.origin !== AGENT ? AGENT : REGISTRY;
    // 旧版搜索方式，并且是spring cloud，不支持 ip、应用名搜索方式
    if (newOrigin === 'registry' && serviceType === 'springCloud') {
      setSearchValues({ ...searchValues, origin: newOrigin, searchType: 'service' });
    } else {
      setSearchValues({ ...searchValues, origin: newOrigin });
      setFetchDataTime(Date.now());
    }
  };

  const getSearchs = () => {
    const searchs = {
      filterInfo: {
        filters: [
          {
            label: intl('widget.service.service_name'),
            value: 'serviceName',
            placeholder: intl('widget.service.service_placeholder')
          },
          {
            label: 'IP',
            value: 'ip',
            placeholder: intl('widget.service.ip_placeholder')
          },
          {
            label: intl('widget.service.app_name'),
            value: 'appId',
            component: MySelect,
            //   mode: 'select',
            //   dataSource: [
            //     { label: intl('widget.service.all_app'), value: '' },
            //     ...appList
            //   ],
            // },
          },
        ],
        defaultValue: 'serviceName',
      },
      isCanCustomColumns,
      tableUniqueKey,
      isCanRefresh,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'mse') {
      searchs.typeInfo = {
        types: [
          {
            label: intl('widget.common.frame', { name: 'Spring Cloud' }),
            value: SPRING_CLOUD,
          },
          {
            label: intl('widget.common.frame', { name: 'Dubbo' }),
            value: DUBBO,
          },
          // { // 暂时隐藏istio
          //   label: intl('widget.common.frame', { name: 'Istio' }),
          //   value: 'istio',
          // },
        ],
        defaultValue: serviceType || SPRING_CLOUD,
        value: 'serviceType',
        style: {
          width: aliyunLang === 'en' ? 200 : 166,
        }
      };
    }

    if (searchValues.origin === 'registry' && searchValues.serviceType === 'springCloud') {
      searchs.filterInfo = {
        filters: [
          {
            label: intl('widget.service.service_name'),
            value: 'serviceName',
            placeholder: intl('widget.service.service_placeholder')
          },
        ],
        defaultValue: 'serviceName',
      };
    }
    return searchs;
  };

  const handleFetchLink = async (record) => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-Performance`, record);
  };
  const handleClickGoToAppInfo = (record) => { // 服务查询跳转到旧版本应用详情
    eventEmitter.emit(`${WIDGET_ID}:go-to-AppInfo`, record);
  };
  return (
    <React.Fragment>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && !IS_ENV_PRIVATE}>
        <If condition={serviceType === SPRING_CLOUD}>
          <Message type="warning" style={{ marginBottom: 8 }}>
            {intl.html('widget.service.sc_label')}
          </Message>
        </If>
        <If condition={serviceType === DUBBO}>
          <Message type="warning" style={{ marginBottom: 8 }}>
            {intl.html('widget.service.dubbo_label')}
          </Message>
        </If>
        <If condition={serviceType === 'hsf'}>
          <Message type="warning" style={{ marginBottom: 8 }}>
            {intl.html('widget.service.hsf_label')}
          </Message>
        </If>
        <If condition={serviceType === SPRING_CLOUD || serviceType === DUBBO}>
          <div style={{ display: 'flex', alignItems: 'center', lineHeight: '30px', color: '#555', marginLeft: 8, marginBottom: 8 }}>
            <span>{intl(searchValues.origin === AGENT ? 'widget.service.search_old_label' : 'widget.service.search_new_label')}</span>
            <span className="link-primary" style={{ marginRight: '4px' }} onClick={handleChangeOrigin}>{intl(searchValues.origin === AGENT ? 'widget.service.switch_old_version' : 'widget.service.switch_new_version')}</span>
            <BalloonIcon text={intl('widget.service.search_hint')} />
          </div>
        </If>
      </If>
      <TableContainer
        autoFetch={autoFetch}
        fetchData={fetchData}
        primaryKey="id"
        rowSelection={rowSelection}
        selectionProps={selectionProps}
        columns={columns(intl, serviceType, handleFetchLink, handleClickGoToAppInfo)}
        search={getSearchs()}
        refreshIndex={fetchDataTime}
        affixActionBar
        sortConfig={{
          isAutoAddSorted,
        }}
        followTrigger
      />
    </React.Fragment >
  );
}

ServiceList.propTypes = {
  rowSelection: PropTypes.shape(),
  selectionProps: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default ServiceList;
