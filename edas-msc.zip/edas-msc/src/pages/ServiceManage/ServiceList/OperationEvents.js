import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { modelDecorator } from '@ali/cn-design';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import TrafficManage from "./components/TrafficManage";

// const TrafficManage = loadWidget({
//    id: '@ali/widget-edas-traffic-manage',
//    version: '0.1',
// })

const OperationEvents = ({ record }) => {
  const intl = useIntl();
  const [trafficManageVisible, setTrafficManageVisible] = useState(false);

  const handleToggleTrafficManage = (show) => {
    setTrafficManageVisible(!!show);
  };

  return (
    <>
      <Actions expandTriggerType="hover">
        {/* <LinkButton key="1" onClick={handleToggleSecuritySettings.bind(null, true)}>
          {intl('widget.service.security_settings')}
        </LinkButton> */}
        <LinkButton key="1" onClick={handleToggleTrafficManage.bind(null, true)}>
          {intl('widget.service.traffic_manage')}
        </LinkButton>
      </Actions>
      {
        trafficManageVisible && <TrafficManage
          isShowing={trafficManageVisible}
          data={record}
          onCancel={handleToggleTrafficManage.bind(null, false)}
          onCreate={handleToggleTrafficManage.bind(null, false)}
        />
      }
    </>
  );
};

OperationEvents.propTypes = {
  record: PropTypes.shape(),
  emitName: PropTypes.string,
};

export default modelDecorator(OperationEvents);
