import React from 'react';
import PropTypes from 'prop-types';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { modelDecorator } from '@ali/cn-design';
import ServiceInfo from './components/ServiceInfo';
import { assign } from 'lodash';

const Events = ({ record, children, emitName, toggleModal }) => {
  const [searchValues] = useGlobalState('searchValues');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const { serviceType, regionId, namespaceId, origin } = searchValues;
  const { group: serviceGroup, version: serviceVersion, serviceName, edasAppId: appId, serviceId, registryType } = record;
  const newRecord = {
    serviceType,
    regionId,
    namespaceId,
    origin,
    appId,
    serviceGroup,
    serviceVersion,
    serviceName,
    serviceId,
    registryType,
  };
  const intl = useIntl();

  const handleGoAppInfo = () => {
    const { searchType, searchValue: searchValue1, ip } = searchValues;
    const values = assign(
      { serviceType, searchType, searchValue: searchValue1, origin, ip },
      { ...record, appId: record.edasAppId },
      { regionId, namespaceId }
    );
    eventEmitter.emit(emitName, values);
  };

  const handleOpen = () => {
    toggleModal({
      type: 'slide',
      size: 'xl',
      visible: true,
      title: intl('widget.service.serviceInfo'),
      content: (
        <ServiceInfo value={newRecord} />
      ),
    });
  };

  return (
    <React.Fragment>
      <If condition={!emitName}>
        <span className="link-primary" onClick={handleOpen}>{children}</span>
      </If>
      <If condition={emitName}>
        <span className="link-primary" onClick={handleGoAppInfo}>{children}</span>
      </If>
    </React.Fragment>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  children: PropTypes.string,
  emitName: PropTypes.string,
};

export default modelDecorator(Events);
