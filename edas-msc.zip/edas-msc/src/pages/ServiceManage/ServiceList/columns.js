import React from 'react';
import { Empty, CopyContent } from '@ali/cn-design';
import Events from './Events';
import ServiceTestEvents from '../../ServiceTest/Events';
import { SPRING_CLOUD } from '../constants';
import { WIDGET_ID, MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE, EDAS_CHANNEL_INFO } from 'constants';
import './index.less';
import OperationEvents from './OperationEvents';

const columns = (intl, serviceType, handleFetchLink, handleClickGoToAppInfo) => {
  let column = [
    {
      key: 'serviceName',
      title: intl('widget.service.service_name'),
      dataIndex: 'serviceName',
      cell: (value, index, record) => (
        <React.Fragment>
          <If condition={!!value}>
            <CopyContent text={value}>
              <Events record={record}>
                {record.serviceName}
              </Events>
            </CopyContent>
          </If>
          <If condition={!value}>--</If>
        </React.Fragment>
      ),
    },
    {
      key: 'version',
      title: intl('widget.service.version'),
      dataIndex: 'version',
      cell: value => <Empty value={value}>{value}</Empty>,
    },
    {
      key: 'group',
      title: intl('widget.service.group'),
      dataIndex: 'group',
      cell: value => (
        <Empty value={value}>
          {value}
        </Empty>
      ),
    },
    {
      key: 'edasAppName',
      title: intl('widget.service.app_name'),
      dataIndex: 'edasAppName',
      cell: (value, index, record) => (
        <Empty value={value}>
          <CopyContent text={value}>
            <If condition={!record.edasAppId || MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas'}>
              <span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={() => handleClickGoToAppInfo(record)}>{record.edasAppName}</span>
            </If>
            <If condition={record.edasAppId && MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
              <If condition={!!record.edasAppId}>
                <Events record={record} emitName={`${WIDGET_ID}:go-to-appInfo`}>
                  {record.edasAppName}
                </Events>
              </If>
            </If>
          </CopyContent>
        </Empty>
      ),
    },
    {
      key: 'instanceNum',
      title: intl('widget.service.instance_number'),
      dataIndex: 'instanceNum',
      cell: value => <Empty value={value}>{value}</Empty>,
    },
  ];
  if (serviceType === SPRING_CLOUD) {
    column = [
      {
        key: 'serviceName',
        title: intl('widget.service.service_name'),
        dataIndex: 'serviceName',
        cell: (value, index, record) => (
          <React.Fragment>
            <If condition={!!value}>
              <CopyContent text={value}>
                <Events record={record}>
                  {record.serviceName}
                </Events>
              </CopyContent>
            </If>
            <If condition={!value}>--</If>
          </React.Fragment>
        ),
      },
      {
        key: 'edasAppName',
        title: intl('widget.service.app_name'),
        dataIndex: 'edasAppName',
        cell: (value, index, record) => (
          <Empty value={value}>
            <CopyContent text={value}>
              <If condition={!record.edasAppId || MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas'}>
                <span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={() => handleClickGoToAppInfo(record)}>{record.edasAppName}</span>
              </If>
              <If condition={record.edasAppId && MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
                <If condition={!!record.edasAppId}>
                  <Events record={record} emitName={`${WIDGET_ID}:go-to-appInfo`}>
                    {record.edasAppName}
                  </Events>
                </If>
              </If>
            </CopyContent>
          </Empty>
        ),
      },
      {
        key: 'instanceNum',
        title: intl('widget.service.instance_number'),
        dataIndex: 'instanceNum',
        cell: value => <Empty value={value}>{value}</Empty>,
      },
    ];
  }
  if (serviceType === 'istio') {
    column = [
      {
        key: 'serviceName',
        title: intl('widget.service.service_name'),
        dataIndex: 'serviceName',
        cell: (value, index, record) => (
          <React.Fragment>
            <If condition={!!value}>
              <CopyContent text={value}>
                <Events record={record}>
                  {record.serviceName}
                </Events>
              </CopyContent>
            </If>
            <If condition={!value}>--</If>
          </React.Fragment>
        ),
      },
      {
        key: 'version',
        title: intl('widget.service.version'),
        dataIndex: 'version',
        cell: value => <Empty value={value}>{value}</Empty>,
      },
      {
        key: 'group',
        title: intl('widget.service.group'),
        dataIndex: 'group',
        cell: value => (
          <Empty value={value}>
            {value}
          </Empty>
        ),
      },
      {
        key: 'edasAppName',
        title: intl('widget.service.app_name'),
        dataIndex: 'edasAppName',
        cell: (value, index, record) => (
          <Empty value={value}>
            <CopyContent text={value}>
              <If condition={!record.edasAppId || MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas'}>
                <span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={() => handleClickGoToAppInfo(record)}>{record.edasAppName}</span>
              </If>
              <If condition={record.edasAppId && MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
                <If condition={!!record.edasAppId}>
                  <Events record={record} emitName={`${WIDGET_ID}:go-to-appInfo`}>
                    {record.edasAppName}
                  </Events>
                </If>
              </If>
            </CopyContent>
          </Empty>
        ),
      },
      {
        key: 'clusterName',
        title: intl('widget.k8s.cluster_name'),
        dataIndex: 'clusterName',
        cell: (value) => (
          <Empty value={value}>
            <CopyContent text={value}>
              {value}
            </CopyContent>
          </Empty>
        ),
      },
      {
        key: 'instanceNum',
        title: intl('widget.service.instance_number'),
        dataIndex: 'instanceNum',
        cell: value => <Empty value={value}>{value}</Empty>,
      },
    ];
  }
  if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && ['springCloud', 'dubbo'].includes(serviceType) && !IS_ENV_PRIVATE && EDAS_CHANNEL_INFO.toLowerCase() !== 'finance') {
    column.push({
      key: 'remark',
      title: intl('widget.common.operating'),
      dataIndex: 'remark',
      cell: (value, index, record) => (
        <span className="link-primary badge-red" onClick={() => handleFetchLink(record)}>{intl('widget.service.pressure_test')}</span>
      ),
    });
  }

  if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && IS_ENV_PRIVATE && columns === 'istio') {
    column.push({
      key: 'operating',
      title: intl('widget.common.operating'),
      dataIndex: 'operating',
      width: 160,
      cell: (value, index, record) => (
        <OperationEvents record={record} />
      ),
    });
  }

  if (!IS_ENV_PRIVATE) {
    column.push({
      key: 'remark',
      title: intl('widget.common.operating'),
      dataIndex: 'remark',
      cell: (value, index, record) => (
        <ServiceTestEvents record={record}>
          {intl('widget.service.test')}
        </ServiceTestEvents>
      ),
    });
  }
  return column;
};

export default (intl, type, handleFetchLink, handleClickGoToAppInfo) => columns(intl, type, handleFetchLink, handleClickGoToAppInfo);
