import React, { useEffect, useState } from 'react';
import { get } from 'lodash';
import { Loading } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import { SPRING_CLOUD, DUBBO } from 'pages/ServiceManage/constants';
import BasicInfo from './components/BasicInfo';
import ServiceRelationShip from './components/Relationships';
import Meta from './components/Meta';
import Interface from './components/Interface';
import SpringCloudInterface from './components/SpringCloudInterface';
import services from 'services';
import { lowerFirstData } from 'utils/transfer-data';
import PropTypes from 'prop-types';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_SHOW_DUBBO_TIMEOUTCONFIG, IS_ENV_PRIVATE } from 'constants';
import TimeoutConfig from './components/TimeoutConfig';

const ServicInfo = (props) => {
  const { value = {} } = props;
  const intl = useIntl();
  const [isLoading, setLoading] = useState(false);
  const [showMore, setShowMore] = useState(false); // 没有权限或报错时，不展示其他数据
  const [basicInfo, setBasicInfo] = useState({});
  const { appId, serviceType, serviceName } = value;

  const SERVICE_TYPE = {
    springCloud: 'Spring Cloud',
    dubbo: 'Dubbo',
    hsf: 'HSF',
    istio: intl('widget.service.service_mesh')
  };

  useEffect(() => {
    fetchBaiscInfo();
  }, []);

  const fetchBaiscInfo = async () => {
    setLoading(true);
    const params = { ...value, region: value.regionId, namespace: value.namespaceId };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'arms') {
      params.version = params.serviceVersion;
      params.group = params.serviceGroup;
      const res = await services.fetchArms({
        data: params,
        params: { action: 'ContainerAction', eventSubmitDoServiceDetail: 1 },
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          setShowMore(false);
          callback();
        }
      });
      const data = lowerFirstData(res) || {};
      setLoading(false);
      setShowMore(true);
      const newBasicInfo = {
        ...data,
        serviceTypeLabel: SERVICE_TYPE[data.serviceType],
      };
      setBasicInfo(newBasicInfo);
      return;
    }
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params.version = params.serviceVersion;
      params.group = params.serviceGroup;
    }
    const res = await services.fetchServiceBasicInfo({
      data: params,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        setShowMore(false);
        callback();
      }
    });
    const data = lowerFirstData(res) || {};
    setLoading(false);
    setShowMore(true);
    const newBasicInfo = {
      ...data,
      serviceTypeLabel: SERVICE_TYPE[data.serviceType],
    };
    setBasicInfo(newBasicInfo);
  };
  const metadata = get(basicInfo, 'metadata', {});
  const methods = get(basicInfo, 'methods', []);

  return (
    <div style={{ paddingBottom: 32 }}>
      <Loading visible={isLoading} style={{ width: '100%' }}>
        <BasicInfo data={{ ...basicInfo, appId, serviceName }} />
      </Loading>
      {/* 子账号权限问题，不能渲染这些数据，但是后端接口没有报错，前端处理 */}
      <If condition={showMore}>
        <ServiceRelationShip value={value} />
        <Loading visible={isLoading} style={{ width: '100%' }}>
          <If condition={serviceType === DUBBO}>
            <h4 className="common-title" style={{ marginTop: 16 }}>{intl('widget.service.metadata_title')}</h4>
            <Interface data={methods} basicInfo={{ ...basicInfo, appId }} />
            <Meta data={metadata} />
          </If>
          <If condition={serviceType === SPRING_CLOUD}>
            <h4 className="common-title" style={{ marginTop: 16 }}>{intl('widget.service.metadata_title')}</h4>
            <SpringCloudInterface data={methods} value={value} basicInfo={{ ...basicInfo, appId }} />
            <Meta data={metadata} />
          </If>
        </Loading>
        <If condition={serviceType === DUBBO}>
          <If condition={(IS_ENV_PRIVATE && IS_SHOW_DUBBO_TIMEOUTCONFIG) || !IS_ENV_PRIVATE}>
            <TimeoutConfig value={value} basicInfo={{ ...basicInfo, appId, regionId: value.regionId, namespaceId: value.namespaceId }} />
          </If>
        </If>
      </If>
    </div>
  );
};

ServicInfo.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
};

export default ServicInfo;
