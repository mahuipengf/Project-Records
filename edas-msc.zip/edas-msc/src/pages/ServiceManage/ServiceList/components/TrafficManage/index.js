import React, { useState, useEffect } from "react";
import SlidePanel from "components/SlidePanel";
import {
  Radio,
  Form,
  Select,
  Input,
  Switch,
  Button,
  Loading,
  Message
} from "@ali/cn-design";
import { Field } from '@alicloud/console-components';
import BalloonForm from "components/BalloonForm";
import QuestionBalloon from "components/QuestionBalloon";
import InlineEdit from "components/InlineEdit";
import Validator from "utils/validator";
import {
  getTrafficPolicies,
  updateTrafficPolicies
} from "services/meshes";
import styles from "./index.less";
import PropTypes from "prop-types";
import { useGlobalState } from '@ali/widget-hooks';

const FormItem = Form.Item;
// const { Option } = Select;
const RadioGroup = Radio.Group;

const isEmpty = value => !value && value !== 0;

const formItemLayout = {
  labelCol: {
    fixedSpan: 10,
  },
  wrapperCol: {
    span: 15,
  },
};
const formItemLayout2 = {
  labelCol: {
    fixedSpan: 9,
  },
};
const list = [
  {
    value: "loadbalance",
    label: "负载均衡",
  },
  {
    value: "session",
    label: "会话保持",
  },
];
const algorithms = [
  {
    label: "轮询调度算法",
    value: "ROUND_ROBIN",
  },
  {
    label: "随机调度算法",
    value: "RANDOM",
  },
  {
    label: "最小连接数算法",
    value: "LEAST_CONN",
  },
];
const sessions = [
  {
    value: 1,
    label: "基于HTTP头部",
  },
  {
    value: 2,
    label: "基于Cookie键",
  },
  {
    value: 3,
    label: "基于源IP",
  },
];
const httpHeaders = [
  {
    value: "Cookie",
    label: "Cookie",
  },
  {
    value: "User-Agent",
    label: "User-Agent",
  },
  {
    value: "自定义",
    label: "自定义",
  },
];
const faultTypes = [
  {
    value: "delay",
    label: "延时故障",
  },
  {
    value: "abort",
    label: "中断故障",
  },
];
const numRangeValidate = (min, max) => {
  let data = {};
  if (min || min === 0) {
    data.min = min;
    data.max = max;
    data.minmaxMessage =
      max || max === 0
        ? `数字范围应该在${min}-${max}之间`
        : `数字不能小于${min}`;
  }
  return data;
};
// 表单提交验证 因为form组件跨标签无法校验数据，因此使用自己写的校验
// 以下是无法被表单自动验证的内容的校验规则
const validateRules = {
  httpHeaderValue: {
    patternMessage:
      "请输入有效的HTTP Header，以字母或数字开头和结尾，可以使用'-','_','.'作为连接符",
    pattern: /^[0-9a-zA-Z][0-9a-zA-Z_.-]*[0-9a-zA-Z]$/,
  },
  lifeCycle: numRangeValidate(0, 86400), // 生命周期
  maxConnections: numRangeValidate(1), //最大连接数
  maxRetries: numRangeValidate(0),
  http1MaxPendingRequests: numRangeValidate(0),
  maxRequestsPerConnection: numRangeValidate(1),
  connectTimeout: numRangeValidate(0),
  http2MaxRequests: numRangeValidate(1),
  consecutiveErrors: numRangeValidate(0),
  maxEjectionPercent: numRangeValidate(0, 100),
  interval: numRangeValidate(0),
  baseEjectionTime: numRangeValidate(0),
  delayPercentage: {
    ...numRangeValidate(0, 100),
    required: values => values ? values.httpFaultMode === "delay" : true,
    requiredMessage: "该字段必填",
  },
  abortPercentage: {
    ...numRangeValidate(0, 100),
    required: values => values ? values.httpFaultMode === "abort" : true,
    requiredMessage: "该字段必填",
  },
  fixedDelay: {
    ...numRangeValidate(0),
    required: values => values ? values.httpFaultMode === "delay" : true,
    requiredMessage: "该字段必填",
  },
  httpStatus: {
    ...numRangeValidate(200, 599),
    required: values => values ? values.httpFaultMode === "abort" : true,
    requiredMessage: "该字段必填",
  },
  httpFaultVersion: {
    required: values => values ? !!values.httpFaultMode && values.httpFaultMode !== "disable" : true,
    requiredMessage: "该字段必填",
  },
};

export default function TrafficManage({ isShowing, onCancel, onCreate, data }) {
  const [type, setType] = useState("loadbalance");
  // const [sessionType, setSessionType] = useState(1); // 1基于HTTP头部 2基于Cookie键 3 基于源IP
  const [error, setError] = useState({}); // 收集错误
  const [detail, setDetail] = useState({}); // 负载均衡详情
  const [submitLoading, setSubmitLoading] = useState(false);
  const [loading, setLoading] = useState(false); // 请求页面数据时的loading
  const [versionList, setVersionList] = useState(null); // 版本列表
  const [httpSelect, setHttpSelect] = useState();
  const [searchValues] = useGlobalState('searchValues');

  const field = Field.useField();
  const validator = new Validator(validateRules);

  useEffect(() => {
    getDetail();
  }, [data]);

  const validateFields = data => {
    const requiredFields = [];

    // 熔断配置
    if (data.enableConnectionPool) {
      if (
        isEmpty(data.maxConnections) &&
        isEmpty(data.maxRetries) &&
        isEmpty(data.http1MaxPendingRequests) &&
        isEmpty(data.connectTimeout) &&
        isEmpty(data.maxRequestsPerConnection) &&
        isEmpty(data.http2MaxRequests)
      ) {
        requiredFields.push("熔断配置")
      }
    }

    // 离群摘除
    if (data.enableOutlierDetection) {
      if (
        isEmpty(data.consecutiveErrors) &&
        isEmpty(data.maxEjectionPercent) &&
        isEmpty(data.interval) &&
        isEmpty(data.baseEjectionTime)
      ) {
        requiredFields.push("离群摘除")
      }
    }

    // 故障注入
    if (data.httpFaultMode == "delay") {
      if (
        isEmpty(data.delayPercentage) &&
        isEmpty(data.fixedDelay)
      ) {
        requiredFields.push("故障注入")
      }
    }

    // 故障注入
    if (data.httpFaultMode == "abort") {
      if (
        isEmpty(data.abortPercentage) &&
        isEmpty(data.httpStatus)
      ) {
        requiredFields.push("故障注入")
      }
    }

    return requiredFields;
  }

  const handleSubmit = async () => {
    const { regionId, namespaceId, serviceType, origin } = searchValues;
    const sendData = {
      trafficPoliciesCreateOrUpdateDTO: {
        serviceMeshId: data.serviceMeshId,
        namespace: data.group,
        serviceName: data.serviceName,
      },
      request: {
        region: regionId,
        namespace: namespaceId,
        serviceType,
        origin: origin,
      }
    };
    field.validate(async (err, data) => {
      if (data.httpSelect !== "自定义") {
        data.httpHeaderValue = data.httpSelect;
      }
      // 校验自定义数据
      let errors = validator.validateAll({ ...detail, ...data });
      if (!err) {

        // 负载均衡与会话二者数据仅存一个
        if (type === "loadbalance") {
          data.dialogueType = null;
          data.cookieName = null;
          data.lifeCycle = null;
        } else {
          data.loadBalancerAlgorithm = null;
        }
        if (!errors) {
          const requiredFields = validateFields({ ...detail, ...data });
          if (requiredFields && requiredFields.length) {
            Message.error({
              content: `${requiredFields}被启用，请填充${requiredFields}相关配置项，或者关闭开关`,
              duration: 2000
            });
            return;
          }
          setSubmitLoading(true);
          try {
            const result = await updateTrafficPolicies({
              ...sendData,
              trafficPoliciesCreateOrUpdateDTO: {
                ...sendData.trafficPoliciesCreateOrUpdateDTO,
                ...detail,
                ...data,
                enable: true
              }
            });
            onCreate && onCreate();
          } finally {
            setSubmitLoading(false);
          }
        } else {
          setError(errors);
        }
      } else {
        setError({ ...err, ...(errors || {}) });
      }
    });
  };

  const getDetail = async () => {
    const { regionId, namespaceId, serviceType, origin } = searchValues;
    const sendData = {
      serviceMeshId: data.serviceMeshId,
      k8snamespace: data.group,
      serviceName: data.serviceName,
      region: regionId,
      namespace: namespaceId,
      serviceType,
      origin: origin,
    };

    setLoading(true);
    // 获取流量管理相关信息
    {
      const data = await getTrafficPolicies(sendData);
      setLoading(false);
      // 设置流量调度机制
      if (data.dialogueType) {
        setType("session");
      } else {
        data.dialogueType = 1;
        setType("loadbalance");
      }
      setHttpSelect(
        data.httpHeaderValue === 'Cookie'
          ? 'Cookie'
          : data.httpHeaderValue === 'User-Agent'
            ? 'User-Agent'
            : '自定义'
      );
      setDetail(data);
    }
    // field.setValues(data);
  };

  const onChange = (value) => {
    setHttpSelect(value);
    if (value === "自定义") {
      setDetail({
        ...detail,
        httpHeaderValue: "自定义",
      });
    }
  };
  const onNormalChange = (value, type) => {
    switch (type) {
      case "type":
        setType(value);
        break;
      case "dialogueType":
        // setSessionType(value);
        setDetail({ ...detail, dialogueType: value });
        break;
      case "httpFaultMode":
        const {
          delayPercentage,
          abortPercentage,
          fixedDelay,
          httpStatus,
          httpFaultVersion,
          ...restErrors
        } = error;
        setError(restErrors);
        if (value === "disable") {
          field.remove(["delayPercentage", "abortPercentage", "fixedDelay", "httpStatus", "httpFaultVersion"])
        }
        setDetail({
          ...detail,
          httpFaultMode: value,
          enable: value === "disable" ? detail.enable : true,
        });
        break;
      default:
        break;
    }
  };
  const onSwitchChange = (checked, type) => {
    setDetail({
      ...detail,
      [`${type}`]: checked,
      enable: checked ? true : detail.enable,
    });
  };
  const onAllSwitchChange = (checked) => {
    if (!checked) {
      let switchStatus = {
        enableConnectionPool: checked,
        enableOutlierDetection: checked,
        enableAuthorizationPolicy: checked,
        faultInjection: checked,
        tlsMode: "DISABLE",
        httpFaultMode: "disable",
        enable: checked,
      };
      setDetail({ ...detail, ...switchStatus });
    } else {
      setDetail({ ...detail, enable: checked });
    }
  };

  const onConfirm = (value, item = {}) => {
    console.log(value);
    console.log(item);
    if (item.name) {
      delete error[item.name];
      let err = validator.validate(item.name, value);
      console.log(err);
      if (err) {
        setError(err);
      } else {
        delete error[item.name];
        setError(error);
      }
    }
    field.setValue(item.name, value);
    console.log(field.getValues());
  };

  return (
    <SlidePanel
      top={50}
      title="流量治理策略"
      isShowing={isShowing}
      width="medium"
      onMaskClick={onCancel}
      onSlideCompleted={() => {
        console.log("completed");
      }}
      onClose={onCancel}
      customFooter={
        <div className={styles["flow-footer-content"]}>
          <div className={styles["flow-footer-button"]}>
            <Button
              className={styles["flow-button"]}
              onClick={handleSubmit}
              type="primary"
              loading={submitLoading}
            >
              确定
            </Button>
            <Button
              className={styles["flow-button"]}
              onClick={onCancel}
              type="normal"
            >
              取消
            </Button>
          </div>
          {/* <div className={styles["flow-footer-switch"]}>
            <div className={styles["footer-switch-label"]}>流量治理</div>
            <FormItem className={styles["no-bottom"]} size="small">
              <Switch
                onChange={onAllSwitchChange}
                name="enable"
                size="small"
                checked={detail.enable}
              />
            </FormItem>
          </div> */}
        </div>
      }
    >
      <Loading visible={loading}>
        <Form
          {...formItemLayout}
          field={field}
          className={styles["governance"]}
        >
          <div className={styles["service-governance-box"]}>
            <div className={styles["service-governance-title-box"]}>
              <span className={styles["service-governance-title"]}>
                流量调度机制
              </span>
              <RadioGroup
                dataSource={list}
                shape="button"
                size="medium"
                value={type}
                onChange={(value) => onNormalChange(value, "type")}
              />
            </div>
            {type === "loadbalance" && (
              <FormItem
                label="负载均衡算法"
                {...formItemLayout}
                className={styles["no-bottom"]}
              >
                <Select
                  style={{ width: "100%" }}
                  onChange={(value) =>
                    setDetail({
                      ...detail,
                      loadBalancerAlgorithm: value,
                    })
                  }
                  name="loadBalancerAlgorithm"
                  dataSource={algorithms}
                  value={detail.loadBalancerAlgorithm || algorithms[0].value}
                  placeholder="请选择"
                ></Select>
              </FormItem>
            )}
            {type === "session" && (
              <>
                <FormItem className={styles["no-bottom"]}>
                  <RadioGroup
                    // className="session-radio-box"
                    dataSource={sessions}
                    value={detail.dialogueType || sessions[0].value}
                    name="dialogueType"
                    onChange={(value) => onNormalChange(value, "dialogueType")}
                  />
                </FormItem>

                {detail.dialogueType === 1 && (
                  <>
                    <div className="form-zero-margin">
                      <FormItem
                        className="no-bottom"
                        label={
                          <QuestionBalloon
                            title="基于http头部"
                            content="根据设定的请求头来计算哈希值，相同的值会转发到同一实例中"
                          />
                        }
                        {...formItemLayout}
                      >
                        <Select
                          style={{ width: "100%" }}
                          onChange={(v) => onChange(v)}
                          name="httpSelect"
                          dataSource={httpHeaders}
                          defaultValue={httpHeaders[0].value}
                          value={httpSelect}
                        ></Select>
                      </FormItem>
                    </div>
                    {httpSelect === "自定义" && (
                      <div className="http-box">
                        <FormItem className="no-bottom">
                          <InlineEdit
                            defaultValue={detail.httpHeaderValue}
                            error={error.httpHeaderValue}
                            onConfirm={onConfirm}
                            name="httpHeaderValue"
                          />
                        </FormItem>
                      </div>
                    )}
                  </>
                )}
                {/* 基于Cookie键 */}
                {detail.dialogueType === 2 && (
                  <FormItem className="no-bottom">
                    <FormItem
                      className="no-bottom"
                      label={
                        <QuestionBalloon
                          title="Cookie键名称"
                          content="填入具体cookie字段的key后，相同value的请求会转发到同一实例中"
                        />
                      }
                      {...formItemLayout}
                      required
                      asterisk={false}
                      requiredMessage="该字段必填"
                    >
                      <InlineEdit
                        defaultValue={detail.cookieName}
                        onConfirm={onConfirm}
                        style={{ width: 120 }}
                        name="cookieName"
                      />
                    </FormItem>
                    <FormItem
                      label="生命周期(s)"
                      {...formItemLayout}
                      className="no-bottom"
                      required
                      asterisk={false}
                      requiredMessage="该字段必填"
                    >
                      <InlineEdit
                        defaultValue={detail.lifeCycle}
                        style={{ width: 120 }}
                        min={1}
                        max={86400}
                        error={error.lifeCycle}
                        onConfirm={onConfirm}
                        htmlType="number"
                        name="lifeCycle"
                      />
                    </FormItem>
                  </FormItem>
                )}
                {detail.dialogueType === 3 && (
                  <div className="session-ip-text">
                    流量将会按照请求源IP地址的哈希值进行会话保持。
                  </div>
                )}
              </>
            )}
          </div>
          <div className={styles["other-content-box"]}>
            <div className={styles["connect-pool-box"]}>
              <div className={styles["connect-pool-label"]}>熔断配置</div>
              <div className={styles["connect-pool-content"]}>
                <div className={styles["switch-label"]}>
                  {detail.enableConnectionPool ? "已开启" : "已关闭"}
                </div>
                <FormItem className={styles["no-bottom"]} size="small">
                  <Switch
                    onChange={(c) => onSwitchChange(c, "enableConnectionPool")}
                    checked={detail.enableConnectionPool}
                    name="enableConnectionPool"
                    size="small"
                  />
                </FormItem>
              </div>
            </div>
            {detail.enableConnectionPool && (
              <div className={styles["in-content-box"]}>
                <div className={styles["small-content-box"]}>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="最大连接数(个)"
                        content="指向目标地址的最大连接数（http1/tcp），默认为2^32-1"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.maxConnections}
                      onConfirm={onConfirm}
                      min={0}
                      error={error.maxConnections}
                      htmlType="number"
                      name="maxConnections"
                    />
                  </FormItem>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="最大请求重试次数(次)"
                        content="在集群内在限定时间内对外http访问的最大重试次数，默认为2^32-1"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.maxRetries}
                      onConfirm={onConfirm}
                      min={0}
                      error={error.maxRetries}
                      htmlType="number"
                      name="maxRetries"
                    />
                  </FormItem>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="最大等待请求数(个)"
                        content="连接目标地址的最大pending http请求数，默认为2^32-1"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.http1MaxPendingRequests}
                      min={0}
                      onConfirm={onConfirm}
                      error={error.http1MaxPendingRequests}
                      htmlType="number"
                      name="http1MaxPendingRequests"
                    />
                  </FormItem>
                </div>
                <div className={styles["small-content-box"]}>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="TCP连接超时(ms)"
                        content="tcp连接超时时间，单位为ms, 默认为10s"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.connectTimeout}
                      onConfirm={onConfirm}
                      error={error.connectTimeout}
                      // inline="small"
                      min={0}
                      name="connectTimeout"
                      htmlType="number"
                    />
                  </FormItem>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="每连接最大请求数(个)"
                        content="每个连接的最大http请求数，设置为1，代表禁用keep alive，默认为0，代表没有限制； http2连接池使用单个连接下多路复用多个请求，所以才会有最大请求数的配置"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.maxRequestsPerConnection}
                      min={0}
                      error={error.maxRequestsPerConnection}
                      onConfirm={onConfirm}
                      htmlType="number"
                      name="maxRequestsPerConnection"
                    />
                  </FormItem>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="HTTP2最大请求数(个)"
                        content="目标地址的最大请求数，默认值为2^32-1"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.http2MaxRequests}
                      error={error.http2MaxRequests}
                      onConfirm={onConfirm}
                      min={0}
                      htmlType="number"
                      name="http2MaxRequests"
                    />
                  </FormItem>
                </div>
              </div>
            )}
          </div>
          <div className={styles["other-content-box"]}>
            <div className={styles["connect-pool-box"]}>
              <div className={styles["connect-pool-label"]}>离群摘除</div>
              <div className={styles["connect-pool-content"]}>
                <div className={styles["switch-label"]}>
                  {detail.enableOutlierDetection ? "已开启" : "已关闭"}
                </div>
                <FormItem className={styles["no-bottom"]} size="small">
                  <Switch
                    onChange={(v) =>
                      onSwitchChange(v, "enableOutlierDetection")
                    }
                    checked={detail.enableOutlierDetection}
                    name="enableOutlierDetection"
                    size="small"
                  />
                </FormItem>
              </div>
            </div>
            {detail.enableOutlierDetection && (
              <div className={styles["in-content-box"]}>
                <div className={styles["small-content-box"]}>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="连续错误数(次)"
                        content="连续5XX错误响应的数量,例如设定为2,则在一个周期内收到连续2个以上5xx错误则会触发熔断"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.consecutiveErrors}
                      error={error.consecutiveErrors}
                      onConfirm={onConfirm}
                      min={0}
                      htmlType="number"
                      name="consecutiveErrors"
                    />
                  </FormItem>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="最大隔离实例比例(%)"
                        content="上游实例允许被隔离的最大比例,计算方式为向上取整,例如10个实例,隔离比例设为11%,则最多隔离2个实例"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.maxEjectionPercent}
                      error={error.maxEjectionPercent}
                      onConfirm={onConfirm}
                      min={0}
                      max={100}
                      htmlType="number"
                      name="maxEjectionPercent"
                    />
                  </FormItem>
                </div>
                <div className={styles["small-content-box"]}>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="检查周期"
                        content="两次健康检查的间隔时间，如 5s、10s"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.interval}
                      onConfirm={onConfirm}
                      error={error.interval}
                      min={0}
                      htmlType="number"
                      name="interval"
                    />
                  </FormItem>
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="最短隔离时间(s)"
                        content="实例第一次被隔离的时间，之后每次隔离时间为隔离次数与最短隔离时间的乘积"
                      />
                    }
                  >
                    <InlineEdit
                      defaultValue={detail.baseEjectionTime}
                      error={error.baseEjectionTime}
                      onConfirm={onConfirm}
                      min={0}
                      htmlType="number"
                      name="baseEjectionTime"
                    />
                  </FormItem>
                </div>
              </div>
            )}
          </div>
          {/* <div className="other-content-box">
					<div className="connect-pool-box">
						<div className="connect-pool-label">Mutual TLS</div>
						<div className="connect-pool-content">
							<div className="switch-label">
								{detail.tlsMode === 'ISTIO_MUTUAL'
									? '已开启'
									: '已关闭'}
							</div>
							<FormItem className="no-bottom" size="small">
								<Switch
									onChange={(c) =>
										onSwitchChange(c, 'tlsMode')
									}
									checked={
										detail.tlsMode === true ||
										detail.tlsMode === 'ISTIO_MUTUAL'
									}
									name="tlsMode"
									size="small"
								/>
							</FormItem>
						</div>
					</div>
					<div className="tls-text">
						开启Mutual
						TLS功能，组件仅会通过基于TLS建立的安全信道通信
					</div>
				</div> */}
          <div className={styles["other-content-box"]}>
            <div className={styles["connect-pool-box"]}>
              <div className={styles["connect-pool-label"]}>故障注入</div>
              <div className={styles["connect-pool-content"]}>
                <div className={styles["switch-label"]}>
                  {detail.httpFaultMode && detail.httpFaultMode !== "disable" ? "已开启" : "已关闭"}
                </div>
                <FormItem className={styles["no-bottom"]} size="small">
                  <Switch
                    checked={
                      detail.httpFaultMode && detail.httpFaultMode !== "disable"
                    }
                    onChange={(c) => {
                      onNormalChange(c ? "delay" : "disable", "httpFaultMode");
                    }}
                  />
                </FormItem>
              </div>
            </div>
            <div className={styles["tls-text"]}>
              当前故障注入功能暂不支持基于流量比例的灰度发布
            </div>
            {detail.httpFaultMode && detail.httpFaultMode !== "disable" && (
              <div className={styles["form-zero-margin"]}>
                <FormItem
                  {...formItemLayout2}
                  label="故障版本"
                  required
                  requiredMessage="该字段必填"
                >
                  <InlineEdit
                    defaultValue={detail.httpFaultVersion}
                    error={error.httpFaultVersion}
                    onConfirm={onConfirm}
                    name={"httpFaultVersion"}
                  />
                  {/* <span className={styles["cookie-content-box"]}>
                    {detail.httpFaultVersion}
                  </span>
                  <BalloonForm
                    closable={false}
                    trigger={
                      <span
                        style={{
                          color: "#0064C8",
                          cursor: "pointer",
                        }}
                      >
                        修改
                      </span>
                    }
                    onConfirm={(data) => {
                      setDetail({
                        ...detail,
                        ...data,
                      });
                    }}
                  >
                    <FormItem label="" required requiredMessage="请选择">
                      <Input
                        style={{ width: "240px" }}
                        placeholder="请输入版本"
                        name="httpFaultVersion"
                        defaultValue={detail.httpFaultVersion}
                      />
                    </FormItem>
                  </BalloonForm> */}
                </FormItem>
                <FormItem {...formItemLayout2} label="故障类型">
                  <RadioGroup
                    dataSource={faultTypes}
                    value={detail.httpFaultMode}
                    name="httpFaultMode"
                    onChange={(value) => onNormalChange(value, "httpFaultMode")}
                  />
                </FormItem>
                {detail.httpFaultMode == "delay" && (
                  <FormItem
                    {...formItemLayout2}
                    label="故障百分比(%)"
                    required
                    requiredMessage="该字段必填"
                  >
                    <InlineEdit
                      defaultValue={detail.delayPercentage}
                      min={0}
                      max={100}
                      error={error.delayPercentage}
                      onConfirm={onConfirm}
                      name={"delayPercentage"}
                      htmlType="number"
                    />
                  </FormItem>
                )}
                {detail.httpFaultMode == "abort" && (
                  <FormItem
                    {...formItemLayout2}
                    label="故障百分比(%)"
                    required
                    requiredMessage="该字段必填"
                  >
                    <InlineEdit
                      defaultValue={detail.abortPercentage}
                      min={0}
                      max={100}
                      error={error.abortPercentage}
                      onConfirm={onConfirm}
                      name={"abortPercentage"}
                      htmlType="number"
                    />
                  </FormItem>
                )}

                {/* 延迟 */}
                {detail.httpFaultMode === "delay" && (
                  <FormItem
                    {...formItemLayout2}
                    label={
                      <QuestionBalloon
                        title="延时(s)"
                        content="设定延时时间，单位为秒，请输入正整数例如1,2,3等"
                      />
                    }
                    required
                    requiredMessage="该字段必填"
                  // asterisk={false}
                  >
                    <InlineEdit
                      defaultValue={detail.fixedDelay}
                      onConfirm={onConfirm}
                      error={error.fixedDelay}
                      min={0}
                      name="fixedDelay"
                      htmlType="number"
                    />
                  </FormItem>
                )}
                {/* 中断 */}
                {detail.httpFaultMode === "abort" && (
                  <FormItem
                    {...formItemLayout2}
                    label="Http状态码"
                    required
                    requiredMessage="该字段必填"
                  // asterisk={false}
                  >
                    <InlineEdit
                      defaultValue={detail.httpStatus}
                      onConfirm={onConfirm}
                      error={error.httpStatus}
                      htmlType="number"
                      name="httpStatus"
                      min={200}
                      max={599}
                    />
                  </FormItem>
                )}
              </div>
            )}
          </div>
        </Form>
      </Loading>
    </SlidePanel>
  );
}

TrafficManage.propTypes = {
  isShowing: PropTypes.bool,
  data: PropTypes.object,
  onCancel: PropTypes.func,
  onCreate: PropTypes.func,
};
