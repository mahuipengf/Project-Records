import React, { useEffect, useState } from 'react';
import services from 'services';
import PropTypes from 'prop-types';
import { find, map } from 'lodash';
import { Select } from '@ali/cn-design';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { lowerFirstData } from 'utils/transfer-data';

const MySelect = (props) => {
  const { onChange } = props;
  const [searchValues] = useGlobalState('searchValues');
  const { regionId, namespaceId } = searchValues;
  const [appList, setAppList] = useState([]);

  const intl = useIntl();

  useEffect(() => {
    fetchAppList({ regionId, namespaceId, pageNumber: 1, pageSize: 100 });
  }, []);

  const dataSource = [
    { label: intl('widget.service.all_app'), value: '', fillProps: '' },
    ...appList
  ];
  const handleChange = (val) => {
    const findObj = find(dataSource, (item) => item.value === val);
    onChange(val, findObj);
  };
  const fetchAppList = async ({ regionId: RegionId, pageNumber, pageSize, appName }) => {
    // 这个是分页接口，但是需要拿到全部数据
    const res = await services.GetAppList({
      params: { regionId: RegionId, pageNumber, pageSize, appName }
    });
    const { result = [] } = lowerFirstData(res) || {};
    const newData = map(result, item => ({
      ...item,
      key: item.appId,
      value: item.appId,
      label: item.appName,
      fillProps: item.appName,
    }));
    setAppList(newData);
  };
  const handleSearch = (val) => {
    fetchAppList({ regionId, namespaceId, pageNumber: 1, pageSize: 100, appName: val });
  };
  return (
    <React.Fragment>
      <Select
        showSearch
        onChange={handleChange}
        dataSource={dataSource}
        style={{ width: 200 }}
        onSearch={handleSearch}
        filterLocal={false}
      />
    </React.Fragment>
  );
};

MySelect.propTypes = {
  onChange: PropTypes.func,
};

export default MySelect;
