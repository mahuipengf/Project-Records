const SPRING_CLOUD = 'springCloud';
const DUBBO = 'dubbo';
const HSF = 'hsf';

const AGENT = 'agent';
const REGISTRY = 'registry';

const SERVICE_TYPE = {
  springCloud: 'Spring Cloud',
  dubbo: 'Dubbo',
  hsf: 'HSF',
};

const IP_PATTERN = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

export {
  SPRING_CLOUD,
  DUBBO,
  HSF,
  AGENT,
  REGISTRY,
  SERVICE_TYPE,
  IP_PATTERN,
};
