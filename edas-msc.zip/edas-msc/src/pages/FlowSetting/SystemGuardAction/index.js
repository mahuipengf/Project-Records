import ActionRulesDialog from '../../App/AppDetail/components/common/ActionRulesDialog';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import styles from './index.less';
import { ACTION_MODULE_TYPE } from '../../App/AppDetail/components/common/config/constants/flow';
import { Balloon, Button, Dialog, Icon, Input, Message, Radio, Select, Table } from '@alicloud/console-components';
// import { IwebActionRules } from 'config/interfaces/flowProtection';
import { contentTextOfBehaviorDesc } from 'utils/util';
import { getParams } from 'utils';
// import { useDispatch } from '@ali/sre-utils-dva';
import services from 'services';
import Cookie from 'js-cookie';

const Option = Select.Option;
const { Group: RadioGroup } = Radio;

const SystemGuardAction = () => {
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  // const dispatch = useDispatch();
  const containerRef = useRef(null);
  const [ isLoading, setIsLoading ] = useState(false);
  const [ webActionRules, setWebActionRules ] = useState([]);// 行为列表数据
  const [ seleId, setSeleId ] = useState(0);
  const [ editItem, setEditItem ] = useState({});
  const [ visible, setVisible ] = useState(false);
  const [ bindName, setBindName ] = useState('');
  const [ bindType, setBindType ] = useState(1);

  useEffect(() => {
    fetchData();
  }, []);

  // 请求行为列表
  const fetchData = useCallback(async () => {
    setIsLoading(true);
    const params = {
      AppName: appName,
      ClassificationSet: '[1,2]',
      namespace: 'default',
      RegionId: region,
      AhasRegionId: region,
      Namespace: 'default',
      NameSpace: 'default',
      SourceType: 'MSE',
    };
    const result = await services.ListSentinelBlockFallbackDefinitions({params});
    if (result?.length) {
      result.forEach(item => {
        const { TargetMap } = item;
        if (TargetMap) {
          item.AssociatedResources = Object.keys(TargetMap).length;
        } else {
          item.AssociatedResources = 0;
        }
      });
      setWebActionRules(result);
    }
    setIsLoading(false);
  }, [ isLoading, webActionRules ]);

  // 渲染行为描述
  function renderBehaviorDesc(value, index, record) {
    const { ResourceClassification = 1, FallbackBehavior } = record;
    record.resourceClassification = ResourceClassification;
    record.fallbackBehavior = FallbackBehavior;

    return (
      <Balloon
        trigger={
          <div className={styles['contentText']}>
            {contentTextOfBehaviorDesc(record)}
          </div>
        }
        closable={false}
        align='t'
      >
        {contentTextOfBehaviorDesc(record)}
      </Balloon>
    );
  }

  // 渲染操作
  function renderOpt(value, index, record) {
    return (
      <div className={styles['flowOpt']}>
        <span onClick={() => handleAddActionRules(record)}>
          <Icon type="edit" size="xs" /> &nbsp;
          <span>{'修改'}</span>
        </span>
        ｜
        <span onClick={() => handleDelAction(value, record)}>
          <Icon type="ashbin1" size="xs" /> &nbsp;
          <span>{'删除'}</span>
        </span>
      </div>
    );
  }

  // 删除行为确认弹窗
  function handleDelAction(id, record) {
    const { Name, TargetMap = [] } = record;
    const associatedResources = Object.keys(TargetMap).length;
    Dialog.confirm({
      title: '温馨提示',
      content: (
        <>
          <p>
            <span>
              {'您确定要删除该行为: '}
              <span style={{ color: '#0070cc' }}>{Name}</span>
              {' 吗？'}
            </span>
          </p>
          <p>
            <span>
              {'当前行为关联资源数: '}
              <span style={{ color: '#0070cc' }}>{associatedResources}</span>
              {'，删除该行为后这些资源触发规则后会采用默认处理行为。'}
            </span>
          </p>
        </>

      ),
      onOk: () => onDelAction(id),
    });
  }

  // 删除行为请求
  async function onDelAction(id) {
    const Data = await services.DeleteSentinelBlockFallbackDefinition({ params: {Id: id} });
    if (Data) {
      Message.success('删除成功');
      fetchData();
    } else {
      Message.error('删除失败，请重试');
    }
  }

  // 新增、编辑行为弹窗
  function handleAddActionRules(record) {
    setEditItem(record);
    if (containerRef.current.handleActionDialogChange) {
      containerRef.current.handleActionDialogChange();
    }
  }

  // 选择绑定接口
  function onSeleIdChange(id) {
    setSeleId(id);
  }

  // 绑定行为
  async function onBindAction() {
    if (!bindName) {
      Message.warning('请输入绑定接口名称');
      return;
    }
    if (!seleId) {
      Message.warning('请选择绑定行为名称');
      return;
    }
    const { Success = false, Message: msg = '' } = await dispatch.flowAppModel.queryBindSentinelBlockFallbackDefinition({
      AppName: appName,
      FallbackId: seleId,
      Resource: bindName,
      TargetType: bindType,
    });

    if (Success) {
      Message.success('绑定成功');
    } else {
      Message.error(msg);
    }
    onBindDialogVisible();
  }

  // 弹窗状态
  function onBindDialogVisible() {
    visible && setSeleId(0);
    setVisible(!visible);
  }

  // 输入绑定接口名称
  function onBindApiNameChange(val) {
    setBindName(val);
  }

  // 绑定类型改变
  function onBindTypeChange(type) {
    setBindType(type);
  }

  return (
    <div className={styles['content']}>
      <div className={styles['addActionBtn']}>
        <Button
          type={'primary'}
          onClick={() => handleAddActionRules()}
        >新增行为</Button>
        {false && <Button
          type={'primary'}
          onClick={() => onBindDialogVisible()}
        >绑定规则</Button>}
      </div>
      <div className={styles['list']}>
        <Table
          dataSource={webActionRules}
          loading={isLoading}
          hasBorder={false}
        >
          <Table.Column
            title="行为名称"
            dataIndex="Name"
            align={'center'}
          />
          <Table.Column
            title="针对资源类型"
            dataIndex="ResourceClassification"
            align={'center'}
            cell={type => ACTION_MODULE_TYPE[type]}
          />
          <Table.Column
            title="行为描述"
            dataIndex="FallbackBehavior"
            align={'center'}
            width={350}
            cell={renderBehaviorDesc}
          />
          <Table.Column
            title="关联资源数"
            dataIndex="AssociatedResources"
            align={'center'}
          />
          <Table.Column dataIndex="Id" title="操作" align={'center'} cell={renderOpt} />
        </Table>
      </div>
      {/* 新增行为 */}
      <ActionRulesDialog
        wrapRef={containerRef}
        record={editItem}
        fetchData={fetchData}
      />
      {/* 绑定行为 */}
      <Dialog
        title='绑定自定义限流行为'
        visible={visible}
        onOk={onBindAction}
        onCancel={onBindDialogVisible}
        onClose={onBindDialogVisible}
      >
        <ul className={styles['bindApiBox']}>
          <li>
            <span>绑定类型</span>
            <RadioGroup value={bindType} onChange={onBindTypeChange}>
              <Radio id="limiting" value={1}>限流</Radio>
              <Radio id="fuse" value={2}>熔断</Radio>
              <Radio id="system" value={3}>系统保护</Radio>
              <Radio id="hotspot" value={4}>热点参数</Radio>
            </RadioGroup>
          </li>
          <li>
            <span>绑定接口</span>
            <Input
              placeholder='请输入绑定接口名称'
              value={bindName}
              onChange={onBindApiNameChange}
            />
          </li>
          <li>
            <span>绑定行为</span>
            <Select
              value={seleId || ''}
              onChange={onSeleIdChange}
              placeholder={'请选择绑定行为名称'}
            >
              {!!webActionRules?.length && webActionRules.map(item => {
                return <Option key={item.Id} value={item.Id}>{item.Name}</Option>;
              })}
            </Select>
          </li>
        </ul>
      </Dialog>
    </div>
  );
};

export default SystemGuardAction;
