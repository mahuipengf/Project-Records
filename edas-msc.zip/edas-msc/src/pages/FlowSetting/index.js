import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useIntl } from '@ali/widget-hooks';
import styles from './index.less';
import { Tab } from '@alicloud/console-components';
import { removeParams } from '@ali/sre-utils';
import { getParams, setParams } from 'utils';
import { useHistory } from 'dva';
import services from 'services';
import SystemGuardBasic from './SystemGuardBasic';
import SystemGuardAction from './SystemGuardAction';
import SystemGuardClusterProtection from './SystemGuardClusterProtection';

const FlowSetting = () => {
  const history = useHistory();
  const intl = useIntl();
  const activeType = getParams('activeType') || 'base';
  const appName = getParams('appName') || 'spring-cloud-a';
  const [ tabIdx, setTabIdx ] = useState(activeType || 'base');
  console.log('getparamsActiveType', getParams('activeType'), activeType);


  // 规则Tab切换
  function handleTab(key) {
    setParams('activeType', String(key));
    removeParams('searchKey');
    setTabIdx(String(key));
  }

  return (
    <div className={styles['rulesTabContent']}>
      <Tab
        onChange={key => handleTab(key)}
        shape={'wrapped'}
        activeKey={tabIdx}
        className={styles['tabOfStyle']}
      >
        <Tab.Item
          title='基础设置' //基础设置
          key='base'
          style={{ background: '#FFF' }}
        >
          {tabIdx === 'base' ? <div><SystemGuardBasic
            ahasStatus={''}
          /></div> : <div></div>}
        </Tab.Item>
        <Tab.Item
          title={'行为管理'} // 行为管理
          key='behavior'
          style={{ background: '#FFF' }}
        >
          {tabIdx === 'behavior' ? <div><SystemGuardAction /></div> : <div></div>}
        </Tab.Item>
        <Tab.Item
          title={'集群流控'} // 集群流控
          key='flow'
          style={{ background: '#FFF' }}
        >
          {tabIdx === 'flow' ? <div><SystemGuardClusterProtection
            pageType={'guardApp'}
          /></div> : <div></div>}
        </Tab.Item>
      </Tab>
    </div>
  );
};

// FlowSetting.propTypes = {
//   rowSelection: PropTypes.shape(),
//   selectionProps: PropTypes.func,
//   tableUniqueKey: PropTypes.string,
// };

export default FlowSetting;
