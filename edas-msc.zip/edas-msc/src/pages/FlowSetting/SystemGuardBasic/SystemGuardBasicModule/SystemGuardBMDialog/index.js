import JSONEditor from 'components/JsonEditor';
import React, { memo, useCallback, useEffect, useMemo, useState } from 'react';
import styles from './index.less';
import { Button, Field, Form, Input, Message, Radio } from '@alicloud/console-components';
import { JUMP_URL_NOT_EMPTY, OPERATION_FAILED, STATUS_CODE_NOT_EMPTY, SUCCESS_MSG } from '../../../../App/AppDetail/components/common/config/constants/flow';
import { compare } from 'utils/util';
import services from 'services';
import Cookie from 'js-cookie';
import { useIntl } from '@ali/widget-hooks';

const { Group: RadioGroup } = Radio;

const SystemGuardBMDialog = memo(({ record, onCloseDialog, onChange, appName }) => {
  const intl = useIntl();
  const fixedSDKVersion = intl('ahas_sentinel.SystemGuardPreview.appNewVersion');
  // const disPatch = useDispatch();
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const myfield = Field.useField();
  const { init, getValue } = myfield;
  const [ dataType, setDataType ] = useState(0); // 返回 content-type，策略=0 出现且必填。取值 0=text，1=JSON
  const [ dataArea, setDataArea ] = useState('');
  const [ jsonErrors, setJsonErrors ] = useState([]);
  // const appVersion = useSelector(({ flowAppModel }) => flowAppModel.appVersion);
  const [ appVersion, setAppVersion ] = useState(true);
  const [ version, setVersion ] = useState(false);

  const [ formItemLayout ] = useState({
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  });

  useEffect(() => {
    // 版本号
    if (appVersion) {
      const { JAVA_SDK } = appVersion;
      if ((JAVA_SDK && !compare(JAVA_SDK, fixedSDKVersion))) {
        setVersion(true);
      }
    }
  }, []);

  useEffect(() => {
    const { AppName: webFlowAppName = '', WebRespContentType = 0, WebRespMessage = '' } = record;

    if (webFlowAppName) {
      myfield.setValue('webFallbackMode', record.WebFallbackMode);
      myfield.setValue('webRespStatusCode', record.WebRespStatusCode);
      myfield.setValue('webRedirectUrl', record.WebRedirectUrl);
      setDataType(WebRespContentType);
      setDataArea(WebRespMessage);
    } else {
      myfield.setValue('webFallbackMode', 0);
      myfield.setValue('webRespStatusCode', '');
      myfield.setValue('webRedirectUrl', '');
      setDataType(0);
      setDataArea('');
    }
  }, []);

  const fetchUpdateData = useCallback(async (submitData) => {
    const result = await services.SentinelUpdateAdapterSettingOfApp({
      params: {
        ...submitData,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    if (result) {
      Message.success({
        content: SUCCESS_MSG(intl),
        animation: false,
        style: { marginTop: '50px' },
      });

      onCloseDialog();
      onChange();
    } else {
      Message.error({
        content: msg,
        animation: false,
        style: { marginTop: '50px' },
      });
    }
  }, [ onCloseDialog, onChange ]);

  const handleAddWebFlowRule = useCallback(() => {
    let isValid = false;

    myfield.validate((errors, values) => {
      const { webRespStatusCode = '', webRedirectUrl = '', webFallbackMode = 0 } = values;
      if (webFallbackMode && !webRedirectUrl) {
        Message.warning({
          content: JUMP_URL_NOT_EMPTY(intl),
          animation: false,
          style: { marginTop: '50px' },
        });
      } else if (!webFallbackMode && !webRespStatusCode) {
        Message.warning({
          content: STATUS_CODE_NOT_EMPTY(intl),
          animation: false,
          style: { marginTop: '50px' },
        });
      } else {
        isValid = true;
      }
    });

    if (getValue('webFallbackMode') === 0 && !dataArea) {
      Message.warning('HTTP 返回文本不可为空');
      return;
    }

    if (getValue('webFallbackMode') === 0 && dataArea && jsonErrors.length) {
      Message.warning(dataType === 0 ? '文本数据格式错误，请检查文本数据格式并重新输入' : 'JSON 数据格式错误，请检查 JSON 数据格式并重新输入');
      return;
    }

    if (isValid) {
      const submitData = {
        AppName: appName,
        WebFallbackMode: getValue('webFallbackMode'),
        WebRespStatusCode: getValue('webRespStatusCode'),
        WebRedirectUrl: getValue('webRedirectUrl'),
        WebRespContentType: dataType,
        WebRespMessage: dataArea,
      };
      fetchUpdateData(submitData);
    }
  }, [ fetchUpdateData, dataType, dataArea, jsonErrors ]);

  const renderFooter = useMemo(() => {
    return (
      <span className={styles['footer']}>
        <Button
          onClick={handleAddWebFlowRule}
          type={'primary'}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_add"
        >
          {'确定'}
        </Button>

        <Button
          onClick={onCloseDialog}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_cancel"
        >
          {'取消'}
        </Button>
      </span>
    );
  }, [ handleAddWebFlowRule, onCloseDialog ]);

  // 数据格式改变
  function handleDataTypeChange(type) {
    setDataType(Number(type));
  }

  // HTTP 返回文本内容改变
  function handleContentTypeChange(val) {
    setDataArea(val);
  }

  // json文案错误验证
  function onValidationError(errors) {
    setJsonErrors(errors);
  }

  return (
    <div className={styles['content']}>
      {version && (
        <Message style={{ marginBottom: '8px' }} type="warning">
          <span>
            {'SDK/agent <= 1.8.4 时 content-type 及返回内容配置不生效，旧版本仅支持返回默认内容。'}
          </span>
        </Message>
      )}
      <Form field={myfield} style={{ maxWidth: '500px' }}>
        <div style={{ position: 'relative' }}>
          <Form.Item {...formItemLayout} label={'Web fallback 行为'}>
            <RadioGroup {...init('webFallbackMode', {})}>
              <Radio id={'cpu'} value={0}>
                {'返回指定内容'}
              </Radio>
              <Radio id={'load'} value={1}>
                {'跳转到指定页面'}
              </Radio>
            </RadioGroup>
          </Form.Item>

          {myfield.getValue('webFallbackMode') === 0 && (
            <Form.Item {...formItemLayout} label={'HTTP 状态码'}>
              <Input
                placeholder={'数字，0 < x <= 999，默认 429'}
                trim
                {...init('webRespStatusCode', {
                  rules: [
                    {
                      pattern: /^[1-9][0-9]{0,2}?$/,
                      message: '请输入合法的数字',
                    },
                  ],
                })}
              />
            </Form.Item>
          )}

          {myfield.getValue('webFallbackMode') === 1 && (
            <Form.Item {...formItemLayout} label={'跳转Url'}>
              <Input trim placeholder={'跳转的页面地址'} {...init('webRedirectUrl', {})} />
            </Form.Item>
          )}
        </div>

        {getValue('webFallbackMode') === 0 && <>
          <Form.Item {...formItemLayout} label={'返回 content-type'}>
            <RadioGroup value={dataType} onChange={handleDataTypeChange}>
              <Radio id={'text'} value={0}>
                {'普通文本'}
              </Radio>
              <Radio id={'json'} value={1}>
                {'JSON 字符串'}
              </Radio>
            </RadioGroup>
          </Form.Item>

          {dataType === 0 && <Form.Item {...formItemLayout} label={'HTTP 返回文本'} required>
            <Input.TextArea
              className={styles['inputTextArea']}
              placeholder={'普通文格式数据'}
              value={dataArea}
              onChange={handleContentTypeChange}
            />
          </Form.Item>}

          {dataType === 1 && <Form.Item {...formItemLayout} label={'HTTP 返回文本'} required>
            <JSONEditor
              edit={true}
              title={''}
              type={'stress'}
              value={dataArea}
              // propsValue={''}
              onOk={handleContentTypeChange}
              jsonMax={true}
              onValidationError={onValidationError}
            />
          </Form.Item>}
        </>}
      </Form>
      {renderFooter}
    </div>
  );
});

export default SystemGuardBMDialog;
