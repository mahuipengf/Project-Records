import React, { useCallback, useEffect, useMemo, useState } from 'react';
import SystemGuardBMDialog from './SystemGuardBMDialog';
import styles from './index.less';
import { Balloon, Dialog, Icon, Table } from '@alicloud/console-components';
import { FLOW_TYPE, MODULE_TYPE } from '../../../App/AppDetail/components/common/config/constants/flow';
import { getParams } from 'utils';
// import { useDispatch } from '@ali/sre-utils-dva';
import services from 'services';
import Cookie from 'js-cookie';
import { useIntl } from '@ali/widget-hooks';

const SystemGuardBasicModule = () => {
  const intl = useIntl();
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  // const dispatch = useDispatch();
  const [ isLoading, setIsLoading ] = useState(false);
  const [ WebFallbackMode, setWebFallbackMode ] = useState(0);// 状态码/http
  const [ webFlowRules, setWebFlowRules ] = useState({});// 配置数据
  const [ dialogWebFlow, setDialogWebFlow ] = useState(false);// dialog visible
  const [ webFlowRulesArr, setwebFlowRulesArr ] = useState([{
    WebFallbackMode: 0,
    WebRespStatusCode: 429,
    WebRedirectUrl: '',
  }]);// table数据

  useEffect(() => {
    services.GetSentinelClientVersionOfApp({
      params: {
        AppName: appName,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
  }, []);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    // const { Data: result = {} } = await services.SentinelGetAdapterSettingOfApp({
    const result = await services.SentinelGetAdapterSettingOfApp({
      params:{
        AppName: appName,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    // const { AppName = '' } = result;
    // const { WebFallbackMode = 0 } = result;
    const AppName = result?.AppName || '';
    const WebFallbackMode = result?.WebFallbackMode || 0;

    if (AppName) {
      setWebFlowRules(result);
      setwebFlowRulesArr([ result ]);
      setWebFallbackMode(WebFallbackMode);
    }
    setIsLoading(false);
  }, [ isLoading, webFlowRules, webFlowRulesArr, WebFallbackMode ]);

  const openWebFlowAdd = useCallback(() => {
    setDialogWebFlow(true);
  }, [ dialogWebFlow ]);

  const closeWebFlowAdd = useCallback(() => {
    setDialogWebFlow(false);
  }, [ dialogWebFlow ]);

  const renderFlowOpt = useMemo(() => {
    return (
      <div className={styles['flowOpt']}>
        <span onClick={openWebFlowAdd}>
          <Icon type="edit" size="xs" /> &nbsp;
          <span>{'修改'}</span>
        </span>
      </div>
    );
  }, []);

  return (
    <div className={styles['content']}>
      <div className={styles['contentTitle']}>
        <p>模块适配设置</p>
        <Balloon
          trigger={<Icon type="help" size="small" />}
          closable={false}
          align={'r'}
        >
          <span>
            仅 AHAS Sentinel Client 1.5.0 及以上版本可用
          </span>
        </Balloon>
      </div>
      <div className={styles['list']}>
        <Table
          dataSource={webFlowRulesArr}
          loading={isLoading}
          hasBorder={false}
        >
          <Table.Column
            title="适配模块"
            dataIndex="WebFallbackMode"
            align={'center'}
            cell={type => MODULE_TYPE[type]}
          />
          <Table.Column
            title="流控处理逻辑"
            dataIndex="WebFallbackMode"
            align={'center'}
            cell={type => FLOW_TYPE(intl)[type]}
          />
          { !WebFallbackMode ? (
            <Table.Column
              title="HTTP 状态码"
              dataIndex="WebRespStatusCode"
              align={'center'}
            />
          ) : (
            <Table.Column title="跳转Url" dataIndex="WebRedirectUrl" align={'center'} />
          )}
          <Table.Column title="操作" align={'center'} cell={renderFlowOpt} />
        </Table>
      </div>
      <Dialog
        visible={dialogWebFlow}
        footer={<div />}
        onClose={closeWebFlowAdd}
        title={<div>{'模块适配设置修改'}</div>}
        style={{ width: '600px' }}
        shouldUpdatePosition
      >
        <SystemGuardBMDialog
          record={webFlowRules}
          onCloseDialog={closeWebFlowAdd}
          onChange={fetchData}
          appName={appName}
        />
      </Dialog>
    </div>
  );
};

export default SystemGuardBasicModule;
