import React from 'react';
import SystemGuardBasicModule from './SystemGuardBasicModule';
import SystemGuardBasicProtection from './SystemGuardBasicProtection';
import SystemGuardBasicUniversal from './SystemGuardBasicUniversal';

const SystemGuardBasic = ({ ahasStatus }) => {
  const isNginx = sessionStorage.getItem('isNginx') === 'true';
  return (
    <div>
      {!isNginx &&
        <>
          <SystemGuardBasicProtection
            ahasStatus={ahasStatus}
          />
        </>
      }
      <SystemGuardBasicModule />
      <SystemGuardBasicUniversal />
    </div>
  );
};

export default SystemGuardBasic;
