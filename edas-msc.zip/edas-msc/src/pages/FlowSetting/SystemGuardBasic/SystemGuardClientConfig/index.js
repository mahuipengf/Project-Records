import React, { FC, useCallback, useEffect, useMemo, useState } from 'react';
import SystemGuardClientDialog from './SystemGuardClientDialog';
import styles from './index.less';
import { Balloon, Dialog, Icon, Table } from '@alicloud/console-components';
import { DEFAULT_REQUEST_TIMEOUT } from '../../../App/AppDetail/components/common/config/constants/flow';
import { getParams } from 'utils';
// import { useDispatch } from '@ali/sre-utils-dva';
import services from 'services';
import Cookie from 'js-cookie';

const SystemGuardClientConfig = () => {
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  // const dispatch = useDispatch();
  const [ isLoading, setIsLoading ] = useState(true);
  const [ basicConfig, setBasicConfig ] = useState({});// 基础配置数据
  const [ dialogBasic, setDialogBasic ] = useState(false);// dialog visible
  const [ basicConfigArr, setBasicConfigArr ] = useState([{
    RequestTimeout: DEFAULT_REQUEST_TIMEOUT,
  }]); // table数据

  useEffect(() => {
    fetchData();
    setIsLoading(false);
  }, []);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    const result = await services.GetSentinelClusterClientSettingOfApp({
      params:{
        AppName: appName,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    // const { AppName = '' } = result;
    const AppName = result?.AppName || '';
    if (AppName) {
      setBasicConfig(result);
      setBasicConfigArr([ result ]);
    }
    setIsLoading(false);
  }, [ basicConfig, basicConfigArr, isLoading ]);

  const openBasicConfigAdd = useCallback(() => {
    setDialogBasic(true);
  }, [ dialogBasic ]);

  const closeBasicConfigAdd = useCallback(() => {
    setDialogBasic(false);
  }, [ dialogBasic ]);

  const renderBasicOpt = useMemo(() => {
    return (
      <div className={styles['basicOpt']}>
        <span onClick={openBasicConfigAdd}>
          <Icon type="edit" size="xs" /> &nbsp;
          <span>{'修改'}</span>
        </span>
      </div>
    );
  }, []);

  function renderRequestTimeout(value) {
    return (
      <span>{`${value} ms`}</span>
    );
  }

  return (
    <div className={styles['content']}>
      <div className={styles['contentTitle']}>
        <p>Token Client 设置</p>
        <Balloon
          trigger={<Icon type="help" size="small"/>}
          closable={false}
          align={'r'}
        >
          <span>
            AHAS Sentinel Client 1.6.0 及以上版本可用
          </span>
        </Balloon>
      </div>
      <div className={styles['list']}>
        <Table
          dataSource={basicConfigArr}
          loading={isLoading}
          hasBorder={false}
        >
          <Table.Column
            title="Token 请求超时时间"
            dataIndex="RequestTimeout"
            cell={renderRequestTimeout}
            align={'center'}
          />
          <Table.Column title="操作" align={'center'} cell={renderBasicOpt}/>
        </Table>
      </div>
      <Dialog
        visible={dialogBasic}
        footer={<div />}
        onClose={closeBasicConfigAdd}
        title={<div>{'Token Client 设置修改'}</div>}
        style={{ width: '550px' }}
      >
        <SystemGuardClientDialog
          record={basicConfig}
          onCloseDialog={closeBasicConfigAdd}
          onChange={fetchData}
          appName={appName}
        />
      </Dialog>
    </div>
  );
};

export default SystemGuardClientConfig;
