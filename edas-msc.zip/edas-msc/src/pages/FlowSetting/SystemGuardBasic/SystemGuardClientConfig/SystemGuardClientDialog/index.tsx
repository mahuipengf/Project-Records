import React, { FC, memo, useCallback, useEffect, useMemo, useState } from 'react';
import styles from './index.css';
import { Balloon, Button, Field, Form, Icon, Input, Message } from '@alicloud/console-components';
import { DEFAULT_REQUEST_TIMEOUT, MODIFY_SUCCESS } from 'config/constants/flow';
import { ISubmitDataClientAdd, IformItemLayout } from 'config/interfaces/flowProtection';
import { useDispatch } from '@ali/sre-utils-dva';

interface Iprops {
  record: any;
  onCloseDialog: () => void;
  onChange: () => void;
  appName: string;
}

const SystemGuardClientDialog: FC<Iprops> = memo(({ record, onCloseDialog, onChange, appName }) => {
  const disPatch = useDispatch();
  const myfield = Field.useField();
  const { init, getValue } = myfield;
  const [ formItemLayout ] = useState<IformItemLayout>({
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  });

  useEffect(() => {
    const { AppName: basicAppName = '' } = record;
    if (basicAppName) {
      myfield.setValue('requestTimeout', record.RequestTimeout);
    } else {
      myfield.setValue('requestTimeout', DEFAULT_REQUEST_TIMEOUT);
    }
  }, []);

  const fetchUpdateData = useCallback(async (submitData: ISubmitDataClientAdd) => {
    const { Message: msg = '操作失败', Success = false } = await disPatch.flowAppModel.UpdateSentinelClusterClientSettingOfApp({ ...submitData });
    if (Success) {
      Message.success({
        content: MODIFY_SUCCESS,
        animation: false,
        style: { marginTop: '50px' },
      });

      onChange();
      onCloseDialog();
    } else {
      Message.error({
        content: msg,
        animation: false,
        style: { marginTop: '50px' },
      });
    }
  }, [ onChange, onCloseDialog ]);

  const handleAddBasicRule = useCallback(() => {
    let isValid = false;

    myfield.validate(errors => {
      if (!errors) {
        isValid = true;
      }
    });

    if (isValid) {
      const submitData = {
        AppName: appName,
        RequestTimeout: Number(getValue('requestTimeout')),
      };
      fetchUpdateData(submitData);
    }
  }, [ fetchUpdateData ]);

  const renderFooter = useMemo(() => {
    return (
      <span className={styles.footer}>
        <Button
          onClick={handleAddBasicRule}
          type={'primary'}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_add"
        >
          {'确定'}
        </Button>

        <Button
          onClick={onCloseDialog}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_cancel"
        >
          {'取消'}
        </Button>
      </span>
    );
  }, []);

  const hintLayout = useMemo(() => {
    return <Icon type="prompt" size="small" style={{ marginLeft: '5px' }} />;
  }, []);

  return (
    <div className={styles.content}>
      <Form field={myfield} style={{ maxWidth: '500px' }}>
        <div>
          <Form.Item
            {...formItemLayout}
            label={
              <span>
                {'token 请求超时时间'}
                <Balloon align="r" type="primary" trigger={hintLayout}>
                  <div>
                    <p className={styles.balloonTipsBox}>
                      Token client 请求 token server 的超时时长，超时会退化到单机模式。对于网络不稳定的场景，超时时长可以适当放大，但注意这也会使 RT 增加。
                    </p>
                  </div>
                </Balloon>
              </span>
            }
          >
            <Input
              placeholder={'数字，0 < x <= 10000，默认 20'}
              addonTextAfter={'ms'}
              trim
              {...init('requestTimeout', {
                rules: [
                  {
                    required: true,
                    message: '不能为空',
                  },
                  {
                    pattern: /^((?!0)[0-9]{1,4}|10000)$/,
                    message: '请输入 (0, 10000] 范围内的数字',
                  },
                ],
              })}
            />
          </Form.Item>
        </div>
      </Form>
      {renderFooter}
    </div>
  );
});

export default SystemGuardClientDialog;

