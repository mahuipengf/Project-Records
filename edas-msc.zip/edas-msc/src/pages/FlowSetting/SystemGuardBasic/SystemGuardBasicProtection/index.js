import React, { FC, useCallback, useEffect, useState } from 'react';
import SystemGuardBPDialog from './SystemGuardBPDialog';
import SystemGuardBPTips from './SystemGuardBPTips';
import SystemGuardRuleCheck from '../../../App/AppDetail/components/common/SystemGuardRuleCheck';
import styles from './index.less';
import {
  BEGINNER_TIPS,
  MSG_TIPS,
  POST_BUY_URL,
  PROFESSIONAL_TIPS,
  SWITCH_FAILED,
  SWITCH_SUCCESS,
} from '../../../App/AppDetail/components/common/config/constants/flow';
import {
  Balloon,
  Button,
  Dialog,
  Icon,
  Loading,
  Message,
  Radio,
} from '@alicloud/console-components';
import { getActiveRegion } from '@ali/sre-utils';
import { getParams } from 'utils';
import { useIntl } from '@ali/widget-hooks';
// import { useDispatch } from '@ali/sre-utils-dva';
import services from 'services';
import Cookie from 'js-cookie';

const { Group: RadioGroup } = Radio;

const SystemGuardBasicProtection = ({ ahasStatus = '' }) => {
  const intl = useIntl();
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const regionId = getActiveRegion();
  // const dispatch = useDispatch();
  const [ value, setValue ] = useState(0); // radio的默认value值
  const [ postBuyUrl, setPostBuyUrl ] = useState(''); // 开通专业版url
  const [ dirtyLevel, setDirtyLevel ] = useState(0);
  const [ disabledRadio, setDisabledRadio ] = useState(false); // 是否禁用单选框
  const [ isLoading, setIsLoading ] = useState(false);
  const [ dialogRuleCheck, setDialogRuleCheck ] = useState(false); // 规则校验visible
  const [ msgPointText, setMsgPointText ] = useState('');

  useEffect(() => {
    const { ALIYUN_CONSOLE_CONFIG = {} } = window;
    const { CHANNEL_LINKS = {} } = ALIYUN_CONSOLE_CONFIG;
    const { post_buy = '' } = CHANNEL_LINKS;
    if (post_buy) {
      setPostBuyUrl(post_buy);
    } else {
      setPostBuyUrl(POST_BUY_URL);
    }

    if (ahasStatus === '00' || ahasStatus === '01') {
      setIsLoading(false);
      setDisabledRadio(true);
    } else {
      setValue(0);
      fetchPriceModelData();
    }
  }, []);

  // 获取防护模式配置数据
  const fetchPriceModelData = useCallback( async () => {
    setIsLoading(true);
    // const {
    //   Data: result = {},
    // } = await services.SentinelQueryAppPriceLevel({
    //   params: {
    //     AppName: appName,
    //     namespace: 'default',
    //     RegionId: region,
    //     AhasRegionId: region,
    //     Namespace: 'default',
    //     NameSpace: 'default',
    //   }
    // });
    const result = await services.SentinelQueryAppPriceLevel({
      params: {
        AppName: appName,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    const { AppName = '', CurrentLevel = 0, DirtyLevel = 0 } = result;
    if (AppName) {
      setDirtyLevel(DirtyLevel);
      setValue(CurrentLevel);
    }
    setIsLoading(false);
  }, [ dirtyLevel, value, isLoading ]);

  // 修改防护模式配置数据
  const fetchModifyData = useCallback(
    async (value) => {
      const {
        Message: msg = SWITCH_FAILED(intl),
        Success = false,
        Code,
        Message: msgPointText = '',
      } = await services.SentinelModifyAppPriceLevel({
        AppName: appName,
        priceLevel: value,
         namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      });
      if (Code === 'sentinel.time.forbidden') {
        Message.error({
          content: MSG_TIPS(intl),
          style: { marginTop: '50px' },
          animation: false,
        });
      } else if (Code === 'sentinel.rulecount.exceed') {
        setDialogRuleCheck(true);
        setMsgPointText(msgPointText);
      } else if (Success && appName) {
        Message.success({
          content: SWITCH_SUCCESS(intl),
          style: { marginTop: '50px' },
          animation: false,
        });

        fetchPriceModelData();
      } else {
        Message.error({
          content: msg,
          style: { marginTop: '50px' },
          animation: false,
        });
      }
    },
    [ dialogRuleCheck, msgPointText, fetchPriceModelData ],
  );

  const handlePriceModelChange = useCallback(
    value => {
      if (value === 0) {
        window.goldlog.record(
          '/ahas-flow.app_setting.guard_mode_vip',
          'CLK',
          '',
          'GET',
        );
      }
      if (value === 1) {
        window.goldlog.record(
          '/ahas-flow.app_setting.guard_mode_ordinary',
          'CLK',
          '',
          'GET',
        );
      }
      Dialog.confirm({
        content: <SystemGuardBPDialog value={value} />,
        needWrapper: false,
        title: '提示',
        onOk: () => {
          window.goldlog.record(
            '/ahas-flow.app_setting.mode_confirm_btn',
            'CLK',
            '',
            'GET',
          );

          fetchModifyData(value);
        },
        onCancel: () => {
          window.goldlog.record(
            '/ahas-flow.app_setting.mode_cancel_btn',
            'CLK',
            '',
            'GET',
          );
        },
      });
    },
    [ fetchPriceModelData ],
  );

  const closeRuleCheck = useCallback(() => {
    setDialogRuleCheck(false);
  }, [ dialogRuleCheck ]);

  return (
    <>
      {
        value ?
          <div className={styles.content}>
            <Loading visible={isLoading}>
              <div className={styles.contentTitle}>
                <p>防护模式设置</p>
                <Balloon
                  trigger={<Icon type="help" size="small" />}
                  closable={false}
                  align={'r'}
                >
                  <div style={{ lineHeight: '24px' }}>
                    <p> {BEGINNER_TIPS(intl)} </p>
                    <p> {PROFESSIONAL_TIPS(intl)} </p>
                  </div>
                </Balloon>
              </div>
              <div className={styles.list}>
                {/* <p>模式选择</p> */}
                <ul className={styles.item_1}>
                  <li>
                    <RadioGroup value={value} onChange={handlePriceModelChange}>
                      <Radio value={0}>高级防护</Radio>
                      <Radio value={1}>入门级防护</Radio>
                    </RadioGroup>
                  </li>
                  <li>
                    <p>
                      <span> {PROFESSIONAL_TIPS(intl)} </span>
                    </p>
                    <p>
                      <span> {BEGINNER_TIPS(intl)} </span>
                    </p>
                  </li>
                </ul>
                <ul className={styles.item_2}>
                  <SystemGuardBPTips
                    postBuyUrl={postBuyUrl}
                    value={value}
                    dirtyLevel={dirtyLevel}
                    disabledRadio={disabledRadio}
                  />
                </ul>
              </div>
            </Loading>
            <Dialog
              visible={dialogRuleCheck}
              footer={
                <Button onClick={closeRuleCheck} type="primary">
                确定
                </Button>
              }
              onClose={closeRuleCheck}
              title={'提示'}
            >
              <SystemGuardRuleCheck
                msgPointText={msgPointText}
                onCloseDialog={closeRuleCheck}
                regionId={regionId}
                appName={appName}
                dirtyLevel={dirtyLevel}
              />
            </Dialog>
          </div> : <></>
      }
    </>
  );
};

export default SystemGuardBasicProtection;
