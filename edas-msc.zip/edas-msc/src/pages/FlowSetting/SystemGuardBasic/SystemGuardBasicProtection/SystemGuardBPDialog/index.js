import React, { FC, memo, useMemo } from 'react';
import styles from './index.less';
import { Icon } from '@alicloud/console-components';


const SystemGuardBPDialog = memo(({ value }) => {

  const typeOfPriceModel = useMemo(() => {
    return <span style={{ color: '#00c1de' }}>{!value ? '高级' : '入门级'}</span>;
  }, [ value ]);

  // 切换防护模式文案提示
  const renderCopywritingTips = useMemo(() => {
    return (
      <div className={styles.copywritingTips}>
        <Icon type="prompt" style={{ width: '40px', marginRight: '20px', marginTop: '-6px', color: '#ffce03' }} />
        <div className={styles.copywritingItem}>
          <p className={styles.priceModelTips}>
            {'是否切换防护模式到 '}
            {typeOfPriceModel}
            {' ?'}
          </p>
          <p className={styles.priceModelTtem}>{(!value ? '高级' : '入门级') + '防护模式信息'}</p>
          <p className={styles.priceModelTtem}>
            <span>{'计费规则：'}</span>
            <span>{!value ? '3 元/节点/天' : '0.3 元/节点/天'}</span>
          </p>
          <p className={styles.priceModelTtem}>
            <span>{'防护规则数：'}</span>
            <span className={!value ? 'professional-text' : 'beginner-text'}>
              {!value ? '无限制' : '2条'}
            </span>
          </p>
          <p className={styles.priceModelTtem}>
            <span>{'历史监控数据：'}</span>
            <span className={!value ? 'professional-text' : 'beginner-text'}>
              {!value ? '7 天' : '30分钟'}
            </span>
          </p>
          <p className={styles.priceModelTtem}>
            <span>{'生效时间：'}</span>
            <span>
              {!value
                ? '切换后立即生效（含规则限制和计费）'
                : '计费模式切换后次日凌晨生效、规则数立即生效'}
            </span>
          </p>
        </div>
      </div>
    );
  }, [ value ]);

  return (
    <>
      { renderCopywritingTips }
    </>
  );
});

export default SystemGuardBPDialog;
