import React, { memo, useMemo, useState } from 'react';
import moment from 'moment';
import styles from './index.less';

const SystemGuardBPTips = memo(({ postBuyUrl, value, dirtyLevel, disabledRadio }) => {
  const [ nowDate ] = useState(new Date().getTime());

  const renderDom = useMemo(() => {
    return (
      <>
        { !value && dirtyLevel ? (
          <li className={styles.content}>
            <span className={styles.list}>
              温馨提示 : 当前计费模式为：
              <span className={styles.item}>高级&nbsp;，</span>
              <span className={styles.item}>
                &nbsp;{moment(nowDate).format('YYYY-MM-DD') + ' 23:59:59'}
              </span>
              &nbsp;后自动切换为入门级
            </span>
          </li>
        ) : ''}
        { disabledRadio && (
          <li className={styles.content}>
            <span className={styles.list}>
              温馨提示 : 您当前版本为：
              <span className={styles.item}>免费版</span>
              ，若要进行防护模式配置，请点此
              <span className={styles.item}>
                <a target="_blank" href={postBuyUrl}>
                  &nbsp;去开通专业版
                </a>
              </span>
            </span>
          </li>
        )}
      </>
    );
  }, [ postBuyUrl, value, dirtyLevel, disabledRadio ]);

  return (
    <>
      { renderDom }
    </>
  );
});

export default SystemGuardBPTips;
