import React, { FC, useCallback, useEffect, useMemo, useState } from 'react';
import SystemGuardBUDialog from './SystemGuardBUDialog';
import styles from './index.less';
import { Balloon, Dialog, Icon, Table } from '@alicloud/console-components';
import { DEFAULT_CONTEXT_AMOUNT, DEFAULT_ORIGIN_AMOUNT, DEFAULT_RESOURCE_AMOUNT, DEFAULT_STATISTIC_RT } from '../../../App//AppDetail/components/common/config/constants/flow';
import { getParams } from 'utils';
// import { useDispatch } from '@ali/sre-utils-dva';
import services from 'services';
import Cookie from 'js-cookie';

const SystemGuardBasicUniversal = () => {
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  // const dispatch = useDispatch();
  const [ isLoading, setIsLoading ] = useState(true);
  const [ basicConfig, setBasicConfig ] = useState({});// 基础配置数据
  const [ dialogBasic, setDialogBasic ] = useState(false);// dialog visible
  const [ basicConfigArr, setBasicConfigArr ] = useState([{
    MaxResourceAmount: DEFAULT_RESOURCE_AMOUNT,
    MaxOriginAmount: DEFAULT_ORIGIN_AMOUNT,
    MaxContextAmount: DEFAULT_CONTEXT_AMOUNT,
    StatisticMaxRt: DEFAULT_STATISTIC_RT,
  }]); // table数据

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    const result = await services.SentinelGetGeneralSettingOfApp({
      params: {
        AppName: appName,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    // const { AppName = '' } = result;
    const AppName = result?.AppName || '';
    if (AppName) {
      setBasicConfig(result);
      setBasicConfigArr([ result ]);
    }
    setIsLoading(false);
  }, [ basicConfig, basicConfigArr, isLoading ]);

  const openBasicConfigAdd = useCallback(() => {
    setDialogBasic(true);
  }, [ dialogBasic ]);

  const closeBasicConfigAdd = useCallback(() => {
    setDialogBasic(false);
  }, [ dialogBasic ]);

  const renderBasicOpt = useMemo(() => {
    return (
      <div className={styles['basicOpt']}>
        <span onClick={openBasicConfigAdd}>
          <Icon type="edit" size="xs" /> &nbsp;
          <span>{'修改'}</span>
        </span>
      </div>
    );
  }, []);

  return (
    <div className={styles['content']}>
      <div className={styles['contentTitle']}>
        <p>通用设置</p>
        <Balloon
          trigger={<Icon type="help" size="small"/>}
          closable={false}
          align={'r'}
        >
          <span>
            仅 AHAS Sentinel Client 1.5.0 及以上版本可用
          </span>
        </Balloon>
      </div>
      <div className={styles['list']}>
        <Table
          dataSource={basicConfigArr}
          loading={isLoading}
          hasBorder={false}
        >
          <Table.Column
            title="簇点数目限制"
            dataIndex="MaxResourceAmount"
            align={'center'}
          />
          <Table.Column title="来源数目限制" dataIndex="MaxOriginAmount" align={'center'} />
          <Table.Column
            title="入口数目限制"
            dataIndex="MaxContextAmount"
            align={'center'}
          />
          <Table.Column
            title="最大统计 RT (ms)"
            dataIndex="StatisticMaxRt"
            align={'center'}
          />
          <Table.Column title="操作" align={'center'} cell={renderBasicOpt}/>
        </Table>
      </div>
      <Dialog
        visible={dialogBasic}
        footer={<div />}
        onClose={closeBasicConfigAdd}
        title={<div>{'通用设置修改'}</div>}
        style={{ width: '600px' }}
      >
        <SystemGuardBUDialog
          record={basicConfig}
          onCloseDialog={closeBasicConfigAdd}
          onChange={fetchData}
          appName={appName}
        />
      </Dialog>
    </div>
  );
};

export default SystemGuardBasicUniversal;
