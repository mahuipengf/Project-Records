import React, { FC, memo, useCallback, useEffect, useMemo, useState } from 'react';
import styles from './index.less';
import { Balloon, Button, Field, Form, Icon, Input, Message } from '@alicloud/console-components';
import { DEFAULT_CONTEXT_AMOUNT, DEFAULT_ORIGIN_AMOUNT, DEFAULT_RESOURCE_AMOUNT, DEFAULT_STATISTIC_RT, SUCCESS_MSG } from '../../../../App/AppDetail/components/common/config/constants/flow';
// import { ISubmitDataBasicAdd, IformItemLayout } from 'config/interfaces/flowProtection';
// import { useDispatch } from '@ali/sre-utils-dva';
import services from 'services';
import Cookie from 'js-cookie';
import { useIntl } from '@ali/widget-hooks';

const SystemGuardBUDialog = memo(({ record, onCloseDialog, onChange, appName }) => {
  const intl = useIntl();
  const myfield = Field.useField();
  const { init, getValue } = myfield;
  const [ formItemLayout ] = useState({
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  });
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';

  useEffect(() => {
    const { AppName: basicAppName = '' } = record;
    if (basicAppName) {
      myfield.setValue('resourceAmount', record.MaxResourceAmount);
      myfield.setValue('originAmount', record.MaxOriginAmount);
      myfield.setValue('contextAmount', record.MaxContextAmount);
      myfield.setValue('statisticRt', record.StatisticMaxRt);
    } else {
      myfield.setValue('resourceAmount', DEFAULT_RESOURCE_AMOUNT);
      myfield.setValue('originAmount', DEFAULT_ORIGIN_AMOUNT);
      myfield.setValue('contextAmount', DEFAULT_CONTEXT_AMOUNT);
      myfield.setValue('statisticRt', DEFAULT_STATISTIC_RT);
    }
  }, []);

  const fetchUpdateData = useCallback(async (submitData) => {
    const result = await services.SentinelUpdateGeneralSettingOfApp({ ...submitData });
    if (result) {
      Message.success({
        content: SUCCESS_MSG(intl),
        animation: false,
        style: { marginTop: '50px' },
      });

      onChange();
      onCloseDialog();
    } else {
      Message.error({
        content: msg,
        animation: false,
        style: { marginTop: '50px' },
      });
    }
  }, [ onChange, onCloseDialog ]);

  const handleAddBasicRule = useCallback(() => {
    let isValid = false;

    myfield.validate(errors => {
      if (!errors) {
        isValid = true;
      }
    });

    if (isValid) {
      const submitData = {
        params: {
          AppName: appName,
          MaxResourceAmount: getValue('resourceAmount'),
          MaxOriginAmount: getValue('originAmount'),
          MaxContextAmount: getValue('contextAmount'),
          StatisticMaxRt: getValue('statisticRt'),
          namespace: 'default',
          RegionId: region,
          AhasRegionId: region,
          Namespace: 'default',
          NameSpace: 'default',
        }
      };
      fetchUpdateData(submitData);
    }
  }, [ fetchUpdateData ]);

  const renderFooter = useMemo(() => {
    return (
      <span className={styles['footer']}>
        <Button
          onClick={handleAddBasicRule}
          type={'primary'}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_add"
        >
          {'确定'}
        </Button>

        <Button
          onClick={onCloseDialog}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_cancel"
        >
          {'取消'}
        </Button>
      </span>
    );
  }, []);

  const hintLayout = useMemo(() => {
    return <Icon type="prompt" size="small" style={{ marginLeft: '5px' }} />;
  }, []);

  return (
    <div className={styles['content']}>
      <Form field={myfield} style={{ maxWidth: '500px' }}>
        <div>
          <Form.Item
            {...formItemLayout}
            label={
              <span>
                {'簇点数目限制'}
                <Balloon align="r" type="primary" trigger={hintLayout}>
                  <div>
                    <p className={styles['balloonTipsBox']}>
                      簇点数目限制：限制埋点资源数目。实际资源数目不建议超过 6000 ，否则内存占用会非常多
                    </p>
                  </div>
                </Balloon>
              </span>
            }
          >
            <Input
              placeholder={'数字，0 < x <= 50000，默认 6000'}
              trim
              {...init('resourceAmount', {
                rules: [
                  {
                    required: true,
                    message: '不能为空',
                  },
                  {
                    pattern: /^\d{1,4}$|^[1-4]\d{4}$|^50000$/,
                    message: '请输入合法的数字',
                  },
                ],
              })}
            />
          </Form.Item>

          <Form.Item {...formItemLayout} label={'来源数目限制'}>
            <Input
              placeholder={'数字，0 < x <= 50000，默认 500'}
              trim
              {...init('originAmount', {
                rules: [
                  {
                    required: true,
                    message: '不能为空',
                  },
                  {
                    pattern: /^\d{1,4}$|^[1-4]\d{4}$|^50000$/,
                    message: '请输入合法的数字',
                  },
                ],
              })}
            />
          </Form.Item>
        </div>
        <div>
          <Form.Item {...formItemLayout} label={'入口数目限制'}>
            <Input
              placeholder={'数字，0 < x <= 50000，默认 2000'}
              trim
              {...init('contextAmount', {
                rules: [
                  {
                    required: true,
                    message: '不能为空',
                  },
                  {
                    pattern: /^\d{1,4}$|^[1-4]\d{4}$|^50000$/,
                    message: '请输入合法的数字',
                  },
                ],
              })}
            />
          </Form.Item>

          <Form.Item
            {...formItemLayout}
            label={
              <span>
                {'最大统计 RT (ms)'}
                <Balloon align="r" type="primary" trigger={hintLayout}>
                  <div>
                    <p className={styles['balloonTipsBox']}>最大统计 RT (ms)：统计的最大 RT (ms)，超出此上限的将按照这个上限值记录</p>
                  </div>
                </Balloon>
              </span>
            }
          >
            <Input
              placeholder={'数字，x > 0，默认 4900'}
              trim
              {...init('statisticRt', {
                rules: [
                  {
                    required: true,
                    message: '不能为空',
                  },
                  {
                    pattern: /^[1-9]\d*$/,
                    message: '请输入合法的数字',
                  },
                ],
              })}
            />
          </Form.Item>
        </div>
      </Form>
      {renderFooter}
    </div>
  );
});

export default SystemGuardBUDialog;

