import React, { useEffect, useState } from 'react';
import styles from './index.less';
import { Balloon, Button, Dialog, Loading, Message, NumberPicker, Radio, Range, Switch } from '@alicloud/console-components';
const { Group: RadioGroup } = Radio;
import { CLISTER_STATUS, CLUSTRER_GEARLEVEL } from '../../../App/AppDetail/components/common/config/constants/flow';
import { getParams } from 'utils';
import services from 'services';
import Cookie from 'js-cookie';

const SystemGuardClusterQps = () => {
  const appName = getParams('appName') || 'spring-cloud-a';
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const isPublic = getParams('region') === 'public';
  const isNginx = sessionStorage.getItem('isNginx') === 'true';
  const [ isLoading, setIsLoading ] = useState(true);
  const [ isBtnLoading, setIsBtnLoading ] = useState(false);
  const [ gearlevel, setGearlevel ] = useState(1);
  const [ isEdit, setIsEdit ] = useState(false);
  const [ hasCluster, setHasCluster ] = useState(false);
  const [ clusterId, setClusterId ] = useState(0);
  const [ maxQps, setMaxClusterQps ] = useState(10000);
  const [ maxQpsInput, setMaxQpsInput ] = useState(10000);
  const [ maxCount, setMaxThresholdCount ] = useState(9500);
  const [ clusterName, setClusterName ] = useState('');
  const [ clusterEnable, setClusterEnable ] = useState(true);
  const [ assignStatus, setAssignStatus ] = useState(-1);
  const [ gearType, setGearType ] = useState(0);
  const [ gearTypeInput, setGearTypeInput ] = useState(0);

  useEffect(() => {
    isNginx && setGearType(1);
    setIsLoading(true);
    getClusterDetail();
  }, []);

  // 轮询请求集群状态
  function queryAssignStatus() {
    setTimeout(() => {
      getClusterDetail();
    }, 3000);
  }

  // 获取qps档位信息
  async function getClusterDetail() {
    const Data = await services.GetClusterDetail({
      params: {
        AppName: appName,
      }
    });
    const { ClusterConfig = {}, AssignStatus = -1 } = Data;
    const { MaxClusterQps = 10000, MaxThresholdCount = 5000, Id, ClusterQpsLevel = 1, Enable = false, TrialFlag = 0 } = ClusterConfig;
    if (Data && Id) {
      setAssignStatus(AssignStatus);
      if (AssignStatus === 0 || AssignStatus === 1) {
        queryAssignStatus();
        setIsBtnLoading(true);
      } else {
        setIsBtnLoading(false);
      }
      setGearType(TrialFlag);
      if (TrialFlag) {
        setMaxClusterQps(3000);
        setMaxQpsInput(3000);
        setMaxThresholdCount(2000);
      } else {
        setMaxClusterQps(MaxClusterQps);
        setMaxQpsInput(MaxClusterQps);
        setMaxThresholdCount(MaxThresholdCount);
      }
      setGearTypeInput(TrialFlag);
      setGearlevel(ClusterQpsLevel);
      setClusterId(Id);
      setClusterName('HAS_CLUSTER');
      setHasCluster(true);
      setClusterEnable(Enable);
    } else {
      setIsEdit(true);
    }
    setIsLoading(false);
  }

  // 创建集群qps档位
  function handleCreateCluster() {
    const levelTypeNow = gearType ? '试用档位' : '生产档位';
    const maxQpsTips = gearType ? '3000' : maxQpsInput;
    if (!gearTypeInput) {
      const contentTips = <span className={styles.typeChangeTips}>新建档位为<span>&nbsp;{levelTypeNow}&nbsp;</span>，QPS 量级为 <span>{maxQpsTips}</span>。<span>创建后的集群流控在线时长折算比例会按照正式档位量级的折算比例，计费也会实时生效</span>请确认是否创建？</span>;

      Dialog.confirm({
        title: '温馨提示',
        content: contentTips,
        onOk: () => createCluster(),
        onCancel: () => handleSaveOrCancelOrEditGearlevel('cancel'),
      });
    } else {
      createCluster();
    }
  }

  // 发送创建集群qps档位请求
  async function createCluster() {
    // setIsLoading(true);
    const params = {
      AppName: appName,
      ShareLevel: '',
      MaxClusterQps: maxQpsInput,
      Enable: clusterEnable,
      TrialFlag: gearType,
    };
    const result = await services.CreateCluster({
      params: {
        ...params,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    console.log(result);
    if (result) {
      Message.success('创建成功');
      setIsEdit(false);
      getClusterDetail();
    }
    setIsLoading(false);
  }

  // 保存qps档位信息
  async function updateCluster(trialType) {
    setIsLoading(true);
    const params = {
      AppName: appName,
      MaxClusterQps: maxQpsInput,
      ClusterId: clusterId,
      TrialFlag: trialType,
    };
    const result = await services.UpdateCluster({
      params: {
        ...params,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    console.log(result);
    if (result === 'sentinel.cluster.quota.insufficient') {
      Message.error('设置档位不可小于该应用所在集群已有规则的总QPS');
    } else if (result) {
      Message.success('保存成功');
      setGearType(trialType);
    }
    getClusterDetail();
    setIsLoading(false);
  }

  // 最大QPS档位选择
  function onRadioChange(value) {
    setGearlevel(Number(value));
  }

  // 编辑/保存/取消编辑最大QPS档位
  function handleSaveOrCancelOrEditGearlevel(type) {
    if (hasCluster && assignStatus !== 2) {
      Message.warning('资源分配未完成，请稍后再试');
    } else if (type === 'edit') {
      setIsEdit(true);
    } else if (type === 'cancel') {
      setMaxQpsInput(maxQps);
      setGearType(gearTypeInput);
      clusterName && setIsEdit(false);
    } else if (type === 'create') {
      handleCreateCluster();
      // setIsEdit(false);
    } else {
      onGearTypeChange();
    }
  }

  // 集群类型改变
  function onGearTypeChange() {
    if (maxQpsInput <= 0) {
      Message.warning('最大 QPS 值不可以为0，请重新设置。');
      return;
    }
    if (gearType !== gearTypeInput) {
      const levelTypeNow = gearType ? '试用档位' : '生产档位';
      const levelTypeChange = gearTypeInput ? '试用档位' : '生产档位';
      const maxQpsTips = gearType ? '3000' : maxQpsInput;
      const contentTips = <span className={styles.typeChangeTips}>您当前的档位为<span>&nbsp;{levelTypeChange}&nbsp;</span>，即将新切换为<span>&nbsp;{levelTypeNow}&nbsp;</span>，QPS 量级为 <span>{maxQpsTips}</span>。<span>调整后的集群流控在线时长折算比例会立即变化至新的量级的折算比例，计费也会实时生效</span>请确认是否切换？</span>;

      clusterName && Dialog.confirm({
        title: '温馨提示',
        content: contentTips,
        onOk: () => { updateCluster(gearType); setIsEdit(false); },
        onCancel: () => handleSaveOrCancelOrEditGearlevel('cancel'),
      });
    } else if (maxQps !== maxQpsInput) {
      const contentTips = <span className={styles.typeChangeTips}>您当前的集群流控总 QPS 量级为<span>&nbsp;{maxQps}&nbsp;</span>，即将变更为<span>&nbsp;{maxQpsInput}&nbsp;</span>。<span>调整后的集群流控在线时长折算比例会立即变化至新的量级的折算比例，计费也会实时生效</span>请确认是否切换？</span>;

      clusterName && Dialog.confirm({
        title: '温馨提示',
        content: contentTips,
        onOk: () => { updateCluster(gearType); setIsEdit(false); },
        onCancel: () => handleSaveOrCancelOrEditGearlevel('cancel'),
      });
    } else {
      updateCluster(gearType);
      setIsEdit(false);
    }
  }

  // 档位状态改变
  function onSwitchChange(checked) {
    const dialogType = checked ? '开启' : '关闭';
    clusterName && Dialog.confirm({
      title: '温馨提示',
      content: (
        <span>
          {'是否确定 '}
          <span style={{ color: '#0070cc' }}>{dialogType}</span>
          {' 最大QPS : '}
          <span style={{ color: '#0070cc' }}>{maxQps}</span>
          {' , 最大阈值 : '}
          <span style={{ color: '#0070cc' }}>{maxCount}</span>
          {' 的集群配置？'}
        </span>
      ),
      onOk: () => handleOpenOrCloseCluster(checked),
    });
  }

  // 开启、关闭档位设置
  async function handleOpenOrCloseCluster(checked) {
    const dialogType = checked ? '开启' : '关闭';
    const params = { ClusterId: clusterId };
    const result = checked ? await services.Clusteron({
      params: {
        ...params,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    }) : await services.Clusteroff({
      params: {
        ...params,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    if (result === 'sentinel.cluster.rule.exist') {
      Message.warning('集群流控规则生效中，不可关闭集群');
    } else if (result === 'sentinel.cluster.quota.insufficient') {
      Message.warning('调整后的总 QPS 配额不足，请先调整现有规则再调整集群流控量级');
    } else if (result) {
      setClusterEnable(checked);
      Message.success(`${dialogType}成功`);
    } else {
      Message.error(`${dialogType}失败，请重试`);
    }
  }

  // 渲染集群状态
  const renderAssignStatus = () => {
    let textColor = '#333333';
    switch (assignStatus) {
      case 0: textColor = '#0070cc';
        break;
      case 1: textColor = '#0070cc';
        break;
      case 2: textColor = '#009900';
        break;
      case 5: textColor = '#d93026';
        break;
      default: textColor = '#333333';
    }

    return (
      <Button style={{ color: textColor }} type="normal" text loading={isBtnLoading}>
        {CLISTER_STATUS[assignStatus] || '未知'}
      </Button>
    );
  };

  // Max QPS 值改变
  function onMaxQpsChangeInt(value) {
    setMaxQpsInput(value ? Number(value) : 0);
  }

  // 档位类型改变
  function handleGearTypeChange(value) {
    const val = Number(value);
    if (!val) {
      setMaxClusterQps(10000);
      setMaxQpsInput(10000);
    }
    setGearType(val);
  }

  return (
    <div className={styles.content}>
      <Loading visible={isLoading}>
        <div className={styles.contentTitle}>
          <p>集群流控资源配置</p>
        </div>
        <div className={styles.clusterContent}>
          <div className={styles.clusterGearTypeItem}>
            <p className={styles.clusterGearTypeTitle}>集群类型</p>
            <div>
              <RadioGroup
                value={gearType}
                disabled={!isEdit}
                onChange={handleGearTypeChange}
              >
                <Radio id="unTry" value={0}>生产</Radio>
                <Radio id="tryOut" value={1}>试用</Radio>
              </RadioGroup>
            </div>
          </div>
          <div className={styles.clusterItem}>
            <p className={styles.clusterTitle}>量级配置</p>
            <div className={styles.clusterGearbox}>
              <div className={styles.clusterGearlevel}>
                {!gearType && <div className={ isNginx ? styles.clusterRangeNginx : styles.clusterRange}>
                  <Range
                    value={maxQpsInput}
                    min={0}
                    max={isNginx ? 10000 : 100000}
                    step={10000}
                    marks={isNginx ? 1 : 10}
                    disabled={!isEdit}
                    onChange={onMaxQpsChangeInt}
                  />
                  <NumberPicker
                    value={maxQpsInput}
                    min={0}
                    max={isNginx ? 10000 : 100000}
                    step={10000}
                    disabled={!isEdit}
                    editable={false}
                    onChange={onMaxQpsChangeInt}
                  />
                </div>}
                {false && <RadioGroup
                  value={gearlevel}
                  onChange={onRadioChange}
                  disabled={!isEdit}
                >
                  {CLUSTRER_GEARLEVEL(intl).map(item => {
                    return (
                      <Balloon
                        trigger={<Radio value={item.value}>{item.title}</Radio>}
                        closable={false}
                        align={'t'}
                      >
                        <p>档位:&nbsp;<span style={{ color: '#0070cc' }}>{item.title}</span></p>
                        <p>QPS范围:&nbsp;<span style={{ color: '#0070cc' }}>{item.descQps}</span></p>
                        <p>阈值范围:&nbsp;<span style={{ color: '#0070cc' }}>{item.descCount}</span></p>
                      </Balloon>
                    );
                  })}
                </RadioGroup>}
                {!isEdit && <p className={clusterName ? styles.gearConfig : styles.gearConfigHidden}>集群信息：
                  {clusterName ? <>
                    {'最大QPS : '}
                    <span className={styles.gearConfigCount}>{maxQps}</span>
                    {' , 最大阈值 : '}
                    <span className={styles.gearConfigCount}>{maxCount}</span>&nbsp;
                    {clusterName && <span style={{ marginLeft: '8px' }}>
                      <Switch
                        checked={clusterEnable}
                        onChange={onSwitchChange}
                      />
                    </span>}
                    {clusterEnable ? '（档位开启，配置生效中）' : '（档位关闭，配置未生效）'}
                  </> : <span>
                    （请先创建集群配置）
                    {/* <span
                      style={{ color: '#0070CC', cursor: 'pointer' }}
                      onClick={() => handleSaveOrCancelOrEditGearlevel('create')}
                    > 创建集群配置 </span>） */}
                  </span>}
                </p>}
                {clusterName && clusterEnable && <p className={styles.clusterConfig}>
                  集群状态：{renderAssignStatus()}
                </p>}
                <p>
                  注意：
                  {!!gearType && <span style={{ color: '#c30a0a' }}>试用档位仅供测试效果使用，不保证稳定性，请勿在生产环境使用。试用档位不产生额外费用。</span>}
                  <br/>
                  {isPublic && <>
                    <span style={{ color: '#c30a0a' }}>公网环境网络时延较高，仅供测试用，必要时可调整 token client 超时时长。公网集群流控目前暂不额外计费。</span>
                    <br/>
                  </>}
                  集群内需要流控的接口预估的最大 QPS（代表可能到来的最大流量），流量超出该值的部分会退化到单机模式。
                  {/* <Balloon
                    trigger={<span style={{ color: '#0070CC', cursor: 'pointer' }}>（档位建议值范围）</span>}
                    closable={false}
                    align={'r'}
                    shouldUpdatePosition={true}
                    className={styles.gearTips}
                  >
                    <Table dataSource={CLUSTRER_GEARLEVEL} style={{ width: '400px' }}>
                      <Table.Column title="档位" dataIndex="title" />
                      <Table.Column title="QPS范围" dataIndex="descQps" />
                      <Table.Column title="阈值范围" dataIndex="descCount" />
                    </Table>
                  </Balloon> */}
                </p>
              </div>
              <div className={styles.clusterGearBtn}>
                {(!hasCluster ?
                  <Button
                    type="primary"
                    onClick={() => handleSaveOrCancelOrEditGearlevel('create')}
                  >
                  创建
                  </Button> : isEdit ?
                    <>
                      <Button
                        type="primary"
                        onClick={() => handleSaveOrCancelOrEditGearlevel('save')}
                      >
                      保存
                      </Button>
                      <Button
                        onClick={() => handleSaveOrCancelOrEditGearlevel('cancel')}
                      >
                      取消
                      </Button>
                    </> :
                    <Button
                      type="primary"
                      onClick={() => handleSaveOrCancelOrEditGearlevel('edit')}
                    >
                    编辑
                    </Button>)
                }
              </div>
            </div>
          </div>
        </div>
      </Loading>
    </div>
  );
};

export default SystemGuardClusterQps;
