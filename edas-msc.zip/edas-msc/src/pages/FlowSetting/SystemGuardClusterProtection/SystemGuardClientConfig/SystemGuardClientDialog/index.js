import React, { memo, useCallback, useEffect, useMemo, useState } from 'react';
import styles from './index.less';
import { Balloon, Button, Field, Form, Icon, Input, Message } from '@alicloud/console-components';
import { DEFAULT_REQUEST_TIMEOUT, MODIFY_SUCCESS } from '../../../../App/AppDetail/components/common/config/constants/flow';
import services from 'services';
import Cookie from 'js-cookie';
import { useIntl } from '@ali/widget-hooks';

const SystemGuardClientDialog = memo(({ record, onCloseDialog, onChange, appName }) => {
  const intl = useIntl();
  const region = Cookie.get('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const myfield = Field.useField();
  const { init, getValue } = myfield;
  const [ formItemLayout ] = useState({
    labelCol: { span: 6 },
    wrapperCol: { span: 18 },
  });

  useEffect(() => {
    const { AppName: basicAppName = '' } = record;
    if (basicAppName) {
      myfield.setValue('requestTimeout', record.RequestTimeout);
    } else {
      myfield.setValue('requestTimeout', DEFAULT_REQUEST_TIMEOUT);
    }
  }, []);

  const fetchUpdateData = useCallback(async (submitData) => {
    const result = await services.UpdateSentinelClusterClientSettingOfApp({
      params:{
        ...submitData,
        namespace: 'default',
        RegionId: region,
        AhasRegionId: region,
        Namespace: 'default',
        NameSpace: 'default',
      }
    });
    if (result) {
      Message.success({
        content: MODIFY_SUCCESS(intl),
        animation: false,
        style: { marginTop: '50px' },
      });

      onChange();
      onCloseDialog();
    } else {
      Message.error({
        content: result?.msg,
        animation: false,
        style: { marginTop: '50px' },
      });
    }
  }, [ onChange, onCloseDialog ]);

  const handleAddBasicRule = useCallback(() => {
    let isValid = false;

    myfield.validate(errors => {
      if (!errors) {
        isValid = true;
      }
    });

    if (isValid) {
      const submitData = {
        AppName: appName,
        RequestTimeout: Number(getValue('requestTimeout')),
      };
      fetchUpdateData(submitData);
    }
  }, [ fetchUpdateData ]);

  const renderFooter = useMemo(() => {
    return (
      <span className={styles['footer']}>
        <Button
          onClick={handleAddBasicRule}
          type={'primary'}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_add"
        >
          {'确定'}
        </Button>

        <Button
          onClick={onCloseDialog}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_cancel"
        >
          {'取消'}
        </Button>
      </span>
    );
  }, []);

  const hintLayout = useMemo(() => {
    return <Icon type="prompt" size="small" style={{ marginLeft: '5px' }} />;
  }, []);

  return (
    <div className={styles['content']}>
      <Form field={myfield} style={{ maxWidth: '500px' }}>
        <div>
          <Form.Item
            {...formItemLayout}
            label={
              <span>
                {'token 请求超时时间'}
                <Balloon align="r" type="primary" trigger={hintLayout}>
                  <div>
                    <p className={styles['balloonTipsBox']}>
                      Token client 请求 token server 的超时时长，超时会退化到单机模式。对于网络不稳定的场景，超时时长可以适当放大，但注意这也会使 RT 增加。
                    </p>
                  </div>
                </Balloon>
              </span>
            }
          >
            <Input
              placeholder={'数字，0 < x <= 10000，默认 20'}
              addonTextAfter={'ms'}
              trim
              {...init('requestTimeout', {
                rules: [
                  {
                    required: true,
                    message: '不能为空',
                  },
                  {
                    pattern: /^((?!0)[0-9]{1,4}|10000)$/,
                    message: '请输入 (0, 10000] 范围内的数字',
                  },
                ],
              })}
            />
          </Form.Item>
        </div>
      </Form>
      {renderFooter}
    </div>
  );
});

export default SystemGuardClientDialog;

