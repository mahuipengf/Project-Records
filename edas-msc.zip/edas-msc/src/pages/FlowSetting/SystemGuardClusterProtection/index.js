// import ClusterTollDialog from '../common/ClusterTollDialog';
import React from 'react';
import SystemGuardClientConfig from './SystemGuardClientConfig';
import SystemGuardClusterQps from './SystemGuardClusterQps';
// import SystemGuardClusterQpsHide from './SystemGuardClusterQpsHide';
// import { Message } from '@alicloud/console-components';
// import { DEFAULT_BREADCRUMB_ITEM as defaultBreadCrumbItem } from 'config/constants';
// import { getParams } from '@ali/sre-utils';
// import { useDispatch } from '@ali/sre-utils-dva';

const SystemGuardClusterProtection = () => {
  // const isAutoToll = sessionStorage.getItem('isAutoToll') !== 'true';
  // const [ tollDialogVisible, setTollDialogVisible ] = useState(isAutoToll);

  // 集群流控商业化收费详情弹窗
  // function handleChangeTollDialog() {
  //   setTollDialogVisible(!tollDialogVisible);
  // }

  return (
    <div>
      {/* <Message type="notice">
        <span>
          自<span style={{ color: '#0070cc' }}>&nbsp;2021年03月22日&nbsp;</span>
          起，集群流控功能公测期结束，正式开始收费。集群流控功能按应用申请的 QPS 量级收费，点击参考&nbsp;
          <a
            style={{ color: '#0070cc', cursor: 'pointer' }}
            onClick={handleChangeTollDialog}
          >收费方式详情。</a>
        </span>
      </Message>
      <ClusterTollDialog
        tollDialogVisible={tollDialogVisible}
        handleDialogHidden= {handleChangeTollDialog}
      /> */}
      <SystemGuardClusterQps />
      {/* <SystemGuardClusterQpsHide /> */}
      <SystemGuardClientConfig />
    </div>
  );
};

export default SystemGuardClusterProtection;
