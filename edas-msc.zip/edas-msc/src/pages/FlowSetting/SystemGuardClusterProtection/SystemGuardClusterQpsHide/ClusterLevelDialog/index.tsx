import React, { FC, useState } from 'react';
import styles from './index.css';
import { Balloon, Button, Message, Radio } from '@alicloud/console-components';
import { CLUSTRER_GEARLEVEL } from 'config/constants/flow';
import { getParams } from '@ali/sre-utils';
import { useDispatch } from '@ali/sre-utils-dva';

const { Group: RadioGroup } = Radio;

interface IClusterLevel {
  gearlevel: number;
  clusterId: number;
  clusterEnable: boolean;
  onCloseDialog: () => void;
  onChange: () => void;
}

const ClusterLevelDialog: FC<IClusterLevel> = props => {
  const dispatch = useDispatch();
  const appName = getParams('edasAppId') || getParams('appName') || '';
  const { gearlevel = 1, clusterId, clusterEnable = true, onCloseDialog, onChange } = props;
  const [ level, setLevel ] = useState(gearlevel);

  // 档位改变
  function onRadioChange(value: string | number | boolean) {
    setLevel(Number(value));
  }

  // 创建集群qps档位
  async function createCluster() {
    const params = {
      AppName: appName,
      ShareLevel: '',
      MaxClusterQps: 10000,
      Enable: clusterEnable,
      TrialFlag: 0,
    };
    const { Success = false } = await dispatch.flowAppModel.createCluster(params);
    if (Success) {
      Message.success('创建成功');
    }
    onCloseDialog();
    onChange();
  }

  // 编辑qps档位信息
  async function updateCluster() {
    const params = {
      AppName: appName,
      MaxClusterQps: 10000,
      ClusterId: clusterId,
      TrialFlag: 0,
    };
    const { Success = false, Code = '' } = await dispatch.flowAppModel.updateCluster(params);
    if (Code === 'sentinel.cluster.quota.insufficient') {
      Message.error('设置档位不可小于该应用所在集群已有规则的总QPS');
    } else if (Success) {
      Message.success('保存成功');
    }
    onCloseDialog();
    onChange();
  }

  // 渲染footer
  const renderFooter = () => {
    return (
      <span className={styles.footer}>
        <Button
          onClick={clusterId ? updateCluster : createCluster}
          type={'primary'}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_add"
        >
          {clusterId ? '保存' : '创建'}
        </Button>

        <Button
          onClick={onCloseDialog}
          data-spm-click="gostr=/aliyun;locaid=d_SystemGuardSystemRules_rule_cancel"
        >
          {'取消'}
        </Button>
      </span>
    );
  };

  return (
    <>
      <div className={styles.content}>
        <p className={styles.clusterTitle}>最大 QPS 档位</p>
        <div className={styles.clusterGearbox}>
          <div className={styles.clusterGearlevel}>
            <RadioGroup
              value={level}
              onChange={onRadioChange as any}
            >
              {CLUSTRER_GEARLEVEL().map(item => {
                return (
                  <Balloon
                    trigger={<Radio value={item.value}>{item.title}</Radio>}
                    closable={false}
                    align={'t'}
                  >
                    <p>档位:&nbsp;<span style={{ color: '#0070cc' }}>{item.title}</span></p>
                    <p>QPS范围:&nbsp;<span style={{ color: '#0070cc' }}>{item.descQps}</span></p>
                    <p>阈值范围:&nbsp;<span style={{ color: '#0070cc' }}>{item.descCount}</span></p>
                  </Balloon>
                );
              })}
            </RadioGroup>
          </div>
        </div>
      </div>
      {renderFooter()}
    </>
  );
};

export default ClusterLevelDialog;
