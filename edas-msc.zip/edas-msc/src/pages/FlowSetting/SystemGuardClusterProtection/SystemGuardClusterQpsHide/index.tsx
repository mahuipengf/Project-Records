import ClusterLevelDialog from './ClusterLevelDialog';
import React, { FC, useEffect, useState } from 'react';
import styles from './index.css';
import { Balloon, Dialog, Icon, Loading, Message, Switch, Table } from '@alicloud/console-components';
import { CLISTER_STATUS, CLUSTRER_GEARLEVEL } from 'config/constants/flow';
import { getParams } from '@ali/sre-utils';
import { useDispatch } from '@ali/sre-utils-dva';

const SystemGuardClusterQpsHide: FC = () => {
  const appName = getParams('edasAppId') || getParams('appName') || '';
  const dispatch = useDispatch();
  const [ isLoading, setIsLoading ] = useState<boolean>(true);
  const [ gearlevel, setGearlevel ] = useState<number>(1);
  const [ clusterId, setClusterId ] = useState(0);
  const [ maxQps, setMaxClusterQps ] = useState(0);
  const [ maxCount, setMaxThresholdCount ] = useState(0);
  const [ clusterName, setClusterName ] = useState('');
  const [ clusterEnable, setClusterEnable ] = useState(true);
  const [ clusterDetail, setClusterDetail ] = useState<any>([]);
  const [ dialogClusterLevel, setDialogClusterLevel ] = useState<boolean>(false);
  const [ assignStatus, setAssignStatus ] = useState<number>(-1);

  useEffect(() => {
    getClusterDetail();
  }, []);

  // 获取qps档位信息
  async function getClusterDetail() {
    setIsLoading(true);
    const { Data = {}, Success = false } = await dispatch.flowAppModel.getClusterDetail({ AppName: appName });
    const { ClusterConfig = {}, AssignStatus = -1 } = Data;
    const { MaxClusterQps = 10000, MaxThresholdCount = 5000, Id, ClusterQpsLevel = 1, Enable = false } = ClusterConfig;
    if (Success && Id) {
      ClusterConfig.AssignStatus = AssignStatus;
      setAssignStatus(AssignStatus);
      setClusterDetail([ ClusterConfig ]);
      setGearlevel(ClusterQpsLevel);
      setClusterId(Id);
      setMaxClusterQps(MaxClusterQps);
      setMaxThresholdCount(MaxThresholdCount);
      const selectCluster = (ClusterQpsLevel >= 1 && ClusterQpsLevel <= 5) ? CLUSTRER_GEARLEVEL.filter(val => val.value === ClusterQpsLevel) : [{ title: '_OUT' }];
      const clusterName = selectCluster[0]?.title;
      setClusterName(clusterName);
      setClusterEnable(Enable);
    }
    setIsLoading(false);
  }

  // 档位状态改变
  function onSwitchChange(checked: boolean) {
    const dialogType = checked ? '开启' : '关闭';
    clusterName && Dialog.confirm({
      title: '温馨提示',
      content: (
        <span>
          {'是否确定 '}
          <span style={{ color: '#0070cc' }}>{dialogType}</span>
          {' 档位：'}
          <span style={{ color: '#0070cc' }}>{clusterName}</span>
          {' ( 最大QPS : '}
          <span style={{ color: '#0070cc' }}>{maxQps}</span>
          {' , 最大阈值 : '}
          <span style={{ color: '#0070cc' }}>{maxCount}</span>
          {' ) 配置？'}
        </span>
      ),
      onOk: () => handleOpenOrCloseCluster(checked),
    });
  }

  // 开启、关闭档位设置
  async function handleOpenOrCloseCluster(checked: boolean) {
    const dialogType = checked ? '开启' : '关闭';
    const params = { ClusterId: clusterId };
    const { Success = false, Code = '' } = checked ? await dispatch.flowAppModel.setClusteron(params) : await dispatch.flowAppModel.setClusteroff(params);
    if (Code === 'sentinel.cluster.rule.exist') {
      Message.warning('集群流控规则生效中，不可关闭集群');
    } else if (Success) {
      getClusterDetail();
      Message.success(`${dialogType}成功`);
    } else {
      Message.error(`${dialogType}失败，请重试`);
    }
  }


  // 渲染档位
  const renderclusterName = (level: number) => {
    const selectCluster = (level >= 1 && level <= 5) ? CLUSTRER_GEARLEVEL.filter(val => val.value === level) : [{ title: '_OUT' }];
    const clusterName = selectCluster[0]?.title;
    return (<span>{clusterName !== '_OUT' ? clusterName : '--'}</span>);
  };

  // 渲染集群档位状态
  const renderEnable = (enable: boolean) => {
    return (
      <Switch
        checked={enable}
        onChange={() => onSwitchChange(!enable)}
      />
    );
  };

  // 渲染集群状态
  const renderOpt = () => {
    return (
      <div className={styles.basicOpt}>
        <span onClick={clusterLevelConfigChange}>
          <Icon type="edit" size="xs" /> &nbsp;
          <span>{'编辑'}</span>
        </span>
      </div>
    );
  };

  // 渲染无集群配置提示
  const renderEmptyContent = () => {
    return (
      <span>
        暂无集群流控资源配置，
        <span
          style={{ color: '#0070CC', cursor: 'pointer' }}
          onClick={clusterLevelConfigChange}
        > 点此创建 </span>
      </span>
    );
  };

  // 渲染集群状态
  const renderAssignStatus = (val: number) => {
    let textColor = '#333333';
    switch (assignStatus) {
      case 0: textColor = '#0070cc';
        break;
      case 1: textColor = '#0070cc';
        break;
      case 2: textColor = '#009900';
        break;
      case 5: textColor = '#d93026';
        break;
      default: textColor = '#333333';
    }

    return (
      <span style={{ color: textColor }}>{CLISTER_STATUS[val] || '未知'}</span>
    );
  };

  // 集群档位配置弹窗
  function clusterLevelConfigChange() {
    if (assignStatus !== 2) {
      Message.warning('资源分配未完成，请稍后再试');
    } else {
      setDialogClusterLevel(!dialogClusterLevel);
    }
  }

  return (
    <div className={styles.content}>
      <Loading visible={isLoading}>
        <div className={styles.contentTitle}>
          <p>集群流控资源配置</p>
          {/* <Balloon
            trigger={<Icon type="help" size="small" />}
            closable={false}
            align={'r'}
          >
            <span>
              集群流控资源配置
            </span>
          </Balloon> */}
        </div>

        <div>
          <Message style={{ marginBottom: '8px' }} type="notice">
            <span>
              集群内需要流控的接口预估的最大 QPS（代表可能到来的最大流量）,流量超出该值的部分会退化到单机模式。
              <Balloon
                trigger={<span style={{ color: '#0070CC', cursor: 'pointer' }}>（档位建议值范围）</span>}
                closable={false}
                align={'r'}
                shouldUpdatePosition={true}
                className={styles.gearTips}
              >
                <Table dataSource={CLUSTRER_GEARLEVEL} style={{ width: '400px' }}>
                  <Table.Column title="档位" dataIndex="title" />
                  <Table.Column title="QPS范围" dataIndex="descQps" />
                  <Table.Column title="阈值范围" dataIndex="descCount" />
                </Table>
              </Balloon>
            </span>
          </Message>
          <Table
            dataSource={clusterDetail}
            loading={isLoading}
            hasBorder={false}
            emptyContent={renderEmptyContent()}
          >
            {clusterName !== '_OUT' && <Table.Column
              title="档位"
              dataIndex="ClusterQpsLevel"
              cell={renderclusterName}
              align={'center'}
            />}
            <Table.Column
              title="最大QPS"
              dataIndex="MaxClusterQps"
              cell={(val: number) => val || 10000}
              align={'center'}
            />
            <Table.Column
              title="最大阈值"
              dataIndex="MaxThresholdCount"
              cell={(val: number) => val || 5000}
              align={'center'}
            />
            {clusterName !== '_OUT' && clusterEnable && <Table.Column
              title="集群状态"
              dataIndex="AssignStatus"
              // cell={(status: number) => CLISTER_STATUS[status] || '未知'}
              cell={renderAssignStatus}
              align={'center'}
            />}
            {clusterName !== '_OUT' && <Table.Column
              title="档位状态"
              dataIndex="Enable"
              cell={renderEnable}
              align={'center'}
            />}
            {clusterName !== '_OUT' && <Table.Column
              title="操作"
              align={'center'}
              dataIndex="Id"
              cell={renderOpt}
            />}
          </Table>
        </div>
      </Loading>
      <Dialog
        visible={dialogClusterLevel}
        footer={<div />}
        onClose={clusterLevelConfigChange}
        title={'集群流控档位配置'}
        style={{ width: '510px' }}
      >
        <ClusterLevelDialog
          gearlevel={gearlevel}
          clusterId={clusterId}
          clusterEnable={clusterEnable}
          onCloseDialog={clusterLevelConfigChange}
          onChange={getClusterDetail}
        />
      </Dialog>
    </div>
  );
};

export default SystemGuardClusterQpsHide;
