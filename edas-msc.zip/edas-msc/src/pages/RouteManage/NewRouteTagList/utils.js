import { get, forEach, isEmpty } from 'lodash';

const mapRouteRules = (tagItemValue) => {
  const RouteRules = get(tagItemValue, 'RouteRules', []);
  const AppId = get(tagItemValue, 'AppId');
  const Region = get(tagItemValue, 'Region');
  const params = {
    AppId,
    Region,
    Rules: {},
  };
  forEach(RouteRules, item => {
    const Rule = get(item, 'Rules[0]', {});
    if (!isEmpty(Rule)) {
      const protocol = Rule.protocol === 'springCloud' ? 'springcloud' : Rule.protocol;
      const conditionsKey = Rule.protocol === 'springCloud' ? 'restItems' : 'argumentItems';
      params.Rules[item.Tag] = {
        ...item,
        Rules: {
          [protocol]: [{
            ...Rule,
            [conditionsKey]: Rule.conditions
          }]
        }
      };
    } else {
      params.Rules[item.Tag] = {
        ...item,
        Rules: {}
      };
    }
  });
  return params;
};

const newMapRouteRules = tagItemValue => {
  const RouteRules = get(tagItemValue, 'RouteRules', []);
  const AppId = get(tagItemValue, 'AppId');
  const Region = get(tagItemValue, 'Region');
  const params = {
    AppId,
    Region,
    Rules: {},
  };
  forEach(RouteRules, item => {

    const Rules = get(item, 'Rules', {});
    const rules = {};
    const springCloud = [];
    const dubbo = [];
    forEach(Rules, Rule => {
      if (!isEmpty(Rule)) {
        if (Rule.protocol === 'springCloud') {
          springCloud.push(Rule);
          rules[`${Rule.protocol.toLocaleLowerCase()}`] = springCloud;
        } else if (Rule.protocol === 'dubbo') {
          dubbo.push(Rule);
          rules[`${Rule.protocol.toLocaleLowerCase()}`] = dubbo;
        }
      } else {
        rules[`${Rule.protocol.toLocaleLowerCase()}`] = [];
      }
    });
    params.Rules[item.Tag] = {
      ...item,
      Rules: {
        ...rules,
      },
    };
  });
  return params;
};

export {
  mapRouteRules,
  newMapRouteRules,
};
