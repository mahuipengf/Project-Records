import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { Message, Pagination, Loading } from '@alicloud/console-components';
import services from 'services';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE, WIDGET_ID } from 'constants';
import Search from './components/Search';
import { map, uniqueId, get, sum, isEmpty } from 'lodash';
import TagItem from './components/TagItem';
import { mapConditions } from 'utils';
import { modelDecorator, Empty } from '@ali/cn-design';
import Masonry from 'react-masonry-component';
import './index.less';
import RoleHoc from 'containers/RoleHoc';

const NewRouteTagList = ({ toggleModal, isShowMessage }) => {
  const [component] = useGlobalState('component');
  const intl = useIntl();
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [searchValues] = useGlobalState('searchValues');
  const [loading, setLoading] = useState(false);
  const [onBottom, setOnBottom] = useState(false);
  const [data, setData] = useState({
    TotalSize: 0,
    Result: [],
  });
  const [searchs, setSearchs] = useState({
    PageNumber: 1,
    PageSize: 10,
    ...searchValues,
  });
  const [eventEmitter] = useGlobalState('eventEmitter');

  useEffect(() => {
    ListApplicationsWithTagRules();
  }, [searchs, refreshIndex]);

  // 页脚悬浮设置
  useEffect(() => {
    document.getElementById('mse-page-content') && document.getElementById('mse-page-content').addEventListener('scroll', diffFooter);
    window.addEventListener('resize', diffFooter);
    return () => {
      document.getElementById('mse-page-content') && document.getElementById('mse-page-content').removeEventListener('scroll', diffFooter);
      window.removeEventListener('resize', diffFooter);
    };
  }, []);

  const diffFooter = () => {
    if (component === 'AppInfo') return;
    const dom = document.getElementById('mse-page-content');
    if (!dom) return;
    const marginBottom = dom.scrollHeight - dom.scrollTop - dom.clientHeight;
    if (marginBottom > 0 && !onBottom) {
      setOnBottom(true);
    } else {
      setOnBottom(false);
    }
  };

  const ListApplicationsWithTagRules = async () => {
    setLoading(true);
    const res = await services.ListApplicationsWithTagRules({
      params: searchs,
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      }
    });
    setLoading(false);
    const TotalSize = get(res, 'TotalSize', 0);
    const Result = get(res, 'Result', []);
    const newData = {
      TotalSize,
      Result: map(Result, item => ({
        ...item,
        uid: uniqueId(),
        Region: item.Region || searchValues.regionId,
        RouteRules: mapRouteRules(item.RouteRules),
      }))
    };
    setData(newData);
    diffFooter();
  };

  const mapRouteRules = (list = []) => {
    const total = sum(map(list, item => item.InstanceNum || 0));
    let totalRate = 0;
    return map(list, (item, index) => {
      const springCloud = get(item, 'Rules.springcloud', []);
      const dubbo = get(item, 'Rules.dubbo', []);
      const ScRule = map(springCloud, child => ({
        ...child,
        uid: uniqueId(),
        conditions: mapConditions(child.restItems),
        restItems: mapConditions(child.restItems),
        protocol: 'springCloud',
      }));
      const dubboRule = map(dubbo, child => {
        const { serviceName = '', version = '', group = '', methodName = '', paramTypes = [] } = child;
        return ({
          ...child,
          method: `${serviceName}:${version}:${group}:${methodName}:${paramTypes}`,
          uid: uniqueId(),
          conditions: mapConditions(child.argumentItems),
          argumentItems: mapConditions(child.argumentItems),
          protocol: 'dubbo',
        });
      });
      const Rules = [...ScRule, ...dubboRule];
      if (index < list.length - 1) {
        const InstanceRate = item.InstanceRate === undefined ? Math.round(((item.InstanceNum || 0) * 100 / total)) : item.InstanceRate;
        totalRate += InstanceRate;
        return ({
          ...item,
          uid: uniqueId(),
          InstanceRate: total === 0 ? 0 : InstanceRate,
          Rules,
        });
      }
      return ({
        ...item,
        uid: uniqueId(),
        InstanceRate: item.InstanceNum === 0 ? 0 : 100 - totalRate,
        Rules,
      });
    });
  };

  const handlePageNumberChange = (PageNumber) => {
    setSearchs({ ...searchs, PageNumber });
  };

  const handlePageSizeChange = (PageSize) => {
    setSearchs({ ...searchs, PageSize });
  };

  const handleSearchChange = (params) => {
    setSearchs({ ...searchs, ...params });
  };

  const handleChangeTagItem = (val) => {
    const Result = get(data, 'Result', []);
    const newResult = map(Result, item => item.uid === val.uid ? ({ ...item, ...val }) : item);
    setData({ ...data, Result: newResult });
  };

  const styles2 = {
    display: 'flex',
    padding: '8px 0px 16px',
    flexFlow: 'row-reverse',
    background: '#fff',
    borderBottom: '1px solid #ddd',
    position: 'sticky',
    bottom: 0,
    boxShadow: '0 0 10px #ddd'
  };
  const styles1 = {
    display: 'flex',
    padding: '8px 0px 16px',
    flexFlow: 'row-reverse',
    background: '#fff',
  };

  const goToRocketMQRoute = async () => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-fullLinkGrayscalekHome`);
  };
  return (
    <React.Fragment>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && !IS_ENV_PRIVATE && (searchValues.protocol === 'SPRING_CLOUD' || searchValues.protocol === 'DUBBO')}>
        <Message type="warning" style={{ marginBottom: 16 }}>
          {
            intl.html(searchValues.protocol === 'SPRING_CLOUD' ? 'widget.route_tag.sc_label' : 'widget.route_tag.dubbo_label')
          }
        </Message>
      </If>
      <If condition={isShowMessage}>
        <Message type="notice" style={{ marginBottom: 16 }}>
          {intl('widget.msc.fulllink.grayscale_tag_value.msg1')}<span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={() => goToRocketMQRoute()}>{intl('widget.app.new_canary_support.push_full_link_grayscale')}</span>{intl('widget.msc.fulllink.grayscale_tag_value.msg2')}
        </Message>
      </If>
      <div className="new-route-tag">
        <If condition={component === 'NewRouteTagList'}>
          <Search onSearch={handleSearchChange} />
        </If>
        <div id="new-route-tag-list" >
          <Loading visible={loading} style={{ width: '100%' }}>
            <If condition={!isEmpty(data.Result)}>
              <Masonry
                style={{ margin: '0px -8px 16px -8px' }}
                className="masonry-container" // default ''
                elementType={'div'} // default 'div'
                options={{}} // default {}
                disableImagesLoaded={false} // default false
                updateOnEachImageLoad={false} // default false and works only if disableImagesLoaded is false
              >
                <For each="item" index="index" of={data.Result}>
                  <div key={item.uid} style={{ margin: '0px 8px 16px', width: component === 'AppGovernance' || component === 'AppDetail' ? 'calc(100% - 16px)' : 'calc(50% - 16px)', border: '1px solid #eee' }}>
                    <TagItem
                      value={item || {}}
                      onChange={handleChangeTagItem}
                      toggleModal={toggleModal}
                      setRefreshIndex={setRefreshIndex}
                    />
                  </div>
                </For>
              </Masonry>
            </If>
            <If condition={isEmpty(data.Result)}>
              <Empty showIcon />
            </If>
          </Loading>
        </div>
        <If condition={component !== 'AppGovernance' || component !== 'AppDetail'}>
          <div style={onBottom ? styles2 : styles1}>
            <Pagination
              defaultCurrent={1}
              onChange={handlePageNumberChange}
              onPageSizeChange={handlePageSizeChange}
              total={data.TotalSize}
              pageSize={searchs.PageSize}
              current={searchs.PageNumber}
              pageSizeList={[5, 10, 20]}
              pageSizeSelector="dropdown"
              totalRender={() =>
                intl('widget.service.totalcount', { total: data.TotalSize })}
            />
          </div>
        </If>
      </div>
    </React.Fragment>
  );
};

NewRouteTagList.propTypes = {
  toggleModal: PropTypes.func,
  isShowMessage: PropTypes.bool,
};

export default RoleHoc(modelDecorator(NewRouteTagList));

