import React from 'react';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import { Empty, CopyContent, Button } from '@ali/cn-design';
import DataFields from 'components/DataFields';
import RouteInfo from 'containers/RouteInfo';
import { head, map } from 'lodash';
import { mapConditions } from 'utils';
import AppInstance from '../../../RouteTagList/components/RouteInfo/AppInstance';

const TagItemInfo = (props) => {
  const { value, handleEdit, handleRemove } = props;
  const intl = useIntl();

  const items = [
    {
      dataIndex: 'Name',
      label: intl('widget.authentication.rule_name'),
      visible: true,
      render: (val) => <Empty value={val}>{val}</Empty>
    },
    {
      dataIndex: 'AppName',
      label: intl('widget.common.app_name'),
      visible: true,
      render: (val) => <CopyContent text={val}>{val}</CopyContent>
    },
    {
      dataIndex: 'Tag',
      label: intl('widget.route.tag'),
      visible: !value.isIstioApp,
    },
    {
      dataIndex: 'CarryData',
      label: intl('widget.route.link_delivery'),
      visible: !value.isIstioApp,
      render: val => val ? intl('widget.common.yes') : intl('widget.common.no'),
    },
    {
      dataIndex: 'Enable',
      label: intl('widget.route.flow_state'),
      visible: !value.isIstioApp,
      render: val => val ? intl('widget.common.opened') : intl('widget.common.closed'),
    },
    {
      dataIndex: 'AppId',
      label: intl('widget.route.app_instance'),
      visible: !value.isIstioApp,
      render: (val, record) => (
        <AppInstance
          appId={val}
          tag={record.Tag}
          namespaces={{ region: record.Region }}
        />
      ),
      span: 24,
    },
  ];

  const newRule = map(value.Rules || [], item => ({ ...item, conditions: mapConditions(item.protocol === 'springCloud' ? item.restItems || [] : item.argumentItems || [], intl) }));

  return (
    <React.Fragment>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h4 className="common-title" style={{ width: 144, marginTop: 8 }}>{intl('widget.common.basic_info')}</h4>
          <div>
            <Button type="primary" onClick={handleEdit} style={{ marginRight: 8 }}>{intl('widget.common.edit')}</Button>
            <Button type="normal" warning onClick={handleRemove}>{intl('widget.common.delete')}</Button>
          </div>
        </div>
        <DataFields
          dataSource={value}
          items={items}
        />
        <h4 className="common-title" style={{ marginTop: 16 }}>
          {intl('widget.route.business_flow')}
        </h4>
        <RouteInfo
          value={{
            triggerPolicy: head(value.Rules) ? head(value.Rules).triggerPolicy : '',
            rules: newRule
          }}
        />
      </div>
    </React.Fragment>
  );
};

TagItemInfo.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  handleEdit: PropTypes.func,
  handleRemove: PropTypes.func,
};

export default TagItemInfo;
