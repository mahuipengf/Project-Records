import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Field } from '@alicloud/console-components';
import { Table, Button, NumberPicker, Loading, Balloon, Icon, CopyContent } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import { size, map, values, sum, includes } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import TagItemInfo from '../TagItemInfo';
import TagItemEdit from '../TagItemEdit';
import services from 'services';
import { mapRouteRules } from '../../utils';
import { mapConditionsFormData } from 'utils';

const TagItem = (props) => {
  const field = Field.useField();
  const intl = useIntl();
  const { value, onChange, toggleModal, setRefreshIndex } = props;
  const { init, validate, getValue, getValues } = field;
  const [isEdit, setIsEdit] = useState(false);
  const [loading, setLoading] = useState(false);
  const [tagItemValue, setTagItemValue] = useState({});
  const editForm = useRef(null);
  const [component] = useGlobalState('component');
  const [show100Hint, setShow100Hint] = useState(false);

  useEffect(() => {
    setTagItemValue(value);
  }, [value, isEdit]);

  useEffect(() => {
    const res = isEdit && (includes(values(getValues()), undefined) || sum(values(getValues())) !== 100);
    setShow100Hint(res);
  }, [getValues()]);

  const handleSubmit = () => {
    validate(async (errors) => {
      if (errors) return;
      setLoading(true);
      const newData = {
        ...tagItemValue,
        RouteRules: map(tagItemValue.RouteRules || [], item => ({
          ...item,
          Rules: map(item.Rules, child => {
            const { method, ...rest } = child;
            return ({
              ...rest,
              conditions: mapConditionsFormData(child.conditions || [], child.protocol),
            });
          })
        }))
      };
      const params = mapRouteRules(newData);
      await services.ApplyTagPolicies({
        params,
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      setLoading(false);
      setIsEdit(false);
      onChange && onChange(tagItemValue);
    });
  };

  const handleChange = (uid, obj) => {
    const newData = map(tagItemValue.RouteRules || [], item => item.uid === uid ? ({ ...item, ...obj }) : item);
    const newValue = {
      ...tagItemValue,
      RouteRules: newData
    };
    setTagItemValue(newValue);
  };

  const handleOpenInfo = (record = {}) => {
    toggleModal({
      type: 'slide',
      size: 'large',
      visible: true,
      title: intl('widget.authentication.info'),
      content: (
        <TagItemInfo
          value={{
            AppId: value.AppId,
            AppName: value.AppName,
            Region: value.Region,
            ...record,
          }}
          handleEdit={() => handleEdit({
            AppId: value.AppId,
            AppName: value.AppName,
            Region: value.Region,
            ...record,
          })}
          handleRemove={() => handleRemove(record)}
        />
      ),
    });
  };

  const handleEdit = (record = {}) => {
    toggleModal({
      size: 'xl',
      type: 'slide',
      visible: true,
      title: record.Id ? intl('widget.route.tag.edit') : intl('widget.route.tag.create'),
      content: (
        <TagItemEdit
          ref={editForm}
          setRefreshIndex={setRefreshIndex}
          value={{
            AppId: value.AppId,
            AppName: value.AppName,
            Region: value.Region,
            ...record,
          }}
          allData={value}
        />
      ),
      onConfirm: () => editForm.current.handleSubmit(),
    });
  };

  const handleRemove = (val) => {
    const RouteRules = map(value.RouteRules || [], item => item.Tag === val.Tag ? { ...item, remove: true } : item);
    const newData = {
      ...value,
      RouteRules: map(RouteRules, item => ({
        ...item,
        Rules: map(item.Rules, child => {
          const { method, ...rest } = child;
          return ({
            ...rest,
            conditions: mapConditionsFormData(child.conditions || [], child.protocol),
          });
        })
      }))
    };
    const params = mapRouteRules(newData);
    DialogAlert({
      title: intl('widget.common.tips'),
      content: intl.html('widget.common.delete_confirm', { name: val.Name }),
      onOk: async () => {
        await services.ApplyTagPolicies({
          params,
          customErrorHandle: (err, response, callback) => {
            callback();
          }
        });
        toggleModal({ visible: false });
        setRefreshIndex(Date.now());
      },
      footerActions: ['ok', 'cancel']
    });
  };

  const columns = (n) => [
    {
      key: 'Tag',
      title: intl('widget.route.tag_n', { n }),
      dataIndex: 'Tag',
      cell: (val, index, record) => {
        const color = ['110, 132, 159', '117,100,164', '156, 116, 113', '161,154,109', '109,156,101'];
        const i = index % 5;
        return (
          <div >
            <If condition={record.Status === 0}>
              <span
                style={{
                  color: `rgba(${color[i]}, 0.9)`,
                  background: `rgba(${color[i]}, 0.1)`,
                  padding: '4px 8px',
                  borderRadius: 10,
                }}
              >
                {val === '_base' ? intl('widget.app.canary_no_tag') : val}
              </span>
            </If>
            <If condition={record.Status === 1}>
              <span
                style={{
                  color: `rgba(${color[i]}, 0.9)`,
                  background: `rgba(${color[i]}, 0.1)`,
                  padding: '4px 8px',
                  borderRadius: 10,
                }}
              >
                {val === '_base' ? intl('widget.app.canary_no_tag') : val}
              </span>
              <span> {intl('widget.common.brackets', { text: intl('widget.route.has_canary_rule') })}</span>
              <Balloon
                align="t"
                trigger={<Icon type="help" style={{ color: '#777', cursor: 'pointer' }} />}
                closable={false}
              >
                <span>{intl('widget.route.delete_canary_to_use_tag')}</span>
              </Balloon>
            </If>
            <If condition={record.Status === 2}>
              <span
                style={{
                  color: `rgba(${color[i]}, 0.9)`,
                  background: `rgba(${color[i]}, 0.1)`,
                  padding: '4px 8px',
                  borderRadius: 10,
                }}
              >
                {val === '_base' ? intl('widget.app.canary_no_tag') : val}
              </span>
              <span>{intl('widget.common.brackets', { text: intl('widget.common.error') })}</span>
              <Balloon
                align="t"
                trigger={<Icon type="help" style={{ color: '#777', cursor: 'pointer' }} />}
                closable={false}
              >
                <span>{intl('widget.route.data_error_contact_admin')}</span>
              </Balloon>
            </If>
            <If condition={record.Status === 3}>
              <span
                style={{
                  color: `rgba(${color[i]}, 0.9)`,
                  background: `rgba(${color[i]}, 0.1)`,
                  padding: '4px 8px',
                  borderRadius: 10,
                }}
              >
                {val === '_base' ? intl('widget.app.canary_no_tag') : val}
              </span>
              <span>{intl('widget.common.brackets', { text: intl('widget.common.deleted') })}</span>
              <Balloon
                align="t"
                trigger={<Icon type="help" style={{ color: '#777', cursor: 'pointer' }} />}
                closable={false}
              >
                <span>{intl('widget.route.deleted_tag_and_change_again')}</span>
              </Balloon>
            </If>
          </div>
        );
      },
    },
    {
      key: 'Rate',
      title: intl('widget.route.flow_rate'),
      dataIndex: 'Rate',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={!isEdit}>
            <div style={{ lineHeight: '24px' }}>{`${val || 0}%`}</div>
          </If>
          <If condition={isEdit}>
            <NumberPicker
              {...init(`Rate-${record.uid}`, {
                initValue: val,
                rules: [{ required: true }],
                props: {
                  onChange: (v) => handleChange(record.uid, { Rate: v })
                }
              })}
              style={{ marginRight: 8 }}
              max={100}
              min={0}
              state={getValue(`Rate-${record.uid}`) === undefined ? 'error' : ''}
              size="small"
              placeholder="0~100"
            />
            %
          </If>
        </React.Fragment>
      ),
    },
    {
      key: 'InstanceNum',
      title: intl('widget.route.instance_number_rate'),
      dataIndex: 'InstanceNum',
      cell: (val, index, record) => `${val}（${record.InstanceRate}%）`,
    },
    {
      key: 'Status',
      title: intl('widget.route.business_flow'),
      dataIndex: 'Status',
      cell: (val, index, record) => (
        <React.Fragment>
          <If condition={hasMoreOneTag}>
            <If condition={val === 0}>
              <If condition={record.Name}>
                <span className="link-primary" style={{ color: `${record.Enable ? '' : '#777'}` }} onClick={() => handleOpenInfo(record)}>
                  {record.Name}
                </span>
              </If>
              <If condition={!record.Name}>
                <span style={{ marginRight: 8, color: '#777' }}>{intl('widget.common.none')}</span>
                <span className="link-primary" onClick={() => handleEdit(record)}>
                  {intl('widget.common.add')}
                </span>
              </If>
            </If>
            <If condition={val === 1}>
              <span style={{ color: '#777' }}>{record.Name || intl('widget.common.none')}</span>
            </If>
            <If condition={val === 2}>
              <span style={{ color: '#777' }}>{record.Name || intl('widget.common.none')}</span>
            </If>
            <If condition={val === 3}>
              <If condition={record.Name}>
                <span style={{ marginRight: 8, color: '#777' }}>
                  {record.Name}
                </span>
                <span className="link-primary" onClick={() => handleRemove(record)}>{intl('widget.common.delete')}</span>
              </If>
              <If condition={!record.Name}>
                <span style={{ marginRight: 8, color: '#777' }}>{intl('widget.common.none')}</span>
              </If>
            </If>
          </If>
          <If condition={!hasMoreOneTag}>
            <span style={{ color: '#777' }}>{record.Name || intl('widget.common.none')}</span>
          </If>
        </React.Fragment>
      ),
    },
  ];

  const hasMoreOneTag = useMemo(() => {
    return size(value.RouteRules || []) > 1;
  }, [value]);

  return (
    <React.Fragment>
      <Loading visible={loading} style={{ width: '100%', position: 'relative' }}>
        <div
          style={{
            background: '#F7F7F7',
            padding: '8px 16px',
            lineHeight: '32px',
            borderBottom: '1px solid #eee',
            display: 'flex',
            alignContent: 'center',
            justifyContent: 'space-between'
          }}
        >
          <div>
            <If condition={component !== 'AppInfo'}>
              <CopyContent text={value.AppName}>{value.AppName}</CopyContent>
            </If>
          </div>
          <If condition={!isEdit}>
            <If condition={sum(map(value.RouteRules || [], item => item.InstanceNum || 0)) === 0 || !hasMoreOneTag}>
              <Balloon
                align="t"
                trigger={
                  <span>
                    <span style={{ color: '#777' }}>{intl('widget.route.flow_distribution')}</span>
                    <Icon type="help" style={{ color: '#777', cursor: 'pointer', marginLeft: 4 }} />
                  </span>
                }
                closable={false}
              >
                <span>{intl.html('widget.route.app_no_instance_can_not_operating', { name: value.AppName })}</span>
              </Balloon>
            </If>
            <If condition={sum(map(value.RouteRules || [], item => item.InstanceNum || 0)) !== 0 && hasMoreOneTag}>
              <span className="link-primary" onClick={() => setIsEdit(true)}>{intl('widget.route.flow_distribution')}</span>
            </If>
          </If>
          <If condition={isEdit}>
            <div>
              <If condition={includes(values(getValues()), undefined) || sum(values(getValues())) !== 100}>
                <Balloon
                  align="t"
                  trigger={
                    <Button
                      size="small"
                      type="secondary"
                      style={{ marginRight: 16 }}
                      onClick={() => handleSubmit()}
                      disabled
                    >{intl('widget.common.save')}</Button>
                  }
                  triggerType="hover"
                >
                  {intl('widget.route.tag.flow_not_100_can_not_change')}
                </Balloon>
              </If>
              <If condition={includes(values(getValues()), undefined) || sum(values(getValues())) === 100}>
                <Button
                  size="small"
                  type="secondary"
                  style={{ marginRight: 16 }}
                  onClick={() => handleSubmit()}
                >{intl('widget.common.save')}</Button>
              </If>
              <span
                className="link-primary"
                onClick={() => setIsEdit(false)}
              >{intl('widget.common.cancel')}</span>
            </div>
          </If>
        </div>
        <Table dataSource={value.RouteRules || []} hasBorder={false} >
          <For each="column" index="index" of={columns(size(value.RouteRules || []))}>
            <Table.Column {...column} />
          </For>
        </Table>
        <If condition={show100Hint}>
          <span style={{ color: 'red', paddingLeft: 16, position: 'absolute' }}>{intl('widget.route.tag.flow_not_100_can_not_change')}</span>
        </If>
      </Loading>
    </React.Fragment >
  );
};

TagItem.propTypes = {
  onChange: PropTypes.func,
  toggleModal: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
  setRefreshIndex: PropTypes.func,
};

export default TagItem;
