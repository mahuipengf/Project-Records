import React from 'react';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import { Search as SearchComp, Icon, Button } from '@alicloud/console-components';

const Search = (props) => {
  const { onSearch } = props;
  const intl = useIntl();

  const handleSearch = (value, filterValue) => {
    onSearch({ [filterValue]: value, PageNumber: 1 });
  };

  const onFilterChange = (value) => {
    console.log(value);
  };

  const filter = [
    {
      label: intl('widget.route.app_name'),
      value: 'AppName',
    },
  ];

  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
      <SearchComp
        shape="simple"
        onSearch={handleSearch}
        filter={filter}
        onFilterChange={onFilterChange}
        defaultFilterValue="AppName"
        followTrigger
      />
      <Button onClick={() => onSearch({ PageNumber: 1 })}>
        <Icon type="refresh" />
      </Button>
    </div>
  );
};

Search.propTypes = {
  onSearch: PropTypes.func,
};

export default Search;

