import React, { useImperativeHandle, useEffect, useRef, useState, forwardRef } from 'react';
import PropTypes from 'prop-types';
import { Form, Message } from '@ali/cn-design';
import { Input, Loading, Switch, Balloon, Icon, Field } from '@alicloud/console-components';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { forEach, map, get, isEmpty, head, split } from 'lodash';
import { NNAME_PATTERN, MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';
import AppInstance from '../../../RouteTagList/components/RouteInfo/AppInstance';
import { Namespace } from '@ali/mamba-namespace';
import Rules from 'pages/App/AppDetail/components/NewCanary/components/CanaryEdit/Rules';
import { mapConditionsFormData } from 'utils';
import { newMapRouteRules } from '../../utils';

const FormItem = Form.Item;

const TagItemEdit = (props, ref) => {
  const field = Field.useField();
  const { value = {}, setRefreshIndex, allData = [] } = props;
  const intl = useIntl();
  const { init, validate, setValues, getValue } = field;
  const [searchValues] = useGlobalState('searchValues');
  const [appServiceData, setAppServiceData] = useGlobalState('appServiceData');
  const [isLoading, setIsLoading] = useState(false);
  const formRef = useRef();
  const [serviceLoading, setServiceLoading] = useState(false);
  // const istioData = get(appServiceData, 'istio', []);

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  useEffect(() => {
    const AppId = get(value, 'AppId', '');
    const Name = get(value, 'Name', '');
    const CarryData = get(value, 'CarryData', false);
    const Enable = get(value, 'Enable', false);
    const Tag = get(value, 'Tag', '');
    const Rules = get(value, 'Rules', []);
    const TriggerPolicy = get(value, 'TriggerPolicy', 'CONTENT');
    const Region = get(value, 'Region');
    setValues({
      Name,
      AppId,
      CarryData,
      Tag,
      Rules,
      TriggerPolicy,
      Region,
      Enable
    });
  }, [value]);

  useEffect(() => {
    if (getValue('AppId')) {
      setServiceLoading(true);
      Promise.all([fetchDubboServiceList(getValue('AppId')), SpringCloudfetchServiceList(getValue('AppId')), fetchIstioServiceList(getValue('AppId'))]).then((res) => {
        setAppServiceData({
          dubbo: res[0],
          springCloud: res[1],
          // istio: res[2],
          istio: [], // 新版路由暂不支持istio
        });
        setServiceLoading(false);
      });
    }
  }, [getValue('AppId')]);

  const fetchDubboServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: namespaces.regionId || value.Region,
      namespace: namespaces.namespaceId || value.Namespace,
      serviceType: 'dubbo',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || value.Region,
        namespace: namespaces.namespaceId || value.Namespace,
        ...namespaces,
        serviceType: 'dubbo',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    const newData = map(data || [], item => {
      const newMethods = map(item.methods, child => {
        return ({
          ...child,
          key: `${child.name}:${child.parameterTypes}`,
          value: `${child.name}:${child.parameterTypes}`,
          label: `${child.name}(${child.parameterTypes || []})`,
        });
      });
      return ({
        ...item,
        methods: newMethods,
        value: `${item.serviceName}:${item.version}:${item.group}`,
        key: `${item.serviceName}:${item.version}:${item.group}`,
        label: `${item.serviceName}:${item.version}:${item.group}`,
      });
    });
    return newData;
  };

  const SpringCloudfetchServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: namespaces.regionId || value.Region,
      namespace: namespaces.namespaceId || value.Namespace,
      serviceType: 'springCloud',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || value.Region,
        namespace: namespaces.namespaceId || value.Namespace,
        ...namespaces,
        serviceType: 'springCloud',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    return data;
  };

  const fetchIstioServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: namespaces.regionId || value.Region,
      namespace: namespaces.namespaceId || value.Namespace,
      serviceType: 'istio',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || value.Region,
        namespace: namespaces.namespaceId || value.Namespace,
        ...namespaces,
        serviceType: 'istio',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    return data;
  };

  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        console.log(errors, values);
        if (errors) return reject(errors);
        const params = {
          Id: value.Id,
          Region: value.Region,
          Name: values.Name,
          Tag: values.Tag,
          AppId: values.AppId,
          TriggerPolicy: values.TriggerPolicy,
          CarryData: values.CarryData,
          Enable: values.Enable
        };
        if (values.TriggerPolicy === 'CONTENT') {
          params.Rules = map(values.Rules, (items) => {
            const protocol = get(items, 'protocol');
            const method = get(items, 'method', '');
            const [serviceName, version, group, methodName, paramTypes = ''] = split(protocol === 'dubbo' ? method : '', ':'); // 除了 dubbo 类型不传 method信息
            if (protocol === 'springCloud') {
              return {
                ...items,
                triggerPolicy: values.TriggerPolicy,
                serviceName,
                version,
                group,
                methodName,
                paramTypes: split(paramTypes, ','),
                conditions: mapConditionsFormData(items.conditions || [], items.protocol),
                restItems: mapConditionsFormData(items.conditions || [], items.protocol),
              };
            } else if (protocol === 'dubbo') {
              return {
                ...items,
                triggerPolicy: values.TriggerPolicy,
                serviceName,
                version,
                group,
                methodName,
                paramTypes: split(paramTypes, ','),
                conditions: mapConditionsFormData(items.conditions || [], items.protocol),
                argumentItems: mapConditionsFormData(items.conditions || [], items.protocol),
              };
            }
          });
        }
        const RouteRules = map(allData.RouteRules || [], item => { return item.Tag === params.Tag ? { ...item, ...params } : item; });
        const newData = {
          ...allData,
          RouteRules: map(RouteRules, item => ({
            ...item,
            Rules: map(item.Rules, child => {
              const { ...rest } = child;
              return ({
                ...rest,
                conditions: mapConditionsFormData(child.conditions || [], child.protocol),
              });
            }),
          })),
        };
        const newParams = newMapRouteRules(newData);
        await services.ApplyTagPolicies({
          params: newParams,
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        params.Id ? Message.success(intl('widget.common.update_successful')) : Message.success(intl('widget.common.add_successful'));
        resolve();
        setRefreshIndex(Date.now());
      });
    });
  };

  // 针对springCloud，dubbo需要区分判断数据
  const handleValidatorRules = (rule, val, callback) => {
    forEach(val, item => {
      if (!item.condition || isEmpty(item.conditions)) {
        callback(intl('widget.route.rule_not_complete'));
        return;
      }
      forEach(item.conditions, child => {
        if (item.protocol === 'istio') {
          if (!child.type || !child.name || !child.cond || (!child.value && child.value !== 0)) {
            callback(intl('widget.route.condition.rule_not_complete'));
            return;
          }
        }
        if (item.protocol === 'springCloud') {
          if (!child.type || !child.name || !child.cond || (!child.value && child.value !== 0)) {
            callback(intl('widget.route.condition.rule_not_complete'));
            return;
          }
        }
        if (item.protocol === 'dubbo') {
          if (!(child.index >= 0) || !child.cond || (!child.value && child.value !== 0)) {
            callback(intl('widget.route.condition.rule_not_complete'));
          }
        }
      });
    });
    callback();
  };

  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  const fetchNamespaces = async (region) => {
    const { data = [] } = await services.fetchNamespaces({ params: { regionId: region } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  return (
    <Loading visible={isLoading} style={{ width: '100%' }}>
      <Form field={field} labelAlign="left">
        <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
          <FormItem label={intl('widget.common.microservice_space')} required>
            <If condition={!value.id}>
              <Namespace
                {...init('namespaces', {
                  initValue: { regionId: value.Region, namespaceId: value.Namespace, },
                  rules: [
                    {
                      required: true,
                      message: intl('widget.common.please_select_microservice_space'),
                    },
                  ],
                })}
                style={{ width: '47%' }}
                fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
                fetchNamespaces={fetchNamespaces}
              />
            </If>
            <If condition={value.id}>
              {value.Namespace}
            </If>
          </FormItem>
        </If>
        <FormItem label={intl('widget.route.name')} required>
          <If condition={!value.Id}>
            <Input
              {...init('Name', {
                rules: [
                  {
                    required: true,
                    message: intl('widget.route.name_input_error'),
                  },
                  {
                    pattern: NNAME_PATTERN,
                    message: intl('widget.common.name_pattern'),
                  },
                ],
              })}
              placeholder={intl('widget.common.name_placeholder')}
              maxLength={64}
              minLength={1}
              showLimitHint
              style={{ width: '100%' }}
            />
          </If>
          <If condition={value.Id}>
            {value.Name}
          </If>
        </FormItem>
        <FormItem
          label={intl('widget.home.app')}
          required
        >
          {value.AppName}
        </FormItem>
        <FormItem label={intl('widget.route.tag')} required>
          {value.Tag}
        </FormItem>
        <FormItem label={intl('widget.route.app_instance')}>
          <AppInstance appId={getValue('AppId')} tag={getValue('Tag')} namespaces={{ regionId: value.Region, ...getValue('namespaces') }} />
        </FormItem>
        <FormItem
          label={
            <React.Fragment>
              <span style={{ marginRight: 8 }}>{intl('widget.route.link_delivery')}</span>
              <If condition={searchValues.protocol === 'SPRING_CLOUD'}>
                <Balloon trigger={<Icon type="help" />} closable={false}>
                  {intl.html('widget.route.sc_link_delivery_hint')}
                </Balloon>
              </If>
              <If condition={searchValues.protocol === 'DUBBO'}>
                <Balloon trigger={<Icon type="help" />} closable={false}>
                  {intl.html('widget.route.dubbo_link_delivery_hint')}
                </Balloon>
              </If>
            </React.Fragment>
          }
        >
          <Switch
            {...init('CarryData', {
              valueName: 'checked'
            })}
          />
        </FormItem>
        <If condition={getValue('TriggerPolicy') === 'CONTENT'}>
          <FormItem label={intl('widget.route.business_flow')} required={getValue('TriggerPolicy') === 'CONTENT'}>
            <Rules
              {...init('Rules', {
                initValue: [],
                rules: [
                  {
                    required: true,
                    message: intl('widget.route.flow_rule_error'),
                  },
                  {
                    validator: handleValidatorRules
                  }
                ],
              })}
              tag={getValue('tag')}
              ruleId={value.id}
              ref={formRef}
              handleClickVisbile={() => {}}

            />
          </FormItem>
          <FormItem label={intl('widget.route.open_business_flow')} >
            <Switch
              {...init('Enable', {
                valueName: 'checked'
              })}
            />
          </FormItem>
        </If>
      </Form>
    </Loading>
  );
};

TagItemEdit.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  setRefreshIndex: PropTypes.number,
  allData: PropTypes.objectOf(PropTypes.any),
};
const RefEditForm = forwardRef(TagItemEdit);

export default RefEditForm;
