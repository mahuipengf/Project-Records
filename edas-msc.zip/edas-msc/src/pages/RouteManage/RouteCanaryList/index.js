import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { modelDecorator, TableContainer, CopyContent, Empty } from '@ali/cn-design';
import services from 'services';
import Events from './Events';
import EditForm from './components/EditForm';
import { Dubbo, SpringCloud } from 'components/Icon';
import RouteInfo from './components/RouteInfo';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const PROTOCOL = {
  springCloud: 'Spring Cloud',
  dubbo: 'dubbo',
};
const ICON = {
  dubbo: <Dubbo />,
  springCloud: <SpringCloud />,
};

const RouteDynamic = (props) => {
  const { toggleModal, tableUniqueKey } = props;
  const intl = useIntl();
  const [refreshIndex, setRefreshIndex] = useState(undefined); // 手动触发表格更新
  const [searchValues] = useGlobalState('searchValues');
  const [autoFetch, setAutoFetch] = useState(false);

  useEffect(() => {
    setAutoFetch(true);
  }, []);

  const fetchData = async (params = {}) => {
    const newParams = {
      ...searchValues,
      ...params,
      category: 1,
      source: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'EDAS' : undefined
    };
    const { Result = [], TotalSize = 0 } = await services.getRoutePolicyList({ params: newParams });
    return {
      Data: Result,
      TotalCount: TotalSize,
    };
  };

  const handleEdit = (record = {}) => {
    toggleModal({
      type: 'slide',
      visible: true,
      title: record.Id ? intl('widget.route.canary.edit') : intl('widget.route.canary.create'),
      content: (
        <EditForm
          value={record}
          toggleModal={toggleModal}
          setRefreshIndex={setRefreshIndex}
        />
      ),
      onConfirm: null,
    });
  };

  const handleOpenInfo = (record = {}) => {
    toggleModal({
      type: 'slide',
      visible: true,
      title: intl('widget.route.canary.info'),
      content: (
        <RouteInfo
          value={record}
          handleEdit={handleEdit}
        />
      ),
      onConfirm: null,
    });
  };

  const FLOW_TYPE = {
    CONTENT: intl('widget.route.gray_by_content'),
    PERCENT: intl('widget.route.gray_by_rate'),
  };

  const columns = [
    {
      key: 'Name',
      title: intl('widget.route.name'),
      dataIndex: 'Name',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <span className="link-primary" onClick={() => handleOpenInfo(record)}>{value}</span>
        </CopyContent>
      ),
    },
    {
      key: 'AppName',
      title: intl('widget.common.app_name'),
      dataIndex: 'AppName',
    },
    {
      key: 'TriggerPolicy',
      title: intl('widget.route.flow_type'),
      dataIndex: 'TriggerPolicy',
      cell: (value) => FLOW_TYPE[value],
    },
    {
      key: 'Protocol',
      title: intl('widget.route.frame_type'),
      dataIndex: 'Protocol',
      cell: (value, index, record) => {
        const arr = [];
        if (record.ScRules && record.ScRules.length) {
          arr.push('springCloud');
        }
        if (record.DubboArgRules && record.DubboArgRules.length) {
          arr.push('dubbo');
        }
        return (
          <React.Fragment>
            <Empty value={!arr.length && undefined}>
              <For each="item" index="index" of={arr}>
                <div style={{ display: 'flex' }} key={index}>
                  {ICON[item]}
                  <span>{PROTOCOL[item]}</span>
                </div>
              </For>
            </Empty>
          </React.Fragment>
        );
      }
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => <Events record={record} handleEdit={() => handleEdit(record)} setRefreshIndex={setRefreshIndex} />,
    },
  ];

  const searchs = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.route.name'),
          value: 'Name',
        },
      ],
      defaultValue: 'Name',
      placeholder: intl('widget.route.name_placeholder'),
    },
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };

  return (
    <React.Fragment>
      <TableContainer
        autoFetch={autoFetch}
        search={searchs}
        columns={columns}
        fetchData={fetchData}
        refreshIndex={refreshIndex}
        affixActionBar
        primaryKey="Id"
      />
    </React.Fragment>
  );
};

RouteDynamic.propTypes = {
  toggleModal: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default modelDecorator(RouteDynamic);

