import React, { useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { Form, Loading, Tab, Button, Range } from '@ali/cn-design';
import Dialog from 'components/Dialog';
import confirm from 'components/Confirm';
import { Field } from '@alicloud/console-components';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { map, forEach, filter, get, uniqueId, join, split } from 'lodash';
import AppInstance from '../RouteInfo/AppInstance';
import { lowerFirstData } from 'utils/transfer-data';
import Rules from '../../../RouteTagList/components/EditForm/Rules';
import styles from './index.less';
import YamlModal from './YamlModal';
import { mapConditions, mapConditionsFormData } from 'utils';

const FormItem = Form.Item;

const EditForm = (props) => {
  const field = Field.useField();
  const [isLoading, setIsLoading] = useState(false);
  const [isConfirmLoading, setIsConfirmLoading] = useState(false);
  const [isShowYaml, setIsShowYaml] = useState(false);
  const [appInstanceRate, setAppInstanceRate] = useState(0);
  const [showRangeHint, setShowRangeHint] = useState(false);
  const [serviceList, setServiceList] = useGlobalState('serviceList');
  const { value, toggleModal } = props;
  const intl = useIntl();
  const { init, validate, getValue, setValue, setValues } = field;
  const [searchValues] = useGlobalState('searchValues');
  const rulesRef = useRef();

  useEffect(() => {
    if (value.Id) {
      if (value.hasData) {
        confirm({
          title: intl('widget.route.canary.data_change'),
          content: intl('widget.route.canary.data_not_save', { name: value.Name }),
          onOk: () => fetchNewData(value.Id),
          onCancel: () => fetchNewData(value.Id),
          onClose: () => fetchNewData(value.Id),
        });
        return;
      }
      fetchData(value.Id);
    }
  }, [value.Id]);

  useEffect(() => {
    if (getValue('AppId')) {
      fetchServiceList(getValue('AppId'));
    }
  }, [getValue('AppId')]);

  const fetchNewData = (id) => {
    return new Promise(resolve => {
      fetchData(id);
      resolve();
    });
  };

  const fetchData = async (Id) => {
    const { regionId, namespaceId } = searchValues;
    const params = {
      regionId,
      namespaceId,
      policyId: Id,
    };
    setIsLoading(true);
    const res = await services.getRoutePolicy({
      params,
      customErrorHandle: (err, response, callback) => {
        setIsLoading(false);
        callback();
      }
    }) || {};
    setIsLoading(false);
    const scRules = get(res, 'ScRules', []);
    const newScRules = map(scRules, item => {
      return {
        ...item,
        uid: uniqueId(),
        conditions: mapConditions(item.restItems),
        protocol: 'springCloud'
      };
    });
    const dubboArgRules = get(res, 'DubboArgRules', []);
    const newDubboRules = map(dubboArgRules, item => {
      const { serviceName = '', version = '', group = '', methodName = '', paramTypes = [] } = item;
      return {
        ...item,
        method: `${serviceName}:${version}:${group}:${methodName}:${paramTypes}`,
        uid: uniqueId(),
        conditions: mapConditions(item.argumentItems),
        protocol: 'dubbo'
      };
    });
    setValues({ ...res, Rules: [...newScRules, ...newDubboRules] });
  };

  const fetchServiceList = async (appId) => {
    const res = await services.getServiceList({
      data: {
        region: searchValues.regionId,
        namespace: searchValues.namespaceId,
        serviceType: 'dubbo',
        appId,
      },
    });
    const data = lowerFirstData(res) || [];
    const newData = map(data || [], item => {
      const newMethods = map(item.methods, child => {
        return ({
          ...child,
          key: `${child.name}:${child.parameterTypes}`,
          value: `${child.name}:${child.parameterTypes}`,
          label: `${child.name}(${child.parameterTypes || []})`,
        });
      });
      return ({
        ...item,
        methods: newMethods,
        value: `${item.serviceName}:${item.version}:${item.group}`,
        key: `${item.serviceName}:${item.version}:${item.group}`,
        label: `${item.serviceName}:${item.version}:${item.group}`,
      });
    });
    setServiceList(newData);
  };

  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const params = {
        Id: values.Id,
        regionId: searchValues.regionId,
        namespaceId: searchValues.namespaceId,
        Name: values.Name,
        AppId: values.AppId,
        Category: 1,
        TriggerPolicy: values.TriggerPolicy,
      };
      if (values.TriggerPolicy === 'CONTENT') {
        const { errors: Errors } = await rulesRef.current.validator();
        if (Errors) return;
        const ScRulesJson = filter(values.Rules, item => item.protocol === 'springCloud');
        const DubboArgRulesJson = filter(values.Rules, item => item.protocol === 'dubbo');
        params.ScRulesJson = map(ScRulesJson, item => ({
          ...item,
          triggerPolicy: 'CONTENT',
          restItems: mapConditionsFormData(item.conditions || [], item.protocol),
        }));
        params.DubboArgRulesJson = map(DubboArgRulesJson, item => {
          const [serviceName, version, group, methodName, paramTypes = ''] = split(item.method, ':'); // 除了 dubbo 类型不传 method信息

          return {
            ...item,
            TriggerPolicy: 'CONTENT',
            serviceName,
            version,
            group,
            methodName,
            paramTypes,
            argumentItems: mapConditionsFormData(item.conditions || [], item.protocol),
          };
        });
      }
      if (values.TriggerPolicy === 'CONTENT') {
        params.Tag = values.Tag;
      }
      setIsShowYaml(true);
      return;
      setIsConfirmLoading(true);
      await services.buildYaml(params, params, {
        customErrorHandle: (err, response, callback) => {
          setIsConfirmLoading(false);
          callback();
        }
      });
      setIsConfirmLoading(true);
    });
  };

  // 针对springCloud，dubbo需要区分判断数据
  const handleValidatorRules = (rule, val, callback) => {
    if (getValue('TriggerPolicy') === 'PERCENT') {
      callback();
      return;
    }
    forEach(val, item => {
      if (!item.condition || !item.conditions || !item.conditions.length) {
        callback(intl('widget.route.rule_not_complete'));
        return;
      }
      forEach(item.conditions, child => {
        if (item.protocol === 'springCloud') {
          if (!child.type || !child.name || !child.cond || !child.value) {
            callback(intl('widget.route.condition.rule_not_complete'));
            return;
          }
        }
        if (item.protocol === 'dubbo') {
          if (!(child.index >= 0) || !child.cond || !child.value) {
            callback(intl('widget.route.condition.rule_not_complete'));
          }
        }
      });
    });
    callback();
  };

  const handleReset = () => {
    confirm({
      title: intl('widget.common.reset'),
      content: intl('widget.route.canary.data_rest', { name: value.Name }),
      onOk: () => fetchData(value.Id),
    });
  };

  const handleChangeRange = (val) => {
    if (val > appInstanceRate) {
      setShowRangeHint(true);
    } else {
      setShowRangeHint(false);
    }
  };

  const tabs = [
    {
      value: 'CONTENT',
      title: intl('widget.route.gray_by_content'),
      component: (
        <FormItem label={intl('widget.route.business_flow')} required={getValue('TriggerPolicy') === 'CONTENT'}>
          <Rules
            {...init('Rules', {
              initValue: value.Rules || [],
              rules: [
                {
                  required: getValue('TriggerPolicy') === 'CONTENT',
                  message: intl('widget.route.flow_rule_error'),
                },
                {
                  validator: handleValidatorRules
                }
              ],
            })}
            ref={rulesRef}
          />
        </FormItem>
      )
    },
    {
      value: 'PERCENT',
      title: intl('widget.route.gray_by_rate'),
      component: (
        <React.Fragment>
          <div style={{ padding: '12px 16px', background: '#f2f2f2', margin: '16px 0' }}>{intl('widget.route.flow_rate_label')}</div>
          <FormItem label={intl('widget.route.flow_rate1', { n: '%' })} required={getValue('TriggerPolicy') === 'PERCENT'}>
            {/* <NumberPicker
              min={0}
              max={100}
              placeholder={intl('widget.route.flow_rate_placeholder')}
              {...init('Rate', {
                initValue: value.Rate,
                rules: [
                  {
                    required: getValue('TriggerPolicy') === 'PERCENT',
                    message: intl('widget.route.flow_rate_error'),
                  },
                  {
                    validator: handleValidatorRate
                  }
                ],
                props: {
                  onChange: handleChange
                }
              })}
            /> */}
            <Range
              min={0}
              max={100}
              marks={10}
              step={10}
              marksPosition="below"
              style={{ padding: '8px 16px' }}
              placeholder={intl('widget.route.flow_rate_placeholder')}
              {...init('Rate', {
                initValue: value.Rate,
                rules: [
                  {
                    required: getValue('TriggerPolicy') === 'PERCENT',
                    message: intl('widget.route.flow_rate_error'),
                  },
                ],
                props: {
                  onChange: handleChangeRange
                }
              })}
            />
            <If condition={showRangeHint}>
              <span style={{ color: 'red' }}>{intl('widget.route.flow_rate_hint', { n: appInstanceRate })}</span>
            </If>
          </FormItem>
        </React.Fragment>
      )
    },
  ];

  const handleChangeTriggerPolicy = (val) => {
    setValue('TriggerPolicy', val);
  };

  return (
    <React.Fragment>
      <Loading visible={isLoading}>
        <Form field={field} labelAlign="left" style={{ width: 780, paddingBottom: 64 }}>
          <AppInstance value={value} callback={(val) => setAppInstanceRate(val)} rate={getValue('TriggerPolicy') === 'PERCENT' ? getValue('Rate') : 0} />
          <h4 className="common-title">{intl('widget.route.business_flow')}</h4>
          <Tab shape="wrapped" activeKey={getValue('TriggerPolicy')} onClick={val => handleChangeTriggerPolicy(val)}>
            {map(tabs, n => (
              <Tab.Item title={n.title} key={n.value}>
                {n.component}
              </Tab.Item>
            ))}
          </Tab>
        </Form>
      </Loading>
      <div className={styles['route-conary-panel-footer']}>
        <Button type="primary" style={{ marginRight: 8 }} onClick={handleSubmit} loading={isConfirmLoading}>
          {intl('widget.route.generate_yaml')}
        </Button>
        <Button style={{ marginRight: 8 }} onClick={handleReset}>
          {intl('widget.common.reset')}
        </Button>
        <Button onClick={() => toggleModal({ visible: false })}>
          {intl('widget.common.cancel')}
        </Button>
      </div>
      <Dialog title={intl('widget.route.canary_yaml_title', { title: value.Name })} visible={isShowYaml} onClose={() => setIsShowYaml(false)} footer={false}>
        <YamlModal onClose={setIsShowYaml} />
      </Dialog>
    </React.Fragment>
  );
};

EditForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  toggleModal: PropTypes.func,
};

export default EditForm;
