import React from 'react';
import { useIntl } from '@ali/widget-hooks';
import MonacoEditor from 'components/MonacoEditor';
import PropTypes from 'prop-types';

const value1 = `
Hello;
I'm canary's YAML;
How are you;
`;


const YamlModal = (props) => {
  const intl = useIntl();

  const { value = value1, title } = props;


  return (
    <MonacoEditor
      title={title}
      height={300}
      width={600}
      value={value}
      readOnly={true}
      isEnableMaximize={false}
    />
  );
};

YamlModal.propTypes = {
  value: PropTypes.string,
  title: PropTypes.string,
};

export default YamlModal;
