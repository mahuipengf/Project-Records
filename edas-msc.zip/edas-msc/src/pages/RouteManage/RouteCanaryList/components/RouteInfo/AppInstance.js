import React, { useEffect, useState } from 'react';
import { Loading } from '@ali/cn-design';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import Instance from '../../../components/AppInstance';
import { find } from 'lodash';

const AppInstance = (props) => {
  const intl = useIntl();
  const { value = {}, callback, rate: currentRate = 0 } = props;
  const [list, setList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (value.AppId) {
      fetchData(value.AppId);
    }
  }, [value.AppId]);

  useEffect(() => {
    const newList = list.slice(0, 2) || [];
    const oldItem = find(newList, item => item.Old === false) || {};
    const newItem = find(newList, item => item.Old !== false) || {};
    const { InstanceInfoList: oldInstance = [] } = oldItem;
    const { InstanceInfoList: newInstance = [] } = newItem;
    const rate = ((oldInstance.length / ((oldInstance.length + newInstance.length) || 1)) * 100).toFixed(0);
    callback && callback(rate || 0);
  }, [list]);

  const fetchData = async (appId) => {
    setIsLoading(true);
    const Data = await services.GetApplicationCanaryInstances({
      params: { appId },
      customErrorHandle: (err, response, call) => {
        setIsLoading(false);
        call();
      }
    });
    setList(Data);
    setIsLoading(false);
  };

  const newList = list.slice(0, 2) || [];
  const oldItem = find(newList, item => item.Old === false) || {};
  const newItem = find(newList, item => item.Old !== false) || {};
  const { InstanceInfoList: oldInstance = [] } = oldItem;
  const { InstanceInfoList: newInstance = [] } = newItem;

  return (
    <If condition={value.Id}>
      <h5 className="common-title" style={{ marginTop: 8 }}>{intl('widget.route.app_instance_n', { n: oldInstance.length + newInstance.length })}</h5>
      <div>
        <Loading visible={isLoading} style={{ width: '100%' }}>
          <Instance
            style={currentRate > ((oldInstance.length / ((oldInstance.length + newInstance.length) || 1)) * 100).toFixed(0) ? { boxShadow: '0 0px 4px red', color: 'red' } : {}}
            list={oldInstance}
            rate={((oldInstance.length / ((oldInstance.length + newInstance.length) || 1)) * 100).toFixed(0)}
            version={oldItem.Version}
            old={false}
          />
          <Instance
            list={newInstance}
            rate={((newInstance.length / ((oldInstance.length + newInstance.length) || 1)) * 100).toFixed(0)}
            version={newItem.Version}
            old
          />
        </Loading>
      </div>
    </If>
  );
};

AppInstance.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  callback: PropTypes.func,
};

export default AppInstance;
