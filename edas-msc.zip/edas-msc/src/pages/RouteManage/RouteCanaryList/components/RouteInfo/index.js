import React from 'react';
import { Badge } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import RouteInfo from 'containers/RouteInfo';
import AppInstance from './AppInstance';
import CommonEvent from 'components/CommonEvent';

const AppInfo = (props) => {
  const intl = useIntl();
  const { value = {}, handleEdit } = props;

  return (
    <If condition={value.Id}>
      <div style={{ width: 680 }}>
        <AppInstance value={value} />
        <div style={{ display: 'flex', alignItems: 'center', marginTop: 16 }}>
          <h4 className="common-title" style={{ width: 144, marginTop: 8 }}>{intl('widget.route.business_flow')}</h4>
          <If condition={handleEdit}>
            <If condition={value.hasNewData}>
              <Badge dot>
                <CommonEvent type="edit" text={intl('widget.common.edit')} onClick={() => handleEdit && handleEdit(value)} />
              </Badge>
            </If>
            <If condition={!value.hasNewData}>
              <CommonEvent type="edit" text={intl('widget.common.edit')} onClick={() => handleEdit && handleEdit(value)} />
            </If>
          </If>
        </div>
        <RouteInfo id={value.Id} />
      </div>
    </If>
  );
};

AppInfo.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  handleEdit: PropTypes.func,
};

export default AppInfo;
