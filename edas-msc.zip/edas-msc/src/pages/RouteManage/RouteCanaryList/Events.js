import React from 'react';
import PropTypes from 'prop-types';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { useIntl } from '@ali/widget-hooks';
import { Badge } from '@ali/cn-design';

const Events = (props) => {
  const intl = useIntl();
  const { record, handleEdit } = props;

  return (
    <Actions expandTriggerType="hover">
      <If condition={record.hasNewData}>
        <Badge dot>
          <LinkButton key="1" onClick={handleEdit}>{intl('widget.common.edit')}</LinkButton>
        </Badge>
      </If>
      <If condition={!record.hasNewData}>
        <LinkButton key="1" onClick={handleEdit}>{intl('widget.common.edit')}</LinkButton>
      </If>
    </Actions>

  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  handleEdit: PropTypes.func,
};

export default Events;
