import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { Button, Message, modelDecorator, TableContainer, CopyContent, Empty } from '@ali/cn-design';
import services from 'services';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import Events from './Events';
import EditForm from './components/EditForm';
import Status from 'components/Status/CommonStatus';
import { Dubbo, SpringCloud, Istio } from 'components/Icon';
import RouteInfo from './components/RouteInfo';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';
import { map, isEmpty } from 'lodash';
import RoleHoc from 'containers/RoleHoc';

const PROTOCOL = {
  springCloud: 'Spring Cloud',
  dubbo: 'Dubbo',
  istio: 'Istio',
};
const ICON = {
  dubbo: <Dubbo />,
  springCloud: <SpringCloud />,
  istio: <Istio />,
};

const RouteDynamic = (props) => {
  const { toggleModal, tableUniqueKey } = props;
  const intl = useIntl();
  const [refreshIndex, setRefreshIndex] = useState(undefined); // 手动触发表格更新
  const [searchValues] = useGlobalState('searchValues');
  const [autoFetch, setAutoFetch] = useState(false);
  const editForm = useRef(null);

  useEffect(() => {
    setAutoFetch(true);
  }, []);

  const fetchData = async (params = {}) => {
    const newParams = {
      ...searchValues,
      region: searchValues.regionId,
      ...params,
      category: 0,
      source: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'EDAS' : undefined
    };
    const res = await services.getRoutePolicyList({ params: newParams });
    const { result = [], totalSize = 0 } = lowerFirstData(res) || {};
    return {
      Data: map(result, item => {
        if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
          return ({
            ...item,
            regionId: item.namespaceId ? item.namespaceId.split(':')[0] : undefined,
            isIstioApp: !isEmpty(item.istioRules)
          });
        }
        return ({
          ...item,
          isIstioApp: !isEmpty(item.istioRules)
        });
      }),
      TotalCount: totalSize,
    };
  };

  const handleEdit = (record = {}) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'xl',
      title: record.Id ? intl('widget.route.tag.edit') : intl('widget.route.tag.create'),
      content: (
        <EditForm
          ref={editForm}
          value={record}
          setRefreshIndex={setRefreshIndex}
        />
      ),
      onConfirm: () => editForm.current.handleSubmit(),
    });
  };

  const handleOpenInfo = (record = {}) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'xl',
      title: intl('widget.route.tag.info'),
      content: (
        <RouteInfo
          value={record}
          handleEdit={handleEdit}
        />
      ),
      onConfirm: null,
    });
  };

  const columns = [
    {
      key: 'Name',
      title: intl('widget.route.name'),
      dataIndex: 'name',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <span className="link-primary" onClick={() => handleOpenInfo(record)}>{value}</span>
        </CopyContent>
      ),
    },
    {
      key: 'Enable',
      title: intl('widget.common.state'),
      dataIndex: 'enable',
      cell: value => <Status value={value} />,
      width: 100,
    },
    {
      key: 'AppName',
      title: intl('widget.common.app_name'),
      dataIndex: 'appName',
      cell: (value) => (
        <CopyContent text={value}>
          {value}
        </CopyContent>
      ),
    },
    {
      key: 'Tag',
      title: intl('widget.route.tag'),
      dataIndex: 'tag',
      cell: value => value || '--',
    },
    {
      key: 'Protocol',
      title: intl('widget.route.frame_type'),
      dataIndex: 'protocol',
      cell: (value, index, record) => {
        const arr = [];
        if (record.scRules && record.scRules.length) {
          arr.push('springCloud');
        }
        if (record.dubboArgRules && record.dubboArgRules.length) {
          arr.push('dubbo');
        }
        if (record.istioRules && record.istioRules.length) {
          arr.push('istio');
        }
        return (
          <React.Fragment>
            <Empty value={!arr.length && undefined}>
              <For each="item" index="index" of={arr}>
                <div style={{ display: 'flex' }} key={index}>
                  {ICON[item]}
                  <span>{PROTOCOL[item]}</span>
                </div>
              </For>
            </Empty>
          </React.Fragment>
        );
      }
    },
    {
      key: 'carryData',
      title: intl('widget.route.link_delivery'),
      dataIndex: 'carryData',
      cell: value => (
        <React.Fragment>
          <If condition={value}>{intl('widget.common.yes')}</If>
          <If condition={value === false}>{intl('widget.common.no')}</If>
          <If condition={value === undefined}>--</If>
        </React.Fragment>
      ),
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => <Events record={record} handleEdit={() => handleEdit(record)} setRefreshIndex={setRefreshIndex} />,
    },
  ];

  const searchsEdas = {
    typeInfo: {
      types: [
        { value: '', label: intl('widget.authentication.all_frame') },
        { value: 'SPRING_CLOUD', label: 'Spring Cloud' },
        { value: 'DUBBO', label: 'Dubbo' },
        // { value: 'istio', label: intl('widget.service.service_mesh') }, // mesh 的标签路由本来打算上的，开发完提测后又不上了。。。
      ],
      defaultValue: searchValues.protocol || '',
      value: 'protocol',
    },
    filterInfo: {
      filters: [
        {
          label: intl('widget.route.name'),
          value: 'Name',
        },
      ],
      defaultValue: 'Name',
      placeholder: intl('widget.route.name_placeholder'),
    },
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };

  const searchs = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.route.name'),
          value: 'Name',
        },
      ],
      defaultValue: 'Name',
      placeholder: intl('widget.route.name_placeholder'),
    },
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };

  return (
    <React.Fragment>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && !IS_ENV_PRIVATE && (searchValues.protocol === 'SPRING_CLOUD' || searchValues.protocol === 'DUBBO')}>
        <Message type="warning" style={{ marginBottom: 16 }}>
          {
            intl.html(searchValues.protocol === 'SPRING_CLOUD' ? 'widget.route_tag.sc_label' : 'widget.route_tag.dubbo_label')
          }
        </Message>
      </If>
      <TableContainer
        autoFetch={autoFetch}
        search={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? searchsEdas : searchs}
        columns={columns}
        fetchData={fetchData}
        refreshIndex={refreshIndex}
        affixActionBar
        primaryKey="id"
        operation={() => (
          <Button
            type="primary"
            onClick={() => handleEdit()}
            style={{ marginRight: 8 }}
          >
            {intl('widget.route.tag.create')}
          </Button>
        )}
        emptyContent={
          <Actions expandTriggerType="hover" style={{ justifyContent: 'center' }}>
            <LinkButton key="1" onClick={() => handleEdit()}>{intl('widget.route.no_data_go_create')}</LinkButton>
          </Actions>
        }
      />
    </React.Fragment>
  );
};

RouteDynamic.propTypes = {
  toggleModal: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default RoleHoc(modelDecorator(RouteDynamic));

