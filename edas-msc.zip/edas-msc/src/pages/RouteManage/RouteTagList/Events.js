import React from 'react';
import PropTypes from 'prop-types';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { Message } from '@ali/cn-design';
import confirm from 'components/Confirm';
import services from 'services';

const Events = (props) => {
  const intl = useIntl();
  const { record, handleEdit, setRefreshIndex } = props;
  const [searchValues] = useGlobalState('searchValues');
  const { regionId, namespaceId } = searchValues;
  const { id, name, enable, triggerPolicy, tag } = record;

  const handleDelete = () => {
    confirm({
      title: intl('widget.common.delete'),
      content: intl('widget.common.delete_confirm', { name }),
      onOk: () => services.deleteRoutePolicy({
        data: { id, policyId: id, regionId, namespaceId },
      }).then(() => {
        Message.success(intl('widget.common.delete_successful'));
        setRefreshIndex(Date.now());
      }),
    });
  };

  const handleOpen = () => {
    confirm({
      title: intl('widget.route.tag.open_rule'),
      content: intl('widget.common.open_confirm', { name }),
      onOk: () => services.updateRoutePolicy({
        data: { id, tag, triggerPolicy, Enable: true, regionId, namespaceId }
      }).then(() => {
        Message.success(intl('widget.common.open_successful'));
        setRefreshIndex(Date.now());
      }),
    });
  };

  const handleClose = () => {
    confirm({
      title: intl('widget.route.tag.close_rule'),
      content: intl('widget.common.close_confirm', { name }),
      onOk: () => services.updateRoutePolicy({
        data: { id, tag, triggerPolicy, Enable: false, regionId, namespaceId },
      }).then(() => {
        Message.success(intl('widget.common.close_successful'));
        setRefreshIndex(Date.now());
      }),
    });
  };

  return (
    <Actions expandTriggerType="hover">
      <LinkButton key="1" onClick={handleEdit}>{intl('widget.common.edit')}</LinkButton>
      <If condition={enable}>
        <LinkButton key="2" onClick={handleClose}>{intl('widget.common.close1')}</LinkButton>
      </If>
      <If condition={!enable}>
        <LinkButton key="3" onClick={handleOpen}>{intl('widget.common.open1')}</LinkButton>
      </If>
      <LinkButton key="4" onClick={handleDelete}>{intl('widget.common.delete')}</LinkButton>
    </Actions>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  handleEdit: PropTypes.func,
  setRefreshIndex: PropTypes.func,
};

export default Events;
