import React, { useImperativeHandle, forwardRef, useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Message, Loading, Switch, Balloon, Icon, Radio } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { forEach, filter, map, get, uniqueId, trim, assign, sumBy, find, split } from 'lodash';
import Rules from './Rules';
import { NNAME_PATTERN, MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';
import AppSelector from 'containers/AppSelector';
import TagSelector from 'containers/TagSelector';
import AppInstance from '../RouteInfo/AppInstance';
import { Namespace } from '@ali/mamba-namespace';
import IstioTagTable from 'pages/RouteManage/components/IstioTagTable';
import { mapConditions, mapConditionsFormData } from 'utils';

const FormItem = Form.Item;

const EditForm = (props, ref) => {
  const field = Field.useField();
  const { value = {}, setRefreshIndex } = props;
  const intl = useIntl();
  const { init, validate, setValues, getValue, remove, setValue } = field;
  const [searchValues] = useGlobalState('searchValues');
  const [appServiceData, setAppServiceData] = useGlobalState('appServiceData');
  const [isLoading, setIsLoading] = useState(false);
  const rulesRef = useRef();
  const { regionId, namespaceId } = assign({}, searchValues, value);
  const [serviceLoading, setServiceLoading] = useState(false);
  const istioData = get(appServiceData, 'istio', []);

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  useEffect(() => {
    if (value.id) {
      fetchData(value.id);
    } else {
      setValue('namespaces', { regionId, namespaceId });
    }
  }, [value.id]);

  useEffect(() => {
    if (getValue('appId')) {
      setServiceLoading(true);
      Promise.all([fetchServiceList(getValue('appId')), SpringCloudfetchServiceList(getValue('appId')), fetchIstioServiceList(getValue('appId'))]).then((res) => {
        setAppServiceData({
          dubbo: res[0],
          springCloud: res[1],
          istio: res[2],
        });
        if (res[2].length) {
          setValue('triggerPolicy', 'PERCENT'); // istio 目前只能比例灰度
          remove('rules');
        } else {
          setValue('triggerPolicy', 'CONTENT'); // sc, dubbo 目前只能内容灰度
          remove('istioItems');
        }
        setServiceLoading(false);
      });
    }
  }, [getValue('appId')]);

  const fetchData = async (Id) => {
    const namespaces = getValue('namespaces') || {};
    const params = {
      regionId,
      namespaceId,
      ...namespaces,
      policyId: Id,
    };
    setIsLoading(true);
    let res = await services.getRoutePolicy({
      params,
      customErrorHandle: (err, response, callback) => {
        setIsLoading(false);
        callback();
      }
    }) || {};
    setIsLoading(false);
    res = lowerFirstData(res);
    const scRules = get(res, 'scRules', []);
    const newScRules = map(scRules, item => ({
      ...item,
      uid: uniqueId(),
      conditions: mapConditions(item.restItems),
      protocol: 'springCloud'
    }));
    const dubboArgRules = get(res, 'dubboArgRules', []);
    const newDubboRules = map(dubboArgRules, item => {
      const { serviceName = '', version = '', group = '', methodName = '', paramTypes = [] } = item;
      return {
        ...item,
        method: `${serviceName}:${version}:${group}:${methodName}:${paramTypes}`,
        uid: uniqueId(),
        conditions: mapConditions(item.argumentItems),
        protocol: 'dubbo'
      };
    });
    setValues({
      ...res,
      namespaces: { regionId, namespaceId },
      rules: [...newScRules, ...newDubboRules]
    });
  };

  const fetchServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: namespaces.regionId || regionId,
      namespace: namespaces.namespaceId || namespaceId,
      serviceType: 'dubbo',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || regionId,
        namespace: namespaces.namespaceId || namespaceId,
        ...namespaces,
        serviceType: 'dubbo',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    const newData = map(data || [], item => {
      const newMethods = map(item.methods, child => {
        return ({
          ...child,
          key: `${child.name}:${child.parameterTypes}`,
          value: `${child.name}:${child.parameterTypes}`,
          label: `${child.name}(${child.parameterTypes || []})`,
        });
      });
      return ({
        ...item,
        methods: newMethods,
        value: `${item.serviceName}:${item.version}:${item.group}`,
        key: `${item.serviceName}:${item.version}:${item.group}`,
        label: `${item.serviceName}:${item.version}:${item.group}`,
      });
    });
    return newData;
  };

  const SpringCloudfetchServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: namespaces.regionId || regionId,
      namespace: namespaces.namespaceId || namespaceId,
      serviceType: 'springCloud',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || regionId,
        namespace: namespaces.namespaceId || namespaceId,
        ...namespaces,
        serviceType: 'springCloud',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    // setSpringCloudServiceList(data);
    return data;
  };

  const fetchIstioServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: namespaces.regionId || regionId,
      namespace: namespaces.namespaceId || namespaceId,
      serviceType: 'istio',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || regionId,
        namespace: namespaces.namespaceId || namespaceId,
        ...namespaces,
        serviceType: 'istio',
        searchType: 'app',
        searchValue: appId,
      };
      return []; // mesh暂时不支持标签路由
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    // setSpringCloudServiceList(data);
    return data;
  };

  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        console.log(errors, values);
        if (errors) return reject(errors);
        const { namespaces = {} } = values;
        let params = {
          Id: value.id,
          regionId,
          region: regionId,
          namespaceId,
          ...namespaces,
          Name: values.name,
          Tag: values.tag,
          AppId: values.appId,
          Category: 0,
          TriggerPolicy: values.triggerPolicy,
          source: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'EDAS' : undefined,
          ExtraJson: { description: values.description },
          CarryData: values.carryData,
        };
        if (values.triggerPolicy === 'CONTENT') {
          const { errors: Errors } = await rulesRef.current.validator();
          if (Errors) return reject();
          const ScRulesJson = filter(values.rules, item => item.protocol === 'springCloud');
          const DubboArgRulesJson = filter(values.rules, item => item.protocol === 'dubbo');
          params = {
            ...params,
            ScRulesJson: map(ScRulesJson, item => ({
              ...item,
              triggerPolicy: values.triggerPolicy,
              restItems: mapConditionsFormData(item.conditions || [], item.protocol),
            })),
            DubboArgRulesJson: map(DubboArgRulesJson, item => {
              const { serviceName = '', version = '', group = '', methodName = '', paramTypes = [] } = item.method;
              return {
                ...item,
                triggerPolicy: values.triggerPolicy,
                serviceName,
                version,
                group,
                methodName,
                paramTypes: split(paramTypes, ','),
                argumentItems: mapConditionsFormData(item.conditions || [], item.protocol),
              };
            }),
          };
        }
        if (values.triggerPolicy === 'PERCENT') {
          params.Tag = values.tag;
          params.IstioRulesJson = [
            {
              type: 'traffic_for_weight', // 写死字段，有问题直接联系 张海彬
              istioItems: values.istioItems
            }
          ];
        }
        value.id
          ? await services.updateRoutePolicy({
            data: params,
            customErrorHandle: (err, response, callback) => {
              reject();
              callback();
            }
          })
          : await services.addRoutePolicy({
            data: params,
            customErrorHandle: (err, response, callback) => {
              reject();
              callback();
            }
          });
        value.id ? Message.success(intl('widget.common.update_successful')) : Message.success(intl('widget.common.add_successful'));
        resolve();
        setRefreshIndex(Date.now());
      });
    });
  };

  // 针对springCloud，dubbo需要区分判断数据
  const handleValidatorRules = (rule, val, callback) => {
    forEach(val, item => {
      if (!item.condition || !item.conditions || !item.conditions.length) {
        callback(intl('widget.route.rule_not_complete'));
        return;
      }
      forEach(item.conditions, child => {
        if (item.protocol === 'springCloud') {
          if (!child.type || !child.name || !child.cond || (!child.value && child.value !== 0)) {
            callback(intl('widget.route.condition.rule_not_complete'));
            return;
          }
        }
        if (item.protocol === 'dubbo') {
          if (!(child.index >= 0) || !child.cond || (!child.value && child.value !== 0)) {
            callback(intl('widget.route.condition.rule_not_complete'));
          }
        }
      });
    });
    callback();
  };

  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  const fetchNamespaces = async (region) => {
    const { data = [] } = await services.fetchNamespaces({ params: { regionId: region } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  const TRIGGER_POLICY = [
    { value: 'CONTENT', label: intl('widget.route.tag_by_content') },
    { value: 'PERCENT', label: intl('widget.route.tag_by_rate') },
  ];

  const handleValidatorIstioItems = (rule, val, callback) => {
    if (find(val, item => (!item.rate && item.rate !== 0))) {
      callback(intl('widget.route_tag.tag_table_no_complete'));
    }
    const total = sumBy(val, 'rate');
    if (total !== 100) {
      callback(intl('widget.route_tag.tag_table_must_100'));
    }
    callback();
  };

  return (
    <Loading visible={isLoading} style={{ width: '100%' }}>
      <Form field={field} labelAlign="left" style={{ paddingTop: 16 }} >
        <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
          <FormItem label={intl('widget.common.microservice_space')} required>
            <If condition={!value.id}>
              <Namespace
                {...init('namespaces', {
                  initValue: { regionId, namespaceId },
                  rules: [
                    {
                      required: true,
                      message: intl('widget.common.please_select_microservice_space'),
                    },
                  ],
                  props: {
                    onChange: v => {
                      setValues({
                        appId: undefined,
                      });
                    }
                  },
                })}
                style={{ width: '47%' }}
                fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
                fetchNamespaces={fetchNamespaces}
              />
            </If>
            <If condition={value.id}>
              {namespaceId}
            </If>
          </FormItem>
        </If>
        <FormItem label={intl('widget.route.name')} required>
          <Input
            {...init('name', {
              initValue: value.name,
              rules: [
                {
                  required: true,
                  message: intl('widget.route.name_input_error'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.common.name_pattern'),
                },
              ],
            })}
            placeholder={intl('widget.common.name_placeholder')}
            maxLength={64}
            minLength={1}
            showLimitHint
            disabled={value.id}
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem label={intl('widget.route.description')}>
          <Input.TextArea
            {...init('description', {
              initValue: value.extra && value.extra.description,
            })}
            placeholder={intl('widget.route.description_placecholder')}
            maxLength={64}
            showLimitHint
            autoHeight={
              {
                minRows: 1,
                maxRows: 4
              }
            }
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem
          label={intl('widget.home.app')}
          required
        >
          <AppSelector
            {...init('appId', {
              initValue: value.appId,
              rules: [
                {
                  required: true,
                  message: intl('widget.common.select_app'),
                },
              ],
              props: {
                onChange: () => {
                  setValue('tag', undefined);
                  remove('tag');
                },
              }
            })}
            namespaces={getValue('namespaces')}
            disabled={value.id}
          />
        </FormItem>
        <If condition={!istioData.length}>
          <FormItem
            label={
              <span>
                <span>{intl('widget.route.tag')}</span>
                <If condition={searchValues.protocol === 'SPRING_CLOUD'}>
                  <span style={{ marginLeft: 8 }}>{intl.html('widget.route.how_to_create_sc_app_tag')}</span>
                </If>
                <If condition={searchValues.protocol === 'DUBBO'}>
                  <span style={{ marginLeft: 8 }}>{intl.html('widget.route.how_to_create_dubbo_app_tag')}</span>
                </If>
              </span>
            }
            required
          >
            <TagSelector
              {...init('tag', {
                initValue: value.tag,
                rules: [
                  {
                    required: !istioData.length,
                    message: intl('widget.common.select_tag'),
                  },
                ],
              })}
              appId={getValue('appId')}
              disabled={value.id}
            />
          </FormItem>
        </If>
        <If condition={!istioData.length}>
          <FormItem label={intl('widget.route.app_instance')}>
            <AppInstance appId={getValue('appId')} tag={getValue('tag')} namespaces={{ regionId, namespaceId, ...getValue('namespaces') }} />
          </FormItem>
        </If>
        <If condition={!istioData.length}>
          <Form.Item
            label={
              <React.Fragment>
                <span style={{ marginRight: 8 }}>{intl('widget.route.link_delivery')}</span>
                <If condition={searchValues.protocol === 'SPRING_CLOUD'}>
                  <Balloon trigger={<Icon type="help" />} closable={false}>
                    {intl.html('widget.route.sc_link_delivery_hint')}
                  </Balloon>
                </If>
                <If condition={searchValues.protocol === 'DUBBO'}>
                  <Balloon trigger={<Icon type="help" />} closable={false}>
                    {intl.html('widget.route.dubbo_link_delivery_hint')}
                  </Balloon>
                </If>
              </React.Fragment>
            }
          >
            <Switch
              name="carryData"
              defaultChecked={!!value.carryData}
              defaultValue={!!value.carryData}
            />
          </Form.Item>
        </If>
        <FormItem label={intl('widget.route.flow_type')} required>
          <Radio.Group
            {...init('triggerPolicy', {
              initValue: value.triggerPolicy || 'CONTENT',
              props: {
                onChange: () => {
                  remove('rules');
                  remove('rate');
                },
              }
            })}
            disabled
            dataSource={TRIGGER_POLICY}
          />
        </FormItem>
        <If condition={getValue('triggerPolicy') === 'CONTENT'}>
          <FormItem label={intl('widget.route.business_flow')} required={getValue('triggerPolicy') === 'CONTENT'}>
            <Rules
              {...init('rules', {
                initValue: value.rules || [],
                rules: [
                  {
                    required: getValue('triggerPolicy') === 'CONTENT',
                    message: intl('widget.route.flow_rule_error'),
                  },
                  {
                    validator: handleValidatorRules
                  }
                ],
              })}
              tag={getValue('tag')}
              ruleId={value.id}
              ref={rulesRef}
              serviceLoading={serviceLoading}
            />
          </FormItem>
        </If>
        <If condition={getValue('triggerPolicy') === 'PERCENT'}>
          <div className="common-box">
            <FormItem label={intl('widget.route.frame_type')} required>
              <Radio.Group
                {...init('protocol', {
                  initValue: value.protocol || 'istio',
                  rules: [
                    {
                      required: true,
                      message: intl('widget.route.frame_type_errorr'),
                    },
                  ],
                })}
                dataSource={[{ value: 'istio', label: intl('widget.service.service_mesh') }]}
                disabled={!!value.id}
              />
            </FormItem>
            <FormItem label={intl('widget.route.flow_rate')} required={getValue('triggerPolicy') === 'PERCENT'}>
              <IstioTagTable
                {...init('istioItems', {
                  initValue: value.istioItems || [],
                  rules: [
                    {
                      required: true,
                      message: intl('widget.route_tag.app_no_tag'),
                    },
                    {
                      validator: handleValidatorIstioItems
                    }
                  ],
                })}
                appId={getValue('appId')}
              />
            </FormItem>
          </div>
        </If>
      </Form >
    </Loading>
  );
};

const RefEditForm = forwardRef(EditForm);

EditForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  setRefreshIndex: PropTypes.number,
};

export default RefEditForm;
