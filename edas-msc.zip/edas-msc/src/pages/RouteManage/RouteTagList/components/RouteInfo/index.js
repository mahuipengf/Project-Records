import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { CopyContent } from '@ali/cn-design';
import RouteInfo from 'containers/RouteInfo';
import AppInstance from './AppInstance';
import DataFields from 'components/DataFields';
import { useIntl } from '@ali/widget-hooks';
import DescEdit from 'components/DescEdit';
import services from 'services';
import CommonEvent from 'components/CommonEvent';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const RouteInfoComp = (props) => {
  const { value, handleEdit } = props;
  const [data, setData] = useState({});
  const intl = useIntl();

  const handleCallback = (val = {}) => {
    setData(val);
  };

  const handleChangeDetail = async (params, params2) => {
    await services.updateRoutePolicy({
      data: { Id: value.id, TriggerPolicy: value.triggerPolicy, Tag: value.tag, ExtraJson: params },
      params2
    });
  };

  const items = [
    // {
    //   dataIndex: 'namespaceId',
    //   label: intl('widget.common.microservice_space'),
    //   visible: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas',
    //   render: (val) => <CopyContent text={val}>{val}</CopyContent>
    // },
    {
      dataIndex: 'name',
      label: intl('widget.route.name'),
      visible: true,
      render: (val) => <CopyContent text={val}>{val}</CopyContent>
    },
    {
      dataIndex: 'appName',
      label: intl('widget.common.app_name'),
      visible: true,
      render: () => <CopyContent text={value.appName}>{value.appName}</CopyContent>
    },
    {
      dataIndex: 'tag',
      label: intl('widget.route.tag'),
      visible: !value.isIstioApp,
    },
    {
      dataIndex: 'carryData',
      label: intl('widget.route.link_delivery'),
      visible: !value.isIstioApp,
      render: val => val ? intl('widget.common.yes') : intl('widget.common.no'),
    },
    {
      dataIndex: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'extra' : 'extraJson',
      label: intl('widget.route.description'),
      visible: true,
      render: (val) => (
        <DescEdit
          name="description"
          value={val && val.description}
          handleSubmit={handleChangeDetail}
          onChange={(extraJson) => setData({ ...data, extraJson, extra: extraJson })}
        />
      ),
      span: 24,
    },
    {
      dataIndex: 'appId',
      label: intl('widget.route.app_instance'),
      visible: !value.isIstioApp,
      render: (val, record) => (
        <AppInstance
          appId={val}
          tag={record.tag}
          namespaces={{ namespaceId: record.namespaceId, region: record.namespaceId ? record.namespaceId.split(':')[0] : undefined }}
        />
      ),
      span: 24,
    },
  ];

  return (
    <div>
      <DataFields
        dataSource={data}
        items={items}
        title={intl('widget.common.basic_info')}
      />
      <div style={{ display: 'flex', alignItems: 'center', marginTop: 16 }}>
        <h4 className="common-title" style={{ width: 144, marginTop: 8 }}>
          <If condition={!value.isIstioApp}>{intl('widget.route.business_flow')}</If>
          <If condition={value.isIstioApp}>{intl('widget.route.flow_rate')}</If>
        </h4>
        <If condition={handleEdit}>
          <CommonEvent type="edit" text={intl('widget.common.edit')} onClick={() => handleEdit && handleEdit(value)} />
        </If>
      </div>
      <RouteInfo id={value.id} callback={handleCallback} />
    </div>
  );
};

RouteInfoComp.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  handleEdit: PropTypes.func,
};

export default RouteInfoComp;
