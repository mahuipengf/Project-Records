import React, { useEffect, useState } from 'react';
import styles from './index.less';
import { Loading } from '@ali/cn-design';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl } from '@ali/widget-hooks';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';

const AppInstance = (props) => {
  const { appId, tag, namespaces = {} } = props;
  const [appList, setAppList] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const instanceList = [];
  const intl = useIntl();

  useEffect(() => {
    if (appId) {
      if (!tag) {
        setAppList([]);
        return;
      }
      fetchData({ ...namespaces, appId, pageNumber: 1, pageSize: 50, tag, source: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'EDAS' : undefined });
    }
  }, [appId, tag]);

  const fetchData = async (params) => {
    setIsLoading(true);
    const res = await services.GetApplicationInstances({
      params,
      customErrorHandle: (err, response, callback) => {
        setIsLoading(false);
        callback();
      }
    });
    const { result = [] } = lowerFirstData(res);
    instanceList.push(...result);
    if (result.length && result.length === params.pageSize) {
      fetchData({ ...params, pageNumber: params.pageNumber + 1 });
    } else {
      setIsLoading(false);
      setAppList(instanceList);
    }
  };

  return (
    <Loading visible={isLoading} style={{ width: '100%' }}>
      <If condition={appList.length}>
        <div className={styles.appInstance}>
          <For each="item" index="index" of={appList}>
            <div key={index}>
              <span className={styles.item}>{`${item.ip || ''}`}</span>
            </div>
          </For>
        </div>
      </If>
      <If condition={!appList.length}>
        {intl('widget.common.no_data')}
      </If>
    </Loading>
  );
};

AppInstance.propTypes = {
  appId: PropTypes.string,
  tag: PropTypes.string,
};

export default AppInstance;
