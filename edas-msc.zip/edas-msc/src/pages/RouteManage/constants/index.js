export const PROTOCAL = {
  SPRINGCLOUD: 'Spring Cloud',
  DUBBO: 'Dubbo',
};
