import React, { useImperativeHandle, forwardRef } from 'react';
import { Radio, Form, Loading, Input } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { forEach, map, union, head, get, isEmpty, find, filter } from 'lodash';
import ConditionList from 'containers/ConditionList';
import PropTypes from 'prop-types';
import ScPath from 'containers/ScPath';
import DubboMethod from 'containers/DubboMethod';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';

const FormItem = Form.Item;

const RouteForm = (props, ref) => {
  const field = Field.useField();
  const intl = useIntl();
  const { init, validate, getValues, getValue, setValue } = field;
  const { value = {}, onChange, ruleId, serviceLoading = false, style } = props;
  const [appServiceData] = useGlobalState('appServiceData');
  const springCloudData = get(appServiceData, 'springCloud', []);
  const [component] = useGlobalState('component');
  const dubboServiceList = get(appServiceData, 'dubbo', []);

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  const handleChange = () => {
    onChange({ ...value, ...getValues() });
  };

  const handleSubmit = () => {
    return new Promise((resolve) => {
      validate((errors, values) => {
        resolve({ errors, values });
      });
    });
  };

  const handleValidatorConditions = (rule, val, callback) => {
    forEach(val, item => {
      if (getValue('protocol') === 'dubbo') {
        if (!(item.index >= 0) || !item.cond || (!item.value && item.value !== 0)) {
          callback(intl('widget.route.condition.rule_not_complete'));
          return;
        }
      }
      if (getValue('protocol') === 'springCloud' || getValue('protocol') === 'istio') {
        if (!item.type || !item.name || !item.cond || (!item.value && item.value !== 0)) {
          callback(intl('widget.route.condition.rule_not_complete'));
        }
      }
    });
    callback();
  };

  const modeData = [
    { value: 'AND', label: intl('widget.route.condition_and') },
    { value: 'OR', label: intl('widget.route.condition_or') },
  ];

  const PROTOCOL_DATA = () => {
    const arr = [
      {
        value: 'springCloud',
        label: 'Spring Cloud',
        visible: !isEmpty(appServiceData.springCloud) || (isEmpty(appServiceData.springCloud) && isEmpty(appServiceData.dubbo) && isEmpty(appServiceData.istio)),
      },
      {
        value: 'dubbo',
        label: 'Dubbo',
        visible: !isEmpty(appServiceData.dubbo) || (isEmpty(appServiceData.springCloud) && isEmpty(appServiceData.dubbo) && isEmpty(appServiceData.istio)),
      },
      {
        value: 'istio',
        label: intl('widget.service.service_mesh'),
        visible: (MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas') && (!isEmpty(appServiceData.istio) || (isEmpty(appServiceData.springCloud) && isEmpty(appServiceData.dubbo) && isEmpty(appServiceData.istio))),
      }
    ];
    // if (!isEmpty(appServiceData.springCloud)) {
    //   arr.push({ value: 'springCloud', label: 'Spring Cloud' });
    // }
    // if (!isEmpty(appServiceData.dubbo)) {
    //   arr.push({ value: 'dubbo', label: 'Dubbo' });
    // }
    // // 应用详情金丝雀支持istio
    // if (!isEmpty(appServiceData.istio) && component === 'AppInfo') {
    //   arr.push({ value: 'istio', label: intl('widget.service.service_mesh') });
    // }
    // // 应用详情金丝雀支持istio
    // if (isEmpty(appServiceData.springCloud) && isEmpty(appServiceData.dubbo) && isEmpty(appServiceData.istio) && component === 'AppInfo') {
    //   arr.push(...[
    //     { value: 'springCloud', label: 'Spring Cloud' },
    //     { value: 'dubbo', label: 'Dubbo' },
    //     { value: 'istio', label: intl('widget.service.service_mesh') }
    //   ]);
    //   return arr;
    // }
    // if (isEmpty(appServiceData.springCloud) && isEmpty(appServiceData.dubbo) && component !== 'AppInfo') {
    //   arr.push(...[
    //     { value: 'springCloud', label: 'Spring Cloud' },
    //     { value: 'dubbo', label: 'Dubbo' },
    //   ]);
    // }
    const newArr = filter(arr, item => item.visible);
    const firstItem = head(newArr) || {};
    const currentItem = find(newArr, { value: getValue('protocol') });
    if (!ruleId && isEmpty(currentItem)) {
      setValue('protocol', firstItem.value);
    }
    return newArr;
  };

  const getPaths = () => {
    const methods = map(springCloudData, item => item.methods || []);
    const newMethods = union(...methods);
    const paths = map(newMethods, item => item.paths || []);
    const newPaths = union(...paths);
    return map(newPaths, item => ({ value: item, label: item }));
  };

  return (
    <Form field={field} labelAlign="left" style={style}>
      <FormItem label={intl('widget.route.frame_type')} required>
        <Loading visible={serviceLoading}>
          <Radio.Group
            {...init('protocol', {
              initValue: value.protocol || (head(PROTOCOL_DATA()) && head(PROTOCOL_DATA()).value),
              rules: [
                {
                  required: true,
                  message: intl('widget.route.frame_type_errorr'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            dataSource={PROTOCOL_DATA()}
            disabled={!!ruleId && value.uid > 0}
          />
        </Loading>
      </FormItem>
      <If condition={getValue('protocol') === 'dubbo'}>
        <FormItem label={intl('widget.app.service_method')} required={getValue('protocol') === 'dubbo'}>
          <DubboMethod
            {...init('method', {
              initValue: value.method,
              rules: [
                {
                  required: getValue('protocol') === 'dubbo',
                  message: intl('widget.route.service_method_error'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            dataSource={dubboServiceList}
          />
        </FormItem>
      </If>
      <If condition={getValue('protocol') === 'springCloud'}>
        <FormItem label={intl('widget.route.path')}>
          <ScPath
            {...init('path', {
              initValue: value.path,
              props: {
                onChange: handleChange
              }
            })}
            hasClear
            showSearch
            style={{ width: '85%' }}
            dataSource={getPaths()}
            placeholder={intl('widget.route.path_placeholder')}
          />
        </FormItem>
      </If>
      <If condition={getValue('protocol') === 'istio'}>
        <FormItem label={intl('widget.route.path')}>
          <Input
            {...init('path', {
              initValue: value.path,
              props: {
                onChange: handleChange
              }
            })}
            style={{ width: '100%' }}
            placeholder={intl('widget.route.path_placeholder')}
          />
        </FormItem>
      </If>
      <FormItem label={intl('widget.route.condition_mode')} required>
        <Radio.Group
          {...init('condition', {
            initValue: value.condition || 'AND',
            rules: [
              {
                required: true,
                message: intl('widget.route.condition_mode_error'),
              },
            ],
            props: {
              onChange: handleChange
            }
          })}
          dataSource={modeData}
        />
      </FormItem>
      <FormItem
        label={intl('widget.route.condition_list')}
        required
      >
        <ConditionList
          {...init('conditions', {
            initValue: value.conditions || [],
            rules: [
              {
                required: true,
                message: intl('widget.route.condition_list_error'),
              },
              {
                validator: handleValidatorConditions,
              }
            ],
            props: {
              onChange: handleChange
            }
          })}
          method={getValue('method')}
          protocol={getValue('protocol')}
        />
      </FormItem>
    </Form >
  );
};

const RefRouteForm = forwardRef(RouteForm);

RouteForm.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
  style: PropTypes.objectOf(PropTypes.any),
  ruleId: PropTypes.number,
  serviceLoading: PropTypes.bool,
};

export default RefRouteForm;

