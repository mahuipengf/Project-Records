import React from 'react';
import styles from './index.less';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';

const AppInstance = (props) => {
  const { version = '0.0', list = [], rate = 0, old = true, style = {} } = props;
  const intl = useIntl();

  return (
    <div className={styles.appContainer} style={{ boxShadow: style.boxShadow }}>
      <div className={styles.left}>
        <div className={styles.leftContainer} style={{ color: style.color }}>
          <div className={!old ? styles.version3 : styles.version2} style={{ color: style.color }}>{`${version}`}</div>
          <div>{intl('widget.common.brackets', { text: `${rate}%` })}</div>
        </div>
      </div>
      <div className={styles.right}>
        <If condition={list.length}>
          <For each="item" index="index" of={list}>
            <div key={index}>
              <span className={styles.item}>{`${item.Ip || ''}:${item.Port || ''}`}</span>
            </div>
          </For>
        </If>
        <If condition={!list.length}>
          <span style={{ marginLeft: 4 }}>{intl('widget.common.no_data')}</span>
        </If>
      </div>
    </div>
  );
};

AppInstance.propTypes = {
  version: PropTypes.string,
  rate: PropTypes.number,
  old: PropTypes.bool,
  list: PropTypes.arrayOf(PropTypes.object),
  style: PropTypes.objectOf(PropTypes.any),
};

export default AppInstance;
