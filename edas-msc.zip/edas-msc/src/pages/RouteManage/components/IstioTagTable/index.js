import React, { useState, useEffect } from 'react';
import { useGlobalState, useIntl } from '@ali/widget-hooks';
import { Table, NumberPicker } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { assign, map, sumBy, uniqueId } from 'lodash';
import PropTypes from 'prop-types';
import services from 'services';
import { MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';

const IstioTagTable = (props) => {
  const { value, onChange, namespaces, appId, show } = props;
  const field = Field.useField();
  const { init } = field;
  const [searchValues] = useGlobalState('searchValues');
  const [tagList, setTagList] = useState(value);
  const [isLoadingTag, setIsLoadingTag] = useState(false);

  const intl = useIntl();
  const { regionId, namespaceId } = assign({}, searchValues, MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? namespaces : {});

  useEffect(() => {
    setTagList(value);
  }, [value]);

  useEffect(() => {
    handleChangeAppId(appId);
  }, [appId]);

  const handleChangeAppId = async (val) => {
    if (!val) return;
    setIsLoadingTag(true);
    const res = await services.ListApplicationTagInstancese({
      params: {
        regionId,
        namespaceId,
        appId: val,
        protocol: 'istio',
        source: MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? 'EDAS' : undefined
      },
      customErrorHandle: (err, response, callback) => {
        setIsLoadingTag(false);
        callback();
      }
    });
    setIsLoadingTag(false);
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    const total = sumBy(data, 'instanceNum');
    let totalRate = 0;
    const newData = map(data, (item, index) => {
      if (index < data.length - 1) {
        const instanceRate = item.instanceRate === undefined ? Math.round(((item.instanceNum || 0) * 100 / total)) : item.instanceRate;
        totalRate += instanceRate;
        return ({
          ...item,
          uid: uniqueId(),
          instanceRate,
          rate: item.rate === undefined ? Math.round(((item.instanceNum || 0) * 100 / total)) : item.rate,
        });
      }
      return ({
        ...item,
        uid: uniqueId(),
        instanceRate: 100 - totalRate,
        rate: item.rate === undefined ? (100 - totalRate) : item.rate,
      });
    });
    if (!value) {
      setTagList(newData);
    }
    onChange && onChange(newData);
  };

  const handleChange = (uid, obj) => {
    const newData = map(tagList, item => item.uid === uid ? ({ ...item, ...obj }) : item);
    onChange && onChange(newData);
  };

  const rateRender = (val, index, record) => (
    <React.Fragment>
      <If condition={show}>{val}</If>
      <If condition={!show}>
        <NumberPicker
          {...init(`rate-${record.uid}`, {
            initValue: val || 0,
            props: {
              onChange: (v) => handleChange(record.uid, { rate: v || 0 })
            }
          })}
          max={100}
          min={0}
          style={{ width: '100%' }}
        />
      </If>
    </React.Fragment>
  );

  return (
    <Table
      dataSource={tagList}
      loading={isLoadingTag}
    >
      <Table.Column title={intl('widget.route.tag')} dataIndex="tag" />
      <Table.Column title={intl('widegt.route_tag.instance_number')} dataIndex="instanceNum" />
      <Table.Column title={intl('widget.route_tag.point_rate')} dataIndex="instanceRate" />
      <Table.Column
        title={intl('widget.route.flow_rate1', { n: '%' })}
        dataIndex="rate"
        cell={rateRender}
      />
    </Table>
  );
};

IstioTagTable.propTypes = {
  onChange: PropTypes.func,
  show: PropTypes.bool,
  appId: PropTypes.number,
  value: PropTypes.arrayOf(PropTypes.any),
  namespaces: PropTypes.objectOf(PropTypes.any),
};

export default IstioTagTable;

