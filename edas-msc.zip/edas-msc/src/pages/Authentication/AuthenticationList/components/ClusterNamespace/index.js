import React, { useEffect } from 'react';
import { isEmpty, split, find, head, get } from 'lodash';
import { Select } from '@ali/cn-design';
import PropTypes from 'prop-types';

const ClusterNamespace = ({ onChange, value, fetchData, dataSource, hasDefault = true }) => {
  useEffect(() => {
    if (!fetchData) return;
    fetchData();
  }, []);

  useEffect(() => {
    if (!hasDefault) return;
    if (!value && !isEmpty(dataSource)) {
      const firstCluster = head(dataSource);
      if (!isEmpty(firstCluster)) {
        const firstK8sNamespace = get(firstCluster, 'child[0]', {});
        onChange(`${firstCluster.value}+${firstK8sNamespace.value}`);
      }
    }
  }, [dataSource]);

  const handleChange = (val) => {
    onChange(val);
  };

  const handleChangeCluster = (val) => {
    const clusterItem = find(dataSource, { value: val });
    const k8sNamespace = get(clusterItem, 'child[0]', {});
    handleChange(`${val}+${k8sNamespace.value}`);
  };

  const [a, b] = split(value, '+');
  return (
    <React.Fragment>
      <Select
        showSearch
        style={{ width: '47%', marginRight: 8 }}
        onChange={(val) => handleChangeCluster(val)}
        dataSource={dataSource}
        value={a}
      />
      <Select
        showSearch
        style={{ width: '47%', marginTop: 4 }}
        onChange={(val) => handleChange(`${a}+${val}`)}
        dataSource={find(dataSource, { value: a })?.child}
        value={b}
      />
    </React.Fragment>
  );
};

ClusterNamespace.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.arrayOf(PropTypes.object),
  fetchData: PropTypes.func,
  dataSource: PropTypes.arrayOf(PropTypes.object),
  hasDefault: PropTypes.bool
};

export default ClusterNamespace;
