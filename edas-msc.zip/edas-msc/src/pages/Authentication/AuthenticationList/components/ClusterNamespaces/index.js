import React from 'react';
import { useIntl } from '@ali/widget-hooks';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { map, filter, uniqueId, find, isEmpty, head, get, size } from 'lodash';
import { Icon } from '@ali/cn-design';
import PropTypes from 'prop-types';
import ClusterNamespace from '../ClusterNamespace';

const ClusterNamespaces = ({ onChange, value = [], dataSource }) => {
  const intl = useIntl();

  const handleAdd = () => {
    const newValue = [...value, { uid: uniqueId() }];
    onChange(newValue);
  };

  const handleDelete = (uid) => {
    const newValue = filter(value, item => item.uid !== uid);
    onChange(newValue);
  };

  const handleChange = (uid, val) => {
    const newValue = map(value, item => item.uid === uid ? { ...item, value: val } : item);
    onChange(newValue);
  };

  const getDataSource = () => map(dataSource, (item, index) => {
    const child = map(get(item, 'child', []), c => {
      const label = `${item.value}+${c.value}`;
      return { ...c, disabled: !!find(value, { value: label }) };
    });
    if (!find(child, { disabled: false })) {
      return { ...item, disabled: true, child };
    }
    return { ...item, child };
  });

  return (
    <React.Fragment>
      <For each="item" of={value}>
        <div key={item.uid} style={{ marginTop: 8 }}>
          <ClusterNamespace
            hasDefault={false}
            showSearch
            onChange={(val) => handleChange(item.uid, val)}
            dataSource={getDataSource()}
            value={item.value}
          />
          <If condition={!isEmpty(value)}>
            <Icon type="delete" size="xs" style={{ marginLeft: 8, cursor: 'pointer' }} onClick={() => handleDelete(item.uid)} />
          </If>
        </div>
      </For>
      <div style={{ display: 'flex', marginTop: 8 }}>
        <Actions expandTriggerType="hover" >
          <LinkButton key="1" onClick={handleAdd}><Icon type="add" size="xs" />{intl('widget.authentication.add_callee')}</LinkButton>
        </Actions>
      </div>
    </React.Fragment>
  );
};

ClusterNamespaces.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.arrayOf(PropTypes.object),
  dataSource: PropTypes.arrayOf(PropTypes.object),
};

export default ClusterNamespaces;
