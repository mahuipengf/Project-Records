import React, { useImperativeHandle, forwardRef, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Radio, Switch, Message, Loading, RemoteSelect } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { MSC_WIDGET_CONSOLE_CONFIG, NNAME_PATTERN, EDAS_CHANNEL_INFO } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';
import { map, head, find, isEmpty, uniqBy, forEach, uniqueId, filter, orderBy, split, uniq, get } from 'lodash';
import Rules from '../RuleList';
import { Namespace } from '@ali/mamba-namespace';
import ClusterNamespace from '../ClusterNamespace';

const FormItem = Form.Item;

const EditForm = (props, ref) => {
  const field = Field.useField();
  const { value, setRefreshIndex } = props;
  const intl = useIntl();
  const { init, validate, getValue, setValue, setValues, getValues } = field;
  const [searchValues] = useGlobalState('searchValues');
  const [fetchAppTime, setFetchAppTime] = useState(undefined);
  const [appList, setAppList] = useGlobalState('appList');
  const [isLoading, setIsLoading] = useState(false);
  const [serviceLoading, setServiceLoading] = useState(false);
  const [appServiceData, setAppServiceData] = useGlobalState('appServiceData');
  const [k8sNamespaceData, setK8sNamespaceData] = useGlobalState('k8sNamespaceData');

  const currentAppList = [];

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  useEffect(() => {
    if (value.id) {
      fetchData();
    }
  }, [value]);

  const fetchData = async () => {
    const { id, tenantId, source, regionId, namespaceId } = value;
    setIsLoading(true);
    const params = { policyId: id, regionId, namespaceId, tenantId };
    const res = await services.fetchAuthenticationInfo({
      data: params,
      customErrorHandle: (err, response, callback) => {
        setIsLoading(false);
        callback();
      }
    });
    setIsLoading(false);
    const { name, protocol, appId, enable, regionId: region, namespaceId: namespace, authRule = [], authType = 0, k8sNamespace } = lowerFirstData(res) || {};
    const data = {
      id,
      policyId: id,
      name,
      protocol,
      authType,
      appId,
      k8sNamespace,
      enable,
      source,
      namespaces: { regionId: region, namespaceId: namespace },
      authRule: map(authRule, item => {
        if (authType === 1) {
          return ({
            uid: uniqueId(),
            black: item.black,
            k8sNamespaces: map(item.k8sNamespaces, child => ({ uid: uniqueId(), value: child })),
          });
        } else {
          if (!item.method || isEmpty(item.method)) {
            return ({
              uid: uniqueId(),
              ...item,
              method: undefined,
              appIds: map(item.appIds, child => ({ uid: uniqueId(), value: child })),
            });
          }
          const { serviceName = '', version = '', group = '', name: methodName = '', parameterTypes = [], returnType = '' } = item.method;
          return ({
            uid: uniqueId(),
            ...item,
            method: `${serviceName}:${version}:${group}:${methodName}:${parameterTypes}:${returnType}`,
            appIds: map(item.appIds, child => ({ uid: uniqueId(), value: child }))
          });
        }
      }),
    };
    setValues({ ...data });
    // validate('authRule'); // 修复偶现 authRule 显示不存在
  };

  useEffect(() => {
    if (getValue('appId')) {
      setServiceLoading(true);
      Promise.all([fetchDubboServiceList(getValue('appId')), SpringCloudfetchServiceList(getValue('appId')), fetchIstioServiceList(getValue('appId'))]).then(res => {
        setTimeout(() => {
          setAppServiceData({
            dubbo: res[0],
            springCloud: res[1],
            istio: (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && !get(window, 'EDAS_USER_FEATURES.featureIstioEnable', false)) ? [] : res[2], // edas istio 有开关
          });
          setServiceLoading(false);
        }, 500);
      });
    }
  }, [getValue('appId')]);

  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        if (errors) {
          console.log('errors', errors);
          return reject(errors);
        }
        const { id, name, protocol, appId, enable, namespaces = {}, authRule: authRules, authType, k8sNamespace } = values;
        const authRule = map(authRules, item => {
          if (authType === 1) {
            return ({
              black: item.black,
              k8sNamespaces: map(item.k8sNamespaces, child => child.value),
            });
          }
          if (authType === 0) {
            const [serviceName, version, group, methodName, parameterTypes = [], returnType] = split(item.method, ':');
            return ({
              all: item.all,
              black: item.black,
              appIds: map(item.appIds, child => child.value),
              method: protocol === 'DUBBO' ? {
                serviceName,
                version,
                group,
                name: methodName,
                parameterTypes: split(parameterTypes, ','),
                returnType,
              } : undefined,
              path: (protocol === 'SPRING_CLOUD' || protocol === 'istio') ? item.path : undefined
            });
          }
          return item;
        });
        const params = {
          id,
          policyId: id,
          name,
          protocol,
          authType,
          regionId: namespaces.regionId || searchValues.regionId,
          namespaceId: namespaces.namespaceId || searchValues.namespaceId,
          enable,
          authRule,
          appId: authType === 0 ? appId : undefined,
          k8sNamespace: authType === 1 ? k8sNamespace : undefined,
          source: searchValues.source,
        };

        id ? await services.updateAuthentication({
          data: params,
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        }) : await services.addAuthentication({
          data: params,
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        id ? Message.success(intl('widget.common.update_successful')) : Message.success(intl('widget.common.add_successful'));
        resolve();
        setRefreshIndex(Date.now());
      });
    });
  };

  const fetchDubboServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: searchValues.regionId,
      namespace: searchValues.namespaceId,
      serviceType: 'dubbo',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || searchValues.regionId,
        namespace: namespaces.namespaceId || searchValues.namespaceId,
        serviceType: 'dubbo',
        searchType: 'app',
        searchValue: appId
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    const newData = map(data || [], item => {
      const newMethods = map(item.methods, child => {
        return ({
          ...child,
          key: `${child.name}:${child.parameterTypes}:${child.returnType}`,
          value: `${child.name}:${child.parameterTypes}:${child.returnType}`,
          label: `${child.name}(${child.parameterTypes})`,
        });
      });
      return ({
        ...item,
        methods: newMethods,
        value: `${item.serviceName}:${item.version}:${item.group}`,
        key: `${item.serviceName}:${item.version}:${item.group}`,
        label: `${item.serviceName}:${item.version}:${item.group}`,
      });
    });
    return newData;
  };

  const SpringCloudfetchServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: searchValues.regionId,
      namespace: searchValues.namespaceId,
      serviceType: 'springCloud',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || searchValues.regionId,
        namespace: namespaces.namespaceId || searchValues.namespaceId,
        serviceType: 'springCloud',
        searchType: 'app',
        searchValue: appId
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    return data;
  };

  const fetchIstioServiceList = async (appId) => {
    const namespaces = getValue('namespaces') || {};
    let params = {
      region: searchValues.regionId,
      namespace: searchValues.namespaceId,
      serviceType: 'istio',
      appId,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        region: namespaces.regionId || searchValues.regionId,
        namespace: namespaces.namespaceId || searchValues.namespaceId,
        serviceType: 'istio',
        searchType: 'app',
        searchValue: appId,
      };
    }
    const res = await services.getServiceList({ data: params });
    const data = lowerFirstData(MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? res.data : res) || [];
    return data;
  };

  // 命名空间 -> 微服务空间
  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  // 命名空间 -> 微服务空间
  const fetchNamespaces = async (regionId) => {
    const { data = [] } = await services.fetchNamespaces({ params: { regionId } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  const handleVilidorName = async (rule, val, callback) => {
    const namespaces = getValue('namespaces') || {};
    const params = {
      policyName: val,
      regionId: namespaces.regionId || searchValues.regionId,
      namespaceId: namespaces.namespaceId || searchValues.namespaceId,
    };
    const res = await services.CheckAuthPolicyName({ data: params });
    if (res) {
      callback();
    } else {
      callback(intl('widget.authentication.name_enabled'));
    }
  };

  const fetchAppList = async () => {
    const { namespaces = {} } = getValues();
    const currentNamespaceId = namespaces.namespaceId || searchValues.namespaceId;
    const currentRegionId = namespaces.regionId || searchValues.regionId;
    const { data = [] } = await services.GetAppList({
      params: {
        regionId: currentRegionId,
        namespaceId: currentNamespaceId,
      }
    });
    let Data = map(data, item => ({
      ...item,
      key: item.appId,
      value: item.appId,
      label: item.appName,
    }));
    if (currentNamespaceId) {
      Data = filter(Data, item => item.regionId === currentNamespaceId); // 过滤掉命名空间不一致的应用，因为在默认命名空间下，会拿到所有的数据
    }
    Data = orderBy(Data, ['label']);
    const firstItem = head(Data);
    if (firstItem && !getValue('appId')) {
      setValue('appId', firstItem.value);
    }
    setAppList(Data);
    return { Data };
  };

  const GetApplicationList = async ({ pageNumber = 1, pageSize = 50 }) => {
    const { Result = [] } = await services.GetAppList({
      params: {
        regionId: searchValues.regionId,
        pageNumber,
        pageSize,
      }
    });
    const Data = map(Result, item => ({
      ...item,
      key: item.AppId,
      value: item.AppId,
      label: item.AppName,
    }));
    currentAppList.push(...Data);
    if (Result.length && Result.length === pageSize) {
      return GetApplicationList({ pageNumber: pageNumber + 1, pageSize });
    } else {
      // let IsNOistioAppList = filter(currentAppList, item => item.Source !== 'ASM');
      const IsNoIstioAppList = orderBy(currentAppList, ['label']);
      const firstItem = head(IsNoIstioAppList);
      if (firstItem && !getValue('appId')) {
        setValue('appId', firstItem.value);
      }
      setAppList(IsNoIstioAppList);
      return { Data: IsNoIstioAppList };
    }
  };

  const handleValidatorRules = (rule, val, callback) => {
    console.log(val);
    const authType = getValue('authType');
    /**
     * 应用类型
     */
    if (authType === 0) {
      if (getValue('protocol') === 'SPRING_CLOUD' || getValue('protocol') === 'istio') {
        const pathEmpty = find(val, item => !item.all && !item.path); // sc 或 istio 指定接口  path 不存在
        if (pathEmpty) {
          callback(intl('widget.authentication.callee_path_error'));
          return;
        }
        const deduplication = uniqBy(val, 'path'); // path 重复
        if (deduplication.length < val.length) {
          callback(intl('widget.authentication.callee_path_repeat'));
        }
      }
      if (getValue('protocol') === 'DUBBO') {
        const pathEmpty = find(val, item => !item.all && !item.method); // dobbo 指定接口 method 不存在
        if (pathEmpty) {
          callback(intl('widget.authentication.callee_interface_error'));
        }
      }
      // appIds 未填
      forEach(val, item => {
        if (isEmpty(item.appIds) || find(item.appIds, child => !child.value)) {
          callback(intl('widget.authentication.caller_error'));
        }
      });
    }
    /**
     * k8s namspace 类型
     */
    if (authType === 1) {
      // 集群 或 namespace 未填
      forEach(val, item => {
        if (isEmpty(item.k8sNamespaces) || find(item.k8sNamespaces, child => !child.value)) {
          callback(intl('widget.authentication.caller_error'));
        }
      });
    }
    callback();
  };

  const PROTOCOL_DATA = () => {
    // k8s namespace
    if (getValue('authType') === 1) {
      return [
        { value: 'SPRING_CLOUD', label: 'Spring Cloud' },
        { value: 'DUBBO', label: 'Dubbo' },
        { value: 'istio', label: intl('widget.service.service_mesh') }
      ];
    }
    // 应用类型
    const arr = [];
    if (!isEmpty(appServiceData.springCloud)) {
      arr.push({ value: 'SPRING_CLOUD', label: 'Spring Cloud' });
    }
    if (!isEmpty(appServiceData.dubbo)) {
      arr.push({ value: 'DUBBO', label: 'Dubbo' });
    }
    if (!isEmpty(appServiceData.istio)) {
      arr.push({ value: 'istio', label: intl('widget.service.service_mesh') });
    }
    if (isEmpty(appServiceData.springCloud) && isEmpty(appServiceData.dubbo) && isEmpty(appServiceData.istio)) {
      arr.push(...[
        { value: 'SPRING_CLOUD', label: 'Spring Cloud' },
        { value: 'DUBBO', label: 'Dubbo' },
        // { value: 'istio', label: intl('widget.service.service_mesh') }
      ]);

      if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && get(window, 'EDAS_USER_FEATURES.featureIstioEnable' && EDAS_CHANNEL_INFO.toLowerCase() !== 'finance', false)) {
        arr.push({ value: 'istio', label: intl('widget.service.service_mesh') });
      }
    }
    const firstItem = head(arr) || {};
    const currentItem = find(arr, { value: getValue('protocol') });
    if (!value.id && isEmpty(currentItem)) {
      setValue('protocol', firstItem.value);
    }
    return arr;
  };

  const fetchK8sNamespace = async () => {
    const namespaces = getValue('namespaces') || {};
    const res = await services.ListKubernetesNamespace({
      params: {
        region: namespaces.regionId || searchValues.regionId,
      }
    });
    const newArr = map(res || [], item => {
      const [a, b] = split(item, '+');
      return [a, b];
    });
    const cluster = uniq(map(newArr, item => item[0]));
    const clusterArr = map(cluster, item => ({ value: item, label: item, child: [] }));
    forEach(newArr, item => {
      const clusterItem = find(clusterArr, { value: item[0] });
      clusterItem && clusterItem.child.push({ value: item[1], label: item[1] });
    });
    setK8sNamespaceData(clusterArr);
  };

  return (
    <Loading visible={isLoading} style={{ width: '100%' }}>
      <Form field={field} labelAlign="left">
        <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
          <If condition={!value.id}>
            <FormItem label={intl('widget.common.microservice_space')} required>
              <Namespace
                {...init('namespaces', {
                  initValue: { regionId: searchValues.regionId, namespaceId: searchValues.namespaceId },
                  rules: [
                    {
                      required: true,
                      message: intl('widget.common.please_select_microservice_space'),
                    },
                  ],
                  props: {
                    onChange: () => {
                      setValue('appId', undefined);
                      setFetchAppTime(Date.now());
                    }
                  }
                })}
                style={{ width: 360 }}
                fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
                fetchNamespaces={fetchNamespaces}
              />
            </FormItem>
          </If>
        </If>
        <FormItem label={intl('widget.authentication.rule_name')} required>
          <Input
            {...init('name', {
              // initValue: value.name,
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.name_input_error'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.authentication.name_pattern'),
                },
                {
                  validator: handleVilidorName
                }
              ],
            })}
            disabled={value.id}
            placeholder={intl('widget.authentication.name_placeholder')}
            maxLength={64}
            minLength={1}
            showLimitHint
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem label={intl('widget.authentication.callee_type')} required>
          <Radio.Group
            dataSource={
              MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'
                ? [
                  { value: 0, label: intl('widget.home.app') },
                ]
                : [
                  { value: 0, label: intl('widget.home.app') },
                  { value: 1, label: 'K8s Namespace' },
                ]}
            {...init('authType', {
              initValue: value.id ? '' : 0,
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.please_inter_callee_type'),
                },
              ],
            })}
            disabled={value.id}
          />
        </FormItem>
        <If condition={getValue('authType') === 0}>
          <FormItem label={intl('widget.authentication.callee_name', { type: intl('widget.home.app') })} required>
            <RemoteSelect
              {...init('appId', {
                rules: [
                  {
                    required: true,
                    message: intl('widget.authentication.callee_error'),
                  },
                ],
                props: {
                  onChange: () => setValue('changeAppId', Date.now()) // 需改 app 时，需要更新部分数据
                }
              })}
              followTrigger
              disabled={value.id}
              style={{ width: '97%' }}
              showIcon
              refreshIndex={fetchAppTime}
              fetchData={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? fetchAppList : GetApplicationList}
              // isPollingApi
              placeholder={intl('widget.authentication.callee_placeholder')}
            />
          </FormItem>
        </If>
        <If condition={getValue('authType') === 1}>
          <FormItem label={intl('widget.authentication.callee_name', { type: 'K8s Namespace' })} required>
            <ClusterNamespace
              {...init('k8sNamespace', {
                rules: [
                  {
                    required: true,
                    message: intl('widget.authentication.callee_error'),
                  },
                ],
              })}
              dataSource={k8sNamespaceData}
              fetchData={fetchK8sNamespace}
              disabled={value.id}
            />
          </FormItem>
        </If>
        <FormItem label={intl('widget.authentication.callee_protocol')} required>
          <Loading visible={serviceLoading}>
            <Radio.Group
              dataSource={PROTOCOL_DATA()}
              {...init('protocol', {
                // initValue: value.protocol,
                rules: [
                  {
                    required: true,
                    message: intl('widget.authentication.callee_protocol_error'),
                  },
                ],
              })}
              disabled={value.id}
            />
          </Loading>
        </FormItem>
        <FormItem required className="auth-rule">
          <Rules
            {...init('authRule', {
              initValue: [],
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.both_rule_error'),
                },
                {
                  validator: handleValidatorRules
                }
              ],
            })}
            protocol={getValue('protocol')}
            appId={getValue('appId')}
            changeAppId={getValue('changeAppId')}
            authType={getValue('authType')}
            k8sNamespace={getValue('k8sNamespace')}
          />
        </FormItem>
        <FormItem label={intl('widget.authentication.default_state')}>
          <Switch
            {...init('enable', {
              valueName: 'checked', initValue: !!value.enable
            })}
          />
        </FormItem>
      </Form >
    </Loading>
  );
};

const RefEditForm = forwardRef(EditForm);

EditForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  setRefreshIndex: PropTypes.number,
};

export default RefEditForm;
