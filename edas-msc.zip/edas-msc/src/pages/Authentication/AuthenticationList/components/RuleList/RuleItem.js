import React, { useRef, useEffect } from 'react';
import { Form, Field } from '@alicloud/console-components';
import { Radio, Input } from '@ali/cn-design';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { map, find, union, filter, get } from 'lodash';
import AppIds from './AppIds';
import PropTypes from 'prop-types';
import ScPath from 'containers/ScPath';
import ClusterNamespaces from '../ClusterNamespaces';
import DubboMethod from 'containers/DubboMethod';

const FormItem = Form.Item;

const RuleItem = (props) => {
  const { value, protocol, onChange, authType } = props;
  const field = Field.useField({ scrollToFirstError: true });
  const { init, validate, getValues, setValues } = field;
  const intl = useIntl();
  const [appServiceData] = useGlobalState('appServiceData');
  const springCloudServiceList = get(appServiceData, 'springCloud', []);
  const dubboServiceList = get(appServiceData, 'dubbo', []);
  const [k8sNamespaceData] = useGlobalState('k8sNamespaceData');
  const [appList] = useGlobalState('appList');

  const editFormRef = useRef();

  useEffect(() => {
    const black = get(value, 'black');
    const appIds = get(value, 'appIds', []);
    const all = get(value, 'all');
    const method = get(value, 'method');
    const path = get(value, 'path');
    const k8sNamespaces = get(value, 'k8sNamespaces', []);
    setValues({ black, appIds, all, method, path, k8sNamespaces });
  }, [value]);

  const handleChange = () => {
    onChange({ ...value, ...getValues() });
    validate();
  };

  const handleVilidataAppIds = (rule, val, callback) => {
    if (!val || find(val, item => !item.value)) {
      callback(intl('widget.authentication.caller_error'));
    }
    callback();
  };

  const AUTHENTICATION_TYPE_DATA = [
    { value: false, label: intl('widget.authentication.white_list') },
    { value: true, label: intl('widget.authentication.black_list') },
  ];

  const PROTOCOL_DATA = (bool, pro) => {
    const arr = [
      {
        all: true,
        DUBBO: intl('widget.authentication.all_service_all_interface'),
        SPRING_CLOUD: intl('widget.authentication.all_path'),
        istio: intl('widget.authentication.all_path'),
      },
      {
        all: false,
        DUBBO: intl('widget.authentication.all_interface'),
        SPRING_CLOUD: intl('widget.authentication.all_path'),
        istio: intl('widget.authentication.all_path')
      },
    ];
    return find(arr, { all: bool }, {})[pro];
  };

  const getPaths = () => {
    const methods = map(springCloudServiceList, item => item.methods || []);
    const newMethods = union(...methods);
    const paths = map(newMethods, item => item.paths || []);
    const newPaths = union(...paths);
    return map(newPaths, item => ({ value: item, label: item }));
  };

  return (
    <Form field={field} labelAlign="left" ref={editFormRef} style={{ paddingTop: 16 }}>
      <If condition={authType === 0}>
        <If condition={value.all}>
          <FormItem
            label={
              intl((protocol === 'DUBBO' || protocol === 'istio') ? 'widget.authentication.callee_interface' : 'widget.authentication.callee_path')}
          >
            <span style={{ lineHeight: '32px' }}>{PROTOCOL_DATA(value.all, protocol, intl)}</span>
          </FormItem>
        </If>
        <If condition={!value.all}>
          <If condition={protocol === 'DUBBO'}>
            <FormItem
              label={intl('widget.authentication.callee_interface')}
              required
            >
              <DubboMethod
                {...init('method', {
                  initValue: value.method,
                  rules: [
                    {
                      required: true,
                      message: intl('widget.authentication.caller_interface_error'),
                    },
                  ],
                  props: {
                    onChange: handleChange
                  }
                })}
                dataSource={dubboServiceList}
              />
            </FormItem>
          </If>
          <If condition={protocol === 'SPRING_CLOUD'}>
            <FormItem label={intl('widget.authentication.callee_path')} required>
              <ScPath
                {...init('path', {
                  initValue: value.path,
                  rules: [
                    {
                      required: true,
                      message: intl('widget.authentication.caller_path_placeholder'),
                    },
                  ],
                  props: {
                    onChange: handleChange
                  }
                })}
                hasClear
                showSearch
                style={{ width: '80%' }}
                dataSource={getPaths()}
                placeholder={intl('widget.authentication.caller_path_placeholder')}
              />
            </FormItem>
          </If>
          <If condition={protocol === 'istio'}>
            <FormItem label={intl('widget.authentication.callee_path')} required>
              <Input
                {...init('path', {
                  initValue: value.path,
                  rules: [
                    {
                      required: true,
                      message: intl('widget.authentication.caller_path_placeholder'),
                    },
                  ],
                  props: {
                    onChange: handleChange
                  }
                })}
                style={{ width: '100%' }}
                placeholder={intl('widget.authentication.caller_path_placeholder')}
              />
            </FormItem>
          </If>
        </If>
        <FormItem label={intl('widget.authentication.type')} required>
          <Radio.Group
            {...init('black', {
              initValue: value.black,
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.type_error'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            dataSource={AUTHENTICATION_TYPE_DATA}
          />
        </FormItem>
        <FormItem
          label={intl('widget.authentication.caller_type', { type: intl('widget.home.app') })}
          required
        >
          <AppIds
            {...init('appIds', {
              initValue: value.appIds || [],
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.callee_error'),
                },
                {
                  validator: handleVilidataAppIds
                }
              ],
              props: {
                onChange: handleChange
              }
            })}
            dataSource={appList}
            placeholder={intl('widget.authentication.callee_placeholder')}
          />
        </FormItem>
      </If>
      <If condition={authType === 1}>
        <FormItem label={intl('widget.authentication.type')} required>
          <Radio.Group
            {...init('black', {
              initValue: value.black,
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.type_error'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            dataSource={AUTHENTICATION_TYPE_DATA}
          />
        </FormItem>
        <FormItem
          label={intl('widget.authentication.caller_type', { type: 'K8s Namespace' })}
          required
        >
          <ClusterNamespaces
            {...init('k8sNamespaces', {
              initValue: value.k8sNamespaces || [],
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.callee_error'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            dataSource={k8sNamespaceData}
            placeholder={intl('widget.authentication.callee_placeholder')}
          />
        </FormItem>
      </If>
    </Form >
  );
};

RuleItem.propTypes = {
  onChange: PropTypes.func,
  protocol: PropTypes.string,
  value: PropTypes.objectOf(PropTypes.any),
  authType: PropTypes.string,
};

export default RuleItem;
