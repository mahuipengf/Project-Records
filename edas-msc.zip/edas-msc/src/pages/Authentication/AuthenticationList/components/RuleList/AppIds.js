import React from 'react';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { map, filter, uniqueId, find, isEmpty } from 'lodash';
import { Icon, Select } from '@ali/cn-design';
import PropTypes from 'prop-types';

const AppIds = ({ onChange, value = [], dataSource }) => {
  const intl = useIntl();

  const handleAdd = () => {
    const newValue = [...value, { uid: uniqueId() }];
    onChange(newValue);
  };

  const handleDelete = (uid) => {
    const newValue = filter(value, item => item.uid !== uid);
    onChange(newValue);
  };

  const handleChange = (uid, val) => {
    const newValue = map(value, item => item.uid === uid ? { ...item, value: val } : item);
    onChange(newValue);
  };

  const getDataSource = () => map(dataSource, item => {
    if (find(value, { value: item.value })) return ({ ...item, disabled: true });
    return item;
  });

  return (
    <React.Fragment>
      <For each="item" of={value}>
        <div key={item.uid}>
          <Select
            showSearch
            style={{ width: '95%', marginTop: 4 }}
            onChange={(val) => handleChange(item.uid, val)}
            dataSource={getDataSource()}
            value={item.value}
          />
          <If condition={!isEmpty(value)}>
            <Icon type="delete" size="xs" style={{ marginLeft: 8, cursor: 'pointer' }} onClick={() => handleDelete(item.uid)} />
          </If>
        </div>
      </For>
      <div style={{ display: 'flex', marginTop: 8, }}>
        <Actions expandTriggerType="hover" >
          <LinkButton key="1" onClick={handleAdd}><Icon type="add" size="xs" />{intl('widget.authentication.add_callee')}</LinkButton>
        </Actions>
      </div>
    </React.Fragment>
  );
};

AppIds.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.arrayOf(PropTypes.object),
};

export default AppIds;
