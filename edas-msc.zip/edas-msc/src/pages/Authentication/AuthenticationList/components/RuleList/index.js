import React, { useState, useEffect } from 'react';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { Icon, Message, BalloonIcon } from '@ali/cn-design';
import { uniqueId, map, filter, find } from 'lodash';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import RuleItem from './RuleItem';
import CommonEvent from 'components/CommonEvent';

const RuleList = (props) => {
  const { value = [], onChange, protocol, appId, changeAppId, authType, k8sNamespace } = props;
  const intl = useIntl();
  const [list, setList] = useState([]);

  useEffect(() => {
    setList(value);
  }, [value]);

  useEffect(() => {
    if (changeAppId) {
      handleChangeAppId(value);
    }
  }, [changeAppId]);

  const handleChangeAppId = (val) => {
    const newList = map(val, item => ({ ...item, method: undefined, path: undefined }));
    onChange(newList);
  };

  const handleAdd = (all) => {
    if (authType === 0 && !appId) {
      Message.warning(intl('widget.authentication.add_rule_limit'));
      return;
    }
    if (authType === 1 && !k8sNamespace) {
      Message.warning(intl('widget.authentication.add_rule_limit'));
      return;
    }
    const item = {
      uid: uniqueId(),
      all,
      black: false,
      appIds: [],
      k8sNamespaces: [],
    };
    const newList = [...list || [], item];
    onChange(newList);
  };

  const handleChange = (uid, val) => {
    const newList = map(list, item => item.uid === uid ? val : item);
    onChange(newList);
  };

  const handleDelete = (uid) => {
    const newList = filter(list, item => item.uid !== uid);
    onChange(newList);
  };

  return (
    <div style={{ padding: 16, border: '1px dashed #ddd' }}>
      <If condition={authType === 0}>
        <div className="common-box" style={{ display: 'flex', padding: 16, marginBottom: 8, }}>
          <Actions expandTriggerType="hover">
            <LinkButton key="1" onClick={() => handleAdd(true)} disabled={find(value, { all: true })}>
              <Icon type="add" size="xs">
                <span style={{ marginLeft: 4 }}>{intl('widget.authentication.add_all_rule')}</span>
              </Icon>
            </LinkButton>
          </Actions>
          <BalloonIcon text={intl('widget.authentication.all_rule_label')} style={{ cursor: 'pointer', marginLeft: -8 }} />
        </div>
        <For each="item" of={filter(list, item => item.all)}>
          <div key={item.uid} className="common-box" style={{ position: 'relative' }}>
            <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between' }}>
              <span>{intl('widget.authentication.all_rule')}</span>
              <Icon type="close" size="xs" className="common-icon" onClick={() => handleDelete(item.uid)} />
            </div>
            <RuleItem
              protocol={protocol}
              authType={authType}
              key={item.uid}
              value={item}
              onChange={(values) => handleChange(item.uid, values)}
            />
          </div>
        </For>
        <div className="common-box" style={{ padding: 16 }}>
          <CommonEvent onClick={() => handleAdd(false)} text={intl('widget.authentication.add_appoint_rule')} />
          <BalloonIcon text={intl('widget.authentication.appoint_rule_label')} style={{ marginLeft: 8, cursor: 'pointer' }} />
        </div>
        <For each="item" index="index" of={filter(list, item => !item.all)}>
          <div className="common-box" key={item.uid} style={{ position: 'relative' }}>
            <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between' }}>
              <span>{intl('widget.authentication.appoint_rule', { n: index + 1 })}</span>
              <Icon type="close" size="xs" className="common-icon" onClick={() => handleDelete(item.uid)} />
            </div>
            <RuleItem
              protocol={protocol}
              authType={authType}
              key={item.uid}
              value={item}
              onChange={(values) => handleChange(item.uid, values)}
            />
          </div>
        </For>
      </If>
      <If condition={authType === 1}>
        <div className="common-box" style={{ padding: 16 }}>
          <CommonEvent onClick={() => handleAdd(false)} text={intl('widget.authentication.add_appoint_rule')} />
          <BalloonIcon text={intl('widget.authentication.appoint_rule_label')} style={{ marginLeft: 8, cursor: 'pointer' }} />
        </div>
        <For each="item" index="index" of={list}>
          <div className="common-box" key={item.uid} style={{ position: 'relative' }}>
            <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between' }}>
              <span>{intl('widget.authentication.appoint_rule', { n: index + 1 })}</span>
              <Icon type="close" size="xs" className="common-icon" onClick={() => handleDelete(item.uid)} />
            </div>
            <RuleItem
              protocol={protocol}
              authType={authType}
              key={item.uid}
              value={item}
              onChange={(values) => handleChange(item.uid, values)}
            />
          </div>
        </For>
      </If>
    </div>
  );
};

RuleList.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  onChange: PropTypes.func,
  protocol: PropTypes.string,
  appId: PropTypes.string,
  authType: PropTypes.string,
  changeAppId: PropTypes.string,
};

export default RuleList;
