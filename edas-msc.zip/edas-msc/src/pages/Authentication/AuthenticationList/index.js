import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import Events from './Events';
import { TableContainer, CopyContent, modelDecorator, Empty, Button, Message } from '@ali/cn-design';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import Status from 'components/Status/CommonStatus';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE, EDAS_CHANNEL_INFO } from 'constants';
import { map, split, get } from 'lodash';
import { lowerFirstData } from 'utils/transfer-data';
import EditForm from './components/EditForm';
import AuthenticationInfo from '../AuthenticationInfo';
import { Dubbo, SpringCloud, Istio } from 'components/Icon';
import RoleHoc from 'containers/RoleHoc';

const PROTOCOL_DATA3 = {
  DUBBO: 'Dubbo',
  SPRING_CLOUD: 'Spring Cloud',
  istio: 'Istio',
};

const ICON = {
  DUBBO: <Dubbo />,
  SPRING_CLOUD: <SpringCloud />,
  istio: <Istio />,
};

function TableContainerExample(props) {
  const { tableUniqueKey, toggleModal } = props;
  const [isCanCustomColumns] = useState(true);
  const [isCanMultipleSearch] = useState(true);
  const [isCanRefresh] = useState(true);
  const [isAutoAddSorted] = useState(true);
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const [appList, setAppList] = useGlobalState('appList');
  const [searchValues] = useGlobalState('searchValues');
  const [autoFetch, setAutoFetch] = useState(false);
  const editForm = useRef(null);
  const intl = useIntl();
  const { regionId, namespaceId } = searchValues;
  const currentAppList = [];
  const defaultValue = {
    protocol: searchValues.protocol || 'SPRING_CLOUD',
    enable: true,
    source: searchValues.source,
  };

  useEffect(() => {
    fetchAppList({ regionId, namespaceId, pageNumber: 1, pageSize: 50 });
  }, []);

  // 这个是分页接口，但是需要拿到全部数据
  const fetchAppList = async ({ regionId: RegionId, namespaceId: NamespaceId, pageNumber, pageSize }) => {
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      const { data = [] } = await services.GetAppList({
        params: { regionId: RegionId, namespaceId: NamespaceId }
      });
      const newData = map(data, item => ({
        ...item,
        key: item.appId,
        value: item.appId,
        label: item.appName,
      }));
      setAppList(newData);
      if (!autoFetch) {
        setAutoFetch(true);
      }
      return;
    }
    const res = await services.GetAppList({ params: { regionId: RegionId, pageNumber, pageSize } });
    const { result = [] } = lowerFirstData(res) || {};
    const newData = map(result, item => ({
      ...item,
      key: item.appId,
      value: item.appId,
      label: item.appName,
    }));
    currentAppList.push(...newData);
    if (result.length && result.length === pageSize) {
      fetchAppList({ regionId, pageNumber: pageNumber + 1, pageSize });
    } else {
      setAppList(currentAppList);
      if (!autoFetch) {
        setAutoFetch(true);
      }
    }
  };

  const fetchData = async (params) => {
    const res = await services.fetchAuthenticationList({
      data: {
        ...params,
        protocol: params.protocol || undefined,
        regionId,
        namespaceId
      }
    });
    const { result = [], results = [], totalSize: TotalCount } = lowerFirstData(res) || {};
    const List = MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' ? results : result;
    return {
      Data: map(List, item => ({ ...item, authType: item.authType || 0 })),
      TotalCount,
    };
  };

  const columns = [
    {
      key: 'name',
      title: intl('widget.authentication.rule_name'),
      dataIndex: 'name',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <span className="link-primary" onClick={() => handleGoToInfo(record)}>{value}</span>
        </CopyContent>
      ),
    },
    {
      key: 'enable',
      title: intl('widget.common.state'),
      dataIndex: 'enable',
      cell: value => <Status value={value} intl={intl} />
    },
    {
      key: 'protocol',
      title: intl('widget.authentication.callee_protocol'),
      dataIndex: 'protocol',
      cell: value => (
        <Empty value={value}>
          <div style={{ display: 'flex' }}>
            {ICON[value]}
            <span>{PROTOCOL_DATA3[value]}</span>
          </div>
        </Empty>
      ),
    },
    {
      key: 'authType',
      title: intl('widget.authentication.callee_type'),
      dataIndex: 'authType',
      cell: (value) => value === 1 ? 'K8s Namespace' : intl('widget.home.app'),
    },
    {
      key: 'authTypeName',
      title: intl('widget.authentication.callee'),
      dataIndex: 'authTypeName',
      cell: (value, index, record) => {
        const [cluster, namespace] = split(record.k8sNamespace, '+');
        return (
          <React.Fragment>
            <If condition={record.authType === 0}>
              <CopyContent text={record.appName}>
                <Empty value={record.appName}>{record.appName}</Empty>
              </CopyContent>
            </If>
            <If condition={record.authType === 1}>
              <CopyContent text={record.k8sNamespace}>
                <Empty value={record.k8sNamespace}>{`${cluster}${intl('widget.common.brackets', { text: namespace })}`}</Empty>
              </CopyContent>
            </If>
          </React.Fragment>
        );
      },
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => <Events record={record} handleEdit={() => handleEdit(record)} setFetchDataTime={setFetchDataTime} />,
    },
  ];

  const searchs = {
    typeInfo: {
      types: [
        { value: '', label: intl('widget.authentication.all_frame') },
        { value: 'SPRING_CLOUD', label: 'Spring Cloud' },
        { value: 'DUBBO', label: 'Dubbo' },
        { value: 'istio', label: 'Istio' }
      ],
      defaultValue: searchValues.protocol || '',
      value: 'protocol',
    },
    filterInfo: {
      filters: [
        // {
        //   label: intl('widget.authentication.callee_protocol'),
        //   value: 'protocol',
        //   mode: 'select',
        //   dataSource: PROTOCOL_DATA,
        //   defaultValue: searchValues.protocol,
        // },
        {
          label: intl('widget.authentication.rule_name'),
          value: 'name',
          placeholder: intl('widget.authentication.rule_name_placeholder')
        },
        {
          label: intl('widget.authentication.callee'),
          value: 'appId',
          mode: 'select',
          dataSource: [
            { label: intl('widget.authentication.all_app'), value: '' },
            ...appList
          ],
        },
      ],
      defaultValue: 'name',
    },
    isCanCustomColumns,
    isCanMultipleSearch,
    tableUniqueKey,
    isCanRefresh,
  };


  if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && get(window, 'EDAS_USER_FEATURES.featureIstioEnable', false) && EDAS_CHANNEL_INFO.toLowerCase() !== 'finance') {
    searchs.typeInfo.types.push({ value: 'istio', label: intl('widget.service.service_mesh') });
  }

  const handleGoToInfo = (record) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl('widget.authentication.info'),
      content: (
        <AuthenticationInfo value={record} handelEdit={() => handleEdit(record)} />
      ),
      onConfirm: null,
    });
  };

  const handleEdit = (record = defaultValue) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl(record.id ? 'widget.authentication.edit_rule' : 'widget.authentication.create_rule'),
      content: (
        <EditForm
          ref={editForm}
          value={record}
          setRefreshIndex={setFetchDataTime}
        />
      ),
      onConfirm: () => editForm.current.handleSubmit(),
    });
  };

  return (
    <React.Fragment>
      <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && !IS_ENV_PRIVATE}>
        <If condition={searchValues.protocol === 'DUBBO'}>
          <Message type="warning" style={{ marginBottom: 16 }}>
            {intl.html('widget.authentication.list_dubbo_label')}
          </Message>
        </If>
        <If condition={searchValues.protocol === 'SPRING_CLOUD'}>
          <Message type="warning" style={{ marginBottom: 16 }}>
            {intl.html('widget.authentication.list_sp_label')}
          </Message>
        </If>
        <If condition={searchValues.protocol === 'istio'}>
          <Message type="warning" style={{ marginBottom: 16 }}>
            {intl.html('widget.authentication.list_istio_label')}
          </Message>
        </If>
      </If>
      <TableContainer
        autoFetch={autoFetch}
        fetchData={fetchData}
        primaryKey="id"
        columns={columns}
        search={searchs}
        refreshIndex={fetchDataTime}
        affixActionBar
        isUseStorage={MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas'}
        sortConfig={{
          isAutoAddSorted,
        }}
        followTrigger
        operation={() => (
          <Button type="primary" onClick={() => handleEdit()}>
            {intl('widget.authentication.create_rule')}
          </Button>
        )}
        emptyContent={
          <div >
            <Actions expandTriggerType="hover" style={{ justifyContent: 'center' }}>
              <LinkButton key="1" onClick={() => handleEdit()}>{intl('widget.authentication.no_data_go_create')}</LinkButton>
            </Actions>
          </div>
        }
      />
    </React.Fragment>
  );
}

TableContainerExample.propTypes = {
  toggleModal: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default RoleHoc(modelDecorator(TableContainerExample));
