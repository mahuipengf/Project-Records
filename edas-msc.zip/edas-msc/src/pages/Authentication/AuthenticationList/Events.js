import React from 'react';
import PropTypes from 'prop-types';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { Message } from '@ali/cn-design';
import confirm from 'components/Confirm';
import services from 'services';

const Events = (props) => {
  const intl = useIntl();
  const { record, handleEdit, setFetchDataTime } = props;
  const [searchValues] = useGlobalState('searchValues');
  const { regionId, namespaceId } = searchValues;
  const { id, name, enable } = record;

  const handleOpen = () => {
    confirm({
      title: intl('widget.authentication.list.open_rule'),
      content: intl('widget.authentication.list.open_rule_confirm', { name }),
      onOk: () => services.updateAuthentication({
        data: { id, policyId: id, enable: true },
      }).then(() => {
        Message.success(intl('widget.common.open_successful'));
        setFetchDataTime(Date.now());
      }),
    });
  };

  const handleClose = () => {
    confirm({
      title: intl('widget.authentication.list.close_rule'),
      content: intl('widget.authentication.list.close_rule_confirm', { name }),
      onOk: () => services.updateAuthentication({
        data: { id, policyId: id, enable: false },
      }).then(() => {
        Message.success(intl('widget.common.close_successful'));
        setFetchDataTime(Date.now());
      }),
    });
  };

  const handleDelete = () => {
    confirm({
      title: intl('widget.common.delete'),
      content: intl('widget.authentication.list.delete_rule_confirm', { name }),
      onOk: () => services.removeAuthentication({
        data: { id, policyId: id, regionId, namespaceId }
      }).then(() => {
        Message.success(intl('widget.common.delete_successful'));
        setFetchDataTime(Date.now());
      }),
    });
  };

  return (
    <Actions expandTriggerType="hover">
      <If condition={handleEdit}>
        <LinkButton key="1" onClick={handleEdit}>{intl('widget.common.edit')}</LinkButton>
      </If>
      <If condition={enable}>
        <LinkButton key="3" onClick={handleClose}>{intl('widget.common.close1')}</LinkButton>
      </If>
      <If condition={!enable}>
        <LinkButton key="2" onClick={handleOpen}>{intl('widget.common.open1')}</LinkButton>
      </If>
      <LinkButton key="4" onClick={handleDelete}>{intl('widget.common.delete')}</LinkButton>
    </Actions>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  handleEdit: PropTypes.func,
  setFetchDataTime: PropTypes.func,
};

export default Events;
