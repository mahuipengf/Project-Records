import React, { useState, useEffect } from 'react';
import { Loading } from '@ali/cn-design';
import { useGlobalState } from '@ali/widget-hooks';
import { map, uniqueId } from 'lodash';
import services from 'services';
import BasicInfo from './components/BasicInfo';
import RuleInfo from './components/RuleInfo';
import { lowerFirstData } from 'utils/transfer-data';
import PropTypes from 'prop-types';

const AuthenticationInfo = (props) => {
  const { handelEdit, value } = props;
  const [searchValues] = useGlobalState('searchValues');
  const [isConfirmLoading, setIsConfirmLoading] = useState(false);
  const [data, setData] = useState({});

  useEffect(() => {
    if (value.id) {
      fetchData();
    }
  }, [value.id]);

  const fetchData = async () => {
    const { tenantId, regionId, namespaceId } = searchValues;
    const { id } = value;
    setIsConfirmLoading(true);
    const params = { policyId: id, regionId, namespaceId, tenantId };
    const res = await services.fetchAuthenticationInfo({
      data: params,
      customErrorHandle: (err, response, callback) => {
        setIsConfirmLoading(false);
        callback();
      }
    });
    setIsConfirmLoading(false);
    const { name, protocol, appId, appName, enable, regionId: region, namespaceId: namespace, authRule, authType = 0, k8sNamespace, source } = lowerFirstData(res) || {};
    const newData = {
      id,
      name,
      protocol,
      appId,
      authType,
      k8sNamespace,
      enable,
      source,
      appName,
      namespaces: { regionId: region, namespaceId: namespace },
      authRule: map(authRule, (n) => ({ uid: uniqueId(), ...n })),
    };
    setData(newData);
  };

  return (
    <Loading visible={isConfirmLoading} style={{ width: '100%' }} >
      <BasicInfo data={{ ...data }} handelEdit={handelEdit} />
      <RuleInfo data={{ ...data }} />
    </Loading>
  );
};

AuthenticationInfo.propTypes = {
  handelEdit: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
};

export default AuthenticationInfo;
