import React from 'react';
import DataFields from '@alicloud/console-components-data-fields';
import { Empty, CopyContent } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import CommonEvent from 'components/CommonEvent';

const BasicInfo = ({ data = {}, handelEdit }) => {
  const intl = useIntl();

  const handleGoToEdit = () => {
    handelEdit && handelEdit();
  };

  const PROTOCOL_DATA = {
    DUBBO: 'Dubbo',
    SPRING_CLOUD: 'Spring Cloud',
    istio: intl('widget.service.service_mesh'),
  };

  const items = [
    {
      dataIndex: 'name',
      label: intl('widget.authentication.rule_name'),
      render: value => {
        return (
          <Empty value={value}>
            <CopyContent text={value}>
              {value}
            </CopyContent>
          </Empty>
        );
      },
    },
    {
      dataIndex: 'protocol',
      label: intl('widget.authentication.callee_protocol'),
      render: value => <Empty value={value}>{PROTOCOL_DATA[value]}</Empty>,
    },
    {
      dataIndex: 'enable',
      label: intl('widget.common.state'),
      render: value => value ? intl('widget.common.opened') : intl('widget.common.closed'),
    },
    {
      dataIndex: 'authType',
      label: intl('widget.authentication.callee_type'),
      render: value => {
        const obj = { 0: intl('widget.home.app'), 1: 'K8s Namespace' };
        return <Empty value={value}>{obj[value] || '--'}</Empty>;
      }
    },
  ];

  return (
    <React.Fragment>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <h4 className="common-title" style={{ width: 144 }}>{intl('widget.authentication.basic_info')}</h4>
        <If condition={handelEdit}>
          <CommonEvent type="edit" text={intl('widget.common.edit')} onClick={handleGoToEdit} style={{ marginTop: 8 }} />
        </If>
      </div>
      <DataFields
        dataSource={data}
        items={items}
        style={{ padding: '8px 0', borderBottom: '1px solid #eee' }}
      />
    </React.Fragment>
  );
};

BasicInfo.propTypes = {
  data: PropTypes.objectOf(PropTypes.any),
  handelEdit: PropTypes.func,
};

export default BasicInfo;
