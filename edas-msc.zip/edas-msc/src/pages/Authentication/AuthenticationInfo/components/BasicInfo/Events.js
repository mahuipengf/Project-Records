import React from 'react';
import PropTypes from 'prop-types';
import { useGlobalState } from '@ali/widget-hooks';

const Events = ({ record, children, emitName }) => {
  const [eventEmitter] = useGlobalState('eventEmitter');

  const handleGoToDetail = () => {
    eventEmitter.emit(emitName, record);
  };

  return (
    <span className="link-primary" onClick={handleGoToDetail}>{children}</span>
  );
};

Events.propTypes = {
  record: PropTypes.shape(),
  children: PropTypes.string,
  emitName: PropTypes.string,
};

export default Events;
