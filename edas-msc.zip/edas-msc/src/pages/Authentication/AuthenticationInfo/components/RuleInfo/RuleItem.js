import React from 'react';
import { useIntl } from '@ali/widget-hooks';
import { get, join, find, map, isEmpty, split } from 'lodash';
import DataFields from 'components/DataFields';
import { Empty } from '@ali/cn-design';
import PropTypes from 'prop-types';

const authentication_type_data = (intl, black) => !black ? intl('widget.authentication.white_list') : intl('widget.authentication.black_list');

const PROTOCOL_DATA = (all, pro, intl) => {
  const arr = [
    {
      all: true,
      DUBBO: intl('widget.authentication.all_service_all_interface'),
      SPRING_CLOUD: intl('widget.authentication.all_path'),
      istio: intl('widget.authentication.all_path'),
    },
    {
      all: false,
      DUBBO: intl('widget.authentication.all_interface'),
      SPRING_CLOUD: intl('widget.authentication.all_path'),
      istio: intl('widget.authentication.all_path'),
    },
  ];
  return find(arr, { all }, {})[pro];
};

const items = (intl, protocol, authType) => [
  {
    dataIndex: 'app_type',
    label: intl(protocol === 'DUBBO' ? 'widget.authentication.callee_interface' : 'widget.authentication.callee_path'),
    span: 24,
    render: (value, record) => {
      const { all, path, method = {} } = record;
      const methodName = get(method, 'name', '--');
      const methodServiceName = get(method, 'serviceName', '--');
      if (all) return PROTOCOL_DATA(all, protocol, intl);
      return protocol === 'DUBBO' ? `${methodServiceName} / ${methodName}` : path;
    },
    visible: authType === 0,
  },
  {
    dataIndex: 'black',
    label: intl('widget.authentication.type'),
    span: 24,
    render: value => <Empty value={value}>{authentication_type_data(intl, value)}</Empty>,
    visible: true,
  },
  {
    dataIndex: 'appNames',
    label: intl('widget.authentication.caller_type', { type: intl('widget.home.app') }),
    span: 24,
    render: value => <Empty value={value}>{join(value, ', ')}</Empty>,
    visible: authType === 0,
  },
  {
    dataIndex: 'k8sNamespaces',
    label: intl('widget.authentication.caller_type', { type: 'K8s Namespace' }),
    span: 24,
    render: value => {
      if (isEmpty(value)) return '--';
      const newValue = map(value, item => {
        const [cluster, namespace] = split(item, '+');
        return `${cluster}${intl('widget.common.brackets', { text: namespace })}`;
      });
      return join(newValue, ', ');
    },
    visible: authType === 1,
  },
];

const RuleItem = (props) => {
  const { value = {}, protocol, authType } = props;
  const intl = useIntl();

  return (
    <DataFields
      dataSource={{ ...value, protocol }}
      items={items(intl, protocol, authType)}
      style={{ padding: '8px 0', borderBottom: 0 }}
    />
  );
};

RuleItem.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  protocol: PropTypes.string,
  authType: PropTypes.string,
};

export default RuleItem;
