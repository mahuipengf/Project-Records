import React from 'react';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import DataFields from 'components/DataFields';
import { Empty } from '@ali/cn-design';
import RuleItem from './RuleItem';
import { filter, split } from 'lodash';

const items = (intl, data) => [
  {
    dataIndex: 'authType',
    label: intl('widget.authentication.callee_name', { type: data.authType === 1 ? 'K8s Namespace' : intl('widget.home.app') }),
    render: (value, record) => {
      const [cluster, namespace] = split(record.k8sNamespace, '+');
      return (
        <React.Fragment>
          <If condition={value === 1}>
            <Empty value={record.k8sNamespace}>{`${cluster}${intl('widget.common.brackets', { text: namespace })}`}</Empty>
          </If>
          <If condition={value === 0}>
            <Empty value={record.appName}>{record.appName}</Empty>
          </If>
        </React.Fragment>
      );
    },
    visible: true,
    span: 24,
  },
];

const BasicInfo = ({ data = {} }) => {
  const intl = useIntl();

  return (
    <React.Fragment>
      <h5 className="common-title">{intl('widget.authentication.service_rule')}</h5>
      <DataFields
        dataSource={data}
        items={items(intl, data)}
        style={{ padding: '8px 0', borderBottom: 0 }}
      />
      <If condition={data.authType === 0}>
        <For each="item" index="index" of={filter(data.authRule || [], item => item.all)}>
          <div className="common-box" key={index}>
            <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.authentication.all_rule')}</div>
            <RuleItem
              protocol={data.protocol}
              key={item.uid}
              authType={data.authType}
              value={item}
            />
          </div>
        </For>
        <For each="item" index="index" of={filter(data.authRule || [], item => !item.all)}>
          <div className="common-box" key={index}>
            <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.authentication.appoint_rule', { n: index + 1 })}</div>
            <RuleItem
              protocol={data.protocol}
              key={item.uid}
              authType={data.authType}
              value={item}
            />
          </div>
        </For>
      </If>
      <If condition={data.authType === 1}>
        <For each="item" index="index" of={data.authRule || []}>
          <div className="common-box" key={index}>
            <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.authentication.appoint_rule', { n: index + 1 })}</div>
            <RuleItem
              protocol={data.protocol}
              authType={data.authType}
              key={item.uid}
              value={item}
            />
          </div>
        </For>
      </If>
    </React.Fragment>
  );
};

BasicInfo.propTypes = {
  data: PropTypes.objectOf(PropTypes.any),
};

export default BasicInfo;
