import AuthenticationList from './AuthenticationList';

export default AuthenticationList;
