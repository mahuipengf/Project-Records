import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, modelDecorator, Empty, CopyContent, Message } from '@ali/cn-design';
import { WIDGET_ID } from 'constants';
import DialogAlert from 'components/DialogAlert';
import { timeFmt, aliyunSite } from 'utils';

function List(props) {
  const { tableUniqueKey } = props;
  const [searchValues] = useGlobalState('searchValues');
  const [eventEmitter] = useGlobalState('eventEmitter');
  const [refreshIndex, setRefreshIndex] = useState(0);

  const intl = useIntl();
  const { regionId } = searchValues;

  useEffect(() => setRefreshIndex(Date.now()), []);
  const fetchData = async (params) => {
    const { Result = [], TotalSize = 0 } = await services.QueryGovernanceKubernetesCluster({
      params: {
        ...params,
        regionId,
      }
    });
    return {
      Data: Result,
      TotalCount: TotalSize,
    };
  };

  const handleGoToInfo = (record) => {
    eventEmitter.emit(`${WIDGET_ID}:go-to-K8sClusterInfo`, record);
  };

  const handleDeleteGovernanceKubernetesCluster = async(record) => {
    DialogAlert({
      title: intl('widget.common.clear'),
      content: <div style={{ maxWidth: 400, lineHeight: '18px' }}>
        <div>{intl.html('widget.msc.k8s_clear_message_tips')}</div>
        <div>{intl.html('widget.msc.k8s_clear_message_tips_two')}</div>
      </div>,
      onOk: () => {
        services.DeleteGovernanceKubernetesCluster({
          params: {
            ClusterId: record.ClusterId
          }
        }).then((res) => {
          if (res) {
            Message.success(intl('widget.common.clear_successful'));
            setRefreshIndex(Date.now());
          }
        });
      },
      footerActions: ['ok', 'cancel']
    });
  };
  const columns = [
    {
      key: 'ClusterName',
      title: intl('widget.k8s.name_id'),
      dataIndex: 'ClusterName',
      cell: (value, index, record) => {
        return (
          <div>
            <CopyContent text={value} style={{ display: 'block' }}>
              <span onClick={() => handleGoToInfo(record)} className="link-primary">{value}</span>
            </CopyContent>
            <CopyContent text={record?.ClusterId}>
              <span onClick={() => handleGoToInfo(record)} className="link-primary">{record?.ClusterId}</span>
            </CopyContent>
          </div>

        );
      },
    },
    {
      key: 'PilotStartTime',
      title: intl('widget.k8s.start_time'),
      dataIndex: 'PilotStartTime',
      cell: value => <Empty value={value}>{timeFmt(value, 'YYYY-MM-DD HH:mm:ss')}</Empty>,
    },
    {
      key: 'K8sVersion',
      title: intl('widget.service.version'),
      dataIndex: 'K8sVersion',
      cell: value => <Empty value={value}>{value}</Empty>,
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => (
        <div>
          <span className="link-primary" onClick={() => handleGoToInfo(record)}>{intl('widget.k8s.manage')}</span>
          {aliyunSite !== 'INTL' && (<><span style={{ margin: '0px 4px', color: '#d8d8d8' }}>｜</span><span className="link-primary" onClick={() => handleDeleteGovernanceKubernetesCluster(record)}>{intl('widget.common.clear')}</span></>)}
        </div>),
    },
  ];

  const searchs = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.k8s.cluster_name'),
          value: 'ClusterName',
          placeholder: intl('widget.k8s.please_enter_cluster_name'),
        },
        {
          label: intl('widget.k8s.cluster_id'),
          value: 'ClusterId',
          placeholder: intl('widget.k8s.please_enter_cluster_id'),
        },
      ],
      defaultValue: 'ClusterName',
    },
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };

  return (
    <React.Fragment>
      <TableContainer
        fetchData={fetchData}
        primaryKey="appId"
        columns={columns}
        search={searchs}
        isUseStorage
        affixActionBar
        followTrigger
        refreshIndex={refreshIndex}
      />
    </React.Fragment>
  );
}

List.propTypes = {
  tableUniqueKey: PropTypes.string,
};

export default modelDecorator(List);
