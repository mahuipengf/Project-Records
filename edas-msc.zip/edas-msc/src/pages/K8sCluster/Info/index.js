import React, { useState } from 'react';
import BasicInfo from './components/BasicInfo';
import Namespaces from './components/Namespaces';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import services from 'services';
import { Collapse } from '@alicloud/console-components';
import { get, keys, map, uniqueId } from 'lodash';

const { Panel } = Collapse;

const k8sClusterInfo = ({ tableUniqueKey }) => {
  const [searchValues] = useGlobalState('searchValues');
  const [data, setData] = useState({});

  const intl = useIntl();

  const fetchK8sData = async () => {
    const res = await services.GetGovernanceKubernetesCluster({
      params: searchValues
    });
    const K8sNamespaces = get(res, 'Namespaces', []);
    const NewNamespaces = map(K8sNamespaces, item => {
      const TagKeys = keys(item.Tags);
      const NewTags = map(TagKeys, child => ({
        uid: uniqueId(),
        key: child,
        value: item.Tags[child],
        text: `${child}:${item.Tags[child]}`
      }));
      return {
        uid: uniqueId(),
        ...item,
        Tags: item.Tags || {},
        NewTags
      };
    });
    setData({
      ...res,
      Namespaces: NewNamespaces
    });
    return {
      ...res,
      Namespaces: NewNamespaces
    };
  };

  return (
    <div style={{ paddingBottom: 16 }}>
      <Collapse defaultExpandedKeys={['0']}>
        <Panel title={intl('widget.common.basic_info')}>
          <BasicInfo data={data} />
          <Namespaces fetchK8sData={fetchK8sData} tableUniqueKey={tableUniqueKey} />
        </Panel>
      </Collapse>
    </div>
  );
};

export default k8sClusterInfo;
