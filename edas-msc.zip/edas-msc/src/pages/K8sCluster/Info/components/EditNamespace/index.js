import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Field } from '@alicloud/console-components';
import { Form, Input, Message } from '@ali/cn-design';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { NNAME_PATTERN } from 'constants';
import SlidePanel from 'components/SlidePanel';
import { forEach, map, get, uniqueId } from 'lodash';
import IconBack from 'components/IconBack';
import TagList from 'containers/TagList';
import CommonEvent from 'components/CommonEvent';

const FormItem = Form.Item;

const EditNamespace = (props) => {
  const field = Field.useField();
  const [loading, setLoading] = useState(false);
  const [searchValues] = useGlobalState('searchValues');
  const { value, visible, onClose, onOk, k8sData } = props;
  const intl = useIntl();
  const { init, validate, getValue, setValues, reset, setValue } = field;

  useEffect(() => {
    const NewTags = get(value, 'NewTags', []);
    const Name = get(value, 'Name', '');
    const uid = get(value, 'uid', '');
    setValues({
      uid,
      Name,
      NewTags,
    });
  }, [value]);

  const handleSubmit = () => {
    validate(async (errors, values) => {
      if (errors) return;
      const NewTags = get(values, 'NewTags', []);
      const Tags = {};
      forEach(NewTags, tag => (Tags[tag.key] = tag.value));
      const Namespaces = get(k8sData, 'Namespaces', []);
      let NamespaceInfos = map(Namespaces, item => ({
        Name: item.Name,
        Tags: item.Tags,
      }));
      if (!values.uid) { // 修改
        NamespaceInfos = [...NamespaceInfos, { Name: values.Name, Tags }];
      } else {
        NamespaceInfos = map(Namespaces, item => {
          const uid = get(item, 'uid', '');
          return {
            Name: item.Name,
            Tags: uid === values.uid ? Tags : item.Tags,
          };
        });
      }
      setLoading(true);
      await services.ModifyGovernanceKubernetesCluster({
        params: {
          regionId: searchValues.regionId,
          ClusterId: k8sData.ClusterId,
          NamespaceInfos
        },
        customErrorHandle: (err, response, callback) => {
          callback();
          setLoading(false);
        }
      });
      // 这个是去下发请求到mse的，然后mse这边下发规则到客户集群pilot组件，3秒是mse这边需要点时间同步到数据库
      setTimeout(() => {
        setLoading(false);
        onOk();
        Message.success(intl(value.uid ? 'widget.common.update_successful' : 'widget.common.add_successful'));
      }, 3000);
    });
  };

  const handleClose = () => {
    setLoading(false);
    reset();
    onClose();
  };

  return (
    <SlidePanel
      title={
        <IconBack goBack={handleClose}>{intl(getValue('uid') ? 'widget.k8s.edit_tag' : 'widget.k8s.crete_namespace')}</IconBack>
      }
      processingText={intl('widget.common.ok')}
      isShowing={visible}
      onOk={handleSubmit}
      onClose={handleClose}
      onCancel={handleClose}
      isProcessing={loading}
      width={780}
    >
      <Form field={field}>
        <FormItem label={intl('widget.common.name')} required>
          <Input
            {...init('Name', {
              initValue: '',
              rules: [
                {
                  required: true,
                  message: intl('widget.common.name_pattern'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.common.name_pattern'),
                },
              ],
            })}
            placeholder={intl('widget.common.name_pattern')}
            maxLength={64}
            minLength={1}
            showLimitHint
            disabled={getValue('uid')}
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem
          label={
            <span>
              {intl('widget.app.tag')}
              <CommonEvent
                style={{ marginLeft: 8 }}
                onClick={() => {
                  setValue('NewTags', [...getValue('NewTags'), { uid: uniqueId() }]);
                }}
                text={intl('widget.common.add')}
              />
            </span>
          }
          required
        >
          <TagList
            {...init('NewTags', {
              initValue: [],
              rules: [
                {
                  required: true,
                  message: intl('widget.app.tab_placeholder'),
                },
                {
                  validator: (rule, val, callback) => {
                    forEach(val, item => {
                      if (!item.key || !item.value) {
                        callback(intl('widget.app.tab_placeholder'));
                      }
                    });
                    callback();
                  }
                }
              ],
            })}
            add={false}
          />
        </FormItem>
      </Form>
    </SlidePanel>
  );
};

EditNamespace.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  groupInfo: PropTypes.objectOf(PropTypes.any),
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  onOk: PropTypes.func,
  k8sData: PropTypes.objectOf(PropTypes.any),
};

export default EditNamespace;
