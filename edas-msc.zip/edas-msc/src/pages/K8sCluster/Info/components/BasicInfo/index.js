import React from 'react';
import DataFields from 'components/DataFields';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import { Empty, CopyContent } from '@ali/cn-design';
import { timeFmt } from 'utils';

const BasicInfo = ({ data = {} }) => {
  const intl = useIntl();

  const items = [
    {
      dataIndex: 'ClusterId',
      label: intl('widget.k8s.cluster_id'),
      visible: true,
    },
    {
      dataIndex: 'ClusterName',
      label: intl('widget.k8s.cluster_name'),
      visible: true,
      render: (value) => (
        <Empty value={value}>
          <CopyContent text={value}>
            {value}
          </CopyContent>
        </Empty>
      )
    },
    {
      dataIndex: 'K8sVersion',
      label: intl('widget.service.version'),
      visible: true,
    },
    {
      label: intl('widget.k8s.start_time'),
      dataIndex: 'PilotStartTime',
      visible: true,
      render: (value) => <Empty value={value}>{timeFmt(value, 'YYYY-MM-DD HH:mm:ss')}</Empty>
    },
  ];
  return (
    <React.Fragment>
      <DataFields
        dataSource={data}
        items={items}
        style={{ marginBottom: 16, borderBottom: '1px solid #eee' }}
        title={intl('widget.k8s.cluster_info')}
      />
    </React.Fragment>
  );
};

BasicInfo.propTypes = {
  data: PropTypes.objectOf(PropTypes.any),
};

export default BasicInfo;
