import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { TableContainer, modelDecorator, Empty, Button, Message, Select, Form, Icon, Balloon, Field } from '@ali/cn-design';
import DialogAlert from 'components/DialogAlert';
import { get, size, map } from 'lodash';
import Status from 'components/Status/CommonStatus';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import services from 'services';
import EditNamespace from '../EditNamespace';
import SlidePanel from 'components/SlidePanel';

function List(props) {
  const { tableUniqueKey, fetchK8sData } = props;
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [searchValues] = useGlobalState('searchValues');
  const [k8sData, setK8sData] = useState({});
  const [showEditNamespace, setShowEditNamespace] = useState(false);
  const [namespaceValue, setNamespaceValue] = useState({});
  const [dataSource, setDataSource] = useState([]);
  const [mseNamespace, setMseNamespace] = useState('');
  const [rowData, setRowData] = useState([]);
  const intl = useIntl();

  const field = Field.useField();
  const { init, validate, setValue } = field;

  const fetchData = async () => {
    const data = await fetchK8sData();
    const Namespaces = get(data, 'Namespaces', []);
    setK8sData(data);
    return {
      Data: Namespaces,
      TotalCount: size(Namespaces),
    };
  };

  const handleChangeState = (record) => {
    const Tags = get(record, 'Tags', {});
    const isOpened = Tags['mse-enable'] === 'enabled'; // 是否是已开启状态
    const Namespaces = get(k8sData, 'Namespaces', []);
    const mse_enable = isOpened ? {} : { 'mse-enable': 'enabled' };
    if (isOpened) {
      delete Tags['mse-enable'];
    }
    const NamespaceInfos = map(Namespaces, item => ({
      Name: item.Name,
      Tags: item.uid === record.uid ? { ...Tags, ...mse_enable } : item.Tags,
    }));
    DialogAlert({
      title: intl(isOpened ? 'widget.k8s.close_msc' : 'widget.k8s.open_msc'),
      content: intl.html(isOpened ? 'widget.k8s.close_msc_confirm' : 'widget.k8s.open_msc_confirm', { Name: record.Name }),
      onOk: () => new Promise(async (resolve, reject) => {
        await services.ModifyGovernanceKubernetesCluster({
          params: {
            regionId: searchValues.regionId,
            ClusterId: k8sData.ClusterId,
            NamespaceInfos
          },
          customErrorHandle: (err, response, callback) => {
            reject();
            callback();
          }
        });
        // 这个是去下发请求到mse的，然后mse这边下发规则到客户集群pilot组件，3秒是mse这边需要点时间同步到数据库
        setTimeout(() => {
          Message.success(intl(isOpened ? 'widget.common.close_successful' : 'widget.common.open_successful'));
          setRefreshIndex(Date.now());
          resolve();
        }, 3000);
      }),
      footerActions: ['ok', 'cancel']
    });
  };

  // 创建
  const handleOpenEditNamespace = async(record = {}) => {
    setRowData(record);
    const data = await services.QueryNamespace({
      params: {
        Region: searchValues.regionId,
        RegionId: searchValues.regionId,
      }
    });
    const newData = map(data || [], item => ({
      ...item,
      label: item.Namespace,
      value: item.Namespace,
    }));
    if (newData && newData.some((item) => item.Namespace === record.Tags.mseNamespace)) {
      setDataSource(newData);
    } else {
      newData.push({
        label: record.mseNamespace,
        value: record.mseNamespace,
      });
      setDataSource(newData);
    }
    setMseNamespace(record?.Tags?.mseNamespace || '');
    setValue('mseNamespace', record?.Tags?.mseNamespace || '');
    setNamespaceValue({ ...record });
    setShowEditNamespace(true);
  };

  // 完成
  const handleOk = async() => {
    const Namespaces = get(k8sData, 'Namespaces', []);
    const NamespaceInfos = map(Namespaces, item => {
      if (item.uid === rowData.uid) {
        if (mseNamespace) {
          item.Tags.mseNamespace = mseNamespace;
        } else {
          delete item.Tags.mseNamespace;
        }
      }
      return {
        Name: item.Name,
        Tags: item.Tags,
      };
    });
    validate(async(err, values) => {
      if (err) return err;
      await services.ModifyGovernanceKubernetesCluster({
        params: {
          regionId: searchValues.regionId,
          ClusterId: k8sData.ClusterId,
          NamespaceInfos
        }
      });
      setShowEditNamespace(false);
      setRefreshIndex(Date.now());
    });
  };

  const columns = [
    {
      key: 'Name',
      title: intl('widget.common.name'),
      dataIndex: 'Name',
      cell: value => <Empty value={value}>{value}</Empty>
    },
    {
      key: 'NewTags',
      title: intl('widget.app.tag'),
      dataIndex: 'NewTags',
      cell: value => (
        <For index="index" each="item" of={value}>
          <i tab={item} style={{ color: '#7a94a9', marginRight: 4, padding: '4px 8px', borderRadius: 10, background: '#ecf2f6', fontStyle: 'normal' }}>{item.text || '--'}</i>
        </For>
      ),
    },
    {
      key: 'Tags',
      title: intl('widget.msc.k8s.isenable.micro.service.governance'),
      dataIndex: 'Tags',
      cell: (value) => <Status value={value['mse-enable'] === 'enabled'} />,
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => (
        <React.Fragment>
          <Actions expandTriggerType="hover">
            <LinkButton key="1" onClick={() => handleOpenEditNamespace(record)}>{intl('widget.msc.k8s.corresponding.microservice.namespace.title')}</LinkButton>
            <If condition={record.Tags['mse-enable'] === 'enabled'}>
              <LinkButton key="3" onClick={() => handleChangeState(record)}>{intl('widget.k8s.close_msc')}</LinkButton>
            </If>
            <If condition={record.Tags['mse-enable'] !== 'enabled'}>
              <LinkButton key="2" onClick={() => handleChangeState(record)}>{intl('widget.k8s.open_msc')}</LinkButton>
            </If>
          </Actions>
        </React.Fragment>
      ),
    },
  ];

  const searchs = {
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    tableUniqueKey,
    isCanRefresh: true,
  };

  const handleChangeNamespace = (val) => {
    setMseNamespace(val);
    setValue('mseNamespace', val);
    validate();
  };

  return (
    <React.Fragment>
      <TableContainer
        refreshIndex={refreshIndex}
        fetchData={fetchData}
        primaryKey="appId"
        columns={columns}
        search={searchs}
        isUseStorage
        // operation={() => (
        //   <Button type="primary" onClick={() => handleOpenEditNamespace()}>
        //     {intl('widget.k8s.crete_namespace')}
        //   </Button>
        // )}
        pagination={<div />} // 组件有问题，不要分页时传入空div
      />
      {/* <EditNamespace
        visible={showEditNamespace}
        value={namespaceValue}
        onClose={() => setShowEditNamespace(false)}
        onOk={handleOk}
        k8sData={k8sData}
      /> */}
      <SlidePanel
        title={intl('widget.msc.k8s.corresponding.microservice.namespace.title')}
        processingText={intl('widget.common.ok')}
        isShowing={showEditNamespace}
        onOk={handleOk}
        onClose={() => setShowEditNamespace(false)}
        onCancel={() => setShowEditNamespace(false)}
        width={780}
      >
        <Form field={field}>
          <Form.Item
            // required
            label={<span>
              {intl('widget.msc.k8s.corresponding.microservice.namespace')}<Balloon
                trigger={
                  <Icon type="help" style={{ color: '#888', cursor: 'pointer', marginLeft: 6 }} />}
                closable={false}
              >
                {intl('widget.msc.k8s.corresponding.microservice.namespace.tips')}
              </Balloon></span>}
          >
            <Select.AutoComplete
              {...init('mseNamespace', {
                initValue: '',
                // rules: [
                //   {
                //     required: true,
                //     message: intl('widget.msc.k8s.corresponding.microservice.namespace.placeholder'),
                //   },
                // ],
              })}
              showSearch
              style={{ width: '100%', marginTop: '4px' }}
              dataSource={dataSource}
              value={mseNamespace}
              onChange={handleChangeNamespace}
              placeholder={intl('widget.msc.k8s.corresponding.microservice.namespace.placeholder')}
              followTrigger
            />
          </Form.Item>
        </Form>
      </SlidePanel>
    </React.Fragment>
  );
}

List.propTypes = {
  tableUniqueKey: PropTypes.string,
  fetchK8sData: PropTypes.func,
};

export default modelDecorator(List);
