import React from 'react';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import { isEmpty, split } from 'lodash';
import DataFields from 'components/DataFields';
import { Empty } from '@ali/cn-design';
import MonacoEditor from 'components/MonacoEditor';
import ConditionList from 'containers/ConditionList';

const ItemInfo = (props) => {
  const { style, value = {} } = props;
  const intl = useIntl();

  const dataSource = {
    force: intl('widget.ddegradation.executeCondition_all'),
    exception: intl('widget.ddegradation.executeCondition_warning')
  };

  const operData = {
    'return+null': intl('widget.mock.return_null'),
    throw: intl('widget.mock.return_excention_error'),
    'return+json': intl('widget.mock.return_customize_json'),
    'return+callback': intl('widget.mock.return_customize_callback'),
  };

  const getItems = (item) => [
    {
      dataIndex: 'Protocol',
      label: intl('widget.route.frame_type'),
      visible: true,
      render: val => {
        const Protocol = { springCloud: 'Spring Cloud', dubbo: 'Dubbo' };
        return Protocol[val] || '--';
      },
    },
    // {
    //   dataIndex: 'ExecuteCondition',
    //   label: intl('widget.ddegradation.executeCondition'),
    //   visible: true,
    //   render: val => dataSource[val] || '--'
    // },
    {
      dataIndex: 'Path',
      label: 'Path',
      visible: item.Protocol === 'springCloud',
    },
    // {
    //   dataIndex: 'Service',
    //   label: intl('widget.app.service_method'),
    //   visible: item.Protocol === 'dubbo',
    //   span: 24,
    // },
    {
      dataIndex: 'Oper',
      label: intl('widget.mock.mock_policy'),
      visible: true,
      render: val => operData[val] || '--'
    },
    {
      dataIndex: 'Method',
      label: intl('widget.service.httpMethods'),
      visible: item.Protocol === 'springCloud',
    },
    {
      dataIndex: 'DubboMethod',
      label: intl('widget.degradation.service'),
      visible: item.Protocol === 'dubbo',
      render: val => {
        return <span style={{ wordBreak: 'break-word' }}>{split(val, '#')[0]}</span>;
      }
    },
    {
      dataIndex: 'ServiceMethod',
      label: intl('widget.msc.method'),
      visible: item.Protocol === 'dubbo',
      render: (val, record) => {
        return <span style={{ wordBreak: 'break-word' }}>{split(record.DubboMethod, '#')[1]}</span>;
      }
    },
    // {
    //   dataIndex: 'ExceptionClassName',
    //   label: intl('widget.mock.force_name'),
    //   visible: item.Oper === 'throw',
    // },
    // {
    //   dataIndex: 'ExceptionMessage',
    //   label: intl('widget.mock.force_message'),
    //   visible: item.Oper === 'throw',
    // },
    // {
    //   dataIndex: 'ClazzName',
    //   label: intl('widget.mse.class_name'),
    //   visible: item.Oper === 'return+callback',
    // },
    // {
    //   dataIndex: 'DegradeServiceName',
    //   label: intl('widget.mse.callback_method'),
    //   visible: item.Oper === 'return+callback',
    // },
    {
      dataIndex: 'Condition',
      label: intl('widget.route.condition_mode'),
      visible: true,
    },
    {
      dataIndex: 'Conditions',
      label: intl('widget.route.condition_list'),
      visible: true,
      span: 24,
      render: (val) => <ConditionList value={val} show protocol={item.Protocol} parent="MstMock" />
    },
    {
      dataIndex: 'Value',
      label: intl('widget.mock.policy_content'),
      visible: true,
      span: 24,
      render: (val) => (
        <MonacoEditor
          isEnableMaximize={false}
          width="100%"
          height={200}
          language="json"
          value={val}
          readOnly
          minimap={false}
        />
      )
    },
    {
      dataIndex: 'Timeout',
      label: intl('widget.msc.return_timeout'),
      visible: true,
      render: (val) => `${val || 0}ms`
    },
  ];

  return (
    <div style={{ width: '100%', ...style }}>
      <If condition={isEmpty(value)}>
        <Empty showIcon emptyMessage={intl('widget.common.no_data')} />
      </If>
      <If condition={!isEmpty(value)}>
        <For each="item" index="index" of={value}>
          <div key={index} className="common-box">
            <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.msc.mst_mock_rule_n', { n: index + 1 })}</div>
            <DataFields
              key={index}
              dataSource={item}
              items={getItems(item)}
              style={{ padding: '8px 0', borderBottom: 0 }}
            />
          </div>
        </For>
      </If>
    </div>
  );
};

ItemInfo.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  style: PropTypes.objectOf(PropTypes.any),
};

export default ItemInfo;
