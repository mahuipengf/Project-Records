import React, { useImperativeHandle, forwardRef, useEffect, useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { Form, Input, Message, Switch, Select, Loading } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import { head, forEach, filter, map, split, get, uniqueId, isEmpty } from 'lodash';
import { NNAME_PATTERN, MSC_WIDGET_CONSOLE_CONFIG } from 'constants';
import { lowerFirstData } from 'utils/transfer-data';
import AppSelector from 'containers/AppSelector';
import { Namespace } from '@ali/mamba-namespace';
import Rules from '../RuleItems';
import { mapConditions, mapConditionsFormData } from 'utils';

const FormItem = Form.Item;

const AddForm = (props, ref) => {
  const field = Field.useField();
  const { value = {}, setRefreshIndex } = props;
  const intl = useIntl();
  const { init, validate, getValue, setValues } = field;
  const rulesRef = useRef();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (value.Id) {
      fetchData();
    } else {
      setValues({
        Namespaces: { regionId: value.Region, namespaceId: value.Namespace },
        Region: value.Region,
        Namespace: value.Namespace
      });
    }
  }, [value]);

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  const fetchData = async () => {
    const params = {
      Region: value.Region,
      Namespace: value.Namespace,
      Id: value.Id,
    };
    setIsLoading(true);
    const Data = await services.GetMockRuleById({
      params,
      customErrorHandle: (err, response, callback) => {
        setIsLoading(false);
        callback();
      }
    }) || {};
    setIsLoading(false);
    const ScRules = get(Data, 'ScMockItems', []);
    const ScMockItems = map(ScRules, item => {
      return {
        ...item,
        Uid: uniqueId(),
        Protocol: 'springCloud',
        Conditions: mapConditions(lowerFirstData(item.ArgumentMockItems || [])),
      };
    });
    const DubboArgRules = get(Data, 'DubboMockItems', []);
    const DubboMockItems = map(DubboArgRules, item => {
      const { ServiceName = '', Version = '', Group = '', MethodName = '', ParamTypes = '' } = item;
      return {
        ...item,
        DubboMethod: `${ServiceName}:${Version}:${Group}#${MethodName}${!isEmpty(ParamTypes) ? `(${ParamTypes})` : ''}`,
        Uid: uniqueId(),
        Protocol: 'dubbo',
        Conditions: mapConditions(lowerFirstData(item.ArgumentMockItems || [])),
      };
    });
    const Description = get(Data, 'ExtraJson.description');
    const newValues = {
      ...Data,
      Region: value.Region,
      Namespace: value.Namespace,
      Namespaces: { regionId: value.Region, namespaceId: value.Namespace },
      Description,
      Rules: [...ScMockItems, ...DubboMockItems]
    };
    setValues(newValues);
  };

  const handleSubmit = () => {
    return new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        if (errors) return reject(errors);
        const params = {
          Id: value.Id,
          MockType: value.MockType,
          Region: values.Region,
          Namespace: values.Namespace,
          Name: values.Name,
          // ProviderAppId: values.ProviderAppId,
          // ProviderAppName: values.ProviderAppName,
          ExtraJson: { description: values.Description },
          Enable: values.Enable,
        };
        const ConsumerAppsJson = [{
          AppId: values.ConsumerAppId,
          AppName: values.ConsumerAppName,
        }];
        const ScRulesJson = filter(values.Rules, item => item.Protocol === 'springCloud');
        const DubboArgRulesJson = filter(values.Rules, item => item.Protocol === 'dubbo');
        const ScMockItemJson = map(ScRulesJson, item => {
          // const [ServiceName = '', Path = ''] = split(item.ScMethod, ':');
          return {
            // executeCondition: item.ExecuteCondition,
            oper: item.Oper,
            Path: item.Path,
            Value: item.Value,
            Method: item.Method,
            Condition: item.Condition,
            Timeout: item.Timeout,
            ArgumentMockItems: mapConditionsFormData(item.Conditions, item.Protocol),
            // exceptionClassName: item.ExceptionClassName || 'java.lang.RuntimeException',
            // exceptionMessage: item.ExceptionMessage,
            // degradeServiceName: item.DegradeServiceName,
            // clazzName: item.ClazzName,
          };
        });

        const DubboMockItemJson = map(DubboArgRulesJson, item => {
          const [Service, Method = ''] = split(item.DubboMethod, '#'); // 注意这里是因为 mstMock 的服务方法都是自填，数据与其他地方的DubboMethod不一样
          const [ServiceName = '', Version = '', Group = ''] = split(Service, ':');
          const match = (str = '') => {
            const string = str.match(/\(.*?\)/);
            const MethodName = split(str, string)[0];
            const firstStr = head(string) || '';
            const param = firstStr.match(/(?<=\()[^]*(?=\))/);
            const first = head(param);
            const ParamTypes = first ? split(first, ',') : [];
            return { MethodName, ParamTypes };
          };
          const { MethodName, ParamTypes } = match(Method);
          return {
            // executeCondition: item.ExecuteCondition,
            oper: item.Oper,
            Value: item.Value,
            ServiceName,
            MethodName,
            ParamTypes,
            Version,
            Group,
            Condition: item.Condition,
            Timeout: item.Timeout,
            ArgumentMockItems: mapConditionsFormData(item.Conditions, item.Protocol),
            // exceptionClassName: item.ExceptionClassName || 'java.lang.RuntimeException',
            // exceptionMessage: item.ExceptionMessage,
            // degradeServiceName: item.DegradeServiceName,
            // clazzName: item.ClazzName,
          };
        });
        if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
          params.ScMockItemJson = ScMockItemJson;
          params.DubboMockItemJson = DubboMockItemJson;
          params.ConsumerAppsJson = ConsumerAppsJson;
        } else {
          params.ScMockItems = ScMockItemJson;
          params.DubboMockItems = DubboMockItemJson;
          params.ConsumerAppIds = ConsumerAppsJson;
        }
        console.log(params);
        value.Id
          ? await services.UpdateMockRule({
            params,
            customErrorHandle: (err, response, callback) => {
              reject();
              callback();
            }
          })
          : await services.AddMockRule({
            params,
            customErrorHandle: (err, response, callback) => {
              reject();
              callback();
            }
          });
        value.Id ? Message.success(intl('widget.common.update_successful')) : Message.success(intl('widget.common.add_successful'));
        resolve();
        setRefreshIndex(Date.now());
      });
    });
  };

  // 针对springCloud，dubbo需要区分判断数据
  const handleValidatorRules = (rule, val, callback) => {
    forEach(val, item => {
      if (item.Protocol === 'springCloud' && !item.Path) {
        callback(intl('widget.degradation.degradation_service_can_not_empty'));
      }
      if (item.Protocol === 'dubbo') {
        const [Service, Method = ''] = split(item.DubboMethod, '#'); // 这里是因为mstMock 的服务方法都是自填，数据与其他地方的DubboMethod不一样

        if (!Service || !Method) {
          callback(intl('widget.degradation.degradation_service_can_not_empty'));
        }
      }
      if (!item.Value) {
        callback(intl('widget.msc.please_enter_return_data'));
      }
      if (!item.Timeout && item.Timeout < 0) {
        callback(intl('widget.msc.please_enter_return_timeout'));
      }
      if (isEmpty(item.Conditions)) {
        callback(intl('widget.route.condition.rule_not_complete'));
      }
      forEach(item.Conditions || [], condition => {
        if (!condition.type || !condition.name || !condition.cond || (!condition.value && condition.value !== 0)) {
          callback(intl('widget.route.condition.rule_not_complete'));
        }
      });
    });
    callback();
  };

  const fetchRegions = async () => {
    const { data = [] } = await services.fetchRegions();
    const newData = map(data, item => item.regionName && item.regionName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      regionName: item.regionName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  const fetchNamespaces = async (region) => {
    const { data = [] } = await services.fetchNamespaces({ params: { regionId: region } });
    const newData = map(data, item => item.namespaceName && item.namespaceName.indexOf(intl('widget.common.namespace')) > -1 ? ({
      ...item,
      namespaceName: item.namespaceName.replace(intl('widget.common.namespace'), intl('widget.common.microservice_space'))
    }) : item);
    return newData;
  };

  return (
    <Loading visible={isLoading} style={{ width: '100%' }}>
      <Form field={field} labelAlign="left">
        <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas'}>
          <FormItem label={intl('widget.common.microservice_space')} required>
            <If condition={!value.Id}>
              <Namespace
                {...init('Namespaces', {
                  initValue: { regionId: value.Region, namespaceId: value.Namespace },
                  rules: [
                    {
                      required: true,
                      message: intl('widget.common.please_select_microservice_space'),
                    },
                  ],
                  props: {
                    onChange: (v) => {
                      setValues({
                        Region: v.regionId,
                        Namespace: v.namespaceId,
                        ConsumerAppId: undefined,
                        ConsumerAppName: undefined,
                      });
                    },
                  }
                })}
                style={{ width: '47%' }}
                fetchRegions={fetchRegions} // 返回对象 { regionId, namespaceId }
                fetchNamespaces={fetchNamespaces}
              />
            </If>
            <If condition={value.Id}>
              {getValue('Namespace')}
            </If>
          </FormItem>
        </If>
        <FormItem label={intl('widget.authentication.rule_name')} required>
          <Input
            {...init('Name', {
              initValue: value.Name,
              rules: [
                {
                  required: true,
                  message: intl('widget.authentication.rule_name_placeholder'),
                },
                {
                  pattern: NNAME_PATTERN,
                  message: intl('widget.common.name_pattern'),
                },
              ],
            })}
            placeholder={intl('widget.authentication.rule_name_placeholder')}
            maxLength={64}
            minLength={1}
            showLimitHint
            disabled={value.Id}
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem label={intl('widget.route.description')}>
          <Input
            {...init('Description', {
              initValue: value.ExtraJson && value.ExtraJson.description,
            })}
            placeholder={intl('widget.route.description_placecholder')}
            maxLength={64}
            showLimitHint
            style={{ width: '100%' }}
          />
        </FormItem>
        <FormItem
          label={intl('widget.home.app')}
          required
        >
          <AppSelector
            {...init('ConsumerAppId', {
              rules: [
                {
                  required: true,
                  message: intl('widget.mock.intro_provider_placeholder'),
                },
              ],
              props: {
                onChange: (id, name) => {
                  setValues({
                    ConsumerAppName: name,
                    Rules: []
                  });
                }
              }
            })}
            namespaces={getValue('Namespaces')}
            disabled={value.Id}
            followTrigger
          />
        </FormItem>
        <FormItem label={intl('widget.msc.mst_mock_rule_list')} required>
          <Rules
            {...init('Rules', {
              rules: [
                {
                  required: true,
                  message: intl('widget.msc.please_add_mst_mock_rule'),
                },
                {
                  validator: handleValidatorRules
                }
              ],
            })}
            PolicyId={value.Id}
            ref={rulesRef}
          />
        </FormItem>
        <If condition={!value.Id}>
          <FormItem label={intl('widget.authentication.default_state')}>
            <Switch
              {...init('Enable', {
                initValue: !!value.Enable,
                valueName: 'checked',
              })}
            />
          </FormItem>
        </If>
      </Form >
    </Loading>
  );
};

const RefAddForm = forwardRef(AddForm);

AddForm.propTypes = {
  value: PropTypes.objectOf(PropTypes.any),
  setRefreshIndex: PropTypes.number,
};

export default RefAddForm;
