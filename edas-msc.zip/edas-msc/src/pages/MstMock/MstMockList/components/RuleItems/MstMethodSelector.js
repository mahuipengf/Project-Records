import React from 'react';
import { split, head, isEmpty } from 'lodash';
import { Input } from '@ali/cn-design';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';

const MstMethodSelector = ({ onChange, value }) => {
  const intl = useIntl();

  const handleChange = (val) => {
    onChange(val);
  };

  const [Service = '', Method = ''] = split(value, '#');
  // const [ServiceName = '', Version = '', Group = ''] = split(Service, ':');
  // const match = (str = '') => {
  //   const string = str.match(/\(.*?\)/);
  //   const MethodName = split(str, string)[0];
  //   const firstStr = head(string) || '';
  //   const param = firstStr.match(/(?<=\()[^]*(?=\))/);
  //   const first = head(param);
  //   const ParamTypes = first ? split(first, ',') : [];
  //   return { MethodName, ParamTypes };
  // };
  // const { MethodName = '', ParamTypes = [] } = match(Method);
  // const newMethod = `${MethodName}${!isEmpty(ParamTypes) ? `(${ParamTypes})` : ''}`;

  return (
    <React.Fragment>
      <Input
        showSearch
        style={{ width: 'calc(50% - 4px)', marginRight: 8 }}
        onChange={(val) => handleChange(`${val}#${Method}`)}
        value={Service}
        placeholder={intl('widget.msc.please_enter_servive')}
      />
      <Input
        showSearch
        style={{ width: 'calc(50% - 4px)' }}
        onChange={(val) => handleChange(`${Service}#${val}`)}
        value={Method}
        placeholder={intl('widget.msc.please_enter_method')}
      />
    </React.Fragment>
  );
};

MstMethodSelector.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.arrayOf(PropTypes.object),
};

export default MstMethodSelector;
