import React, { useState, useEffect, useImperativeHandle, useRef, forwardRef } from 'react';
import { uniqueId, map, filter, get } from 'lodash';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import PropTypes from 'prop-types';
import { Icon } from '@ali/cn-design';
import CommonEvent from 'components/CommonEvent';
import RouteForm from './Item';

const RulesRef = (props, ref) => {
  const { value = [], onChange, PolicyId } = props;
  const intl = useIntl();
  const [list, setList] = useState([]);
  const rulesRef = useRef();
  const formRef = useRef();

  useEffect(() => {
    setList(value);
    onChange(value);
  }, [value]);

  useImperativeHandle(ref, () => ({
    validator
  }));

  const handleAdd = () => {
    const newList = [...list, {
      Uid: -uniqueId(),
      // ExecuteCondition: 'force',
      // DubboMethod: undefined,
      // ScMethod: undefined,
      Oper: 'return+json',
      Protocol: 'springCloud',
      // Value: undefined,
      // Method: undefined,
    }];
    onChange(newList);
  };

  const handleDelete = (Uid) => {
    const newList = filter(list, item => item.Uid !== Uid);
    onChange(newList);
  };

  const validator = async () => {
    const res = formRef.current && await formRef.current.handleSubmit();
    return res;
  };

  const handleChange = (val) => {
    const newList = map(list, item => item.Uid === val.Uid ? val : item);
    onChange(newList);
  };

  return (
    <div ref={rulesRef}>
      <For each="item" index="index" of={list}>
        <div className="common-box" key={index} style={{ paddingBottom: 0 }}>
          <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee', display: 'flex', justifyContent: 'space-between' }}>
            <span>{intl('widget.msc.mst_mock_rule_n', { n: index + 1 })}</span>
            <Icon type="close" size="xs" className="common-icon" onClick={() => handleDelete(item.Uid)} />
          </div>
          <RouteForm value={item} key={item.Uid} ref={formRef} onChange={handleChange} PolicyId={PolicyId} />
        </div>
      </For>
      <div className="common-box" style={{ padding: 16 }}>
        <CommonEvent onClick={handleAdd} text={intl('widget.msc.add_mst_mock_rule')} />
      </div>
    </div>
  );
};

const RefRules = forwardRef(RulesRef);

RulesRef.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  onChange: PropTypes.func,
  PolicyId: PropTypes.string,
};

export default RefRules;
