import React, { useImperativeHandle, forwardRef, useEffect } from 'react';
import { Radio, Form, Loading, Select, Input, NumberPicker, Icon, Balloon } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { useIntl } from '@ali/widget-hooks';
import { forEach, get } from 'lodash';
import PropTypes from 'prop-types';
import MstMethodSelector from './MstMethodSelector';
import MonacoEditor from 'components/MonacoEditor';
import ConditionList from 'containers/ConditionList';

const FormItem = Form.Item;

const RouteForm = (props, ref) => {
  const field = Field.useField();
  const intl = useIntl();
  const { init, validate, getValues, getValue, setValue, setValues } = field;
  const { value = {}, onChange, PolicyId } = props;

  useEffect(() => {
    setValues(value);
  }, [value]);

  useImperativeHandle(ref, () => ({
    handleSubmit,
  }));

  const handleChange = () => {
    onChange({ ...value, ...getValues() });
  };

  const handleSubmit = () => {
    return new Promise((resolve) => {
      validate((errors, values) => {
        resolve({ errors, values });
      });
    });
  };

  const handleValidatorConditions = (rule, val, callback) => {
    forEach(val, item => {
      if (getValue('protocol') === 'dubbo') {
        if (!(item.index >= 0) || !item.cond || (!item.value && item.value !== 0)) {
          callback(intl('widget.route.condition.rule_not_complete'));
          return;
        }
      }
      if (getValue('protocol') === 'springCloud' || getValue('protocol') === 'istio') {
        if (!item.type || !item.name || !item.cond || (!item.value && item.value !== 0)) {
          callback(intl('widget.route.condition.rule_not_complete'));
        }
      }
    });
    callback();
  };

  return (
    <Form field={field} labelAlign="left" style={{ paddingTop: 16 }}>
      <FormItem label={intl('widget.route.frame_type')} required>
        <Radio.Group
          {...init('Protocol', {
            initValue: 'springCloud',
            rules: [
              {
                required: true,
                message: intl('widget.route.frame_type_errorr'),
              },
            ],
            props: {
              onChange: () => {
                setValue('Conditions', []);
                handleChange();
              }
            }
          })}
          dataSource={[
            { value: 'springCloud', label: 'Spring Cloud' },
            { value: 'dubbo', label: 'Dubbo' }
          ]}
        // disabled={!!PolicyId && value.Uid > 0}
        />
      </FormItem>
      <If condition={getValue('Protocol') === 'dubbo'}>
        <FormItem
          label={
            <React.Fragment>
              <span>{intl('widget.app.service_method')}</span>
              <Balloon
                align="t"
                trigger={<Icon type="help" style={{ display: 'inline-grid', marginLeft: 4, color: '#777', cursor: 'pointer' }} />}
                closable={false}
                style={{ minWidth: 450 }}
              >
                {intl.html('widget.app.service_method_hint')}
              </Balloon>
            </React.Fragment>
          }
          required={getValue('Protocol') === 'dubbo'}
        >
          <MstMethodSelector
            {...init('DubboMethod', {
              // initValue: value.DubboMethod,
              rules: [
                {
                  required: getValue('Protocol') === 'dubbo',
                  message: intl('widget.route.service_method_error'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
          />
        </FormItem>
      </If>
      <If condition={getValue('Protocol') === 'springCloud'}>
        <FormItem label={intl('widget.degradation.degradation_service_path')} required={getValue('Protocol') === 'springCloud'}>
          <Input
            {...init('Path', {
              // initValue: value.Path,
              rules: [
                {
                  required: getValue('Protocol') === 'springCloud',
                  message: intl('widget.msc.please_enter_service_path'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            placeholder={intl('widget.msc.please_enter_service_path')}
          />
        </FormItem>
        <FormItem label={intl('widget.service.httpMethods')} required={getValue('Protocol') === 'springCloud'}>
          <Select
            {...init('Method', {
              initValue: 'GET',
              rules: [
                {
                  required: getValue('Protocol') === 'springCloud',
                  message: intl('widget.msc.please_select_method'),
                },
              ],
              props: {
                onChange: handleChange
              }
            })}
            style={{ width: '100%' }}
            dataSource={[
              { value: 'GET', label: 'GET' },
              { value: 'POST', label: 'POST' },
              // { value: 'PATCH', label: 'PATCH' },
              { value: 'PUT', label: 'PUT' },
              { value: 'DELETE', label: 'DELETE' },
            ]}
            placeholder={intl('widget.msc.please_select_method')}
            followTrigger
          />
        </FormItem>
      </If>
      <FormItem label={intl('widget.route.condition_mode')} required>
        <Radio.Group
          {...init('Condition', {
            initValue: 'AND',
            rules: [
              {
                required: true,
                message: intl('widget.route.condition_mode_error'),
              },
            ],
            props: {
              onChange: handleChange
            }
          })}
          dataSource={[
            { value: 'AND', label: intl('widget.route.condition_and') },
            { value: 'OR', label: intl('widget.route.condition_or') },
          ]}
        />
      </FormItem>
      <FormItem
        label={intl('widget.route.condition_list')}
        required
      >
        <ConditionList
          {...init('Conditions', {
            initValue: [],
            rules: [
              {
                required: true,
                message: intl('widget.route.condition_list_error'),
              },
              {
                validator: handleValidatorConditions,
              }
            ],
            props: {
              onChange: handleChange
            }
          })}
          parent="MstMock"
          protocol={getValue('Protocol')}
        />
      </FormItem>
      <FormItem
        label={intl('widget.mock.mock_policy')}
        required
      >
        <Select
          {...init('Oper', {
            initValue: value.Oper || 'return+json',
            props: {
              onChange: handleChange
            }
          })}
          style={{ width: '100%', marginBottom: 8 }}
          followTrigger
          dataSource={[
            // { value: 'return+null', label: intl('widget.mock.return_null') },
            // { value: 'throw', label: intl('widget.mock.return_excention_error') },
            { value: 'return+json', label: intl('widget.mock.return_customize_json') },
            // { value: 'return+callback', label: intl('widget.mock.return_customize_callback') },
          ]}
        />
      </FormItem>
      <FormItem
        label={intl('widget.msc.return_data')}
        required
      >
        <MonacoEditor
          {...init('Value', {
            // initValue: value.Value,
            rules: [
              {
                required: true,
                message: intl('widget.msc.please_enter_return_data'),
              },
            ],
            props: {
              onChange: handleChange
            }
          })}
          isEnableMaximize={false}
          width="100%"
          height={200}
          // language="json"
          minimap={false}
        />
      </FormItem>
      <FormItem label={intl('widget.msc.return_timeout')} required>
        <NumberPicker
          {...init('Timeout', {
            initValue: 0,
            rules: [
              {
                required: true,
                message: intl('widget.msc.please_enter_return_timeout'),
              },
            ],
            props: {
              onChange: handleChange
            }
          })}
          min={0}
          max={30000}
          style={{ width: '95%' }}
          placeholder={intl('widget.msc.please_enter_return_timeout')}
        />
        <span style={{ marginLeft: 8 }}>ms</span>
      </FormItem>
    </Form >
  );
};

const RefRouteForm = forwardRef(RouteForm);

RouteForm.propTypes = {
  onChange: PropTypes.func,
  value: PropTypes.objectOf(PropTypes.any),
  Uid: PropTypes.number,
  serviceLoading: PropTypes.bool,
  PolicyId: PropTypes.string,
};

export default RefRouteForm;

