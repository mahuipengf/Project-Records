import React, { useState, useRef } from 'react';
import PropTypes from 'prop-types';
import services from 'services';
import { useIntl, useGlobalState } from '@ali/widget-hooks';
import Events from './Events';
import { TableContainer, CopyContent, modelDecorator, Empty, Button, Message } from '@ali/cn-design';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import Status from 'components/Status/CommonStatus';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_ENV_PRIVATE } from 'constants';
import { map, isEmpty } from 'lodash';
import AddForm from './components/AddForm';
import RuleInfo from './components/RuleInfo';
import { Dubbo, SpringCloud } from 'components/Icon';

const PROTOCOL = {
  DUBBO: 'Dubbo',
  SPRING_CLOUD: 'Spring Cloud',
};

const ICON = {
  DUBBO: <Dubbo />,
  SPRING_CLOUD: <SpringCloud />,
};

function MstMockList(props) {
  const { tableUniqueKey, toggleModal } = props;
  const [isCanCustomColumns] = useState(true);
  const [isCanMultipleSearch] = useState(true);
  const [isCanRefresh] = useState(true);
  const [isAutoAddSorted] = useState(true);
  const [fetchDataTime, setFetchDataTime] = useState(undefined);
  const [searchValues] = useGlobalState('searchValues');
  const addForm = useRef(null);
  const intl = useIntl();
  const { regionId, namespaceId } = searchValues;
  const defaultValue = {
    Protocol: searchValues.protocol || 'SPRING_CLOUD',
    Enable: true,
    Region: searchValues.regionId,
    Namespace: searchValues.namespaceId,
    MockType: 1,
  };

  const fetchData = async ({ pageNumber, pageSize, Protocol, Name, ProviderAppName, ConsumerAppName }) => {
    let params = {
      Region: regionId,
      PageNumber: pageNumber,
      PageSize: pageSize,
      Protocol,
      Name,
      ProviderAppName,
      ConsumerAppName,
      MockType: 1,
    };
    if (MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas') {
      params = {
        ...params,
        Namespace: namespaceId
      };
    }
    const Data = await services.GetAccountMockRule({
      params
    });
    const { Result = [], TotalSize = 0 } = Data || {};
    return {
      Data: map(Result, item => ({ ...item, Region: item.Region || regionId, Namespace: item.Namespace || namespaceId, MockType: item.MockType || 1 })),
      TotalCount: TotalSize,
    };
  };

  const columns = [
    {
      key: 'Name',
      title: intl('widget.authentication.rule_name'),
      dataIndex: 'Name',
      cell: (value, index, record) => (
        <CopyContent text={value}>
          <span className="link-primary" onClick={() => handleGoToInfo(record)}>{value}</span>
        </CopyContent>
      ),
    },
    {
      key: 'ConsumerAppName',
      title: intl('widget.home.app'),
      dataIndex: 'ConsumerAppName',
      cell: value => (
        <CopyContent text={value}>
          {value}
        </CopyContent>
      )
    },
    // {
    //   key: 'Protocol',
    //   title: intl('widget.app.framework'),
    //   dataIndex: 'Protocol',
    //   cell: (value, index, record) => {
    //     const arr = [];
    //     if (!isEmpty(record.ScMockItems)) {
    //       arr.push('SPRING_CLOUD');
    //     }
    //     if (!isEmpty(record.DubboMockItems)) {
    //       arr.push('DUBBO');
    //     }
    //     return (
    //       <React.Fragment>
    //         <Empty value={!arr.length && undefined}>
    //           <For each="item" index="index" of={arr}>
    //             <div style={{ display: 'flex' }} key={index}>
    //               {ICON[item]}
    //               <span>{PROTOCOL[item]}</span>
    //             </div>
    //           </For>
    //         </Empty>
    //       </React.Fragment>
    //     );
    //   }
    // },
    {
      key: 'Enable',
      title: intl('widget.common.state'),
      dataIndex: 'Enable',
      cell: val => <Status value={val} intl={intl} />
    },
    {
      key: 'operations',
      title: intl('widget.common.operating'),
      cell: (value, index, record) => <Events record={record} handleEdit={() => handleEdit(record)} setFetchDataTime={setFetchDataTime} />,
    },
  ];

  const searchs = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.authentication.rule_name'),
          value: 'Name',
          placeholder: intl('widget.authentication.rule_name_placeholder')
        },
        {
          label: intl('widget.home.app'),
          value: 'ConsumerAppName',
          placeholder: intl('widget.app.name_placeholder')
        },
      ],
      defaultValue: 'Name',
    },
    isCanCustomColumns,
    isCanMultipleSearch,
    tableUniqueKey,
    isCanRefresh,
  };

  const handleGoToInfo = (record) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl('widget.authentication.info'),
      content: (
        <RuleInfo value={{ ...record }} handleEdit={() => handleEdit(record)} />
      ),
      onConfirm: null,
    });
  };

  const handleEdit = (record = defaultValue) => {
    toggleModal({
      size: 'large',
      type: 'slide',
      visible: true,
      title: intl('widget.msc.edit_mock'),
      content: (
        <AddForm
          ref={addForm}
          value={{ ...record }}
          setRefreshIndex={setFetchDataTime}
        />
      ),
      onConfirm: () => addForm.current.handleSubmit(),
    });
  };

  const handleAdd = (record = defaultValue) => {
    toggleModal({
      type: 'slide',
      visible: true,
      size: 'large',
      title: intl('widget.msc.create_mock'),
      content: (
        <AddForm
          ref={addForm}
          value={{ ...record }}
          setRefreshIndex={setFetchDataTime}
        />
      ),
      onConfirm: () => addForm.current.handleSubmit(),
    });
  };

  return (
    <React.Fragment>
      {/* <If condition={MSC_WIDGET_CONSOLE_CONFIG.productName === 'Edas' && !IS_ENV_PRIVATE}>
        <Message type="warning" style={{ marginBottom: 16 }}>
          {intl.html('widget.degradation.label')}
        </Message>
      </If> */}
      <TableContainer
        fetchData={fetchData}
        primaryKey="id"
        columns={columns}
        search={searchs}
        refreshIndex={fetchDataTime}
        affixActionBar
        isUseStorage={MSC_WIDGET_CONSOLE_CONFIG.productName !== 'Edas'}
        sortConfig={{
          isAutoAddSorted,
        }}
        operation={() => (
          <Button type="primary" onClick={() => handleAdd()}>
            {intl('widget.msc.create_mock')}
          </Button>
        )}
        emptyContent={
          <div >
            <Actions expandTriggerType="hover" style={{ justifyContent: 'center' }}>
              <LinkButton key="1" onClick={() => handleAdd()}>{intl('widget.authentication.no_data_go_create')}</LinkButton>
            </Actions>
          </div>
        }
      />
    </React.Fragment>
  );
}

MstMockList.propTypes = {
  toggleModal: PropTypes.func,
  tableUniqueKey: PropTypes.string,
};

export default modelDecorator(MstMockList);
