import MstMockList from './MstMockList';

export default MstMockList;
