import React, { Component } from 'react';
import JSONEditor from 'jsoneditor';
import 'jsoneditor/dist/jsoneditor.css';
import './index.less';

export default class JSONEditorDemo extends Component {
  componentDidMount() {
    const { onChange, value = {} } = this.props;

    const options = {
      mode: 'tree',
      modes: ['code', 'tree', 'view'], // allowed modes
      onError: err => console.log(err),
      onModeChange: (newMode, oldMode) => {
        console.log('Mode switched from', oldMode, 'to', newMode);
      },
      onChangeText: val => onChange(JSON.parse(val)),
    };

    this.jsoneditor = new JSONEditor(this.container, options);
    console.log(this.jsoneditor);

    this.jsoneditor.set(value);
  }

  componentWillUnmount() {
    if (this.jsoneditor) {
      this.jsoneditor.destroy();
    }
  }

  // componentDidUpdate() {
  //   const { json } = this.props;
  //   this.jsoneditor.update(json);
  // }

  render() {
    return (
      <div className="jsoneditor-react-container" ref={el => this.container = el} />
    );
  }
}
