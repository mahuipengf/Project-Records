import React from 'react';
import PropTypes from 'prop-types';
import { Instance } from 'components/Icon';
import styles from './index.less';
import { useIntl } from '@ali/widget-hooks';
import Cookie from 'js-cookie';

const CommonCard = ({ title, value = 0, unit }) => {
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';
  const intl = useIntl();
  return (
    <div className={styles['common-card']}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span>{title}</span>
        <Instance />
      </div>
      <div style={{ marginTop: 16 }}>
        <span style={{ fontSize: 28, color: '#555', marginRight: 4, }}>{value}</span>
        <If condition={aliyunSite !== 'INTL'}>
          <span>{unit || intl('widget.home.individual')}</span>
        </If>
      </div>
    </div>
  );
};

CommonCard.propTypes = {
  value: PropTypes.number,
  title: PropTypes.string,
  unit: PropTypes.string,
};

export default CommonCard;
