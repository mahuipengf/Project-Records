import React from 'react';

const Iframe = (props) => {
  const { ...rest } = props;
  return <iframe id="frame-content" height="600" frameBorder={0} width="100%" {...rest} />;
};

export default Iframe;
