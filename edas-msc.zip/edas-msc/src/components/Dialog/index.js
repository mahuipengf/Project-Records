import React from 'react';
import { Dialog } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';

const MyDialog = (props) => {
  const intl = useIntl();
  const { children, ...rest } = props;
  return (<Dialog {...rest} okProps={{ children: intl('widget.common.ok') }} cancelProps={{ children: intl('widget.common.cancel') }} >
    {children}
  </Dialog>);
};
export default MyDialog;
