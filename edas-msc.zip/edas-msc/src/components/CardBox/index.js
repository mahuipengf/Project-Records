import React from 'react';
import PropTypes from 'prop-types';

const CardBox = ({ title, children }) => {
  return (
    <div style={{ boxShadow: '0 0 10px #eee', marginBottom: 16 }}>
      <h5 style={{ padding: '8px 16px', borderBottom: '1px solid #eee', margin: 0 }}>{title}</h5>
      <div style={{ padding: 8 }}>
        {children}
      </div>
    </div>
  );
};

CardBox.propTypes = {
  title: PropTypes.string,
  children: PropTypes.element,
};

export default CardBox;
