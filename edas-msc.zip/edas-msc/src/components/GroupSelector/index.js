import React, { useEffect, useState } from 'react';
import propTypes from 'prop-types';
import { Select, IconButton } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';
import { head } from 'lodash';

const GroupSelector = (props) => {
  const { handleAdd, dataSource, onChange } = props;
  const [groupId, setCurrentGroupId] = useState('');
  const intl = useIntl();

  useEffect(() => {
    if (!groupId) {
      const firstGroup = head(dataSource) || {};
      setCurrentGroupId(firstGroup.value);
      onChange && onChange(firstGroup.value);
    }
  }, [dataSource]);

  const handleChangeGroup = (val) => {
    setCurrentGroupId(val);
    onChange && onChange(val);
  };

  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      {/* <span style={{ fontSize: 14, marginRight: 16 }}>{intl('widget.k8s_gray.select_lane_group')}</span> */}
      <Select
        value={groupId}
        dataSource={dataSource}
        onChange={handleChangeGroup}
        style={{ border: 'none', background: 'red' }}
        popupStyle={{ border: 'none', background: 'red' }}
      />
      <IconButton type="add" onClick={handleAdd} style={{ marginLeft: 16 }}>{intl('widget.common.create')}</IconButton>
    </div>
  );
};

GroupSelector.propTypes = {
  handleAdd: propTypes.func,
  dataSource: propTypes.arrayOf(propTypes.any),
  onChange: propTypes.func,
  value: propTypes.number,
};

export default GroupSelector;
