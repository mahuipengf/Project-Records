import React from 'react';
import { Icon } from '@ali/cn-design';
import PropTypes from 'prop-types';
import './index.less';

const CommonEvent = (props) => {
  const { text, onClick, style, type = 'add' } = props;

  return (
    <Icon style={style} className="link-primary link-primary-add" type={type} size="xs" >
      <span onClick={onClick}>{text}</span>
    </Icon>
  );
};

CommonEvent.propTypes = {
  onClick: PropTypes.func,
  text: PropTypes.string,
  type: PropTypes.string,
  style: PropTypes.objectOf(PropTypes.any),
};
export default CommonEvent;
