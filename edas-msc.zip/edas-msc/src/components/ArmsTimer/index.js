import React from 'react';
import { get } from 'lodash';
import { TimeContainer } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { useIntl, useGlobalState } from '@ali/widget-hooks';

const ArmsTimer = (props) => {
  // const [metricQuery, setMetricQuery] = useGlobalState('metricQuery');
  const field = Field.useField();
  const intl = useIntl();
  const { init } = field;

  const handleChange = (val) => {
    if (!val) return;
    const times = get(val, 'value', []);
    const params = {
      StartTime: times[0],
      EndTime: times[1],
    };
    const interval = (times[1] - times[0]) / 60000;
    if (interval <= 60) {
      params.IntervalInSec = 60000;
    } else if (interval > 60 && interval <= 360) {
      params.IntervalInSec = 300000;
    } else if (interval > 360 && interval <= 3600) {
      params.IntervalInSec = 600000;
    } else if (interval > 3600 && interval <= 36000) {
      params.IntervalInSec = 3600000;
    } else {
      params.IntervalInSec = 3600000;
    }
    // setMetricQuery(params);
  };

  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <span >{intl('widget.k8s_gray.arms_times')}</span>
      <TimeContainer
        {...init('time', { initValue: 'last_15_minutes' })}
        onChange={handleChange}
        mode="realTime"
      />
    </div>
  );
};

export default ArmsTimer;
