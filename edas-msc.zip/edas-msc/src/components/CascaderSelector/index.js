import React, { useState, useEffect } from 'react';
import { Icon, Select } from '@ali/cn-design';
import { map, forEach } from 'lodash';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import './index.less';

const CascaderSelector = (props) => {
  const { value, onChange, dataSource: oldDataSource = [], ...rest } = props;
  const [subList, setSubList] = useState([]);
  const [currentValue, setCurrentValue] = useState({});
  const [visible, setVisible] = useState(false);
  const intl = useIntl();


  useEffect(() => {
    mapCurrentValue(value);
  }, [value]);

  const dataSource = map(oldDataSource, item => {
    if (!item.children) return ({ ...item, showLabel: item.label });
    const newChildren = map(item.children, child => {
      const newChild = { ...child, parent: item.value, showLabel: `${item.label || ''} / ${child.label || ''}` };
      return newChild;
    });
    const newItem = { ...item, children: newChildren };
    return newItem;
  });

  const mapCurrentValue = (val) => {
    if (!val) {
      setCurrentValue({});
      return;
    }
    forEach(dataSource, item => {
      if (item.value === val) {
        setCurrentValue(item);
        return;
      }
      if (item.children) {
        forEach(item.children, child => {
          if (child.value === val) {
            setSubList(item.children);
            setCurrentValue(child);
          }
        });
      }
    });
  };

  const handleClickParent = (item) => {
    if (!item.children) {
      setCurrentValue(item);
      setSubList([]);
      setVisible(false);
      onChange && onChange(item.value, item);
      return;
    }
    setSubList(item.children || []);
  };

  const handleClickChild = (item) => {
    setCurrentValue(item);
    setVisible(false);
    onChange && onChange(item.value, item);
  };

  return (
    <React.Fragment>
      <Select
        {...rest}
        value={currentValue.showLabel}
        dataSource={dataSource}
        visible={visible}
        onVisibleChange={val => setVisible(val)}
        popupContent={
          <div className="cascader-selector">
            <div className="cascader-selector-wrap">
              <If condition={dataSource && dataSource.length}>
                <div className="selector">
                  <For index="index" each="item" of={dataSource}>
                    <div
                      className={currentValue.value === item.value ? 'select-item select-item-active' : 'select-item'}
                      className={`select-item ${currentValue.value === item.value && 'select-item-active'} ${currentValue.parent === item.value && 'select-item-parent-active'}`}
                      onClick={() => handleClickParent(item)}
                      key={item.value}
                    >
                      <If condition={currentValue.value === item.value}>
                        <Icon type="select" className="select" />
                      </If>
                      <span className="text">{item.label}</span>
                      <If condition={item.children}>
                        <Icon type="arrow-right" className="arrow-right" />
                      </If>
                    </div>
                  </For>
                </div>
              </If>
              <If condition={subList.length}>
                <div className="selector">
                  <For index="index" each="item" of={subList}>
                    <div className={currentValue.value === item.value ? 'select-item select-item-active' : 'select-item'} key={item.value} onClick={() => handleClickChild(item)}>
                      <If condition={currentValue.value === item.value}>
                        <Icon type="select" className="select" />
                      </If>
                      <span className="text">{item.label}</span>
                      <If condition={item.children}>
                        <Icon type="arrow-right" className="arrow-right" />
                      </If>
                    </div>
                  </For>
                </div>
              </If>
              <If condition={!dataSource || !dataSource.length}>
                <div className="no-data">{intl('widget.common.no_data')}</div>
              </If>
            </div>
          </div>
        }
      />
    </React.Fragment>
  );
};


CascaderSelector.propTypes = {
  value: PropTypes.string,
  onChange: PropTypes.func,
  dataSource: PropTypes.arrayOf(PropTypes.object),
};


export default CascaderSelector;
