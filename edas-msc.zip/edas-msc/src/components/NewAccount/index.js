import React from 'react';
import { NoPermission } from '../Icon';
import { Button } from '@alicloud/console-components';
import PropTypes from 'prop-types';
import { useIntl } from '@ali/widget-hooks';
import Cookie from 'js-cookie';
import { IS_SAU_BUSINESS } from 'constants';


const NewAccount = ({ mscAccount }) => {
  const intl = useIntl();
  const aliyunSite = Cookie.get('aliyun_site') || 'CN';
  let openHref = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn';
  let rechargeHref = 'https://usercenter2.aliyun.com/finance/fund-management/recharge';
  // const openEnterpriseHref = `https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn&orderType=UPGRADE&instanceId=synthetic_post_${mscAccount.UserId}`;
  if (aliyunSite === 'INTL') {
    openHref =
      "https://common-buy-intl.alibabacloud.com/?commodityCode=mse_basic_public_intl";
    rechargeHref =
      "https://usercenter2-intl.aliyun.com/renew/manual?spm=5176.mse-ops.top-nav.ditem-ren.36c3142fCQOCud&expiresIn=&commodityCode=";
  }
  return (
    <div style={{ display: 'flex', justifyContent: 'center', margin: 100 }}>
      <NoPermission style={{ width: 120, height: 120, marginRight: 16 }} />
      {/* 公测用户 */}
      <If condition={mscAccount.Status === 0 && mscAccount.TimeLeft === 0}>
        <div>
          <h5 style={{ margin: '16px 0 0' }}>{intl('widget.msc.you_no_open_msc')}</h5>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500 }}>{intl.html('widget.msc.account_status_0')}</div>
          <Button type="primary">{intl.html('widget.msc.open_mse_basic_public_now', { openHref })}</Button>
        </div>
      </If>
      {/* 新用户 */}
      <If condition={mscAccount.Status === 1}>
        <div>
          <h5 style={{ margin: '16px 0 0' }}>{intl('widget.msc.you_no_open_msc')}</h5>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500 }}>{intl.html('widget.msc.account_status_1')}</div>
          <Button type="primary">{intl.html('widget.msc.open_mse_basic_public_now', { openHref })}</Button>
        </div>
      </If>
      {/* 欠费停机 */}
      <If condition={mscAccount.Status === 3}>
        <div>
          <h5 style={{ margin: '16px 0 0' }}>{intl('widget.msc.you_has_closed_msc')}</h5>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500 }}>{intl.html('widget.msc.account_status_3', { rechargeHref })}</div>
          <Button type="primary" style={{ padding: 0 }}>{intl.html('widget.msc.open_again', { rechargeHref })}</Button>
        </div>
      </If>
    </div>
  );
};

NewAccount.propTypes = {
  mscAccount: PropTypes.objectOf(PropTypes.any),
};
export default NewAccount;
