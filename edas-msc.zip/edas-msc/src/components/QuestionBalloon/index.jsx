import React from 'react';
import { Icon, Balloon } from '@ali/cn-design';
import styles from './index.less';

export default function QuestionBalloon({ title, content, align }) {
	return (
		<>
			<span className={styles["label-text"]}>{title}</span>
			<Balloon
				trigger={<Icon type="question-circle" size="xs" />}
				closable={false}
				align={align || 'r'}
			>
				{content}
			</Balloon>
		</>
	);
}
