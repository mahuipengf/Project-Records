import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { NumberPicker, Range } from '@ali/cn-design';

const RangePicker = (props) => {
  const {
    value,
    defaultValue = 0,
    onChange,
    marks = 10,
    marksPosition = 'below',
    type = 'inline',
    unit,
    style,
    ...rest
  } = props;
  const [cuttentValue, setCurrentValue] = useState(0);

  useEffect(() => {
    setCurrentValue(value);
  }, [value]);

  const handleChange = (val) => {
    setCurrentValue(val);
    onChange && onChange(val);
  };

  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <Range
        value={cuttentValue === undefined ? defaultValue : cuttentValue}
        marksPosition={marksPosition}
        marks={marks}
        onChange={val => handleChange(val)}
        style={{ padding: '8px 32px 0 8px' }}
        {...rest}
      />
      <NumberPicker
        type={type}
        value={cuttentValue === undefined ? defaultValue : cuttentValue}
        onChange={val => handleChange(val)}
        {...rest}
      />
      <If condition={unit}>
        <span>{unit}</span>
      </If>
    </div>
  );
};

RangePicker.propTypes = {
  value: PropTypes.number,
  defaultValue: PropTypes.number,
  marks: PropTypes.number,
  marksPosition: PropTypes.string,
  type: PropTypes.string,
  unit: PropTypes.string,
  onChange: PropTypes.func,
  style: PropTypes.objectOf(PropTypes.any),
};

export default RangePicker;
