import React from 'react';
import SlidePanel from '@alicloud/console-components-slide-panel';
import { useIntl } from '@ali/widget-hooks';

const MySlidePanel = (props) => {
  const intl = useIntl();
  const { children, ...rest } = props;
  return (
    <SlidePanel
      okText={intl('widget.common.ok')}
      cancelText={intl('widget.common.cancel')}
      {...rest}
    >
      {children}
    </SlidePanel>
  );
};

export default MySlidePanel;
