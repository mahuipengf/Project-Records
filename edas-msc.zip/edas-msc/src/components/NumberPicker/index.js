import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { NumberPicker, Range } from '@ali/cn-design';
import './index.less';

const MetaNumberPicker = (props) => {
  const { value, onChange, ...rest } = props;
  const [cuttentValue, setCurrentValue] = useState(value);


  useEffect(() => {
    setCurrentValue(value);
  }, [value]);


  const handleChange = (val) => {
    onChange && onChange(val);
  };

  return (
    <div className="number-pickier-container">
      <Range
        value={cuttentValue}
        step={1}
        marksPosition="below"
        marks={10}
        onChange={val => handleChange(val)}
        style={{ padding: '8px 32px 0 8px', width: '70%' }}
      />
      <NumberPicker {...rest} type="inline" value={cuttentValue} onChange={val => handleChange(val)} />
      <span style={{ marginLeft: 8 }}>%</span>
    </div>
  );
};

MetaNumberPicker.propTypes = {
  value: PropTypes.number,
  onChange: PropTypes.func,
};

export default MetaNumberPicker;
