import React, { useEffect, useState } from 'react';
import { Loading, Empty } from '@ali/cn-design';
import PropTypes from 'prop-types';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

const Markdown = (props) => {
  const [markdown, setMarkdown] = useState('');
  const [loading, setLoading] = useState(false);
  const { fetchData, value } = props;

  useEffect(() => {
    setMarkdown(value);
  }, [value]);

  useEffect(() => {
    fetchData && fetchMarkData();
  }, [fetchData]);

  const fetchMarkData = async () => {
    setLoading(true);
    const { data } = await fetchData();
    setLoading(false);
    setMarkdown(data);
  };

  return (
    <Loading visible={loading} style={{ width: '100%', }}>
      <If condition={!markdown}>
        <Empty showIcon />
      </If>
      <If condition={markdown}>
        {/* <ReactMarkdown source={markdown} escapeHtml={false} remarkPlugins={[remarkGfm]} /> */}
        <ReactMarkdown children={markdown} remarkPlugins={[remarkGfm]} />
      </If>
    </Loading>
  );
};

Markdown.propTypes = {
  fetchData: PropTypes.func,
  value: PropTypes.string,
};

export default Markdown;
