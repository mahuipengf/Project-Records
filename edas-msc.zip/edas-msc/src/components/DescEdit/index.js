import React, { Fragment, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Truncate from '@alicloud/console-components-truncate';
import { Button, Balloon, Form, Message, Input } from '@ali/cn-design';
import { Field } from '@alicloud/console-components';
import { useIntl } from '@ali/widget-hooks';
import CommonEvent from 'components/CommonEvent';

const FormItem = Form.Item;

const ConfigDesc = props => {
  const { value, handleSubmit, onChange, name } = props;
  const field = Field.useField();
  const { init, validate, setValue } = field;
  const intl = useIntl();

  const [isVisible, setVisible] = useState(false);
  const [isLoading, setLoading] = useState(false);

  useEffect(() => {
    setValue(name, value);
  }, [value]);

  const handleEdit = () => {
    setVisible(true);
  };

  const handleCancel = () => {
    setLoading(false);
    setVisible(false);
  };

  const handleOk = async () => {
    validate(async (errors, values) => {
      if (errors) return;
      setLoading(true);
      handleSubmit && await handleSubmit(values, {
        customErrorHandle: (err, response, callback) => {
          setLoading(false);
          callback();
        }
      });
      onChange && onChange(values);
      Message.success(intl('widget.common.update_successful'));
      handleCancel();
    });
  };

  return (
    <Fragment>
      <Truncate value="80" align="b">
        {value || intl('widget.route.no_detail')}
      </Truncate>
      <Balloon
        trigger={
          <CommonEvent text={intl('widget.common.edit')} type="edit" style={{ marginLeft: 4 }} onClick={handleEdit} />
        }
        visible={isVisible}
        align="b"
        triggerType="click"
        popupStyle={{ width: '500px' }}
        onClose={handleCancel}
      >
        <Form field={field} labelAlign="top">
          <FormItem label={intl('widget.route.description')}>
            <Input.TextArea
              maxLength={64}
              showLimitHint
              placeholder={intl('widget.route.description_placecholder')}
              {...init(name, {
                initValue: value,
              })}
            />
          </FormItem>
          <FormItem>
            <div style={{ textAlign: 'right' }}>
              <Button validate="true" loading={isLoading} type="primary" onClick={handleOk}>
                {intl('widget.common.ok')}
              </Button>
              <Button style={{ marginLeft: '8px' }} type="normal" onClick={handleCancel}>
                {intl('widget.common.cancel')}
              </Button>
            </div>
          </FormItem>
        </Form>
      </Balloon>
    </Fragment>
  );
};

ConfigDesc.propTypes = {
  value: PropTypes.string,
  handleSubmit: PropTypes.func,
  onChange: PropTypes.func,
  name: PropTypes.string,
};

export default ConfigDesc;
