import { confirm } from '@ali/cn-design';

const myconfirm = (props) => {
  return confirm({
    okProps: { children: window.ALIYUN_WIND_MESSAGE['@wind_v2.base.Dialog.ok'] },
    cancelProps: { children: window.ALIYUN_WIND_MESSAGE['@wind_v2.base.Dialog.cancel'] },
    ...props,
  });
};

export default myconfirm;
