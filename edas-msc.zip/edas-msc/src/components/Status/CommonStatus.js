import React from 'react';
import PropTypes from 'prop-types';
import Status from './index';
import { useIntl } from '@ali/widget-hooks';

const CommonStatus = ({ value, intl }) => {
  intl = intl || useIntl();
  const dataSource = [
    {
      value: false,
      type: 'disabled',
      label: intl('widget.common.closed'),
    },
    {
      value: true,
      type: 'success',
      label: intl('widget.common.opened'),
    }
  ];

  return <Status value={value} dataSource={dataSource} />;
};

CommonStatus.propTypes = {
  value: PropTypes.bool,
};

export default CommonStatus;
