import React from 'react';
import PropTypes from 'prop-types';
import Status from './index';
import { useIntl } from '@ali/widget-hooks';

const CommonStatusLine = ({ value }) => {
  const intl = useIntl();
  const dataSource = [
    {
      value: 0,
      type: 'disabled',
      label: intl('widget.common.offline'),
    },
    {
      value: 1,
      type: 'success',
      label: intl('widget.common.launch'),
    },
    {
      value: 2,
      type: 'loading',
      label: intl('widget.common.offline.loading'),
    },
    {
      value: 3,
      type: 'loading',
      label: intl('widget.common.launch.loading'),
    },
  ];

  return <Status value={value} dataSource={dataSource} />;
};

CommonStatusLine.propTypes = {
  value: PropTypes.bool,
};

export default CommonStatusLine;
