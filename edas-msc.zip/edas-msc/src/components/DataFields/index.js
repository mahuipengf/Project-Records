import React from 'react';
import DataFields from '@alicloud/console-components-data-fields';
import Truncate from '@alicloud/console-components-truncate';
import { Empty } from '@ali/cn-design';
import PropTypes from 'prop-types';
import { filter, map } from 'lodash';
import './index.less';

const DataFieldsComp = (props) => {
  const { dataSource, items, style, title } = props;

  const getItems = () => {
    const newItems = filter(items, item => !!item.visible);
    return map(newItems, item => {
      delete item.visible;
      return item.render
        ? {
          ...item,
          label: (
            <Truncate align="t" popupStyle={{ wordBreak: 'break-all' }} value={140} type="width">
              {item.label}
            </Truncate>
          )
        } : {
          ...item,
          label: (
            <Truncate align="t" popupStyle={{ wordBreak: 'break-all' }} value={140} type="width">
              {item.label}
            </Truncate>
          ),
          render: (value) => (
            <Empty value={value}>
              <span style={{ wordBreak: 'break-all' }}>{value}</span>
            </Empty>
          )
        };
    });
  };

  return (
    <React.Fragment>
      <div className="dataFields">
        <If condition={title}>
          <h4 className="common-title">{title}</h4>
        </If>
        <DataFields
          dataSource={dataSource}
          items={getItems()}
          style={{ padding: '8px 0', borderBottom: '1px solid #eee', ...style }}
        />
      </div>
    </React.Fragment>
  );
};

DataFieldsComp.propTypes = {
  dataSource: PropTypes.objectOf(PropTypes.any),
  items: PropTypes.arrayOf(PropTypes.object),
  style: PropTypes.objectOf(PropTypes.any),
  title: PropTypes.string,
};

export default DataFieldsComp;
