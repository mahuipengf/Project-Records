import { Dialog } from '@ali/cn-design';
import { useIntl } from '@ali/widget-hooks';

const DialogAlert = (props) => Dialog.alert({
  ...props,
  okProps: { children: window.ALIYUN_WIND_MESSAGE['@wind_v2.base.Dialog.ok'] },
  cancelProps: { children: window.ALIYUN_WIND_MESSAGE['@wind_v2.base.Dialog.cancel'] },
});
export default DialogAlert;
