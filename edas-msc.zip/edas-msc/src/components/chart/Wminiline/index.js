import { Wcontainer, Wminiline } from '@alife/aisc-widgets';
import React from 'react';
import { get, isEmpty, assign } from 'lodash';
import { useIntl } from '@ali/widget-hooks';
import PropTypes from 'prop-types';

const defaultOptions = {
  // symbol: true,
  tooltip: {},
  // label: {
  //   offset: 0,
  // },
  padding: [20, 20, 10, 10],
  area: true,
  colors: ['#0077cc'],
  areaColors: ['l(90) 0:#0077cc 1:#0077cc00'], // 颜色渐变
  xAxis: {
    mask: 'MM-DD HH:mm:ss',
    type: 'time',
  },
};


const Demo = (props) => {
  const { data, option, title, height, style, titleStyle, getChartInstance } = props;
  const intl = useIntl();
  const newOption = assign({}, defaultOptions, option);
  return (
    <Wcontainer
      title={title}
      titleStyle={{ padding: '8px 0', fontSize: 14, ...titleStyle }}
      style={{ padding: '0 16px', ...style }}
    >
      <div>
        <If condition={isEmpty(data)}>
          <div style={{ color: '#777', height }}>
            <div style={{ height: '100%', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div>
                <img style={{ height: 64 }} src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAABPCAMAAAAXxfH1AAAAjVBMVEUAAAC/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7++vr6/v7+/v7+/v7++vr6/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7+/v7/9y992AAAALnRSTlMABWchDPbnfMo6X8LyN7Yoo47P+e5AulVsLQnXr1oVG+qcgTOndUndvpVPx4fRwGtpZgAABClJREFUaN7t2dmSojAAheGwBFBRlIDsiCDgNuf9H29w6UrLMgViMxcz3x1dsX6BxDRKGoS1kpG/QWZwyV9R4kwm50dz0cLeET0yrSue9JhMSlSsBNAVupLJtHY7Q4ErSwKpiR1104969t9KCwoi0nD+hf4us7eWk4U5qXMxCHtrXcxPjYllo7JY97I/ArB25BOEFZAUpK+IAqePhCUdgz7NVCAQXqZsHobpGxchAyyJ9OcByvdMVqJSLoevMSAY+EYTiR/GCrDdAsmuf9FRU1XNT4CV5uqfuBnhloDyLayCuYREwKZv103QGz3susJbhKRygNmzu8EggdQRPmJPKif86tcVAeirfsJfADShPbyBbld/tLDut0OWgLkUiNAHkVMAUXvYA/Tr1QL6fZLaAB2yK4fAoT1M5rgTSY0g8XnxMnoh9M7y8TzM2euyPBSNuWvqVmi33eLtkHAEaHItzMnN/X2PG1Y0w19nEItqXW40z7gW7nOF5moCXeoMh2gK4rFhDYtquE2hdoZNtNiNDdPHtr/FujOchcftq+NKHH2pFVxvEzvAqTXcaXR4Der48QZwJg57tAoEwFGYOEyKBJVVTKYOEynfnxxCusOC44rt3EgeEeY6wht028o/GDbRTY9/MDxbBWa7QIt+7FLf+UI7n5AfDXf7H/5wuIicL3N7wvCVgWP1fWmydXyYLmwfTe3Lr9CY8B4LMvdvzGrO/xthLz9cgsXBlcaGhTAdEPbWeNI30sgwFv3DIgWnOCPCxnWN8uT2DKeoaKlzFvcKKuL74Qg3Sb/w/Db0GYtVHUDxdljwIqbNjF5hiQIBH7pUAGXEI4xcu8dZJHSE9wDNCFcwQB0xudxz7bExbg/vKJDWhqKUP7SOfTnEUm4Ni0DymskYUHwm7GuosKgtfELjie4CqB864+tWwXE1awuvgJxw/L2MCnNryO33eNFctylw+FhYDTrCYfO6boDTx8KC3/0IE9bGLoD853cnB9B35DuPAbPusPehcJwA+/qXaabQHS4ARR4X5luEU/tpZE6a4eNzaV741BsXjkuAOi/dkLSETfsmWgBIZ/ZdsRsTJjYDsPduh/4yRGXdFgajjFHcUMoelGJMmEQUADturicND6EY+bVwu8OoMFma4FYr3FyMWpgpiVVDA3to2H39JkjOA9wx0yXkUQ6k2j02pDojfuceb1/3kULdH/apLfCf/Mz45V+aBfkEBwj8P1yO+jnnj+U0XqwAOemyrZd3JaAOK/ieZ9x5nvztWFoBSD2jlXTW8WBm9z+cNYDN/SFd6cKofkfZxePHiY4Ks/RWpY4vtxHPsRdj2Ozlcn78hmEX29AYo3eMmV51bFbHffBzpjp//QCyPXuy/edxL9lZwcMh46+fRJbgTiNTs3XcBAKZ2vJ+zmcyPSO0TIe84Tfmtw84DtxGwwAAAABJRU5ErkJggg==" />
                <div>{intl('widget.common.no_data')}</div>
              </div>
            </div>
          </div>
        </If>
        <If condition={!isEmpty(data)}>
          <Wminiline getChartInstance={getChartInstance} height={height} config={newOption} data={data} />
        </If>
      </div>
    </Wcontainer>
  );
};

Demo.propTypes = {
  data: PropTypes.objectOf(PropTypes.any),
  height: PropTypes.number,
  style: PropTypes.objectOf(PropTypes.any),
  title: PropTypes.string,
  titleStyle: PropTypes.objectOf(PropTypes.any),
  option: PropTypes.objectOf(PropTypes.any),
  getChartInstance: PropTypes.func,
};

export default Demo;
