import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { forEach } from 'lodash';
import {
  Chart,
  Geom,
  Axis,
  Legend,
  Tooltip,
  Label,
} from 'bizcharts';
import { useIntl } from '@ali/widget-hooks';
import { Empty } from '@ali/cn-design';

const Interval = ({ data = [], axis = 'name', yxis = 'value', lossless = '' }) => {
  const intl = useIntl();
  const [total, setTotal] = useState(0);

  const cols = {

    [yxis]: {
      minTickInterval: 1
    }
  };

  useEffect(() => {
    let newTotal = lossless === 'lossless' ? 1 : 0;
    forEach(data, item => {
      newTotal = newTotal + item[yxis];
    });
    setTotal(newTotal);
  }, [data]);
  return (
    <React.Fragment>
      <If condition={!total}>
        <Empty showIcon />
      </If>
      <If condition={total}>
        <Chart height={lossless === 'lossless' ? 250 : 360} style={{ width: '100%' }} data={data} scale={cols} forceFit>
          <Legend position="bottom" offsetY={30} />
          <Axis name={axis} />
          <Axis
            name={yxis}
            title={{
              text: lossless === 'lossless' ? ' ' : intl('widget.home.interval_title'),
              textStyle: {
                wordWrap: 'break-word',
                fontSize: '12',
                textAlign: 'right',
                fill: '#999',
                fontWeight: 'bold',
                rotate: 270
              },
              position: 'end'
            }}
            label={{ formatter: (val) => { if (val >= 1000 && lossless === 'lossless') return `${(val / 1000).toFixed(1)}k`; else return val; } }}
          />
          <Tooltip
            showTitle={false}
            itemTpl={'<li><span style="background-color:{color};" class="g2-tooltip-marker"></span>{name}: {value}</li>'}
          />
          <Geom
            type="interval"
            position={`${axis}*${yxis}`}
            color={axis}
            size={['name', [40]]} // 可以根据数据设置柱子宽度

            style={{
              lineWidth: 1,
              radius: 10, // 可以指定圆角半径,默认为宽度一半
            }}
          >
            {/* <Label content={yxis} offset={10} /> */}
          </Geom>
        </Chart>
      </If>
    </React.Fragment>
  );
};

Interval.propTypes = {
  axis: PropTypes.string,
  yxis: PropTypes.string,
  data: PropTypes.arrayOf(PropTypes.object),
  lossless: PropTypes.string,
};

export default Interval;
