import React, { useEffect, useState } from 'react';
import Cookie from 'js-cookie';
import { forEach, isEmpty } from 'lodash';
import PropTypes from 'prop-types';
import {
  Chart,
  Geom,
  Coord,
  Tooltip,
  Guide,
  Legend,
} from 'bizcharts';
import { useIntl } from '@ali/widget-hooks';
import { Empty } from '@ali/cn-design';

const Pie = ({ data = [], axis = 'name', yxis = 'value' }) => {
  const intl = useIntl();
  const [total, setTotal] = useState(0);
  const aliyunLang = Cookie.get('aliyun_lang') || 'zh';

  const cols = {
    [yxis]: {
      formatter: val => (val = `${(val / total * 100).toFixed(1)}%`),
    },
  };

  useEffect(() => {
    let newTotal = 0;
    forEach(data, item => {
      newTotal = newTotal + item[yxis];
    });
    setTotal(newTotal);
  }, [data]);

  const getValue = (index) => {
    const item = data[index] || {};
    return (
      <div style={{ lineHeight: '22px' }}>
        <span style={{ minWidth: 60 }}>{item.value || 0}</span>
        <span style={{ color: '#999' }}>{intl('widget.common.brackets', { text: `${((item.value || 0) / total * 100).toFixed(1)}%` })}</span>
      </div>
    );
  };

  return (
    <div style={{ position: 'relative' }}>
      <If condition={!total}>
        <Empty showIcon />
      </If>
      <If condition={total}>
        <Chart
          height={360}
          data={data}
          scale={cols}
          padding="auto"
          forceFit
          onGetG2Instance={(chart) => {
            // 饼图绘制多次会导致setSelected处理不生效，延时hack一下fixed
            setTimeout(() => {
              // 设置默认选中
              const geom = (chart && chart.get('geoms') && chart.get('geoms').length) ? chart.get('geoms')[0] : {}; // 获取所有的图形
              if (isEmpty(geom)) return;
              const items = geom.get ? geom.get('data') : []; // 获取图形对应的数据
              geom.setSelected(items[1]);
            }, 2000);
          }}
        >
          <Coord type="theta" radius={0.70} innerRadius={0.55} />
          {/* <Axis name="percent" /> */}
          <Legend
            position="left-bottom"
            offsetX={aliyunLang === 'en' ? 50 : 100}
            offsetY={40}
            itemFormatter={(v) => {
              const curItem = _.filter(data, itm => (itm.name === v))[0];
              return v + '    ' + (curItem.value || 0) + '  ' + `(${((curItem.value || 0) / total * 100).toFixed(1)}%)`;
            }}
          />
          <Tooltip
            showTitle={false}
            itemTpl='<li><span style="background-color:{color};" class="g2-tooltip-marker"></span>{name}: {value}</li>'
          />
          <Geom
            type="intervalStack"
            position={yxis}
            color={axis}
            tooltip={[
              `${axis}*${yxis}`,
              (item, percent) => {
                percent = `${(percent / total * 100).toFixed(1)}%`;
                return {
                  name: item,
                  value: percent,
                };
              },
            ]}
            style={{
              lineWidth: 1,
              stroke: '#fff',
            }}
          />
          <Guide>
            <Guide.Html
              position={['50%', '50%']}
              html={`<div style='text-align: center'><div style='color:#555;font-size:28px; margin-bottom: 8'>${total}</div><div>${intl('widget.home.pie_total_count')}</div></div>`}
              alignX="middle"
              alignY="middle"
            />
          </Guide>
        </Chart>
        {/* <div style={{ position: 'absolute', right: `${aliyunLang === 'en' ? '50px' : '100px'}`, bottom: 4 }}>
          {getValue(0)}
          {getValue(1)}
          {getValue(2)}
        </div> */}
      </If>
    </div >
  );
};

Pie.propTypes = {
  axis: PropTypes.string,
  yxis: PropTypes.string,
  data: PropTypes.arrayOf(PropTypes.object),
};

export default Pie;
