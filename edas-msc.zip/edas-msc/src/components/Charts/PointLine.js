import React, { useEffect, useState, useRef, createRef } from 'react';
import { forEach, isEmpty } from 'lodash';
import PropTypes from 'prop-types';
// import {
//   Chart,
//   Geom,
//   Coord,
//   Tooltip,
//   Guide,
//   Legend,
// } from 'bizcharts';
import { useIntl } from '@ali/widget-hooks';
import { Wcontainer, Wline } from '@alife/aisc-widgets';
import { registerShape, Chart } from '@antv/g2';
import { Empty } from '@ali/cn-design';

// { data = [], axis = 'name', yxis = 'value' }
const PointLine = ({ data }) => {
  const intl = useIntl();
  const [total, setTotal] = useState(0);
  const chartRef = createRef();
  // const cols = {
  //   [yxis]: {
  //     formatter: val => (val = `${(val / total * 100).toFixed(1)}%`),
  //   },
  // };

  return (
    <div style={{ position: 'relative' }}>
      {/* <Wline
        // event={chartEvent}
        // config={options}
        height={300}
        data={data}
        ref={chartRef}
      /> */}
      <Wline
        height={200}
        // config={options}
        data={data}
        key={data}
        ref={chartRef}
        // getChartInstance={(c) => (chart1 = c)}
      />
    </div >
  );
};

PointLine.propTypes = {
  // axis: PropTypes.string,
  // yxis: PropTypes.string,
  // data: PropTypes.arrayOf(PropTypes.object),
};

export default PointLine;
