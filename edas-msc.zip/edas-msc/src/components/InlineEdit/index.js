import React, { useState, forwardRef, useEffect } from 'react';
import { Input, Balloon, Icon } from '@ali/cn-design';
import StatusIndicator from '@alicloud/console-components-status-indicator';
import styles from './index.less';

const InlineEdit = forwardRef((props, ref) => {
	const [edit, setEdit] = useState(false);
	const [showError, setShowError] = useState(false);
	const [showValue, setShowValue] = useState(); // 展示的内容
	const [inputValue, setInputValue] = useState(); // 输入框的值
	const {
		value,
		defaultValue,
		onChange,
		onConfirm,
		name,
		error,
		errInterval,
		errAlign = 'l',
		...restProps
	} = props;

	const getError = () => {
		return error && error.errors && error.errors[0];
	};

	const getValue = () => {
		if (value !== undefined) {
			return value;
		}
		return defaultValue;
	};
	const confirm = () => {
		console.log('props=', props);
		setShowValue(inputValue);
		setShowError(false);
		onConfirm && onConfirm(inputValue, props);
		setEdit(false);
	};

	useEffect(() => {
		const v = getValue();
		setShowValue(v);
		setInputValue(v);
	}, [value, defaultValue]);

	useEffect(() => {
		setShowError(!!error);
		if (error) {
			setTimeout(() => {
				setShowError(false);
			}, errInterval || 3000);
		}
	}, [error]);

	const handleChange = (e) => {
		setInputValue(e);
		onChange && onChange(e);
	};

	const mainContent = (
		<div className={styles["inline-edit"]}>
			{edit ? (
				<>
					<Input
						size="small"
						onChange={handleChange}
						defaultValue={showValue || ''}
						name={name}
						autoFocus={true}
						{...restProps}
						ref={ref}
					/>
					<span>
						<Icon
							onClick={confirm}
							type="select"
							size="xs"
							onChange={handleChange}
						/>
						<Icon
							onClick={() => setEdit(false)}
							type="times"
							size="xs"
						/>
					</span>
				</>
			) : (
					<>
						<span className={styles["span-value"]}>{showValue}</span>
						<Input
							{...restProps}
							htmlType="hidden"
							name={name}
							ref={ref}
							value={showValue}
						/>
						<Icon
							onClick={() => setEdit(true)}
							style={{ cursor: 'pointer' }}
							type="edit"
							size="xs"
						/>
					</>
				)}
		</div>
	);
	return (
		<Balloon visible={showError} trigger={mainContent} align={errAlign}>
			<StatusIndicator className={styles["balloon-error-msg"]} type="error">
				{getError()}
			</StatusIndicator>
		</Balloon>
	);
});
export default InlineEdit;
