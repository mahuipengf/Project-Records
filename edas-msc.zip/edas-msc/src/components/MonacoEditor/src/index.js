import MonacoEditor from './editor';
import MonacoDiffEditor from './diff';

export { MonacoEditor as default, MonacoDiffEditor };
