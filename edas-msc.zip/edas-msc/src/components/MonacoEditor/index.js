import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Icon } from '@ali/cn-design';
import Dialog from 'components/Dialog';
import { isEmpty } from 'utils';
import { useIntl } from '@ali/widget-hooks';
import MonacoEditor, { MonacoDiffEditor } from './src';

// monaco初始化的时候，编辑器的状态不能是display为none，解法也只能是等到需要显示时才初始化
const Editor = props => {
  const intl = useIntl();
  const {
    value: propsValue,
    title = intl('widget.common.monaco_title'),
    language = 'plaintext',
    height = 300,
    width = 600,
    isEnableMaximize = true,
    theme = 'vs-dark',
    readOnly = false,
    renderSideBySide = true,
    originValue = null,
    minimap = true,
  } = props;
  const [value, setValue] = useState(propsValue);
  const [visible, setVisible] = useState(false);

  const options = {
    selectOnLineNumbers: true,
    readOnly,
    renderSideBySide,
    minimap: {
      enabled: minimap
    },
  };

  const editorDidMount = editor => {
    editor.focus();
  };
  const onChange = newValue => {
    setValue(newValue);
    props.onChange(newValue);
  };
  const toggleDialog = () => {
    setVisible(!visible);
  };

  useEffect(() => {
    if (value !== propsValue) {
      setValue(propsValue);
    }
  }, [propsValue]);

  return (
    <div style={{ position: 'relative' }}>
      <If condition={isEmpty(originValue)}>
        <If condition={isEnableMaximize}>
          <Icon
            type="expand-arrows-alt"
            onClick={toggleDialog}
            style={{ position: 'absolute', top: 0, right: 0, color: '#fff', zIndex: 2 }}
          />
        </If>
        <MonacoEditor
          width={width}
          height={height}
          language={language}
          theme={theme}
          value={value}
          options={options}
          onChange={onChange}
          editorDidMount={editorDidMount}
        />
      </If>
      <If condition={!isEmpty(originValue)}>
        <MonacoDiffEditor
          width={width}
          height={height}
          language={language}
          theme={theme}
          original={originValue}
          value={value}
          options={options}
        />
      </If>
      <Dialog title={title} visible={visible} onClose={toggleDialog} isFullScreen shouldUpdatePosition footer={false}>
        <MonacoEditor
          width="1000px"
          height="600px"
          language={language}
          theme={theme}
          value={value}
          onChange={onChange}
          options={options}
          editorDidMount={editorDidMount}
        />
      </Dialog>
    </div>
  );
};

Editor.propTypes = {
  readOnly: PropTypes.bool,
  title: PropTypes.string,
  value: PropTypes.string,
  onChange: PropTypes.func,
  language: PropTypes.string,
  height: PropTypes.number,
  width: PropTypes.number,
  isEnableMaximize: PropTypes.bool,
  theme: PropTypes.string,
  originValue: PropTypes.string,
  renderSideBySide: PropTypes.bool,
  minimap: PropTypes.bool,
};

export default Editor;
