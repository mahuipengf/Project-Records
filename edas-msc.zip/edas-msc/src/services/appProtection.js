import { BaseModel, dvaModel, reducer } from '@ali/sre-utils-dva';

const DEFAULT_STATE = {
  applicationProtection: {
    protecList: [],
    totalCount: 0,
  },
  keyStatisticsOnNode: {
    TotalCount: 0,
    Metrics: [],
  },
  apiDetails: {
    activeResourceName: '_all',
    favorite: false,
    hasRule: false,
    type: 0,
  },
  HotKey: '',
  machineDetails: {
    privateIp: '_all',
    parentIp: '',
    pid: -1,
    processConfigurationId: '',
    vpcId: '',
    resource: '',
  },
  apiShowTime: {
    backTime: undefined,
    statisticsEndTime: undefined,
  },
  resourceType: 1,
  machineAllType: 0,
  machineJvmAllType: 0,
  appVersion: {},
  showModelstype: true,
  systemGuardPageType: 'pageApp',
  sortDesc: {
    sortIndex: 0,
    descType: true,
  },
  fullScreen: {
    fullScreenApi: false,
    fullScreenMac: false,
  },

  chartsFilter: [
    '通过QPS',
    '拒绝QPS',
    '异常QPS',
    '等待IO完成的CPU使用率',
    '系统CPU使用率',
    '用户CPU使用率',
    'Load',
    '系统BufferCache内存量',
    '系统PageCache内存量',
    '系统空闲内存量',
    '已使用内存量',
    '磁盘空闲量',
    '磁盘使用量',
    '网络接收流量大小',
    '网络发送流量大小',
    '网络丢弃报文数',
    '网络接收的错误数',
    '网络接收的报文数',
    '网络发送的报文数',
    'FullGC次数',
    'YoungGC次数',
    'FullGC耗时',
    'YoungGC耗时',
    '使用总和',
    '年轻代Eden区',
    '老年代',
    '年轻代Survivor区',
    '元空间',
    '阻塞线程数',
    '总和',
    '死锁线程数',
    '新建线程数',
    'Runnable的线程数',
    '终结线程数',
    'Timed_Waiting的线程数',
    'Waiting的线程数',
    '非堆内存commit字节数',
    '非堆内存init字节数',
    '非堆内存使用字节数',
    '总量',
  ],
  exceptionTime: 0,
  protectionSceneDataStepOne: JSON.stringify(''), // 防护管理-Step1-防护场景数据
  flowRuleOptionsDataStepTwo: JSON.stringify(''), // 防护管理-Step2-防护规则数据
  actionDataStepThree: JSON.stringify(''), // 防护管理-Step3-限流行为数据
  alarmRulesDataStepFour: JSON.stringify(''), // 防护管理-Step4-告警规则数据
  activeClusterName: '_all',
  activeHotSpotName: '',
  activeHotSpotDetails: '',
};

@dvaModel('flowAppModel')
class FlowAppModel extends BaseModel {
  state = DEFAULT_STATE;

  @reducer
  clear(key) {
    if (!key) {
      return {
        ...DEFAULT_STATE,
      };
    }
    return {
      ...this.state,
      [key]: DEFAULT_STATE[key],
    };
  }

  @reducer
  setApiActiveName(payload) {
    return {
      ...this.state,
      apiDetails: {
        activeResourceName: payload.activeResourceName,
        favorite: payload.favorite,
        hasRule: payload.hasRule,
        type: payload.type,
      },
    };
  }

  @reducer
  setMachineActiveName(payload) {
    return {
      ...this.state,
      machineDetails: {
        privateIp: payload.privateIp,
        parentIp: payload.parentIp,
        pid: payload.pid,
        processConfigurationId: payload.processConfigurationId,
        vpcId: payload.vpcId,
        resource: payload.resource,
      },
    };
  }

  @reducer
  setApiShowTime(payload) {
    return {
      ...this.state,
      apiShowTime: {
        backTime: payload.backTime,
        statisticsEndTime: payload.statisticsEndTime,
      },
    };
  }

  @reducer
  setResourceType(payload) {
    return {
      ...this.state,
      resourceType: payload,
    };
  }

  @reducer
  setMachineAllType(payload) {
    return {
      ...this.state,
      machineAllType: payload,
    };
  }

  @reducer
  keyStatisticsOnNode(payload) {
    return {
      ...this.state,
      keyStatisticsOnNode: payload,
    };
  }
  @reducer
  setHotKey(payload) {
    return {
      ...this.state,
      HotKey: payload,
    };
  }
  @reducer
  setMachineJvmAllType(payload) {
    return {
      ...this.state,
      machineJvmAllType: payload,
    };
  }

  @reducer
  setAppVersion(payload) {
    return {
      ...this.state,
      appVersion: payload,
    };
  }

  @reducer
  setShowModelstype(payload) {
    return {
      ...this.state,
      showModelstype: payload,
    };
  }

  @reducer
  setSystemGuardPageType(payload) {
    return {
      ...this.state,
      systemGuardPageType: payload,
    };
  }

  @reducer
  setSortDesc(payload) {
    return {
      ...this.state,
      sortDesc: {
        sortIndex: payload.sortIndex,
        descType: payload.descType,
      },
    };
  }

  @reducer
  setFullScreen(payload) {
    return {
      ...this.state,
      fullScreen: {
        fullScreenApi: payload.fullScreenApi,
        fullScreenMac: payload.fullScreenMac,
      },
    };
  }

  @reducer
  setChartsFilter(payload) {
    return {
      ...this.state,
      chartsFilter: payload,
    };
  }

  @reducer
  setExceptionTime(payload) {
    return {
      ...this.state,
      exceptionTime: payload,
    };
  }

  @reducer
  setProtectionSceneDataStepOne(payload) {
    return {
      ...this.state,
      protectionSceneDataStepOne: payload,
    };
  }

  @reducer
  setFlowRuleOptionsDataStepTwo(payload) {
    return {
      ...this.state,
      flowRuleOptionsDataStepTwo: payload,
    };
  }

  @reducer
  setActionDataStepThree(payload) {
    return {
      ...this.state,
      actionDataStepThree: payload,
    };
  }

  @reducer
  setAlarmRulesDataStepFour(payload) {
    return {
      ...this.state,
      alarmRulesDataStepFour: payload,
    };
  }

  @reducer
  setClusterActiveName(payload) {
    return {
      ...this.state,
      activeClusterName: payload,
    };
  }

  @reducer
  setActiveHotSpotName(payload) {
    return {
      ...this.state,
      activeHotSpotName: payload,
    };
  }

  @reducer
  setActiveHotSpotDetails(payload) {
    return {
      ...this.state,
      activeHotSpotDetails: payload,
    };
  }
}

export default new FlowAppModel().model;

declare global {
  interface Actions {
    flowAppModel: FlowAppModel;
  }
}
