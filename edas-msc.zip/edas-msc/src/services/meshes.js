import { customRequest } from '@ali/cn-design';
import { restfulAPI } from "./restfulAPI";

const meshRequest = customRequest();

const SERVICE = {
	getTrafficPolicies:
		'/sp/api/istiorule/meshes/{serviceMeshId}/namespaces/{k8snamespace}/services/{serviceName}/trafficpolicies', // 获取流量治理信息
	postTrafficPolicies: '/sp/api/istiorule/meshes/namespaces/services/trafficpolicies',
}

export const getTrafficPolicies = async (params) => {
	const { restUrl, data } = restfulAPI(SERVICE.getTrafficPolicies, params);
	return meshRequest({
		url: restUrl
	})({
		params: data
	});
};

export const updateTrafficPolicies = async (params) => {
	const { restUrl, data } = restfulAPI(SERVICE.postTrafficPolicies, params);
	return meshRequest({
		url: restUrl,
		method: 'post',
		headers: {
			'Content-Type': 'application/json'
		},
	})({
		data
	});
};