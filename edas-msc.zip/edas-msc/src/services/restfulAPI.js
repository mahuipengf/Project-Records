export const restfulAPI = function (url, formData) {
	if (typeof formData === 'string') {
		return { restUrl: url, data: formData };
	}
	const newFormData = Array.isArray(formData)
		? [...formData]
		: { ...formData };
	if (!url) throw new Error('url不能为空');
	if (url.indexOf('{') === -1 || !formData)
		return { restUrl: url, data: newFormData };
	let restfulArray = url.split('/');
	const result = restfulArray.map((item) => {
		if (item.indexOf('{') !== -1) {
			const key = item.substring(1, item.length - 1);
			delete newFormData[key];
			return formData[key] || '';
		}
		return item;
	});
	return { restUrl: result.join('/'), data: newFormData };
};
