/**
 * product // pop接口参数
 * action // pop接口参数
 * method // 默认get，如果是get接口，可以省略
 * url // 非pop接口请求路径
 */
import newRequest from './newService';
import axios from './axios';
// import model from './model';

const GetOverview = newRequest({ //  获取概览
  action: 'GetOverview',
});

const fetchAuthenticationList = newRequest({
  url: '/sp/api/mse/fetchPolicyList', // 服务鉴权列表
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  },
  action: 'ListAuthPolicy',
});

const addAuthentication = newRequest({ //  添加服务鉴权
  url: '/sp/api/mse/addPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  },
  action: 'AddAuthPolicy',
});

const fetchAuthenticationInfo = newRequest({ // 获取鉴权详情
  url: '/sp/api/mse/getPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  },
  action: 'GetAuthPolicyInfo',
});

const updateAuthentication = newRequest({ // 更新服务鉴权
  url: '/sp/api/mse/updatePolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  },
  action: 'UpdateAuthPolicy'
});

const removeAuthentication = newRequest({ // 删除鉴权
  url: '/sp/api/mse/removePolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  },
  action: 'RemoveAuthPolicy'
});

const fetchRegions = newRequest({
  url: '/sp/api/dev/outlier/regions'
});

const fetchNamespaces = newRequest({
  url: '/sp/api/dev/outlier/namespaces'
});

const GetAppList = newRequest({ // 获取应用列表
  action: 'GetApplicationList',
  url: '/sp/applications',
});

const GetApplicationDetail = newRequest({ // 获取应用详情
  action: 'GetApplicationDetail',
});

const GetApplicationInstances = newRequest({ // 应用实例
  action: 'GetApplicationInstanceList',
  url: '/sp/api/route/getInstances',
});

const ListApplicationTagInstancese = newRequest({ // 应用实例
  action: 'ListApplicationTagInstancese',
  url: '/sp/api/route/getTagInstance',
});

const GetApplicationCanaryInstances = newRequest({
  action: 'GetApplicationCanaryInstances',
});

const getRoutePolicy = newRequest({ // 路由应用的路由获取详情
  action: 'GetRoutePolicy',
  url: '/sp/api/route/getPolicy',
});

const getRoutePolicyList = newRequest({ // 路由应用的动态路由列表
  action: 'FetchRoutePolicyList',
  url: '/sp/api/route/fetchPolicyList',
});

const getCanaryPolicy = newRequest({ // 根据appId获取金丝雀详情
  action: 'GetCanaryPolicy',
});

const updateRoutePolicy = newRequest({ // 修改路由
  action: 'UpdateRoutePolicy',
  url: '/sp/api/route/updatePolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const getServiceList = newRequest({
  url: '/sp/api/mse/getServiceList',
  method: 'post',
  action: 'GetServiceList'
});

const CheckAuthPolicyName = newRequest({ // 校验服务鉴权名称
  url: '/sp/api/mse/checkPolicyName',
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  },
  action: 'CheckAuthPolicyName',
});

const getEcsMarkdown = axios({
  url: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/install_package/edasmsc-ecs.md',
});
const getAcsMarkdown = axios({
  url: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/install_package/edasmsc-ack.md',
});
const getEdasMarkdown = axios({
  url: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/install_package/edasmsc-edas.md',
});

const getlosslessMarkdown = axios({
  url: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/install_package/edasmsc-graceful-shutdown.md',
});

const fetchServicesList = newRequest({ // 服务查询列表
  url: '/sp/api/mse/getServiceListPage',
  method: 'post',
  action: 'GetServiceListPage',
});

const fetchHsfDetail = newRequest({ // hsf服务基本信息
  url: '/json/v5/mst/hsfServiceInfo.json',
  method: 'get',
  action: 'GetHsfDetail'
});

const fetchServiceBasicInfo = newRequest({ // 服务查询基本信息
  url: '/sp/api/mse/getServiceDetail',
  method: 'post',
  action: 'GetServiceDetail',
});

const fetchServiceProvidersPage = newRequest({ // 服务提供者
  url: '/sp/api/mse/getServiceProvidersPage',
  method: 'post',
  action: 'GetServiceProvidersPage'
});

const fetchServiceConsumersPage = newRequest({ // 服务消费者
  url: '/sp/api/mse/getServiceConsumersPage',
  method: 'post',
  action: 'GetServiceConsumersPage'
});

const fetchOutlierEjectionList = newRequest({ // 获取策略列表
  url: '/sp/api/dev/outlier/fetchPolicyList',
  action: 'ListOutlierPolicy',
});

const updateOutlierEjectionConfig = newRequest({ // 修改策略
  url: '/sp/api/dev/outlier/updatePolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
  action: 'UpdateOutlierConfig',
});

const removeOutlierEjection = newRequest({ // 删除策略
  url: '/sp/api/dev/outlier/removePolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
  action: 'RemoveOutlierPolicy',
});

const fetchApplicationsByRpcType = newRequest({ // 获取应用
  url: '/sp/api/dev/outlier/fetchAppList',
  action: 'GetOutlierApplicationList',
});

const addOutlierEjection = newRequest({ // 创建策略
  url: '/sp/api/dev/outlier/addPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
  action: 'CreateOutlierConfig',
});

const deleteRoutePolicy = newRequest({ // 删除路由规则
  action: 'RemoveRoutePolicy',
  url: '/sp/api/route/removePolicy',
  method: 'post',
});

const addRoutePolicy = newRequest({ // 创建路由规则
  action: 'AddRoutePolicy',
  url: '/sp/api/route/addPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const GetApplicationTags = newRequest({ // 获取应用标签列表
  action: 'GetApplicationTagList',
  url: '/sp/api/route/getTags',
});

const ListEventsPage = newRequest({
  action: 'ListEventsPage',
});

const getServiceTestLink = newRequest({ // 服务压测
  url: 'sp/api/mse/getServiceTestLink',
});

const GetDubboTestMethod = newRequest({
  url: '/sp/api/mse/test/dubbo/method',
  action: 'GetDubboTestMethod',
  product: 'mse',
});

const GetIstioTestMethod = newRequest({
  url: '/sp/api/mse/test/istio/method',
  action: 'GetIstioTestMethod',
  product: 'mse',
});

const GetSpringCloudTestMethod = newRequest({
  url: '/sp/api/mse/test/springcloud/method',
  action: 'GetSpringCloudTestMethod',
  product: 'mse',
});

const postDubboParams = newRequest({
  url: '/sp/api/mse/test/dubbo/invoke',
  method: 'post',
  action: 'InvokeDubboTestMethod',
  product: 'mse',
});

const postSCParams = newRequest({
  url: '/sp/api/mse/test/springcloud/invoke',
  method: 'post',
  action: 'InvokeSpringCloudTestMethod',
  product: 'mse',
});

const InvokeIstioTestMethod = newRequest({
  url: '/sp/api/mse/test/istio/invoke',
  method: 'post',
  action: 'InvokeIstioTestMethod',
  product: 'mse',
});

const getServiceMethodPage = newRequest({
  url: '/sp/api/mse/getServiceMethodPage',
  method: 'post',
  action: 'GetServiceMethodPage',
});

const getServiceMethodList = newRequest({
  url: '/sp/api/mse/getServiceMethodList',
  method: 'post',
  action: 'GetServiceMethodList',
});

const fetchArms = newRequest({
  url: '/api/version.json',
  method: 'post',
});

const GetAccountMockRule = newRequest({
  action: 'GetAccountMockRule'
});

const GetMockRuleByConsumerAppId = newRequest({
  action: 'GetMockRuleByConsumerAppId'
});

const AddMockRule = newRequest({
  action: 'AddMockRule',
  method: 'post',
});

const UpdateMockRule = newRequest({
  action: 'UpdateMockRule',
  method: 'post',
});

const EnableMockRule = newRequest({
  action: 'EnableMockRule',
});

const DisableMockRule = newRequest({
  action: 'DisableMockRule',
});

const RemoveMockRule = newRequest({
  action: 'RemoveMockRule',
});

const RemoveApplication = newRequest({
  action: 'RemoveApplication'
});

const GetMockRuleById = newRequest({
  action: 'GetMockRuleById',
});

const GetMockRuleByProviderAppId = newRequest({
  action: 'GetMockRuleByProviderAppId',
});

const CreateLicenseKey = newRequest({
  action: 'CreateLicenseKey',
});

const GetCanaryStatus = newRequest({
  action: 'GetCanaryStatus',
});

const ApplyCanaryPolicy = newRequest({
  action: 'ApplyCanaryPolicy',
  method: 'post',
});
const QueryServiceTimeConfig = newRequest({
  action: 'QueryServiceTimeConfig',
  method: 'post',
});

const AddServiceTimeConfig = newRequest({
  action: 'AddServiceTimeConfig',
  method: 'post',
});

const DeleteServiceTimeConfig = newRequest({
  action: 'DeleteServiceTimeConfig',
  method: 'post',
});

const ListApplicationsWithTagRules = newRequest({
  action: 'ListApplicationsWithTagRules',
});

const ApplyTagPolicies = newRequest({
  action: 'ApplyTagPolicies',
  method: 'post',
});

const fetchFaultInjectionPolicy = newRequest({ // 故障注入列表
  url: '/sp/api/route/fetchFaultInjectionPolicy',
  method: 'get',
});

const addFaultInjectionPolicy = newRequest({ //  添加故障注入
  url: '/sp/api/route/addFaultInjectionPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  },
});

const updateFaultInjectionPolicy = newRequest({ // 更新故障注入
  url: '/sp/api/route/updateFaultInjectionPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  }
});

const removeFaultInjectionPolicy = newRequest({ // 删除故障注入
  url: '/sp/api/route/removeFaultInjectionPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  }
});

const fetchServiceRetryPolicyList = newRequest({
  url: '/sp/api/route/fetchRetryPolicy'
});

const updateServiceRetryPolicy = newRequest({
  url: '/sp/api/route/updateRetryPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const removeServiceRetryPolicy = newRequest({
  url: '/sp/api/route/removeRetryPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const addServiceRetryPolicy = newRequest({
  url: '/sp/api/route/addRetryPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const fetchServiceTimeoutPolicyList = newRequest({
  url: '/sp/api/route/fetchTimeoutPolicy'
});

const updateServiceTimeoutPolicy = newRequest({
  url: '/sp/api/route/updateTimeoutPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const removeServiceTimeoutPolicy = newRequest({
  url: '/sp/api/route/removeTimeoutPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const addServiceTimeoutPolicy = newRequest({
  url: '/sp/api/route/addTimeoutPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const fetchLoadBalancePolicyList = newRequest({
  url: '/sp/api/mse/fetchLbPolicyList',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const addLoadBalancePolicy = newRequest({
  url: '/sp/api/mse/addLbPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const updateLoadBalancePolicy = newRequest({
  url: '/sp/api/mse/updateLbConfig',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const removeLoadBalancePolicy = newRequest({
  url: '/sp/api/mse/removeLbPolicy',
  method: 'post',
  headers: {
    'Content-Type': 'application/json',
  },
});

const fetchTestHistorys = newRequest({
  action: 'GetHistorys',
  product: 'mst',
});

const RunServiceTest = newRequest({
  action: 'RunServiceTest',
  product: 'mst'
});

const ListKubernetesNamespace = newRequest({
  action: 'ListKubernetesNamespace',
});

const GetGovernanceKubernetesClusterList = newRequest({
  action: 'GetGovernanceKubernetesClusterList',
});

const GetGovernanceKubernetesCluster = newRequest({
  action: 'GetGovernanceKubernetesCluster',
});

const ModifyGovernanceKubernetesCluster = newRequest({
  action: 'ModifyGovernanceKubernetesCluster',
});

const GetUserStatus = newRequest({
  action: 'GetUserStatus',
});

const SetUserStatus = newRequest({
  action: 'SetUserStatus',
});

const ListCommunites = newRequest({
  action: 'ListCommunites'
});

const ListLoadBalancePolicy = newRequest({
  action: 'ListLoadBalancePolicy',
});

const AddLoadBalancePolicy = newRequest({
  action: 'AddLoadBalancePolicy',
});

const UpdateLoadBalanceConfig = newRequest({
  action: 'UpdateLoadBalanceConfig',
});

const RemoveLoadBalancePolicy = newRequest({
  action: 'RemoveLoadBalancePolicy',
});

const GetLoadBalancePolicyInfo = newRequest({
  action: 'GetLoadBalancePolicyInfo',
});

const GetLocalityRule = newRequest({
  action: 'GetLocalityRule',
});

const UpdateLocalityRule = newRequest({
  action: 'UpdateLocalityRule'
});

const GetFaultInjectionRule = newRequest({
  action: 'GetFaultInjectionRule'
});
const DeleteFaultInjectionRule = newRequest({
  action: 'DeleteFaultInjectionRule'
});
const UpdateFaultInjectionRule = newRequest({
  action: 'UpdateFaultInjectionRule'
});
const CreateFaultInjectionRule = newRequest({
  action: 'CreateFaultInjectionRule'
});
const CreateTimeoutRule = newRequest({
  action: 'CreateTimeoutRule'
});
const DeleteTimeoutRule = newRequest({
  action: 'DeleteTimeoutRule'
});
const UpdateTimeoutRule = newRequest({
  action: 'UpdateTimeoutRule'
});
const GetTimeoutRule = newRequest({
  action: 'GetTimeoutRule'
});
const CreateRetryRule = newRequest({
  action: 'CreateRetryRule'
});
const DeleteRetryRule = newRequest({
  action: 'DeleteRetryRule'
});
const UpdateRetryRule = newRequest({
  action: 'UpdateRetryRule'
});
const GetRetryRule = newRequest({
  action: 'GetRetryRule'
});
const QueryAppSummaryMetricsOverview = newRequest({
  action: 'QueryAppSummaryMetricsOverview',
});
const QueryAppMethodMetrics = newRequest({
  action: 'QueryAppMethodMetrics',
});
const QueryAppTopNMacs = newRequest({
  action: 'QueryAppTopNMacs',
});
const QueryAppRPCMacMetrics = newRequest({
  action: 'QueryAppRPCMacMetrics'
});
const RevertApplicationRoutePolicy = newRequest({
  action: 'RevertApplicationRoutePolicy'
});
const FetchLosslessRuleList = newRequest({
  action: 'FetchLosslessRuleList'
});
const GetAppMessageQueueRoute = newRequest({
  action: 'GetAppMessageQueueRoute'
});
const UpdateMessageQueueRoute = newRequest({
  action: 'UpdateMessageQueueRoute'
});
const CreateOrUpdateSwimmingLaneGroup = newRequest({
  action: 'CreateOrUpdateSwimmingLaneGroup'
});
const QueryAllSwimmingLaneGroup = newRequest({
  action: 'QueryAllSwimmingLaneGroup'
});
const QueryAllSwimmingLane = newRequest({
  action: 'QueryAllSwimmingLane'
});
const GetTagsBySwimmingLaneGroupId = newRequest({
  action: 'GetTagsBySwimmingLaneGroupId'
});
const CreateOrUpdateSwimmingLane = newRequest({
  action: 'CreateOrUpdateSwimmingLane'
});
const ListAppBySwimmingLaneGroupTag = newRequest({
  action: 'ListAppBySwimmingLaneGroupTag'
});
const RemoveApplications = newRequest({
  action: 'RemoveApplications'
});
const ModifyLosslessRule = newRequest({
  action: 'ModifyLosslessRule'
});
const QueryEventOverview = newRequest({
  action: 'QueryEventOverview'
});
const DeleteSwimmingLane = newRequest({
  action: 'DeleteSwimmingLane'
});
const DeleteSwimmingLaneGroup = newRequest({
  action: 'DeleteSwimmingLaneGroup'
});
const QueryAppListMetrics = newRequest({
  action: 'QueryAppListMetrics'
});
const DeleteGovernanceKubernetesCluster = newRequest({
  action: 'DeleteGovernanceKubernetesCluster'
});
const QueryGovernanceKubernetesCluster = newRequest({
  action: 'QueryGovernanceKubernetesCluster'
});
const UpdateInstanceRegisterStatus = newRequest({
  action: 'UpdateInstanceRegisterStatus'
});
const GetResourcePackageStatus = newRequest({
  action: 'GetResourcePackageStatus'
});
const QueryEmptyPushSetting = newRequest({
  action: 'QueryEmptyPushSetting'
});
const CreateOrUpdateEmptyPushSetting = newRequest({
  action: 'CreateOrUpdateEmptyPushSetting'
});

const QuerySentinelAppSummaryMetricOverview = newRequest({
  action: 'QuerySentinelAppSummaryMetricOverview',
  method: 'post',
  product: 'ahas',
});
const QuerySentinelMetricsOfResource = newRequest({
  action: 'QuerySentinelMetricsOfResource',
  method: 'post',
  product: 'ahas',
});
const QuerySentinelMacMetricsOfResource = newRequest({
  action: 'QuerySentinelMacMetricsOfResource',
  method: 'post',
  product: 'ahas',
});
const QuerySystemResourceMetricOfGroup = newRequest({
  action: 'QuerySystemResourceMetricOfGroup',
  method: 'post',
  product: 'ahas',
});
const QuerySystemResourceMetricOfGroupOnNode = newRequest({
  action: 'QuerySystemResourceMetricOfGroupOnNode',
  method: 'post',
  product: 'ahas',
});
const QuerySystemStatResourceMetricOfResource = newRequest({
  action: 'QuerySystemStatResourceMetricOfResource',
  method: 'post',
  product: 'ahas',
});
const SentinelGetModelList = newRequest({
  action: 'SentinelGetModelList',
  method: 'post',
  product: 'ahas',
});
const GetClusterDetail = newRequest({
  action: 'GetClusterDetail',
  method: 'post',
  product: 'ahas',
});
const SentinelFlowRuleListByPage = newRequest({
  action: 'SentinelFlowRuleListByPage',
  method: 'post',
  product: 'ahas',
});
const SentinelFlowRuleOnBatch = newRequest({
  action: 'SentinelFlowRuleOnBatch',
  method: 'post',
  product: 'ahas',
});
const SentinelFlowRuleOffBatch = newRequest({
  action: 'SentinelFlowRuleOffBatch',
  method: 'post',
  product: 'ahas',
});
const SentinelFlowRuleDelete = newRequest({
  action: 'SentinelFlowRuleDelete',
  method: 'post',
  product: 'ahas',
});
const SentinelDegradeRuleListByPage = newRequest({
  action: 'SentinelDegradeRuleListByPage',
  method: 'post',
  product: 'ahas',
});
const ListSentinelAllDefaultCircuitBreakerRule = newRequest({
  action: 'ListSentinelAllDefaultCircuitBreakerRule',
  method: 'post',
  product: 'ahas',
});
const DeleteSentinelDefaultCircuitBreakerRule = newRequest({
  action: 'DeleteSentinelDefaultCircuitBreakerRule',
  method: 'post',
  product: 'ahas',
});
const SentinelDegradeRuleDelete = newRequest({
  action: 'SentinelDegradeRuleDelete',
  method: 'post',
  product: 'ahas',
});

const EnableSentinelDefaulCircuitBreakerRule = newRequest({
  action: 'EnableSentinelDefaulCircuitBreakerRule',
  method: 'post',
  product: 'ahas',
});
const DisableSentinelDefaultCircuitBreakerRule = newRequest({
  action: 'DisableSentinelDefaultCircuitBreakerRule',
  method: 'post',
  product: 'ahas',
});
const SentinelDegradeRuleOnBatch = newRequest({
  action: 'SentinelDegradeRuleOnBatch',
  method: 'post',
  product: 'ahas',
});
const SentinelDegradeRuleOffBatch = newRequest({
  action: 'SentinelDegradeRuleOffBatch',
  method: 'post',
  product: 'ahas',
});
const GetSentinelClientVersionOfApp = newRequest({
  action: 'GetSentinelClientVersionOfApp',
  method: 'post',
  product: 'ahas',
});
const ListSentinelManualDegradeRulesByPage = newRequest({
  action: 'ListSentinelManualDegradeRulesByPage',
  method: 'post',
  product: 'ahas',
});
const DeleteSentinelManualDegradeRule = newRequest({
  action: 'DeleteSentinelManualDegradeRule',
  method: 'post',
  product: 'ahas',
});
const BatchEnableSentinelManualDegradeRules = newRequest({
  action: 'BatchEnableSentinelManualDegradeRules',
  method: 'post',
  product: 'ahas',
});
const BatchDisableSentinelManualDegradeRules = newRequest({
  action: 'BatchDisableSentinelManualDegradeRules',
  method: 'post',
  product: 'ahas',
});
const SentinelParamRuleListByPage = newRequest({
  action: 'SentinelParamRuleListByPage',
  method: 'post',
  product: 'ahas',
});
const SentinelHotParamRuleDelete = newRequest({
  action: 'SentinelHotParamRuleDelete',
  method: 'post',
  product: 'ahas',
});
const SentinelHotParamRuleOnBatch = newRequest({
  action: 'SentinelHotParamRuleOnBatch',
  method: 'post',
  product: 'ahas',
});
const SentinelHotParamRuleOffBatch = newRequest({
  action: 'SentinelHotParamRuleOffBatch',
  method: 'post',
  product: 'ahas',
});
const SentinelGatewayApiDefinitionsListForApp = newRequest({
  action: 'SentinelGatewayApiDefinitionsListForApp',
  method: 'post',
  product: 'ahas',
});
const SentinelMetricListTopNResourceName = newRequest({
  action: 'SentinelMetricListTopNResourceName',
  method: 'post',
  product: 'ahas',
});
const SentinelGetResourceFallback = newRequest({
  action: 'SentinelGetResourceFallback',
  method: 'post',
  product: 'ahas',
});
const SentinelFlowRuleNew = newRequest({
  action: 'SentinelFlowRuleNew',
  method: 'post',
  product: 'ahas',
});
const SentinelFlowRuleEdit = newRequest({
  action: 'SentinelFlowRuleEdit',
  method: 'post',
  product: 'ahas',
});
const SentinelDegradeRuleNew = newRequest({
  action: 'SentinelDegradeRuleNew',
  method: 'post',
  product: 'ahas',
});
const SentinelDegradeRuleEdit = newRequest({
  action: 'SentinelDegradeRuleEdit',
  method: 'post',
  product: 'ahas',
});
const SentinelSystemRuleNew = newRequest({
  action: 'SentinelSystemRuleNew',
  method: 'post',
  product: 'ahas',
});
const SentinelSystemRuleEdit = newRequest({
  action: 'SentinelSystemRuleEdit',
  method: 'post',
  product: 'ahas',
});
const AddSentinelHotParamRule = newRequest({
  action: 'AddSentinelHotParamRule',
  method: 'post',
  product: 'ahas',
});
const EditSentinelHotParamRule = newRequest({
  action: 'EditSentinelHotParamRule',
  method: 'post',
  product: 'ahas',
});
const CreateSentinelManualDegradeRule = newRequest({
  action: 'CreateSentinelManualDegradeRule',
  method: 'post',
  product: 'ahas',
});
const UpdateSentinelManualDegradeRule = newRequest({
  action: 'UpdateSentinelManualDegradeRule',
  method: 'post',
  product: 'ahas',
});
const CreateSentinelRetryRule = newRequest({
  action: 'CreateSentinelRetryRule',
  method: 'post',
  product: 'ahas',
});
const SentinelGatewayFlowRuleNew = newRequest({
  action: 'SentinelGatewayFlowRuleNew',
  method: 'post',
  product: 'ahas',
});
const SentinelGatewayFlowRuleEdit = newRequest({
  action: 'SentinelGatewayFlowRuleEdit',
  method: 'post',
  product: 'ahas',
});
const SentinelWebFlowRuleNew = newRequest({
  action: 'SentinelWebFlowRuleNew',
  method: 'post',
  product: 'ahas',
});
const SentinelWebFlowRuleEdit = newRequest({
  action: 'SentinelWebFlowRuleEdit',
  method: 'post',
  product: 'ahas',
});
const BindSentinelBlockFallbackDefinition = newRequest({
  action: 'BindSentinelBlockFallbackDefinition',
  method: 'post',
  product: 'ahas',
});
const SentinelAppMachineList = newRequest({
  action: 'SentinelAppMachineList',
  method: 'post',
  product: 'ahas',
});
const SentinelHttpApiMatchQueryForApp = newRequest({
  action: 'SentinelHttpApiMatchQueryForApp',
  method: 'post',
  product: 'ahas',
});
const QuerySentinelRuleInfo = newRequest({
  action: 'QuerySentinelRuleInfo',
  method: 'post',
  product: 'ahas',
});
const getSwitchOverview = newRequest({
  url: '/api/switch/GetUserSummary', // 开关接入统计
  method: 'post',
  headers: {
    'Content-Type': 'application/json'
  },
  product: 'ahas',
  action: 'GetUserSummary',
});
const ListSentinelBlockFallbackDefinitions = newRequest({
  action: 'ListSentinelBlockFallbackDefinitions',
  method: 'post',
  product: 'ahas'
});
const DeleteSentinelBlockFallbackDefinition = newRequest({
  action: 'DeleteSentinelBlockFallbackDefinition',
  method: 'post',
  product: 'ahas',
});
const SentinelGetAdapterSettingOfApp = newRequest({
  action: 'SentinelGetAdapterSettingOfApp',
  method: 'post',
  product: 'ahas',
});
const TestBlockFallbackDefinitionBehavior = newRequest({
  action: 'TestBlockFallbackDefinitionBehavior',
  method: 'post',
  product: 'ahas',
});
const CreateSentinelBlockFallbackDefinition = newRequest({
  action: 'CreateSentinelBlockFallbackDefinition',
  method: 'post',
  product: 'ahas',
});
const UpdateSentinelBlockFallbackDefinition = newRequest({
  action: 'UpdateSentinelBlockFallbackDefinition',
  method: 'post',
  product: 'ahas',
});
const queryTestBlockFallbackDefinitionBehavior = newRequest({
  action: 'queryTestBlockFallbackDefinitionBehavior',
  method: 'post',
  product: 'ahas',
});
const CreateSentinelDefaultCircuitBreakerRule = newRequest({
  action: 'CreateSentinelDefaultCircuitBreakerRule',
  method: 'post',
  product: 'ahas',
});
const EditSentinelDefaultCircuitBreakerRule = newRequest({
  action: 'EditSentinelDefaultCircuitBreakerRule',
  method: 'post',
  product: 'ahas',
});
const SentinelQueryAppPriceLevel = newRequest({
  action: 'SentinelQueryAppPriceLevel',
  method: 'post',
  product: 'ahas',
});
const SentinelModifyAppPriceLevel = newRequest({
  action: 'SentinelModifyAppPriceLevel',
  method: 'post',
  product: 'ahas',
});
const SentinelUpdateAdapterSettingOfApp = newRequest({
  action: 'SentinelUpdateAdapterSettingOfApp',
  method: 'post',
  product: 'ahas',
});
const SentinelGetGeneralSettingOfApp = newRequest({
  action: 'SentinelGetGeneralSettingOfApp',
  method: 'post',
  product: 'ahas',
});
const SentinelUpdateGeneralSettingOfApp = newRequest({
  action: 'SentinelUpdateGeneralSettingOfApp',
  method: 'post',
  product: 'ahas',
});
const GetSentinelClusterClientSettingOfApp = newRequest({
  action: 'GetSentinelClusterClientSettingOfApp',
  method: 'post',
  product: 'ahas',
});
const CreateCluster = newRequest({
  action: 'CreateCluster',
  method: 'post',
  product: 'ahas',
});
const UpdateCluster = newRequest({
  action: 'UpdateCluster',
  method: 'post',
  product: 'ahas',
});
const Clusteron = newRequest({
  action: 'Clusteron',
  method: 'post',
  product: 'ahas',
});
const Clusteroff = newRequest({
  action: 'Clusteroff',
  method: 'post',
  product: 'ahas',
});
const UpdateSentinelClusterClientSettingOfApp = newRequest({
  action: 'UpdateSentinelClusterClientSettingOfApp',
  method: 'post',
  product: 'ahas',
});
const QueryAppProtectionInfo = newRequest({
  action: 'QueryAppProtectionInfo',
  method: 'post',
  product: 'ahas',
});
const SentinelAppEvents = newRequest({
  action: 'SentinelAppEvents',
  method: 'post',
  product: 'ahas',
});
const QueryAppSummaryMetricsOverviewWithSentinel = newRequest({
  action: 'QueryAppSummaryMetricsOverviewWithSentinel',
  method: 'post',
});
const SentinelListTopNAppsSummaryMetricOfAppType = newRequest({
  action: 'SentinelListTopNAppsSummaryMetricOfAppType',
  method: 'post',
  product: 'ahas',
});
const QueryNginxIngressGateway = newRequest({
  action: 'QueryNginxIngressGateway',
  method: 'get',
});
const UpdateDatabaseRoute = newRequest({
  action: 'UpdateDatabaseRoute',
  method: 'post',
});
const QueryDatabaseRoute = newRequest({
  action: 'QueryDatabaseRoute',
  method: 'post',
});

const ListGateway = newRequest({ // 网关列表
  action: 'ListGateway',
  method: 'post',
});

const ListSwimmingLaneGateway = newRequest({ // 网关全链路灰度列表
  action: 'ListSwimmingLaneGateway',
  method: 'post',
});

const ListGatewayRoute = newRequest({ // 网关路由
  action: 'ListGatewayRoute',
  method: 'post',
});

const ListSwimmingLaneGatewayRoute = newRequest({ // 网关路由支持MSe
  action: 'ListSwimmingLaneGatewayRoute',
  method: 'post',
});

const QuerySwimmingLaneById = newRequest({ // 网关路由查询MSe灰度
  action: 'QuerySwimmingLaneById',
  method: 'post',
});

const OpenXTraceService = newRequest({ // 开通xTrace
  action: 'OpenXTraceService',
  method: 'post',
});

const CheckXTraceServiceStatus = newRequest({ // 检测xTrace开通
  action: 'CheckXTraceServiceStatus',
  method: 'post',
});

const ListSpanNames = newRequest({
  action: 'ListSpanNames',
  method: 'post',
});

const GetTagVal = newRequest({
  action: 'GetTagVal',
  method: 'post',
});

const QueryNamespace = newRequest({
  action: 'QueryNamespace',
  method: 'post',
});

export default {
  GetRetryRule,
  UpdateRetryRule,
  DeleteRetryRule,
  CreateRetryRule,
  QueryAppMethodMetrics,
  QueryAppSummaryMetricsOverview,
  GetTimeoutRule,
  CreateTimeoutRule,
  UpdateTimeoutRule,
  DeleteTimeoutRule,
  QueryNginxIngressGateway,
  DeleteFaultInjectionRule,
  UpdateFaultInjectionRule,
  CreateFaultInjectionRule,
  GetFaultInjectionRule,
  UpdateLocalityRule,
  GetLocalityRule,
  ListLoadBalancePolicy,
  AddLoadBalancePolicy,
  RemoveLoadBalancePolicy,
  GetLoadBalancePolicyInfo,
  UpdateLoadBalanceConfig,
  ListCommunites,
  GetUserStatus,
  SetUserStatus,
  GetGovernanceKubernetesClusterList,
  GetGovernanceKubernetesCluster,
  ModifyGovernanceKubernetesCluster,
  ApplyTagPolicies,
  ListApplicationsWithTagRules,
  DeleteServiceTimeConfig,
  AddServiceTimeConfig,
  ApplyCanaryPolicy,
  GetCanaryStatus,
  CreateLicenseKey,
  GetMockRuleByProviderAppId,
  GetMockRuleById,
  AddMockRule,
  DisableMockRule,
  RemoveMockRule,
  EnableMockRule,
  UpdateMockRule,
  GetAccountMockRule,
  GetMockRuleByConsumerAppId,
  RemoveApplication,
  fetchArms,
  GetOverview,
  fetchAuthenticationList,
  addAuthentication,
  fetchAuthenticationInfo,
  updateAuthentication,
  removeAuthentication,
  fetchRegions,
  fetchNamespaces,
  GetAppList,
  GetApplicationDetail,
  getRoutePolicyList,
  getCanaryPolicy,
  updateRoutePolicy,
  getRoutePolicy,
  getServiceList,
  CheckAuthPolicyName,
  getEcsMarkdown,
  getAcsMarkdown,
  getEdasMarkdown,
  fetchServicesList,
  ListEventsPage,
  fetchServiceBasicInfo,
  fetchHsfDetail,
  RunServiceTest,
  fetchServiceProvidersPage,
  fetchServiceConsumersPage,
  fetchOutlierEjectionList,
  updateOutlierEjectionConfig,
  removeOutlierEjection,
  fetchApplicationsByRpcType,
  addOutlierEjection,
  deleteRoutePolicy,
  getlosslessMarkdown,
  addRoutePolicy,
  GetApplicationInstances,
  GetApplicationCanaryInstances,
  GetApplicationTags,
  getServiceTestLink,
  GetDubboTestMethod,
  postDubboParams,
  GetSpringCloudTestMethod,
  GetIstioTestMethod,
  postSCParams,
  getServiceMethodPage,
  getServiceMethodList,
  ListApplicationTagInstancese,
  QueryServiceTimeConfig,
  fetchFaultInjectionPolicy,
  addFaultInjectionPolicy,
  updateFaultInjectionPolicy,
  removeFaultInjectionPolicy,
  fetchServiceRetryPolicyList,
  updateServiceRetryPolicy,
  removeServiceRetryPolicy,
  addServiceRetryPolicy,
  fetchServiceTimeoutPolicyList,
  updateServiceTimeoutPolicy,
  removeServiceTimeoutPolicy,
  addServiceTimeoutPolicy,
  fetchLoadBalancePolicyList,
  addLoadBalancePolicy,
  updateLoadBalancePolicy,
  removeLoadBalancePolicy,
  fetchTestHistorys,
  ListKubernetesNamespace,
  InvokeIstioTestMethod,
  QueryAppTopNMacs,
  QueryAppRPCMacMetrics,
  RevertApplicationRoutePolicy,
  FetchLosslessRuleList,
  GetAppMessageQueueRoute,
  UpdateMessageQueueRoute,
  CreateOrUpdateSwimmingLaneGroup,
  QueryAllSwimmingLaneGroup,
  QueryAllSwimmingLane,
  GetTagsBySwimmingLaneGroupId,
  CreateOrUpdateSwimmingLane,
  ListAppBySwimmingLaneGroupTag,
  RemoveApplications,
  ModifyLosslessRule,
  QueryEventOverview,
  DeleteSwimmingLane,
  DeleteSwimmingLaneGroup,
  QueryAppListMetrics,
  DeleteGovernanceKubernetesCluster,
  QueryGovernanceKubernetesCluster,
  UpdateInstanceRegisterStatus,
  GetResourcePackageStatus,
  QueryEmptyPushSetting,
  CreateOrUpdateEmptyPushSetting,
  QuerySentinelAppSummaryMetricOverview,
  QuerySentinelMetricsOfResource,
  QuerySentinelMacMetricsOfResource,
  QuerySystemResourceMetricOfGroup,
  QuerySystemResourceMetricOfGroupOnNode,
  QuerySystemStatResourceMetricOfResource,
  SentinelGetModelList,
  GetClusterDetail,
  SentinelFlowRuleListByPage,
  SentinelFlowRuleOnBatch,
  SentinelFlowRuleOffBatch,
  SentinelFlowRuleDelete,
  SentinelDegradeRuleListByPage,
  ListSentinelAllDefaultCircuitBreakerRule,
  DeleteSentinelDefaultCircuitBreakerRule,
  SentinelDegradeRuleDelete,
  EnableSentinelDefaulCircuitBreakerRule,
  DisableSentinelDefaultCircuitBreakerRule,
  SentinelDegradeRuleOnBatch,
  SentinelDegradeRuleOffBatch,
  GetSentinelClientVersionOfApp,
  ListSentinelManualDegradeRulesByPage,
  DeleteSentinelManualDegradeRule,
  BatchEnableSentinelManualDegradeRules,
  BatchDisableSentinelManualDegradeRules,
  SentinelParamRuleListByPage,
  SentinelHotParamRuleDelete,
  SentinelHotParamRuleOnBatch,
  SentinelHotParamRuleOffBatch,
  SentinelGatewayApiDefinitionsListForApp,
  SentinelMetricListTopNResourceName,
  SentinelGetResourceFallback,
  SentinelFlowRuleNew,
  SentinelFlowRuleEdit,
  SentinelDegradeRuleNew,
  SentinelDegradeRuleEdit,
  SentinelSystemRuleNew,
  SentinelSystemRuleEdit,
  AddSentinelHotParamRule,
  EditSentinelHotParamRule,
  CreateSentinelManualDegradeRule,
  UpdateSentinelManualDegradeRule,
  CreateSentinelRetryRule,
  SentinelGatewayFlowRuleNew,
  SentinelGatewayFlowRuleEdit,
  SentinelWebFlowRuleNew,
  SentinelWebFlowRuleEdit,
  BindSentinelBlockFallbackDefinition,
  SentinelAppMachineList,
  SentinelHttpApiMatchQueryForApp,
  QuerySentinelRuleInfo,
  getSwitchOverview,
  ListSentinelBlockFallbackDefinitions,
  DeleteSentinelBlockFallbackDefinition,
  SentinelGetAdapterSettingOfApp,
  TestBlockFallbackDefinitionBehavior,
  CreateSentinelBlockFallbackDefinition,
  UpdateSentinelBlockFallbackDefinition,
  queryTestBlockFallbackDefinitionBehavior,
  CreateSentinelDefaultCircuitBreakerRule,
  EditSentinelDefaultCircuitBreakerRule,
  SentinelQueryAppPriceLevel,
  SentinelModifyAppPriceLevel,
  SentinelUpdateAdapterSettingOfApp,
  SentinelGetGeneralSettingOfApp,
  SentinelUpdateGeneralSettingOfApp,
  GetSentinelClusterClientSettingOfApp,
  CreateCluster,
  UpdateCluster,
  Clusteron,
  Clusteroff,
  UpdateSentinelClusterClientSettingOfApp,
  QueryAppProtectionInfo,
  SentinelAppEvents,
  QueryAppSummaryMetricsOverviewWithSentinel,
  SentinelListTopNAppsSummaryMetricOfAppType,
  UpdateDatabaseRoute,
  QueryDatabaseRoute,
  ListGateway,
  ListGatewayRoute,
  ListSwimmingLaneGatewayRoute,
  QuerySwimmingLaneById,
  ListSwimmingLaneGateway,
  OpenXTraceService,
  CheckXTraceServiceStatus,
  ListSpanNames,
  GetTagVal,
  QueryNamespace,
};
