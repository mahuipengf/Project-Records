import { customRequest } from '@ali/cn-design';
import { MSC_WIDGET_CONSOLE_CONFIG, IS_PRE_OR_LOCAL } from 'constants';
import { upperFirstData1 } from 'utils/transfer-data';
import { has, get, isEmpty, toLower, find, includes } from 'lodash';
import { getCurrentRegion, getParams } from 'utils';
import CooKie from 'js-cookie';
// import React from 'react';

const edasService = customRequest();
const { productName } = MSC_WIDGET_CONSOLE_CONFIG;
const regionId = window.regionId || getCurrentRegion() || 'pre';

const consoleService = customRequest({
  request: config => {
    const { data = {}, params = {}, method } = config;
    const newData = { ...data };
    let newParams = { ...params };
    const ns = getParams('ns');

    if (!isEmpty(newData)) {
      newData.source = newData.source || 'edasmsc';
      if (has(newData, 'namespaceId')) {
        newData.namespace = newData.namespaceId;
        delete newData.namespaceId;
      }
      if (has(newData, 'regionId')) {
        newData.region = newData.regionId;
        delete newData.regionId;
      }
    }

    if (!isEmpty(newParams)) {
      newParams['X-EDAS-AT-ROUTER-KEY'] = IS_PRE_OR_LOCAL && productName === 'Edas' ? localStorage.getItem('edasEnvActiveKey') || '' : undefined; // edas 多环境字段
      newParams.source = newParams.source || 'edasmsc';
      if (has(newParams, 'namespaceId')) {
        newParams.namespace = newParams.namespaceId;
        delete newParams.namespaceId;
      }
      if (has(newParams, 'regionId')) {
        newParams.region = newParams.regionId;
        delete newParams.regionId;
      }
    } else if (toLower(method) === 'post' && !isEmpty(newData) && isEmpty(newParams)) {
      newParams = newData;
    }
    if (ns) {
      newParams.Namespace = ns;
      newParams.namespace = ns;
    }

    const MseSessionId = localStorage && localStorage.getItem("MseSessionId");

    return {
      ...config,
      data: {
        region: regionId,
        params: MseSessionId ? {...upperFirstData1(newParams), MseSessionId} : upperFirstData1(newParams),
      },
    };
  },
  response: res => {
    const data = get(res, 'Data', []);
    return data;
  },
});

// 新功能，edas 直接上 pop 接口
const EdasPop = [
  'QueryServiceTimeConfig',
  'AddServiceTimeConfig',
  'DeleteServiceTimeConfig',
  'GetAccountMockRule',
  'GetMockRuleByProviderAppId',
  'GetMockRuleById',
  'AddMockRule',
  'DisableMockRule',
  'RemoveMockRule',
  'EnableMockRule',
  'UpdateMockRule',
  'GetMockRuleByConsumerAppId',
  'GetHistorys',
  'RunServiceTest'
];
export default ({ action, product = productName, url, method = 'get', headers = {} }) => {
  if (MSC_WIDGET_CONSOLE_CONFIG.isUsePopApi || includes(EdasPop, action)) {
    const X_MSE_ENV_KEY = sessionStorage.getItem('X-MSE-ENV-KEY');
    const X_MSE_ENV_ARR = get(window, 'MSE_ENV_CONFIG.X_MSE_ENV_ARR', []);
    const currentEnvItem = find(X_MSE_ENV_ARR, { value: X_MSE_ENV_KEY }) || {};
    const ip = {
      mse: get(currentEnvItem, 'ip.mse', ''),
      edasmsc: get(currentEnvItem, 'ip.edasmsc', ''),
    };
    const newHeader = { 'x-acs-debug-http-host': ip[product] || '' };
    return consoleService({
      product,
      action,
      method,
      headers: (IS_PRE_OR_LOCAL && (product === 'edasmsc' || product === 'mse')) ? newHeader : {}, // 正常应该拿到headers，但目前pop headers加了'Content-Type': 'application/json' 会导致异常，后续需要优化
      popContentType: 'application/json',
    });
  } else {
    const newParams = { method, url, headers };
    return edasService(newParams);
  }
};
