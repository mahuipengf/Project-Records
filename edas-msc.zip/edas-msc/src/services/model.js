import { takeLatest } from '@ali/wind-effect-creator';
import * as constants from './constants';
import * as services from './services';
import * as selectors from './selectors';

const initialState = {
  productVersionDetail: {},
  productFoundationVersionDetail: {},
  productVersionEnvDetail: {},
  activeMenu: 'versionSummary',
  // activeMenu: 'onlineVerify',
  props: {},
  // productVersionResult: {},
};

export default {
  namespace: '',
  state: initialState,
  reducers: {
    dump(state, action) {
      const { payload = {} } = action;
      return {
        ...state,
        ...payload,
      };
    },
    reset(state, action) {
      const { payload = {} } = action;
      return {
        ...state,
        ...initialState,
        ...payload,
      };
    },
    updateProductVersionDetail(state, action) {
      const { payload = {} } = action;
      return {
        ...state,
        ...payload,
      };
    },
    updateProductVersionEnvDetail(state, action) {
      const { payload = {} } = action;
      return {
        ...state,
        ...payload,
      };
    },
    updateFoundationVersionDetail(state, action) {
      const { payload = {} } = action;
      return {
        ...state,
        ...payload,
      };
    },
    updateActiveMenu(state, action) {
      const { payload = {} } = action;
      return {
        ...state,
        ...payload,
      };
    },
    updateProps(state, action) {
      const { payload = {} } = action;
      return {
        ...state,
        ...payload,
      };
    },
    fetchProductVersionResult(state, action) {
      const { payload = {} } = action;
      return {
        ...state,
        ...payload,
      };
    },
  },
  // effects: {
  //   *fetchProductVersionDetail({ payload }, { call, put, select }) {
  //     const result = yield call(services.fetchProductVersionDetail, payload);

  //     if (result && result.success) {
  //       yield put({
  //         type: 'fetchProductVersionResult',
  //         productVersionResult: result.data,
  //       });
  //     }
  //   },

  //   //   // fetch: () => {
  //   //   //   yield put({
  //   //   //     type: 'dump',
  //   //   //     payload: {
  //   //   //       // DataSource: List,
  //   //   //       DataSource: [12, 34, 56],
  //   //   //     },
  //   //   //   });
  //   //   // }
  //   // },
  // },
  subscriptions: {},
};
