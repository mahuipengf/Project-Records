# 微服务治理 msc

## 开发
- 绑定host
```
127.0.0.1 localhost
127.0.0.1 my.console.aliyun.com  
100.67.79.188  pre-mse.console.aliyun.com 
140.205.215.168 cws.alicdn.com cws2.alicdn.com  
106.11.210.201 g.alicdn.com
```

- 替换 `src/index.html` 中的 `window.ALIYUN_CONSOLE_CONFIG.SEC_TOKEN`
- 修改 `demo/index.html` 中的 `WIDGET_CONSOLE_CONFIG`，声明当前的后端服务为 `Edas`或`mse`

```bash
tnpm i
npm start
```

打开 http://my.console.aliyun.com:3001

#### 开发资料

相关开发资料:

- 开发框架： widget
- 组件库： https://cnd.alibaba.net/
- 代码库：http://gitlab.alibaba-inc.com/widget/edas-msc.git

## 发布

- 发布工具：https://work.def.alibaba-inc.com/app/69721/index
- 预发 VIPER：https://pre-viper.aliyun-inc.com/app/mse/conf?tab=HTML
- 生产 VIPER：https://vipernew.aliyun-inc.com/app/mse/conf?tab=HTML
