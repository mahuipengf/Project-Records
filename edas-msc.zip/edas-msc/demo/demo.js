import React from 'react';
import { hot } from 'react-hot-loader';
import Widget from '@ali/widget-edas-msc';

// ServiceTestList
const props = {
  component: 'ServiceList',
  searchValues: {
    regionId: 'cn-hangzhou',
    appId: 'hkhon1po62@851aed61461e464',
    // rpcType: 26
  },
};
const Demo = () => <Widget {...props} />;

export default hot(module)(Demo);

// 负载均衡
// component: "LoadBalanceList",
// searchValues: { // 表格搜索默认值
//   regionId: 'cn-hangzhou',
//   namespaceId: 'cn-hangzhou',
//   protocol: "istio",
// },

// 服务重试
// component: "ServiceRetryPolicyList",
// searchValues: { // 表格搜索默认值
//   protocol: "istio", // 是否默认框架
//   regionId: 'cn-hangzhou',
//   namespaceId: 'cn-hangzhou',
// },

// 服务超时
// component: "ServiceTimeoutPolicyList",
//   searchValues: { // 表格搜索默认值
//     protocol: "istio", // 是否默认框架
//     regionId: 'cn-hangzhou',
//     namespaceId: 'cn-hangzhou',
//   },
// },


// 故障注入
// component: "FaultInjectionList",
// searchValues: { // 表格搜索默认值
//   protocol: "istio", // 是否默认框架
//   regionId: 'cn-hangzhou',
//   namespaceId: 'cn-hangzhou',
// },

// 服务鉴权各页面参数
// component: "AuthenticationList",
// searchValues: { // 表格搜索默认值
//   protocol: "SPRING_CLOUD", // 是否默认框架
//   regionId: 'cn-beijing',
//   namespaceId: 'cn-beijing',
// },

// component: "AuthenticationInfo",
// searchValues: { // 详情默认值
//   id: '110',
//   regionId: 'cn-beijing',
//   namespaceId: 'cn-beijing',
// },

// component: "AuthenticationNew",
// editValues: { // 新建的默认字段
//   name: "",
//   protocol: "SPRING_CLOUD",
//   appId: "",
//   enable: true,
//   source: "EDAS",
//   regionId: 'cn-beijing',
//   namespaceId: 'cn-beijing:xianhe',
//   authRule: []
// },

// component: "AuthenticationNew",
// editValues: { // 编辑所需字段
//   id: '110',
//   regionId: 'cn-beijing',
//   namespaceId: 'cn-beijing',
// },

// 服务查询
// component: "ServiceList",
// searchValues: { // 表格搜索默认值
//   serviceType: 'springCloud',
//   origin: 'agent', // agent-新, registry-旧
//   regionId: 'cn-beijing',
//   namespaceId: 'cn-beijing',
// },

// component: "ServiceInfo",
// searchValues: { // 表格搜索默认值
//   regionId: 'cn-hangzhou',
//   namespaceId: 'cn-hangzhou',

//   serviceType: 'dubbo',
//   searchType: 'service',
//   searchValue: null,
//   origin: 'registry',
//   appId: '714ef6b0-91ee-4323-b383-168da1c7bbf2',
//   ip: '',
//   serviceId: '714ef6b0-91ee-4323-b383-168da1c7bbf2:com.alibaba.edas.demo.EchoService::',
//   serviceName: 'com.alibaba.edas.demo.EchoService',
//   edasAppName: 'dubbo-cs-p',
//   version: '',
//   group: '',
//   registryType: '',
// },

// component: "AppService",
// searchValues: { // 表格搜索默认值
//   regionId: 'cn-hangzhou',
//   namespaceId: 'cn-hangzhou',
//   appId: ''
// },


// 离群
// component: 'OutlierEjectionList',
// searchValues: {
//   regionId: 'cn-beijing',
//   namespaceId: 'cn-beijing',
//   rpcType: 7, // 被调用服务应用框架，7-dubbo，25-spring cloude
// },

// component: 'OutlierEjectionNew',
// editValues: {
//   regionId: 'cn-beijing',
//   namespaceId: 'cn-beijing',
//   rpcType: 25, // 被调用服务应用框架，7-dubbo，25-spring cloude
// },

// 路由
// component: 'RouteDynamicList',
// searchValues: {
//   regionId: 'cn-shanghai',
// },
