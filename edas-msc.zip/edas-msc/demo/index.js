import '@alife/dpl-console-design-2019/dist/widget.css'

import React from 'react'
import { render } from 'react-dom'
import Demo from './demo.js'

render(<Demo />, document.querySelector('#root'))
