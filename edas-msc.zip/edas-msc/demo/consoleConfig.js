/**
 * --------------------------------------------------------------------
 * 这里配置 one-console 相关的 mock 信息，如 渠道链接 与 功能开关 等等。
 * 这份配置在 node.js 环境使用，请勿把 module.exports 改成 ES6 Module！
 * 注意：配置更改后需要重新执行 `npm start` 才能生效
 * --------------------------------------------------------------------
 */
module.exports = {
  CHANNEL: 'OFFICIAL',
  LOCALE: 'zh-CN',
  SEC_TOKEN: 'F3bGi9iKuYowB23TIfCd21',
  MAIN_ACCOUNT_PK: '2496103360711970',
  CURRENT_PK: '2496103360711970',
  ACCOUNT_TYPE: 'main',
  CHANNEL_FEATURE_STATUS: {},
  CHANNEL_LINKS: {},
  LABELS: {},
  RULE_CONFIG: {},
  portalType: 'one',
}
