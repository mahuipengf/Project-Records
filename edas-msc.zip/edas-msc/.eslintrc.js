module.exports = {
  parser: 'babel-eslint',
  extends: ['eslint-config-ali/react', 'plugin:jsx-control-statements/recommended'],
  rules: {
    semi: [2, 'always'],
    'space-before-function-paren': 0,
    'arrow-parens': 0,
    'react/jsx-no-undef': 0,
    'max-len': 0,
    'react/no-danger': 0,
    'no-nested-ternary': 0,
    'no-console': 0,
    'comma-dangle': 0,
    "no-confusing-arrow": 0
  },
  "globals": {
    "aliwareGetCookieByKeyName": true,
  }
};
