module.exports = {
  version: '1.0.2',
  projectName: 'MSE',
  theme_id: 'aliyun',
  author_id: '23',
  token: 'b4c1c8ae5db8395546c5e82847378264',
  template: `<!DOCTYPE html>
	<html lang="en">
	<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<meta http-equiv="X-UA-Compatible" content="ie=edge">
			<title>MSE</title>
			<link rel="shortcut icon" href="//www.aliyun.com/favicon.ico" type="image/x-icon"/>
		<link rel="stylesheet" type="text/css" href="//g.alicdn.com/aliyun/console/1.3.63/styles/bootstrap/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="//g.alicdn.com/aliyun/console/1.3.63/styles/console1412.css">
		<link rel="stylesheet" type="text/css" href="//g.alicdn.com/cm/edas/2.132.6/styles/edas/edas.console.css">
		<link rel="stylesheet" type="text/css" defer href="//midwayfe.oss-cn-shanghai.aliyuncs.com/assets/consoleNavAdapt@0.01.css">
	
			<!-- 第三方css开始 -->	  
			{css}
		<!-- 第三方css结束 -->	  
		<script src="//midwayfe.oss-cn-shanghai.aliyuncs.com/aliwareIntl_MSE_en.js"></script>
		<script src="//midwayfe.oss-cn-shanghai.aliyuncs.com/aliwareIntl_MSE_zh.js"></script>
		<script src="//g.alicdn.com/cm-design/simplemvc-cdn/0.0.67/jquery.js"></script>
		<script src="//g.alicdn.com/EFDP/naruto-cdn/naruto/lib/lodash4.17.11.js"></script>
		<script src="//g.alicdn.com/EFDP/naruto-cdn/0.0.52/naruto/lib/moment.js"></script>
		<script src="//g.alicdn.com/EFDP/naruto-cdn/naruto/lib/history@4.7.2.js"></script>
		<script src="//g.alicdn.com/EFDP/naruto-cdn/naruto/lib/react@16.8.6.js"></script>
		<script src="//g.alicdn.com/EFDP/naruto-cdn/naruto/lib/react-dom@16.8.6.js"></script>
		<script src="//g.alicdn.com/EFDP/naruto-cdn/naruto/lib/prop-types@15.6.2.js"></script>
		<script src="//g.alicdn.com/EFDP/naruto-cdn/naruto/lib/react-router-dom@4.4.0.js"></script>
		<script>
			window.ReactDOM = window.ReactDom || window.ReactDOM;
			window.ReactDom = window.ReactDOM;
			React.PropTypes = window.PropTypes;
			window.Component = React.Component;
		</script>
		{extraHeader}
	</head>
	<body>
		{extraBody}
			<div id="root" style="overflow: hidden;width: 100%;height: 100%;"></div>
			<div id="app"></div>
			<div id="other"></div>
			
		<!-- 第三方js开始 -->	  
			{js}
		<!-- 第三方js结束 -->
		<script src="//g.alicdn.com/aliyun/console-base/1.6.31/app.polyfill.js"></script>
	</body>
	{extraFooter}
	</html>
`,
  routerTempl: `import React from 'react';
import PropTypes from 'prop-types';
import Nav from './containers/Nav';
import './lib';

{importPre}

const { Switch, Route, Router } = window.ReactRouterDOM || window.ReactRouterDom || {};

const Layout = () => (
	<Nav>
		<Switch>
			{RoutePre}
		</Switch>
	</Nav>
);

const AppRouter = ({ history }) => {
	window.hashHistory = history;
	return (
		<Router history={history}>
			<Route path="/" component={Layout} />
		</Router>
	);
};

AppRouter.propTypes = {
	history: PropTypes.objectOf(PropTypes.any),
};

export default AppRouter;
	`,
  preStr: `import React from 'react';`
};
