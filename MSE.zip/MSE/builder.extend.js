const merge = require('webpack-merge');
const aliasConfig = require('./alias.config');
const { get, last } = require('lodash');

module.exports = (config) => {
  const developConfig = merge(config, {
    resolve: aliasConfig,
    // module: {
    //   rules: [
    //     {
    //       test: /\.ttf$/,
    //       use: ['file-loader'],
    //     },
    //   ],
    // },
    devServer: {
      proxy: {
        '/data/api.json': {
          target: 'https://pre-mse.console.aliyun.com/',
          changeOrigin: true,
          secure: false,
          ws: true,
          withCredentials: true,
        },
      },
    },
  });
  const productConfig = merge(developConfig, {
    externals: [
      {
        lodash: '_',
        moment: 'moment',
        'prop-types': 'PropTypes',
        react: 'React',
        'react-dom': 'ReactDOM',
        // '@ali/wind/dist/wind.js': 'wind',
      },
    ],
  });
  return process.env.NODE_ENV === 'development' ? developConfig : productConfig;
};
