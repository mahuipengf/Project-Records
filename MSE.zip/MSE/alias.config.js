const { resolve } = require('path');

module.exports = {
  alias: {
    src: resolve('src'),
    utils: resolve('src/utils'),
    components: resolve('src/components'),
    pages: resolve('src/pages'),
    containers: resolve('./src/containers'),
    constants: resolve('./src/constants'),
    layouts: resolve('./src/layouts'),
    config: resolve('./src/config'),
    models: resolve('./src/models'),
    store: resolve('./src/store'),
  },
};
