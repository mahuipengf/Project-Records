import Cookie from 'js-cookie';
import _ from 'lodash';
import moment from 'moment';
import { timeFmt } from './time';
import { IS_SAU_BUSINESS } from 'constants/index.js';

export const getCurrentRegion = () => {
  let regions = _.get(window, 'ALIYUN_CONSOLE_CONFIG.STATIC_API.regions', []);
  regions = regions.map((item) => {
    return {
      name: item.regionName,
      id: item.regionId
    };
  });

  let firstRegion = _.head(regions) || { id: 'cn-hangzhou' };
  if (IS_SAU_BUSINESS) {
    firstRegion = { id: 'me-central-1' };
  }
  return window.getParams('region') || Cookie.get('currentRegionId') || firstRegion.id;
};

export const formatDate = text => {
  const aliyunLang = Cookie.get('aliyun_lang') || 'zh';
  if (aliyunLang === 'zh') {
    return moment(text).format('YYYY-MM-DD HH:mm:ss');
  } else if (aliyunLang === 'en') {
    const momentInstance = moment(text).locale('en');
    return momentInstance.format('MMM DD, YYYY, HH:mm:ss');
  }
};

//最新动态时间格式化
export const formatUpdateDate = text => {
  const aliyunLang = Cookie.get('aliyun_lang') || 'zh';
  if (aliyunLang === 'zh') {
    return moment(text).format('YYYY-MM-DD');
  } else if (aliyunLang === 'en') {
    const momentInstance = moment(text).locale('en');
    return momentInstance.format('MMM DD, YYYY');
  }
};

// condition 回显，凸显的是：值
export const mapConditions = (conditions = []) => _.map(conditions, child => {
  switch (child.operator) {
    case 'list':
      return { uid: _.uniqueId(), ...child, cond: child.operator, value: child.nameList };
    case 'mod':
      return { uid: _.uniqueId(), ...child, cond: `mod-${child.cond}`, value: child.remainder };
    case 'rawvalue':
      return { uid: _.uniqueId(), ...child, value: child.datum };
    case 'deterministic_proportional_steaming_division':
      return { uid: _.uniqueId(), ...child, cond: '%', value: child.remainder };
    case 'string': // istio 的条件类型
      return { uid: _.uniqueId(), ...child };
    case 'regexp': // 正则匹配
      return { uid: _.uniqueId(), ...child, value: child.datum };
    default:
      return { uid: _.uniqueId(), ...child };
  }
});

// 提交数据处理 conditions
export const mapConditionsFormData = (conditions = [], type = 'springCloud') => _.map(conditions, child => {
  const val = {};
  if (child.cond === 'list') {
    val.cond = child.cond;
    val.operator = 'list';
  } else if (child.cond === '%') {
    val.cond = '%';
    val.operator = 'deterministic_proportional_steaming_division';
  } else if (child.cond === 'regexp') {
    val.cond = 'regexp';
    val.operator = 'regexp';
  } else if (child.cond && child.cond.indexOf('mod-') > -1) {
    val.cond = _.split(child.cond, '-')[1];
    val.operator = 'mod';
  } else if (child.cond === 'exact' || child.cond === 'prefix' || child.cond === 'regex') { // istio 的条件类型
    val.cond = child.cond;
    val.operator = 'string';
  } else {
    val.cond = child.cond;
    val.operator = 'rawvalue';
  }
  switch (type) {
    case 'springCloud':
      return ({
        type: child.type,
        name: child.name,
        value: child.cond === 'list' ? _.join(_.map(child.value || [], n => _.trim(n))) : child.value,
        ...val,
      });
    case 'dubbo':
      return ({
        index: child.index,
        expr: child.expr,
        type: child.type,
        name: child.name,
        value: child.cond === 'list' ? _.join(_.map(child.value || [], n => _.trim(n))) : child.value,
        ...val,
      });
    case 'istio':
      return ({
        type: child.type,
        name: child.name,
        value: child.cond === 'list' ? _.join(_.map(child.value || [], n => _.trim(n))) : child.value,
        ...val,
      });
    default:
      return child;
  }
});
export {
  timeFmt
};

export const aliyunSite = Cookie.get('aliyun_site') || 'CN';

// export const signFigures = function(num, rank = 6) {
//   if (!num) return (0);
//   const sign = num / Math.abs(num);
//   const number = num * sign;
//   const temp = rank - 1 - Math.floor(Math.log10(number));
//   let ans;
//   if (temp > 0) {
//     ans = parseFloat(number.toFixed(temp));
//   } else if (temp < 0) {
//     ans = Math.round(number / Math.pow(10, temp)) * temp;
//   } else {
//     ans = Math.round(number);
//   }
//   return (ans * sign);
// };

export const signFigures = function(num, rank = 6) {
  if (!num) return (0);
  const sign = num / Math.abs(num);
  const number = num * sign;
  const temp = rank - 1 - Math.floor(Math.log10(number));
  let ans;
  if (temp > 0) {
    ans = parseFloat(number.toFixed(temp));
  } else if (temp < 0) {
    // eslint-disable-next-line no-restricted-properties
    ans = Math.round(number / Math.pow(10, temp)) * temp;
  } else {
    ans = Math.round(number);
  }
  return (ans * sign);
};
