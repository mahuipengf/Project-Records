import * as wind from '@ali/wind/dist/wind.js';

//组件全部注入到window
Object.keys(wind).forEach(keyName => {
  if (keyName === 'version') {
    return;
  }
  window[keyName] = wind[keyName];
});
