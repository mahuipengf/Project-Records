import request from './request/request';
import { CommonReq } from 'config/interfaces';
import { Message } from '@alicloud/console-components';
import { getLocal } from 'utils/util_ahas';

interface OptionParams {
  apiType?: string; // one-console 对应的接口类型
  ignoreError?: boolean; // 是否忽略 api 异常
  description?: string; // 当前请求的描述
  useCors?: boolean; // 是否使用 fecs 提供的跨域接口
  proxy?: boolean; // 是否代理接口
}

function createService(
  product: string,
  action: string,
  {
    apiType = 'open',
    ignoreError = false,
    description = undefined,
    useCors = false,
    proxy = false,
  }: OptionParams = {},
) {
  return (params: CommonReq = {}) => {
    const csTypeExternal = window.getParams('ClusterType') === 'ExternalKubernetes';
    const mseSessionId = localStorage.getItem('MseSessionId');
    if (csTypeExternal) {
      params.AhasRegionId = params.RegionId = 'public'; // cs容器
    } else {
      params.AhasRegionId = params.RegionId = window.regionId;
    }
    if (!params.Namespace) {
      params.NameSpace = params.Namespace = 'default'; // 大小写问题，兼容不同接口。。 目前默认命名空间
    }
    params.Lang = getLocal().substring(0, 2);
    if (mseSessionId) {
      params.MseSessionId = mseSessionId;
    }

    return request({
      data: {
        product,
        action,
        params,
      },
      header: {},
      apiType,
      ignoreError,
      useCors,
      description: description || action,
      proxy,
    }).catch((e: Error) => {
      Message.error(e.message);
    });
  };
}

export default createService;
