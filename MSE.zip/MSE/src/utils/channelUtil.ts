import { confFeature, confLinkGen } from '@alicloud/console-one-conf';

export { confFeature };
