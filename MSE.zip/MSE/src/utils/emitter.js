import utilMethod from './utils';
import { createEventBus } from '@ali/xconsole/alfa';

const emitter = createEventBus();

const alfaEmitter = emitter.on('mseInvoke', (e) => {
  const { functionName, payload, val } = e;
  if (utilMethod[functionName]) {
    utilMethod[functionName](payload, val);
  }
});
export default alfaEmitter;
