/**
 * product // pop接口参数
 * action // pop接口参数
 * method // 默认get，如果是get接口，可以省略
 * url // 非pop接口请求路径
 */
import request from './request';

const fetchGatewayAlarms = request({
  method: 'get',
  product: 'mse',
  action: 'GetGatewayAlarms',
});

export default {
  fetchGatewayAlarms,
};
