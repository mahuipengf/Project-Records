import request from './request';

const getListMigrationTask = request({
  method: 'get',
  product: 'mse',
  action: 'ListMigrationTask',
});

const addMigrationTask = request({
  method: 'post',
  product: 'mse',
  action: 'AddMigrationTask',
});

const updateMigrationTask = request({
  method: 'post',
  product: 'mse',
  action: 'UpdateMigrationTask',
});

const deleteMigrationTask = request({
  method: 'post',
  product: 'mse',
  action: 'DeleteMigrationTask',
});

const getListClusterSelection = request({
  method: 'get',
  product: 'mse',
  action: 'ListClusterSelection',
});

export default {
  getListMigrationTask,
  addMigrationTask,
  updateMigrationTask,
  deleteMigrationTask,
  getListClusterSelection,
};
