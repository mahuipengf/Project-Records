/**
 * product // pop接口参数
 * action // pop接口参数
 * method // 默认get，如果是get接口，可以省略
 * url // 非pop接口请求路径
 */
import request from './request';

const getOverview = request({
  method: 'get',
  product: 'mse',
  action: 'GetOverview',
});

const getK8sCluster = request({
  method: 'get',
  product: 'mse',
  action: 'QueryGovernanceKubernetesCluster',
});

const getK8sClusterInfo = request({
  method: 'get',
  product: 'mse',
  action: 'GetGovernanceKubernetesCluster',
});

const updateK8sCluster = request({
  method: 'get',
  product: 'mse',
  action: 'ModifyGovernanceKubernetesCluster',
});

const getApplicationList = request({
  method: 'get',
  product: 'mse',
  action: 'GetApplicationList',
});

const getAppNamespaceList = request({
  method: 'get',
  product: 'mse',
  action: 'QueryNamespace',
});

const getServiceListPage = request({
  method: 'get',
  product: 'mse',
  action: 'GetServiceListPage',
});

const getServiceProvidersPage = request({
  method: 'get',
  product: 'mse',
  action: 'GetServiceProvidersPage',
});

const getUserStatus = request({
  method: 'get',
  product: 'mse',
  action: 'GetUserStatus',
});

export default {
  getOverview,
  getK8sCluster,
  getK8sClusterInfo,
  updateK8sCluster,
  getApplicationList,
  getAppNamespaceList,
  getUserStatus,
  getServiceListPage,
  getServiceProvidersPage,
};
