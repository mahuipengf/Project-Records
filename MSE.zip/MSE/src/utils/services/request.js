import { customRequest } from '@ali/cn-design';
import { get, assign, find, first } from 'lodash';
import { IS_PRE_OR_LOCAL, X_MSE_ENV_ARR } from 'constants';
import CooKie from 'js-cookie';

const GetAllResultActions = [
  'ListNamingTrack',
  'ListAnsInstances',
  'ListMigrationTask',
  'ListTagKeys',
  'ListTagValues',
  'ListTagResources',
  'TagResources',
  'UntagResources',
  'UpdateRunningConfig',
  'ListZookeeperServices'
];

const consoleService = customRequest({
  request: (config) => {
    const { data = {}, params = {}, source } = config;
    const AcceptLanguage = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';

    const MseSessionId = localStorage && localStorage.getItem('MseSessionId');
    if (source) {
      params.Source = source;
    }
    // const GlobalNamespace = CooKie.get('GlobalNamespace') ? JSON.parse(CooKie.get('GlobalNamespace')) : {};
    const ns = getParams('ns');

    // if (GlobalNamespace && GlobalNamespace.namespace) {
    //   params.Namespace = ns || GlobalNamespace?.namespace || '';
    // }
    if (ns) {
      params.Namespace = ns || '';
    }
    return {
      ...config,
      data: {
        data,
        region: params.DynamicRegion && params.RegionId ? params.RegionId : window.regionId,
        params: MseSessionId
          ? { ...params, AcceptLanguage, MseSessionId }
          : { ...params, AcceptLanguage },
      },
    };
  },
  response: (res) => {
    const resultSymbol = first(Object.getOwnPropertySymbols(res));
    const originData = res[resultSymbol];
    const action = get(originData, 'config.action', '');
    if (GetAllResultActions.includes(action)) {
      return res;
    }
    let data = get(res, 'Data');
    const { Success, Message, ErrorCode } = res;
    if (ErrorCode && Success === false) {
      data = { Success, Message };
    }
    return data;
  },
});

export default ({ action, product = 'mse', headers = {}, method = 'get', source }) => {
  const X_MSE_ENV_KEY = sessionStorage.getItem('X-MSE-ENV-KEY');

  const currentEnvItem = find(X_MSE_ENV_ARR, { value: X_MSE_ENV_KEY }) || {};
  const ip = {
    mse: get(currentEnvItem, 'ip.mse', ''),
    edasmsc: get(currentEnvItem, 'ip.edasmsc', ''),
  };
  const hostHeader = { 'x-acs-debug-http-host': ip[product] || '' };
  return consoleService({
    headers: IS_PRE_OR_LOCAL ? hostHeader : headers,
    product,
    action,
    method,
    source,
  });
};
