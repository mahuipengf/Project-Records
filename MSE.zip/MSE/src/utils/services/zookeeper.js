import request from './request';

const listZookeeperServices = request({
  method: 'get',
  product: 'mse',
  action: 'ListZookeeperServices',
});

const queryZookeeperProviders = request({
  method: 'get',
  product: 'mse',
  action: 'QueryZookeeperProviders',
});
const queryZookeeperConsumers = request({
  method: 'get',
  product: 'mse',
  action: 'QueryZookeeperConsumers',
});
const updateZookeeperProvider = request({
  method: 'post',
  product: 'mse',
  action: 'UpdateZookeeperProvider',
});

const getApplicationList = request({
  method: 'get',
  product: 'edasmsc',
  action: 'GetApplicationList',
});

export default {
  listZookeeperServices,
  queryZookeeperProviders,
  queryZookeeperConsumers,
  updateZookeeperProvider,
  getApplicationList,
};
