import request from './request';

const QueryConfig = request({
  method: 'get',
  product: 'mse',
  action: 'QueryConfig',
});

const createNacosService = request({
  method: 'post',
  product: 'mse',
  action: 'CreateNacosService',
});

const createNacosInstance = request({
  method: 'post',
  product: 'mse',
  action: 'CreateNacosInstance',
});

const updateNacosCluster = request({
  method: 'post',
  product: 'mse',
  action: 'UpdateNacosCluster',
});

const deleteNacosInstance = request({
  method: 'post',
  product: 'mse',
  action: 'DeleteNacosInstance',
});

const cleanClusterDisk = request({
  method: 'get',
  product: 'mse',
  action: 'CleanClusterDisk',
});

const getClusterInfo = request({
  method: 'get',
  product: 'mse',
  action: 'QueryClusterInfo',
});

const getClusterInstance = request({
  method: 'get',
  product: 'mse',
  action: 'QueryInstancesInfo',
});

const getClusterAcl = request({
  method: 'get',
  product: 'mse',
  action: 'QueryAcl',
});

const getClusterDetail = request({
  method: 'get',
  product: 'mse',
  action: 'QueryClusterDetail',
});

const getZooKeeperUploader = request({
  method: 'get',
  product: 'mse',
  action: 'GetZookeeperDataImportUrl',
});

const importZookeeperData = request({
  method: 'get',
  product: 'mse',
  action: 'ImportZookeeperData',
});

const orderClusterRiskNotice = request({
  method: 'post',
  product: 'mse',
  action: 'OrderClusterHealthCheckRiskNotice',
});

const putClusterHealthCheck = request({
  method: 'post',
  product: 'mse',
  action: 'PutClusterHealthCheckTask',
});

const getClusterHealthCheckTask = request({
  method: 'get',
  product: 'mse',
  action: 'ListClusterHealthCheckTask',
});

const getListAnsServiceClusters = request({
  method: 'get',
  product: 'mse',
  action: 'ListAnsServiceClusters',
});

const getListAnsInstances = request({
  method: 'get',
  product: 'mse',
  action: 'ListAnsInstances',
});

const updateNacosInstance = request({
  method: 'post',
  product: 'mse',
  action: 'UpdateNacosInstance',
});

const getServiceListeners = request({
  method: 'get',
  product: 'mse',
  action: 'GetServiceListeners',
});

const launchExportZookeeperData = request({
  method: 'get',
  product: 'mse',
  action: 'ExportZookeeperData',
});

const getExportZookeeperData = request({
  method: 'get',
  product: 'mse',
  action: 'ListExportZookeeperData',
});
const updateRunningConfig = request({
  method: 'post',
  product: 'mse',
  action: 'UpdateRunningConfig',
});


export default {
  QueryConfig,
  createNacosService,
  createNacosInstance,
  updateNacosCluster,
  deleteNacosInstance,
  cleanClusterDisk,
  getClusterInfo,
  getClusterInstance,
  getClusterAcl,
  getClusterDetail,
  getZooKeeperUploader,
  importZookeeperData,
  orderClusterRiskNotice,
  putClusterHealthCheck,
  getClusterHealthCheckTask,
  getListAnsServiceClusters,
  getListAnsInstances,
  updateNacosInstance,
  getServiceListeners,
  launchExportZookeeperData,
  getExportZookeeperData,
  updateRunningConfig,
};
