/**
 * product // pop接口参数
 * action // pop接口参数
 * method // 默认get，如果是get接口，可以省略
 * url // 非pop接口请求路径
 */
import request from './request';
import axios from './axios';
import microgw from './microgw';
import nacos from './nacos';
import migration from './migration';
import zookeeper from './zookeeper';
import access from './access';

const UpgradeCluster = request({
  //  nacos 升级
  action: 'UpgradeCluster',
});

const CheckRole = request({
  // 检验ram授权
  action: 'CheckRole',
});

const CheckSlrRole = request({
  // 检验ram授权
  action: 'CheckServiceLinkRole',
});

const CreateSlrRole = request({
  // 创建角色
  action: 'InitializeServiceLinkRole',
  method: 'post',
});

const fetchAnnouncement = axios({
  url: 'https://fecs.console.aliyun.com/api/wind/announcement?id=mse',
});

const GetUserStatus = request({
  action: 'GetUserStatus',
});

const SetUserStatus = request({
  action: 'SetUserStatus',
});

const GetImage = request({
  // 获取版本号
  action: 'GetImage',
});

const UpdateImage = request({
  // 升级集群实例版本号
  action: 'UpdateImage',
  method: 'post',
});

const GetApplicationDetail = request({
  action: 'GetApplicationDetail',
});

const GetAppList = request({
  // 获取应用列表
  action: 'GetApplicationList',
  url: '/sp/applications',
});

const OpenAhasCommercial = request({
  // 用户开通Ahas
  action: 'OpenAhasCommercial',
});

const getClusterFeature = request({
  method: 'get',
  product: 'mse',
  action: 'ListClusterDetailFeature',
});

const fetchRegisterMonitor = request({
  method: 'get',
  product: 'mse',
  action: 'GetDashBoardUrl',
});

const ListNamingTrack = request({
  method: 'get',
  product: 'mse',
  action: 'ListNamingTrack',
});

const QueryMseHomeDetail = request({
  method: 'get',
  product: 'mse',
  action: 'QueryMseHomeDetail',
});

const QuerySentinelRuleInfo = request({
  method: 'get',
  product: 'ahas',
  action: 'QuerySentinelRuleInfo ',
});

const GetUserSummary = request({
  method: 'get',
  product: 'ahas',
  action: 'GetUserSummary',
});

const QueryLicenseKey = request({
  method: 'post',
  product: 'mse',
  action: 'CreateLicenseKey',
});

const fetchSeataAlarms = request({
  method: 'get',
  product: 'mse',
  action: 'GetSeataAlarms',
});

const ListTagResources = request({
  method: 'get',
  product: 'mse',
  action: 'ListTagResources',
});

const TagResources = request({
  method: 'get',
  product: 'mse',
  action: 'TagResources',
});

const UntagResources = request({
  method: 'get',
  product: 'mse',
  action: 'UntagResources',
});

const ListTagKeys = request({
  method: 'get',
  product: 'tag',
  action: 'ListTagKeys',
});

const ListTagValues = request({
  method: 'get',
  product: 'tag',
  action: 'ListTagValues',
});

const GetSystemGuardApp = request({
  method: 'get',
  product: 'mse',
  action: 'GetApplicationListWithMetircs',
});

const getSentinelQueryAppPriceLevel = request({
  method: 'post',
  product: 'ahas',
  action: 'SentinelQueryAppPriceLevel',
});

const getGetSentinelClientVersionOfAppPage = request({
  method: 'post',
  product: 'ahas',
  action: 'GetSentinelClientVersionOfApp',
});

const getSentinelFavoriteAddFavoriteApp = request({
  method: 'post',
  product: 'ahas',
  action: 'SentinelFavoriteAddFavoriteApp',
});

const getSentinelFavoriteDeleteFavoriteApp = request({
  method: 'post',
  product: 'ahas',
  action: 'SentinelFavoriteDeleteFavoriteApp',
});

const GetLocalityRule = request({
  method: 'post',
  product: 'mse',
  action: 'GetLocalityRule',
  source: 'edasmsc',
});

const UpdateLocalityRule = request({
  method: 'post',
  product: 'mse',
  action: 'UpdateLocalityRule',
  source: 'edasmsc',
});

const ListApplicationsWithTagRules = request({
  method: 'post',
  product: 'mse',
  action: 'ListApplicationsWithTagRules',
  source: 'edasmsc',
});

const RevertApplicationRoutePolicy = request({
  method: 'post',
  product: 'mse',
  action: 'RevertApplicationRoutePolicy',
  source: 'edasmsc',
});

const ApplyTagPolicies = request({
  method: 'post',
  product: 'mse',
  action: 'ApplyTagPolicies',
  source: 'edasmsc',
});

const getServiceList = request({
  method: 'post',
  product: 'mse',
  action: 'GetServiceList',
  source: 'edasmsc',
});

const GetAppMessageQueueRoute = request({
  method: 'post',
  product: 'mse',
  action: 'GetAppMessageQueueRoute',
  source: 'edasmsc',
});

const FetchLosslessRuleList = request({
  method: 'post',
  product: 'mse',
  action: 'FetchLosslessRuleList',
  source: 'edasmsc',
});
const GetLosslessRuleByApp = request({
  method: 'get',
  product: 'mse',
  action: 'GetLosslessRuleByApp',
});

const RemoveApplication = request({
  method: 'post',
  product: 'mse',
  action: 'RemoveApplication',
  source: 'edasmsc',
});

const createGovernanceService = request({
  method: 'post',
  product: 'mse',
  action: 'CreateGovernanceService',
  // source: 'edasmsc',
});

export default {
  ...nacos,
  ...microgw,
  ...migration,
  ...zookeeper,
  ...access,
  GetApplicationDetail,
  UpdateImage,
  GetImage,
  GetUserStatus,
  SetUserStatus,
  UpgradeCluster,
  CheckRole,
  CheckSlrRole,
  CreateSlrRole,
  fetchAnnouncement,
  GetAppList,
  OpenAhasCommercial,
  getClusterFeature,
  fetchRegisterMonitor,
  ListNamingTrack,
  QueryMseHomeDetail,
  QuerySentinelRuleInfo,
  GetUserSummary,
  fetchSeataAlarms,
  QueryLicenseKey,
  ListTagResources,
  TagResources,
  UntagResources,
  ListTagKeys,
  ListTagValues,
  GetSystemGuardApp,
  getSentinelQueryAppPriceLevel,
  getGetSentinelClientVersionOfAppPage,
  getSentinelFavoriteAddFavoriteApp,
  getSentinelFavoriteDeleteFavoriteApp,
  GetLocalityRule,
  UpdateLocalityRule,
  ListApplicationsWithTagRules,
  RevertApplicationRoutePolicy,
  ApplyTagPolicies,
  getServiceList,
  GetAppMessageQueueRoute,
  FetchLosslessRuleList,
  GetLosslessRuleByApp,
  RemoveApplication,
  createGovernanceService,
};
