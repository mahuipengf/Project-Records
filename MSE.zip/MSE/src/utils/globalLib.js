import serviceConfig from '../serviceMock';
import moment from 'moment';
import projectConfig from '../config';
import Cookies from 'js-cookie';
import { head, get, find } from 'lodash';
import { X_MSE_ENV_ARR, IS_PRE_OR_LOCAL } from 'constants';
import { Dialog } from '@ali/wind';
import intl from '@ali/wind-intl';

if (IS_PRE_OR_LOCAL && !sessionStorage.getItem('X-MSE-ENV-KEY')) {
  const firstItem = head(X_MSE_ENV_ARR) || {};
  const X_MSE_ENV_KEY = firstItem.value;
  sessionStorage.setItem('X-MSE-ENV-KEY', X_MSE_ENV_KEY);
}

/**
 * 获取cookie值
 * @param {*String} keyName cookie名
 */
window.aliwareGetCookieByKeyName = function(keyName) {
  let result = '';
  let cookieList = (document.cookie && document.cookie.split(';')) || [];
  cookieList.forEach(str => {
    let [_key = '', _val = ''] = str.split('=') || [];
    if (_key.trim() === keyName) {
      result = _val;
    }
  });

  return result.trim();
};
/**
 * 监听事件对象
 */
window.narutoEvent = (function(window) {
  let eventListObj = {};
  let ignoreEventListObj = {};
  return {
    /**
     * 只监听一次
     */
    once(eventName, callback) {
      this.listen.call(this, eventName, callback, true);
    },
    /**
     * 监听事件<eventName: String 监听事件名, callback: function 回调函数, once: boolean 是否监听一次>
     */
    listen(eventName, callback, once = false) {
      if (!eventName || !callback) {
        return;
      }
      !eventListObj[eventName] && (eventListObj[eventName] = []);
      eventListObj[eventName].push({
        callback,
        once,
      });
    },
    /**
     * 监听事件, 之前未消费的消息也会进行触发<eventName: String 监听事件名, callback: function 回调函数, once: boolean 是否监听一次>
     */
    listenAllTask() {
      const self = this;
      const argsList = Array.prototype.slice.call(arguments);
      const eventName = argsList[0];

      if (!eventName) {
        return;
      }
      //监听事件
      self.listen(...argsList);

      //判断是否有未消费的消息
      if (ignoreEventListObj[eventName] && ignoreEventListObj[eventName].length > 0) {
        const eventObj = ignoreEventListObj[eventName].pop();
        self.trigger.apply(eventObj.self, eventObj.argsList);
      }
    },
    /**
     * 触发事件
     */
    trigger() {
      const self = this;
      let argsList = Array.prototype.slice.call(arguments);
      const eventName = argsList.shift();
      //如果还没有订阅消息, 将其放到未消费队列里
      if (!eventListObj[eventName]) {
        !ignoreEventListObj[eventName] && (ignoreEventListObj[eventName] = []);
        ignoreEventListObj[eventName].push({
          argsList: Array.prototype.slice.call(arguments),
          self,
        });
        return;
      }

      let newList = [];
      eventListObj[eventName].forEach((_obj, index) => {
        if (Object.prototype.toString.call(_obj.callback) !== '[object Function]') {
          return;
        }
        _obj.callback.apply(self, argsList);
        //删除只触发一次的事件
        if (!_obj.once) {
          newList.push(_obj);
        }
      });
      eventListObj[eventName] = newList;
    },
    /**
     * 删除监听事件
     */
    remove(eventName, callback) {
      if (!eventName || !eventListObj[eventName]) {
        return;
      }
      if (!callback) {
        eventListObj[eventName] = null;
      } else {
        let newList = [];
        eventListObj[eventName].forEach((_obj, index) => {
          if (_obj.callback !== callback) {
            newList.push(_obj);
          }
        });
        eventListObj[eventName] = newList.length ? newList : null;
      }
    },
  };
})(window);
/**
 * Naruto的工具类
 */
window.narutoUtils = (function(window) {
  let loadingCount = 0;
  let loadingState = {
    visible: false,
    shape: 'flower',
    tip: 'loading...',
    // color: "#333",
    // style: { height: "100%", width: "100%" }
  };
  return {
    /**
     * 改变loading 的样式
     */
    changeLoadingAttr(obj) {
      if (Object.prototype.toString.call(obj) === '[object Object]') {
        loadingState = Object.assign({}, loadingCount, obj);
      }
    },
    /**
     * 打开loading效果
     */
    openLoading() {
      loadingCount++;
      window.narutoEvent.trigger(
        'narutoLoadingEvent',
        Object.assign(loadingState, {
          visible: true,
          spinning: true,
        })
      );
    },
    /**
     * 尝试关闭loading, 只有当loadingCount小于0时才会关闭loading效果
     */
    closeLoading() {
      loadingCount--;
      if (loadingCount <= 0) {
        loadingCount = 0;
        window.narutoEvent.trigger(
          'narutoLoadingEvent',
          Object.assign(loadingState, {
            visible: false,
            spinning: false,
          })
        );
      }
    },
    /**
     * 关闭loading效果
     */
    closeAllLoading() {
      loadingCount = 0;
      window.narutoEvent.trigger(
        'narutoLoadingEvent',
        Object.assign(loadingState, {
          visible: false,
          spinning: false,
        })
      );
    },
    /**
     * 获取资源地址, 如果资源需要静态化输出 请调用此方法
     */
    getURISource(url) {
      return url;
    },
    /**
     * 升级导航结构
     */
    upgradeNavStruct(data = [], index = 0) {
      return data.map(item => {
        let { id, title, isVirtual, link = '', children, dontUseChild, isExtend, ...other } = item;
        // 如果没有id 则表示是新结构 直接返回
        if (!id) {
          item.title = window.aliwareIntl.get(item.key) || item.title;
          return item;
        }
        let type;
        if (link && link.indexOf('http') === 0) {
          type = 'link';
        } else {
          if (index === 0 && children && children.length && isVirtual) {
            type = 'title';
          }
          // 如果link有值 则表示是一个link节点
          link && (id = link);
        }
        let navObj = {
          key: `/${id}`,
          title: window.aliwareIntl.get(id) || title,
          type,
          url: link,
          hide: !!dontUseChild,
          open: !!isExtend,
          ...other,
        };
        children &&
          (navObj[isVirtual ? 'subNav' : 'navs'] = this.upgradeNavStruct(children, index + 1));

        return navObj;
      });
    },
  };
})(window);

window.aliwareIntl = (function(window) {
  /**
   * 国际化构造方法
   * @param {Object} options 配置信息
   */
  function aliwareI18n(options) {
    // let currentLocal = options.currentLocal || navigator.language || navigator.userLanguage;

    let nowData = options.locals;
    this.nowData = nowData;
    this.setMomentLocale(this.currentLanguageCode);
  }
  let aliwareLocal = window.aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
  let aliwareLocalSite = window.aliwareGetCookieByKeyName('aliyun_country') || 'cn';
  aliwareLocal = aliwareLocal.toLowerCase();
  aliwareLocalSite = aliwareLocalSite.toLowerCase();
  //当前语言
  aliwareI18n.prototype.currentLocal = aliwareLocal;
  //当前地区
  aliwareI18n.prototype.currentSite = aliwareLocalSite;
  //当前语言-地区
  aliwareI18n.prototype.currentLanguageCode = `${aliwareLocal}-${aliwareLocalSite}`;
  /**
   * 通过key获取对应国际化文案
   * @param {String} key 国际化key
   */
  aliwareI18n.prototype.get = function(key) {
    return this.nowData[key];
  };
  /**
   * 修改国际化文案数据
   * @param {String} local 语言信息
   */
  aliwareI18n.prototype.changeLanguage = function(local) {
    this.nowData = window[`i18n_${local}_doc`] || {};
  };
  /**
   * 数字国际化
   * @param {Number} num 数字
   */
  aliwareI18n.prototype.intlNumberFormat = function(num) {
    if (typeof Intl !== 'object' || typeof Intl.NumberFormat !== 'function') {
      return num;
    }
    try {
      return new Intl.NumberFormat(this.currentLanguageCode).format(num || 0);
    } catch (error) {
      return num;
    }
  };
  /**
   * 时间戳格式化
   * @param {Number} num 时间戳
   * @param {Object} initOption 配置信息
   */
  aliwareI18n.prototype.intlTimeFormat = function(num = Date.now(), initOption = {}) {
    try {
      let date = Object.prototype.toString.call(num) === '[object Date]' ? num : new Date(num);
      let options = Object.assign(
        {},
        {
          // weekday: "short",
          hour12: false,
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: 'numeric',
          minute: 'numeric',
          second: 'numeric',
        },
        initOption
      );
      return date.toLocaleDateString(this.currentLanguageCode, options);
    } catch (error) {
      return typeof moment === 'function' ? moment(num).format() : '--';
    }
  };
  /**
   * 获取当前时间格式
   * @param {String} language 语言信息: zh/en
   */
  aliwareI18n.prototype.getIntlTimeFormat = function(language) {
    language = language || aliwareLocal;
    let langObj = {
      zh: 'YYYY年M月D日 HH:mm:ss',
      en: 'MMM D, YYYY, h:mm:ss A',
      default: 'YYYY-MM-DD HH:mm:ss',
    };
    return langObj[language] ? langObj[language] : langObj.default;
  };
  /**
   * 设置moment的locale
   * @param {String} languageCode 语言信息: zh-ch/en-us
   */
  aliwareI18n.prototype.setMomentLocale = function(languageCode) {
    if (Object.prototype.toString.call(moment) === '[object Function]') {
      moment.locale(languageCode || this.currentLanguageCode);
      return true;
    }
    return false;
  };

  return new aliwareI18n({
    currentLocal: `${aliwareLocal}`,
    locals:
      window[`i18n_${aliwareLocal}_doc`] ||
      window.i18n_en_doc ||
      (window.i18ndoc && window.i18ndoc[aliwareLocal]) ||
      {},
  });
})(window);

window.getParams = function(name) {
  let reg = new RegExp(`(^|&)${name}=([^&]*)(&|$)`, 'i');
  let result = [];
  if (window.location.hash !== '') {
    result = window.location.hash.split('?'); //优先判别hash
  } else {
    result = window.location.href.split('?');
  }

  if (result.length === 1) {
    try {
      result = window.parent.location.hash.split('?');
    } catch (error) {
      console.error(error, result);
    }
  }

  if (result.length > 1) {
    let r = result[1].match(reg);
    if (r != null) {
      return decodeURIComponent(r[2]);
    }
  }

  return null;
};

window.setParam = function(name, value) {
  return window.setParams.apply(this, arguments);
};

window.setParams = (function(window) {
  const _originHref = window.location.href.split('#')[0];
  return function(name, value) {
    if (!name) {
      return;
    }

    let obj = {};
    if (typeof name === 'string') {
      obj = {
        [name]: value,
      };
    }

    if (Object.prototype.toString.call(name) === '[object Object]') {
      obj = name;
    }

    let hashArr = [];
    if (window.location.hash) {
      hashArr = window.location.hash.split('?');
    }

    let paramArr = (hashArr[1] && hashArr[1].split('&')) || [];

    let paramObj = {};
    paramArr.forEach(val => {
      let tmpArr = val.split('=');
      paramObj[tmpArr[0]] = decodeURIComponent(tmpArr[1] || '');
    });
    paramObj = Object.assign({}, paramObj, obj);

    let resArr =
      Object.keys(paramObj).map(key => {
        return `${key}=${encodeURIComponent(paramObj[key] || '')}`;
      }) || [];

    hashArr[1] = resArr.join('&');
    let hashStr = hashArr.join('?');
    if (window.history.replaceState) {
      let url = _originHref + hashStr;
      window.history.replaceState(null, '', url);
    } else {
      window.location.hash = hashStr;
    }
  };
})(window);

window.removeParams = (function(window) {
  const _originHref = window.location.href.split('#')[0];
  return function(name) {
    let removeList = [];

    let nameType = Object.prototype.toString.call(name);
    if (nameType === '[object String]') {
      removeList.push(name);
    } else if (nameType === '[object Array]') {
      removeList = name;
    } else if (nameType === '[object Object]') {
      removeList = Object.keys(name);
    } else {
      return;
    }

    let hashArr = [];
    if (window.location.hash) {
      hashArr = window.location.hash.split('?');
    }

    let paramArr = (hashArr[1] && hashArr[1].split('&')) || [];

    // let paramObj = {};
    paramArr = paramArr.filter(val => {
      let tmpArr = val.split('=');
      return removeList.indexOf(tmpArr[0]) === -1;
    });

    hashArr[1] = paramArr.join('&');
    let hashStr = hashArr.join('?');
    if (window.history.replaceState) {
      let url = _originHref + hashStr;
      window.history.replaceState(null, '', url);
    } else {
      window.location.hash = hashStr;
    }
  };
})(window);

window.request = (function(window) {
  let middlewareList = [];
  let middlewareBackList = [];
  let serviceMap = {};
  let serviceList = serviceConfig.serviceList || [];
  let methodList = serviceConfig.method || [];
  /**
   * 获取真实url信息
   */
  let NarutoRealUrlMapper = (function() {
    serviceList.forEach(obj => {
      serviceMap[obj.registerName] = obj;
    });
    return function(registerName) {
      let serviceObj = serviceMap[registerName];
      if (!serviceObj) {
        return null;
      }
      //获取正确请求方式
      serviceObj.methodType = methodList[serviceObj.method];
      return serviceObj;
    };
  })();
  /**
   * 添加中间件函数
   * @param {*function} callback 回调函数
   */
  function middleWare(callback, isBack = true) {
    if (isBack) {
      middlewareBackList.push(callback);
    } else {
      middlewareList.push(callback);
    }
    return this;
  }
  /**
   * 处理中间件
   * @param {*Object} config ajax请求配置信息
   */
  function handleMiddleWare(config) {
    //获取除config外传入的参数
    let args = [].slice.call(arguments, 1);
    //最后一个参数为middlewareList
    let middlewareList = args.pop() || [];
    if (middlewareList && middlewareList.length > 0) {
      config = middlewareList.reduce((config, callback) => {
        if (typeof callback === 'function') {
          return callback.apply(this, [config, ...args]) || config;
        }
        return config;
      }, config);
    }
    return config;
  }
  /**
   * 处理自定义url
   * @param {*Object} config ajax请求配置信息
   */
  function handleCustomService(config) {
    //只处理com.alibaba.开头的url
    if (config && config.url && config.url.indexOf('com.alibaba.') === 0) {
      let registerName = config.url;
      let serviceObj = NarutoRealUrlMapper(registerName);
      if (serviceObj && serviceObj.url && serviceObj.url.replace) {
        //有mock数据 直接返回 生产环境失效
        if (projectConfig.is_preview && serviceObj.is_mock && config.success) {
          let code = null;
          eval(`code = ${serviceObj.defaults};`);
          config.success(code);
          return;
        }
        //替换url中的占位符
        config.url = serviceObj.url.replace(/{([^\}]+)}/g, ($1, $2) => {
          return config.$data[$2];
        });
        try {
          //添加静态参数
          if (serviceObj.is_param && typeof config.data === 'object') {
            config.data = Object.assign({}, JSON.parse(serviceObj.params), config.data);
          }
        } catch (e) {
        }
        //替换请求方式
        if (serviceObj.method && config.type == null) {
          config.type = serviceObj.methodType;
        }
        //将请求参数变为json格式
        if (serviceObj.isJsonData && typeof config.data === 'object') {
          config.data = JSON.stringify(config.data);
          config.processData = false;
          config.dataType = 'json';
          config.contentType = 'application/json';
        }
        try {
          //设置临时代理 生产环境失效
          if (projectConfig.is_preview && serviceObj.is_proxy) {
            let beforeSend = config.beforeSend;
            config.beforeSend = function(xhr) {
              serviceObj.cookie && xhr.setRequestHeader('tmpCookie', serviceObj.cookie);
              serviceObj.header && xhr.setRequestHeader('tmpHeader', serviceObj.header);
              serviceObj.proxy && xhr.setRequestHeader('tmpProxy', serviceObj.proxy);
              beforeSend && beforeSend(xhr);
            };
          }
        } catch (e) {
          console.log(e);
        }
        //设置自动loading效果
        if (serviceObj.autoLoading) {
          window.narutoUtils.openLoading();
          const prevComplete = config.complete;
          config.complete = function() {
            window.narutoUtils.closeLoading();
            typeof prevComplete === 'function' &&
              prevComplete.apply($, Array.prototype.slice.call(arguments));
          };
        }
        //serviceObj = null;
      }
    }
    return config;
  }

  function Request(config) {
    //除了config外的传参
    let args = [].slice.call(arguments, 1);
    //处理前置中间件
    config = handleMiddleWare.apply(this, [config, ...args, middlewareList]);
    //处理自定义url
    config = handleCustomService.apply(this, [config, ...args]);
    if (!config) return;
    //xsrf
    if (
      config.type &&
      config.type.toLowerCase() === 'post' &&
      config.data &&
      Object.prototype.toString.call(config.data) === '[object Object]' &&
      !config.data.sec_token
    ) {
      let sec_token = window.aliwareGetCookieByKeyName('XSRF-TOKEN');
      sec_token && (config.data.sec_token = sec_token);
    }

    //处理后置中间件
    config = handleMiddleWare.apply(this, [config, ...args, middlewareBackList]);

    const X_MSE_ENV_KEY = sessionStorage.getItem('X-MSE-ENV-KEY');
    const currentEnvItem = find(X_MSE_ENV_ARR, { value: X_MSE_ENV_KEY }) || {};
    const ip = {
      mse: get(currentEnvItem, 'ip.mse', ''),
      edasmsc: get(currentEnvItem, 'ip.edasmsc', ''),
    };
    try {
      const AcceptLanguage = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
      if (config && config.data && config.data.params) {
        config.data.params = JSON.stringify(Object.assign({}, { AcceptLanguage }, JSON.parse(config.data.params)));
      } else {
        config.data.params = JSON.stringify(Object.assign({}, { AcceptLanguage }));
      }
      const MseSessionId = localStorage && localStorage.getItem('MseSessionId');
      if (MseSessionId) {
        try {
          config.data.params = JSON.stringify(Object.assign(JSON.parse(config.data.params), { MseSessionId }));
        } catch (e) {
          console.log(e);
        }
      }
    } catch (e) {
      console.log(e);
    }

    return window.$.ajax(
        _.assign({}, config, {
        type: config.type,
        url: config.url,
        data: config.data || '',
        dataType: config.dataType || 'json',
        // async: config.async == null ? true : config.async,
        // processData: config.processData == null ? true : config.processData,
        // contentType: config.contentType || 'application/x-www-form-urlencoded',
        beforeSend(xhr) {
          const action = get(config, 'data.action');
          xhr.setRequestHeader('poweredBy', 'naruto');
          xhr.setRequestHeader('projectName', projectConfig.projectName);
          IS_PRE_OR_LOCAL && action !== 'QueryBusinessLocations' && xhr.setRequestHeader('x-acs-debug-http-host', ip.mse || ''); // 这里是因为老接口都是mse的
          config.beforeSend && config.beforeSend(xhr);
        },
      })
    );
  }
  //暴露方法
  Request.handleCustomService = handleCustomService;
  Request.handleMiddleWare = handleMiddleWare;
  Request.NarutoRealUrlMapper = NarutoRealUrlMapper;
  Request.serviceList = serviceList;
  Request.serviceMap = serviceMap;
  Request.middleWare = middleWare;

  return Request;
})(window);

/**
 * 获取风控验证对象
 * @param {Object} metaData 风控参数对象
 * @param {Object} um um对象 需引入um.js
 * @param {Object} AWSC AWSC 需引入AWSC.js
 */
window.getRiskValidationObj = function getRiskValidationObj(
  metaData,
  um = window.um,
  AWSC = window.AWSC
) {
  const container = document.getElementById('_umfp');
  try {
    container.getElementsByTagName('img')[0].src = `${
      metaData.umidServerUrl
      }/service/clear.png?xt=${metaData.umidToken}&xa=${metaData.umidAppName}`;
  } catch (e) { }

  um.init({
    timeout: metaData.umidTimeout || 3000,
    token: metaData.umidToken,
    timestamp: metaData.umidTimestamp,
    serviceUrl: `${metaData.umidServerUrl}/service/um.json`,
    appName: metaData.umidAppName,
    containers: { flash: container, dcp: container },
  });

  let uabModule = {};
  AWSC.use('uab', (state, uab) => {
    if (state === 'loaded') {
      uabModule = uab;
      // let ua = uabModule.getUA();
      // console.log("ua: " + ua, uabModule.getUA);
    }
  });

  const getCollina = function() {
    return (
      uabModule &&
      uabModule.getUA &&
      uabModule.getUA({
        Token: `${new Date().getTime()}:${Math.random()}`,
        OnlyHost: 0,
      })
    );
  };

  return {
    uabModule,
    getCollina,
  };
};
