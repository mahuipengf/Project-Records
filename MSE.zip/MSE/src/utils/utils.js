import { parse, stringifyUrl, stringify } from 'query-string';

/**
 * 解析参数
 * @param {string} s 需要解析的字符串
 * @return {object} 参数对象
 */
export const parseQuery = (function (window) {
  return function (s = '') {
    return parse(s || window.self.location.search);
  };
})(window);

function getDefaultQuery(parsedQuery) {
  // 默认带上ns和region参数
  const defaultQuery = {};
  if (parsedQuery.ns) {
    defaultQuery.ns = parsedQuery.ns;
  }
  if (parsedQuery.region) {
    defaultQuery.region = parsedQuery.region;
  }
  return defaultQuery;
}

/**
 * 生成 URL
 * @param {object} query 参数对象
 * @param {string} href href
 * @param {boolean} mergeCurrentQuery 是否与当前query参数合并
 * @return {string} 拼装好的URL
 */
export const generateUrl = (query, href, mergeCurrentQuery = true) => {
  const currentQuery = parseQuery();
  // 默认带上ns和region参数
  const defaultQuery = getDefaultQuery(currentQuery);
  return stringifyUrl({
    url: href || window.self.location.href,
    query: Object.assign(mergeCurrentQuery ? currentQuery : defaultQuery, query),
  });
};

/**
 * 跳转路由
 * @param {any} history dva的history
 * @param {string} pathname 需要跳转的路由
 * @param {object} query 参数
 * @param {boolean} mergeCurrentQuery 是否与当前query参数合并
 */
export const pushUrl = (history, pathname, query, mergeCurrentQuery = true) => {
  const currentQuery = parseQuery();
  // 默认带上ns和region参数
  const defaultQuery = getDefaultQuery(currentQuery);
  history.push(
    `${pathname}?${stringify(
      Object.assign(mergeCurrentQuery ? currentQuery : defaultQuery, query)
    )}`
  );
};

/**
 * 获取 url params
 * @param {string} name 需要获取的参数名
 * @return {string | null} 参数值
 */
export const getParams = (name) => {
  const parsed = parseQuery();
  const res = parsed[name];
  if (res) {
    return res === 'undefined' || res === 'null' || res === 'false'
      ? null
      : decodeURIComponent(res);
  }
  return null;
};

/**
 * 动态设置 url params
 * @param {string} name 需要设置的参数名
 * @param {any} value 需要设置的参数值
 */
// export const setParams = (function(window) {
//   return function(name, value) {
//     const _originHref = window.location.origin + window.location.pathname;
//     if (!name) {
//       return;
//     }

//     let query = {};
//     if (typeof name === 'string') {
//       query = {
//         [name]: value,
//       };
//     }
//     if (Object.prototype.toString.call(name) === '[object Object]') {
//       query = name;
//     }

//     const parsed = parseQuery();
//     const historyStr = `?${stringify(Object.assign({}, parsed, query))}`;

//     if (window.history.replaceState) {
//       const url = _originHref + historyStr;
//       window.history.replaceState(null, '', url);
//     } else {
//       window.location.hash = historyStr;
//     }
//   };
// })(window);
export const setParams = (function (window) {
  const _originHref = window.self.location.href.split('#')[0];
  return function (name, value) {
    if (!name) {
      return;
    }

    let obj = {};
    if (typeof name === 'string') {
      obj = {
        [name]: value,
      };
    }

    if (Object.prototype.toString.call(name) === '[object Object]') {
      obj = name;
    }

    let hashArr = [];
    if (window.self.location.hash) {
      hashArr = window.self.location.hash.split('?');
    }

    let paramArr = (hashArr[1] && hashArr[1].split('&')) || [];

    let paramObj = {};
    paramArr.forEach((val) => {
      let tmpArr = val.split('=');
      paramObj[tmpArr[0]] = decodeURIComponent(tmpArr[1] || '');
    });
    paramObj = Object.assign({}, paramObj, obj);

    let resArr =
      Object.keys(paramObj).map((key) => {
        return `${key}=${encodeURIComponent(paramObj[key] || '')}`;
      }) || [];

    hashArr[1] = resArr.join('&');
    let hashStr = hashArr.join('?');
    if (window.history.replaceState) {
      let url = _originHref + hashStr;
      window.history.replaceState(null, '', url);
    } else {
      window.self.location.hash = hashStr;
    }
  };
})(window);
/**
 * 动态删除 url params
 * @param {string} name 需要删除的参数名，不传name则删除所有参数
 */
export const removeParams = (function (window) {
  const _originHref = window.self.location.href.split('#')[0];
  return function (name) {
    let removeList = [];

    let nameType = Object.prototype.toString.call(name);
    if (nameType === '[object String]') {
      removeList.push(name);
    } else if (nameType === '[object Array]') {
      removeList = name;
    } else if (nameType === '[object Object]') {
      removeList = Object.keys(name);
    } else {
      return;
    }

    let hashArr = [];
    if (window.self.location.hash) {
      hashArr = window.self.location.hash.split('?');
    }

    let paramArr = (hashArr[1] && hashArr[1].split('&')) || [];

    // let paramObj = {};
    paramArr = paramArr.filter((val) => {
      let tmpArr = val.split('=');
      return removeList.indexOf(tmpArr[0]) === -1;
    });

    hashArr[1] = paramArr.join('&');
    let hashStr = hashArr.join('?');
    if (window.history.replaceState) {
      let url = _originHref + hashStr;
      window.history.replaceState(null, '', url);
    } else {
      window.self.location.hash = hashStr;
    }
  };
})(window);

export const compareVersion = (v1, v2) => {
  let arr1 = v1.split('.'),
    arr2 = v2.split('.');
  let maxLength = Math.max(arr1.length, arr2.length);
  for (let i = 0; i < maxLength; ++i) {
    let num1 = i < arr1.length ? parseInt(arr1[i], 10) : 0;
    let num2 = i < arr2.length ? parseInt(arr2[i], 10) : 0;
    if (num1 === num2) {
      // eslint-disable-next-line no-continue
      continue;
    }
    //v1>v2 返回1，v1<v2 返回-1， v1=v2 返回0
    return num1 > num2 ? 1 : -1;
  }
  return 0;
};

export function compare(curV, reqV) {
  if (curV && reqV) {
    const arr1 = curV.split('.'),
      arr2 = reqV.split('.');
    const minLength = Math.min(arr1.length, arr2.length);
    let position = 0,
      diff = 0;
    while (position < minLength && ((diff = parseInt(arr1[position]) - parseInt(arr2[position])) === 0)) {
      position++;
    }
    diff = (diff !== 0) ? diff : (arr1.length - arr2.length);
    return diff >= 0;
  }
  return false;
}

export const compareNacosVersion = () => {
  // NACOS_2_1_2_1
  const t = 2121;
  const v = localStorage.getItem('ClusterVersion');
  const a = v.split('_') || [];
  a.shift();
  const c = parseInt(a.join(''), 10) || 0;
  return c >= t;
};

export default {
  parseQuery,
  generateUrl,
  pushUrl,
  getParams,
  setParams,
  removeParams,
  compareVersion,
  compare,
  compareNacosVersion,
};
