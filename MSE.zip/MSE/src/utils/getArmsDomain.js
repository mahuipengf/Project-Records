import { getCurrentRegion } from 'utils';

export const getArmsDomain = () => {
    const regionId = getCurrentRegion();
    return regionId === 'cn-north-2-gov-1' ? 'arms-gov.console.aliyun.com' : 'arms.console.aliyun.com';
};