import moment from 'moment';
import Cookies from 'js-cookie';
import createLoader, { getEventEmitter } from '@ali/widget-loader';
import { WIDGET_EDAS_MSE, WIDGET_EDAS_MSC, WIDGET_MSE_MST, WIDGET_EDAS_MICROGW, WIDGET_EDAS_SEATA } from '../constants';

const lang = {
  en: 'en-US', // 英语
  zh: 'zh-CN', // 汉语
  ja: 'ja-JP', // 日语
  'zh-TW': 'zh-TW', // 繁体中文
  'zh-HK': 'zh-HK', // 繁体中文香港
};

const getCurrentlang = () => {
  let language = Cookies.get('aliyun_lang') || Cookies.get('inner_oneconsole_lang') || 'en';
  // 兼容取值 zh-TW 的case
  if (language.startsWith('zh')) {
    language = 'zh';
  }
  if (language.startsWith('en')) {
    language = 'en';
  }
  if (language.startsWith('ja')) {
    language = 'ja';
  }
  return lang[language] || lang.en;
};

let lodaerWidgetObj = {
  // host: 'https://dev.g.alicdn.com', // 默认 https://g.alicdn.com
  // configHost: 'https://cws.aliyun-inc.com', // 默认 https://cws.alicdn.com
  initiator: 'mse',
  dependencies: {
    lodash: _,
    moment,
    '@ali/widget-utils-console': {
      getLocale() {
        return getCurrentlang();
      },
      getChannel: () => 'OFFICIAL',
      getCurrentUid: () => '00',
      getParentUid: () => '00',
      getAccountType: () => 'main',
      getRegionName: (id) => id,
      getZoneName: (id) => id,
    },
  },
};
window.ALIYUN_CONSOLE_GLOBAL = window.ALIYUN_CONSOLE_GLOBAL || {};
// 兼容预发版本widget本地跨域
if (window.ALIYUN_CONSOLE_GLOBAL.environment !== 'production') {
  lodaerWidgetObj.host = 'https://dev.g.alicdn.com'; // 默认 https://g.alicdn.com
  lodaerWidgetObj.configHost = 'https://cws.aliyun-inc.com'; // 默认 https://cws.alicdn.com
}
const loadWidget = createLoader({ ...lodaerWidgetObj });
const eventEmitter = getEventEmitter();

const Widget = loadWidget(WIDGET_EDAS_MSE);
const MscWidget = loadWidget(WIDGET_EDAS_MSC);
const MstWidget = loadWidget(WIDGET_MSE_MST);
const MicrogwWidget = loadWidget(WIDGET_EDAS_MICROGW);
const SeataWidget = loadWidget(WIDGET_EDAS_SEATA);


export { eventEmitter, Widget, MscWidget, MstWidget, MicrogwWidget, SeataWidget };
export default loadWidget;
