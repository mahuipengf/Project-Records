import mseConsoleService from './mseAxios';
import { Message, customRequest } from '@ali/cn-design';
import { has, isEmpty, toLower, get, find } from 'lodash';
import { upperFirstData1 } from '../transfer-data';
import { IS_PRE_OR_LOCAL, X_MSE_ENV_ARR } from '../../constants';
import CooKie from 'js-cookie';

interface IRequest {
  product?: any,
  action?: any,
  method?: any,
  headers?: any,
  popContentType?: any,
  url?: any,
}
const regionId = window.regionId || '';
const { getParams } = window;
window.ALIYUN_CONSOLE_GLOBAL = window.ALIYUN_CONSOLE_GLOBAL || {};

const edasService = customRequest();
const consoleService = customRequest({
  request: (config: any) => {
    const { data = {}, params = {}, method } = config;
    const newData = { ...data };
    let newParams = { ...params, regionId, ahasRegionId: regionId };
    const mseSessionId = localStorage.getItem('MseSessionId');

    if (!isEmpty(newData)) {
      newData.source = newData.source || 'edasmsc';
      if (has(newData, 'namespaceId')) {
        newData.namespace = newData.namespaceId;
        delete newData.namespaceId;
      }
      if (has(newData, 'regionId')) {
        newData.region = newData.regionId;
        delete newData.regionId;
      }
      if (mseSessionId) {
        newData.MseSessionId = mseSessionId;
      }
    }

    if (!isEmpty(newParams)) {
      newParams.source = newParams.source || 'edasmsc';
      if (has(newParams, 'namespaceId')) {
        newParams.namespace = newParams.namespaceId;
      }
      if (has(newParams, 'regionId')) {
        newParams.region = newParams.regionId;
        // delete newParams.regionId;
      }
      if (mseSessionId) {
        newParams.MseSessionId = mseSessionId;
      }
    } else if (toLower(method) === 'post' && !isEmpty(newData) && isEmpty(newParams)) {
      newParams = newData;
    }
    
    // const GlobalNamespace = CooKie.get('GlobalNamespace') ? JSON.parse(CooKie.get('GlobalNamespace')) : {};
    const ns = getParams('ns');

    // if (GlobalNamespace && GlobalNamespace.namespace) {
    //   newParams.namespace = ns || GlobalNamespace?.namespace || '';
    // }
    if (ns) {
      newParams.namespace = ns || '';
    }
    return {
      ...config,
      data: {
        region: regionId,
        params: upperFirstData1(newParams),
      },
    };
  },
  response: (res: any) => {
    return res;
  },
});

const request = ({ action, product = 'mse', method = 'get', headers = {} }: IRequest) => {
  // 判断预发环境header
  // 兼容MSE开发环境env host
  const X_MSE_ENV_KEY = sessionStorage.getItem('X-MSE-ENV-KEY');

  const currentEnvItem = find(X_MSE_ENV_ARR, { value: X_MSE_ENV_KEY }) || {};
  const ip = {
    mse: get(currentEnvItem, 'ip.mse', ''),
    edasmsc: get(currentEnvItem, 'ip.edasmsc', ''),
  };
  const hostHeader = { 'x-acs-debug-http-host': ip[product] || '' };
  return consoleService({
    product,
    action,
    method,
    headers: IS_PRE_OR_LOCAL ? hostHeader : headers, // 正常应该拿到headers，但目前pop headers加了'Content-Type': 'application/json' 会导致异常，后续需要优化
    popContentType: 'application/json',
  });
};
export default request;
// 原ahas接口请求  dva
// export const ahasMseRequest = (productName: any, params: any) => {
//   return request({
//     action: params,
//     product: productName,
//     method: 'post',
//   });
// };

export const mseAxios = (props: any) => { // 自定义pop请求
  const { productName = 'mse', action, method = 'get', url, headers = {} } = props;
  // 兼容MSE开发环境env host
  const X_MSE_ENV_KEY = sessionStorage.getItem('X-MSE-ENV-KEY');

  const currentEnvItem = find(X_MSE_ENV_ARR, { value: X_MSE_ENV_KEY }) || {};
  const ip = {
    mse: get(currentEnvItem, 'ip.mse', ''),
    edasmsc: get(currentEnvItem, 'ip.edasmsc', ''),
  };
  const hostHeader = { 'x-acs-debug-http-host': ip[productName] || '' };
  const option = {
    product: productName,
    action,
    method: 'post',
    popUrl: '/data/api.json',
    headers: IS_PRE_OR_LOCAL ? hostHeader : headers, // 正常应该拿到headers，但目前pop headers加了'Content-Type': 'application/json' 会导致异常，后续需要优化
  };
  const interceptors: any = {
    request: (config: any) => {
      const { data = {}, params = {}, method } = config;
      const newData = { ...data };
      const mseSessionId = localStorage.getItem('MseSessionId');
      // const GlobalNamespace = CooKie.get('GlobalNamespace') ? JSON.parse(CooKie.get('GlobalNamespace')) : {};
      const ns = getParams('ns');

      // console.log("JSON.parse(CooKie.get('GlobalNamespace'))", JSON.parse(CooKie.get('GlobalNamespace')));
      // Namespace: 'default'
      let newParams = { ...params, regionId, Source: 'edasmsc' };
      if (!isEmpty(newData)) {
        newData.source = newData.source || 'edasmsc';
        if (has(newData, 'namespaceId')) {
          newData.namespace = newData.namespaceId;
          delete newData.namespaceId;
        }
        if (has(newData, 'regionId')) {
          newData.region = newData.regionId;
          delete newData.regionId;
        }
      }
      if (!isEmpty(newParams)) {
        newParams.source = newParams.source || 'edasmsc';
        if (has(newParams, 'namespaceId')) {
          newParams.namespace = newParams.namespaceId;
        }
        if (has(newParams, 'regionId')) {
          newParams.region = newParams.regionId;
          // delete newParams.regionId;
        }
      } else if (toLower(method) === 'post' && !isEmpty(newData) && isEmpty(newParams)) {
        newParams = newData;
      }
      if (mseSessionId) {
        newParams.MseSessionId = mseSessionId;
      }
      // if (GlobalNamespace && GlobalNamespace.namespace) {
      //   newParams.namespace = ns || GlobalNamespace?.namespace || '';
      // }
      if (newParams.Namespace) {
        newParams.namespace = newParams.Namespace
      } else if (ns) {
        newParams.namespace = ns || '';
      }
      return {
        ...config,
        data: {
          region: regionId,
          params: upperFirstData1(newParams),
        },
      };
    },
    response: (res: any) => {
      const { message, httpStatusCode } = res || {};
      if (httpStatusCode < '200' || httpStatusCode >= '300') {
        Message.error(message); // 接口错误信息
        return;
      }
      return res || {}; // 返回所有数据
    },
  };
  if (url) {
    const newParams = { method, url, headers };
    return edasService(newParams);
  }
  return mseConsoleService(option, interceptors);
};
export const ahasMseRequest = (productName: any, params: any) => {
  return mseAxios({
    action: params,
    productName,
    method: 'post',
  });
};

