import _ from 'lodash';
import axios from './axios';
// import createServer from './decorate';
import newRequest from './newService';
import { getCookie } from '@ali/console-base-cookie';

const getParams = window.getParams;

const extraHeaders = {
  headers: {
    'X-Requested-With': 'XMLHttpRequest',
    // 'x-acs-debug-http-host': '100.100.64.103:17819',
    region: getCookie('currentRegionId') || getParams('region') || 'cn-hangzhou',
  },
};

export const GetServiceMethodPageWithMetrics = newRequest(_.assign({}, {
  product: 'mse',
  action: 'GetServiceMethodPageWithMetrics',
  method: 'post',
}, extraHeaders));

export const fetchServicesList = newRequest(_.assign({}, {
  product: 'mse',
  // url: '/sp/api/mse/getServiceListPage',
  action: 'GetServiceListPage',
  method: 'post',
}, extraHeaders));

export const getQuerySentinelMetricsOfResource = newRequest(_.assign({}, {
  product: 'mse',
  // url: 'http://cn-heyuan.arms.aliyuncs.com:9090/api/v1/prometheus/62a25a4f34b0f96f332c73c99a917cdd/1713924715736867/b2uz4m0un8/cn-heyuan/api/v1/query_range?',
  url: '/api/v1/prometheus/62a25a4f34b0f96f332c73c99a917cdd/1713924715736867/b2uz4m0un8/cn-heyuan/api/v1/query_range?',
  // params: 'resourceTimeSeries{appName=%22spring-cloud-c%22,%20namespace=%22default%22,%20resource=%22__total_inbound_traffic__%22,statisticsType=~%22blockedQps|passedQps|exception|grayQps%22,%20userId=%221853548619253853%22}&start=1656404926&end=1656405166&step=1',
  method: 'get',
}, extraHeaders));

export const getEcsMarkdown = axios({
  url: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/install_package/edasmsc-ecs.md',
});
export const getAcsMarkdown = axios({
  url: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/install_package/edasmsc-ack.md',
});
export const getEdasMarkdown = axios({
  url: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/install_package/edasmsc-edas.md',
});

export const getlosslessMarkdown = axios({
  url: 'https://edas-public.oss-cn-hangzhou.aliyuncs.com/install_package/edasmsc-graceful-shutdown.md',
});

// export const CreateLicenseKey = newRequest({
//   action: 'CreateLicenseKey',
// });

// export const CreateLicenseKey = createServer(_.assign({}, {
//   action: 'CreateLicenseKey',
// }, extraHeaders));

export const CreateLicenseKey = newRequest({
  action: 'CreateLicenseKey',
});


// export const CheckOpenArms = newRequest(_.assign({}, {
//   product: 'ahas',
//   action: 'CheckOpenArms',
//   method: 'post',
// }, extraHeaders));

// export const OpenArmsService = newRequest(_.assign({}, {
//   product: 'ahas',
//   action: 'OpenArmsService',
//   method: 'post',
// }, extraHeaders));

// export const CheckReadFromProm = newRequest(_.assign({}, {
//   product: 'ahas',
//   action: 'CheckReadFromProm',
//   method: 'post',
// }, extraHeaders));
