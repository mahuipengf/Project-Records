import React, { useState } from 'react';
import {
  ResponseBizDataCodeError,
  ResponseDataCodeError,
  ResponseDataReferenceError,
  ResponseRiskError,
} from '../errors';
import { SUCCESS_LIST } from '../constants';
import { includes, isUndefined, get } from 'lodash';
import intl from '@ali/wind-intl';
import { Message, Dialog, Button, Icon } from '@alicloud/console-components';
import { CopyContent } from '@ali/mamba';


export default (response) => {
  let requestParams = {};
  /**错误映射 */
  const errorEnum = {
    noPermission: {
      code: 'NoPermission',
      message: intl('mse.common.nopermission'),
    },
    invalidParameter: {
      code: 'InvalidParameter',
      message: intl('mse.common.invalid_param'),
    },
    illegalRequest: {
      code: 'IllegalRequest',
      message: intl('mse.common.illegal_req'),
    },
    notFound: {
      code: 'NotFound',
      message: intl('mse.common.not_found'),
    },
    internalError: {
      code: 'InternalError',
      message: intl('mse.common.internal_err'),
    },
    serviceNotOpen: {
      code: 'MseServiceNotOpen',
      url: intl('mse.common.service_not_open'),
    },
    serviceUnavailable: {
      code: 'ServiceUnavailable',
      message: intl('mse.common.service_unavailable'),
    },
    needLogin: {
      code: 'ConsoleNeedLogin',
      url: 'https://account.aliyun.com/login/login.htm?oauth_callback=',
    },
    needBuy: {
      code: 'RedirectToCommonBuy',
      url: intl('mse.common.service_not_open'),
    },
    openAHASServiceFailed: {
      code: 'OpenAHASServiceFailed',
      message: intl('mse.errormessage.ahas_failed'),
    },
    demoNoOpt: {
      code: 'demo.not.support.operation',
    },
    postonlyOrTokenError: {
      code: 'PostonlyOrTokenError',
    },
    changeRegionError: {
      code: 'SERVER_ERROR_CODE',
      message: intl('mse.errormessage.region'),
    },
    verifyCodeInvalid: {
      code: 'verifyCodeInvalid',
      message: intl('mse.errormessage.code_invalid'),
    },
    missingClusterId: {
      code: 'MissingClusterId',
      message: intl('mse.errormessage.miss_clusterid'),
    },
    riskShow: {
      code: 'FoundRiskAndDoubleConfirm',
    },
  };

  const ErrorComp = ({ content, res }) => {
    const [isShow, setIsShow] = useState(false);
    const errorMessage = {
      action: `${window.location.origin}${requestParams.url}/${requestParams.action}` || '',
      product: get(requestParams, 'product') || '',
      requestId: res.requestId || res.RequestId || '',
      params: JSON.stringify(get(requestParams, 'params')),
    };
    return (
      <div style={{ lineHeight: '20px', minWidth: 460 }}>
        <div>{content}</div>
        <If condition={res}>
          <CopyContent text={JSON.stringify(errorMessage)} visibility>
            <div style={{ display: 'inline' }}>
              <span>
                {intl('mse.common.error_detail')}
                <span style={{ color: '#0077cc' }}>{res.code || res.ErrorCode}</span>）
              </span>
              <Icon
                size="xs"
                type="arrow-down"
                onClick={() => setIsShow(!isShow)}
                style={{
                  transform: isShow ? 'rotate(0deg)' : 'rotate(-90deg)',
                  cursor: 'pointer',
                  transition: 'transform 0.3s cubic-bezier(0.23, 1, 0.32, 1)',
                  color: '#999',
                }}
              />
            </div>
          </CopyContent>
        </If>

        <If condition={isShow}>
          <div style={{ lineHeight: '20px' }}>
            {Object.entries(errorMessage).map(([key, value]) => {
              if (value && value.length > 0) {
                return (
                  <div>
                    {key}: {value}
                  </div>
                );
              }
              return null;
            })}
          </div>
        </If>
      </div>
    );
  };

  window.showErrorMessage = function showErrorMessage(content, options, res) {
    if (!window.dialogRef) {
      window.dialogRef = Dialog.alert({
        content: <ErrorComp content={content} options={options} res={res} />,
        title: intl('mse.errormessage.wrong'),
        footer: (
          <div>
            <Button
              type={'primary'}
              onClick={() => {
                window.dialogRef.hide();
                window.dialogRef = null;
              }}
            >
              {intl('mse.errormessage.confirm')}
            </Button>
          </div>
        ),
        onClose: () => {
          window.dialogRef.hide();
          window.dialogRef = null;
        },
        language: aliwareIntl.currentLanguageCode,
      });
    }
  };

  const consoleExpHanlder = {
    //子账号无权限
    [errorEnum.noPermission.code]: (data, options, res) => {
      window.showErrorMessage(res.message || errorEnum.noPermission.message, options, res);
    },
    //非法参数
    [errorEnum.invalidParameter.code]: (data, options, res) => {
      window.showErrorMessage(res.message || errorEnum.invalidParameter.message, options, res);
    },
    //请求非法：参数越权、用法错误
    [errorEnum.illegalRequest.code]: (data, options, res) => {
      window.showErrorMessage(res.message || errorEnum.illegalRequest.message, options, res);
    },
    //找不到集群
    [errorEnum.notFound.code]: (data, options, res) => {
      window.showErrorMessage(res.message || errorEnum.notFound.message, options, res);
    },
    //兜底错误
    [errorEnum.internalError.code]: (data, options, res) => {
      window.showErrorMessage(res.message || errorEnum.internalError.message, options, res);
    },
    //需要开通
    [errorEnum.serviceNotOpen.code]: () => {
      window.location.href = errorEnum.serviceNotOpen.url;
    },
    // // 服务不可用
    [errorEnum.serviceUnavailable.code]: (data, options, res) => {
      window.showErrorMessage(res.message || errorEnum.serviceUnavailable.message, options, res);
    },
    // 跳转登陆页
    [errorEnum.needLogin.code]: () => {
      window.location.href = errorEnum.needLogin.url + window.location.href;
    },
    // 跳转购买页
    [errorEnum.needBuy.code]: () => {
      window.location.href = errorEnum.needLogin.url + window.location.href;
    },
    // 服务开通失败
    [errorEnum.openAHASServiceFailed.code]: () => {
      Message.warning({
        content: errorEnum.openAHASServiceFailed.message,
        style: { marginTop: '50px' },
        animation: false,
        duration: 4000,
      });
    },
    // token 过期处理
    [errorEnum.postonlyOrTokenError.code]: () => {
      window.reloadDialog(intl('mse.errormessage.token_error'));
    },
    [errorEnum.missingClusterId.code]: () => {
      window.showErrorMessage(intl('mse.errormessage.miss_clusterid'));
    },
    [errorEnum.verifyCodeInvalid.code]: () => {
      window.showErrorMessage(errorEnum.verifyCodeInvalid.message);
    },
    [errorEnum.riskShow.code]: (data, options) => {
      const { codeType, verifyDetail, verifyType } = data;
      let customInputCode = '';
      let msgRequestId = '';
      let dialogIns;

      const sendVerifyMsg = () => {
        const ele = $('.msg-verify-getcode');
        let restSec = 60;

        ele.text(intl.html('mse.errormessage.few_sec_refetch'));
        ele.attr('disabled', true);

        const resetSecInterval = setInterval(() => {
          restSec--;

          ele.text(intl.html('mse.errormessage.few_sec_refetch'));
          ele.attr('disabled', true);

          if (restSec <= 0) {
            ele.text(intl('mse.common.get_code'));
            ele.attr('disabled', false);
            clearInterval(resetSecInterval);
          }
        }, 1000);
        window.request({
          url: '/risk/sendVerifyMessage.json',
          type: 'post',
          data: {
            sec_token: window.ALIYUN_CONSOLE_CONFIG.SEC_TOKEN,
            codeType, //这个参数是由风控返回的，不要写死。
            verifyType, // sms短信 email邮箱，ga,这个参数是由风控返回的，不要写死。
            umid: window.RISK_INFO ? window.RISK_INFO.UMID : 'aliyun_umid',
            collina: window.RISK_INFO ? window.RISK_INFO.GETUA() : 'aliyun_collina',
          },
          success: (res) => {
            const { data = {} } = res;
            msgRequestId = data.requestId;
          },
        });
      };

      const resendRequst = () => {
        const verifyCode = $('.msg-verify-input input').val().trim();

        if (verifyCode) {
          _.assign(options.data, {
            verifyCode: customInputCode,
            verifyType,
            requestId: msgRequestId,
          });
          options.success = (res) => {
            dialogIns.hide();
            options.success(res);
          };
          window.request(options);
        } else {
          $('.msg-verify-error-tip').show();
        }
      };

      const style = {
        width: 380,
        fontSize: 12,
        lineHeight: '24px',
        marginTop: 8,
      };

      const inlineStyle = {
        display: 'inline-block',
        width: 120,
        marginRight: 10,
        textAlign: 'right',
      };

      let contentTip;
      if (verifyType === 'ga') {
        contentTip = (
          <span>
            <span style={inlineStyle}>{intl('mse.common.verify_mfa')}</span>
          </span>
        );
      } else {
        contentTip = (
          <span>
            <span style={inlineStyle}>{intl.html('mse.common.verifytype_choose')}</span>
            <strong style={{ fontSize: 18, marginRight: 13 }}>{verifyDetail}</strong>
          </span>
        );
      }

      const content = (
        <div style={style}>
          <div style={{ marginBottom: 10 }}>
            {contentTip}
            <a target="_blank" href="https://account.console.aliyun.com">
              {intl('mse.common.change_verify_method')}
            </a>
          </div>

          <div>
            <span style={inlineStyle}>{intl('mse.common.verify_code')}</span>

            <Input
              className="msg-verify-input"
              onChange={(val) => {
                customInputCode = val;
                customInputCode && $('.msg-verify-error-tip').hide();
              }}
              trim
              style={{ width: 100, marginRight: 10 }}
            />
            {verifyType !== 'ga' && (
              <Button onClick={sendVerifyMsg} className="msg-verify-getcode">
                {intl('mse.common.get_code')}
              </Button>
            )}
            <div
              className="msg-verify-error-tip"
              style={{ paddingLeft: 110, color: 'red', display: 'none' }}
            >
              {intl('mse.common.verify_code_input')}
            </div>
          </div>
        </div>
      );

      const footer = (
        <div>
          <Button onClick={resendRequst} type="primary">
            {intl('mse.errormessage.confirm')}
          </Button>
          <Button
            onClick={() => {
              dialogIns.hide();
            }}
            style={{ marginLeft: 10 }}
          >
            {intl('mse.common.cancel')}
          </Button>
        </div>
      );

      dialogIns = Dialog.show({
        title: intl.html('mse.common.dialogins_title'),
        content,
        footer,
      });
    },
    // demo示例下无权限操作
    [errorEnum.demoNoOpt.code]: (res) => {
      Message.warning({
        content: res.message,
        style: { marginTop: '50px' },
        animation: false,
        duration: 4000,
      });
    },
    // 还有找到对应的region信息
    [errorEnum.changeRegionError.code]: () => {
      Message.warning({
        content: errorEnum.changeRegionError.message,
        animation: false,
        duration: 4000,
        align: 'cc cc',
      });
    },
  };
  const { config } = response;
  requestParams = { ...config };
  const { data } = response;
  if (!data) {
    throw new ResponseDataReferenceError(response);
  }

  const { code, message } = data;
  const bizData = data.data;

  if (code === 'FoundRiskAndDoubleConfirm') {
    throw new ResponseRiskError(response, message);
  }

  if (code === '200' && bizData.Success !== false) {
    return response;
  } else {
    const handleFunc = consoleExpHanlder[code] || consoleExpHanlder[bizData.ErrorCode]; //捕获外部异常码或业务异常码
    if (handleFunc && typeof handleFunc === 'function') {
      handleFunc(bizData, {}, data);
    } else if (bizData.Success === false) {
      window.showErrorMessage(bizData.Message); // 业务部分的异常
    }
    console.log('0000000', response);
    return response;
  }
};
