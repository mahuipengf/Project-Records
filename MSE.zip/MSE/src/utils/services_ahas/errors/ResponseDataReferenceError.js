import ResponseError from './ResponseError';

class ResponseDataReferenceError extends ResponseError {}

export default ResponseDataReferenceError;
