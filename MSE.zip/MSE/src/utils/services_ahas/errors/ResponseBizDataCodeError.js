import ResponseError from './ResponseError';
import format from 'format';

const ERR_MSG = "Invalid response data's code: %s";

class ResponseBizDataCodeError extends ResponseError {
  constructor(response, message = ERR_MSG) {
    const { Code, Message: responseMessage, RequestId, Data } = response;
    super(response, format(message, Code));

    this.code = Code;
    this.data = Data;
    this.message = responseMessage;
    this.requestId = RequestId;
  }
}

export default ResponseBizDataCodeError;
