import ResponseError from './ResponseError';
import format from 'format';

const ERR_MSG = "Invalid response data's code: %s";

class ResponseDataCodeError extends ResponseError {
  constructor(response, message = ERR_MSG) {
    const { data: { code, data, message: responseMessage, requestId } = {} } = response;
    super(response, format(message, code));

    this.code = code;
    this.data = data;
    this.message = responseMessage;
    this.requestId = requestId;
  }
}

export default ResponseDataCodeError;
