/**
 * 新版本规范
 * * */
import _ from 'lodash';
import { customRequest } from '@ali/mamba';

interface IUpdateServerConfig {
  action?: any;
  product?: any;
  url?: any;
  method?: any;
}

// 统一处理pop接口
const consoleService = customRequest({
  request: (config: any) => {
    const { data, params } = config;
    // 统一处理
    return {
      ...config,
      data: {
        data,
        params,
      },
    };
  },
});

// 统一处理非pop
const axiosService = customRequest({
  request: (config: any) => {
    const { data, params } = config;
    return { ...config, data, params };
  },
});

export default ({ action, product, ...params }: IUpdateServerConfig) => {
  let result: any;
  if (action) {
    result = consoleService({
      ...params,
      product,
      action,
    });
  } else {
    result = axiosService(params);
  }
  return result;
};

export const getUrlParams = (param: any) => {
  let result = '';
  try {
    const urlParams = _.split(location.href.split('?')[1], '&');
    const urlParamsObj = {};
    _.each(urlParams, (item: any) => {
      const [ key, value ] = item.split('=');
      urlParamsObj[key] = value;
    });
    result = urlParamsObj[param];
  } catch (error) {
    console.log(error);
  }
  return result;
};
