import { IS_PRE_OR_LOCAL, MSC_WIDGET_CONSOLE_CONFIG } from 'config/constants/flow';
import { customRequest } from '@ali/cn-design';
import { find, get, has, includes, isEmpty, toLower } from 'lodash';
import { upperFirstData1 } from 'utils/transfer-data';
import { getCurrentRegion } from 'utils/index';
import CooKie from 'js-cookie';
// import React from 'react';

const getParams = window.getParams;

const edasService = customRequest();
const { productName } = MSC_WIDGET_CONSOLE_CONFIG;
const regionId = window.regionId || getCurrentRegion() || getParams('region') || 'cn-hangzhou';

const consoleService = customRequest({
  request: config => {
    const { data = {}, params = {}, method } = config;
    const newData = { ...data };
    let newParams = { ...params };
    const mseSessionId = localStorage.getItem('MseSessionId');
    // const GlobalNamespace = CooKie.get('GlobalNamespace') ? JSON.parse(CooKie.get('GlobalNamespace')) : {};
    const ns = getParams('ns');

    if (!isEmpty(newData)) {
      newData.source = newData.source || 'edasmsc';
      if (has(newData, 'namespaceId')) {
        newData.namespace = newData.namespaceId;
        delete newData.namespaceId;
      }
      if (has(newData, 'regionId')) {
        newData.region = newData.regionId;
        delete newData.regionId;
      }
    }

    if (!isEmpty(newParams)) {
      newParams['X-EDAS-AT-ROUTER-KEY'] = IS_PRE_OR_LOCAL && productName === 'Edas' ? localStorage.getItem('edasEnvActiveKey') || '' : undefined; // edas 多环境字段
      newParams.source = newParams.source || 'edasmsc';
      if (has(newParams, 'namespaceId')) {
        newParams.namespace = newParams.namespaceId;
        delete newParams.namespaceId;
      }
      if (has(newParams, 'regionId')) {
        newParams.region = newParams.regionId;
        delete newParams.regionId;
      }
    } else if (toLower(method) === 'post' && !isEmpty(newData) && isEmpty(newParams)) {
      newParams = newData;
    }
    if (mseSessionId) {
      newParams.MseSessionId = mseSessionId;
    }

    if (mseSessionId) {
      newParams.MseSessionId = mseSessionId;
    }

    // if (GlobalNamespace && GlobalNamespace.namespace) {
    //   newParams.namespace = ns || GlobalNamespace?.namespace || '';
    // }
    if (ns) {
      newParams.namespace = ns || '';
    }

    return {
      ...config,
      data: {
        region: regionId,
        params: upperFirstData1(newParams),
      },
    };
  },
  response: res => {
    const data = get(res, 'Data', []);
    return data;
  },
});

// 新功能，edas 直接上 pop 接口
const EdasPop = [
  'QueryServiceTimeConfig',
  'AddServiceTimeConfig',
  'DeleteServiceTimeConfig',
  'GetAccountMockRule',
  'GetMockRuleByProviderAppId',
  'GetMockRuleById',
  'AddMockRule',
  'DisableMockRule',
  'RemoveMockRule',
  'EnableMockRule',
  'UpdateMockRule',
  'GetMockRuleByConsumerAppId',
  'GetHistorys',
  'RunServiceTest',
];
export default ({ action, product = productName, url, method = 'get', headers = {} }: any) => {
  let result;
  if (MSC_WIDGET_CONSOLE_CONFIG.isUsePopApi || includes(EdasPop, action)) {
    const X_MSE_ENV_KEY = sessionStorage.getItem('X-MSE-ENV-KEY');
    const X_MSE_ENV_ARR = get(window, 'MSE_ENV_CONFIG.X_MSE_ENV_ARR', []);
    const currentEnvItem = find(X_MSE_ENV_ARR, { value: X_MSE_ENV_KEY }) || {};
    const ip = {
      mse: get(currentEnvItem, 'ip.mse', ''),
      edasmsc: get(currentEnvItem, 'ip.edasmsc', ''),
    };
    const newHeader = { 'x-acs-debug-http-host': ip[product] || '' };
    result = consoleService({
      product,
      action,
      method,
      headers: (IS_PRE_OR_LOCAL && (product === 'edasmsc' || product === 'mse')) ? newHeader : {}, // 正常应该拿到headers，但目前pop headers加了'Content-Type': 'application/json' 会导致异常，后续需要优化
      popContentType: 'application/json',
    });
  } else {
    const newParams = { method, url, headers };
    result = edasService(newParams);
  }
  return result;
};
