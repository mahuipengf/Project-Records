import axios from 'axios';
import extractData from './response/extractData';
import validData from './response/validData';
import validStatus from './response/validStatus';
import withCollina from './request/withCollina';
import withSecToken from './request/withSecToken';
import withTransform from './request/withTransform';


import withUmid from './request/withUmid';
import { API_URL } from './constants';
import { get, isFunction, toLower } from 'lodash';


const AXIOS_INSTANCE_REF = Symbol('AXIOS_INSTANCE_REF');

/**
 * console发起请求
 * @param options services层的配置，包括product、action、method等
 * @param params 发起请求的数据 接口配置，常见参数有ignoreError、customErrorHandle
 */
const consoleService = (options: any = {}, interceptors: any = {}) => async (config: any = {}) => {
  const consoleOptions = { ...options };
  consoleOptions.method = toLower(consoleOptions.method) || 'get';
  const { product, action, method, popContentType = 'application/json', headers, popUrl, ...rest } = consoleOptions;
  const { params = {}, data = {} } = config;
  const serviceConfig = {
    product,
    action,
    method,
    params,
    data,
    // 该参数用于链路oneConsole发送请求到pop，由于oneConsole作为proxy层不对数据进行转换
    // 所以需要在request库内部进行转换，默认为application/json
    // 支持修改为application/x-www-form-urlencoded
    popContentType,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', // application/json
      ...headers,
    },
    url: popUrl,
    ...rest,
  };
  try {
    // 缓存 axios 实例
    if (!consoleService[AXIOS_INSTANCE_REF]) {
      consoleService[AXIOS_INSTANCE_REF] = createDefaultAxiosInstance(interceptors);
    }
    const ins = consoleService[AXIOS_INSTANCE_REF];
    return await ins.request(serviceConfig);
  } catch (err) {
    // if (!ignoreError) {
    //   const callback = () => {
    //     throw err;
    //   };
    //   if (isFunction(customErrorHandle)) return customErrorHandle({ ...err }, errServiceConfig, callback);
    //   callback();
    // } else {
    console.warn('error', `${err.message}\n${err.stack}` || err);
    return {};
    // }
  }
};
const createDefaultAxiosInstance = (interceptors: any) => {
  const { request, response } = interceptors;
  const baseService = axios.create({
    url: get(interceptors, 'popUrl', API_URL),
    method: 'post',
  });
  baseService.interceptors.request.use(withTransform());
  baseService.interceptors.request.use(withUmid());
  baseService.interceptors.request.use(withSecToken());
  baseService.interceptors.request.use(withCollina());
  if (isFunction(request)) {
    baseService.interceptors.request.use(request);
  } else {
    baseService.interceptors.request.use(config => {
      const { data, params } = config;
      return {
        ...config,
        data: {
          data,
          params,
        },
      };
    });
  }
  baseService.interceptors.response.use(validStatus);
  baseService.interceptors.response.use(validData);
  baseService.interceptors.response.use(extractData);
  isFunction(response) && baseService.interceptors.response.use(response);
  return baseService;
};

export default consoleService;
