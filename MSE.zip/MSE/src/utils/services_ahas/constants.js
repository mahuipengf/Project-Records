/**
 * productName 产品名
 * urlPrefix 是否需要支持跨域访问，是的话则需要设置跨域域名
 */
export const WIDGET_CONSOLE_CONFIG = window.WIDGET_CONSOLE_CONFIG || {};

export const API_URL = '/data/api.json';

export const DEFAULT_AXIOS_CONTENT_TYPE = 'application/x-www-form-urlencoded;charset=UTF-8';

export const dialogWrapStyle = {
  minWidth: 450,
  maxWidth: 800,
  lineHeight: 1.5,
  fontSize: '12px',
  wordBreak: 'break-all',
  marginLeft: '24px',
  marginTop: '-16px',
};

export const SUCCESS_LIST = [ '200', 200, 'OK', 'Success' ];

export const getPrefix = env => (env === 'widget' ? 'aliyun-widget-' : 'next-');
