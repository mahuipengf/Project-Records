import { mseAxios } from './newRequest';


const GetUserStatusTest = mseAxios({
  productName: 'mse',
  action: 'GetUserStatus',
  method: 'post',
});

const FetchGlobalReadWriteSplitRules = mseAxios({
  productName: 'mse',
  action: 'FetchGlobalReadWriteSplitRules',
  method: 'post',
});

const QueryAppSummaryMetricsOverview = mseAxios({
  productName: 'mse',
  action: 'QueryAppSummaryMetricsOverview',
  method: 'post',
});

const QueryAppSystemMetricsOfGroup = mseAxios({
  productName: 'mse',
  action: 'QueryAppSystemMetricsOfGroup',
  method: 'post',
});

const QueryAppSystemMetricsOfGroupByInstance = mseAxios({
  productName: 'mse',
  action: 'QueryAppSystemMetricsOfGroupByInstance',
  method: 'post',
});

const GetUserStatus = mseAxios({
  productName: 'mse',
  action: 'GetUserStatus',
  method: 'post',
});

const ListEventsPage = mseAxios({
  productName: 'mse',
  action: 'ListEventsPage',
  method: 'post',
});

const GetDubboTestMethod = mseAxios({
  // url: '/sp/api/mse/test/dubbo/method',
  action: 'GetDubboTestMethod',
  productName: 'mse',
});

const GetSpringCloudTestMethod = mseAxios({
  // url: '/sp/api/mse/test/springcloud/method',
  action: 'GetSpringCloudTestMethod',
  productName: 'mse',
});

const GetIstioTestMethod = mseAxios({
  url: '/sp/api/mse/test/istio/method',
  action: 'GetIstioTestMethod',
  productName: 'mse',
});

const fetchHsfDetail = mseAxios({ // hsf服务基本信息
  url: '/json/v5/mst/hsfServiceInfo.json',
  method: 'get',
  action: 'GetHsfDetail',
});

const fetchServiceBasicInfo = mseAxios({ // 服务查询基本信息
  // url: '/sp/api/mse/getServiceDetail',
  method: 'post',
  action: 'GetServiceDetail',
});

const postDubboParams = mseAxios({
  // url: '/sp/api/mse/test/dubbo/invoke',
  method: 'post',
  action: 'InvokeDubboTestMethod',
  productName: 'mse',
});

const RunServiceTest = mseAxios({
  action: 'RunServiceTest',
  productName: 'mst',
});

const InvokeIstioTestMethod = mseAxios({
  url: '/sp/api/mse/test/istio/invoke',
  method: 'post',
  action: 'InvokeIstioTestMethod',
  productName: 'mse',
});

const postSCParams = mseAxios({
  // url: '/sp/api/mse/test/springcloud/invoke',
  method: 'post',
  action: 'InvokeSpringCloudTestMethod',
  productName: 'mse',
});

const fetchTestHistorys = mseAxios({
  action: 'GetHistorys',
  productName: 'mst',
});

const FetchDataSourceConfig = mseAxios({
  method: 'post',
  action: 'FetchDataSourceConfig',
  productName: 'mse',
});

export default {
  GetUserStatusTest,
  FetchGlobalReadWriteSplitRules,
  QueryAppSummaryMetricsOverview,
  QueryAppSystemMetricsOfGroup,
  QueryAppSystemMetricsOfGroupByInstance,
  GetUserStatus,
  ListEventsPage,
  GetDubboTestMethod,
  GetSpringCloudTestMethod,
  GetIstioTestMethod,
  fetchHsfDetail,
  fetchServiceBasicInfo,
  postDubboParams,
  RunServiceTest,
  InvokeIstioTestMethod,
  postSCParams,
  fetchTestHistorys,
  FetchDataSourceConfig,
};
