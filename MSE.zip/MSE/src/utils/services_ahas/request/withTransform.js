import qs from 'qs';
import { includes, isEmpty, isPlainObject } from 'lodash';

const defaultTransformer = config => {
  const { product, action, method, data, popContentType } = config;
  const { params, data: content, ...rest } = data;

  const formatContent = includes(popContentType, 'application/x-www-form-urlencoded')
    ? qs.stringify(content)
    : JSON.stringify(content);
  const newData = {
    product,
    action,
    method,
    ...rest,
    params: !isEmpty(params) && isPlainObject(params) ? JSON.stringify(params) : undefined,
    content: !isEmpty(content) && isPlainObject(content) ? formatContent : undefined,
  };
  return qs.stringify(newData, { indices: false });
};

export default () => config => {
  return {
    ...config,
    data: defaultTransformer(config),
    params: {
      action: config.action,
    },
    method: 'post',
  };
};
