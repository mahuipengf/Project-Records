import qs from 'qs';
import { axios } from '@ali/widget-request';
import { includes } from 'lodash';

const instance = axios.create(
  {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', // application/json,这里待定
    },
    withCredentials: true, // 携带cookie
  },
);

const axiosApi = ({ url, method = 'get', ignoreError = false }) => payload => {
  let option = {};
  if (includes([ 'post', 'put', 'patch' ], method)) {
    option = {
      data: qs.stringify(payload), // Content-Type: application/x-www-form-urlencoded
    };
  } else {
    option = {
      paramsSerializer: params => qs.stringify(params, { indices: false }),
    };
  }
  return instance.request({ url, method, ...option, ignoreError });
};

export default axiosApi;
