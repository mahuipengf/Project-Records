import React, { createContext, useReducer, useContext } from 'react';
import { assign } from 'lodash';

const initialState = {
  /**
   * MscAccount参数介绍：
   *
   * Status: 0-公测用户，1-新用户，2-已开通基础/专业版本，3-基础/专业版本欠费停机
   * Version: 0-基础版本，1-专业版本
   * UserId：用户ID，基础转专业版本时需要传递的参数
   */
  MscAccount: {},
  appServiceData: {
    dubbo: [],
    springCloud: [],
    istio: [],
  },
};

function reducer(state, action) {
  switch (action.type) {
    case 'MscAccount':
      return assign({}, state, { MscAccount: action.payload });
    case 'appServiceData':
      return assign({}, state, { appServiceData: action.payload });
    default:
      throw new Error();
  }
}

const StateContext = createContext();
const DispatchContext = createContext();

function useStateStore() {
  return useContext(StateContext);
}

function useDispatchStore() {
  return useContext(DispatchContext);
}

function StoreProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    <StateContext.Provider value={state}>
      <DispatchContext.Provider value={dispatch}>
        {children}
      </DispatchContext.Provider>
    </StateContext.Provider>
  );
}

export { useStateStore, useDispatchStore, StoreProvider };
