import { get, includes } from 'lodash';

export const WIDGET_CONSOLE_CONFIG = window.WIDGET_CONSOLE_CONFIG;

export const MSC_WIDGET_CONSOLE_CONFIG = { productName: 'mse' } || {};

export const WIDGET_EDAS_MSE = {
  id: get(WIDGET_CONSOLE_CONFIG, 'mse.id', '@ali/widget-edas-mse'),
  version: get(WIDGET_CONSOLE_CONFIG, 'mse.version', '0.1.0'),
};

export const WIDGET_EDAS_MSC = {
  id: get(WIDGET_CONSOLE_CONFIG, 'edasmsc.id', '@ali/widget-edas-msc'),
  version: get(WIDGET_CONSOLE_CONFIG, 'edasmsc.version', '0.6.2'),
};

export const WIDGET_MSE_MST = {
  id: get(WIDGET_CONSOLE_CONFIG, 'mst.id', '@ali/widget-mse-mst'),
  version: get(WIDGET_CONSOLE_CONFIG, 'mst.version', '0.0.1'),
};

export const WIDGET_EDAS_MICROGW = {
  id: get(WIDGET_CONSOLE_CONFIG, 'edasmicrogw.id', '@ali/widget-edas-microgw'),
  version: get(WIDGET_CONSOLE_CONFIG, 'edasmicrogw.version', '1.0.0'),
};

export const WIDGET_EDAS_SEATA = {
  id: get(WIDGET_CONSOLE_CONFIG, 'edasseata.id', '@ali/widget-edas-seata'),
  version: get(WIDGET_CONSOLE_CONFIG, 'edasseata.version', '0.1.0'),
};

export const X_MSE_ENV_ARR = get(window, 'MSE_ENV_CONFIG.X_MSE_ENV_ARR', []);

export const UID = window.ALIYUN_CONSOLE_CONFIG.MAIN_ACCOUNT_PK;

export const WIDGET_ID = '@ali/widget-edas-msc';

export const NNAME_PATTERN = /^[0-9a-zA-Z\-_]{1,64}$/;

export const IS_ENV_PRIVATE = get(window, 'EDAS_USER_FEATURES.envIsPrivateCloud', false); // 转有云

export const IS_SHOW_DUBBO_TIMEOUTCONFIG = get(window, 'EDAS_USER_FEATURES.featureDubboServiceTimeoutControlEnable', false);

export const EDAS_CHANNEL_INFO = get(window, 'EDAS_CHANNEL_INFO.channel', '');

export const IS_IFRAME = window.self !== window.top;

export const IS_SAU_BUSINESS = includes(
  [
    'vco_mpkintl_saudijv',
    'vco_mpkintl_saudijv01',
    'vco_mpkintl_saudijv02',
    'vco_mpkintl_saudijv03',
    'ali_testforJV',
  ],
  window.ALIYUN_CONSOLE_CONFIG.CHANNEL
);

// 预发、本地多环境
const fEnv = get(window, 'ALIYUN_CONSOLE_CONFIG.fEnv');
const hostname = get(window, 'location.hostname');
export const IS_PRE_OR_LOCAL = fEnv === 'pre' || hostname === 'my.console.aliyun.com';

export const FULL_SCREEN_OFF =
  'https://img.alicdn.com/tfs/TB1FSXLkxv1gK0jSZFFXXb0sXXa-64-64.png';

// export const POST_BUY_URL = window.ALIYUN_CONSOLE_CONFIG?.CHANNEL_LINKS?.post_buy ? window.ALIYUN_CONSOLE_CONFIG.CHANNEL_LINKS.post_buy :
//   'http://common-buy.aliyun.com/?commodityCode=ahas_post#/buy';
