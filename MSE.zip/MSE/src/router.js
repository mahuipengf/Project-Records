import React, { useEffect, useState, Component } from 'react';
import PropTypes from 'prop-types';
import './lib';
import MainLayout from './layouts/MainLayout';
import { router } from 'dva';
import services from 'utils/services';
import RoleAuthorization from './containers/RoleAuthorization';
import AckUserGuide from './pages/msc/AckUserGuide';
import { forApp } from '@alicloud/console-base-messenger';
import { getCurrentRegion } from 'utils';
import { timeFmt } from 'utils/time';
import { get } from 'lodash';
import { IS_PRE_OR_LOCAL } from 'constants';

// 注册中心
import Index from 'pages/config/Index';
import Concats from 'pages/config/Concats';
import Alarm from 'pages/config/Alarm';
import InstanceSubLayout from 'pages/config/InstanceSubLayout';
import MigrateCloud from './pages/config/MigrateCloud';

// msc + mst
import MscRouter from './MscRouter';

// 云原生 网关
import {
  GatewayList,
  GatewaySubLayout,
  GatewayConcats,
  GatewayAlarm,
} from 'pages/microgw/index.js';

import { OverviewPage } from 'pages/overview/index.js';
import { MockUser } from './pages/mockuser/index.js';
import { StoreProvider } from './store';

// 设置 region bar
if (forApp) {
  let regions = _.get(window, 'ALIYUN_CONSOLE_CONFIG.STATIC_API.regions', []);
  regions = regions.map((item) => {
    return {
      name: item.regionName,
      id: item.regionId,
    };
  });

  forApp.setRegions(regions);
  forApp.setRegionId(getCurrentRegion());
  forApp.onRegionChange((regionItem) => {
    const { id } = regionItem;
    if (id && getCurrentRegion()) {
      window.location.reload();
    }
  });
}

// 设置ResourceGroup
if (forApp) {
  let groupId = aliwareGetCookieByKeyName('console_base_resource_group_id') || '';
  forApp.setResourceGroupId(groupId);
  forApp.onResourceGroupDataLoaded((value) => {
    console.log('----resourceGroupData----', value);
    localStorage.setItem('resourceGroupData', JSON.stringify(value));
  });
  forApp.onResourceGroupChange((val) => {
    forApp.setResourceGroupId(val?.id || '');
    window.location.reload();
  });
}

const { Router, Switch, Route, Redirect } = router;

const noRegionBar = ['/Instance/', '/msc/app/info', 'msc/k8s/info', '/overview']; // 需要隐藏 region bar 的 pathname
const hasResourceBar = ['/InstanceList', '/microgw','Home']; //需要展示资源组的pathname

const Layout = ({ location }) => {
  useEffect(() => {
    handleChangeLocation();
    if (!window.hasRole) {
      hashHistory.push('/auth');
    }
    if (!location.pathname || location.pathname == '/') {
      hashHistory.push('/overview');
    }
  }, [location]);

  useEffect(() => {
    if (
      window.location.search.indexOf('spm') !== -1 &&
      window.location.search.indexOf('accounttraceid') !== -1
    ) {
      const newHref = window?.location?.origin + '/#/overview';
      window.location.href = newHref;
    }
  }, []);

  const handleChangeLocation = () => {
    const { pathname } = location;

    if (forApp && noRegionBar.find((item) => pathname.indexOf(item) > -1)) {
      forApp.toggleRegion(false); // 隐藏
    } else {
      forApp.toggleRegion(true); // 显示
    }
    if (forApp && hasResourceBar.find((item) => pathname.indexOf(item) > -1)) {
      forApp.toggleResourceGroup(true);
    } else {
      forApp.toggleResourceGroup(false);
    }
  };

  return (
    <MainLayout>
      <Switch>
        <Route
          path="/msc"
          component={(rest) => (
            <StoreProvider>
              <MscRouter {...rest} />
            </StoreProvider>
          )}
        />
        <Route path="/InstanceList" component={Index} />
        <Route path="/MigrateCloud" component={MigrateCloud} />
        <Route path="/Instance" component={InstanceSubLayout} />
        <Route path="/Home" component={Index} />
        <Route path="/microgw" component={GatewayList} />
        <Route path="/gateway" component={GatewaySubLayout} />
        {/* 华北金融云网关告警隐藏 */}
        <If condition={window.regionId !== 'cn-beijing-finance-1'}>
          <Route path="/alarm/concats" component={GatewayConcats} />
          <Route path="/alarm/policy" component={GatewayAlarm} />
        </If>
        {/* 金融云华北暂不开放 告警管理 */}
        <If condition={window.regionId !== 'cn-beijing-finance-1'}>
          <Route path="/Concats" exact component={Concats} />
          <Route path="/Alarm" exact component={Alarm} />
        </If>
        <Route path="/overview" component={OverviewPage} />
        <Route path="/mockuser" component={MockUser} />
        <Redirect to="/overview" />
      </Switch>
    </MainLayout>
  );
};

const AppRouter = ({ history, location }) => {
  const [loading, setLoading] = useState(true);
  window.hashHistory = history;

  useEffect(() => {
    CheckRole();
  }, []);

  const CheckRole = async () => {
    const { HasServiceLinkRole } = await services.CheckSlrRole();
    if (!!HasServiceLinkRole) {
      window.hasRole = true;
    } else {
      window.hasRole = false;
    }
    setLoading(false);
  };

  return loading ? (
    <span>loading</span>
  ) : (
    <Router history={history}>
      <Switch>
        <Route path="/auth" component={RoleAuthorization} />
        <Route path="/ack-unknown-app-use-guide" component={AckUserGuide} />
        <Route path="/" render={(props) => <Layout {...props} />} />
      </Switch>
    </Router>
  );
};

AppRouter.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};

export default AppRouter;
