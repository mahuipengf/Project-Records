import React from 'react';
import intl from '@ali/wind-intl';
import styles from './index.module.less';
import { Button, Icon } from '@ali/cn-design';


const Step = ({ enable, appName, tag, handleClickIntroductionFlow }) => {
  const map = {
    oldEdition: intl('widget.app.step_oldEdition'),
    noTag: intl('widget.app.step_noTag'),
    multipleTag: intl('widget.app.step_multipleTag'),
    onlyNoTag: intl('widget.app.step_onlyNoTag'),
    existence: intl('widget.app.step_existence'),

  };
  // useEffect(() => {}, [tag]);
  return (
    <React.Fragment>
      <div className={styles['step-content']}>
        <div className={styles['step-explain']}>{intl.html('widget.app.new_canary_instructions')}</div>
        <div style={{ width: 678 }}>
          <span className={styles['step-title']}>STEP 1</span>
          <span className={styles['step-circular']} />
          {intl.html('widget.app.step_one_no_Tag')}
        </div>
        <div style={{ display: 'flex' }}>
          {intl.html('widget.app.step_one_msg')}
          <span className={styles['step-line1']} />
          {intl.html('widget.app.step_one_consumer_connected')}
        </div>
        <div>
          <span className={styles['step-title']}>STEP 2</span>
          <span className={styles['step-circular']} />
          {intl.html('widget.app.step_two_deployment_mode')}
        </div>
        <div style={{ display: 'flex' }}>
          {intl.html('widget.app.step_two_msg')}
          <span className={styles['step-line2']} />
          <div className={styles['step-font']}>
            <div>{intl.html('widget.app.step_two_deployment_mode_k8s', { name: appName })}</div>
            <div><span className={styles['step-tip']}> msePilotCreateAppName</span>: {appName}</div>
            <div><span className={styles['step-tip']}> alicloud.service.tag</span>: gray</div>
          </div>
        </div>
        <div>
          <span className={styles['step-title']}>STEP 3</span>
          <span className={`${enable ? styles['step-circular-err'] : styles['step-circular']}`} />
          <Button type="primary" disabled={enable} onClick={() => handleClickIntroductionFlow(true)}>{intl('widget.app.new_canary_introduction_flow')}</Button>
        </div>
        <div style={{ display: 'flex' }}>
          <span className={styles['step-msg']}>{intl.html('widget.app.new_canary_introduction_flow')}</span>
          <span className={`${enable ? styles['step-enable'] : styles['step-line1']}`} />
          {
            enable && <div className={styles['step-tips']}><Icon type="warning" size="medium" className={styles['step-icon']} />{map[tag]}</div>
          }
        </div>
        <div>
          <span className={styles['step-title']}>STEP 4</span>
          <span className={`${enable ? styles['step-circular-err'] : styles['step-circular']}`} />
          {intl.html('widget.app.step_four_vilidate_roll_back')}
        </div>
        <div style={{ display: 'flex' }}>
          {intl.html('widget.app.step_four_msg')}
          <span className={styles['step-line3']} />
          <div className={styles['step-font']}>
            {intl.html('widget.app.step_four_vilidate_release')}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default Step;
