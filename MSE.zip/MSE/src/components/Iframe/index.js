import React, { useState, useEffect, useLayoutEffect } from 'react';

const Iframe = ({ params = '', styles = {}, ...rest }) => {
  let _iframe = null;
  let _parent = null;

  useEffect(() => {
    fetchData();
    return () => {
        // _parent.removeChild(_iframe);
        _iframe.remove();
    };
  }, []);
  useLayoutEffect(() => {
    _iframe = document.getElementById('iframe');
    _parent = document.getElementById('parent');
  }, []);
  const fetchData = () => {
    _iframe.setAttribute('src', params);
  };
  return (
    <React.Fragment>
        <div id="parent">
            <iframe
              id="iframe"
              src="about:blank"
              style={{ ...styles }}
              {...rest}
            />
        </div>
    </React.Fragment>
  );
};

export default Iframe;
