import React from 'react';
import intl from '@ali/wind-intl';
import CommonDialog from '../base/CommonDialog';
import CommonLoading from '../common/CommonLoading';
import { Button, Form, Input, Field } from '@ali/wind';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};
const FormItem = Form.Item;
class NodeEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      prePath: '',
    };
    this.field = new Field(this);
  }

  openDialog = (prePath = '/') => {
    this.dialog.open();
    this.setState({
      prePath,
    });
  };

  closeDialog = () => {
    this.dialog.close();
    this.setState({
      prePath: '',
    });
  };

  addNode = () => {
    this.field.validate((errors, values) => {
      if (errors) {
        return;
      }
      const clusterId = getParams('clusterId');
      const InstanceId = getParams('InstanceId');
      const { prePath } = this.state;
      let path = values.path;
      if (prePath) {
        path = prePath + path;
      }
      request({
        url: 'com.alibaba.MSE.service.CreateZnode',
        beforeSend: () => {
          this.loading.openLoading();
        },
        data: {
          clusterId,
          InstanceId,
          path,
          data: values.data,
        },
        success: res => {
          this.closeDialog();
          this.props.clearAndRefreshAll && this.props.clearAndRefreshAll();
        },
        complete: () => {
          this.loading.closeLoading();
        },
      });
    });
  };

  renderFooter = () => {
    return (
      <div style={{ textAlign: 'right' }}>
        <Button onClick={this.closeDialog}>{intl('mse.common.cancel')}</Button>
        <Button style={{ marginLeft: 10 }} type="primary" onClick={this.addNode}>
          {intl('mse.common.ok')}
        </Button>
      </div>
    );
  };

  render() {
    const { init } = this.field;
    const { prePath } = this.state;
    return (
      <CommonDialog
        shouldUpdatePosition
        ref={node => (this.dialog = node)}
        footer={this.renderFooter()}
        style={{ height: 300 }}
        title={
          <span>
            {intl('mse.register.node.create')}
          </span>
        }
        childStyle={{ height: 'auto' }}
      >
        <CommonLoading ref={node => (this.loading = node)}>
          <div>
            <Form {...formItemLayout} field={this.field}>
              <FormItem label={intl('mse.register.node.path')} required>
                <Input
                  placeholder=""
                  addonBefore={prePath}
                  {...init('path', {
                    rules: [
                      {
                        required: true,
                        message: intl('mse.register.node.path_validate'),
                      },
                    ],
                  })}
                />
              </FormItem>
              <FormItem label={intl('mse.register.node.data')} hasFeedback>
                <Input.TextArea placeholder="" {...init('data')} />
              </FormItem>
            </Form>
          </div>
        </CommonLoading>
      </CommonDialog>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default NodeEdit;
