import React from 'react';
import CommonLoading from '../common/CommonLoading';
import NodeEdit from './NodeEdit';
import ComIf from '../common/ComIf';
import { Dialog, Button, Grid, Tree, Icon, Input, Card, Menu, Message, Table } from '@ali/wind';
import intl from '@ali/wind-intl';
import services from 'utils/services';
import CommonDialog from '../base/CommonDialog';
// import JsonEditor from '@ali/cn-design-json-editor';
// import '@ali/cn-design-json-editor/dist/index.css';
import Uploader from 'components/Uploader';
import ExportTree from './ExportTree';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
const { Row, Col } = Grid;
const TreeNode = Tree.Node;
const SAMELEVEL = 1;
const SUBLEVEL = 2;
class DataTreeShow extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataList: [],
      expandedKeys: [],
      dataDetail: {
        Path: '',
        Name: '',
        Data: '',
        Dir: false,
      },
      canEdit: false,
      loading: false,
      resetData: '',
      isLoading: false,
      verification: '',
      uploader: {
        fileUrl: '',
        maxSize: '',
        fileName: '',
        status: false,
      },
      importVerificate: '',
      importing: false,
    };
    this.activePath = '';
  }

  componentDidMount = () => {
    setTimeout(() => {
      this.getNodeList('/', false);
    });
    this.nodeTreeMenu = document.getElementById('node-tree-menu');
    this.bindMenuDom();
  };

  componentWillUnmount = () => {
    this.removeBindMenuDom();
  };

  bindMenuDom = () => {
    this.removeBindMenuDom();
    this.showMenu = (e) => {
      const target = e.target;
      if (
        !target.classList.contains('node-tree-menu') &&
        !target.classList.contains('node-tree-item')
      ) {
        this.hideTreeMenu();
      }
    };
    document.body.addEventListener('click', this.showMenu);
  };

  removeBindMenuDom = () => {
    if (this.showMenu) {
      document.body.removeEventListener('click', this.showMenu);
    }
  };

  hideTreeMenu = () => {
    if (this.nodeTreeMenu) {
      this.nodeTreeMenu.style.display = 'none';
    }
  };

  resetDatadetail = () => {
    this.setState({
      dataDetail: {
        Path: '',
        Name: '',
        Data: '',
        Dir: false,
      },
    });
  };

  getNodeList = (path = '/', getChild = true) => {
    const clusterId = getParams('clusterId');
    const InstanceId = getParams('InstanceId');
    if (!InstanceId) return;
    request({
      url: 'com.alibaba.MSE.service.treelist',
      data: {
        path,
        clusterId,
        InstanceId,
      },
      beforeSend: () => {
        this.treespan && this.treespan.openLoading();
      },
      success: (res) => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          let _dataList = this.loopTreeFormat(Data);
          try {
            this.setState({
              dataDetail: {
                Path: '',
                Name: '',
                Data: '',
                Dir: false,
              },
              dataList: _dataList,
              expandedKeys: [],
            });
          } catch (e) {}
        }
      },
      complete: () => {
        this.treespan && this.treespan.closeLoading();
      },
    });
  };

  loopTree = (data, key, children) => {
    return data.map((item) => {
      if (item.key === key && !item.isLeaf) {
        item.children = children;
      } else if (item.key !== key && !item.isLeaf && item.children && item.children.length > 0) {
        item.children = this.loopTree(item.children, key, children);
      }
      return item;
    });
  };

  loopTreeFormat = (data) => {
    return data.map((item) => {
      if (item.children && item.children.length > 0) {
        return this.loopTreeFormat(item.Children);
      }
      const label = <div>{item.Name}</div>;
      return {
        label,
        key: item.Path,
        isLeaf: !item.Dir,
      };
    });
  };

  getNodeDetail = (path) => {
    const clusterId = getParams('clusterId');
    const InstanceId = getParams('InstanceId');
    request({
      url: 'com.alibaba.MSE.service.treedetail',
      data: {
        path,
        clusterId,
        InstanceId,
      },
      beforeSend: () => {
        this.dataspan.openLoading();
      },
      success: (res) => {
        const { Data = {} } = res.data;
        this.setState({
          dataDetail: Data,
        });
        this.preDataDetail = JSON.parse(JSON.stringify(Data));
      },
      complete: () => {
        this.dataspan.closeLoading();
      },
    });
  };

  handleSelect = (keys, info) => {
    this.choosedNodeKey = false; //此代码修复 Aone 上  ID ：21492365   的bug
    this.setState({
      selectedKeys: keys,
    });
    if (keys.length > 0) {
      const path = keys[0];
      this.activePath = path;
      this.getNodeDetail(path);
    }
  };

  refresh = () => {
    this.getNodeDetail(this.activePath);
  };

  clearAndRefreshAll = () => {
    this.getNodeList('/', false);
  };

  validateChoosePath = () => {
    let choosed = true;
    const { Path, Data } = this.state.dataDetail;
    if (!Path) {
      Message.show({
        type: 'error',
        content: intl('mse.register.node.value_placeholder'),
      });
      choosed = false;
    }
    this.choosedPathData = Data;
    return choosed;
  };

  showEdit = () => {
    if (this.validateChoosePath()) {
      this.setState({
        canEdit: true,
      });
    }
  };

  hideEdit = () => {
    let { dataDetail } = this.state;
    // dataDetail.data = this.choosedPathData || '';
    let _preDataDetail = '';
    if (this.preDataDetail) {
      _preDataDetail = JSON.parse(JSON.stringify(this.preDataDetail));
    }
    this.setState({
      canEdit: false,
      dataDetail: _preDataDetail || dataDetail,
    });
  };

  openAddNodeDialog = () => {
    this.nodeEdit.openDialog();
  };

  openResetNodeDialog = async () => {
    this.setState({
      loading: true,
    });
    const clusterType = getParams('ClusterType');
    const instanceId = getParams('InstanceId');
    const Data = await services.cleanClusterDisk({
      customErrorHandle: (err, data, callback) => {
        this.setState({
          loading: false,
        });
        callback();
      },
      params: {
        InstanceId: instanceId,
        ClusterType: clusterType,
        Checked: false,
      },
    });
    this.setState({
      loading: false,
      resetData: Data,
    });
    this.nodeReset.open();
  };

  onExpand = (expandedKeys, info) => {
    if (!info.expanded) {
      const targetPath = info.node.props.eventKey;
      expandedKeys = expandedKeys.filter((item) => {
        return item.indexOf(targetPath) !== 0;
      });
    }
    this.setState({
      expandedKeys,
    });
  };

  onLoadData = (node) => {
    return new Promise((resolve) => {
      if (node.props.children) {
        return resolve();
      }
      const clusterId = getParams('clusterId');
      const InstanceId = getParams('InstanceId');
      const path = node.props.eventKey;
      request({
        url: 'com.alibaba.MSE.service.treelist',
        data: {
          path,
          clusterId,
          InstanceId,
        },
        beforeSend: () => {},
        success: (res) => {
          const { Data } = res.data;
          const { dataList } = this.state;
          const formatData = this.loopTreeFormat(Data);
          const newDataList = this.loopTree(dataList, path, formatData);
          this.setState({
            dataList: newDataList,
          });
          resolve();
        },
        complete: () => {},
      });
    });
  };

  removeNode = () => {
    if (this.choosedNodeKey || this.validateChoosePath()) {
      Dialog.confirm({
        content: intl('mse.register.node.delete_confirm'),
        onOk: () => {
          //写删除节点逻辑并请求删除接口删除成功后再刷新页面
          const clusterId = getParams('clusterId');
          const InstanceId = getParams('InstanceId');
          const path = this.choosedNodeKey || this.state.dataDetail.Path;
          request({
            url: 'com.alibaba.MSE.service.DeleteZnode',
            data: {
              clusterId,
              path,
              InstanceId,
            },
            success: (res) => {
              this.choosedNodeKey = '';
              this.activePath = '';
              this.getNodeList('/', false);
            },
          });
        },
        okProps: { children: intl('mse.common.ok') },
        cancelProps: { children: intl('mse.common.cancel') },
      });
    }
  };

  changeData = (value) => {
    let { dataDetail } = this.state;
    dataDetail.Data = value;
    this.setState({
      dataDetail,
    });
  };

  updateNode = () => {
    const { Path, Data } = this.state.dataDetail;
    if (Data && Path) {
      const clusterId = getParams('clusterId');
      const InstanceId = getParams('InstanceId');
      request({
        url: 'com.alibaba.MSE.service.updateznode',
        beforeSend: () => {
          this.dataspan.openLoading();
        },
        data: {
          clusterId,
          path: Path,
          data: Data,
          InstanceId,
        },
        success: (res) => {
          this.setState({
            canEdit: false,
          });
        },
        complete: () => {
          this.dataspan.closeLoading();
        },
      });
    }
  };

  onRightClick = (obj) => {
    const { event, node } = obj;
    event.preventDefault();
    if (this.nodeTreeMenu) {
      this.choosedNodeKey = node.props.eventKey;
      this.nodeTreeMenu.style.left = `${event.target.offsetLeft + 50}px`;
      this.nodeTreeMenu.style.top = `${event.target.offsetTop}px`;
      this.nodeTreeMenu.style.display = 'block';
    }
  };

  addNode = (type) => {
    if (type === 1 && this.choosedNodeKey) {
      const lastPathIndex = this.choosedNodeKey.lastIndexOf('/');
      const prePath = this.choosedNodeKey.substr(0, lastPathIndex + 1);
      this.nodeEdit.openDialog(prePath);
    }
    if (type === 2 && this.choosedNodeKey) {
      this.nodeEdit.openDialog(`${this.choosedNodeKey}/`);
    }
  };

  renderFooter = () => {
    const instanceId = getParams('InstanceId');
    const suffix4Bit = instanceId.substring(instanceId.length - 4, instanceId.length);
    return (
      <div style={{ textAlign: 'right' }}>
        <Button onClick={this.closeDialog}>{intl('mse.common.cancel')}</Button>
        <Button
          style={{ marginLeft: 10 }}
          type="primary"
          loading={this.state.isLoading}
          onClick={this.resetNode}
          disabled={suffix4Bit !== this.state.verification}
        >
          {intl('mse.common.ok')}
        </Button>
      </div>
    );
  };

  closeDialog = () => {
    this.nodeReset.close();
  };

  resetNode = async () => {
    this.setState({
      isLoading: true,
    });
    const clusterType = getParams('ClusterType');
    const instanceId = getParams('InstanceId');
    await services.cleanClusterDisk({
      customErrorHandle: (err, data, callback) => {
        this.setState({
          isLoading: false,
        });
        callback();
      },
      params: {
        InstanceId: instanceId,
        ClusterType: clusterType,
        Checked: true,
      },
    });
    this.setState({
      isLoading: false,
    });
    this.nodeReset.close();
  };

  openImportNodeDialog = async () => {
    this.nodeImport.open();
    const instanceId = getParams('InstanceId');
    const Data = await services.getZooKeeperUploader({
      customErrorHandle: (err, data, callback) => {
        callback();
      },
      params: {
        InstanceId: instanceId,
      },
    });
    const { Url = '', MaxSize = '' } = Data;
    const _maxSize = MaxSize ? parseInt(MaxSize, 10) / 1024 / 1024 : 0;
    const data = { ...this.state.uploader, maxSize: _maxSize, fileUrl: Url };
    this.setState({ uploader: data });
  };

  openExportNodeDialog = async () => {
    this.nodeExport.open();
  };

  renderImportFooter = () => {
    const instanceId = getParams('InstanceId');
    const suffix4Bit = instanceId.substring(instanceId.length - 4, instanceId.length);
    return (
      <div style={{ textAlign: 'right' }}>
        <Button onClick={() => this.handleImport.close()}>{intl('mse.common.cancel')}</Button>
        <Button
          style={{ marginLeft: 10 }}
          type="primary"
          loading={this.state.importing}
          onClick={this.importConfigData}
          disabled={suffix4Bit !== this.state.importVerificate}
        >
          {intl('mse.common.ok')}
        </Button>
      </div>
    );
  };

  importConfigData = async () => {
    this.setState({
      importing: true,
    });
    const { uploader } = this.state;
    const instanceId = getParams('InstanceId');
    await services.importZookeeperData({
      customErrorHandle: (err, data, callback) => {
        this.setState({
          importing: false,
        });
        callback();
      },
      params: {
        InstanceId: instanceId,
        FileUrl: uploader.fileUrl,
        FileName: uploader.fileName,
      },
    });
    this.setState({
      importing: false,
    });
    this.handleImport.close();
    this.nodeImport.close();
  };

  uploaderChange = (data) => {
    this.setState({
      uploader: data,
    });
  };

  getCellProps = (rowIndex, collIndex, length) => {
    if (collIndex === 0) {
      return {
        rowSpan: length,
      };
    }
  };

  render() {
    const {
      dataList = [],
      dataDetail = {},
      expandedKeys,
      canEdit,
      resetData = {},
      uploader,
    } = this.state;
    const { Path = '', Name = '', Data = '' } = dataDetail;
    const { PvcInfoDTOList = [] } = resetData;
    const InstanceId = getParams('InstanceId');
    const loop = (data) =>
      data.map((item) => {
        let label = <div>{item.Name}</div>;
        if (!item.Children && item.Dir) {
          item.Children = [{ path: item.Path }];
        }
        return (
          <TreeNode label={label} key={item.Path} isLeaf={!item.Dir}>
            {item.Children && Array.isArray(item.Children) ? loop(item.Children) : null}
          </TreeNode>
        );
      });
    const commonProps = {
      style: { width: '100%', height: 530 },
      title: intl('mse.register.node.path'),
      extra: (
        <Button text>
          {' '}
          <Icon type="ashbin" size="xl" onClick={this.removeNode} />
        </Button>
      ),
    };
    return (
      <div className="data-manager">
        <div style={{ position: 'relative' }}>
          <Button
            type="primary"
            onClick={() => this.openAddNodeDialog()}
            style={{ marginRight: 10 }}
          >
            {intl('mse.register.node.create')}
          </Button>
          <Button
            type="primary"
            onClick={() => this.openResetNodeDialog()}
            loading={this.state.loading}
          >
            {intl('mse.register.node.reset')}
          </Button>
          {/* 基础版不支持 */}
          <If condition={getParams('MseVersion') !== 'mse_basic'}>
            <Button
              type="primary"
              style={{ marginLeft: 10 }}
              onClick={() => this.openImportNodeDialog()}
            >
              {intl('mse.register.node.import')}
            </Button>
          </If>
          <If condition={getParams('MseVersion') === 'mse_pro'}>
            <Button
              type="primary"
              style={{ marginLeft: 10 }}
              onClick={() => this.openExportNodeDialog()}
            >
              {intl('mse.register.node.data_export')}
            </Button>
          </If>
          <div className="common-absolute">
            <Button type="normal" onClick={() => this.clearAndRefreshAll()}>
              <Icon type="refresh" />
            </Button>
          </div>
        </div>

        <Row>
          <Col span={6}>
            <h5 className="instance-basicinfo-title">{intl('mse.register.node.list')}</h5>
            <CommonLoading ref={(node) => (this.treespan = node)}>
              <div style={{ position: 'relative', height: 500, overflow: 'auto' }}>
                <Tree
                  dataSource={dataList}
                  onExpand={this.onExpand}
                  expandedKeys={expandedKeys}
                  isNodeBlock={{ defaultPaddingLeft: 20 }}
                  onSelect={this.handleSelect}
                  onRightClick={this.onRightClick}
                  loadData={this.onLoadData}
                  showLine
                />
                <div className="node-tree-menu" id="node-tree-menu">
                  <Menu>
                    <Menu.Item className="node-tree-item" onClick={() => this.addNode(SAMELEVEL)}>
                      {' '}
                      <Icon type="plus-circle" /> {intl('mse.register.node.samelevel')}{' '}
                    </Menu.Item>
                    <Menu.Item className="node-tree-item" onClick={() => this.addNode(SUBLEVEL)}>
                      {' '}
                      <Icon type="plus-circle" /> {intl('mse.register.node.sublevel')}{' '}
                    </Menu.Item>
                    <Menu.Item className="node-tree-item" onClick={this.removeNode}>
                      {' '}
                      <Icon type="minus-circle" /> {intl('mse.common.delete')}{' '}
                    </Menu.Item>
                  </Menu>
                </div>
              </div>
            </CommonLoading>
          </Col>
          <Col span={18}>
            <h5 className="instance-basicinfo-title">{intl('mse.register.node.info')}</h5>
            <ComIf if={dataList.length > 0}>
              <CommonLoading ref={(node) => (this.dataspan = node)}>
                <div>
                  <Card {...commonProps} contentHeight="auto">
                    <div className="node-pathname">{this.activePath}</div>
                    <Input.TextArea
                      style={{ width: '100%', height: 240 }}
                      rows={22}
                      disabled={!canEdit}
                      value={Data}
                      onChange={this.changeData}
                    />
                    <p style={{ color: '#888', marginTop: '10px' }}>
                      {' '}
                      <span style={{ color: 'red' }}>★</span>{' '}
                      {intl('mse.register.node.value_validate')}
                    </p>
                    <div style={{ textAlign: 'right', marginTop: 20 }}>
                      <ComIf if={!canEdit}>
                        <Button type="primary" onClick={this.showEdit}>
                          {intl('mse.common.edit')}
                        </Button>
                      </ComIf>
                      <ComIf if={canEdit}>
                        <span>
                          {' '}
                          <Button
                            type="primary"
                            style={{ marginRight: 10 }}
                            onClick={this.updateNode}
                          >
                            {intl('mse.common.ok')}
                          </Button>
                          <Button onClick={this.hideEdit}>{intl('mse.common.cancel')}</Button>
                        </span>
                      </ComIf>
                    </div>
                  </Card>
                </div>
              </CommonLoading>
            </ComIf>
          </Col>
          <NodeEdit
            ref={(node) => (this.nodeEdit = node)}
            clearAndRefreshAll={this.clearAndRefreshAll}
          />
        </Row>

        <ExportTree ref={(node) => (this.nodeExport = node)} />

        <CommonDialog
          title={intl('mse.register.node.reset')}
          style={{ width: 620 }}
          childStyle={{ height: 350, overflowX: 'hidden' }}
          footer={this.renderFooter()}
          ref={(node) => (this.nodeReset = node)}
          shouldUpdatePosition
        >
          <div style={{ marginBottom: 10 }}>{intl.html('mse.register.node.reset_confirm')}</div>
          {/* <JsonEditor
            defaultValue={this.state.resetData}
            mode="preview"
            modes={['preview']}
          /> */}
          <Table
            dataSource={PvcInfoDTOList}
            cellProps={(rowIndex, collIndex) =>
              this.getCellProps(rowIndex, collIndex, PvcInfoDTOList.length)
            }
          >
            <Table.Column
              title={intl('mse.register.instance.id')}
              dataIndex="InstanceId"
              cell={() => <span>{InstanceId}</span>}
            />
            <Table.Column
              title={`PVC ${intl('mse.register.instance.nodes_name')}`}
              dataIndex="Name"
            />
          </Table>
          <div style={{ margin: '10px 0' }}>{intl.html('mse.register.node.confirm')}</div>
          <Input
            value={this.state.verification}
            placeholder={intl('mse.register.node.verification')}
            style={{ width: '100%' }}
            onChange={(v) => this.setState({ verification: v })}
          />
        </CommonDialog>

        <CommonDialog
          title={intl('mse.register.node.import')}
          style={{ width: 620 }}
          childStyle={{ height: 120, overflowX: 'hidden' }}
          footer={
            <div style={{ textAlign: 'right' }}>
              <Button onClick={() => this.nodeImport.close()}>{intl('mse.common.cancel')}</Button>
              <Button
                style={{ marginLeft: 10 }}
                type="primary"
                onClick={() => this.handleImport.open()}
                disabled={!uploader.status}
              >
                {intl('mse.common.ok')}
              </Button>
            </div>
          }
          ref={(node) => (this.nodeImport = node)}
          shouldUpdatePosition
        >
          <div
            style={{
              padding: 10,
              border: '1px dashed #ebedf1',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'column',
            }}
          >
            <Uploader format="binary" uploader={uploader} uploaderChange={this.uploaderChange} />
            <div style={{ fontSize: 12, color: '#888', marginTop: 10 }}>
              {intl('mse.register.node.upload_1')}
              {uploader.maxSize || <Icon type="loading" size="xxs" style={{ margin: '0 2px' }} />}
              {intl('mse.register.node.upload_2')}
              {uploader.maxSize || <Icon type="loading" size="xxs" style={{ margin: '0 2px' }} />}
              {intl('mse.register.node.upload_3')}
            </div>
          </div>
        </CommonDialog>

        <CommonDialog
          title={intl('mse.register.node.data_manager')}
          style={{ width: 620 }}
          childStyle={{ height: 180, overflowX: 'hidden' }}
          footer={this.renderImportFooter()}
          ref={(node) => (this.handleImport = node)}
          shouldUpdatePosition
        >
          <div>
            {intl.html('mse.register.node.import_verificate')}
            <Input
              value={this.state.importVerificate}
              placeholder={intl('mse.register.node.verification')}
              style={{ width: '100%' }}
              onChange={(v) => this.setState({ importVerificate: v })}
            />
          </div>
        </CommonDialog>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default DataTreeShow;
