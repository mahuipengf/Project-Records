import React from 'react';
import { Dialog, Message, Radio, Icon, Button, Table, Pagination, Balloon } from '@ali/wind';
import CommonBalloon from '../../components/common/CommonBalloon';
import services from 'utils/services';
import intl from '@ali/wind-intl';


const { Group: RadioGroup } = Radio;
const ExportType = {
  Snapshot: 'snapshot',
  TransactionLog: 'transactionLog',
};
const ExportStyle = {
  flex: 1,
  padding: 12,
  borderRadius: 2,
  // display: 'inline-block',
  border: '1px solid #c0c6cc',
  minHeight: 70,
  display: 'flex',
  alignItems: 'center',
};
const ExportBody = {
  marginLeft: 6,
  display: 'inline-block',
};
const ExportTitle = {
  fontSize: 12,
  color: '#333333',
  fontWeight: '400',
};
const ExportSubTitle = {
  fontSize: 12,
  marginTop: 8,
  color: '#666666',
  fontWeight: 'normal',
};

class ExportTree extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      exportType: ExportType.Snapshot,
      exporting: false,
      loading: false,
      disabled: true,
      total: 0,
      currentPage: 1,
      pageSize: 5,
      zookeeperData: [],
    };
    this.refreshInterval;
  }

  open = () => {
    this.setState(
      {
        visible: true,
      },
      () => {
        this.getExportTree(true);
        this.refreshInterval = setInterval(() => {
          this.getExportTree(false);
        }, 1000 * 10);
      }
    );
  };

  close = () => {
    this.refreshInterval && clearInterval(this.refreshInterval);
    this.setState({
      visible: false,
    }, () => {
      this.refreshInterval && clearInterval(this.refreshInterval);
    });
  };

  done = () => {};

  onExportTypeChange = (v) => this.setState({ exportType: v });

  getExportTree = async (isLoading) => {
    isLoading && this.setState({ loading: true });
    const InstanceId = getParams('InstanceId');
    const { currentPage, pageSize: PageSize } = this.state;
    const PageNumber = currentPage - 1;
    const res = await services.getExportZookeeperData({
      customErrorHandle: (err, data, callback) => {
        this.setState({ loading: false });
        callback();
      },
      params: { InstanceId, PageNumber, PageSize },
    });
    this.setState({ loading: false });
    let _disabled = false;
    const ExportFileType = new Map()
      .set('snapshot', intl('mse.register.node.snapshot'))
      .set('transactionLog', intl('mse.register.node.transaction'));
    const ExportStatus = new Map()
      .set('CREATE', { name: intl('mse.register.node.download_list.status.create'), icon: 'loading' })
      .set('RUNNING', { name: intl('mse.register.node.download_list.status.running'), icon: 'loading' })
      .set('FINISH', { name: intl('mse.register.node.download_list.status.finish'), icon: '' })
      .set('FAILED', { name: intl('mse.register.node.download_list.status.failed'), icon: 'warning', color: 'red' })
      .set('EXPIRE', { name: intl('mse.register.node.download_list.status.expire'), icon: '' });

    const _zookeeperData = res && res.map(task => {
      const { ContentMap = { files: [], oss: '' }, ExportType, CreateTime, Status } = task;
      const { files = [], oss } = ContentMap;
      let FilesSize = 0;
      let FilesName = '-';
      let balloon = '';
      let _files = [];
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        _files.push(file.name);
        if (i === 0) {
          FilesName = file.name;
        }
        FilesSize += parseInt(file.size, 10);
      }
      if (_files.length > 1) {
        balloon = (
          <Balloon
            trigger={
              <Button type="primary" text style={{ marginLeft: 6 }}>...</Button>
            }
            align="r"
          >
           {_files.map(name => <div>{name}</div>)}
          </Balloon>
        );
      }
      // FilesSize转换
      let unit = 'byte';
      if (FilesSize > 1024) {
        unit = 'kb';
        FilesSize = parseInt(FilesSize / 1024, 10);
        if (FilesSize > 1024) {
          unit = 'M';
          FilesSize = parseInt(FilesSize / 1024, 10);
        }
      }
      if (Status === 'RUNNING') {
        _disabled = true;
      }
      const statusObj = ExportStatus.get(Status);
      const statusError = ContentMap.error || '';
      return {
        FilesName: (
          <span>{FilesName}{balloon}</span>
        ),
        ExportType: ExportFileType.get(ExportType),
        CreateTime: moment(CreateTime).format('YYYY-MM-DD HH:mm'),
        FilesSize: `${FilesSize}${unit}`,
        Status: (
          <div>
            <If condition={Status !== 'FAILED'}>
              <Icon
                type={statusObj.icon}
                className="instance-icon"
                style={{ color: statusObj.color }}
              />
              {statusObj.name}
            </If>
            <If condition={Status === 'FAILED'}>
              <CommonBalloon
                align="r"
                content={<span style={{ marginLeft: 5 }}>{statusError}</span>}
              >
                <Icon
                  type={statusObj.icon}
                  className="instance-icon"
                  style={{ color: statusObj.color }}
                />
                {statusObj.name}
              </CommonBalloon>
            </If>
          </div>
        ),
        Disabled: Status === 'FINISH',
        OSS: oss,
      };
    });
    this.setState({ zookeeperData: _zookeeperData, disabled: _disabled });
  };

  onExportTree = async () => {
    this.setState({ exporting: true });
    const InstanceId = getParams('InstanceId');
    const ExportType = this.state.exportType;
    const res = await services.launchExportZookeeperData({
      customErrorHandle: (err, data, callback) => {
        this.setState({ exporting: false });
        callback();
      },
      params: { InstanceId, ExportType },
    });
    this.setState({ exporting: false }, () => {
      this.getExportTree(true);
    });
  };

  onPaginationChange = currentPage => {
    this.setState({ currentPage });
  };

  renderOptions = (value, index, record) => {
    let { Disabled, OSS } = record;
    return (
      <div>
        <If condition={Disabled}>
          <a
            href={OSS}
            style={{ color: '#0064c8' }}
          >
            {intl('mse.register.node.download')}
          </a>
        </If>
        <If condition={!Disabled}>
          <a
            href="javascript:;"
            style={{ color: '#ccc' }}
          >
            {intl('mse.register.node.download')}
          </a>
        </If>
      </div>
    );
  };

  render() {
    const { visible, exportType, disabled, exporting, loading, total, currentPage, zookeeperData } = this.state;
    const ComDialogStyle = Object.assign({ border: 'none' }, { width: 720 });
    const ContainerStyle = Object.assign({ overflow: 'auto' }, { minHeight: 410, });
    return (
      <Dialog
        title={intl('mse.register.node.data_export')}
        visible={visible}
        onOk={this.done}
        onCancel={this.close}
        onClose={this.close}
        style={ComDialogStyle}
        footer={false}
        shouldUpdatePosition
      >
        <div style={ContainerStyle}>
          <Message key="0" type="notice" style={{ color: '#f68300', padding: '6px 16px' }}>
            {intl('mse.register.node.export.message1')}
          </Message>
          <div style={{ paddingBottom: 16, borderBottom: '1px solid #c0c6cc' }}>
            <h6>{intl('mse.register.node.data_type')}</h6>
            <RadioGroup value={exportType} onChange={this.onExportTypeChange} style={{ width: '100%', display: 'flex' }}>
              <div style={{ ...ExportStyle, backgroundColor: exportType === ExportType.Snapshot ? '#e5f3ff' : '#ffffff' }}>
                <Radio id="snapshot" value={ExportType.Snapshot}>
                  <div style={ExportBody}>
                    <div style={ExportTitle}>
                      {intl('mse.register.node.snapshot')}（snapshot）
                      <CommonBalloon
                        align="r"
                        content={<span style={{ marginLeft: 5 }}>{intl('mse.register.node.snapshot_tips')}</span>}
                      >
                       <Icon type="help" className="common-help-icon" />
                      </CommonBalloon>
                    </div>
                    {/* <div style={ExportSubTitle}>修改时间： 2022-11-07 16:09</div> */}
                  </div>
                </Radio>
              </div>
              <div style={{ ...ExportStyle, marginLeft: 16, backgroundColor: exportType === ExportType.TransactionLog ? '#e5f3ff' : '#ffffff' }}>
                <Radio id="transactionLog" value={ExportType.TransactionLog}>
                  <div style={ExportBody}>
                    <div style={ExportTitle}>
                      {intl('mse.register.node.transaction')}（transaction log）
                      <CommonBalloon
                        align="r"
                        content={<span style={{ marginLeft: 5 }}>{intl('mse.register.node.transaction_tips')}</span>}
                      >
                       <Icon type="help" className="common-help-icon" />
                      </CommonBalloon>
                    </div>
                    {/* <div style={ExportSubTitle}>修改时间： 2022-11-07 16:09</div> */}
                  </div>
                </Radio>
              </div>
            </RadioGroup>
            <div style={{ marginTop: 16, textAlign: 'right' }}>
              <Button
                type="primary"
                loading={exporting}
                disabled={disabled}
                onClick={this.onExportTree}
              >
                {intl('mse.register.node.export')}
              </Button>
            </div>
          </div>
          <div>
            <h6>{intl('mse.register.node.download_list')}</h6>
            <Message key="0" type="notice" style={{ color: '#f68300', padding: '6px 16px' }}>
              {intl('mse.register.node.export.message2')}
            </Message>
            <div style={{ marginTop: 16, marginBottom: 32 }}>
              <Table dataSource={zookeeperData} loading={loading}>
                <Table.Column title={intl('mse.register.node.download_list.filesName')} dataIndex="FilesName" />
                <Table.Column title={intl('mse.register.node.download_list.exportType')}dataIndex="ExportType" width={110} />
                <Table.Column title={intl('mse.register.node.download_list.createTime')}dataIndex="CreateTime" width={136} />
                <Table.Column title={intl('mse.register.node.download_list.filesSize')} dataIndex="FilesSize" />
                <Table.Column title={intl('mse.register.node.download_list.status')} dataIndex="Status" width={110} />
                <Table.Column title={intl('ahas_sentinel.systemGuard.flowControl.operating')} cell={this.renderOptions} width={70} />
              </Table>
              {/* <Pagination
                total={total}
                type="simple"
                size="small"
                current={currentPage}
                onChange={this.onPaginationChange}
                style={{ marginTop: 10, textAlign: 'right' }}
              /> */}
            </div>
          </div>
        </div>
      </Dialog>
    );
  }
}

export default ExportTree;
