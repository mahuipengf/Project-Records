import React from 'react';
import { get } from 'lodash';
import { useStateStore } from '../../store';
import NoPermission from 'containers/AccountPermission/NoPermission';
import intl from '@ali/wind-intl';


const MscPermissionPublic = (props) => {
  const { children, tag } = props;
  const state = useStateStore();
  const UserId = get(state, 'MscAccount.UserId');
  const Version = get(state, 'MscAccount.Version');
  const Status = get(state, 'MscAccount.Status');
  let upgradeEnterpriseHref = `https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn&orderType=UPGRADE&instanceId=synthetic_post_${UserId}`;
  return (
    <div>
      <If condition={Status !== 2 || (Status === 2 && Version)}>
        {children}
      </If>
      <If condition={tag === 'lossless'}>
        <If condition={(Status === 2 && !Version)}>
          <div style={{ display: 'flex', justifyContent: 'center', margin: 100, fontSize: '12px', lineHeight: '24px', color: '#555' }}>
            <NoPermission style={{ width: 120, height: 120, marginRight: 16 }} />
            <div style={{ width: 500, marginTop: 20 }}>
              {intl.html('mse.msc.public.permission.upgrade_base_lossless', { upgradeEnterpriseHref })}
              <div style={{ marginTop: 8 }}>
                {intl.html('mse.msc.public.permission.upgrade_base_lossless_message')}
              </div>
            </div>
          </div>
        </If>
      </If>
    </div>
  );
};
export default MscPermissionPublic;
