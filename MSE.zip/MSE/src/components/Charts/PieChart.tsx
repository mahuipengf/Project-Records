import React, { useEffect } from 'react';
import { Chart } from '@antv/g2';
import { isEmpty } from 'lodash';

interface IPieChart {
  ruleData?: any;
}
const PieChart = ({ ruleData = [] }: IPieChart) => {

  useEffect(() => {
    if (!isEmpty(ruleData)) {
      chartContent();
    }
  }, [ ruleData ]);
  function chartContent() {
    const data = ruleData.ruleList;
    const chart = new Chart({
      container: 'container',
      autoFit: true,
      height: 500,
    });
    chart.data(data);
    chart.scale('percent', {
      formatter: (val: any) => {
        val = val * 100 + '%';
        return val;
      },
    });
    chart.coordinate('theta', {
      radius: 0.75,
      innerRadius: 0.6,
    });
    chart.tooltip({
      showTitle: false,
      showMarkers: false,
      itemTpl: '<li class="g2-tooltip-list-item"><span style="background-color:{color};" class="g2-tooltip-marker"></span>{name}: {value}</li>',
    });
    // 辅助文本
    chart
      .annotation()
      .text({
        position: [ '50%', '45%' ],
        content: ruleData.AllRulesCount,
        style: {
          fontSize: 20,
          fill: '#8c8c8c',
          textAlign: 'center',
        },
        offsetX: -20,
      })
      .text({
        position: [ '50%', '45%' ],
        content: '总数',
        style: {
          fontSize: 14,
          fill: '#8c8c8c',
          textAlign: 'center',
        },
        offsetX: 20,
      })
      .text({
        position: [ '50%', '55%' ],
        content: ruleData.EffectRulesCount,
        style: {
          fontSize: 20,
          fill: '#8c8c8c',
          textAlign: 'center',
        },
        offsetX: -20,
      })
      .text({
        position: [ '50%', '55%' ],
        content: '生效数',
        style: {
          fontSize: 14,
          fill: '#8c8c8c',
          textAlign: 'center',
        },
        offsetX: 20,
      });
    chart
      .interval()
      .adjust('stack')
      .position('percent')
      .color('item')
      .label('percent', () => {
        return {
          content: (data: any) => {
            return `${data.item}: (总数/生效数: ${data.count}/${data.effeftCount})`;
          },
        };
      })
      .tooltip('item*count*effeftCount', (item, count, effeftCount) => {
        return {
          name: item,
          value: `(总数/生效数: ${count}/${effeftCount})`,
        };
      });
    chart.interaction('element-active');
    chart.render();
  }

  return (
    <div id='container' style={{ width: '100%', height: '400px', textAlign: 'center' }}></div>
  );
};

export default PieChart;
