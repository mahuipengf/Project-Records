import React, { useEffect, useState } from 'react';
import {
  Axis,
  Chart,
  Geom,
  Legend,
  Tooltip,
} from 'bizcharts';
import { Empty } from '@ali/cn-design';
import { If } from 'components/tsx-control';
import { forEach } from 'lodash';

interface IInterval {
  axis?: string;
  yxis?: string;
  data?: any;
  lossless?: string;
}
const Interval = ({ data = [], axis = 'name', yxis = 'value', lossless = '' }: IInterval) => {
  const [total, setTotal] = useState(0);
  const cols = {
    [yxis]: {
      minTickInterval: 1,
    },
  };

  useEffect(() => {
    let newTotal = lossless === 'lossless' ? 1 : 0;
    forEach(data, (item) => {
      newTotal += item[yxis];
    });
    setTotal(newTotal);
  }, [data]);
  return (
    <React.Fragment>
      <If condition={!total}>
        <Empty showIcon />
      </If>
      <If condition={total}>
        <Chart
          height={lossless === 'lossless' ? 250 : 360}
          style={{ width: '100%' }}
          data={data}
          scale={cols}
          forceFit
        >
          <Legend position="bottom" offsetY={30} />
          <Axis name={axis} />
          <Axis
            name={yxis}
            // title={{
            //   text: <>asd</>,
            //   // title: '',
            //   // text: lossless === 'lossless' ? '' : intl('widget.home.interval_title'),
            //   textStyle: {
            //     // wordWrap: 'break-word',
            //     fontSize: '12',
            //     textAlign: 'right',
            //     fill: '#999',
            //     fontWeight: 'bold',
            //     rotate: 270,
            //   },
            //   position: 'end',
            // }}
            label={{
              formatter: (val: any) => {
                if (val >= 1000 && lossless === 'lossless') return `${(val / 1000).toFixed(1)}k`;
                return val;
              },
            }}
          />
          <Tooltip
            showTitle={false}
            itemTpl={
              '<li><span style="background-color:{color};" class="g2-tooltip-marker"></span>{name}: {value}</li>'
            }
          />
          <Geom
            type="interval"
            position={`${axis}*${yxis}`}
            color={axis}
            size={['name', [40]]} // 可以根据数据设置柱子宽度
            style={{
              lineWidth: 1,
              radius: 10, // 可以指定圆角半径,默认为宽度一半
            }}
          />
        </Chart>
      </If>
    </React.Fragment>
  );
};

export default Interval;
