import React, { createRef } from 'react';
import { Wline } from '@alife/aisc-widgets';

const PointLine = ({ data }) => {
  const chartRef = createRef<any>();

  return (
    <div style={{ position: 'relative' }}>
      <Wline
        height={200}
        data={data}
        key={data}
        ref={chartRef}
      />
    </div >
  );
};
export default PointLine;
