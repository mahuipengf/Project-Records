import React from 'react';
import styles from './index.module.less';

const CircleChart = ({ size = 0, data = 0, title = '' }: any) => {
  return (
    <div className={styles['content']}>
      <div className={styles['chart']} style={{ width: size, height: size, lineHeight: `${size - 10}px` }}>
        {data}
      </div>
      <p>{title}</p>
    </div>
  );
};

export default CircleChart;
