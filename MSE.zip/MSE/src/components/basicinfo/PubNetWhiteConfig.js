import React, { useState, useEffect } from 'react';
import { Dialog, Input, Message, Form, Field, Icon } from '@ali/cn-design';
import intl from '@ali/wind-intl';
import { forEach, isNaN, inRange, map, fill, values, without } from 'lodash';

const FormItem = Form.Item;

const PubNetWhiteConfig = (props) => {
  const { visible, onClose, originData, onRefresh, showMessage } = props;
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const field = Field.useField();
  const { init } = field;
  const InstanceId = getParams('InstanceId');

  const isIPV4 = (value) => {
    if (typeof value !== 'string') {
      return false;
    }
    const ipv4Format = /^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})$/;
    return ipv4Format.test(value) && value !== '0.0.0.0';
  };

  const isIPV4Subnet = (value = '') => {
    let [ip, mask] = value.split('/');
    if (/^\d+\.\d+\.\d+\.\d+\/\d+$/.test(value) === false) {
      return false;
    }
    if (!mask) {
      return true;
    }
    mask = parseInt(mask, 10);
    if (isNaN(mask) || !inRange(mask, 0, 33)) {
      return false;
    }
    return isIPV4(ip);
  };

  const getIPV4Subnet = (value = '') => {
    let [ip, mask] = value.split('/');
    if (!mask) {
      return ip;
    }
    mask = parseInt(mask, 10);
    const ipParts = map(ip.split('.'), (num) => parseInt(num, 10));
    const computedMask = map(ipParts, (num, index) => {
      let len = Math.min(8, mask - 8 * index);
      len = len < 0 ? 0 : len;
      const maskBinary = fill(Array(len), 1).join('') + fill(Array(8 - len), 0).join('');
      return parseInt(maskBinary, 2);
    });
    const computedIpParts = map(ipParts, (num, index) => num & computedMask[index]);
    return `${computedIpParts.join('.')}/${mask}`;
  };

  const hasMaskCode = (value = '') => {
    if (!value.includes('/')) {
      return false;
    } else if (!value.split('/')[1]) {
      return false;
    } else {
      return true;
    }
  };

  const validateContent = (rule, value, callback) => {
    if (!value) {
      callback();
      return;
    }
    let err = [];
    const entries = [];
    forEach(value.split(','), (entry) => {
      if (entry) {
        entries.push(entry);
      }
    });
    entries.map((ipOrSubnet) => {
      if (!ipOrSubnet) return;
      const formatIp = getIPV4Subnet(ipOrSubnet);
      if (!isIPV4(ipOrSubnet) && !isIPV4Subnet(ipOrSubnet)) {
        err.push(<div>{intl.html('mse.register.instance.ipv4_error', { ip: ipOrSubnet })}</div>);
      }
      if (/^(0\.){3}0(\/(?:3[0-2]|[1-2]?[0-9]))?$/.test(formatIp)) {
        err.push(
          <div>{intl.html('mse.register.instance.ipv4_useless', { ip: ipOrSubnet, formatIp })}</div>
        );
      } else if (isIPV4(ipOrSubnet) && !hasMaskCode(ipOrSubnet)) {
        err.push(
          <div>{intl.html('mse.register.instance.ipv4_nomask', { ip: ipOrSubnet, formatIp })}</div>
        );
      } else if (!isIPV4(ipOrSubnet) && formatIp !== ipOrSubnet) {
        if (!hasMaskCode(ipOrSubnet)) {
          err = [];
          err.push(
            <div>
              {intl.html('mse.register.instance.ipv4_nomask', { ip: ipOrSubnet, formatIp })}
            </div>
          );
        } else {
          err.push(
            <div>
              {intl.html('mse.register.instance.ipv4_repeat', { ip: ipOrSubnet, formatIp })}
            </div>
          );
        }
      }
      if (err.length) {
        callback(<div>{err}</div>);
      }
    });
  };

  const updateAcl = () => {
    field.validate();
    if (without(values(field.getErrors()), null).length !== 0) {
      return;
    }
    const { aclValue } = field.getValues();
    const ClusterId = getParams('ClusterId');
    const InstanceId = getParams('InstanceId');
    setLoading(true);
    request({
      url: 'com.alibaba.MSE.service.UpdateAcl',
      data: {
        ClusterId,
        InstanceId,
        AclEntryList: aclValue,
      },
      success: (res) => {
        setLoading(false);
        onClose();
        onRefresh();
      },
      error: () => {
        setLoading(false);
      },
    });
  };

  const onChangeAcl = (val) => {
    if (originData && !val) {
      setDisabled(true);
    }
  };

  const onConfirm = (val) => {
    const lastFourWords = InstanceId.slice(InstanceId.length - 4, InstanceId.length);
    if (val === lastFourWords) {
      setDisabled(false);
    } else {
      setDisabled(true);
    }
  };

  useEffect(() => {
    if (visible) {
      originData && field.setValue('aclValue', originData);
    }
  }, [visible]);

  return (
    <Dialog
      title={intl('mse.register.instance.white_list')}
      visible={visible}
      style={{ width: 600 }}
      onClose={onClose}
      onCancel={onClose}
      onOk={updateAcl}
      okProps={{ loading, disabled }}
    >
      <If condition={showMessage}>
        <Message style={{ marginBottom: 12 }} type="notice">
          {intl('mse.register.instance.ipv4_message')}
        </Message>
      </If>
      <Form field={field}>
        <FormItem label="">
          <Input.TextArea
            style={{ width: '100%', height: '110px' }}
            {...init('aclValue', {
              rules: [
                {
                  validator: validateContent,
                },
              ],
              props: {
                onChange: onChangeAcl,
              },
            })}
          />
        </FormItem>
      </Form>
      <If condition={!field.getValue('aclValue')}>
        <div style={{ width: '100%' }}>
          <Icon type="warning" size="xs" style={{ color: '#FFA003', marginRight: '10px' }} />
          <If condition={!originData}>{intl.html('mse.register.instance.ipv4_empty_warning')}</If>
          <If condition={originData}>
            {intl.html('mse.register.instance.ipv4_confirm', { InstanceId })}
            <Input
              placeholder={intl('mse.register.node.verification')}
              style={{ width: '100%', marginTop: 8 }}
              onChange={onConfirm}
            />
          </If>
        </div>
      </If>
    </Dialog>
  );
};

export default PubNetWhiteConfig;
