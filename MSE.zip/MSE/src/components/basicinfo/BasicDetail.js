import React from 'react';
import {
  Button,
  IconButton,
  Popconfirm,
  Balloon,
  Grid,
  Icon,
  Table,
  Input,
  Form,
  Field,
  Loading,
  Tag,
} from '@ali/cn-design';
import { LinkButton } from '@ali/wind-rc-actions';
import ComIf from '../common/ComIf';
import {
  mapValues,
  get,
  forEach,
  map,
  fill,
  isNaN,
  inRange,
  values,
  without,
  includes,
} from 'lodash';
import intl from '@ali/wind-intl';
import { formatDate } from 'utils';
import CommonBalloon from '../common/CommonBalloon';
import ResourceTag from '../TagsResource/ResourceTag';
import TagsResourceDialog from '../TagsResource/TagsResourceDialog';
import RenderMseVersion from '../../containers/InstanceList/components/RenderMseVersion';
import RenderAppVersion from '../../containers/InstanceList/components/RenderAppVersion';
import PubNetWhiteConfig from './PubNetWhiteConfig';
import { compareVersion } from 'utils/utils';
import services from 'utils/services';

/**
 * 基础信息页面
 */
const { Row, Col } = Grid;
const commonStyle = {
  labelStyle: {
    color: '#555555',
  },
  contentStyle: {
    color: '#333333',
  },
  rowStyle: {
    lineHeight: '20px',
    fontSize: '12px',
    marginBottom: 8,
  },
  textButtonStyle: {
    marginLeft: 8,
    position: 'relative',
    display: 'inline-block',
    textAlign: 'center',
    verticalAlign: 'top',
  },
};
const RESTART_TAG = 'RESTART_ING';
const SCALE_TAG = 'SCALE_ING';
const CLUSTER_NAME_MAP = mapValues(window.CLUSTER_NAME_MAP, (value) => value.label);

const CHARGE_TYPE_NAME = {
  POSTPAY: intl('mse.register.payment.postpay'),
  PREPAY: intl('mse.register.payment.prepay'),
};
const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};
const FormItem = Form.Item;

class BasicDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      aclValue: '',
      disableRestart: true,
      aclVisible: false,
      aclLoading: false,
      nameVisible: false,
      nameLoading: false,
      InstanceModels: [],
      zoneCount: 3,
      inLoading: false,
      netLoading: false,
      podLoading: false,
      tags: [],
      tagsVisible: false,
      resourceGroupName: '',
      resourceGroupId: '',
      resourceLoading: false,
      showPubNetWhiteMessage: false,
    };
    this.aclValue = '';
    this.originAclValue = '';
    this.checkStateTimmer = null;
    this.field = new Field(this);
    this.nameField = new Field(this);
  }

  componentDidMount() {
    this.getClusterAcl(false);
    this.getClusterInstance(false);
    this.getParameters();
  }

  getClusterAcl = async (refresh) => {
    const InstanceId = getParams('InstanceId');
    if (!InstanceId) return;
    refresh && this.setState({ netLoading: true });
    const res = await services.getClusterAcl({
      customErrorHandle: (err, data, callback) => {
        this.setState({ netLoading: false });
        // callback();
      },
      params: { InstanceId },
      ignoreError: true,
    });
    this.setState({ netLoading: false });
    if (!res) return;
    let aclValue = res.join(',');
    this.aclValue = aclValue;
    this.originAclValue = aclValue;
    const { setValues } = this.field;
    setValues({ aclValue: this.originAclValue });
    this.setState({ aclValue });
  };

  getClusterInstance = async (refresh) => {
    const InstanceId = getParams('InstanceId');
    if (!InstanceId) return;
    refresh && this.setState({ podLoading: true });
    const models = await services.getClusterInstance({
      customErrorHandle: (err, data, callback) => {
        this.setState({ podLoading: false });
        // callback();
      },
      params: { InstanceId },
      ignoreError: true,
    });
    this.setState({ podLoading: false, InstanceModels: models || [] });
    if (!models) return;
    this, this.setState({ resourceLoading: true });
    const res = await services.getClusterDetail({
      customErrorHandle: (err, data, callback) => {
        this.setState({ podLoading: false });
        // callback();
      },
      params: { InstanceId, AclSwitch: false },
      ignoreError: true,
    });
    const { InstanceModels = models, Tags = {}, ResourceGroupId = '' } = res;
    const tags = Object.keys(Tags).map((i) => {
      return { key: i, value: Tags[i], label: `${i}:${Tags[i]}` };
    });
    const resourceGroupData = JSON.parse(localStorage.getItem('resourceGroupData')) ?? [];
    const { displayName = '' } = resourceGroupData.find((i) => i.id === ResourceGroupId) ?? {};

    let _zone = [];
    let _zoneCount = 3;
    InstanceModels &&
      InstanceModels.forEach((pod) => {
        const { PodName } = pod;
        if (!includes(_zone, PodName)) {
          _zone.push(PodName);
        }
      });
    _zoneCount = _zone.length;
    this.setState({
      InstanceModels,
      zoneCount: _zoneCount,
      tags,
      resourceGroupId: ResourceGroupId,
      resourceGroupName: displayName,
    });
    this.setState({ resourceLoading: false });
  };

  getParameters = () => {
    const clusterId = getParams('clusterId');
    const clusterType = getParams('ClusterType');
    const appVersion = getParams('AppVersion');
    const InstanceId = getParams('InstanceId');
    const params = { clusterId, InstanceId };
    if (clusterType === 'Nacos-Ans' && compareVersion(appVersion, '2.1.0.2') > -1) {
      params.NeedRunningConf = true;
    }
    request({
      url: 'com.alibaba.MSE.service.configquery',
      data: params,
      success: (res) => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          const { ConfigAuthEnabled = false, NamingAuthEnabled = false } = Data;
          if (!ConfigAuthEnabled || !NamingAuthEnabled) {
            this.setState({ showPubNetWhiteMessage: true });
          }
        }
      },
    });
  };

  componentWillReceiveProps = (nextProps) => {
    if (nextProps.clusterModel) {
      this.ClusterAliasName = nextProps.clusterModel.ClusterAliasName;
      const { InitStatus } = nextProps.clusterModel;
      try {
        const disableRestart = InitStatus === RESTART_TAG || InitStatus === SCALE_TAG;
        this.setState(
          {
            disableRestart,
          },
          () => {
            if (disableRestart) {
              // 如果发现状态为正在重启，则进行循环检测
              this.loopTimeToCheckClusterInfo();
            }
          }
        );
      } catch (e) {}
    }
  };

  componentWillUnmount = () => {
    this.stopTimmer();
  };

  enabledRestartBtn = () => {
    this.setState({
      disableRestart: false,
    });
  };

  disableRestartBtn = () => {
    this.setState({
      disableRestart: true,
    });
  };

  stopTimmer = () => {
    this.checkStateTimmer && clearInterval(this.checkStateTimmer); // 停止轮询
  };

  checkClusterState = () => {
    const clusterId = getParams('clusterId');
    const InstanceId = getParams('InstanceId');
    request({
      url: 'com.alibaba.MSE.service.clusterDetail',
      data: { clusterId, InstanceId },
      success: (res) => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          if (Data.InitStatus !== RESTART_TAG) {
            this.stopTimmer();
            const { getBasicInfo } = this.props; // 刷新状态
            getBasicInfo && getBasicInfo();
          }
        }
      },
      error: () => {
        this.enabledRestartBtn();
        this.stopTimmer(); // 停止轮询
      },
    });
  };

  // 修改实例名称
  updateCluster = () => {
    const { getValue, validate } = this.nameField;
    validate((errors, values) => {
      if (!errors) {
        const newName = values.clusterAliasName;
        const ClusterId = getParams('ClusterId');
        const InstanceId = getParams('InstanceId');
        request({
          url: 'com.alibaba.MSE.service.clusterupdate',
          data: { ClusterId, ClusterAliasName: newName, requestId: '', InstanceId },
          beforeSend: () => {
            this.setState({ nameLoading: true });
          },
          success: (res) => {
            if (res.code === '200' && res.data) {
              this.props.getBasicInfo();
            }
          },
          complete: () => {
            this.setState({ nameLoading: false, nameVisible: false });
          },
        });
      }
    });
  };

  loopTimeToCheckClusterInfo = () => {
    if (!this.checkStateTimmer) {
      // 已经开启检测则忽略
      this.checkStateTimmer = setInterval(() => {
        this.checkClusterState();
      }, 1000);
    }
  };

  restartInstance = () => {
    const { restartInstance } = this.props;
    restartInstance &&
      restartInstance(() => {
        this.disableRestartBtn();
        this.loopTimeToCheckClusterInfo();
      });
  };

  closeEditName = () => {
    this.setState({
      nameLoading: false,
      nameVisible: false,
    });
  };

  closeInLoading = () => {
    this.setState({ inLoading: false });
  };

  refreshInstanceInfo = () => {
    this.setState({ inLoading: true });
    this.props.getBasicInfo && this.props.getBasicInfo(false, this.closeInLoading);
  };

  renderInstanceInfo() {
    const { clusterModel = {} } = this.props;
    const { inLoading, resourceLoading, resourceGroupName, resourceGroupId } = this.state;
    const {
      MemoryCapacity = 0,
      Cpu = 0,
      DiskCapacity = 0,
      IntranetDomain = '',
      InternetDomain,
      InternetPort,
      VpcId,
      PubNetworkFlow,
    } = clusterModel;
    const InstanceId = getParams('InstanceId');
    const statusObj = window.STATUS_MAP[clusterModel.InitStatus] || {};
    const { init } = this.nameField;
    return (
      <div style={{ paddingBottom: 24, marginBottom: 0, borderBottom: '1px solid #DEDEDE' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h5 className="instance-basicinfo-title">{intl('mse.register.basicinfo')}</h5>
          <Button type="normal" onClick={this.refreshInstanceInfo}>
            <Icon type="refresh" />
          </Button>
        </div>
        <Loading style={{ width: '100%' }} visible={inLoading}>
          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.id')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {InstanceId || '-'}
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.name')}
            </Col>
            {/* <ComIf> */}
            <Col span={9} style={commonStyle.contentStyle}>
              {clusterModel.ClusterAliasName || '--'}
              <Balloon
                visible={this.state.nameVisible}
                type="primary"
                trigger={
                  <IconButton
                    onClick={() => this.setState({ nameVisible: true })}
                    className="outtrigger"
                    style={{ color: '#0070cc', marginLeft: '10px', cursor: 'pointer' }}
                  />
                }
                followTrigger
                triggerType="click"
                onClose={this.closeEditName}
              >
                <div
                  style={{
                    boxSizing: 'border-box',
                    marginTop: '-20px',
                    width: '250px',
                    heihgt: '300px',
                  }}
                >
                  <h3 style={{ color: '#333333', fontWeight: 'bold' }}>
                    {intl('mse.register.instance.name')}
                  </h3>
                  <Form field={this.nameField}>
                    <FormItem label="">
                      <Input
                        maxLength={45}
                        showLimitHint
                        {...init('clusterAliasName', {
                          initValue: clusterModel.ClusterAliasName,
                          rules: [
                            {
                              required: true,
                              pattern:
                                '^(?!_)(?!-)(?!.*?_$)(?!.*?-$)[a-zA-Z0-9\\-_\\u4e00-\\u9fa5]+$',
                              message: intl('mse.register.instance.name_pattern'),
                            },
                          ],
                        })}
                        style={{ width: '100%' }}
                      />
                    </FormItem>
                  </Form>
                  <div style={{ marginTop: '10px', textAlign: 'right' }}>
                    <Button
                      loading={this.state.nameLoading}
                      type="primary"
                      style={{ marginRight: '10px' }}
                      onClick={() => this.updateCluster()}
                    >
                      {intl('mse.common.ok')}
                    </Button>
                    <Button onClick={this.closeEditName}>{intl('mse.common.cancel')}</Button>
                  </div>
                </div>
              </Balloon>
            </Col>
          </Row>
          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.resourceGroupId')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {resourceLoading ? (
                <Icon type="loading" size="xs" />
              ) : (
                <span> {resourceGroupId || '-'}</span>
              )}
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.resourceGroupName')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {resourceLoading ? (
                <Icon type="loading" size="xs" />
              ) : (
                <span> {resourceGroupName || '-'}</span>
              )}
            </Col>
          </Row>
          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.payment')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {CHARGE_TYPE_NAME[clusterModel.ChargeType] || '-'}
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.version')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              <RenderMseVersion record={clusterModel} isBasic={true} />
            </Col>
          </Row>
          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.cluster')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {CLUSTER_NAME_MAP[clusterModel.ClusterType] || '-'}
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.engine')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {/* {clusterModel.AppVersion || '-'} */}
              <RenderAppVersion record={clusterModel} />
            </Col>
          </Row>

          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.nodes_count')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {clusterModel.InstanceCount || '-'}
              <If condition={clusterModel.ClusterId}>
                <span style={{ paddingLeft: 10 }}>
                  {intl.html('mse.register.instance.cores', {
                    cpu: Cpu,
                    memory: MemoryCapacity,
                    disk: DiskCapacity,
                  })}
                </span>
              </If>
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.region')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {window.REGION_NAME_MAP[window.regionId] || clusterModel.region || '-'}
            </Col>
          </Row>

          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.intranet_domain')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              <div>{IntranetDomain} </div>
              <div>
                <span>{IntranetDomain ? `(${VpcId})` : ''}</span>
                <If condition={!IntranetDomain}>-</If>
                <CommonBalloon
                  align="r"
                  content={
                    <span style={{ marginLeft: 5 }}>
                      {intl('mse.register.instance.intranet_balloon')}
                    </span>
                  }
                >
                  <Icon type="help" className="common-help-icon" />
                </CommonBalloon>
              </div>
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.intranet_ports')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {InternetPort || '-'}
              <If condition={clusterModel.ClusterType === 'Nacos-Ans'}>
                <CommonBalloon
                  align="r"
                  content={
                    <span style={{ marginLeft: 5 }}>
                      {intl.html('mse.register.instance.tips')}
                    </span>
                  }
                >
                  <Icon type="help" className="common-help-icon" />
                </CommonBalloon>
              </If>
            </Col>
          </Row>
          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.network_domain')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              <div>{InternetDomain}</div>
              <div>
                <span>
                  {InternetDomain && PubNetworkFlow
                    ? intl.html('mse.register.instance.network', { name: PubNetworkFlow })
                    : ''}
                </span>
                <If condition={!InternetDomain}>-</If>
                <CommonBalloon
                  align="r"
                  content={
                    <span style={{ marginLeft: 5 }}>
                      {intl('mse.register.instance.network_balloon')}
                    </span>
                  }
                >
                  <Icon type="help" className="common-help-icon" />
                </CommonBalloon>
              </div>
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.network_ports')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {InternetPort || '-'}
              <If condition={clusterModel.ClusterType === 'Nacos-Ans'}>
                <CommonBalloon
                  align="r"
                  content={
                    <span style={{ marginLeft: 5 }}>
                    {intl.html('mse.register.instance.tips')}
                    </span>
                  }
                >
                  <Icon type="help" className="common-help-icon" />
                </CommonBalloon>
              </If>
            </Col>
          </Row>
          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.state')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              <span>
                <Icon
                  type={statusObj.icon}
                  className="instance-icon"
                  style={{ color: statusObj.color, marginRight: 8 }}
                />
                {statusObj.name || '-'}
              </span>
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.register.instance.payment')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {/* {clusterModel.PayInfo || '-'} */}
              {CHARGE_TYPE_NAME[clusterModel.ChargeType] || '-'}
            </Col>
          </Row>
          <Row style={commonStyle.rowStyle}>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.tag.button')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              <If condition={resourceLoading}>
                <Icon type="loading" size="xs" />
              </If>
              <If condition={!resourceLoading}>
                <If condition={this.state.tags.length}>
                  {this.state.tags.slice(0, 2).map((tag) => {
                    return (
                      <ResourceTag
                        keyLabel={tag.key}
                        valueLabel={tag.value}
                        style={{ marginRight: 4 }}
                      />
                    );
                  })}
                  <If condition={this.state.tags.length > 2}>
                    <CommonBalloon
                      align="r"
                      content={this.state.tags.map((tag) => {
                        return (
                          <ResourceTag
                            keyLabel={tag.key}
                            valueLabel={tag.value}
                            style={{ marginRight: 4 }}
                          />
                        );
                      })}
                    >
                      <Tag size="small">...</Tag>
                    </CommonBalloon>
                  </If>
                </If>
                <If condition={!this.state.tags.length}>-</If>
                <IconButton
                  onClick={() => this.setState({ tagsVisible: true })}
                  className="outtrigger"
                  style={{ color: '#0070cc', marginLeft: '10px', cursor: 'pointer' }}
                />
              </If>
            </Col>
            <Col span={3} style={commonStyle.labelStyle}>
              {intl('mse.common.create.time')}
            </Col>
            <Col span={9} style={commonStyle.contentStyle}>
              {formatDate(clusterModel.CreateTime)}
            </Col>
          </Row>
        </Loading>
      </div>
    );
  }

  renderStatus() {
    const { clusterModel = {} } = this.props;
    const statusObj = window.STATUS_MAP[clusterModel.InitStatus] || {};
    return (
      <div
        title={intl('mse.register.instance.state')}
        contentHeight="auto"
        style={{
          paddingBottom: 24,
          marginBottom: 0,
          borderBottom: '1px solid #DEDEDE',
        }}
        showTitleBullet={false}
        showHeadDivider={false}
      >
        {/* <h5 className="instance-basicinfo-title">{intl('mse.register.instance.state')}</h5> */}
        <Row style={commonStyle.rowStyle}>
          <Col span={3} style={commonStyle.labelStyle}>
            {intl('mse.register.instance.state')}
          </Col>
          <Col span={9} style={commonStyle.contentStyle}>
            <span>
              <Icon
                type={statusObj.icon}
                className="instance-icon"
                style={{ color: statusObj.color, marginRight: 8 }}
              />
              {statusObj.name || '-'}
            </span>
          </Col>
          <Col span={3} style={commonStyle.labelStyle}>
            {intl('mse.register.instance.payment')}
          </Col>
          <Col span={9} style={commonStyle.contentStyle}>
            {/* {clusterModel.PayInfo || '-'} */}
            {CHARGE_TYPE_NAME[clusterModel.ChargeType] || '-'}
          </Col>
        </Row>
        <Row style={commonStyle.rowStyle}>
          <Col span={3} style={commonStyle.labelStyle}>
            {intl('mse.common.create.time')}
          </Col>
          <Col span={9} style={commonStyle.contentStyle}>
            {formatDate(clusterModel.CreateTime)}
          </Col>
        </Row>
      </div>
    );
  }

  renderClusterList = () => {
    const { InstanceModels = [], podLoading, zoneCount = 1 } = this.state;

    const ZoneRegions = [
      'cn-beijing',
      'cn-zhangjiakou',
      'cn-wulanchabu',
      'cn-hangzhou',
      'cn-shanghai',
      'cn-shenzhen',
      'cn-hongkong',
      'ap-southeast-1',
      'ap-southeast-5',
      'ap-northeast-1',
      'eu-central-1',
    ];
    const VirtualNetwork = ['JST', 'CAINIAO', 'NEW_RETAIL'];
    const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
    const InstanceId = getParams('InstanceId');
    const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
    const isIntl = aliyunSite === 'INTL';
    let commodityCode = 'mse_prepaid_public_cn';
    let upgradeDomain = 'https://common-buy.aliyun.com';
    if (includes(VirtualNetwork, channel)) {
      commodityCode = 'mse_prepaid_public_cn';
      upgradeDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      commodityCode = 'mse_prepaid_public_intl';
      upgradeDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    const changePriceUrl = `${upgradeDomain}/?commodityCode=${commodityCode}&orderType=upgrade&instanceId=${InstanceId}&upgradeType=upgrade`;
    return (
      <div contentHeight="auto" showTitleBullet={false} showHeadDivider={false}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h5 className="instance-basicinfo-title">{intl('mse.register.instance.nodes')}</h5>
          <Button type="normal" onClick={() => this.getClusterInstance(true)}>
            <div>
              <Icon type="refresh" size="xs" />
            </div>
          </Button>
        </div>
        <Table dataSource={InstanceModels} hasBorder={false} loading={podLoading}>
          <Table.Column title={intl('mse.register.instance.nodes_name')} dataIndex="PodName" />
          <Table.Column
            title={intl('mse.register.instance.nodes_state')}
            dataIndex="HealthStatus"
            cell={(value) => {
              if (value) {
                const statusObj = window.STATUS_MAP[value] || {};
                return (
                  <span>
                    <Icon
                      type={statusObj.icon}
                      className="instance-icon"
                      style={{ color: statusObj.color, marginRight: 8 }}
                    />
                    {statusObj.name}
                  </span>
                );
              } else {
                return <Icon type="loading" size="xs" />;
              }
            }}
          />
          <Table.Column
            title={intl('mse.register.instance.nodes_role')}
            dataIndex="Role"
            cell={(value) => {
              if (value) {
                return <span>{value}</span>;
              } else {
                return <Icon type="loading" size="xs" />;
              }
            }}
          />
          <Table.Column
            title={intl('mse.common.opreate.time')}
            dataIndex="CreationTimestamp"
            cell={(value) => formatDate(value)}
          />
          <Table.Column
            title={
              <div>
                <If
                  condition={
                    getParams('MseVersion') === 'mse_basic' &&
                    ((!includes(ZoneRegions, window.regionId) && zoneCount <= 1) ||
                      (includes(ZoneRegions, window.regionId) && zoneCount <= 2))
                  }
                >
                  <CommonBalloon
                    align="r"
                    content={
                      <span>{intl.html('mse.common.zone.update', { url: changePriceUrl })}</span>
                    }
                  >
                    <span>{intl('mse.common.zone')}</span>
                    <Icon type="warning" style={{ color: '#FF3333', marginLeft: '5px' }} />
                  </CommonBalloon>
                </If>
                <If
                  condition={
                    getParams('MseVersion') === 'mse_pro' ||
                    getParams('MseVersion') === 'mse_dev' ||
                    (getParams('MseVersion') === 'mse_basic' &&
                      includes(ZoneRegions, window.regionId) &&
                      zoneCount > 2) ||
                    (getParams('MseVersion') === 'mse_basic' &&
                      !includes(ZoneRegions, window.regionId) &&
                      zoneCount > 1)
                  }
                >
                  <span>{intl('mse.common.zone')}</span>
                </If>
              </div>
            }
            dataIndex="Zone"
          />
          <Table.Column
            title={intl('mse.common.operate')}
            dataIndex=""
            cell={(_, __, record) => (
              <Popconfirm
                cancelButtonText={intl('mse.common.cancel')}
                confirmButtonText={intl('mse.common.ok')}
                title={intl.html('mse.register.restart_confirm', { name: record.PodName })}
                align="l"
                onConfirm={() => this.restartInstancePod(record)}
              >
                <Button type="primary" text>
                  {intl('mse.common.restart')}
                </Button>
              </Popconfirm>
            )}
          />
        </Table>
      </div>
    );
  };

  restartInstancePod = (record) => {
    const { PodName } = record;
    const ClusterId = getParams('clusterId');
    const InstanceId = getParams('InstanceId');
    request({
      url: 'com.alibaba.MSE.service.restart',
      data: {
        ClusterId,
        requestId: '',
        InstanceId,
        PodNameList: PodName,
      },
      success: (res) => {
        if (res.code === '200' && res.data) {
          this.getClusterInstance(true);
          this.disableRestartBtn();
          this.loopTimeToCheckClusterInfo();
        }
      },
    });
  };

  setAclValue = (aclValue) => {
    this.setState({
      aclValue,
    });
  };

  openEditAcl = () => {
    const { setValues } = this.field;
    setValues({ aclValue: this.state.aclValue });
    this.setState({ aclVisible: true });
  };

  closeEditAcl = () => {
    this.setState({
      aclLoading: false,
      aclVisible: false,
    });
  };

  renderAclSetting = () => {
    const { netLoading } = this.state;
    const { init } = this.field;
    const { clusterModel = {} } = this.props;
    const { InternetDomain } = clusterModel;
    const aliyun_lang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
    return (
      <ComIf if={InternetDomain}>
        <div
          style={{
            paddingBottom: 24,
            marginBottom: 0,
            borderBottom: '1px solid #DEDEDE',
          }}
        >
          <div style={{ position: 'relative' }}>
            <h5 className="instance-basicinfo-title" style={{ display: 'inline-block' }}>
              {intl('mse.register.instance.white_list')}
              <CommonBalloon
                align="r"
                content={
                  <span style={{ marginLeft: 5 }}>
                    <a href="https://help.aliyun.com/document_detail/127456.html" target="_blank">
                      {intl('mse.register.instance.query_ip')}
                    </a>
                  </span>
                }
              >
                <Icon type="help" className="common-help-icon" />
              </CommonBalloon>
            </h5>
            <IconButton
              onClick={this.openEditAcl}
              className="outtrigger"
              style={{ color: '#0070cc', marginLeft: '10px', cursor: 'pointer' }}
            />
            <Button
              type="normal"
              style={{ position: 'absolute', top: 16, right: 0 }}
              onClick={() => this.getClusterAcl(true)}
            >
              <Icon type="refresh" />
            </Button>
          </div>
          <Loading style={{ width: '100%' }} visible={netLoading}>
            <div style={commonStyle.rowStyle}>
              <Input.TextArea style={{ width: '100%' }} disabled value={this.originAclValue} />
            </div>
            <div>
              <span style={{ color: '#888888' }}>
                {intl.html('mse.register.instance.white_list_hint_new', {
                  whitelist_url:
                    aliyun_lang === 'zh'
                      ? 'https://help.aliyun.com/document_detail/127456.html#steps-5nd-95l-fua'
                      : 'https://www.alibabacloud.com/help/microservices-engine/latest/a07bf0#ea04e6b0ada5z',
                })}
              </span>{' '}
            </div>
          </Loading>
        </div>
      </ComIf>
    );
  };

  render() {
    const { disableRestart, tagsVisible, tags, aclVisible, showPubNetWhiteMessage } = this.state;
    const { clusterModel = {} } = this.props;
    const tagsDataSource = tags.filter((t) => !t.key.includes('acs:'));
    return (
      <div>
        <div style={{ position: 'relative' }}>
          <Button
            disabled={disableRestart}
            type="primary"
            style={{ marginRight: 20 }}
            onClick={this.restartInstance}
            data-spm-click="gostr=/aliyun;locaid=restart"
          >
            {intl('mse.register.instance.restart')}
          </Button>
        </div>
        {this.renderInstanceInfo()}
        {/* {this.renderStatus()} */}
        {this.renderAclSetting()}
        {this.renderClusterList()}
        <TagsResourceDialog
          visible={tagsVisible}
          dataSource={tagsDataSource}
          resourceGroup={[
            { resourceId: clusterModel.InstanceId, resourceName: clusterModel.ClusterAliasName },
          ]}
          onRefresh={() => this.getClusterInstance()}
          onClose={() => this.setState({ tagsVisible: false })}
          onCancel={() => this.setState({ tagsVisible: false })}
        />
        <PubNetWhiteConfig
          visible={aclVisible}
          onClose={this.closeEditAcl}
          onRefresh={this.getClusterAcl}
          originData={this.originAclValue}
          showMessage={showPubNetWhiteMessage}
        />
      </div>
    );
  }
}

/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default BasicDetail;
