import React from 'react';
import SlidePanel from '@alicloud/console-components-slide-panel';
import intl from '@ali/wind-intl';

const MySlidePanel = (props) => {
  const { children, ...rest } = props;
  return (
    <SlidePanel
      okText={intl('mse.common.ok')}
      cancelText={intl('mse.common.cancel')}
      {...rest}
    >
      {children}
    </SlidePanel>
  );
};

export default MySlidePanel;
