import '@alife/santa-introjs/index.css';
import React, { FC } from 'react';
import SantaIntro from '@alife/santa-introjs';
import styles from './index.module.less';
import intl from '@ali/wind-intl';

interface IStepsIntro {
  element: string;
  content: string;
  position?: string;
}

interface IntroProps {
  stepsArr: Array<IStepsIntro>;
  storageKey: string;
  durationTime?: number;
}

/*
 * 用户引导组件
 * @stepsArr 播放脚本定义
 * storageKey 控制是否出现引导提示字段
 * durationTime 懒加载机制，控制循环周期
 */
const SantaIntroTips: FC<IntroProps> = props => {
  const { stepsArr, storageKey, durationTime = 100 } = props;
  const SantaIntroStatus = localStorage.getItem(storageKey);

  // 引导结束回调
  function handleDownStepsTips() {
    localStorage.setItem(storageKey, 'hidden');
  }

  return (
    <React.Fragment>
      {!SantaIntroStatus && (
        <div className={styles.pandel}>
          <SantaIntro
            steps={stepsArr}
            doneLabel={'完成'}
            skipLabel={'跳过'}
            nextLabel={'下一步'}
            prevLabel={intl('widget.common.pre_step')}
            onExit={handleDownStepsTips}
            onComplete={handleDownStepsTips}
            duration={durationTime}
          />
        </div>
      )}
    </React.Fragment>
  );
};

export default SantaIntroTips;
