import React from 'react';

const defaultStyle = { width: 16, marginRight: 4 };

export default ({ style }) => (
  <img style={style || defaultStyle} width="32" height="32" src="https://sae-oss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sae-log.png" />
);
