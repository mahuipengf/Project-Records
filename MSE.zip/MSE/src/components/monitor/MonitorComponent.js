import React from 'react';
import LineChart from '../chart/LineChart';
import CommonLoading from '../common/CommonLoading';
import ComIf from '../common/ComIf';
import { split, includes, get } from 'lodash';
import { Tab, Button, DatePicker, Message, Icon, Balloon } from '@ali/wind';
import { Dialog } from '@ali/cn-design';
import { compareVersion } from '../../utils/utils';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const TIMMER_CHOOSE = [
  {
    name: intl('mse.register.monitor.30m'),
    value: 30,
    type: 'm',
  },
  {
    name: intl('mse.register.monitor.1h'),
    value: 1,
    type: 'h',
  },
  {
    name: intl('mse.register.monitor.6h'),
    value: 6,
    type: 'h',
  },
  {
    name: intl('mse.register.monitor.1d'),
    value: 1,
    type: 'd',
  },
];
/**zk的monitortype */
const ZK_NUMALIVECONNECTIONS = {
  id: 'zookeeper_NumAliveConnections',
  name: intl('mse.register.monitor.links'),
};

const ZK_TPS = {
  id: 'zookeeper_TPS',
  name: intl('mse.register.monitor.atps'),
};
const ZK_QPS = {
  id: 'zookeeper_QPS',
  name: intl('mse.register.monitor.aqps'),
};

const ZK_TPS_NEW = {
  id: 'zk_TpsCount',
  name: intl('mse.register.monitor.atps'),
};
const ZK_QPS_NEW = {
  id: 'zk_QpsCount',
  name: intl('mse.register.monitor.aqps'),
};

const ZK_PACKETSRECEIVED = {
  id: 'zookeeper_PacketsReceived',
  name: intl('mse.register.monitor.packet'),
};
const ZK_INMEMORYDATATREE_NODECOUNT = {
  id: 'zookeeper_InMemoryDataTree_NodeCount',
  name: intl('mse.register.monitor.znode'),
};
const ZK_OUTSTANDINGREQUESTS = {
  id: 'zookeeper_OutstandingRequests',
  name: intl('mse.register.monitor.queued'),
};
const ZK_AvgRequestLatency = {
  id: 'zookeeper_AvgRequestLatency',
  name: intl('mse.register.monitor.delay'),
};
/**eureka&nacos的monitortype */
const SERVICE_COUNT = {
  id: 'serviceCount',
  name: intl('mse.register.monitor.service'),
};
const IP_COUNT = {
  id: 'ipCount',
  name: intl('mse.register.monitor.provide'),
};

const WRITE_COST_TIME = {
  id: 'writeCostTime',
  name: intl('mse.register.monitor.wcost'),
};
const READ_COST_TIME = {
  id: 'readCostTime',
  name: intl('mse.register.monitor.rcost'),
};
const CENTER_TPS = {
  id: 'regCenterTps',
  name: intl('mse.register.monitor.stps'),
};

const CENTER_QPS = {
  id: 'regCenterQps',
  name: intl('mse.register.monitor.sqps'),
};

/**nacos配置monitortype */
const CONFIG_COUNT = {
  id: 'configCount',
  name: intl('mse.register.monitor.config'),
};
const LISTENER_COUNT = {
  id: 'longPolling',
  name: intl('mse.register.monitor.listen'),
};

const CONFIG_TPS = {
  id: 'publish',
  name: intl('mse.register.monitor.tps'),
};

const CONFIG_QPS = {
  id: 'getConfig',
  name: intl('mse.register.monitor.qps'),
};

const CPU_USAGE = {
  id: 'cpuUsage',
  name: intl('mse.register.monitor.cpu'),
};

const MEMORY_USAGE = {
  id: 'memoryUsage',
  name: intl('mse.register.monitor.memory'),
};

const MenuNoticeStyle = {
  display: 'flex',
  height: 36,
  alignItems: 'center',
  justifyContent: 'end',
  position: 'absolute',
  top: 0,
  left: '100px',
  zIndex: 1,
};

class MonitorComponent extends React.Component {
  constructor(props) {
    super(props);
    const endTime = moment().format('YYYY-MM-DD HH:mm');
    const startTime = moment().subtract(30, 'm').format('YYYY-MM-DD HH:mm');
    this.state = {
      choosedTimmerId: '30m',
      startTime,
      endTime,
      choosedValue: 30,
      choosedType: 'm',
      updateVisible: false,
      isLoading: false,
      format: 'YYYY-MM-DD'
    };
    this.step = 30;
    this.cpu_usage_config = {
      id: CPU_USAGE.id,
      chartTitle: CPU_USAGE.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.memory_usage_config = {
      id: MEMORY_USAGE.id,
      chartTitle: MEMORY_USAGE.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.zk_NumAliveConnections_config = {
      id: ZK_NUMALIVECONNECTIONS.id,
      chartTitle: ZK_NUMALIVECONNECTIONS.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.zookeeper_TPS_config = {
      id: ZK_TPS.id,
      chartTitle: ZK_TPS.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.zookeeper_QPS_config = {
      id: ZK_QPS.id,
      chartTitle: ZK_QPS.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };

    // 3.5.5兼容，3.6+后续会全部升级。
    this.zookeeper_TPS_new_config = {
      id: ZK_TPS_NEW.id,
      chartTitle: ZK_TPS_NEW.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.zookeeper_QPS_new_config = {
      id: ZK_QPS_NEW.id,
      chartTitle: ZK_QPS_NEW.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };

    this.zookeeper_PACKETSRECEIVED_config = {
      id: ZK_PACKETSRECEIVED.id,
      chartTitle: ZK_PACKETSRECEIVED.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.zookeeper_InMemoryDataTree_NodeCount_config = {
      id: ZK_INMEMORYDATATREE_NODECOUNT.id,
      chartTitle: ZK_INMEMORYDATATREE_NODECOUNT.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.zookeeper_OutstandingRequests_config = {
      id: ZK_OUTSTANDINGREQUESTS.id,
      chartTitle: ZK_OUTSTANDINGREQUESTS.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.zookeeper_AvgRequestLatency_config = {
      id: ZK_AvgRequestLatency.id,
      chartTitle: ZK_AvgRequestLatency.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };

    this.service_count_config = {
      id: SERVICE_COUNT.id,
      chartTitle: SERVICE_COUNT.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.ip_count_config = {
      id: IP_COUNT.id,
      chartTitle: IP_COUNT.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.write_request_cost_time_config = {
      id: WRITE_COST_TIME.id,
      chartTitle: WRITE_COST_TIME.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.read_cost_time_config = {
      id: READ_COST_TIME.id,
      chartTitle: READ_COST_TIME.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.read_cost_time_config = {
      id: READ_COST_TIME.id,
      chartTitle: READ_COST_TIME.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.center_tps_config = {
      id: CENTER_TPS.id,
      chartTitle: CENTER_TPS.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.center_qps_config = {
      id: CENTER_QPS.id,
      chartTitle: CENTER_QPS.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.config_count_config = {
      id: CONFIG_COUNT.id,
      chartTitle: CONFIG_COUNT.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.listener_count_config = {
      id: LISTENER_COUNT.id,
      chartTitle: LISTENER_COUNT.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.config_tps_config = {
      id: CONFIG_TPS.id,
      chartTitle: CONFIG_TPS.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };
    this.config_qps_config = {
      id: CONFIG_QPS.id,
      chartTitle: CONFIG_QPS.name,
      series: {},
      xAxis: { field: 'timePoint', mask: 'HH:MM' },
    };

    this.ClusterType = getParams('ClusterType');
    this.AppVersion = getParams('AppVersion');
  }
  componentDidMount = () => {
    this.isload = true; // 组件加载标识
    this.showTimmer = setTimeout(() => {
      const { startTime, endTime } = this.state;
      const _startTime = moment(startTime).toDate().getTime();
      const _endTime = moment(endTime).toDate().getTime();
      this.getAllTypesData(_startTime, _endTime);
    }, 500);
    const aliyun_lang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
    if (aliyun_lang !== 'zh') {
      this.setState({
        format: 'LLL'
      });
    }
  };
  componentWillUnmount = () => {
    this.isload = false;
    this.showTimmer && clearTimeout(this.showTimmer);
  };
  changeStartTime = (value) => {
    const startTime = value.format ? value.format('YYYY-MM-DD HH:mm') : value;
    this.startTime = startTime;
    this.setState({
      startTime,
    });
  };
  changeEndTime = (value) => {
    const endTime = value.format ? value.format('YYYY-MM-DD HH:mm') : value;
    this.endTime = endTime;
    this.setState({
      endTime,
    });
  };
  chooseTime = (value, type) => {
    this.setState({
      choosedTimmerId: `${value}${type}`,
      startTime: '',
      endTime: '',
      choosedValue: value,
      choosedType: type,
    });
    this.startTime = '';
    this.endTime = '';
    let resultTime = {};
    resultTime = this.getTimeFormatter(value, type);
    this.getAllTypesData(resultTime.startTime, resultTime.endTime);
  };
  checkStep = (num, type) => {
    switch (type) {
      case 'm': //分钟级
        this.step = 30;
        break;
      case 'h': //小时级 [1,6) 30, [6,24] 60
        if (num >= 1 && num < 6) {
          this.step = 60;
        }
        if (num >= 6 && num <= 24) {
          this.step = 600;
        }
        break;
      case 'd': // 天级别
        if (num >= 1 && num < 3) {
          this.step = 1800;
        }
        if (num >= 3 && num < 7) {
          this.step = 3600;
        }
        if (num === 7) {
          this.step = 3600;
        }
        break;
      default:
        break;
    }
  };
  getTimeFormatter = (num, type) => {
    this.checkStep(num, type);
    const endTime = moment().toDate().getTime();
    const startTime = moment().subtract(num, type).toDate().getTime();
    return { startTime, endTime };
  };
  cleanAllTypesData = () => {
    [
      CPU_USAGE,
      MEMORY_USAGE,
      ZK_NUMALIVECONNECTIONS,
      ZK_TPS,
      ZK_QPS,
      ZK_TPS_NEW,
      ZK_QPS_NEW,
      ZK_PACKETSRECEIVED,
      ZK_INMEMORYDATATREE_NODECOUNT,
      ZK_OUTSTANDINGREQUESTS,
      ZK_AvgRequestLatency,
    ].forEach((item) => {
      this[item.id] && this[item.id].updateData([]);
    });
  };

  getCommonMonitor = (startTime, endTime) => {
    this.getMonitorData(
      { startTime, endTime, monitorType: CPU_USAGE.id, valType: 'double' },
      () => {
        this.getMonitorData(
          { startTime, endTime, monitorType: MEMORY_USAGE.id, valType: 'double' },
          () => {}
        );
      }
    );
  };

  getNacosEurekaMonitor = (startTime, endTime) => {
    // 监控同步查询，循环嵌套写法
    this.getMonitorData({ startTime, endTime, monitorType: SERVICE_COUNT.id }, () => {
      this.getMonitorData({ startTime, endTime, monitorType: IP_COUNT.id }, () => {
        this.getMonitorData({ startTime, endTime, monitorType: WRITE_COST_TIME.id }, () => {
          this.getMonitorData({ startTime, endTime, monitorType: READ_COST_TIME.id }, () => {
            this.getMonitorData(
              { startTime, endTime, monitorType: CENTER_TPS.id, valType: 'double' },
              () => {
                this.getMonitorData({
                  startTime,
                  endTime,
                  monitorType: CENTER_QPS.id,
                  valType: 'double',
                });
              }
            );
          }); // 服务数
        }); // 实例数
      }); // 接口请求耗时
    }); //jvm耗用
  };

  getNacosConfigMonitor = (startTime, endTime) => {
    // 监控同步查询，循环嵌套写法
    this.getMonitorData({ startTime, endTime, monitorType: CONFIG_COUNT.id }, () => {
      this.getMonitorData({ startTime, endTime, monitorType: LISTENER_COUNT.id }, () => {
        this.getMonitorData(
          { startTime, endTime, monitorType: CONFIG_TPS.id, valType: 'double' },
          () => {
            this.getMonitorData(
              { startTime, endTime, monitorType: CONFIG_QPS.id, valType: 'double' },
              () => {}
            ); // 配置数
          }
        ); // 监听数
      }); // tps
    }); // qps
  };

  getZkMonitor = (startTime, endTime) => {
    // 监控同步查询，循环嵌套写法

    this.getMonitorData({ startTime, endTime, monitorType: ZK_NUMALIVECONNECTIONS.id }, () => {
      const [firstVersion, secondVersion] = split(this.AppVersion, '.');
      const isMore36 =
        Number(firstVersion) > 3 || (Number(firstVersion) === 3 && Number(secondVersion) >= 6); // 3.6.x 版本及以上
      if (this.AppVersion === '3.5.5' || isMore36) {
        this.getMonitorData(
          { startTime, endTime, monitorType: ZK_TPS_NEW.id, valType: 'double' },
          () => {
            this.getMonitorData(
              { startTime, endTime, monitorType: ZK_QPS_NEW.id, valType: 'double' },
              () => {
                this.getMonitorData(
                  { startTime, endTime, monitorType: ZK_INMEMORYDATATREE_NODECOUNT.id },
                  () => {
                    this.getMonitorData(
                      { startTime, endTime, monitorType: ZK_OUTSTANDINGREQUESTS.id },
                      () => {
                        this.getMonitorData({
                          startTime,
                          endTime,
                          monitorType: ZK_AvgRequestLatency.id,
                        }); // 平均请求延时
                      }
                    ); // 请求排队数
                  }
                ); // ZNode梳理
              }
            ); // QPS
          }
        ); // TPS
      } else {
        this.getMonitorData({ startTime, endTime, monitorType: ZK_TPS.id }, () => {
          this.getMonitorData({ startTime, endTime, monitorType: ZK_QPS.id }, () => {
            this.getMonitorData(
              { startTime, endTime, monitorType: ZK_INMEMORYDATATREE_NODECOUNT.id },
              () => {
                this.getMonitorData(
                  { startTime, endTime, monitorType: ZK_OUTSTANDINGREQUESTS.id },
                  () => {
                    this.getMonitorData({
                      startTime,
                      endTime,
                      monitorType: ZK_AvgRequestLatency.id,
                    }); // 平均请求延时
                  }
                ); // 请求排队数
              }
            ); // ZNode梳理
          }); // QPS
        }); // TPS
      }
    }); //客户端连接数
  };

  getAllTypesData = (startTime, endTime) => {
    this.setState({
      startTime: moment(startTime).format('YYYY-MM-DD HH:mm'),
      endTime: moment(endTime).format('YYYY-MM-DD HH:mm'),
    });
    this.cleanAllTypesData();

    this.getCommonMonitor(startTime, endTime);

    if (this.ClusterType === 'ZooKeeper') {
      this.getZkMonitor(startTime, endTime);
    }
    if (this.ClusterType === 'Eureka' || this.ClusterType === 'Nacos-Ans') {
      this.getNacosEurekaMonitor(startTime, endTime);
    }
    if (this.ClusterType === 'Nacos-Ans') {
      this.getNacosConfigMonitor(startTime, endTime);
    }
  };
  getMonitorData = ({ monitorType, startTime, endTime, valType = 'int' }, callback) => {
    let _startTime = Math.floor(startTime / 1000);
    let _endTime = Math.floor(endTime / 1000);
    const clusterId = getParams('clusterId');
    const InstanceId = getParams('InstanceId');
    const loadingInstance = this[`${monitorType}_loading`];
    request({
      url: 'com.alibaba.MSE.service.monitorquery',
      data: {
        clusterId,
        InstanceId,
        monitorType,
        startTime: _startTime,
        endTime: _endTime,
        step: this.step,
      },
      beforeSend: () => {
        loadingInstance && loadingInstance.openLoading();
      },
      success: (res) => {
        const { Data } = res.data;
        const data = Data || [];
        const podNameMap = {};
        const formatdata = [];
        let series = {};
        let valueArray = null;
        let podValueLength = [];
        data.forEach((item) => {
          const podName = item.podName;
          const values = item.values;
          series[podName] = podName; //指定图表项
          podNameMap[podName] = {};
          podNameMap[podName].values = values;
          podNameMap[podName].valuesMap = {};
          values.forEach((_item) => {
            let valuekeys = Object.keys(_item)[0];
            podNameMap[podName].valuesMap[valuekeys] = _item[valuekeys];
          });
          podValueLength.push({ podName, len: values.length });
        });
        podValueLength.sort((pre, next) => {
          //倒序排序，找到最长的数组
          return next.len - pre.len;
        });
        if (podValueLength[0]) {
          const longestPodName = podValueLength[0].podName;
          valueArray = podNameMap[longestPodName].values; //取最长数据的POD
          valueArray.forEach((data) => {
            let valuekeys = Object.keys(data)[0]; //{12321321:9}
            let newData = {};
            Object.keys(podNameMap).forEach((_key) => {
              const valuesMap = podNameMap[_key].valuesMap || {};
              const truelyValue = valuesMap[valuekeys];
              // newData[_key] = null;
              // newData.timePoint = null;
              if (truelyValue) {
                if (valType === 'int') {
                  newData[_key] = parseInt(truelyValue, 10);
                  newData.timePoint = parseInt(valuekeys, 10) * 1000;
                } else {
                  newData[_key] = parseFloat(parseInt(truelyValue * 100, 10)) / 100;
                  newData.timePoint = parseInt(valuekeys, 10) * 1000;
                }
              }
            });
            formatdata.push(newData);
          });
        }

        if (this[monitorType]) {
          this[monitorType].userUpdate(series);
          this[monitorType].updateData(formatdata);
        }
      },
      complete: () => {
        loadingInstance && loadingInstance.closeLoading();
        if (this.isload) {
          // 确定还在组件加载范围
          callback && callback();
        }
      },
    });
  };
  millionTimeFormat = (millisecond) => {
    let daymilli = 1000 * 60 * 60 * 24;
    let hourmilli = 1000 * 60 * 60;
    let minmilli = 1000 * 60;
    const d = Math.floor(millisecond / daymilli); //获取天
    if (d >= 1) {
      return { num: d, type: 'd' };
    }
    // let h_millisecond = millisecond % daymilli;
    const h = Math.floor(millisecond / hourmilli); //获取时
    if (h >= 1) {
      return { num: h, type: 'h' };
    }
    // let m_millisecond = h_millisecond % minmilli;
    const m = Math.floor(millisecond / minmilli); //获取分
    if (m >= 1) {
      return { num: m, type: 'm' };
    }
    return { num: millisecond / 1000, type: 's' }; //否则按照秒计算
  };
  searchByTime = () => {
    const { startTime, endTime } = this.state;
    if (!startTime) {
      Message.show({
        type: 'error',
        content: intl('mse.register.monitor.start_validate'),
      });
      return;
    }
    if (!endTime) {
      Message.show({
        type: 'error',
        content: intl('mse.register.monitor.end_validate'),
      });
      return;
    }
    if (moment(endTime).isBefore(startTime)) {
      Message.show({
        type: 'error',
        content: intl('mse.register.monitor.date_validate'),
      });
      return;
    }
    const startTimeMomentObj = moment(startTime);
    const endTimeMomentObj = moment(endTime);
    const millisecond = endTimeMomentObj.diff(startTimeMomentObj);
    const diffDay = millisecond / 1000 / 60 / 60 / 24; // 查询间隔时间
    if (diffDay > 7) {
      Message.show({
        type: 'error',
        content: intl('mse.register.monitor.delay_validate'),
      });
      return;
    }
    const formatDate = this.millionTimeFormat(millisecond);
    const { type, num } = formatDate;
    this.checkStep(num, type);
    let _startTime = startTimeMomentObj.toDate().getTime();
    let _endTime = endTimeMomentObj.toDate().getTime();
    this.getAllTypesData(_startTime, _endTime);
  };
  refreshMonitor = () => {
    this.isload = true; // 组件加载标识
    const resultTime = this.getTimeFormatter(this.state.choosedValue, this.state.choosedType);
    const { startTime, endTime } = resultTime;
    this.setState({
      startTime: moment(startTime).format('YYYY-MM-DD HH:mm'),
      endTime: moment(endTime).format('YYYY-MM-DD HH:mm'),
    });
    this.cleanAllTypesData();

    this.getCommonMonitor(startTime, endTime);

    if (this.ClusterType === 'ZooKeeper') {
      this.getZkMonitor(startTime, endTime);
    }
    if (this.ClusterType === 'Eureka' || this.ClusterType === 'Nacos-Ans') {
      this.getNacosEurekaMonitor(startTime, endTime);
    }
    if (this.ClusterType === 'Nacos-Ans') {
      this.getNacosConfigMonitor(startTime, endTime);
    }
  };
  updateMonitor = () => {
    const { InstanceId } = this.props;
    const chargeType = getParams('ChargeType');
    const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
    const isIntl = aliyunSite === 'INTL';
    const VirtualNetwork = ['JST', 'CAINIAO', 'NEW_RETAIL'];
    const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
    let commodityCode;
    let upgradeDomain = 'https://common-buy.aliyun.com';
    if (includes(VirtualNetwork, channel)) {
      upgradeDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      upgradeDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    chargeType === 'POSTPAY' ? commodityCode = 'mse' : commodityCode = 'mse_prepaid_public_cn';
    const upPriceUrl = `${upgradeDomain}/?commodityCode=${commodityCode}&orderType=upgrade&instanceId=${InstanceId}&upgradeType=upgrade`;
    window.open(upPriceUrl);
  }
  renderNacosEurekaView = () => {
    return (
      <div>
        <CommonLoading
          ref={(node) => {
            this[`${SERVICE_COUNT.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              formatterY={(val) => {
                if (val >= 1000 && val < 1000000) {
                  val = `${val / 1000}k`;
                } else if (val >= 1000000) {
                  val = `${val / 1000000}m`;
                }
                return val;
              }}
              ref={(node) => {
                this[SERVICE_COUNT.id] = node;
              }}
              {...this.service_count_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${IP_COUNT.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[IP_COUNT.id] = node;
              }}
              {...this.ip_count_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${WRITE_COST_TIME.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[WRITE_COST_TIME.id] = node;
              }}
              {...this.write_request_cost_time_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${READ_COST_TIME.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[READ_COST_TIME.id] = node;
              }}
              {...this.read_cost_time_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${CENTER_TPS.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[CENTER_TPS.id] = node;
              }}
              {...this.center_tps_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${CENTER_QPS.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[CENTER_QPS.id] = node;
              }}
              {...this.center_qps_config}
            />
          </div>
        </CommonLoading>
      </div>
    );
  };

  renderNacosConfigView = () => {
    return (
      <div>
        <CommonLoading
          ref={(node) => {
            this[`${CONFIG_COUNT.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              formatterY={(val) => {
                if (val >= 1000 && val < 1000000) {
                  val = `${val / 1000}k`;
                } else if (val >= 1000000) {
                  val = `${val / 1000000}m`;
                }
                return val;
              }}
              ref={(node) => {
                this[CONFIG_COUNT.id] = node;
              }}
              {...this.config_count_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${LISTENER_COUNT.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[LISTENER_COUNT.id] = node;
              }}
              {...this.listener_count_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${CONFIG_TPS.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[CONFIG_TPS.id] = node;
              }}
              {...this.config_tps_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${CONFIG_QPS.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[CONFIG_QPS.id] = node;
              }}
              {...this.config_qps_config}
            />
          </div>
        </CommonLoading>
      </div>
    );
  };

  renderCommonMonitorView = () => {
    return (
      <div>
        <CommonLoading
          ref={(node) => {
            this[`${CPU_USAGE.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              formatterY={(val) => {
                return `${val}%`;
              }}
              ref={(node) => {
                this[CPU_USAGE.id] = node;
              }}
              {...this.cpu_usage_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${MEMORY_USAGE.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              formatterY={(val) => {
                return `${val}%`;
              }}
              ref={(node) => {
                this[MEMORY_USAGE.id] = node;
              }}
              {...this.memory_usage_config}
            />
          </div>
        </CommonLoading>
      </div>
    );
  };

  renderZkView = () => {
    const [firstVersion, secondVersion] = split(this.AppVersion, '.');
    const isMore36 =
      Number(firstVersion) > 3 || (Number(firstVersion) === 3 && Number(secondVersion) >= 6); // 3.6.x 版本及以上
    return (
      <div>
        <CommonLoading
          ref={(node) => {
            this[`${ZK_NUMALIVECONNECTIONS.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              formatterY={(val) => {
                if (val >= 1000 && val < 1000000) {
                  val = `${val / 1000}k`;
                } else if (val >= 1000000) {
                  val = `${val / 1000000}m`;
                }
                return val;
              }}
              ref={(node) => {
                this[ZK_NUMALIVECONNECTIONS.id] = node;
              }}
              {...this.zk_NumAliveConnections_config}
            />
          </div>
        </CommonLoading>
        <ComIf if={this.AppVersion === '3.5.5' || isMore36}>
          <CommonLoading
            ref={(node) => {
              this[`${ZK_TPS_NEW.id}_loading`] = node;
            }}
          >
            <div>
              <LineChart
                padding={[10, 60, 100, 60]}
                ref={(node) => {
                  this[ZK_TPS_NEW.id] = node;
                }}
                {...this.zookeeper_TPS_new_config}
              />
            </div>
          </CommonLoading>
        </ComIf>
        <ComIf if={!(this.AppVersion === '3.5.5' || isMore36)}>
          <CommonLoading
            ref={(node) => {
              this[`${ZK_TPS.id}_loading`] = node;
            }}
          >
            <div>
              <LineChart
                padding={[10, 60, 100, 60]}
                ref={(node) => {
                  this[ZK_TPS.id] = node;
                }}
                {...this.zookeeper_TPS_config}
              />
            </div>
          </CommonLoading>
        </ComIf>
        <ComIf if={this.AppVersion === '3.5.5' || isMore36}>
          <CommonLoading
            ref={(node) => {
              this[`${ZK_QPS_NEW.id}_loading`] = node;
            }}
          >
            <div>
              <LineChart
                padding={[10, 60, 100, 60]}
                ref={(node) => {
                  this[ZK_QPS_NEW.id] = node;
                }}
                {...this.zookeeper_QPS_new_config}
              />
            </div>
          </CommonLoading>
        </ComIf>
        <ComIf if={!(this.AppVersion === '3.5.5' || isMore36)}>
          <CommonLoading
            ref={(node) => {
              this[`${ZK_QPS.id}_loading`] = node;
            }}
          >
            <div>
              <LineChart
                padding={[10, 60, 100, 60]}
                ref={(node) => {
                  this[ZK_QPS.id] = node;
                }}
                {...this.zookeeper_QPS_config}
              />
            </div>
          </CommonLoading>
        </ComIf>
        <CommonLoading
          ref={(node) => {
            this[`${ZK_INMEMORYDATATREE_NODECOUNT.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[ZK_INMEMORYDATATREE_NODECOUNT.id] = node;
              }}
              {...this.zookeeper_InMemoryDataTree_NodeCount_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${ZK_OUTSTANDINGREQUESTS.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[ZK_OUTSTANDINGREQUESTS.id] = node;
              }}
              {...this.zookeeper_OutstandingRequests_config}
            />
          </div>
        </CommonLoading>
        <CommonLoading
          ref={(node) => {
            this[`${ZK_AvgRequestLatency.id}_loading`] = node;
          }}
        >
          <div>
            <LineChart
              padding={[10, 60, 100, 60]}
              ref={(node) => {
                this[ZK_AvgRequestLatency.id] = node;
              }}
              {...this.zookeeper_AvgRequestLatency_config}
            />
          </div>
        </CommonLoading>
      </div>
    );
  };

  updateMonitorTitle = (
    <div>
      <Icon type="warning" style={{ color: '#ffc440', verticalAlign: 'middle' }} />
      <span
        style={{ color: '#333', fontSize: 18, verticalAlign: 'middle', marginLeft: 8 }}
      >{intl('mse.register.monitor.notice.update')}</span>
    </div>
  );

  openDialog = () => {
    this.setState({
      updateVisible: true
    });
  };


  upgradeMonitor = () => {
    const InstanceId = getParams('InstanceId');
    request({
      url: 'com.alibaba.MSE.service.NacosPrometheusCompatible',
      data: {
        InstanceId,
      },
      beforeSend: () => {
        this.setState({
          isLoading: true,
        });
      },
      success: (res) => {
        if (res.code === '200' && res.data) {
          this.setState({
            updateVisible: false
          });
        }
      },
      complete: () => {
        this.setState({
          isLoading: false,
          updateVisible: false,
        });
        hashHistory.push('/InstanceList');
      },
    });
    // this.setState({
    //   updateVisible: false,
    //   isLoading: false,
    // });
    // hashHistory.push('/InstanceList');
  };

  onCacelUpdate = () => {
    this.setState({
      updateVisible: false
    });
  };

  render() {
    const { choosedTimmerId, startTime, endTime, updateVisible, isLoading, format } = this.state;
    const { VersionType, ClusterType, AppVersion } = this.props;
    return (
      <div style={{ position: 'relative' }}>
        <Tab shape="wrapped">
          <Tab.Item title={intl('mse.register.monitor')} key="monitor">
            <div>
              <ul className="choosed-list" style={{ marginTop: 10, marginBottom: 10 }}>
                {TIMMER_CHOOSE.map((item) => {
                  const _key = `${item.value}${item.type}`;
                  return (
                    <li
                      key={_key}
                      className={`choosed-list-item${choosedTimmerId === _key ? ' active' : ''}`}
                      onClick={() => this.chooseTime(item.value, item.type)}
                    >
                      {item.name}
                    </li>
                  );
                })}
              </ul>
              <span style={{ marginRight: 10 }}>
                {intl('mse.register.monitor.start')}{' '}
                <DatePicker
                  style={{ width: 160 }}
                  showTime={{ format: 'HH:mm', minuteStep: 15 }}
                  format={format}
                  onChange={this.changeStartTime}
                  value={startTime}
                />
              </span>
              <span style={{ marginLeft: 10 }}>
                {intl('mse.register.monitor.end')}{' '}
                <DatePicker
                  style={{ width: 160 }}
                  showTime={{ format: 'HH:mm', minuteStep: 15 }}
                  format={format}
                  onChange={this.changeEndTime}
                  value={endTime}
                />
              </span>
              <Button type="primary" style={{ marginLeft: 10 }} onClick={this.searchByTime}>
                {intl('mse.common.search')}
              </Button>
              <Button type="normal" style={{ marginLeft: 10 }} onClick={this.refreshMonitor}>
                <Icon type="refresh" />
              </Button>
              <ComIf if={this.ClusterType === 'ZooKeeper'}>
                <div>{this.renderCommonMonitorView()}</div>
                <div>{this.renderZkView()}</div>
              </ComIf>
              <ComIf if={this.ClusterType === 'Eureka' || this.ClusterType === 'Nacos-Ans'}>
                <div>{this.renderNacosEurekaView()}</div>
              </ComIf>
              <ComIf if={this.ClusterType === 'Nacos-Ans'}>
                <div>{this.renderNacosConfigView()}</div>
                <div>{this.renderCommonMonitorView()}</div>
              </ComIf>
            </div>
          </Tab.Item>
        </Tab>
        <If condition={ClusterType === 'Nacos-Ans' && (VersionType === 'mse_pro' || VersionType === 'mse_dev')} >
          <div className="mse-message-monitor" style={MenuNoticeStyle}>
            <Message type="notice" style={{ width: '90%', color: '#f68300', marginRight: '20px', paddingRight: '50px' }}>
                {intl('mse.register.monitor.notice_pro')}
                <a
                  href="https://help.aliyun.com/document_detail/126757.html"
                  target="_blank"
                >
                  {intl('mse.register.monitor.notice.learnmore')}
                </a>
            </Message>
            <Button className="mse-update-monitor" style={{ display: 'inline', textAlign: 'right' }} type="primary" onClick={this.openDialog}>
                {intl('mse.register.monitor.notice.update')}
            </Button>
          </div>
        </If>
        <If condition={ClusterType === 'Nacos-Ans' && VersionType === 'mse_basic'}>
          <div className="mse-message-monitor" style={MenuNoticeStyle}>
            <Message type="notice" style={{ width: '800px', color: '#f68300', marginRight: '20px', paddingRight: '50px' }}>
              {intl('mse.register.monitor.notice_dev')}
                <a
                  href="https://help.aliyun.com/document_detail/126757.html"
                  target="_blank"
                >
                  {intl('mse.register.monitor.notice.learnmore')}
                </a>
            </Message>
            <Button className="mse-update-monitor" style={{ display: 'inline' }} type="primary" onClick={this.updateMonitor}>
                  {intl('mse.register.monitor.notice.update_dev')}
            </Button>
          </div>
        </If>
        <If condition={this.ClusterType === 'ZooKeeper'}>
          {/* <Balloon
            trigger={ */}
              <div style={{ position: 'absolute', top: 0, left: 80 }}>
                <Icon type="prompt" size="small" style={{ color: '#0064c8', margin: 8 }} />
                <span>{intl('mse.register.monitor.zk')}<a target="_blank" href="https://help.aliyun.com/document_detail/216036.html">{intl('mse.register.monitor.notice.learnmore')}</a></span>
              </div>
            {/* }
            align="r"
            alignEdge
            closable={false}
          > */}
            {/* ZooKeeper专业版提供更丰富的业务监控看板，包含70余项指标，并支持用户集成到自定义大盘。此外专业版性能及稳定性更优于基础版，<a target="_blank" href="https://help.aliyun.com/document_detail/216036.html">了解更多</a> */}
          {/* </Balloon> */}
        </If>
        <Dialog
          title={this.updateMonitorTitle}
          footer={false}
          visible={updateVisible}
          onClose={this.onCacelUpdate}
        >
        <div style={{ padding: '10px' }}>
          {intl('mse.register.monitor.dialog_title')}
        </div>
        <div style={{ padding: '10px' }}>
          {intl('mse.register.monitor.dialog_1')}
        </div>
        <div style={{ padding: '10px' }}>
          {intl('mse.register.monitor.dialog_2')}
          {
            aliwareGetCookieByKeyName('aliyun_site') !== 'INTL' &&
            <a
              href="https://help.aliyun.com/document_detail/42923.html"
              target="_blank"
            >
            {intl('mse.register.monitor.dialog_2.href')}
            </a>
          }
        </div>
        <If condition={compareVersion(AppVersion, '2.0.4') < 0}>
          <div
            style={{ padding: '10px' }}
          >
            {intl('mse.register.monitor.dialog_3')}
          </div>
        </If>
        <div style={{ margin: '28px 0', textAlign: 'right' }}>
          <Button
            type="primary"
            style={{ marginRight: 10 }}
            onClick={this.upgradeMonitor}
            loading={isLoading}
          >
            {intl('mse.register.monitor.dialog.confirm')}
          </Button>
          <Button onClick={this.onCacelUpdate}>
            {intl('mse.register.monitor.dialog.cancel')}
          </Button>
        </div>
        </Dialog>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default MonitorComponent;
