import React, { useEffect, useState, useRef } from 'react';
import services from 'utils/services';
import { Tab, Loading, IconButton, Dialog, Icon } from '@ali/cn-design';
import { Message, Button } from '@ali/wind';
import { forEach, includes } from 'lodash';
import { compareVersion } from '../../utils/utils';
import intl from '@ali/wind-intl';
import './index.less';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 监控页面 专业版本
 */

const MenuRightStyle = {
  display: 'flex',
  height: 36,
  alignItems: 'center',
  justifyContent: 'end',
  position: 'absolute',
  top: 0,
  right: 0,
  zIndex: 1,
};

const MonitorItems_Nacos = {
  OVERVIEW: 'mse-nacos-overview-url',
  NAMING: 'mse-nacos-naming-url',
  CONFIG: 'mse-nacos-config-url',
  PUSH: 'mse-nacos-push-url',
  CONNECTION: 'mse-nacos-connection-url',
  JVM: 'mse-nacos-jvm-url',
  RESOURCE: 'mse-nacos-resource-url',
};

const MonitorProfessNacos = (props) => {
  const { prometheusVersion = '' } = props;
  const iframeRef = useRef();
  const heightRef = useRef(0);
  const cacheBoards = useRef(new Map());
  const [loading, setLoading] = useState(false);
  const [updateVisible, setUpdateVisible] = useState(false);
  const [currentMonitor, setCurrentMonitor] = useState(prometheusVersion === 'pro' ? MonitorItems_Nacos.OVERVIEW : MonitorItems_Nacos.NAMING);
  const [iframeSrc, setIframeSrc] = useState('');

  const MonitorNames_Nacos_profess = new Map()
    .set('mse-nacos-overview-url', intl('mse.register.monitor.overview'))
    .set('mse-nacos-naming-url', intl('mse.register.monitor.register'))
    .set('mse-nacos-config-url', intl('mse.register.monitor.configuration'))
    .set('mse-nacos-push-url', intl('mse.register.monitor.push'))
    .set('mse-nacos-connection-url', intl('mse.register.monitor.connection'))
    .set('mse-nacos-jvm-url', intl('mse.register.monitor.jvm'))
    .set('mse-nacos-resource-url', intl('mse.register.monitor.resource_nacos'));

  const MonitorNames_Nacos_dev = new Map()
    .set('mse-nacos-naming-url', intl('mse.register.monitor.register'))
    .set('mse-nacos-config-url', intl('mse.register.monitor.configuration'))
    .set('mse-nacos-resource-url', intl('mse.register.monitor.resource_nacos'));

  const MonitorNames = prometheusVersion === 'pro' ? MonitorNames_Nacos_profess : MonitorNames_Nacos_dev;

  useEffect(() => {
    getRegisterMonitor();
    window.addEventListener('resize', onIframeHeightChange);
    return () => {
      window.removeEventListener('resize', onIframeHeightChange);
    };
  }, []);

  const getRegisterMonitor = async () => {
    setLoading(true);
    const InstanceId = getParams('InstanceId');
    const res = await services.fetchRegisterMonitor({
      customErrorHandle: (err, data, callback) => {
        setLoading(false);
        callback();
      },
      params: {
        InstanceId,
        Title: prometheusVersion === 'pro' ? MonitorItems_Nacos.OVERVIEW : MonitorItems_Nacos.NAMING
      },
      ignoreError: true,
    });
    const { UrlMap } = res;
    if (UrlMap) {
      forEach(UrlMap, (value, key) => {
        cacheBoards.current.set(key, value);
      });
    }
    setIframeSrc(cacheBoards.current.get(prometheusVersion === 'pro' ? MonitorItems_Nacos.OVERVIEW : MonitorItems_Nacos.NAMING));
    setLoading(false);
  };

  const onIframeHeightChange = (key) => {
    if (!iframeRef.current) return;
    heightRef.current = document.documentElement.clientHeight - 200;
    iframeRef.current.height = document.documentElement.clientHeight - 200;
  };

  const openNewpage = () => {
    const embedUri = cacheBoards.current.get(currentMonitor);
    if (!embedUri) return;
    let uri = embedUri;
    if (includes(embedUri, 'kiosk=tv2')) {
      uri = embedUri.replace(/kiosk=tv2/, 'kiosk=tv1');
    }
    if (!uri) return;
    window.open(uri, '_blank');
  };

  const monitorTabs_Nacos_profess = [
    { tab: intl('mse.register.monitor.overview'), key: MonitorItems_Nacos.OVERVIEW },
    { tab: intl('mse.register.monitor.register'), key: MonitorItems_Nacos.NAMING },
    { tab: intl('mse.register.monitor.configuration'), key: MonitorItems_Nacos.CONFIG },
    { tab: intl('mse.register.monitor.push'), key: MonitorItems_Nacos.PUSH },
    { tab: intl('mse.register.monitor.connection'), key: MonitorItems_Nacos.CONNECTION },
    { tab: intl('mse.register.monitor.jvm'), key: MonitorItems_Nacos.JVM },
    { tab: intl('mse.register.monitor.resource_nacos'), key: MonitorItems_Nacos.RESOURCE },
  ];

  const monitorTabs_Nacos_dev = [
    { tab: intl('mse.register.monitor.register'), key: MonitorItems_Nacos.NAMING },
    { tab: intl('mse.register.monitor.configuration'), key: MonitorItems_Nacos.CONFIG },
    { tab: intl('mse.register.monitor.resource_nacos'), key: MonitorItems_Nacos.RESOURCE },
  ];

  const monitorTabs =
    prometheusVersion === 'pro' ? monitorTabs_Nacos_profess : monitorTabs_Nacos_dev;

  const changeIframeSrc = async (key) => {
    setCurrentMonitor(key);
    if (!cacheBoards.current.get(key)) {
      setLoading(true);
      const InstanceId = getParams('InstanceId');
      const res = await services.fetchRegisterMonitor({
        customErrorHandle: (err, data, callback) => {
          setLoading(false);
          callback();
        },
        params: {
          InstanceId,
          Title: key,
        },
        ignoreError: true,
      });
      const { UrlMap } = res;
      if (UrlMap) {
        forEach(UrlMap, (value, key) => {
          cacheBoards.current.set(key, value);
        });
      }
      setLoading(false);
    }
    setIframeSrc(cacheBoards.current.get(key));
  };

  return (
    <React.Fragment>
      <Loading visible={loading} style={{ width: '100%', minHeight: 200, position: 'relative' }}>
        <div className="monitor-tabs-nav">
          <Tab
            shape="wrapped"
            activeKey={currentMonitor}
            defaultActiveKey={
              prometheusVersion === 'pro' ? MonitorItems_Nacos.OVERVIEW : MonitorItems_Nacos.NAMING
            }
            onChange={(key) => changeIframeSrc(key)}
            extra={
              <IconButton type="external-link-alt" onClick={openNewpage}>
                {`${intl('mse.register.monitor.openpage')} ${MonitorNames.get(currentMonitor)}`}
              </IconButton>
            }
          >
            {monitorTabs.map((tab) => {
              const { tab: title, key } = tab;
              return <Tab.Item title={title} key={key} />;
            })}
          </Tab>
        </div>

        <iframe
          ref={iframeRef}
          frameBorder={0}
          width="100%"
          scrolling="no"
          height={heightRef.current}
          onLoad={onIframeHeightChange}
          src={iframeSrc}
        />
        {/* <div style={MenuRightStyle}>
          <IconButton type="external-link-alt" onClick={openNewpage}>
            {`${intl('mse.register.monitor.openpage')} ${MonitorNames.get(currentMonitor)}`}
          </IconButton>
        </div> */}
      </Loading>
    </React.Fragment>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default MonitorProfessNacos;
