import React, { useEffect, useState, useRef } from 'react';
import services from 'utils/services';
import { Tab, Loading, IconButton } from '@ali/cn-design';
import { forEach, includes } from 'lodash';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 监控页面 专业版本
 */

const MenuRightStyle = {
  display: 'flex',
  height: 36,
  alignItems: 'center',
  justifyContent: 'end',
  position: 'absolute',
  top: 0,
  right: 0,
  zIndex: 1,
};

const MonitorItems_ZooKeeper = {
  BUSINESS: 'mse-zk-url',
  RESOURCE: 'mse-zk-resource-url',
  TOP: 'mse-zk-top-url',
};


const MonitorProfessZk = () => {
  const iframeRef = useRef();
  const heightRef = useRef(0);
  const cacheBoards = useRef(new Map());
  const [loading, setLoading] = useState(false);
  const [currentMonitor, setCurrentMonitor] = useState(MonitorItems_ZooKeeper.BUSINESS);

  const MonitorNames = new Map()
    .set('mse-zk-url', intl('mse.register.monitor.business'))
    .set('mse-zk-resource-url', intl('mse.register.monitor.resource'))
    .set('mse-zk-top-url', intl('mse.register.monitor.topn'));


  useEffect(() => {
    getRegisterMonitor();
    window.addEventListener('resize', onIframeHeightChange);
    return () => {
      window.removeEventListener('resize', onIframeHeightChange);
    };
  }, []);


  const getRegisterMonitor = async () => {
    setLoading(true);
    const InstanceId = getParams('InstanceId');
    const res = await services.fetchRegisterMonitor({
      customErrorHandle: (err, data, callback) => {
        setLoading(false);
        callback();
      },
      params: {
        InstanceId,
      },
      ignoreError: true,
    });
    const { UrlMap } = res;
    if (UrlMap) {
      forEach(UrlMap, (value, key) => {
        cacheBoards.current.set(key, value);
      });
    }
    setLoading(false);
  };

  const onIframeHeightChange = () => {
    if (!iframeRef.current) return;
    heightRef.current = document.documentElement.clientHeight - 200;
    iframeRef.current.height = document.documentElement.clientHeight - 200;
  };

  const openNewpage = () => {
    const embedUri = cacheBoards.current.get(currentMonitor);
    if (!embedUri) return;
    let uri = embedUri;
    if (includes(embedUri, 'kiosk=tv2')) {
      uri = embedUri.replace(/kiosk=tv2/, 'kiosk=tv1');
    }
    if (!uri) return;
    window.open(uri, '_blank');
  };

  const monitorTabs = [
    { tab: intl('mse.register.monitor.business'), key: MonitorItems_ZooKeeper.BUSINESS },
    { tab: intl('mse.register.monitor.resource'), key: MonitorItems_ZooKeeper.RESOURCE },
    { tab: intl('mse.register.monitor.topn'), key: MonitorItems_ZooKeeper.TOP },
  ];


  return (
    <React.Fragment>
      <Loading visible={loading} style={{ width: '100%', minHeight: 200, position: 'relative' }}>
        <Tab
          shape="wrapped"
          activeKey={currentMonitor}
          defaultActiveKey={MonitorItems_ZooKeeper.BUSINESS}
          onChange={(key) => setCurrentMonitor(key)}
        >
          {monitorTabs.map((tab) => {
            const { tab: title, key } = tab;
            return (
              <Tab.Item title={title} key={key}>
                <iframe
                  ref={iframeRef}
                  frameBorder={0}
                  width="100%"
                  scrolling="no"
                  height={heightRef.current}
                  onLoad={onIframeHeightChange}
                  src={cacheBoards.current.get(key)}
                />
              </Tab.Item>
            );
          })}
        </Tab>
        <div style={MenuRightStyle}>
          <IconButton type="external-link-alt" onClick={openNewpage}>
            {`${intl('mse.register.monitor.openpage')} ${MonitorNames.get(currentMonitor)}`}
          </IconButton>
        </div>
      </Loading>
    </React.Fragment>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default MonitorProfessZk;
