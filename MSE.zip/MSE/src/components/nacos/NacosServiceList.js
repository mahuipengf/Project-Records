import React from 'react';
import { TableContainer, isEmpty, Switch, Input } from '@ali/cn-design';
import CommonLoading from '../common/CommonLoading';
import CommonDialog from '../base/CommonDialog';
import NacosClusterList from './NacosClusterList';
import CommonBalloon from '../common/CommonBalloon';
import Actions, { LinkButton } from '@alicloud/console-components-actions';
import { Dialog, Button, Icon, Message, Balloon, Select } from '@ali/wind';
import NacosServiceCreate from './NacosServiceCreate';
import _, { get, includes } from 'lodash';
import services from 'utils/services';
import { getCurrentRegion } from 'utils';
import intl from '@ali/wind-intl';
import NacosClusterAdvancedWeights from './NacosClusterAdvancedWeights';
import Cookie from 'js-cookie';
import { compareNacosVersion } from '../../utils/utils';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * nacos服务列表
 */
class NacosServiceList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      namespaces: [],
      dialogTitle: '',
      refreshIndex: 0,
      showIndex: 0,
      regionLabel: '',
      NamespaceId: '',
      namespaceLabel: '',
      NamingCreateServiceSupported: false,
      active: 0,
      renderTag: null,
      serviceName: '',
      groupName: '',
      hasIpCount: true,
      cacheServices: [],
      cacheGroup: [],
      isGTNACOS_2_1_2_1: false,
    };
  }

  componentDidMount = () => {
    const _isGTNACOS_2_1_2_1 = compareNacosVersion();
    const { loadSuccess, activeNamespaceId, namespaces = [] } = this.props;
    if (loadSuccess && namespaces.length) {
      const { namespaceId = '', regionLabel = '', namespaceLabel = '' } = this.useCurrentInfo(
        activeNamespaceId,
        namespaces
      );
      this.setState({
        namespaces,
        namespaceId,
        regionLabel,
        namespaceLabel,
        isGTNACOS_2_1_2_1: _isGTNACOS_2_1_2_1
      });
    }
    this.getConfigCreate();
  };

  useCurrentInfo = (activeNamespaceId, namespaces) => {
    let regions = _.get(window, 'ALIYUN_CONSOLE_CONFIG.STATIC_API.regions', []);
    regions = regions.map((item) => {
      return {
        name: item.regionName,
        regionId: item.regionId,
      };
    });
    if (isEmpty(regions) || isEmpty(namespaces)) return {};
    const { name, regionId } =
      _.find(regions, {
        regionId: getCurrentRegion(),
      }) ||
      _.first(regions) ||
      {};
    const { label, value } =
      _.find(namespaces, {
        value: activeNamespaceId,
      }) ||
      _.first(namespaces) ||
      {};
    return {
      regionName: name,
      regionId,
      namespaceName: label,
      namespaceId: value,
      regionLabel: `${name}(${regionId})`,
      namespaceLabel: `${label}(${value})`,
    };
  };

  getConfigCreate = async () => {
    const InstanceId = getParams('InstanceId');
    const ConfigType = getParams('ClusterType');
    const Data = await services.QueryConfig({
      params: {
        InstanceId,
        ConfigType,
      },
    });
    const { NamingCreateServiceSupported = false } = Data;
    this.setState({
      NamingCreateServiceSupported,
    });
  };

  fetchNacosService = async (data) => {
    const { activeNamespaceId } = this.props;
    const ClusterId = getParams('ClusterId');
    const InstanceId = getParams('InstanceId');
    const params = {
      PageNum: data.pageNumber,
      PageSize: data.pageSize,
      InstanceId,
      NamespaceId: `${activeNamespaceId === 'public' ? '' : activeNamespaceId}`,
      ClusterId: `${ClusterId}:${activeNamespaceId === 'public' ? '' : activeNamespaceId}`,
      ...data,
    };
    return request({
      url: 'com.alibaba.MSE.service.ListAnsServices',
      data: params,
      success: () => {},
    });
  };

  fetchData = async (params) => {
    const { loadSuccess, namespaces = [] } = this.props;
    const { serviceName, groupName, hasIpCount } = this.state;
    const newParams = {
      ...params,
      HasIpCount: hasIpCount,
      // HasIpCount: false,
    };
    if (serviceName) {
      newParams.ServiceName = serviceName;
    }
    if (groupName) {
      newParams.GroupName = groupName;
    }
    if (loadSuccess && namespaces.length) {
      window.CN_TRACKER.send({
        name: 'getList',
        type: 'mse-register-nacos-service-list',
      });
      const {
        data: { Data, TotalCount },
      } = await this.fetchNacosService(newParams);
      this.cacheSearchValues({
        ServiceName: newParams.ServiceName,
        GroupName: newParams.GroupName,
      });
      return {
        Data,
        TotalCount,
      };
    }
    return {
      Data: [],
      TotalCount: 0,
    };
  };

  cacheSearchValues = (searchValues) => {
    // eslint-disable-next-line no-shadow
    const { ServiceName, GroupName } = searchValues;
    if (!ServiceName && !GroupName) return;
    const MAX_CACHE_NUM = 20;
    // 过滤缓存key 除去value为undefined 和 空字符串
    const cacheKeys = ['ServiceName', 'GroupName'].filter((key) => {
      const value = searchValues[key];
      return value && value.trim();
    });

    for (let i = 0; i < cacheKeys.length; i++) {
      const key = cacheKeys[i];
      const value = searchValues[key];
      const cacheValue = JSON.parse(localStorage.getItem(key) || '[]');

      // 1、如果有重复的不再添加
      const _value = cacheValue && cacheValue.find((val) => val === value.trim());

      // eslint-disable-next-line no-continue
      if (_value) continue;

      // 2、将超出缓存数量的记录 从数组末尾删除
      if (cacheValue.length >= MAX_CACHE_NUM) cacheValue.pop();

      // 将最新的插入头部
      cacheValue.unshift(value.trim());
      localStorage.setItem(key, JSON.stringify(cacheValue));
    }
  };

  renderOption = (value, index, record) => {
    const { IpCount, Name } = record;
    const defaultTrigger = (
      <LinkButton key="3" disabled>
        {intl('mse.common.delete')}
      </LinkButton>
    );
    return (
      <Actions expandTriggerType="hover" threshold={2} menuProps={{ style: { maxWidth: '200px' } }}>
        <If condition={getParams('MseVersion') === 'mse_pro'}>
          <LinkButton
            key="3"
            onClick={() => {
              this.openServiceTrace(record);
              window.CN_TRACKER.send({
                name: `${Name}-track`,
                type: 'mse-register-nacos-service-list',
              });
            }}
          >
            {intl('mse.register.config_trace')}
          </LinkButton>
        </If>
        <If condition={this.state.isGTNACOS_2_1_2_1}>
          <LinkButton
            key="4"
            onClick={() => {
              this.openInterfaceInfo(record);
              window.CN_TRACKER.send({ name: `${Name}-governance`, type: 'mse-register-nacos-service-list' });
            }}
          >
            接口详情
          </LinkButton>
        </If>
        <If condition={!this.state.isGTNACOS_2_1_2_1}>
          <LinkButton
            key="4"
            onClick={() => {
              this.openServiceGovernance();
              window.CN_TRACKER.send({ name: `${Name}-governance`, type: 'mse-register-nacos-service-list' });
            }}
          >
            {intl('mse.register.service.governance')}
          </LinkButton>
        </If>
        <If condition={IpCount === 0}>
          <LinkButton
            key="2"
            onClick={() => {
              this.deleteService(record);
              window.CN_TRACKER.send({
                name: `${Name}-delete`,
                type: 'mse-register-nacos-service-list',
              });
            }}
          >
            {intl('mse.common.delete')}
          </LinkButton>
        </If>
        <If condition={IpCount !== 0}>
          <Balloon trigger={defaultTrigger} closable={false} align="t">
            {intl('mse.register.service.delete_hint')}
          </Balloon>
        </If>
      </Actions>
    );
  };

  openServiceTrace = (record) => {
    const { Name = '', GroupName = '' } = record;
    const { activeNamespaceId } = this.props;
    const ClusterId = getParams('ClusterId');
    const ClusterName = getParams('ClusterName');
    const ClusterType = getParams('ClusterType');
    const InstanceId = getParams('InstanceId');
    const AppVersion = getParams('AppVersion');
    const MseVersion = getParams('MseVersion');
    hashHistory.push({
      pathname: '/Instance/Service/Detail',
      search: `ClusterId=${ClusterId}&ClusterName=${ClusterName}&ClusterType=${ClusterType}&InstanceId=${InstanceId}&AppVersion=${AppVersion}&MseVersion=${MseVersion}&ServiceName=${Name}&GroupName=${GroupName}&NamespaceId=${activeNamespaceId}&subTitle=${Name}`,
      state: {
        tabKey: 'trace',
      },
    });
  };

  goServiceDetail = (record) => {
    const { Name = '', GroupName = '' } = record;
    const { activeNamespaceId } = this.props;
    const ClusterId = getParams('ClusterId');
    const ClusterName = getParams('ClusterName');
    const ClusterType = getParams('ClusterType');
    const InstanceId = getParams('InstanceId');
    const AppVersion = getParams('AppVersion');
    const MseVersion = getParams('MseVersion');
    window.CN_TRACKER.send({
      name: `${Name}-detail`,
      type: 'mse-register-nacos-service-list',
    });
    hashHistory.push(
      `/Instance/Service/Detail?ClusterId=${ClusterId}&ClusterName=${ClusterName}&ClusterType=${ClusterType}&InstanceId=${InstanceId}&AppVersion=${AppVersion}&MseVersion=${MseVersion}&ServiceName=${Name}&GroupName=${GroupName}&NamespaceId=${activeNamespaceId}&subTitle=${Name}`
    );
  };

  deleteService = (record) => {
    const { activeNamespaceId } = this.props;
    const { Name, GroupName } = record;
    Dialog.confirm({
      type: 'warning',
      title: intl('mse.register.service.delete'),
      content: (
        <div style={{ width: 500 }}>
          {intl.html('mse.common.delete_confirm', { name: record.Name })}
        </div>
      ),
      onOk: () => {
        return new Promise(async (resolve, reject) => {
          request({
            url: 'com.alibaba.MSE.service.DeleteNacosService',
            data: {
              InstanceId: getParams('InstanceId'),
              NamespaceId: activeNamespaceId,
              ServiceName: Name,
              GroupName,
            },
            success: (res) => {
              if (res.code === '200' && res.data) {
                resolve();
                Message.success(intl('mse.common.delete_success'));
                this.setState({
                  refreshIndex: Date.now(),
                });
              }
            },
          });
        });
      },
      messageProps: {
        type: 'warning',
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
  };

  openInterfaceInfo = async (record) => {
    const { GroupName, Source, Name } = record;
    const InstanceId = getParams('InstanceId');
    const ClusterId = getParams('ClusterId');
    const ClusterName = getParams('ClusterName');
    const { activeNamespaceId, namespaces = [] } = this.props;
    const { namespaceId = '' } = this.useCurrentInfo(activeNamespaceId, namespaces);
    if (includes(['console', 'sdk'], Source)) {
      const { Data = [], TotalCount = 0 } = await services.getListAnsInstances({
        params: {
          GroupName,
          InstanceId,
          pageNum: 1,
          pageSize: 10,
          // ClusterName,
          NamespaceId: namespaceId,
          ServiceName: Name,
        },
        customErrorHandle: (err, data, callback) => {
          // callback(); 不要错误弹框
          this.openServiceGovernance();
        },
      });
      if (Array.isArray(Data) && !!Data.length) {
        const instance = Data[0];
        const metadata = instance.Metadata || {};
        const appId = metadata['__micro.service.app.id__'];
        if (appId) {
          const { AppId, AppName, Namespace } = await services.GetApplicationDetail({
            params: {
              AppId: appId,
              Region: window.regionId
            },
            customErrorHandle: (err, data, callback) => {
              this.openServiceGovernance();
            },
          });
          const url = `${window.location.origin}/#/msc/appList/info/systemGuardApiDetails?armsAppId=${AppId}&ahasAppName=${AppName}&appName=${AppName}&ns=${Namespace}`;
          window.open(url, '_blank');
        } else {
          this.openServiceGovernance();
        }
      } else {
        this.openServiceGovernance();
      }
    } else {
      // 服务治理
      const res = await services.getListAnsServiceClusters({
        params: {
          ClusterId,
          ClusterName,
          InstanceId,
          GroupName,
          ServiceName: Name,
          NamespaceId: namespaceId,
          pageSize: 100,
          pageNum: 1,
        },
        customErrorHandle: (err, data, callback) => {
          this.openServiceGovernance();
        },
      });
      if (res && res.AppDetail) {
        const appDetail = res.AppDetail || {};
        const { AppId, AppName } = appDetail;
        const nsAppName = (AppName.indexOf(': ') !== -1) ? AppName.split(': ') : 'default';
        const [ns, appName] = nsAppName;
        const url = `${window.location.origin}/#/msc/appList/info/systemGuardApiDetails?armsAppId=${AppId}&ahasAppName=${appName}&appName=${appName}&ns=${ns}`;
        window.open(url, '_blank');
      } else {
        this.openServiceGovernance();
      }
    }
  };

  openServiceGovernance = () => {
    const aliyunLang = Cookie.get('aliyun_lang') || 'zh';
    Dialog.confirm({
      type: 'warning',
      title: intl('mse.common.tips'),
      content: (
        <div style={{ width: 800, lineHeight: '18px' }}>
          <div>
            {intl.html('mse.nocoscluster.weight.access.document')}
            {intl.html('mse.nocoscluster.weight.other.operate.tips')}
            {intl.html('mse.nocoscluster.weight.other.function.tips')}
          </div>
          <div
            style={{
              width: '100%',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: '8px',
              height: '455px',
            }}
          >
            <img
              src={
                aliyunLang === 'zh'
                  ? 'https://img.alicdn.com/imgextra/i2/O1CN01IyZMmU1ZJjviv9KgM_!!6000000003174-2-tps-1299-900.png'
                  : 'https://img.alicdn.com/imgextra/i2/O1CN01LDGtKp1vjlzXQrCWx_!!6000000006209-2-tps-1304-892.png'
              }
              style={{ width: 750, height: '100%' }}
            />
          </div>
        </div>
      ),
      messageProps: {
        type: 'warning',
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
  };

  renderSpecial = (value, index, record) => {
    const { HealthyInstanceCount, IpCount } = record;
    return (
      <span>
        {HealthyInstanceCount}/{IpCount}
      </span>
    );
  };

  renderFooter = () => {
    return (
      <div style={{ textAligin: 'right' }}>
        <Button
          onClick={() => {
            this.dialog.close();
          }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );
  };

  handleCreate = () => {
    this.setState({
      showIndex: Date.now(),
    });
  };

  hanldeSearch = (value, type) => {
    switch (type) {
      case 'ServiceName':
        this.setState({ serviceName: value });
        break;
      case 'GroupName':
        this.setState({ groupName: value });
        break;
      default:
        break;
    }
  };

  handleSwitch = (checked) => {
    this.setState({ hasIpCount: checked, refreshIndex: Date.now() });
  };

  dialogClose = (val) => {
    this.dialog.close();
    this.setState({
      active: new Date().getTime(),
      renderTag: val,
    });
  };

  render() {
    const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
    const {
      namespaces = [],
      dialogTitle,
      refreshIndex,
      NamingCreateServiceSupported,
      active,
      renderTag,
    } = this.state;
    const columns = [
      {
        key: 'Name',
        title: intl('mse.register.service.name'),
        dataIndex: 'Name',
        width: 300,
        cell: (value, index, record) => (
          <LinkButton onClick={() => this.goServiceDetail(record)}>{value}</LinkButton>
        ),
      },
      {
        key: 'GroupName',
        title: intl('mse.register.service.group'),
        dataIndex: 'GroupName',
        width: 300,
      },
      {
        key: 'HealthyInstanceCount',
        title: (
          <CommonBalloon content={intl('mse.register.service.health_hint')}>
            {intl('mse.register.service.health')}{' '}
            <Icon
              className="commonbuy-tip"
              type="help"
              size="small"
              style={{
                marginLeft: 5,
                color: '#888888',
              }}
            />
          </CommonBalloon>
        ),
        dataIndex: 'HealthyInstanceCount',
        width: 300,
        cell: this.renderSpecial,
      },
      {
        key: 'ClusterCount',
        title: (
          <CommonBalloon content={intl('mse.register.service.app_hint')}>
            {intl('mse.register.service.cluster_count')}
            <Icon
              className="commonbuy-tip"
              type="help"
              size="small"
              style={{
                marginLeft: 5,
                color: '#888888',
              }}
            />
          </CommonBalloon>
        ),
        dataIndex: 'ClusterCount',
        width: 300,
      },
      {
        key: 'opreate',
        title: intl('mse.common.operate'),
        dataIndex: 'opreate',
        width: 300,
        cell: this.renderOption,
      },
    ];
    if (this.state.isGTNACOS_2_1_2_1) {
      columns.splice(2, 0, {
        key: 'Source',
        title: (
          <CommonBalloon content={'1.控制台注册 2.SDK注册 3.服务治理注册'}>
            实例来源
            <Icon
              className="commonbuy-tip"
              type="help"
              size="small"
              style={{
                marginLeft: 5,
                color: '#888888',
              }}
            />
          </CommonBalloon>
        ),
        dataIndex: 'Source',
        width: 300,
        cell: (value, index, record) => {
          const kvMap = {
            console: '控制台注册',
            sdk: 'SDK注册',
            governance: '服务治理注册',
          };
          return kvMap[value];
        }
      });
    }
    const search = {
      isCanRefresh: true,
      isCanMultipleSearch: true,
    };

    return (
      <div className="NacosServiceList-wrap">
        <CommonLoading ref={(node) => (this.loading = node)}>
          <div style={{ width: '100%', position: 'relative' }}>
            <TableContainer
              fetchData={this.fetchData}
              refreshIndex={refreshIndex}
              fixedFooter
              columns={columns}
              search={search}
              operation={() => (
                <React.Fragment>
                  <If condition={this.state.NamingCreateServiceSupported}>
                    <Button type="primary" onClick={this.handleCreate}>
                      {intl('mse.register.service.create')}
                    </Button>
                  </If>
                  <Select.AutoComplete
                    hasClear
                    label={intl('mse.register.service.name')}
                    dataSource={this.state.cacheServices}
                    placeholder={intl('mse.register.service.name_search')}
                    onChange={(value) => this.hanldeSearch(value, 'ServiceName')}
                    style={{ marginLeft: 8, width: 250 }}
                    onPressEnter={() => {
                      this.setState({
                        refreshIndex: Date.now(),
                      });
                    }}
                    onFocus={() => {
                      const _cacheData = JSON.parse(localStorage.getItem('ServiceName') || '[]');
                      this.setState({ cacheServices: _cacheData });
                    }}
                  />
                  <Select.AutoComplete
                    hasClear
                    label={intl('mse.register.service.group')}
                    dataSource={this.state.cacheGroup}
                    placeholder={intl('mse.register.service.group_search')}
                    onChange={(value) => this.hanldeSearch(value, 'GroupName')}
                    style={{ marginLeft: 8, width: 250 }}
                    onPressEnter={() => {
                      this.setState({
                        refreshIndex: Date.now(),
                      });
                    }}
                    onFocus={() => {
                      const _cacheData = JSON.parse(localStorage.getItem('GroupName') || '[]');
                      this.setState({ cacheGroup: _cacheData });
                    }}
                  />
                  <Button
                    type="primary"
                    style={{ marginLeft: 8 }}
                    onClick={() => {
                      this.setState({
                        refreshIndex: Date.now(),
                      });
                    }}
                  >
                    {intl('msc.common.query')}
                  </Button>
                  {/* <span style={{ marginLeft: 12 }}>{intl('mse.register.service.hasip')}</span> */}
                  <Switch
                    onChange={this.handleSwitch}
                    checked={this.state.hasIpCount}
                    style={{ marginLeft: 12, width: 110 }}
                    // checkedChildren={intl('mse.common.hide')}
                    // unCheckedChildren={intl('mse.common.display')}
                    checkedChildren="隐藏空服务"
                    unCheckedChildren="显示空服务"
                  />
                </React.Fragment>
              )}
              emptyContent={<span>{intl('mse.common.no_data')}</span>}
            />
            <div
              style={{
                display: 'inline-block',
                position: 'absolute',
                top: -48,
                right: 0,
                height: 32,
                lineHeight: '32px',
              }}
            >
              {intl('mse.common.document')}：
              <If condition={aliyunSite === 'INTL'}>{intl('mse.register.service.help_tip')}</If>
              <If condition={aliyunSite !== 'INTL'}>
                <a href="https://help.aliyun.com/document_detail/250960.html" target="_blank">
                  {intl('mse.register.service.help_tip')}
                </a>
              </If>
            </div>
          </div>
        </CommonLoading>
        <CommonDialog
          title={dialogTitle}
          style={{ width: 870 }}
          childStyle={{ height: 332, overflowX: 'hidden' }}
          footer={this.renderFooter()}
          ref={(node) => (this.dialog = node)}
          shouldUpdatePosition
        >
          <NacosClusterList
            ref={(node) => (this.nacoscluster = node)}
            namingCreateServiceSupported={NamingCreateServiceSupported}
            dialogClose={this.dialogClose}
          />
        </CommonDialog>
        <NacosClusterAdvancedWeights showIndex={active} renderTag={renderTag} />

        <NacosServiceCreate
          showIndex={this.state.showIndex}
          namespaceId={this.state.namespaceId}
          regionLabel={this.state.regionLabel}
          namespaceLabel={this.state.namespaceLabel}
          refreshNacosData={() => this.setState({ refreshIndex: Date.now() })}
        />
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default NacosServiceList;
