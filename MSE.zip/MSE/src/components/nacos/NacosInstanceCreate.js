import React from 'react';
import { find, first, get, forEach } from 'lodash';
import KeyValue from '../common/KeyValue';
import { Form, Input, Field, Radio, NumberPicker, Select } from '@ali/wind';
import intl from '@ali/wind-intl';

const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const EnabledData = [
  {
    value: true,
    label: intl('mse.common.yes'),
  },
  {
    value: false,
    label: intl('mse.common.no'),
  },
];

class NacosInstanceCreate extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.field = new Field(this);
  }

  validate = () => {
    this.field.validate();
    let validateOk = true;
    const errors = this.field.getErrors();
    Object.keys(errors).forEach((key) => {
      if (errors[key]) {
        validateOk = false;
      }
    });
    return validateOk;
  };

  getValues = () => {
    return this.field.getValues();
  };
  setValues = (values) => {
    this.field.setValues(values);
  };

  handleValidator = (rule, val, callback) => {
    forEach(val, (item) => {
      if (!item.Key || !item.Value) {
        callback(intl('mse.register.case.meta_validate'));
      }
    });
    callback();
  };

  render() {
    const { init } = this.field;
    const { clusterDataSource = [], currentClutser } = this.props;
    return (
      <div>
        <Form {...formItemLayout} field={this.field} labelAlign="left" labelTextAlign="left">
          <FormItem label={intl('mse.register.case.ip')} required>
            <Input
              htmlType="text"
              {...init('Ip', {
                rules: [
                  {
                    required: true,
                    message: intl('mse.register.case.ip_validate'),
                  },
                ],
              })}
            />
          </FormItem>
          <FormItem label={intl('mse.register.case.port')} required>
            <Input
              htmlType="text"
              {...init('Port', {
                rules: [
                  {
                    required: true,
                    message: intl('mse.register.case.port_validate'),
                  },
                ],
              })}
            />
          </FormItem>
          <FormItem label="Cluster Name">
            <Select.AutoComplete
              filterLocal={false}
              dataSource={clusterDataSource}
              {...init('ClusterName', {
                initValue: currentClutser || 'DEFAULT',
              })}
              style={{ width: '100%' }}
            />
          </FormItem>
          <FormItem label={intl('mse.register.case.enabled')}>
            <RadioGroup
              {...init('Enabled', {
                initValue: true,
              })}
              dataSource={EnabledData}
            />
          </FormItem>
          <FormItem label={intl('mse.register.case.weight')}>
            <NumberPicker
              {...init('Weight', {
                initValue: 1,
              })}
              min={0}
              max={10000}
              style={{ width: '100%' }}
            />
          </FormItem>
          {/* <FormItem label="Metadata">
            <KeyValue
              {...init('Metadata', {
                initValue: [],
                rules: [
                  {
                    validator: this.handleValidator,
                  },
                ],
              })}
            />
          </FormItem> */}
        </Form>
      </div>
    );
  }
}

export default NacosInstanceCreate;
