import React, { useState, useEffect, useRef } from 'react';
import {
  Table,
  Button,
  Loading,
  Dialog,
  NumberPicker,
  Tag,
  Message,
  Balloon,
  Input,
  Pagination,
  Icon,
} from '@ali/cn-design';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import CommonDialog from '../../base/CommonDialog';
import NacosInstanceCreate from '../NacosInstanceCreate';
import intl from '@ali/wind-intl';
import services from 'utils/services';

const { Group: TagGroup, Closable: ClosableTag } = Tag;

const ProviderTab = (props) => {
  const { clusterGroups = [], commonParams, isEphemeral, onRefresh, loading, serviceRoot, appDetail } = props;
  const [activeKey, setActiveKey] = useState('');
  const [createLoading, setCreateLoading] = useState(false);
  const [weight, setWeight] = useState(0);
  const [weightLoading, setWeightLoading] = useState(false);
  const [currentRecord, setCurrentRecord] = useState();
  const [tableColumns, setTableColumns] = useState();
  const [clusterDataSource, setClusterDataSource] = useState([]);
  const [filterKey, setFilterKey] = useState('');
  const [filterValue, setFilterValue] = useState('');
  const [filterData, setFilterData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [dataSource, setDataSource] = useState([]);
  const [listLoading, setListLoading] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [limitMsgVisible, setLimitMsgVisible] = useState(false);
  const [refreshIndex, setRefreshIndex] = useState(0);
  const createDialogRef = useRef(null);
  const createFormRef = useRef(null);
  const weightRef = useRef(null);

  const renderActions = (record, key) => {
    const { Enabled, InstanceId } = record;
    return (
      <Actions>
        <LinkButton
          onClick={() => {
            handleOpenWeight(record);
            window.CN_TRACKER.send({
              name: `${InstanceId}-provider-weight`,
              type: 'mse-register-nacos-service-detail',
            });
          }}
        >
          {intl('mse.register.service.provider.weight_edit')}
        </LinkButton>
        <If condition={Enabled}>
          <LinkButton
            onClick={() => handleOffline(record, 'off')}
          >
            {intl('mse.register.cluster.action.offline')}
          </LinkButton>
        </If>
        <If condition={!Enabled}>
          <LinkButton
            onClick={() => {
              handleLineStatus(record, 'on');
              window.CN_TRACKER.send({
                name: `${InstanceId}-provider-online`,
                type: 'mse-register-nacos-service-detail',
              });
            }}
          >
            {intl('mse.register.cluster.action.online')}
          </LinkButton>
        </If>
        <LinkButton
          onClick={() => {
            handleDelete(record);
            window.CN_TRACKER.send({
              name: `${InstanceId}-provider-delete`,
              type: 'mse-register-nacos-service-detail',
            });
          }}
          disabled={serviceRoot === 'governance'}
        >
          <If condition={serviceRoot !== 'governance'}>
            <span>{intl('mse.common.delete')}</span>
          </If>
          <If condition={serviceRoot === 'governance'}>
            <Balloon
              trigger={<span>{intl('mse.common.delete')}</span>}
              closable={false}
            >
              针对该应用关闭MSE微服务治理后，实例信息会被自动删除。
            </Balloon>
          </If>
        </LinkButton>
      </Actions>
    );
  };

  const columns = [
    {
      key: 'Ip:Port',
      title: 'Ip:Port',
      dataIndex: 'Ip:Port',
      cell: (value, index, record) => (
        <span>
          {record.Ip}:{record.Port}
        </span>
      ),
    },
    {
      key: 'ClusterName',
      title: intl('mse.register.cluster.name'),
      dataIndex: 'ClusterName',
    },
    {
      key: 'Healthy',
      title: intl('mse.register.cluster.app.health'),
      dataIndex: 'Healthy',
      align: 'center',
      cell: (value) => (
        <span>
          <If condition={value}>
            <span className="circle-status green" />
          </If>
          <If condition={!value}>
            <span className="circle-status red" />
          </If>
        </span>
      ),
    },
    {
      key: 'Enabled',
      title: intl('mse.register.cluster.app.enabled'),
      dataIndex: 'Enabled',
      align: 'center',
      cell: (value) => (
        <span>
          <If condition={value}>
            <span className="circle-status green" />
          </If>
          <If condition={!value}>
            <span className="circle-status red" />
          </If>
        </span>
      ),
    },
    {
      key: 'Weight',
      title: intl('mse.register.cluster.app.weight'),
      dataIndex: 'Weight',
      align: 'center',
    },
    {
      key: 'Meta',
      title: intl('mse.register.cluster.app.meta'),
      dataIndex: 'Meta',
      align: 'center',
      width: 200,
      cell: (value, index, record) => {
        const { Metadata = {} } = record;
        const metaData = Object.keys(Metadata);
        return (
          <div
            style={{
              minWidth: 150,
              maxWidth: 300,
              minHeight: 50,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <If condition={metaData.length}>
              <TagGroup>
                {metaData.map((key) => {
                  return (
                    <Balloon
                      trigger={
                        <Tag
                          type="normal"
                          size="small"
                          onClick={() => onClickMetadataTag(key, Metadata[key], filterData)}
                          style={{ maxWidth: 300 }}
                        >
                          {key}:{Metadata[key]}
                        </Tag>
                      }
                      closable={false}
                    >
                      <div style={{ fontSize: 14, fontWeight: 500 }}> {key}:</div>
                      <div>{Metadata[key]}</div>
                    </Balloon>
                  );
                })}
              </TagGroup>
            </If>
            <If condition={!metaData.length}>
              <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                {intl('mse.common.empty')}
              </div>
            </If>
          </div>
        );
      },
    },

    {
      key: 'InstanceHeartBeatInterval',
      title: intl('mse.register.cluster.app.interval'),
      dataIndex: 'InstanceHeartBeatInterval',
    },
    {
      key: 'InstanceHeartBeatTimeOut',
      title: intl('mse.register.cluster.app.timeout'),
      dataIndex: 'InstanceHeartBeatTimeOut',
    },
    {
      key: 'Actions',
      title: intl('mse.common.operate'),
      cell: (value, index, record) => renderActions(record, activeKey),
    },
  ];

  const handleOffline = (record) => {
    if (serviceRoot === 'governance') {
      const { AppId, AppName } = appDetail;
      const nsAppName = (AppName.indexOf(': ') !== -1) ? AppName.split(': ') : 'default';
      const [ns, appName] = nsAppName;
      const url = `${window.location.origin}/#/msc/appList/info/nodeDetails?armsAppId=${AppId}&ahasAppName=${appName}&ns=${ns}`;
      window.open(url, '_blank');
    } else {
      handleLineStatus(record, 'off');
      window.CN_TRACKER.send({
        name: `${record.InstanceId}-provider-offline`,
        type: 'mse-register-nacos-service-detail',
      });
    }
  };

  const onChangeClusterGroups = (values) => {
    const { Name, Ephemeral = false } = values;
    setActiveKey(Name);
    if (Name === activeKey) {
      fetchData(Name, true);
    } else {
      setFilterData([]);
    }
  };

  const handleFilterData = (dataSource) => {
    let result = [];
    if (filterData && filterData.length) {
      result = dataSource.filter((item) => {
        const { Metadata } = item;
        const keys = Object.keys(Metadata);
        const flag = filterData.every((filter) => {
          const filterKeys = keys.filter((i) => i.includes(filter.key));
          const res = filterKeys.some((k) => Metadata[k].includes(filter.value));
          return res;
        });
        return flag;
      });
    } else {
      result = dataSource;
    }
    return result;
  };

  const loopData = async (params) => {
    let content = [];
    const { Data = [], TotalCount } = await services.getListAnsInstances({
      params,
    });
    const page = Math.ceil(TotalCount / 500) < 10 ? Math.ceil(TotalCount / 500) : 10;
    content = content.concat(handleFilterData(Data));
    if (page > 1) {
      for (let i = 2; i <= page; i++) {
        const _params = { ...params, pageNum: i };
        // eslint-disable-next-line no-await-in-loop
        const { Data = [] } = await services.getListAnsInstances({
          params: _params,
        });
        content = content.concat(handleFilterData(Data));
      }
    }
    if (Math.ceil(TotalCount / 500) >= 11) {
      Message.show({
        type: 'warning',
        content: intl('mse.register.service.provider.limit_warning'),
        duration: 3000,
        align: 'cc cc',
        hasMask: true,
        offset: [0, -50],
      });
      setLimitMsgVisible(true);
      window.CN_TRACKER.send({
        name: 'max-limit',
        type: 'mse-register-nacos-service-list',
      });
    } else {
      setLimitMsgVisible(false);
    }
    return content;
  };

  const fetchData = async (key = activeKey, isLoop = false) => {
    setListLoading(true);
    const { GroupName, NamespaceId, ServiceName, InstanceId } = commonParams;
    const _params = {
      GroupName,
      NamespaceId,
      ServiceName,
      InstanceId,
      pageNum: currentPage,
      pageSize,
      ClusterName: key,
    };
    if (!isLoop) {
      const { Data = [], TotalCount = 0 } = await services.getListAnsInstances({
        params: _params,
      });
      const res = handleFilterData(Data);
      setDataSource(res);
      setTotalCount(TotalCount);
      setListLoading(false);
      setLimitMsgVisible(false);
    } else {
      const params = { ..._params, pageNum: 1, pageSize: 500 };
      const res = await loopData(params);
      setDataSource(res);
      setListLoading(false);
    }
  };

  const renderCreateInstanceFooter = () => {
    return (
      <div style={{ textAligin: 'right' }}>
        <Button
          type="primary"
          style={{ marginRight: 10 }}
          onClick={handleCreateInstance}
          loading={createLoading}
        >
          {intl('mse.common.ok')}
        </Button>
        <Button
          onClick={() => {
            createDialogRef.current.close();
          }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );
  };

  const renderWeightFooter = () => {
    return (
      <div style={{ textAligin: 'right' }}>
        <Button
          type="primary"
          style={{ marginRight: 10 }}
          onClick={handleEditWeight}
          loading={weightLoading}
        >
          {intl('mse.common.ok')}
        </Button>
        <Button
          onClick={() => {
            weightRef.current.close();
          }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );
  };

  const handleCreateInstance = async () => {
    if (createFormRef.current.validate()) {
      const values = createFormRef.current.getValues();
      const { GroupName, NamespaceId, ServiceName, InstanceId } = commonParams;
      const params = {
        ...values,
        InstanceId,
        NamespaceId,
        ServiceName,
        GroupName,
        Ephemeral: isEphemeral,
      };
      setCreateLoading(true);
      await services.createNacosInstance({
        customErrorHandle: (err, data, callback) => {
          setCreateLoading(false);
          callback();
        },
        params: { ...params },
      });
      Message.success(intl('mse.common.create_success'));
      setCreateLoading(false);
      createDialogRef.current.close();
      onRefresh();
      // fetchData();
      setRefreshIndex(Date.now());
    }
  };

  const handleEditWeight = async () => {
    const { GroupName, NamespaceId, ServiceName, InstanceId } = commonParams;
    const { Ip, Port, Ephemeral, Enabled, Metadata } = currentRecord;
    setWeightLoading(true);
    const params = {
      ClusterName: activeKey,
      GroupName,
      NamespaceId,
      ServiceName,
      InstanceId,
      Ip,
      Port,
      Ephemeral,
      Metadata,
      Enabled,
      Weight: weight,
    };
    await services.updateNacosInstance({
      params,
      customErrorHandle: (err, data, callback) => {
        weightRef.current.close();
        setWeightLoading(false);
        callback();
      },
    });
    weightRef.current.close();
    setWeightLoading(false);
    // fetchData();
    setRefreshIndex(Date.now());
  };

  const handleLineStatus = (record, type) => {
    Dialog.confirm({
      title:
        type === 'on'
          ? intl('mse.register.service.provider.online_title')
          : intl('mse.register.service.provider.offline_title'),
      content:
        type === 'on'
          ? intl('mse.register.service.provider.online_tip')
          : intl('mse.register.service.provider.offline_tip'),
      onOk: async () => {
        const { GroupName, NamespaceId, ServiceName, InstanceId } = commonParams;
        const { Ip, Port, Ephemeral, Weight, Enabled, Metadata } = record;
        const params = {
          ClusterName: activeKey,
          GroupName,
          NamespaceId,
          ServiceName,
          InstanceId,
          Ip,
          Port,
          Ephemeral,
          Weight,
          Metadata,
          Enabled: type === 'on',
        };
        await services.updateNacosInstance({
          params,
          customErrorHandle: (err, data, callback) => {
            callback();
          },
        });
        // fetchData();
        setRefreshIndex(Date.now());
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
  };

  const handleDelete = (record) => {
    Dialog.confirm({
      title: intl('mse.register.service.provider.delete_title'),
      content: intl('mse.register.service.provider.delete_tip'),
      onOk: async () => {
        const { GroupName, NamespaceId, ServiceName, InstanceId } = commonParams;
        const { Ip, Port, Ephemeral } = record;
        const params = {
          ClusterName: activeKey,
          GroupName,
          NamespaceId,
          ServiceName,
          InstanceId,
          Ip,
          Port,
          Ephemeral,
        };
        await services.deleteNacosInstance({
          params,
          customErrorHandle: (err, data, callback) => {
            callback();
          },
        });
        setRefreshIndex(Date.now());
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
  };

  const handleOpenWeight = (record) => {
    weightRef.current.open();
    setWeight(record.Weight);
    setCurrentRecord(record);
  };

  const changeWeight = (value) => {
    setWeight(value);
  };

  const onClickMetadataTag = (key, value, filter) => {
    let result = [...filterData];
    const ishas = result.some((r) => r.key === key && r.value === value);
    if (!ishas) {
      result.push({ key, value });
    }
    setFilterData(result);
  };

  const handleFilter = () => {
    if (filterData && filterData.length) {
      if ((filterKey && !filterValue) || (!filterKey && filterValue)) {
        Message.warning(intl('mse.register.service.provider.filter_warning'));
        return;
      } else if (!filterKey && !filterValue) {
        setRefreshIndex(Date.now());
        return;
      }
    } else if (!filterKey || !filterValue) {
      Message.warning(intl('mse.register.service.provider.filter_warning'));
      return;
    }
    let result = [...filterData];
    const ishas = result.some((r) => r.key === filterKey && r.value === filterValue);
    if (!ishas) {
      result.push({ key: filterKey, value: filterValue });
    }
    setFilterData(result);
  };

  const handleClear = () => {
    setFilterData([]);
  };

  const handleClose = (key) => {
    const result = filterData.filter((i) => i.key !== key);
    setFilterData(result);
  };

  const onPageChange = (val) => {
    setCurrentPage(val);
  };

  const onPageSizeChange = (val) => {
    setCurrentPage(1);
    setPageSize(val);
  };

  useEffect(() => {
    filterData.length ? fetchData(activeKey, true) : fetchData();
    setFilterKey('');
    setFilterValue('');
  }, [currentPage, pageSize, activeKey, filterData, refreshIndex]);

  useEffect(() => {
    if (clusterGroups && clusterGroups.length) {
      if (activeKey) {
        filterData.length ? fetchData(activeKey, true) : fetchData(activeKey);
      } else {
        setActiveKey(clusterGroups[0].Name);
      }
      const result = clusterGroups.map((item) => {
        return { lable: item.Name, value: item.Name };
      });
      setClusterDataSource(result);
    }
  }, [clusterGroups]);

  useEffect(() => {
    if (isEphemeral) {
      setTableColumns(columns);
    } else {
      const _columns = columns.filter(
        (c) =>
          c.dataIndex !== 'InstanceHeartBeatInterval' && c.dataIndex !== 'InstanceHeartBeatTimeOut'
      );
      setTableColumns(_columns);
    }
  }, [isEphemeral, activeKey, filterData]);

  return (
    <div
      style={{
        marginTop: 12,
        border: '1px solid #D1D5D9',
        borderRadius: '0 4px 4px 0',
        display: 'flex',
        justifyContent: 'flex-start',
        minHeight: 360,
      }}
    >
      <div style={{ width: 180, borderRight: '1px solid #ddd', marginRight: 12 }}>
        <h4 style={{ marginLeft: 12 }}>{intl('mse.register.service.cluster_total')}</h4>
        <div>
          <Loading visible={loading} style={{ width: '100%', height: 400, overflowY: 'scroll' }}>
            <If condition={clusterGroups.length}>
              {clusterGroups.map((item) => {
                return (
                  <div
                    style={{
                      height: 30,
                      width: '100%',
                      padding: '0 0 0 16px',
                      backgroundColor: activeKey === item.Name ? '#FAFAFA' : '#fff',
                      color: activeKey === item.Name ? '#0064C8' : '#303030',
                      display: 'flex',
                      alignItems: 'center',
                      cursor: 'pointer',
                    }}
                    onClick={() => onChangeClusterGroups(item)}
                  >
                    {item.Name}
                  </div>
                );
              })}
            </If>
            <If condition={!loading && !clusterGroups.length}>
              <div style={{ minHeight: 200, width: '100%', textAlign: 'center' }}>
                {intl('mse.register.service.provider.no_data')}
              </div>
            </If>
          </Loading>
        </div>
      </div>
      <div style={{ width: 'calc(100% - 180px)', padding: '12px 0' }}>
        <React.Fragment>
          <div>
            <If condition={serviceRoot !== 'governance'}>
              <Button
                type="primary"
                onClick={() => {
                  createDialogRef.current.open();
                  window.CN_TRACKER.send({
                    name: 'provider-create',
                    type: 'mse-register-nacos-service-detail',
                  });
                }}
              >
                {intl('mse.register.create')}
              </Button>
            </If>
            <If condition={serviceRoot === 'governance'}>
              <Balloon
                trigger={
                  <Button
                    type="primary"
                    disabled
                  >
                    {intl('mse.register.create')}
                  </Button>
                }
                closable={false}
              >
                通过服务治理注册的应用，将自动获取实例信息，不需要手工创建。
              </Balloon>
            </If>
            <span style={{ margin: '0 8px', fontSize: 14 }}>
              {intl('mse.register.metadata.filter')}
            </span>
            <Input
              placeholder="key"
              style={{ marginRight: 8 }}
              value={filterKey}
              onChange={(val) => setFilterKey(val)}
            />
            <Input
              placeholder="value"
              value={filterValue}
              onChange={(val) => setFilterValue(val)}
              onPressEnter={handleFilter}
            />
            <Button type="primary" style={{ margin: '0 8px' }} onClick={handleFilter}>
              {/* {intl('mse.register.service.filter')} */}
              {filterData.length
                ? intl('mse.register.service.provider.filter')
                : intl('mse.register.service.provider.add_filter')}
              <If condition={!!filterData.length && listLoading}>
                <Icon type="loading" style={{ marginLeft: 4 }} />
              </If>
            </Button>
            <If condition={filterData && filterData.length}>
              <Button type="primary" onClick={handleClear}>
                {intl('mse.common.clear')}
              </Button>
            </If>
          </div>
          <div style={{ marginTop: 8 }}>
            <TagGroup>
              {filterData.map((item) => {
                return (
                  <Balloon
                    trigger={
                      <ClosableTag
                        type="normal"
                        key={item.key}
                        afterClose={() => handleClose(item.key)}
                        style={{ maxWidth: 200 }}
                      >
                        {item.key}:{item.value}
                      </ClosableTag>
                    }
                    closable={false}
                  >
                    <div style={{ fontSize: 14, fontWeight: 500 }}> {item.key}:</div>
                    <div>{item.value}</div>
                  </Balloon>
                );
              })}
            </TagGroup>
          </div>
        </React.Fragment>
        <Table
          columns={tableColumns}
          hasBorder={false}
          dataSource={dataSource}
          loading={listLoading}
          emptyContent={
            <div>
              <If condition={filterData.length}>
                {intl('mse.register.service.provider.no_metadata')}
              </If>
              <If condition={!filterData.length}>
                {intl('mse.register.service.provider.no_data')}
              </If>
            </div>
          }
        />
        <If condition={limitMsgVisible}>
          <div
            style={{ display: 'flex', justifyContent: 'center', color: '#FF0000', marginTop: 12 }}
          >
            {intl('mse.register.service.provider.limit_warning')}
          </div>
        </If>
        <If condition={!filterData.length}>
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Pagination
              style={{ marginTop: 12 }}
              total={totalCount}
              totalRender={(total) => (
                <sapn style={{ fontSize: 12, color: '#888', margin: '0 4px' }}>{intl('mse.register.trace.total_tip', { total })}</sapn>
              )}
              current={currentPage}
              onChange={onPageChange}
              pageSizeSelector="dropdown"
              pageSizeList={[10, 20, 50]}
              pageSize={pageSize}
              onPageSizeChange={onPageSizeChange}
            />
          </div>
        </If>
      </div>
      <CommonDialog
        title={intl('mse.register.cluster.create')}
        style={{ width: 870 }}
        childStyle={{ height: 250, overflowX: 'hidden' }}
        footer={renderCreateInstanceFooter()}
        ref={createDialogRef}
        shouldUpdatePosition
      >
        <NacosInstanceCreate
          ref={createFormRef}
          clusterDataSource={clusterDataSource}
          currentClutser={activeKey}
        />
      </CommonDialog>
      <CommonDialog
        title={intl('mse.register.service.provider.weight_edit')}
        style={{ width: 480 }}
        childStyle={{ height: 100, overflowX: 'hidden' }}
        footer={renderWeightFooter()}
        ref={weightRef}
        shouldUpdatePosition
      >
        <div>
          <span style={{ fontSize: 12, marginRight: 24 }}>
            {intl('mse.register.cluster.app.weight')}
          </span>
          <NumberPicker value={weight} onChange={changeWeight} min={0} max={10000} type="inline" />
          <p style={{ fontSize: 12, marginLeft: 44, marginTop: 8, color: '#666' }}>
            {intl('mse.register.cluster.weight_hint')}
          </p>
        </div>
      </CommonDialog>
    </div>
  );
};

export default ProviderTab;
