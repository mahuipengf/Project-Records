import React, { useState, forwardRef, useImperativeHandle } from 'react';
import ServiceTrace from '../../../pages/config/Trace/index';

const TraceTab = forwardRef((props, ref) => {
  {
    const { commonParams } = props;
    const { ServiceName, GroupName, NamespaceId } = commonParams;
    const [refreshIndex, setRefreshIndex] = useState(0);
    const ServiceDetailParams = {
      type: 'config',
      serviceName: ServiceName,
      groupName: GroupName,
      namespaceId: NamespaceId,
    };
    useImperativeHandle(ref, () => ({
      onRefresh: handleRefreshTrace,
    }));

    const handleRefreshTrace = () => {
      setRefreshIndex(Date.now());
    };
    return (
      <div style={{ marginTop: 12 }}>
        <ServiceTrace serviceDetailParams={ServiceDetailParams} refreshIndex={refreshIndex} />
      </div>
    );
  }
});
export default TraceTab;
