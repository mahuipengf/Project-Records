import React from 'react';
import intl from '@ali/wind-intl';
import ServiceTrace from '../../../pages/config/Trace/index';

const NacosInstanceDetailTrack = (props) => {
  const commonParams = {
    ClusterId: getParams('ClusterId'),
    ClusterName: getParams('ClusterName'),
    InstanceId: getParams('InstanceId'),
    NamespaceId: getParams('NamespaceId'),
    GroupName: getParams('GroupName'),
    ServiceName: getParams('ServiceName'),
    Ip: getParams('Ip') || '',
  };
  const ServiceDetailParams = {
    type: 'ip',
    ip: commonParams.Ip,
  };

  return (
    <div style={{ padding: 20 }} className="mse-nacos-service-detail">
      <h1 style={{ fontSize: 24 }}>{commonParams.Ip}</h1>
      <h2 style={{ fontSize: 14 }}>{intl('mse.register.service.trace')}</h2>
      <ServiceTrace serviceDetailParams={ServiceDetailParams} />
    </div>
  );
};

export default NacosInstanceDetailTrack;
