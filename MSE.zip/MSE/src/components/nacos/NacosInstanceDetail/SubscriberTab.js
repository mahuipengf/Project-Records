import React, { useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import { Table, TableContainer } from '@ali/cn-design';
import { getCurrentRegion } from 'utils';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import { get } from 'lodash';
import intl from '@ali/wind-intl';
import services from 'utils/services';

const SubscriberTab = forwardRef((props, ref) => {
  const { commonParams } = props;
  const [dataSource, setDataSource] = useState([]);
  const [loading, setLoading] = useState(false);

  const columns = [
    {
      key: 'IP',
      title: intl('mse.register.service.subscriber'),
      dataIndex: 'IP',
    },
    {
      key: 'Agent',
      title: intl('mse.register.service.subscriber.agent'),
      dataIndex: 'Agent',
    },
    {
      title: intl('mse.common.operate'),
      dataIndex: 'Actions',
      cell: (value, index, record) => (
        <Actions>
          <LinkButton onClick={() => goDetailTrack(record)}>
            {intl('mse.register.service.trace')}
          </LinkButton>
        </Actions>
      ),
    },
  ];

  useImperativeHandle(ref, () => ({
    fetchData,
  }));

  const goDetailTrack = (record) => {
    const { ip } = record;
    const search = get(hashHistory, 'location.search', '');
    const url = `/#/Instance/Service/Subscriber/Trace${search}&Ip=${ip}`;
    window.open(url, '_blank');
  };

  const fetchData = async () => {
    const { InstanceId, ServiceName, GroupName, NamespaceId } = commonParams;
    let params = {
      InstanceId,
      ServiceName,
      GroupName,
      RegionId: getCurrentRegion(),
      PageNum: 1,
      PageSize: 1000,
      NamespaceId,
    };
    if (NamespaceId !== 'public') {
      params = {
        ...params,
        NamespaceId
      };
    }
    setLoading(true);
    const result = await services.getServiceListeners({ params });
    setDataSource(result);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div style={{ marginTop: 12 }}>
      <Table columns={columns} hasBorder={false} dataSource={dataSource} loading={loading} />
    </div>
  );
});

export default SubscriberTab;
