import React, { useState, useEffect, useRef } from 'react';
import { get } from 'lodash';
import { Tab, Grid, Loading, Button, Icon, Divider } from '@ali/cn-design';
import services from 'utils/services';
import ClusterGroupTab from './ClusterGroupTab';
import ProviderTab from './ProviderTab';
import SubscriberTab from './SubscriberTab';
import TraceTab from './TraceTab';
import intl from '@ali/wind-intl';
import { compareNacosVersion } from '../../../utils/utils';

const { Row, Col } = Grid;
const commonStyle = {
  labelStyle: {
    color: '#111111',
  },
  contentStyle: {
    color: '#555555',
  },
  rowStyle: {
    lineHeight: '20px',
    fontSize: '12px',
    marginBottom: 8,
  },
};

const NacosInstanceDetail = () => {
  const tabKey = get(hashHistory, 'location.state.tabKey', '');
  const [page, setPage] = useState({
    pageSize: 1000,
    pageNum: 1,
  });
  const [basicInfo, setBasicInfo] = useState();
  const [appDetail, setAppDetail] = useState();
  const [loading, setLoading] = useState(false);
  const [moduleLoading, setModuleLoading] = useState(false);
  const [activeKey, setActiveKey] = useState(tabKey ?? '');
  const [clusterGroups, setClusterGroups] = useState([]);
  const [isEphemeral, setIsEphemeral] = useState(true);
  const subscriberRef = useRef(null);
  const traceRef = useRef(null);
  const commonParams = {
    ClusterId: getParams('ClusterId'),
    ClusterName: getParams('ClusterName'),
    InstanceId: getParams('InstanceId'),
    NamespaceId: getParams('NamespaceId'),
    GroupName: getParams('GroupName'),
    ServiceName: getParams('ServiceName'),
  };
  const [isGTNACOS_2_1_2_1, setIsGTNACOS_2_1_2_1] = useState(false);

  // isRefreshBasic 是否基础信息有loading
  const getBasicInfo = async (isRefreshBasic = false) => {
    setModuleLoading(true);
    isRefreshBasic && setLoading(true);
    setClusterGroups([]);
    const _params = {
      ...commonParams,
      ...page,
    };
    const { Clusters = [], Ephemeral, GroupName, Name, Source = '', ProtectThreshold = 0, AppDetail = {} } = await services.getListAnsServiceClusters({
      params: _params,
    });
    const basicData = {
      serviceName: Name,
      groupName: GroupName,
      region: '',
      namespace: commonParams.NamespaceId,
      ephemeral: Ephemeral,
      instanceTotal: Clusters.length,
      // 实例来源
      Source,
      // 保护阈值
      ProtectThreshold,
    };
    setBasicInfo(basicData);
    setAppDetail(AppDetail);
    setClusterGroups(Clusters);
    setIsEphemeral(Ephemeral);
    isRefreshBasic && setLoading(false);
    setModuleLoading(false);
  };

  const onChangeTab = (key) => {
    setActiveKey(key);
  };

  const renderEphemeral = () => {
    if (loading) {
      return <span>-</span>;
    } else {
      return get(basicInfo, 'ephemeral', '-') ? intl('mse.common.no') : intl('mse.common.yes');
    }
  };

  const renderInstanceRoot = () => {
    const kvMap = {
      console: '控制台注册',
      sdk: 'SDK注册',
      governance: '服务治理注册',
    };
    if (loading) {
      return <span>-</span>;
    } else {
      const v = get(basicInfo, 'Source', '');
      return v ? kvMap[v] : '-';
    }
  };

  const renderCheckType = () => {
    const kvMap = {
      http: 'HTTP',
      tcp: 'TCP',
      connection: '链接存活检查',
    };
    if (loading) {
      return <span>-</span>;
    } else {
      const v = get(appDetail, 'CheckType', '');
      return v ? kvMap[v] : '-';
    }
  };

  const onRefreshTabContent = (tabKey) => {
    if (tabKey !== activeKey) {
      return;
    }
    window.CN_TRACKER.send({
      name: `${tabKey}-tab`,
      type: 'mse-register-nacos-service-detail',
    });
    switch (tabKey) {
      case 'cluster':
        getBasicInfo(false);
        break;
      case 'provider':
        getBasicInfo(false);
        break;
      case 'subscriber':
        subscriberRef.current.fetchData();
        break;
      case 'trace':
        traceRef.current.onRefresh();
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    if (!tabKey) {
      // isEphemeral ? setActiveKey('provider') : setActiveKey('cluster');
      setActiveKey('provider');
    }
  }, [isEphemeral]);

  useEffect(() => {
    getBasicInfo(true);
    const _isGTNACOS_2_1_2_1 = compareNacosVersion();
    setIsGTNACOS_2_1_2_1(_isGTNACOS_2_1_2_1);
  }, []);

  return (
    <div className="mse-nacos-service-detail">
      <div style={{ marginBottom: 16 }}>
        <Loading visible={loading} style={{ width: '100%' }}>
          <div
            style={{
              border: '1px solid rgb(220, 223, 230)',
              background: 'rgb(249, 249, 249)',
              padding: '16px 24px',
            }}
          >
            <Row style={commonStyle.rowStyle}>
              <Col span={3} style={commonStyle.labelStyle}>
                {intl('mse.register.service.name')}
              </Col>
              <Col span={9} style={commonStyle.contentStyle}>
                {get(basicInfo, 'serviceName', '-')}
              </Col>
              <Col span={3} style={commonStyle.labelStyle}>
                {intl('mse.register.service.groups')}
              </Col>
              <Col span={9} style={commonStyle.contentStyle}>
                {get(basicInfo, 'groupName', '-')}
              </Col>
            </Row>
            <Row style={commonStyle.rowStyle}>
              <Col span={3} style={commonStyle.labelStyle}>
                {intl('mse.register.namespace.region')}
              </Col>
              <Col span={9} style={commonStyle.contentStyle}>
                {window.REGION_NAME_MAP[window.regionId] || '-'}
              </Col>
              <Col span={3} style={commonStyle.labelStyle}>
                {intl('mse.register.nacos.namespace')}
              </Col>
              <Col span={9} style={commonStyle.contentStyle}>
                {get(basicInfo, 'namespace', '-')}
              </Col>
            </Row>
            <If condition={!isGTNACOS_2_1_2_1}>
              <Row style={commonStyle.rowStyle}>
                <Col span={3} style={commonStyle.labelStyle}>
                  {intl('mse.register.service.ephemeral')}
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {renderEphemeral()}
                </Col>
                <Col span={3} style={commonStyle.labelStyle}>
                  {intl('mse.register.service.cluster_count')}
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {get(basicInfo, 'instanceTotal', '-')}
                </Col>
              </Row>
            </If>
            <If condition={isGTNACOS_2_1_2_1}>
              <Row style={commonStyle.rowStyle}>
                <Col span={3} style={commonStyle.labelStyle}>
                  实例来源
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {renderInstanceRoot()}
                </Col>
                <Col span={3} style={commonStyle.labelStyle}>
                  保护阈值
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {get(basicInfo, 'ProtectThreshold', '-')}
                </Col>
              </Row>
            </If>
            <If condition={isGTNACOS_2_1_2_1 && get(basicInfo, 'Source', '') === 'governance'}>
              <Row style={commonStyle.rowStyle}>
                <Col span={3} style={commonStyle.labelStyle}>
                  应用名称
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {get(appDetail, 'AppName', '-')}
                </Col>
                <Col span={3} style={commonStyle.labelStyle}>
                  端口
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {get(appDetail, 'Port', '-')}
                </Col>
              </Row>
              <Row style={commonStyle.rowStyle}>
                <Col span={3} style={commonStyle.labelStyle}>
                  健康检查协议
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {renderCheckType() || '-'}
                </Col>
                <Col span={3} style={commonStyle.labelStyle}>
                  健康检查路径
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {get(appDetail, 'CheckPath', '-')}
                </Col>
              </Row>
              <If condition={get(appDetail, 'CheckType', '') === 'tcp' || get(appDetail, 'CheckType', '') === 'http'}>
                <Row style={commonStyle.rowStyle}>
                  <Col span={3} style={commonStyle.labelStyle}>
                    健康检查响应超时时间
                  </Col>
                  <Col span={9} style={commonStyle.contentStyle}>
                    {get(appDetail, 'CheckTimeout', '-')}
                  </Col>
                  <Col span={3} style={commonStyle.labelStyle}>
                    健康检查响应间隔时间
                  </Col>
                  <Col span={9} style={commonStyle.contentStyle}>
                    {get(appDetail, 'CheckInternal', '-')}
                  </Col>
                </Row>
                <Row style={commonStyle.rowStyle}>
                  <Col span={3} style={commonStyle.labelStyle}>
                    健康检查健康阈值
                  </Col>
                  <Col span={9} style={commonStyle.contentStyle}>
                    {get(appDetail, 'HealthyCheckTimes', '-')}
                  </Col>
                  <Col span={3} style={commonStyle.labelStyle}>
                    健康检查不健康阈值
                  </Col>
                  <Col span={9} style={commonStyle.contentStyle}>
                    {get(appDetail, 'UnhealthyCheckTimes', '-')}
                  </Col>
                </Row>
              </If>
            </If>
          </div>
        </Loading>
      </div>
      <Loading visible={loading} style={{ width: '100%' }}>
        <Tab shape="wrapped" onChange={onChangeTab} activeKey={activeKey}>
          <Tab.Item
            title={intl('mse.register.service.provider')}
            key="provider"
            onClick={() => onRefreshTabContent('provider')}
          >
            <ProviderTab
              clusterGroups={clusterGroups}
              commonParams={commonParams}
              isEphemeral={isEphemeral}
              onRefresh={() => getBasicInfo(false)}
              loading={moduleLoading}
              serviceRoot={get(basicInfo, 'Source', '')}
              appDetail={appDetail}
            />
          </Tab.Item>
          <Tab.Item
            title={intl('mse.register.service.subscriber')}
            key="subscriber"
            onClick={() => onRefreshTabContent('subscriber')}
          >
            <SubscriberTab ref={subscriberRef} commonParams={commonParams} />
          </Tab.Item>
          <Tab.Item
            title={intl('mse.register.service.trace')}
            key="trace"
            onClick={() => onRefreshTabContent('trace')}
          >
            <TraceTab ref={traceRef} commonParams={commonParams} />
          </Tab.Item>
        </Tab>
      </Loading>
    </div>
  );
};

export default NacosInstanceDetail;
