import React, { useState, useEffect, useRef } from 'react';
import { Table, Button, Icon, Message } from '@ali/cn-design';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import CommonDialog from '../../base/CommonDialog';
import NacosClusterCreate from '../NacosClusterCreate';
import intl from '@ali/wind-intl';
import services from 'utils/services';

const ClusterGroupTab = (props) => {
  const { clusterGroups = [], onRefresh, commonParams, loading } = props;
  const [clusterName, setClusterName] = useState('');
  const [clusterMeta, setClusterMeta] = useState({});
  const [btnLoading, setBtnLoading] = useState(false);

  const clusterDialogRef = useRef(null);
  const clusterFormRef = useRef(null);

  const columns = [
    {
      key: 'Name',
      title: intl('mse.register.cluster.name'),
      dataIndex: 'Name',
    },
    {
      key: 'HealthCheckerType',
      title: intl('mse.register.cluster.health'),
      dataIndex: 'HealthCheckerType',
      align: 'center',
    },
    {
      key: 'DefaultCheckPort',
      title: intl('mse.register.cluster.health_port'),
      dataIndex: 'DefaultCheckPort',
      align: 'center',
    },
    {
      key: 'UseIPPort4Check',
      title: intl('mse.register.cluster.health_case'),
      dataIndex: 'UseIPPort4Check',
      align: 'center',
      cell: (value) => (value ? intl('mse.common.yes') : intl('mse.common.no')),
    },
    {
      key: 'Action',
      title: intl('mse.common.operate'),
      dataIndex: 'Action',
      cell: (value, index, record) => {
        const { ClusterName = '' } = record;
        return (
          <Actions>
            <LinkButton
              onClick={() => {
                openClusterDialog(record);
                window.CN_TRACKER.send({
                  name: `${ClusterName}-cluster-edit`,
                  type: 'mse-register-nacos-service-detail',
                });
              }}
            >
              {intl('mse.common.edit')}
            </LinkButton>
          </Actions>
        );
      },
    },
  ];

  const openClusterDialog = (record) => {
    const { Name, DefaultCheckPort, UseIPPort4Check, HealthCheckerType } = record;
    const _HealthCheckerType = HealthCheckerType.toLowerCase();
    let _HealthChecker = JSON.stringify({ type: 'NONE' });
    if (_HealthCheckerType === 'tcp') {
      _HealthChecker = JSON.stringify({ type: 'TCP' });
    }
    clusterDialogRef.current.open();
    setClusterName(Name);
    setClusterMeta({
      ClusterName: Name,
      CheckPort: DefaultCheckPort,
      UseInstancePortForCheck: UseIPPort4Check,
      HealthChecker: _HealthChecker,
    });
  };

  const handleSubmitCluster = async () => {
    if (clusterFormRef.current.validate()) {
      const values = clusterFormRef.current.getValues();
      const { GroupName, NamespaceId, ServiceName, InstanceId } = commonParams;
      const params = { ...values, InstanceId, NamespaceId, ServiceName, GroupName };
      setBtnLoading(true);
      await services.updateNacosCluster({
        customErrorHandle: (err, data, callback) => {
          setBtnLoading(false);
          callback();
        },
        params: { ...params },
      });
      Message.success(intl('mse.common.update_success'));
      setBtnLoading(false);
      clusterDialogRef.current.close();
      onRefresh();
    }
  };

  const renderFooter = () => {
    return (
      <div style={{ textAligin: 'right' }}>
        <Button
          type="primary"
          style={{ marginRight: 10 }}
          onClick={handleSubmitCluster}
          loading={btnLoading}
        >
          {intl('mse.common.ok')}
        </Button>
        <Button
          onClick={() => {
            clusterDialogRef.current.close();
          }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );
  };

  return (
    <div style={{ marginTop: 12 }}>
      <Table columns={columns} dataSource={clusterGroups} hasBorder={false} loading={loading} />
      <CommonDialog
        title={intl.html('mse.register.cluster.health_check', { name: clusterName })}
        style={{ width: 870 }}
        childStyle={{ height: 220, overflowX: 'hidden' }}
        footer={renderFooter()}
        ref={clusterDialogRef}
        shouldUpdatePosition
      >
        <NacosClusterCreate ref={clusterFormRef} clusterMeta={clusterMeta} />
      </CommonDialog>
    </div>
  );
};

export default ClusterGroupTab;
