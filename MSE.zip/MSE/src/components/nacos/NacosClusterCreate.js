import React from 'react';
import { find, first, get, forEach } from 'lodash';
import { Form, Input, Field, Radio, BalloonIcon } from '@ali/cn-design';
import intl from '@ali/wind-intl';

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
};
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const FormItemLabel = (text = '', popCtx = '') => (
  <span>
    <span style={{ fontSize: '13px', color: '#333' }}>{text}</span>
    <BalloonIcon
      icon="help"
      align="r"
      style={{
        color: popCtx ? '#808080' : 'transparent',
        fontSize: '12px',
        marginLeft: '5px',
      }}
      text={popCtx}
    />
  </span>
);
const HealthCheckerData = [
  {
    value: JSON.stringify({ type: 'NONE' }),
    label: intl('mse.register.cluster.health_none'),
  },
  {
    value: JSON.stringify({ type: 'TCP' }),
    label: intl('mse.register.cluster.health_tcp'),
  },
];

const InstanceCheckerData = [
  {
    value: true,
    label: intl('mse.common.yes'),
  },
  {
    value: false,
    label: intl('mse.common.no'),
  },
];

class NacosClusterCreate extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.field = new Field(this);
  }

  componentDidMount() {
    const { clusterMeta } = this.props;
    this.field.setValues(clusterMeta);
  }

  validate = () => {
    this.field.validate();
    let validateOk = true;
    const errors = this.field.getErrors();
    Object.keys(errors).forEach((key) => {
      if (errors[key]) {
        validateOk = false;
      }
    });
    return validateOk;
  };

  getValues = () => {
    return this.field.getValues();
  };
  setValues = (values) => {
    this.field.setValues(values);
  };

  render() {
    const { init } = this.field;
    return (
      <div>
        <Form {...formItemLayout} field={this.field} labelAlign="left" labelTextAlign="left">
          <FormItem label={intl('mse.register.cluster.name')} required>
            <Input
              htmlType="text"
              disabled
              {...init('ClusterName', {
                rules: [
                  {
                    required: true,
                    message: intl('mse.register.cluster.name_validate'),
                  },
                ],
              })}
            />
          </FormItem>
          <FormItem label={FormItemLabel(intl('mse.register.cluster.health_port'), intl('mse.register.cluster.port_hint'))} required>
            <Input
              htmlType="text"
              {...init('CheckPort', {
                initValue: '80',
                rules: [
                  {
                    required: true,
                    message: intl('mse.register.cluster.port_validate'),
                  },
                ],
              })}
            />
          </FormItem>
          <FormItem label={FormItemLabel(intl('mse.register.cluster.health_case'), intl('mse.register.cluster.case_hint'))}>
            <RadioGroup
              {...init('UseInstancePortForCheck', {
                initValue: false,
              })}
              dataSource={InstanceCheckerData}
            />
          </FormItem>
          <FormItem label={intl('mse.register.cluster.health')}>
            <RadioGroup
              {...init('HealthChecker', {
                initValue: JSON.stringify({ type: 'NONE' }),
              })}
              dataSource={HealthCheckerData}
            />
          </FormItem>
        </Form>
      </div>
    );
  }
}

export default NacosClusterCreate;
