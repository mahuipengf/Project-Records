import React from 'react';
import { find, first, get } from 'lodash';
import { Form, Field } from '@ali/wind';
import intl from '@ali/wind-intl';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 命名空间详情
 */
const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};
const FormItem = Form.Item;
const regions = get(window, 'ALIYUN_CONSOLE_CONFIG.STATIC_API.regions', []);
class NameSpaceInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.AppVersion = getParams('AppVersion');
    this.field = new Field(this);
  }

  getValues = () => {
    return this.field.getValues();
  };
  setValues = values => {
    this.field.setValues(values);
  };
  getRegionLabel = () => {
    const { regionName, regionId } =
      find(regions, {
        regionId: window.regionId,
      }) ||
      first(regions) ||
      {};
    return `${regionName || ''}(${regionId})`;
  };
  render() {
    const { getValue } = this.field;
    return (
      <div>
        <Form {...formItemLayout} field={this.field} labelAlign="left" labelTextAlign="left">
          <FormItem label={intl('mse.register.namespace.region')}>
            <div style={{ fontSize: 12, marginTop: 8 }}>{this.getRegionLabel()}</div>
          </FormItem>
          <FormItem label={intl('mse.register.namespace.id')}>
            <div style={{ fontSize: 12, marginTop: 8 }}>{getValue('Id') === 'public' ? '' : getValue('Id')}</div>
          </FormItem>
          <FormItem label={intl('mse.register.namespace')}>
            <div style={{ fontSize: 12, marginTop: 8 }}>{getValue('Name')}</div>
          </FormItem>
        </Form>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default NameSpaceInfo;
