import React from 'react';
import CommonLoading from '../common/CommonLoading';
import CommonDialog from '../base/CommonDialog';
import ComIf from '../common/ComIf';
import CommonBalloon from '../common/CommonBalloon';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import { Icon, Table, Message, Dialog, NumberPicker, Button, Balloon } from '@ali/wind';
import NacosInstanceCreate from './NacosInstanceCreate';
import NacosClusterCreate from './NacosClusterCreate';
import services from 'utils/services';
import { includes } from 'lodash';
import intl from '@ali/wind-intl';

const HealthChecker = {
  none: intl('mse.register.cluster.health_none'),
  tcp: intl('mse.register.cluster.health_tcp'),
  http: intl('mse.register.cluster.health_http'),
};
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * nacos服务集群列表
 */
class NacosClusterList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      clusterList: [],
      Ephemeral: false,
      PageSize: 1000,
      current: 1,
      total: 0,
      openRowKeys: [],
      childOpenRowKeys: [],
      weight: 0,
      loading: false,
      clusterName: '',
      clusterMeta: {},
      dialog: null,
    };
    this.basicParams = {};
    this.cltInstance = {};
  }
  getClusters = (params) => {
    this.basicParams = params;
    const { PageSize, current } = this.state;
    const ClusterId = getParams('ClusterId');
    const InstanceId = getParams('instanceId');
    const data = Object.assign({}, params, { ClusterId, InstanceId, PageSize, PageNum: current });
    request({
      url: 'com.alibaba.MSE.service.ListAnsServiceClusters',
      data,
      beforeSend: () => {
        this.loading && this.loading.openLoading();
      },
      success: (res) => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          const { Clusters, Ephemeral } = Data;

          this.setState({
            Ephemeral,
            clusterList: Clusters.map((item) => {
              return Object.assign({}, { id: `${item.ServiceName}${item.Name}` }, item);
            }),
          });
        }
      },
      complete: () => {
        this.loading && this.loading.closeLoading();
      },
    });
  };
  getInstances = (ServiceName, ClusterName, id, flag) => {
    const { PageSize, current } = this.state;
    const ClusterId = getParams('ClusterId');
    const InstanceId = getParams('instanceId');
    const data = Object.assign({}, { ClusterName }, this.basicParams, {
      ClusterId,
      InstanceId,
      PageSize,
      PageNum: current,
    });
    request({
      url: 'com.alibaba.MSE.service.ListAnsInstances',
      data,
      beforeSend: () => {
        this.loading && this.loading.openLoading();
      },
      success: (res) => {
        const { Data = [] } = res.data;
        const Datas = [];
        const { openRowKeys, clusterList } = this.state;
        if (flag) {
          const micro_id = Data.length > 0 && Data[0].Metadata && (Data[0].Metadata['__micro.service.app.id__'] || '');
          if (Data && micro_id) {
            window.open(`https://mse.console.aliyun.com/#/msc/app/info/information/interface?appId=${micro_id}`, 'top');
          } else {
            Dialog.confirm({
              type: 'warning',
              title: intl('mse.common.tips'),
              content: (
                <div style={{ width: 800, lineHeight: '18px' }}>
                  {intl.html('mse.nocoscluster.weight.access.document')}
                  {intl.html('mse.nocoscluster.weight.other.operate.tips')}
                  {intl.html('mse.nocoscluster.weight.other.function.tips')}
                  <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: '8px', height: '455px' }}>
                    <img src="https://img.alicdn.com/imgextra/i4/O1CN01OdAl0U1OA9pAdv9Qx_!!6000000001664-2-tps-2982-1848.png" style={{ width: '700px' }} />
                  </div>
                </div>
              ),
              messageProps: {
                type: 'warning',
              },
              okProps: { children: intl('mse.common.ok') },
              cancelProps: { children: intl('mse.common.cancel') },
            });
          }
        } else {
          clusterList.forEach((item) => {
            if (item.id === id) {
              item.children = Data;
            }
          });
          if (!openRowKeys.includes(id)) {
            openRowKeys.push(id);
          }
          this.setState({
            clusterList,
            openRowKeys,
          });
        }
      },
      complete: () => {
        this.loading && this.loading.closeLoading();
      },
    });
  };
  getInstancesMetaData = (id) => {
    const { childOpenRowKeys } = this.state;
    if (!childOpenRowKeys.includes(id)) {
      childOpenRowKeys.push(id);
    }
    this.setState({
      childOpenRowKeys,
    });
  };

  switchStatus = (record) => {
    const Advanced = (<Icon
      className="commonbuy-tip"
      type="help"
      size="xs"
      style={{
        marginLeft: 5,
        color: '#888888',
      }}
    />);
    const switchLineDialog = Dialog.confirm({
      type: 'warning',
      title: record.Enabled ? intl('mse.nocoscluster.action.services.offline') : intl('mse.nocoscluster.action.services.online'),
      content: (
        <div style={{ width: 300 }}>
          <span style={{ display: 'block', color: '#888', fontSize: 12, marginTop: 8 }}>
            {intl('mse.nocoscluster.services.operate')}
            <If condition={record.Enabled}>{intl('mse.register.cluster.action.offline')}</If>
            <If condition={!record.Enabled}>{intl('mse.register.cluster.action.online')}</If>
            {intl('mse.common.operate')}
            <div style={{ marginTop: 8 }}>
              <If condition={record.Enabled}>
                {intl('mse.nocoscluster.advanced.offline')}
                <Balloon trigger={Advanced} closable={false}>
                {intl('mse.nocoscluster.advanced.offline.balloon.tips')}<span data-tracker="overview-mse-server-list-offline-details" style={{ color: '#0077cc', cursor: 'pointer' }} onClick={() => this.advancedWeights('line')}>{intl('mse.common.view.details')}</span>
                </Balloon>
              </If>
              <If condition={!record.Enabled}>
                {intl('mse.nocoscluster.advanced.online')}
                <Balloon trigger={Advanced} closable={false}>
                {intl('mse.nocoscluster.advanced.online.ballon.tips')}<span data-tracker="overview-mse-server-list-online-details" style={{ color: '#0077cc', cursor: 'pointer' }} onClick={() => this.advancedWeights('line')}>{intl('mse.common.view.details')}</span>
                </Balloon>
              </If>
            </div>
          </span>
        </div>
      ),
      onOk: () => {
        return new Promise(async (resolve, reject) => {
          request({
            url: 'com.alibaba.MSE.service.UpdateNacosInstance',
            data: {
              ...record,
              InstanceId: getParams('InstanceId'),
              NamespaceId: this.basicParams.NamespaceId,
              ServiceName: this.basicParams.ServiceName,
              GroupName: this.basicParams.GroupName,
              Enabled: !record.Enabled,
            },
            success: (res) => {
              if (res.code === '200' && res.data) {
                resolve();
                Message.success(intl('mse.common.update_success'));
                const { clusterList } = this.state;
                const newRecord = { ...record, Enabled: !record.Enabled };
                clusterList.forEach((item) => {
                  if (item.Name === record.ClusterName) {
                    item.children.forEach((instanceItem) => {
                      if (instanceItem.InstanceId === newRecord.InstanceId) {
                        instanceItem.Enabled = newRecord.Enabled;
                      }
                    });
                  }
                });
                this.setState({
                  clusterList,
                });
              }
            },
          });
        });
      },
      messageProps: {
        type: 'warning',
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
    this.setState({ dialog: switchLineDialog });
  };
  advancedWeights = (str) => {
    const { dialog } = this.state;
    const { dialogClose } = this.props;
    console.log('this.state', this.props);
    dialog.hide();
    dialogClose(str);
  }
  switchWeight = (record) => {
    const { Weight } = record;
    const Advanced = (<Icon
      className="commonbuy-tip"
      type="help"
      size="xs"
      style={{
        marginLeft: 5,
        color: '#888888',
      }}
    />);
    const widgehtDialog = Dialog.confirm({
      type: 'warning',
      title: intl('mse.register.cluster.weight.edit'),
      content: (
        <div style={{ width: 300 }}>
          <NumberPicker
            style={{ width: '100%', marginTop: 16 }}
            defaultValue={Weight}
            min={0}
            max={10000}
            onChange={(v) => this.setState({ weight: v })}
          />
          <span style={{ display: 'block', color: '#888', fontSize: 12, marginTop: 8 }}>
            {intl('mse.register.cluster.weight_hint')}
            <div style={{ marginTop: 8 }}>
              {intl('mse.nocoscluster.advanced.weight.adjustment')}
              <Balloon trigger={Advanced} closable={false}>
              {intl('mse.nocoscluster.advanced.weight.function.tips')}<span data-tracker="overview-mse-server-list-weight-details" style={{ color: '#0077cc', cursor: 'pointer' }} onClick={() => this.advancedWeights('weight')}>{intl('mse.common.view.details')}</span>
              </Balloon>
            </div>
          </span>
        </div>
      ),
      onOk: () => {
        return new Promise(async (resolve, reject) => {
          request({
            url: 'com.alibaba.MSE.service.UpdateNacosInstance',
            data: {
              ...record,
              InstanceId: getParams('InstanceId'),
              NamespaceId: this.basicParams.NamespaceId,
              ServiceName: this.basicParams.ServiceName,
              GroupName: this.basicParams.GroupName,
              Weight: this.state.weight,
            },
            success: (res) => {
              if (res.code === '200' && res.data) {
                resolve();
                Message.success(intl('mse.common.update_success'));
                const { clusterList } = this.state;
                const newRecord = { ...record, Weight: this.state.weight };
                clusterList.forEach((item) => {
                  if (item.Name === record.ClusterName) {
                    item.children.forEach((instanceItem) => {
                      if (instanceItem.InstanceId === newRecord.InstanceId) {
                        instanceItem.Weight = newRecord.Weight;
                      }
                    });
                  }
                });
                this.setState({
                  clusterList,
                });
              }
            },
          });
        });
      },
      messageProps: {
        type: 'warning',
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
    this.setState({
      dialog: widgehtDialog,
    });
  };

  deleteInstance = (record) => {
    const { GroupName, NamespaceId, ServiceName } = this.basicParams;
    Dialog.confirm({
      type: 'warning',
      title: intl('mse.common.delete'),
      content: (
        <div style={{ width: 500 }}>
          {intl.html('mse.common.delete_confirm', { name: `${record.Ip}:${record.Port}` })}
        </div>
      ),
      onOk: () => {
        return new Promise(async (resolve, reject) => {
          const params = {
            InstanceId: getParams('InstanceId'),
            ServiceName: record.ServiceName,
            NamespaceId,
            GroupName,
            ClusterName: record.ClusterName,
            Ip: record.Ip,
            Port: record.Port,
            Ephemeral: record.Ephemeral,
          };
          await services.deleteNacosInstance({
            customErrorHandle: (err, data, callback) => {
              reject();
              callback();
            },
            params: { ...params },
          });
          resolve();
          Message.success(intl('mse.common.delete_success'));
          const { ServiceName, Name, id } = this.cltInstance;
          this.getInstances(ServiceName, Name, id);
        });
      },
      messageProps: {
        type: 'warning',
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
  };

  handleMore = (id) => {
    const { openRowKeys } = this.state;
    let index = openRowKeys.indexOf(id);
    openRowKeys.splice(index, 1);
    this.setState({
      openRowKeys,
    });
  };

  handleChildMore = (id) => {
    const { childOpenRowKeys } = this.state;
    let index = childOpenRowKeys.indexOf(id);
    childOpenRowKeys.splice(index, 1);
    this.setState({
      childOpenRowKeys,
    });
  };

  renderMore = (value, index, record) => {
    this.cltInstance = record;
    const { ServiceName, Name, id, HealthCheckerType } = record;
    const { openRowKeys } = this.state;
    if (openRowKeys.includes(id)) {
      return (
        <a href="javascript:;" onClick={() => this.handleMore(id)}>
          {intl('mse.register.cluster.packup')}
        </a>
      );
    }
    return (
      <div>
        <a href="javascript:;" onClick={() => this.getInstances(ServiceName, Name, id)}>
          {intl('mse.register.cluster.action.app')}
        </a>
        <a href="javascript:;" onClick={() => this.getInstances(ServiceName, Name, id, true)} style={{ marginLeft: 16 }} data-tracker="overview-mse-query-service-details">
          {intl('mse.register.cluster.query.service.details')}
        </a>
        <If
          condition={
            !includes(
              ['http', intl('mse.register.cluster.health_beat')],
              HealthCheckerType.toLowerCase()
            ) && this.props.namingCreateServiceSupported
          }
        >
          <a
            href="javascript:;"
            style={{ marginLeft: 16 }}
            onClick={() => this.openClusterMeta(record)}
          >
            {intl('mse.register.cluster.action.health')}
          </a>
        </If>
      </div>
    );
  };

  openClusterMeta = (record) => {
    const { Name, DefaultCheckPort, UseIPPort4Check, HealthCheckerType } = record;
    const _HealthCheckerType = HealthCheckerType.toLowerCase();
    let _HealthChecker = JSON.stringify({ type: 'NONE' });
    if (_HealthCheckerType === 'tcp') {
      _HealthChecker = JSON.stringify({ type: 'TCP' });
    }
    this.setState({
      clusterName: Name,
      clusterMeta: {
        ClusterName: Name,
        CheckPort: DefaultCheckPort,
        UseInstancePortForCheck: UseIPPort4Check,
        HealthChecker: _HealthChecker,
      },
    });
    this.cltdialog.open();
  };

  renderChildrenMore = (value, index, record) => {
    const { InstanceId, Ephemeral } = record;
    const { childOpenRowKeys } = this.state;
    if (childOpenRowKeys.includes(InstanceId)) {
      return (
        <a href="javascript:;" onClick={() => this.handleChildMore(InstanceId)}>
          {intl('mse.register.cluster.packup')}
        </a>
      );
    }
    return (
      <Actions expandTriggerType="hover">
        <LinkButton key="1" onClick={() => this.getInstancesMetaData(InstanceId)}>
          {intl('mse.register.cluster.action.view')}
        </LinkButton>
        <LinkButton key="2" onClick={() => this.switchWeight(record)} data-tracker="overview-mse-server-list-weight">
          {intl('mse.register.cluster.action.weight')}
        </LinkButton>
        <LinkButton key="3" onClick={() => this.switchStatus(record)}>
          <If condition={record.Enabled}><span data-tracker="overview-mse-server-list-offline">{intl('mse.register.cluster.action.offline')}</span></If>
          <If condition={!record.Enabled}><span data-tracker="overview-mse-server-list-online">{intl('mse.register.cluster.action.online')}</span></If>
        </LinkButton>
        <If condition={!Ephemeral}>
          <LinkButton key="4" onClick={() => this.deleteInstance(record)}>
            {intl('mse.common.delete')}
          </LinkButton>
        </If>
      </Actions>
    );
  };

  renderInstanceMetaData = (value, index, record) => {
    if (!value) {
      return null;
    }
    const { Metadata } = value;
    const dataSource = [];
    let _index = 1;
    for (let i in Metadata) {
      if (_index === 2) {
        _index = 1;
        dataSource[dataSource.length - 1].k2 = i;
        dataSource[dataSource.length - 1].v2 = Metadata[i];
      } else {
        dataSource.push({
          k1: i,
          v1: Metadata[i],
        });
        _index += 1;
      }
    }
    return (
      <div>
        <Table dataSource={dataSource} emptyContent={<span>{intl('mse.common.no_data')}</span>}>
          <Table.Column title="key" dataIndex="k1" width="15%" />
          <Table.Column title="value" dataIndex="v1" width="35%" />
          <Table.Column title="key" dataIndex="k2" width="15%" />
          <Table.Column title="value" dataIndex="v2" width="35%" />
        </Table>
      </div>
    );
  };

  renderInstanceDetail = (value, index, record) => {
    const { Metadata } = record;
    return (
      <div>
        {Object.keys(Metadata).map((key) => {
          return (
            <span key={key} style={{ marginRight: 10 }}>
              <span>{key}</span>:<span>{Metadata[key]}</span>
            </span>
          );
        })}
      </div>
    );
  };

  renderFormatTime = (value) => {
    return <span>{window.moment(value).format('YYYY-MM-DD HH:mm:ss')}</span>;
  };

  renderIpPort = (value, index, record) => {
    return (
      <span>
        {record.Ip}:{record.Port}
      </span>
    );
  };

  renderStatus = (value) => {
    return (
      <span>
        <ComIf if={value}>
          <span className="circle-status green" />
        </ComIf>
        <ComIf if={!value}>
          <span className="circle-status red" />
        </ComIf>
      </span>
    );
  };

  renderEphemeral = (value) => {
    return (
      <span>
        <ComIf if={value}>true</ComIf>
        <ComIf if={!value}>false</ComIf>
      </span>
    );
  };

  renderInstance = (record) => {
    const { childOpenRowKeys } = this.state;
    const children = record.children;

    return (
      <div>
        <Table
          primaryKey="InstanceId"
          dataSource={children}
          openRowKeys={childOpenRowKeys}
          expandedRowRender={this.renderInstanceMetaData}
          hasExpandedRowCtrl={false}
          expandedRowIndent={[0, 0]}
        >
          <Table.Column title="Ip:Port" cell={this.renderIpPort} />
          <Table.Column
            title={intl('mse.register.cluster.app.health')}
            dataIndex="Healthy"
            cell={this.renderStatus}
          />
          <Table.Column
            title={intl('mse.register.cluster.app.enabled')}
            dataIndex="Enabled"
            cell={this.renderStatus}
          />
          <Table.Column
            title={intl('mse.register.cluster.app.ephemeral')}
            dataIndex="Ephemeral"
            cell={this.renderEphemeral}
          />
          <Table.Column title={intl('mse.register.cluster.app.weight')} dataIndex="Weight" />
          <Table.Column
            title={intl('mse.register.cluster.app.interval')}
            dataIndex="InstanceHeartBeatInterval"
          />
          <Table.Column
            title={intl('mse.register.cluster.app.timeout')}
            dataIndex="InstanceHeartBeatTimeOut"
          />
          <Table.Column
            title={intl('mse.register.cluster.app.meta')}
            dataIndex="Metadata"
            cell={this.renderChildrenMore}
          />
        </Table>
      </div>
    );
  };

  renderFooter = () => {
    return (
      <div style={{ textAligin: 'right' }}>
        <Button
          type="primary"
          style={{ marginRight: 10 }}
          onClick={this.submitInstance}
          loading={this.state.loading}
        >
          {intl('mse.common.ok')}
        </Button>
        <Button
          onClick={() => {
            this.dialog.close();
          }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );
  };

  submitInstance = async () => {
    if (this.nscreate.validate()) {
      const values = this.nscreate.getValues();
      const InstanceId = getParams('InstanceId');
      const { GroupName, NamespaceId, ServiceName } = this.basicParams;
      const { Metadata } = values;
      let _Metadata = {};
      if (Metadata.length) {
        Metadata.forEach((data) => {
          const { Key, Value } = data;
          _Metadata[Key] = Value;
        });
      }
      const params = {
        ...values,
        InstanceId,
        NamespaceId,
        ServiceName,
        GroupName,
        Ephemeral: this.state.Ephemeral,
        Metadata: JSON.stringify(_Metadata),
      };
      this.setState({ loading: true });
      await services.createNacosInstance({
        customErrorHandle: (err, data, callback) => {
          this.setState({ loading: false });
          callback();
        },
        params: { ...params },
      });
      Message.success(intl('mse.common.create_success'));
      this.setState({ loading: false });
      this.dialog.close();
      this.getClusters({ GroupName, NamespaceId, ServiceName });
    }
  };

  renderCltFooter = () => {
    return (
      <div style={{ textAligin: 'right' }}>
        <Button
          type="primary"
          style={{ marginRight: 10 }}
          onClick={this.submitCluster}
          loading={this.state.loading}
        >
          {intl('mse.common.ok')}
        </Button>
        <Button
          onClick={() => {
            this.cltdialog.close();
          }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );
  };

  submitCluster = async () => {
    if (this.cltcreate.validate()) {
      const values = this.cltcreate.getValues();
      const InstanceId = getParams('InstanceId');
      const { GroupName, NamespaceId, ServiceName } = this.basicParams;
      const params = { ...values, InstanceId, NamespaceId, ServiceName, GroupName };
      this.setState({ loading: true });
      await services.updateNacosCluster({
        customErrorHandle: (err, data, callback) => {
          this.setState({ loading: false });
          callback();
        },
        params: { ...params },
      });
      Message.success(intl('mse.common.update_success'));
      this.setState({ loading: false });
      this.cltdialog.close();
      this.getClusters({ GroupName, NamespaceId, ServiceName });
    }
  };

  render() {
    const { clusterList, openRowKeys } = this.state;
    return (
      <div>
        <CommonLoading ref={(node) => (this.loading = node)}>
          <div style={{ width: '100%', position: 'relative' }}>
            <If condition={this.props.namingCreateServiceSupported}>
              <Button type="primary" onClick={() => this.dialog.open()} style={{ marginBottom: 8 }}>
                {intl('mse.register.cluster.create')}
              </Button>
            </If>
            <Table
              primaryKey="id"
              dataSource={clusterList}
              hasBorder={false}
              expandedRowRender={this.renderInstance}
              openRowKeys={openRowKeys}
              hasExpandedRowCtrl={false}
              expandedRowIndent={[0, 0]}
              emptyContent={<span>{intl('mse.common.no_data')}</span>}
            >
              <Table.Column
                title={
                  <CommonBalloon content={intl('mse.register.cluster.app_hint')}>
                    {intl('mse.register.cluster.app')}
                    <Icon
                      className="commonbuy-tip"
                      type="help"
                      size="small"
                      style={{
                        marginLeft: 5,
                        color: '#888888',
                      }}
                    />
                  </CommonBalloon>
                }
                dataIndex="Name"
              />
              <Table.Column
                title={intl('mse.register.cluster.health')}
                dataIndex="HealthCheckerType"
                cell={(value) => {
                  const _value = value.toLowerCase();
                  const renderValue = HealthChecker[_value] ? HealthChecker[_value] : value;
                  return renderValue;
                }}
              />
              <Table.Column
                title={intl('mse.register.cluster.operate')}
                dataIndex="ServiceName"
                cell={this.renderMore}
              />
            </Table>
          </div>
        </CommonLoading>
        <CommonDialog
          title={intl('mse.register.cluster.create')}
          style={{ width: 870 }}
          childStyle={{ height: 332, overflowX: 'hidden' }}
          footer={this.renderFooter()}
          ref={(node) => (this.dialog = node)}
          shouldUpdatePosition
        >
          <NacosInstanceCreate ref={(node) => (this.nscreate = node)} />
        </CommonDialog>
        <CommonDialog
          title={intl.html('mse.register.cluster.health_check', { name: this.state.clusterName })}
          style={{ width: 870 }}
          childStyle={{ height: 332, overflowX: 'hidden' }}
          footer={this.renderCltFooter()}
          ref={(node) => (this.cltdialog = node)}
          shouldUpdatePosition
        >
          <NacosClusterCreate
            ref={(node) => (this.cltcreate = node)}
            clusterMeta={this.state.clusterMeta}
          />
        </CommonDialog>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default NacosClusterList;
