import React from 'react';
import CommonLoading from '../common/CommonLoading';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * nacos命名空间
 */

class NacosNameSpaceTab extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      namespaces: [],
      PageSize: 10,
      current: 1,
      total: 0,
    };
  }
  componentDidMount = () => {};

  render() {
    return <div>s</div>;
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default NacosNameSpaceTab;
