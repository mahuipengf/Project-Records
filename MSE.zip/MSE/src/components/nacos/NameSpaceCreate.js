import React from 'react';
import { find, first, get } from 'lodash';
import { Form, Input, Field } from '@ali/wind';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 创建命名空间
 */
const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};
const FormItem = Form.Item;
const regions = get(window, 'ALIYUN_CONSOLE_CONFIG.STATIC_API.regions', []);
class NameSpaceCreate extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.AppVersion = getParams('AppVersion');
    this.field = new Field(this);
  }

  validate = () => {
    this.field.validate();
    let validateOk = true;
    const errors = this.field.getErrors();
    Object.keys(errors).forEach(key => {
      if (errors[key]) {
        validateOk = false;
      }
    });
    return validateOk;
  };

  getValues = () => {
    return this.field.getValues();
  };

  setValues = values => {
    this.field.setValues(values);
  };

  getRegionLabel = () => {
    const { regionName, regionId } =
      find(regions, {
        regionId: window.regionId,
      }) ||
      first(regions) ||
      {};
    return `${regionName || ''}(${regionId})`;
  };

  validateNamespzecId = (rule, value, callback) => {
    if (!value || value.trim() === '') {
      callback();
    } else {
      const { locale = {} } = this.props;
      if (value.length > 128) {
        callback('输入字符超过字符数限制');
      }
      const chartReg = /^[\w-]+/g;
      const matchResult = value.match(chartReg);
      if (matchResult) {
        if (matchResult.length > 1) {
          callback('请勿输入非法字符');
        } else {
          if (value.length !== matchResult[0].length) {
            callback('请勿输入非法字符');
            return;
          }
          callback();
        }
      } else {
        callback('请勿输入非法字符');
      }
    }
  }

  render() {
    const { init, getValue } = this.field;
    const nameValue = getValue('Name'); // public 的名称不可编辑
    const id = getValue('Id');
    return (
      <div>
        <Form {...formItemLayout} field={this.field} labelAlign="left" labelTextAlign="left">
          <FormItem label={intl('mse.register.namespace.region')}>
            <div style={{ fontSize: 12, marginTop: 8 }}>{this.getRegionLabel()}</div>
          </FormItem>
          <FormItem label={intl('mse.register.namespace_name')} required>
            <Input
              htmlType="text"
              {...init('Name', {
                rules: [
                  {
                    required: true,
                    message: intl('mse.register.namespace.name_validate'),
                  },
                ],
              })}
            />
          </FormItem>
          <FormItem label={intl('mse.register.namespace.id')} >
            <Input
              htmlType="text"
              {...init('Id', {
                rules: [
                  { validator: this.validateNamespzecId },
                ],
              })}
              placeholder={intl('mse.register.namespace_placeholder')}
              disabled={this.props.title === intl('mse.register.namespace.edit')}
            />
          </FormItem>
          {
            this.AppVersion === '1.1.3' && (
              <FormItem label={intl('mse.register.namespace.desc')} required>
                <Input.TextArea
                  htmlType="text"
                  {...init('Desc', {
                    rules: [
                      {
                        required: true,
                        message: intl('mse.register.namespace.desc_validate'),
                      },
                    ],
                  })}
                />
                <Input htmlType="hidden" {...init('ServiceCount', { initValue: 1000 })} />
                <Input htmlType="hidden" {...init('Id')} />
              </FormItem>
            )
          }
        </Form>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default NameSpaceCreate;
