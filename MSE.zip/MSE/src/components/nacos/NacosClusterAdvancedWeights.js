import React, { useRef, useEffect } from 'react';
import Panel from '../common/Panel';
import intl from '@ali/wind-intl';
import { useCompare } from '@ali/cn-design';

const NacosClusterAdvancedWeights = ({ showIndex, renderTag }) => {
  const refPanel = useRef(null);
  useEffect(() => {
    showIndex && refPanel.current.show();
  }, [useCompare(showIndex)]);
  return (
    <Panel ref={refPanel} title={intl('mse.service.governance')}>
      <If condition={renderTag === 'weight'}>
        <iframe
          src="https://aliware-images.oss-cn-hangzhou.aliyuncs.com/MSE/mse-grey-and-online-guide.html"
          style={{ width: '100%', border: 'none', height: 'calc(100% + 16px)', marginTop: -16 }}
        />
      </If>
      <If condition={renderTag === 'line'}>
        <iframe
          src="https://aliware-images.oss-cn-hangzhou.aliyuncs.com/MSE/mse-offline-and-dump-guide.html"
          style={{ width: '100%', border: 'none', height: 'calc(100% + 16px)', marginTop: -16 }}
        />
      </If>
    </Panel>
  );
};

export default NacosClusterAdvancedWeights;
