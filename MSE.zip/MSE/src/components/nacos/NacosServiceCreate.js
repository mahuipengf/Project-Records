import React, { useEffect, useState, useRef } from 'react';
import PropTypes from 'prop-types';
import Panel from '../common/Panel';
import {
  useCompare,
  Form,
  Input,
  Loading,
  Field,
  Radio,
  Message,
  Button,
  Select,
  Switch,
  Balloon,
  IconButton,
  BalloonIcon,
  NumberPicker,
  Icon
} from '@ali/cn-design';
import services from 'utils/services';
import intl from '@ali/wind-intl';
import { compareNacosVersion } from '../../utils/utils';
import AppIntoDialog from 'components/AppIntoDialog';
import { includes } from 'lodash';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const FormItemLabel = (text = '', popCtx = '') => (
  <span>
    <span style={{ fontSize: '13px', color: '#333' }}>{text}</span>
    <BalloonIcon
      icon="help"
      align="r"
      style={{
        color: popCtx ? '#808080' : 'transparent',
        fontSize: '12px',
        marginLeft: '5px',
      }}
      text={popCtx}
    />
  </span>
);
const EphemeralData = [
  {
    value: true,
    label: intl('mse.common.yes'),
  },
  {
    value: false,
    label: intl('mse.common.no'),
  },
];

const NacosServiceCreate = (props) => {
  const refPanel = useRef(null);
  const dialogRef = useRef(null);
  const field = Field.useField();
  const [isLoading, setIsLoading] = useState(false);
  const { init, validate, setValues, getValue } = field;
  const [checkType, setCheckType] = useState('connection');
  const [ephemeral, setEphemeral] = useState(true);
  const [isAppLoading, setIsAppLoading] = useState(false);
  const [isPortLoading, setIsPortLoading] = useState(false);
  const [namespaces, setNamespaces] = useState([]);
  const [applications, setApplications] = useState([]);
  const applicationRef = useRef({});
  const [livenessCheck, setLivenessCheck] = useState(true);
  const [isOpenMsc, setIsOpenMsc] = useState(false);
  const [isGTNACOS_2_1_2_1, setIsGTNACOS_2_1_2_1] = useState(false);
  // const [appLinkService, setAppLinkService] = useState({});

  const { showIndex = 0, namespaceId, namespaceLabel, regionLabel, refreshNacosData } = props;

  useEffect(() => {
    showIndex && refPanel.current.show();
    // setValues({ CheckType: 'connection' });
    const _isGTNACOS_2_1_2_1 = compareNacosVersion();
    getUserStatus();
    getAppNamespaceList();
    // getApplicationList();
    setIsGTNACOS_2_1_2_1(_isGTNACOS_2_1_2_1);
  }, [useCompare(showIndex)]);

  const getUserStatus = async () => {
    setIsLoading(true);
    const res = await services.getUserStatus({
      customErrorHandle: (err, data, callback) => {
        setIsLoading(false);
        callback();
      },
    });
    const { Status = 1 } = res;
    // Status    是否开通  1 未开通、2 开通
    // Version   开通版本  0 基础版、 1 专业版、 2 企业版
    // FreeVersion  是否开通试用版  0 未开通、1 开通试用版、 2 试用版到期
    const _isOpenMsc = Status === 2;
    setIsLoading(false);
    setIsOpenMsc(_isOpenMsc);
  };

  const getAppNamespaceList = async () => {
    const res = await services.getAppNamespaceList({
      customErrorHandle: (err, data, callback) => {
        callback();
      },
      params: {
        Source: 'edasmsc',
        Region: window.regionId
      },
    });
    const _namespaces = res && res.map(n => {
      const { Namespace } = n;
      return {
        ...n,
        label: Namespace,
        value: Namespace
      };
    });
    setNamespaces(_namespaces);
  };

  const getApplicationList = async (n) => {
    setIsAppLoading(true);
    const res = await services.getApplicationList({
      customErrorHandle: (err, data, callback) => {
        setIsAppLoading(false);
        callback();
      },
      params: {
        pageNumber: 1,
        pageSize: 100,
        Source: 'edasmsc',
        Region: window.regionId,
        Namespace: n,
      },
    });
    const { Result = [], TotalSize = 0 } = res;
    const _applications = Result.map(app => {
      const { Namespace, AppId, AppName } = app;
      Reflect.set(applicationRef.current, AppId, app);
      return {
        ...app,
        label: `${Namespace}: ${AppName}`,
        value: AppId
      };
    });
    setApplications(_applications);
    setIsAppLoading(false);
  };

  const getServiceListPage = async (appId) => {
    setIsPortLoading(true);
    const _services = await services.getServiceListPage({
      customErrorHandle: (err, data, callback) => {
        setIsPortLoading(false);
        callback();
      },
      params: {
        AppId: appId,
        PageNumber: 1,
        PageSize: 10,
        Source: 'edasmsc',
        ServiceType: 'springCloud',
        Region: window.regionId
      },
    });
    const { Result = [] } = _services;
    const [appLinkService] = Result;
    if (!appLinkService) {
      setValues({ Port: 80 });
      setIsPortLoading(false);
      return;
    }
    const { ServiceName } = appLinkService;
    const _ports = await services.getServiceProvidersPage({
      customErrorHandle: (err, data, callback) => {
        setIsPortLoading(false);
        callback();
      },
      params: {
        AppId: appId,
        ServiceName,
        PageNumber: 1,
        PageSize: 10,
        Source: 'edasmsc',
        ServiceType: 'springCloud',
        Region: window.regionId
      },
    });
    const { Result: portResult = [] } = _ports;
    const [appLinkPort] = portResult;
    const { Port = 80 } = appLinkPort;
    setValues({ Port });
    setIsPortLoading(false);
  };

  const openMsc = () => {
    const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
    const isIntl = aliyunSite === 'INTL';
    let commodityCode = 'mse_basic_public_cn';
    let domain = 'https://common-buy.aliyun.com';
    if (isIntl) {
      commodityCode = 'mse_basic_public_intl';
      domain = 'https://common-buy-intl.alibabacloud.com';
    }
    const openUri = `${domain}/?commodityCode=${commodityCode}`;
    window.open(openUri, '_blank');
  };

  const handleSubmit = () =>
    new Promise((resolve, reject) => {
      validate(async (errors, values) => {
        if (errors) return reject(errors);
        const NamespaceId = namespaceId;
        const LivenessCheck = livenessCheck;
        const ClusterId = getParams('ClusterId');
        const InstanceId = getParams('InstanceId');
        const { initEphemeral = '' } = values;
        const params = {
          ...values,
          InstanceId,
          NamespaceId,
        };
        if (initEphemeral !== 'Governance') {
          let _Ephemeral;
          if (!isGTNACOS_2_1_2_1) {
            const { Ephemeral } = values;
            _Ephemeral = !Ephemeral;
          } else {
            const { initEphemeral } = values;
            _Ephemeral = initEphemeral === 'SDK';
          }
          const _params = {
            ...params,
            ClusterId,
            Ephemeral: _Ephemeral
          };
          await services.createNacosService({
            customErrorHandle: (err, data, callback) => {
              reject();
              callback();
            },
            params: { ..._params },
          });
        } else {
          const app = Reflect.get(applicationRef.current, values.AppId) || {};
          const _params = {
            ...params,
            LivenessCheck,
            RegionId: window.regionId,
            AppName: `${app.Namespace}: ${app.AppName}`
          };
          await services.createGovernanceService({
            customErrorHandle: (err, data, callback) => {
              reject();
              callback();
            },
            params: { ..._params },
          });
        }
        Message.success(intl('mse.common.create_success'));
        resolve();
        refreshNacosData();
      });
    });

  return (
    <Panel
      ref={refPanel}
      title={intl('mse.register.service.create')}
      onOk={handleSubmit}
      footerAction={['ok', 'cancel']}
    >
      <Loading visible={isLoading} style={{ width: '100%' }}>
        <Form field={field} labelAlign="top">
          <FormItem label={intl('mse.register.namespace.region')}>
            <div style={{ lineHeight: '32px' }}>{regionLabel}</div>
          </FormItem>
          <FormItem label={intl('mse.register.namespace')}>
            <div style={{ lineHeight: '32px' }}>{namespaceLabel}</div>
          </FormItem>
          <FormItem label="服务名称" required>
            <Input
              {...init('ServiceName', {
                rules: [
                  {
                    required: true,
                    message: intl('mse.register.service.name_validate'),
                  },
                  {
                    pattern: /^[0-9a-zA-Z\-_.:]{1,236}$/,
                    message: intl('mse.register.service.name_placeholder'),
                  },
                ],
              })}
              placeholder={intl('mse.register.service.name_placeholder')}
              maxLength={236}
              showLimitHint
            />
          </FormItem>
          <FormItem
            required
            label={FormItemLabel('分组名称', intl('mse.register.service.group_hint'))}
          >
            <Input
              {...init('GroupName', {
                rules: [
                  {
                    required: true,
                    message: intl('mse.register.service.group_validate'),
                  },
                  {
                    pattern: /^[0-9a-zA-Z\-_.:]{1,128}$/,
                    message: intl('mse.register.service.group_placeholder'),
                  },
                ],
              })}
              placeholder={intl('mse.register.service.group_placeholder')}
              maxLength={128}
              showLimitHint
            />
          </FormItem>
          <If condition={!isGTNACOS_2_1_2_1}>
            <FormItem
              label={FormItemLabel(
                intl('mse.register.service.ephemeral'),
                intl('mse.register.service.ephemeral_hint')
              )}
            >
              <RadioGroup
                {...init('Ephemeral', {
                  // false 是持久化
                  initValue: false,
                })}
                dataSource={EphemeralData}
              />
            </FormItem>
            <FormItem
              label={FormItemLabel(
                intl('mse.register.service.threshold'),
                intl('mse.register.service.threshold_hint')
              )}
            >
              <NumberPicker
                {...init('ProtectThreshold', {
                  initValue: 0,
                })}
                style={{ width: '100%' }}
                min={0}
                max={1}
                step={0.1}
              />
            </FormItem>
          </If>
          <If condition={isGTNACOS_2_1_2_1}>
            <FormItem
              required
              label="实例来源"
            >
              <RadioGroup
                {...init('initEphemeral', {
                  initValue: 'Console',
                  rules: [
                    {
                      required: true,
                      message: '请选择实例来源',
                    }
                  ],
                  props: {
                    onChange: _ephemeral => setEphemeral(_ephemeral)
                  }
                })}
                dataSource={[
                  {
                    value: 'Console',
                    label: FormItemLabel(
                      '控制台注册',
                      '在MSE注册中心控制台上手工注册的实例'
                    ),
                  },
                  {
                    value: 'SDK',
                    label: FormItemLabel(
                      'SDK注册',
                      '在应用中调用Nacos SDK注册实例接口注册的实例'
                    ),
                  },
                  {
                    value: 'Governance',
                    label: (
                      <div style={{ display: 'inline-block' }}>
                        <If condition={!isOpenMsc}>
                          <Balloon
                            trigger={
                              <span>{FormItemLabel('服务治理注册', '通过关联服务治理应用自动同步过来的实例')}</span>
                            }
                            visible
                            align="r"
                            closable={false}
                          >
                            <div>
                              <Icon
                                size="small"
                                type="prompt"
                                style={{ color: '#0064c8', marginRight: 6 }}
                              />
                              <span
                                style={{ color: '#0064c8', cursor: 'pointer', marginRight: 4 }}
                                onClick={openMsc}
                              >
                                开通MSE服务治理
                              </span>
                              通过Java Agent进行服务注册发现，试用版15天内免费
                            </div>
                          </Balloon>
                        </If>
                        <If condition={isOpenMsc}>
                          <span>{FormItemLabel('服务治理注册', '通过关联服务治理应用自动同步过来的实例')}</span>
                        </If>
                      </div>
                    ),
                    disabled: !isOpenMsc,
                  }
                ]}
              />
            </FormItem>
            <If condition={getValue('initEphemeral') !== 'Governance'}>
              <FormItem
                label={FormItemLabel(
                  intl('mse.register.service.threshold'),
                  intl('mse.register.service.threshold_hint')
                )}
              >
                <NumberPicker
                  {...init('ProtectThreshold', {
                    initValue: 0,
                  })}
                  style={{ width: '100%' }}
                  min={0}
                  max={1}
                  step={0.1}
                />
              </FormItem>
            </If>
            <If condition={getValue('initEphemeral') === 'Governance'}>
              <FormItem
                label="命名空间"
                required
              >
                <Select
                  {...init('Namespace', {
                    rules: [
                      {
                        required: true,
                        message: '请选择命名空间',
                      }
                    ],
                    props: {
                      onChange: (n) => getApplicationList(n)
                    }
                  })}
                  style={{ width: '100%' }}
                  dataSource={namespaces}
                  placeholder="请选择命名空间"
                />
              </FormItem>
              <FormItem
                label="应用名称"
                required
              >
                <Select
                  {...init('AppId', {
                    rules: [
                      {
                        required: true,
                        message: '请选择服务治理应用',
                      }
                    ],
                    props: {
                      onChange: (appId) => getServiceListPage(appId)
                    }
                  })}
                  style={{ width: '86%' }}
                  dataSource={applications}
                  placeholder="请选择应用"
                />
                <div
                  style={{ display: 'inline-block', width: '14%', textAlign: 'end' }}
                >
                  <IconButton
                    type={!isAppLoading ? 'refresh' : 'loading'}
                    onClick={() => { getApplicationList(); }}
                  />
                  <Button
                    text
                    type="primary"
                    style={{ marginLeft: 10, marginTop: -4 }}
                    onClick={() => dialogRef.current.open()}
                  >
                    接入新应用
                  </Button>
                </div>
              </FormItem>
              <FormItem
                required
                label="端口"
              >
                <Input
                  {...init('Port', {
                    initValue: 80,
                    rules: [
                      {
                        required: true,
                        message: '请输入服务端口',
                      }
                    ],
                  })}
                  state={isPortLoading ? 'loading' : ''}
                  placeholder="选择应用后自动填入，支持修改"
                />
              </FormItem>
              <FormItem
                required
                label="开启健康检查"
              >
                <Switch
                  checked={livenessCheck}
                  onChange={checked => setLivenessCheck(checked)}
                />
              </FormItem>
              <If condition={livenessCheck}>
                <FormItem
                  required
                  label={FormItemLabel('健康检查协议', '链接存活检查通过检查provider和Nacos服务端维持的长连接是否存在来判断应用是否健康；TCP协议健康检查通过发送SYN握手报文来检测服务器端口是否存活；HTTP协议健康检查通过发送请求模拟浏览器的访问行为来检查服务器应用是否健康')}
                >
                  <RadioGroup
                    {...init('CheckType', {
                        initValue: 'connection',
                        rules: [
                          {
                            required: true,
                            message: '请选择健康检查协议',
                          }
                        ],
                        props: {
                          onChange: _checkType => setCheckType(_checkType)
                        }
                    })}
                    dataSource={[
                      {
                        value: 'connection',
                        label: '链接存活检查',
                      },
                      {
                        value: 'tcp',
                        label: 'TCP',
                      },
                      {
                        value: 'http',
                        label: 'HTTP',
                      },
                    ]}
                  />
                </FormItem>
                <If condition={includes(['tcp', 'http'], getValue('CheckType'))}>
                  <If condition={getValue('CheckType') === 'http'}>
                    <FormItem
                      required
                      label={FormItemLabel('健康检查路径', '用于健康检查页面文件的URI，建议对静态页面进行检查')}
                    >
                      <Input
                        {...init('CheckPath', {
                          rules: [
                            {
                              required: true,
                              message: '请输入健康检查路径',
                            }
                          ],
                        })}
                        maxLength={80}
                        showLimitHint
                        placeholder="长度限制为1-80个字符，只能使用字母、数字、“-”、“_”、“%”、“？”、“#”、“&”、“=”这些字符"
                      />
                    </FormItem>
                  </If>
                  <FormItem
                    label={FormItemLabel('健康检查响应超时时间', '每次健康检查响应的最大超时时间，超时视同不健康')}
                  >
                    <NumberPicker
                      {...init('CheckTimeout', {
                        initValue: 5
                      })}
                      min={0}
                      addonTextAfter="秒"
                      style={{ width: '100%' }}
                    />
                  </FormItem>
                  <FormItem
                    label={FormItemLabel('健康检查响应间隔时间', '相邻两次健康检查的时间间隔')}
                  >
                    <NumberPicker
                      {...init('CheckInternal', {
                        initValue: 2
                      })}
                      min={0}
                      addonTextAfter="秒"
                      style={{ width: '100%' }}
                    />
                  </FormItem>
                  <FormItem
                    label={FormItemLabel('健康检查健康阈值', '表示服务从异常到健康的连续健康检查成功次数')}
                  >
                    <NumberPicker
                      {...init('HealthyCheckTimes', {
                        initValue: 2
                      })}
                      min={0}
                      addonTextAfter="次"
                      style={{ width: '100%' }}
                    />
                  </FormItem>
                  <FormItem
                    label={FormItemLabel('健康检查不健康阈值', '表示服务从健康到异常的连续健康检查失败次数')}
                  >
                    <NumberPicker
                      {...init('UnhealthyCheckTimes', {
                        initValue: 2
                      })}
                      min={0}
                      addonTextAfter="次"
                      style={{ width: '100%' }}
                    />
                  </FormItem>
                </If>
              </If>
            </If>
          </If>
        </Form>
        <AppIntoDialog ref={dialogRef} />
      </Loading>
    </Panel>
  );
};

NacosServiceCreate.propTypes = {
  fetchNacosData: PropTypes.func,
  namespaceLabel: PropTypes.string,
  showIndex: PropTypes.number,
  namespaceId: PropTypes.string,
  regionLabel: PropTypes.string,
};

export default NacosServiceCreate;
