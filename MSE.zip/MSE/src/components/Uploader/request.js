import { each } from 'lodash';
import { isEmpty } from '@ali/cn-design';

const getError = (option, xhr, msg) => {
  const newMsg = msg || `cannot post ${option.action} ${xhr.status}'`;
  const err = new Error(newMsg);
  err.status = xhr.status;
  err.method = option.method;
  err.url = option.action;
  return err;
};

const getBody = (xhr) => {
  const text = xhr.responseText || xhr.response;
  if (!text) {
    return text;
  }

  try {
    return JSON.parse(text);
  } catch (e) {
    return text;
  }
};

/**
 * 自定义request扩展支持二进制
 * @param {*} options
 * @param {*} format
 * formdata 以表单形式提交，binary 以二进制形式提交
 */
const request = (options, format = 'formdata') => {
  const {
    onProgress,
    onError,
    onSuccess,
    method = 'POST',
    headers = {},
    data = {},
    timeout,
    withCredentials,
  } = options;
  const xhr = new XMLHttpRequest();

  if (onProgress && xhr.upload) {
    xhr.upload.onprogress = function progress(e) {
      if (e.total > 0) {
        e.percent = (e.loaded / e.total) * 100;
      }
      onProgress(e);
    };
  }

  xhr.onerror = function error(e) {
    onError(e);
  };

  xhr.onload = function onload() {
    if (xhr.status < 200 || xhr.status >= 300) {
      return onError(getError(options, xhr), getBody(xhr));
    }

    onSuccess(getBody(xhr), xhr);
  };

  if (format === 'formdata') {
    xhr.open(method, options.action, true);

    const formData = new FormData();

    if (typeof timeout === 'number' && timeout > 0) {
      xhr.timeout = timeout;
      xhr.ontimeout = () => {
        const msg = `Upload abort for exceeding time (timeout: ${timeout}ms)`;
        onError(getError(options, xhr, msg), getBody(xhr));
      };
    }

    if (withCredentials && 'withCredentials' in xhr) {
      xhr.withCredentials = true;
    }

    if (headers['X-Requested-With'] !== null) {
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    }

    if (!isEmpty(headers)) {
      each(Object.keys(headers), (key) => {
        if (headers[key] !== null) {
          xhr.setRequestHeader(key, headers[key]);
        }
      });
    }

    if (!isEmpty(data)) {
      each(Object.keys(data), (key) => {
        if (data[key] !== null) {
          formData.append(key, data[key]);
        }
      });
    }

    formData.append(options.filename, options.file);

    xhr.send(formData);
  } else if (format === 'binary') {
    xhr.open(method, options.action, true);

    if (typeof timeout === 'number' && timeout > 0) {
      xhr.timeout = timeout;
      xhr.ontimeout = () => {
        const msg = `Upload abort for exceeding time (timeout: ${timeout}ms)`;
        onError(getError(options, xhr, msg), getBody(xhr));
      };
    }

    if (withCredentials && 'withCredentials' in xhr) {
      xhr.withCredentials = true;
    }

    if (headers['X-Requested-With'] !== null) {
      xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    }

    if (!isEmpty(headers)) {
      each(Object.keys(headers), (key) => {
        if (headers[key] !== null) {
          xhr.setRequestHeader(key, headers[key]);
        }
      });
    }

    xhr.send(options.file);
  }

  return {
    abort() {
      xhr.abort();
    },
  };
};

export default request;
