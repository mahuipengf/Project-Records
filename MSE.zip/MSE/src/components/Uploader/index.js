import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { isEmpty, head } from 'lodash';
import { Upload, Message, Button, Icon } from '@ali/cn-design';
import request from './request';
import intl from '@ali/wind-intl';

const Uploader = (props) => {
  const {
    uploader,
    uploaderChange,
    // 前缀
    uploadAccept = 'snapshot',
    // 支持 formdata和binary
    format = 'formdata',
  } = props;
  const [uploadValue, setUploadValue] = useState([]);

  const formatter = () => ({
    success: true,
    url: uploader.fileUrl,
  });

  const handleError = (error) => {
    console.log('error: ', error);
    if (error.error.code === 'BEFOREUPLOAD_REJECT') return;
    Message.error(intl('mse.register.node.upload.message1'));
    const data = { ...uploader, status: false };
    uploaderChange(data);
  };

  const handleSuccess = () => {
    const data = { ...uploader, status: true };
    uploaderChange(data);
  };

  const handleRemove = () => {
    setUploadValue([]);
    const data = { ...uploader, status: false };
    uploaderChange(data);
  };

  const beforeUpload = (file) => {
    console.log('file: ', file);
    if (isEmpty(file)) return false;
    const fileName = head(file.name.split('.'));
    if (uploadAccept !== '' && uploadAccept !== fileName) {
      Message.warning(intl('mse.register.node.upload.message2'));
      setUploadValue([]);
      return false;
    }
    if (file.size > uploader.maxSize * 1024 * 1024) {
      Message.warning(
        intl('mse.register.node.upload.message3', {
          size: uploader.maxSize,
        })
      );
      setUploadValue([]);
      return false;
    }
    setUploadValue([file]);
    const data = { ...uploader, fileName: file.name };
    uploaderChange(data);
    return true;
  };

  return (
    <Upload
      action={uploader.fileUrl}
      value={uploadValue}
      limit={1}
      listType="text"
      accept={uploadAccept}
      formatter={formatter}
      request={(options) => request(options, format)}
      onSuccess={handleSuccess}
      onError={handleError}
      onRemove={handleRemove}
      beforeUpload={beforeUpload}
      disabled={isEmpty(uploader.fileUrl)}
      method="put"
      headers={{
        'Content-Type': '',
      }}
      style={{ width: '100%', textAlign: 'center' }}
    >
      <Button loading={isEmpty(uploader.fileUrl)} type="primary">
        <Icon type="upload" />
        {intl('mse.register.node.upload')}
      </Button>
    </Upload>
  );
};

Uploader.propTypes = {
  uploader: PropTypes.object,
  uploaderChange: PropTypes.func,
  uploadSize: PropTypes.number,
  uploadAccept: PropTypes.string,
  format: PropTypes.string,
};

export default Uploader;
