import React, { useState } from 'react';
import { X_MSE_ENV_ARR } from 'constants';
import { Select } from '@ali/wind';
import { find, get } from 'lodash';

const PreEnvSelector = () => {
  const [currentEnv, setCurrentEnv] = useState(sessionStorage.getItem('X-MSE-ENV-KEY'));

  const handleChangeEnv = (val) => {
    sessionStorage.setItem('X-MSE-ENV-KEY', val);
    setCurrentEnv(val);
    setTimeout(() => {
      window.location.reload();
    }, 300);
  };
  const X_MSE_ENV_KEY = currentEnv;
  const currentEnvItem = find(X_MSE_ENV_ARR, { value: X_MSE_ENV_KEY }) || {};
  const ip = {
    mse: get(currentEnvItem, 'ip.mse', ''),
    edasmsc: get(currentEnvItem, 'ip.edasmsc', ''),
  };
  const mse_x_acs_debug_http_host = ip.mse || '';
  sessionStorage.setItem('mse_x_acs_debug_http_host', mse_x_acs_debug_http_host);

  return (
    <div style={{
      position: 'fixed',
      zIndex: 10000,
      left: 20,
      bottom: 20
    }}
    >
      <Select
        style={{ minWidth: 120 }}
        showSearch
        dataSource={X_MSE_ENV_ARR}
        value={currentEnv}
        onChange={handleChangeEnv}
      />
    </div>
  );
};

export default PreEnvSelector;
