import React, { useState, useEffect } from 'react';
import { Dialog, Button, Balloon, Icon, Tag } from '@ali/wind';
import { TagContainer, IconButton, Table, Message } from '@ali/cn-design';
import services from 'utils/services';
import ResourceTag from './ResourceTag';
import intl from '@ali/wind-intl';
import { get } from 'lodash';
import './index.less';

const TagsResourceDialog = (props) => {
  const { visible, onClose, onCancel, dataSource, resourceGroup, onRefresh } = props;
  const [tagValues, setTagValues] = useState();
  const [addValues, setAddValues] = useState([]);
  const [removeValues, setRemoveValues] = useState([]);
  const [resourceIds, setResourceIds] = useState({});
  const [step, setStep] = useState(1);
  const [resultDataSource, setResultDataSource] = useState([]);
  const [loading, setLoading] = useState(false);
  const [disabled, setDisabled] = useState(false);
  const [tagsLength, setTagsLength] = useState(0);

  const handleChangeTag = (params) => {
    const { addValues, deleteValues, values, errors } = params;
    console.group('------------');
    console.log('addValues', addValues);
    console.log('deleteValues', deleteValues);
    console.log('values', values);
    console.log('errors', errors);
    console.groupEnd('------------');
    setTagsLength(values.length);

    const systemValues = values.filter((val) => val.key.includes('acs:'));
    errors ? setDisabled(true) : setDisabled(false);
    if (systemValues.length) {
      setDisabled(true);
    } else {
      setTagValues(values);
      setAddValues(addValues);
      setRemoveValues(deleteValues);
    }
  };

  const onSubmit = async () => {
    const addtagsObj = {};
    const rmTagsObj = {};
    let removeRes = {};
    let addRes = {};
    let success = false;
    if (addValues && addValues.length) {
      addValues.forEach((item, index) => {
        addtagsObj[`Tag.${index + 1}.Key`] = item.key;
        addtagsObj[`Tag.${index + 1}.Value`] = item.value;
      });
    }
    if (removeValues && removeValues.length) {
      removeValues.forEach((item, index) => {
        rmTagsObj[`TagKey.${index + 1}`] = item.key;
      });
    }
    return new Promise(async (resolve, reject) => {
      setLoading(true);
      if (removeValues.length) {
        removeRes = await romoveTagResources(rmTagsObj, reject);
      }
      if (addValues.length) {
        addRes = await addTagResources(addtagsObj, reject);
      }
      success = get(addRes, 'Success', true) && get(removeRes, 'Success', true);
      setLoading(false);
      if (success) {
        const res = resourceGroup[0];
        const data = [{ ...res, tagValues, addValues, removeValues }];
        setResultDataSource(data);
        setStep(2);
      }
      resolve();
    });
  };

  const addTagResources = async (tags, reject) => {
    const res = await services.TagResources({
      params: { RegionId: window.regionId, ResourceType: 'cluster', ...tags, ...resourceIds },
    });
    if (!res.Success) {
      Dialog.alert({
        title: intl('mse.errormessage.wrong'),
        content: res.Message,
      });
      setLoading(false);
    }
    return res;
  };
  const romoveTagResources = async (tags, reject) => {
    const res = await services.UntagResources({
      params: { RegionId: window.regionId, ResourceType: 'cluster', ...tags, ...resourceIds },
    });
    if (!res.Success) {
      Dialog.alert({
        title: intl('mse.errormessage.wrong'),
        content: res.Message,
      });
      setLoading(false);
    }
    return res;
  };

  const fetchKeys = async () => {
    if (resourceGroup && resourceGroup.length) {
      const resourceIdObj = {};
      resourceGroup.forEach((item, index) => {
        resourceIdObj[`ResourceId.${index + 1}`] = item.resourceId;
      });
      const {
        TagResources: { TagResource = [] },
      } = await services.ListTagResources({
        params: {
          RegionId: window.regionId,
          ResourceType: 'cluster',
          ...resourceIdObj,
        },
      });
      const data = TagResource.filter((tag) => !tag.TagKey.includes('acs:')).map((i) => {
        return { key: i.TagKey, value: i.TagValue };
      });
      return {
        Data: data,
      };
    }
  };

  const columns = [
    {
      title: intl('mse.register.instance'),
      dataIndex: 'resourceId',
      cell: (value, index, record) => {
        return (
          <div>
            <Button text type="primary">
              {record.resourceName}
            </Button>
            <div>{value}</div>
          </div>
        );
      },
    },
    {
      title: intl('mse.tag.change'),
      dataIndex: 'change',
      cell: (value, index, record) => {
        return intl('mse.tag.change_result', {
          add: record.addValues.length,
          remove: record.removeValues.length,
        });
      },
    },
  ];

  const handleClose = () => {
    onClose();
    if (step === 2) {
      onRefresh();
    }
  };

  useEffect(() => {
    if (resourceGroup && resourceGroup.length) {
      const resourceIdObj = {};
      resourceGroup.forEach((item, index) => {
        resourceIdObj[`ResourceId.${index + 1}`] = item.resourceId;
      });
      setResourceIds(resourceIdObj);
    }
  }, [resourceGroup]);

  useEffect(() => {
    if (visible) {
      setStep(1);
    }
  }, [visible]);

  useEffect(() => {
    if (dataSource && dataSource.length) {
      setTagsLength(dataSource.length);
    }
  }, [dataSource]);

  return (
    <Dialog
      title={intl('mse.tag.dialog.title')}
      visible={visible}
      onClose={handleClose}
      onCancel={onCancel}
      style={{ width: 700 }}
      height="600px"
      footer={
        <div>
          <If condition={step === 1 && (addValues.length || removeValues.length)}>
            <div style={{ float: 'left' }}>
              {intl('mse.tag.change')}：{addValues.length} {intl('mse.tag.bind')}，
              {removeValues.length} {intl('mse.tag.unbind')}。
              <Balloon
                triggerType="hover"
                closable={false}
                trigger={<Icon type="prompt" size="small" />}
                align="t"
                style={{ width: 400 }}
              >
                <div>
                  <div style={{ marginBottom: 8 }}>{intl('mse.tag.current')}</div>
                  <div style={{ marginBottom: 12 }}>
                    {tagValues.map((tag) => {
                      return (
                        <ResourceTag
                          keyLabel={tag.key}
                          valueLabel={tag.value}
                          style={{ marginRight: 4 }}
                        />
                      );
                    })}
                  </div>
                  <div style={{ marginBottom: 8 }}> {intl('mse.tag.change')}</div>
                  <div>
                    <div style={{ padding: '4px 0' }}>
                      <span style={{ marginRight: 8 }}>{intl('mse.tag.bind')}</span>
                      {addValues.map((tag) => {
                        return (
                          <ResourceTag
                            keyLabel={tag.key}
                            valueLabel={tag.value}
                            style={{ marginRight: 4 }}
                          />
                        );
                      })}
                    </div>
                    <div style={{ padding: '4px 0' }}>
                      <span style={{ marginRight: 8 }}>{intl('mse.tag.unbind')}</span>
                      {removeValues.map((tag) => {
                        return (
                          <ResourceTag
                            keyLabel={tag.key}
                            valueLabel={tag.value}
                            style={{ marginRight: 4 }}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>
              </Balloon>
            </div>
          </If>
          <div style={{ float: 'right' }}>
            <If condition={step === 1}>
              <Button type="primary" onClick={onSubmit} disabled={disabled} loading={loading}>
                {intl('mse.tag.dialog.save')}
              </Button>
            </If>

            <Button onClick={handleClose}>
              {step === 1 ? intl('mse.tag.dialog.cancel') : intl('mse.tag.dialog.close')}
            </Button>
          </div>
        </div>
      }
    >
      <If condition={step === 1}>
        <p style={{ marginBottom: 8 }}>
          {intl('mse.tag.dialog.tips')}
          <IconButton
            onClick={() => window.open('https://resourcemanager.console.aliyun.com')}
            type="external-link-alt"
          >
            {intl('mse.tag.manage')}
          </IconButton>
        </p>
        <div
          style={{ height: 400, overflowY: 'auto' }}
          className={tagsLength === 20 ? 'TagContainerDel' : ''}
        >
          {/* for fix Tagscontainer limit bug */}
          <TagContainer
            limit={20}
            dataSource={dataSource}
            fetchKeys={fetchKeys}
            onChange={handleChangeTag}
          />
        </div>
      </If>
      <If condition={step === 2}>
        <div>
          <Icon type="success" style={{ color: '#1DC11D', marginRight: 8 }} />
          <span style={{ fontSize: 16, fontWeight: 700 }}>{intl('mse.tag.dialog.success')}</span>
          {/* <p>所选的{resourceGroup.length}个资源编辑标签成功</p> */}
          <p>
            {intl('mse.tag.edit_success', {
              total: resourceGroup.length,
            })}
          </p>
        </div>
        <Table columns={columns} dataSource={resultDataSource} />
      </If>
    </Dialog>
  );
};

export default TagsResourceDialog;
