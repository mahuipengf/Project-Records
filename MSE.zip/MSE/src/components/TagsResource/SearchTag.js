import React, { useState, useEffect } from 'react';
import { Field } from '@ali/cn-design';
import { Button, Form, Select, Overlay } from '@ali/wind';
import { includes } from 'lodash';
import intl from '@ali/wind-intl';

const SearchTag = (props) => {
  const { tagKeys, tagValues, onChangeKey, onConfirm, onClick } = props;
  const [visible, setVisible] = useState(false);
  const btnRef = React.createRef();
  const field = Field.useField();
  const { getValue, getValues, reset } = field;

  const handleClick = () => {
    setVisible(true);
    onClick();
  };

  const handleChangeKeys = (val) => {
    onChangeKey(val);
  };

  const handleReset = () => {
    reset();
  };

  const handleConfirm = () => {
    const data = getValues();
    if (!data.key) return;
    onConfirm(data);
    setVisible(false);
  };

  return (
    <div>
      <Button onClick={handleClick} ref={btnRef}>
        {intl('mse.tag.button')}
      </Button>
      <Overlay
        visible={visible}
        target={() => btnRef.current}
        safeNode={() => btnRef.current}
        onRequestClose={(s, e) => {
          const { target = {} } = e;
          const { className } = target;
          if (includes(className, 'next-overlay-inner') || includes(className, 'next-menu-item')) {
            return false;
          }
          setVisible(false);
        }}
      >
        <div style={{ border: '1px solid #ddd', background: '#fff', padding: 15 }}>
          <Form field={field} inline labelAlign="top">
            <Form.Item label={intl('mse.tag.key')}>
              <Select
                showSearch
                style={{ width: 300 }}
                dataSource={tagKeys}
                onChange={handleChangeKeys}
                name="key"
              />
              <span style={{ marginLeft: 20 }}>:</span>
            </Form.Item>
            <Form.Item label={intl('mse.tag.value')}>
              <Select
                disabled={!getValue('key')}
                showSearch
                style={{ width: 300 }}
                dataSource={tagValues}
                name="value"
              />
            </Form.Item>
          </Form>
          <div style={{ marginTop: 10 }}>
            <Button type="primary" style={{ marginRight: 10 }} onClick={handleConfirm}>
              {intl('mse.common.search')}
            </Button>
            <Button onClick={handleReset}> {intl('mse.common.reset')}</Button>
          </div>
        </div>
      </Overlay>
    </div>
  );
};

export default SearchTag;
