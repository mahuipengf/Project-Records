import React from 'react';
import { Tag } from '@ali/wind';
import Truncate from '@alicloud/console-components-truncate';
import CommonBalloon from 'components/common/CommonBalloon';

const ResourceTag = (props) => {
  const { keyLabel = '', valueLabel = '空值', size = 'small', type = 'normal', style } = props;
  return (
    <Tag size={size} style={style} type={type}>
      <CommonBalloon
        align="t"
        content={
          <span>
            {keyLabel}: {valueLabel}
          </span>
        }
      >
        <Truncate threshold={20} showTooltip={false}>
          {keyLabel}
        </Truncate>
        :
        <Truncate threshold={20} showTooltip={false}>
          {valueLabel}
        </Truncate>
      </CommonBalloon>
    </Tag>
  );
};

export default ResourceTag;
