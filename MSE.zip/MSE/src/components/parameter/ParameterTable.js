import React from 'react';
import ComIf from '../common/ComIf';
import {
  Button,
  Form,
  Grid,
  Radio,
  Loading,
  Table,
  Input,
  NumberPicker,
  Field,
  Message,
  Icon,
} from '@ali/wind';
import intl from '@ali/wind-intl';
import { compareVersion } from 'utils/utils';
import './index.less';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const { Row, Col } = Grid;
const RadioGroup = Radio.Group;
const FormItem = Form.Item;
/**
 * 集群参数设置
 */
const aliyun_lang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
const NACOS_TIP_MAP = {
  ConfigAuthEnabled: {
    name: 'ConfigAuthEnabled',
    value: '',
    desc: intl('mse.register.params.auth_desc'),
    descRender: () => {
      return (
        <div>
          <div>{intl('mse.register.params.auth_desc')}</div>
          <div style={{ color: 'red' }}>
            <b>{intl('mse.register.params.auth_notice')}</b>
          </div>
        </div>
      );
    },
    range: 'true/false',
    supported: 'ConfigAuthSupported',
  },
  NamingAuthEnabled: {
    name: 'NamingAuthEnabled',
    value: '',
    desc: intl('mse.register.params.namingauth_desc'),
    descRender: () => {
      return (
        <div>
          <div>{intl('mse.register.params.namingauth_desc')}</div>
          <div style={{ color: 'red' }}>
            <b>{intl('mse.register.params.namingauth_notice')}</b>
          </div>
        </div>
      );
    },
    range: 'true/false',
    supported: 'NamingAuthSupported',
  },
  EurekaSupported: {
    name: 'EurekaSupported',
    value: '',
    desc: intl('mse.register.params.eurekaSupported_desc'),
    descRender: () => {
      return (
        <div>
          <div>{intl('mse.register.params.eurekaSupported_desc')}</div>
          <div style={{ color: 'red' }}>
            <b>{intl('mse.register.params.eurekaSupported_notice')}</b>
          </div>
        </div>
      );
    },
    range: 'true/false',
    // supported: 'EurekaSupported',
  },
  ConfigSecretEnabled: {
    name: 'ConfigSecretEnabled',
    value: '',
    desc: intl('mse.register.params.secret_desc'),
    range: 'true/false',
    supported: 'ConfigSecretSupported',
  },
  MCPEnabled: {
    name: 'MCPEnabled',
    value: '',
    desc:
      aliyun_lang === 'zh'
        ? intl.html('mse.register.params.mcp_desc')
        : intl('mse.register.params.mcp_desc_intl'),

    range: 'true/false',
    supported: 'MCPSupported',
  },
};

class ParameterTable extends React.Component {
  field = new Field(this, {
    autoUnmount: false,
    onChange: (name, value) => {
      switch (name) {
        case 'initLimit':
          this.field.setValue('initLimit', value);
          break;
        default:
          break;
      }
    },
  });
  constructor(props) {
    super(props);
    this.state = {
      showmore: false,
      isEdit: false,
    };
    this.tickTimeRef = React.createRef();
    this.initLimitRef = React.createRef();
    this.syncLimitRef = React.createRef();
    this.maxClientCnxnsRef = React.createRef();
    this.juteMaxbufferRef = React.createRef();
    this.AppVersion = getParams('AppVersion');
    this.ZK_TIP_MAP = {
      TickTime: {
        name: 'TickTime',
        value: '',
        desc: intl('mse.register.params.tick_desc'),
        range: '2000 ~ 10000',
      },
      InitLimit: {
        name: 'InitLimit',
        value: '',
        desc: intl('mse.register.params.init_desc'),
        range: '10 ~ 30',
      },
      SyncLimit: {
        name: 'SyncLimit',
        value: '',
        desc: intl('mse.register.params.sync_desc'),
        range: '10 ~ 20',
      },
      MaxClientCnxns: {
        name: 'MaxClientCnxns',
        value: '',
        desc: intl('mse.register.params.client_desc'),
        range: '0 ~ 50',
      },
      OpenSuperAcl: {
        name: 'OpenSuperAcl',
        value: '',
        desc: intl('mse.register.params.acl_desc'),
        range: 'true|false',
      },
      UserName: {
        name: intl('mse.register.params.username_name'),
        value: '',
        desc: '',
        range: intl('mse.register.params.username_range'),
      },
      PassWord: {
        name: intl('mse.register.params.password_name'),
        value: '',
        desc: '',
        range: intl('mse.register.params.password_range'),
      },
      JuteMaxbuffer: {
        name: 'Jute.Maxbuffer',
        value: '',
        desc: intl('mse.register.params.jute_desc'),
        range: '0 ~ 1073741823',
      },
      MinSessionTimeout: {
        name: 'MinSessionTimeout',
        value: '-1',
        desc: intl('mse.register.params.min_session_desc'),
        range: '-1 ~ 2147483647',
      },
      MaxSessionTimeout: {
        name: 'MaxSessionTimeout',
        value: '-1',
        desc: intl('mse.register.params.max_session_desc'),
        range: '-1 ~ 2147483647',
      },
      SnapshotCount: {
        name: 'SnapshotCount',
        value: '100000',
        desc: intl('mse.register.params.snapshotcount_desc'),
        range: '50000 ~ 2147483647',
      },
      ExtendedTypesEnable: {
        name: 'ExtendedTypesEnable',
        value: '',
        desc: intl('mse.register.params.extendedTypesEnable_desc'),
        descRender: () => {
          return (
            <div>
              <div>{intl('mse.register.params.extendedTypesEnable_desc')}</div>
              <If condition={compareVersion(this.AppVersion, '3.8.0.4') < 0}>
                <div>
                  <b>{intl('mse.register.params.extendedTypesEnable_message')}</b>
                </div>
              </If>
            </div>
          );
        },
        range: 'true|false',
      },
    };
  }

  renderTitle = () => {
    const { showmore } = this.state;
    const contentTitle = intl('mse.register.params.list');
    const extSpan = <span>{contentTitle}</span>;
    return extSpan;
  };
  showMore = () => {
    this.setState({
      showmore: true,
    });
  };
  showLess = () => {
    this.setState({
      showmore: false,
    });
  };
  toggleMore = () => {
    const { showmore } = this.state;
    this.setState({
      showmore: !showmore,
    });
  };

  /**
   * 编辑
   */
  editValue = () => {
    const { isEdit } = this.state;
    this.field.setValues(this.props.paramsConfig);
    this.setState({
      isEdit: !isEdit,
    });
  };

  /**
   * 放弃编辑
   */
  cancelEdit = () => {
    const { reset } = this.field;
    // 1.关闭编辑
    this.closeEdit();
    // 2.重启初始值
    reset();
  };

  renderRadio(val, userNameValue, passWord, disalbedToottip = '') {
    const dataSource = [
      { label: intl('mse.common.yes'), value: true },
      { label: intl('mse.common.no'), value: false },
    ];
    let isEmptyNameValue = userNameValue.value;
    let isEmptyPassWordValue = passWord.value;
    // const disabled = getParams('MseVersion') === 'mse_dev' && val.id === 'ConfigAuthEnabled';
    return (
      <div>
        <RadioGroup {...val} dataSource={dataSource} disabled={!!disalbedToottip} />
        <If condition={disalbedToottip}>
          {' '}
          <div>{disalbedToottip}</div>{' '}
        </If>
        <ComIf if={this.field.getValue('OpenSuperAcl')}>
          <span>
            {' '}
            <FormItem
              label={intl('mse.register.params.username')}
              validateState={isEmptyNameValue ? '' : 'error'}
              help={isEmptyNameValue ? '' : intl('mse.register.params.username_validate')}
            >
              <Input placeholder="" {...userNameValue} />
            </FormItem>
            <FormItem
              label={intl('mse.register.params.password')}
              validateState={isEmptyPassWordValue ? '' : 'error'}
              help={isEmptyPassWordValue ? '' : intl('mse.register.params.password_validate')}
            >
              <Input placeholder="" name="instanceCount" {...passWord} htmlType="password" />
            </FormItem>
          </span>
        </ComIf>
      </div>
    );
  }

  renderNumPicker(val = {}, limit = {}) {
    let isEmptyValue = val.value;
    return (
      <FormItem
        label=""
        validateState={isEmptyValue !== '' ? '' : 'error'}
        help={
          isEmptyValue !== '' ? '' : intl.html('mse.register.params.validate', { name: val.id })
        }
      >
        <NumberPicker
          placeholder=""
          {...val}
          style={{ width: '100%' }}
          min={limit.min}
          max={limit.max}
        />
      </FormItem>
    );
  }

  renderEditValue = (value, index, record) => {
    const { isEdit } = this.state;
    const { paramsConfig = {} } = this.props;
    let render = null;
    if (!isEdit) {
      render = <span>{value}</span>;
    } else {
      const { init } = this.field;
      let supported = paramsConfig[record.supported];
      let supportTip = '';
      switch (record.name) {
        case 'OpenSuperAcl':
          render = this.renderRadio(init('OpenSuperAcl'), init('UserName'), init('PassWord'));
          break;
        case 'ExtendedTypesEnable':
          if (value === 'N/A') {
            return <span>N/A</span>;
          } else {
            render = this.renderRadio(
              init('ExtendedTypesEnable'),
              init('UserName'),
              init('PassWord')
            );
          }
          break;
        case 'TickTime':
          render = this.renderNumPicker(init('TickTime'), { min: 2000, max: 10000 });
          break;
        case 'InitLimit':
          render = this.renderNumPicker(init('InitLimit'), { min: 10, max: 30 });
          break;
        case 'SyncLimit':
          render = this.renderNumPicker(init('SyncLimit'), { min: 10, max: 20 });
          break;
        case 'MaxClientCnxns':
          render = this.renderNumPicker(init('MaxClientCnxns'), { min: 0, max: 50 });
          break;
        case 'Jute.Maxbuffer':
          render = this.renderNumPicker(init('JuteMaxbuffer'), { min: 0, max: 1073741823 });
          break;
        case 'MinSessionTimeout':
          render = this.renderNumPicker(init('MinSessionTimeout'), { min: -1, max: 2147483647 });
          break;
        case 'MaxSessionTimeout':
          render = this.renderNumPicker(init('MaxSessionTimeout'), { min: -1, max: 2147483647 });
          break;
        case 'SnapshotCount':
          render = this.renderNumPicker(init('SnapshotCount'), { min: 50000, max: 2147483647 });
          break;
        case 'EurekaSupported':
          render = this.renderRadio(
            init(record.name),
            init('UserName'),
            init('PassWord')
            // supportTip
          );
          break;
        case 'NamingAuthEnabled':
        case 'ConfigSecretEnabled':
          if (!supported) {
            supportTip = intl('mse.register.params.upgrade');
            if (getParams('MseVersion') === 'mse_basic') {
              supportTip =
                record.name === 'NamingAuthEnabled'
                  ? intl('mse.register.params.unable_namingauth')
                  : intl('mse.register.params.unable_config');
            }
          }
          render = this.renderRadio(
            init(record.name),
            init('UserName'),
            init('PassWord'),
            supportTip
          );
          break;
        case 'MCPEnabled':
        case 'ConfigAuthEnabled':
          if (!supported) {
            supportTip = intl('mse.register.params.upgrade');
          }
          render = this.renderRadio(
            init(record.name),
            init('UserName'),
            init('PassWord'),
            supportTip
          );
          break;
        default:
          break;
      }
    }
    return render;
  };

  /**
   * 保存并提交
   */
  updateParams = () => {
    let { clusterType = '' } = this.props;
    this.field.validate((errors, values) => {
      // 判断为空则直接返回
      const {
        TickTime,
        InitLimit,
        SyncLimit,
        MaxClientCnxns,
        JuteMaxbuffer,
        OpenSuperAcl,
        UserName,
        PassWord,
        ConfigAuthEnabled,
        NamingAuthEnabled,
        MCPEnabled,
        ConfigSecretEnabled,
        MinSessionTimeout,
        MaxSessionTimeout,
        SnapshotCount,
        ExtendedTypesEnable,
        EurekaSupported,
      } = values;
      if (clusterType === 'ZooKeeper') {
        if (
          !TickTime ||
          !InitLimit ||
          !SyncLimit ||
          MaxClientCnxns === '' ||
          !JuteMaxbuffer ||
          !MinSessionTimeout ||
          !MaxSessionTimeout ||
          !SnapshotCount
        ) {
          return;
        }
        if (MinSessionTimeout > MaxSessionTimeout) {
          Message.error(intl('mse.register.params.update_validate'));
          return;
        }
        if (OpenSuperAcl) {
          if (!UserName || !PassWord) {
            return;
          }
        }
      }
      const clusterId = getParams('clusterId');
      const InstanceId = getParams('InstanceId');
      this.props.openTableLoading();
      request({
        url: 'com.alibaba.MSE.service.configupdate',
        data: {
          clusterId,
          InstanceId,
          tickTime: TickTime,
          initLimit: InitLimit,
          syncLimit: SyncLimit,
          maxClientCnxns: MaxClientCnxns,
          juteMaxbuffer: JuteMaxbuffer,
          openSuperAcl: OpenSuperAcl,
          userName: UserName,
          passWord: PassWord,
          ConfigAuthEnabled,
          NamingAuthEnabled,
          MCPEnabled,
          ConfigSecretEnabled,
          MinSessionTimeout,
          MaxSessionTimeout,
          SnapshotCount: SnapshotCount && SnapshotCount.toString(),
          ExtendedTypesEnable,
          EurekaSupported,
        },
        success: (res) => {
          this.closeEdit();
          this.props.getParameters();
        },
        complete: () => {
          this.props.closeTableLoading();
        },
      });
    });
  };

  /**
   * 关闭编辑
   */
  closeEdit = () => {
    this.setState({
      isEdit: false,
    });
  };

  /**
   * 编辑保存按钮
   */
  renderEditSaveBtn() {
    const { isEdit } = this.state;
    let btn = null;
    if (isEdit) {
      btn = (
        <div>
          <Button onClick={this.updateParams} type="primary">
            {intl('mse.register.params.ok')}
          </Button>
          <Button onClick={this.cancelEdit} style={{ marginLeft: '20px' }}>
            {intl('mse.register.params.cancel')}
          </Button>
        </div>
      );
    } else {
      btn = (
        <Button onClick={this.editValue} type="primary">
          {intl('mse.common.edit')}
        </Button>
      );
    }
    return btn;
  }
  renderDesc = (value, index, record) => {
    if (record.name === 'OpenSuperAcl' && this.field.getValue('OpenSuperAcl')) {
      return (
        <div>
          <div>{intl('mse.register.params.username_hint')}</div>
          <div>{intl('mse.register.params.password_hint')}</div>
          <div>{value}</div>
        </div>
      );
    }
    if (record.descRender) {
      return record.descRender(value, index, record);
    } else {
      return <div>{value}</div>;
    }
  };
  render() {
    const { showmore } = this.state;
    const { paramsConfig = {}, tableVisible = false, clusterType = '' } = this.props;
    const paramsData = [];
    let tipMap = {};
    if (clusterType === 'ZooKeeper') {
      tipMap = this.ZK_TIP_MAP;
    } else if (clusterType === 'Nacos-Ans') {
      if (compareVersion(this.AppVersion, '2.1.2.0') < 0) {
        const { EurekaSupported, ...maps } = NACOS_TIP_MAP;
        tipMap = maps;
      } else {
        tipMap = NACOS_TIP_MAP;
      }
    }
    Object.keys(tipMap).forEach((key) => {
      let obj = tipMap[key];
      const _value = paramsConfig[key];
      if (_value !== undefined) {
        obj.value = _value.toString();
        paramsData.push(obj);
      } else if (!_value && obj.name === 'ExtendedTypesEnable') {
        obj.value = 'N/A';
        paramsData.push(obj);
      }
    });
    return (
      <div className="params-setting page-section">
        <div className="section-header">
          <Icon type="poweroff" size="small" style={{ marginRight: 5, color: '#aaa' }} />
          <span className="title" style={{ marginRight: 20 }}>
            {intl('mse.register.params.title_restart')}
          </span>
          {this.renderEditSaveBtn()}
        </div>

        <div style={{ marginTop: 8 }}>
          <Loading
            visible={tableVisible}
            shape="fusion-reactor"
            style={{ position: 'relative', width: '100%' }}
          >
            <Table dataSource={paramsData} hasBorder={false} style={{ width: '100%' }}>
              <Table.Column title={intl('mse.register.params.name')} dataIndex="name" />
              <Table.Column
                title={intl('mse.register.params.value')}
                dataIndex="value"
                cell={this.renderEditValue}
              />
              <Table.Column
                title={intl('mse.register.params.desc')}
                dataIndex="desc"
                cell={this.renderDesc}
              />
              <Table.Column title={intl('mse.register.params.range')} dataIndex="range" />
            </Table>
          </Loading>
        </div>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default ParameterTable;
