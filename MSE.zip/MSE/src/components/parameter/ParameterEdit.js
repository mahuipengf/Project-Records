import React from 'react';
import ComIf from '../common/ComIf';
import CommonDialog from '../base/CommonDialog';
import { Button, Form, Grid, Radio, Icon, Input, NumberPicker, Field } from '@ali/wind';
import intl from '@ali/wind-intl';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 集群参数编辑修改
 */
const { Row, Col } = Grid;
const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};
const FormItem = Form.Item;
const RadioGroup = Radio.Group;
class ParameterEdit extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showmore: false,
    };
    this.field = new Field(this, {
      autoUnmount: false,
    });
  }

  componentDidMount() { }
  renderTitle = () => {
    const contentTitle = intl('mse.register.params.list');
    const extSpan = <span>{contentTitle}</span>;
    return extSpan;
  };
  showMore = () => {
    this.setState({
      showmore: true,
    });
  };
  showLess = () => {
    this.setState({
      showmore: false,
    });
  };
  openDialog = paramsConfig => {
    this.dialog.open(() => {
      this.field.setValues(paramsConfig);
    });
  };
  closeDialog = () => {
    this.dialog.close();
  };
  renderTitle = () => {
    return <span>{intl('mse.register.params.edit')}</span>;
  };
  toggleMore = () => {
    const { showmore } = this.state;
    this.setState({
      showmore: !showmore,
    });
  };
  updateParams = () => {
    this.field.validate((errors, values) => {
      if (errors) {
        return;
      }
      const clusterId = getParams('clusterId');
      const InstanceId = getParams('InstanceId');
      request({
        url: 'com.alibaba.MSE.service.configupdate',
        data: {
          clusterId,
          InstanceId,
          configType: 'ZK_SERVER_CONF',
          ...values,
        },
        success: res => {
          this.closeDialog();
          this.props.getParameters();
        },
      });
    });
  };
  render() {
    const { showmore } = this.state;

    const { init } = this.field;
    return (
      <div>
        <CommonDialog
          style={{ height: 'auto', width: 560 }}
          childStyle={{ height: 400 }}
          ref={node => (this.dialog = node)}
          title={this.renderTitle()}
          shouldUpdatePosition={false}
          footer={
            <div style={{ textAlign: 'right' }}>
              <Button onClick={this.closeDialog}>{intl('mse.common.cancel')}</Button>
              <Button style={{ marginLeft: 10 }} type="primary" onClick={this.updateParams}>
                {intl('mse.register.params.save')}
              </Button>
            </div>
          }
        >
          <Form {...formItemLayout} field={this.field} labelAlign="top">
            <FormItem label="tickTime:" hasFeedback help="">
              <NumberPicker
                placeholder=""
                {...init('tickTime')}
                style={{ width: '100%' }}
                min={2000}
                max={10000}
              />
            </FormItem>
            <FormItem label="initLimit" hasFeedback requiredTrigger="onBlur">
              <NumberPicker
                placeholder=""
                {...init('initLimit')}
                style={{ width: '100%' }}
                min={10}
                max={30}
              />
            </FormItem>

            <FormItem label="syncLimit:" hasFeedback requiredMessage="">
              <NumberPicker
                placeholder=""
                {...init('syncLimit')}
                style={{ width: '100%' }}
                min={10}
                max={20}
              />
            </FormItem>
            <FormItem label="maxClientCnxns:" hasFeedback requiredMessage="">
              <NumberPicker
                placeholder=""
                {...init('maxClientCnxns')}
                style={{ width: '100%' }}
                min={0}
                max={50}
              />
            </FormItem>
            <div className="toggle-container" onClick={this.toggleMore}>
              <ComIf if={!showmore}>
                <Icon type="angle-double-down" className="toggle-icon" />
              </ComIf>
              <ComIf if={showmore}>
                <Icon type="angle-double-up" className="toggle-icon" />
              </ComIf>
            </div>
            <ComIf if={showmore}>
              <div>
                <FormItem label={intl('mse.register.params.acl')} hasFeedback requiredMessage="">
                  <RadioGroup
                    dataSource={[{ label: intl('mse.common.yes'), value: true }, { label: intl('mse.common.no'), value: false }]}
                    {...init('openSuperAcl')}
                  />
                </FormItem>
                <ComIf if={this.field.getValue('openSuperAcl')}>
                  <span>
                    {' '}
                    <FormItem label={intl('mse.register.params.username')} hasFeedback requiredMessage="">
                      <Input placeholder="" {...init('userName')} />
                    </FormItem>
                    <FormItem label={intl('mse.register.params.password')} hasFeedback requiredMessage="">
                      <Input
                        placeholder=""
                        name="instanceCount"
                        {...init('passWord')}
                        htmlType="password"
                      />
                    </FormItem>
                  </span>
                </ComIf>

                <FormItem label="jute.Maxbuffer:" hasFeedback requiredMessage="">
                  <NumberPicker
                    placeholder=""
                    min={0}
                    max={1073741823}
                    {...init('juteMaxbuffer')}
                    style={{ width: '100%' }}
                  />
                </FormItem>
              </div>
            </ComIf>
          </Form>
        </CommonDialog>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default ParameterEdit;
