import React, { useState } from 'react';
import { Dialog, Form, Field, Radio } from '@ali/cn-design';
import intl from '@ali/wind-intl';
import services from 'utils/services';

const FormItem = Form.Item;
const RadioGroup = Radio.Group;
const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};

const ParameterRunningEdit = (props) => {
  const { visible, record, getParameters, onClose } = props;
  const { name, desc, value, descRender } = record;
  const [loading, setLoading] = useState(false);
  const field = Field.useField();
  const { init } = field;

  const handleEdit = async () => {
    const values = field.getValues();
    const InstanceId = getParams('InstanceId');
    setLoading(true);
    const { Success } = await services.updateRunningConfig({
      customErrorHandle: (err, data, callback) => {
        setLoading(false);
        callback();
      },
      params: { ...values, InstanceId },
    });
    if (Success) {
      getParameters();
      setLoading(false);
      onClose();
    }
  };

  const renderEditValue = () => {
    if (record.value !== 'N/A') {
      switch (name) {
        case 'forcePushEmptyProtectionForAllService':
          return renderRadio(init('EmptyProtect', { initValue: JSON.parse(value) }));
        default:
          break;
      }
    } else {
      return <div style={{ lineHeight: '28px' }}>N/A</div>;
    }
  };

  const renderRadio = (val) => {
    const dataSource = [
      { label: intl('mse.common.yes'), value: true },
      { label: intl('mse.common.no'), value: false },
    ];
    return (
      <RadioGroup
        {...init('EmptyProtect', { initValue: JSON.parse(value) })}
        dataSource={dataSource}
      />
    );
  };

  return (
    <Dialog
      title={intl('mse.register.params.edit')}
      visible={visible}
      onClose={onClose}
      onCancel={onClose}
      style={{ width: 500 }}
      onOk={handleEdit}
      okProps={{ loading, disabled: record.value === 'N/A' }}
    >
      <Form {...formItemLayout} field={field}>
        <FormItem label={intl('mse.register.params.name')}>
          <div style={{ lineHeight: '28px' }}>{name}</div>
        </FormItem>
        <FormItem label={intl('mse.register.params.description')}>{descRender}</FormItem>
        <FormItem label={intl('mse.register.params.value')}>{renderEditValue()}</FormItem>
      </Form>
    </Dialog>
  );
};

export default ParameterRunningEdit;
