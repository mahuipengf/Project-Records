import React, { useState, useEffect } from 'react';
import { Table, Icon } from '@ali/cn-design';
import intl from '@ali/wind-intl';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import ParameterRunningEdit from './ParameterRunningEdit';
import { compareVersion } from 'utils/utils';
import './index.less';

const ParameterRunningTable = (props) => {
  const { paramsConfig, tableVisible, getParameters } = props;
  const [paramsData, setParamsData] = useState([]);
  const [currentRecord, setCurrentRecord] = useState({});
  const [editVisible, setEditVisible] = useState(false);
  const aliyun_lang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';

  const Nacos_Running_Config_Map = {
    emptyProtect: {
      name: 'forcePushEmptyProtectionForAllService',
      value: '',
      desc:
        ' 是否打开推空保护功能，可避免注册中心进行变更或遇到突发情况时，服务消费者可能获取到空的服务提供者实例列表，影响可用性。注意事项请参看推空保护',
      range: 'true/false',
      descRender: (value, index, record) => {
        const appVersion = getParams('AppVersion');
        return (
          <div>
            {aliyun_lang === 'zh'
              ? intl.html('mse.register.params.forcePushEmptyProtectionForAllService_desc')
              : intl.html('mse.register.params.forcePushEmptyProtectionForAllService_desc_intl')}
            <If condition={record?.value === 'N/A' && compareVersion(appVersion, '2.1.0.2') === -1}>
              <div style={{ color: 'red' }}>
                <b>{intl('mse.register.params.forcePushEmptyProtectionForAllService_limit')}</b>
              </div>
            </If>
          </div>
        );
      },
    },
  };

  const renderAction = (value, index, record) => {
    return (
      <Actions>
        <LinkButton onClick={() => onClickEdit(record)}>{intl('mse.common.edit')}</LinkButton>
      </Actions>
    );
  };

  const renderDesc = (value, index, record) => {
    if (record.descRender) {
      return record.descRender(value, index, record);
    } else {
      return <div>{value}</div>;
    }
  };

  const onClickEdit = (record) => {
    setCurrentRecord(record);
    setEditVisible(true);
  };

  useEffect(() => {
    // const configKeys = Object.keys(paramsConfig);
    if (tableVisible) {
      let data = [];
      Object.keys(Nacos_Running_Config_Map).forEach((key) => {
        let obj = Nacos_Running_Config_Map[key];
        const _value = paramsConfig[key];
        if (_value !== undefined) {
          obj.value = _value.toString();
          data.push(obj);
        } else {
          obj.value = 'N/A';
          data.push(obj);
        }
      });
      setParamsData(data);
    }
  }, [paramsConfig]);

  return (
    <div className="page-section">
      <div className="section-header">
        <Icon type="terminal" size="small" style={{ marginRight: 5, color: '#aaa' }} />
        <span className="title">{intl('mse.register.params.title_running')}</span>
      </div>
      <Table
        dataSource={paramsData}
        hasBorder={false}
        style={{ width: '100%' }}
        loading={tableVisible}
      >
        <Table.Column title={intl('mse.register.params.name')} dataIndex="name" />
        <Table.Column title={intl('mse.register.params.value')} dataIndex="value" />
        <Table.Column title={intl('mse.register.params.desc')} dataIndex="desc" cell={renderDesc} />
        <Table.Column title={intl('mse.register.params.range')} dataIndex="range" />
        <Table.Column title={intl('mse.common.operate')} dataIndex="action" cell={renderAction} />
      </Table>

      <ParameterRunningEdit
        visible={editVisible}
        onClose={() => setEditVisible(false)}
        record={currentRecord}
        getParameters={getParameters}
      />
    </div>
  );
};

export default ParameterRunningTable;
