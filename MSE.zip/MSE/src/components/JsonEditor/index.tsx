import 'jsoneditor/dist/jsoneditor.min.css';
import CodeDiff from 'react-code-diff-lite';
import React, { PropsWithChildren, useEffect, useRef, useState } from 'react';
import styles from './index.module.less';
import { Button } from '@alicloud/console-components';

export interface IJSONEditorProps {
  edit?: boolean; // 是否编辑模式，默认为true
  type?: string; // 兼容服务压测功能，默认值为空  stress:服务压测模块引用
  title: string; // 窗口标题
  value: string; // json串
  onOk?: (value: string) => void; // value修改后调取
  noEdit?: boolean;
  propsValue?: string;
  handleJsonMax?: () => void;
  jsonMax?: boolean;
  handleContrast?: () => void;
  contrast?: boolean;
  onValidationError?:any;
}

const JSONEditor = (props: PropsWithChildren<IJSONEditorProps>) => {
  const [ component, setComponent ] = useState<any>(null);
  const [ instance, setInstance ] = useState<any>(null);
  const containerRef = useRef(null);

  // 按需加载
  useEffect(() => {
    (async function() {
      const jEditor = await import(/* webpackChunkName: "jsoneditor" */'jsoneditor'/* webpackPrefetch: true */);
      setComponent(jEditor);
    })();
  }, []);

  useEffect(() => {
    if (containerRef.current && !instance) {
      const inst = new component.default(containerRef.current, {
        navigationBar: false,
        search: false,
        caseSensitive: true,
        mainMenuBar: false,
        onChange: () => {
          const value = inst.getText();
          props.onOk && props.onOk(value);
        },
        onValidationError: props.onValidationError,
      });

      const { value } = props;

      // 设置模式
      try {
        // 尝试解析，是否为标准格式的JSON
        // PS：有些object类型的开关值是不标准的，例如：Map<integer, integer>
        const jsonValue = JSON.parse(value);
        inst.setMode('code');
        inst.set(jsonValue);
      } catch (e) {
        inst.setMode('code');
        inst.setText(value);
      }
      setInstance(inst);
    }
  });

  function getDisplayValue(propsValue?: string) {
    if (propsValue) {
      try {
        const json = JSON.parse(propsValue);
        return JSON.stringify(json, null, 2);
      } catch (e) {
        return propsValue;
      }
    }
    const { value } = props;
    try {
      const json = JSON.parse(value);
      return JSON.stringify(json, null, 2);
    } catch (e) {
      return value;
    }
  }

  if (!component) {
    return null;
  }

  function renderJsonEditor() {
    if (props.noEdit) {
      return (
        <>
          <div className={styles.jsonIcon}>
            <Button type="primary" text onClick={props.handleJsonMax}>{!props.jsonMax ? '最大化' : '最小化'}</Button>
          </div>
          <pre className={styles.container}>
            <code>{getDisplayValue()}</code>
          </pre>
        </>
      );
    }
    if (props.contrast) {
      return <CodeDiff oldStr={getDisplayValue(props.propsValue)} newStr={getDisplayValue()} context={100}/>;
    }
    if (props.edit) {
      return (
        <>
          {props.type !== 'stress' && <div className={styles.jsonIcon}>
            <Button type="primary" text onClick={props.handleJsonMax}>{!props.jsonMax ? '最大化' : '最小化'}</Button>
          </div>}
          <div
            ref={containerRef}
            className={props.type !== 'stress' ? styles.container : styles.containerStress}
            style={{ overflowY: 'visible' }}
          />
        </>
      );
    }

  }

  return (
    <>
      {renderJsonEditor()}
    </>
  );
};

export default JSONEditor;
