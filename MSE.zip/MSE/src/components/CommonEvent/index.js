import './index.css';
import React from 'react';
import { Icon } from '@ali/cn-design';

const CommonEvent = (props) => {
  const { text, onClick, style, type = 'add' } = props;

  return (
    <Icon style={style} className="link-primary link-primary-add" type={type} size="xs" >
      <span onClick={onClick}>{text}</span>
    </Icon>
  );
};

export default CommonEvent;
