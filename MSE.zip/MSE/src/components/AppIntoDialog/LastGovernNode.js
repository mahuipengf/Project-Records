import React, { useEffect, useState, useRef, useMemo } from 'react';
import PropTypes from 'prop-types';
import { TableContainer, Button, Pagination } from '@ali/cn-design';
import services from 'utils/services';
import intl from '@ali/wind-intl';
const contanier = {
  height: 252,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
};

const flexStyle = {
  display: 'flex',
  flexDirection: 'column',
  marginLeft: 30,
};

const titleStyle = {
  fontSize: 16,
  fontWeight: 500,
  height: 36,
  lineHeight: '24px',
  color: '#333',
  marginBottom: 10,
};

const descStyle = {
  color: '#555',
  fontSize: 12,
  height: 18,
  lineHeight: '18px',
};

const MscVersion = new Map()
  .set(0, 'Basic')
  .set(1, 'Profess')
  .set(2, 'business')
  .set(3, 'Beta');

const LastGovernNode = (props) => {
  const { setLoading } = props;
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [mscVersion, setMscVersion] = useState('Basic');

  const OpenVersionDesc = {
    Basic: {
      Title: intl('mse.register.version.basic'),
      Desc: [
        intl('mse.msc.k8s.docs1'),
        intl('mse.msc.k8s.docs2'),
        intl('mse.msc.k8s.docs3'),
      ]
    },
    Profess: {
      Title: intl('mse.register.version.pro'),
      Desc: [
        intl('mse.msc.k8s.docs1'),
        intl('mse.msc.k8s.docs2'),
        intl('mse.msc.k8s.docs3'),
        intl('mse.msc.k8s.docs4'),
      ]
    },
    business: {
      Title: intl('widget.msc.enterprise_version'),
      Desc: [
        intl('mse.msc.k8s.docs1'),
        intl('mse.msc.k8s.docs2'),
        intl('mse.msc.k8s.docs3'),
        intl('mse.msc.k8s.docs4'),
        intl('mse.msc.k8s.docs5'),
      ]
    },
    Beta: {
      Title: intl('mse.register.version.trial'),
      Desc: [
        intl('mse.msc.k8s.docs1'),
        intl('mse.msc.k8s.docs2'),
        intl('mse.msc.k8s.docs3'),
        intl('mse.msc.k8s.docs4'),
        intl('mse.msc.k8s.docs5'),
      ]
    },
  };

  useEffect(() => {
    getUserStatus();
  }, []);

  const getUserStatus = async () => {
    setLoading && setLoading(true);
    const res = await services.getUserStatus({
      customErrorHandle: (err, data, callback) => {
        setLoading && setLoading(false);
        callback();
      },
    });
    const { Version = 0, FreeVersion = 2 } = res;
    // Status    是否开通  1 未开通、2 开通
    // Version   开通版本  0 基础版、 1 专业版、 2 企业版
    // FreeVersion  是否开通试用版  0 未开通、1 开通试用版、 2 试用版到期
    const version = FreeVersion === 2 ? Version : 3;
    const _mscVersion = MscVersion.get(version);
    setMscVersion(_mscVersion);
    setLoading && setLoading(false);
  };

  return (
    <div style={{ marginTop: 16 }}>
      <div style={contanier}>
        <svg width="258px" height="123px" viewBox="0 0 258 123" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
          <defs>
            <linearGradient x1="50%" y1="0%" x2="50%" y2="100%" id="linearGradient-1">
              <stop stopColor="#FFA551" offset="0%" />
              <stop stopColor="#F14D01" offset="100%" />
            </linearGradient>
          </defs>
          <g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
              <g transform="translate(-415.000000, -2662.000000)">
                  <g transform="translate(242.000000, 2473.000000)">
                      <g transform="translate(173.000000, 189.000000)">
                          <g transform="translate(160.000000, 61.500000)">
                              <rect fill="#EBECEC" x="0" y="47.5" width="36" height="14" />
                              <rect fill="#EBECEC" x="77" y="47.5" width="20" height="14" />
                              <rect fill="#F7F7F7" x="77" y="40.5" width="20" height="7" />
                              <rect fill="#F7F7F7" x="0" y="20.5" width="36" height="27" />
                              <rect fill="#EBECEC" x="36" y="20.5" width="41" height="27" />
                              <path d="M56.5,0 C67.8218374,0 77,9.17816263 77,20.5 L36,20.5 L36.0028595,20.1540902 C36.1875326,8.99180885 45.2936916,0 56.5,0 Z" fill="#C3C5C6" />
                              <path d="M56.5,20 C67.8218374,20 77,29.1781626 77,40.5 L36,40.5 L36.0028595,40.1540902 C36.1875326,28.9918088 45.2936916,20 56.5,20 Z" fill="#F7F7F7" transform="translate(56.500000, 30.250000) scale(1, -1) translate(-56.500000, -30.250000) " />
                              <rect fill="#F7F7F7" x="36" y="47.5" width="41" height="7" />
                              <rect fill="#C3C5C6" x="36" y="54.5" width="41" height="7" />
                          </g>
                          <g transform="translate(115.000000, 0.000000)">
                              <rect fill="#FFCDA3" x="0" y="82" width="43" height="41" />
                              <path d="M0,82 L27,55 L27,69 L38,69 L38,82 L0,82 Z" fill="#FFCDA3" />
                              <rect fill="#FFA552" x="20" y="82" width="30" height="14" rx="7" />
                              <rect fill="#FFA552" x="27" y="69" width="30" height="14" rx="7" />
                              <rect fill="#181818" x="34" y="41" width="14" height="50" />
                              <rect fill="url(#linearGradient-1)" x="34" y="0" width="14" height="41" />
                              <polygon fill="#EBECEC" points="48 0 143 0 123 20.5 143 41 48 41" />
                              <g id="GOOD-JOB" transform="translate(50.812000, 16.144000)" fill="#333333" fillRule="nonzero">
                                  <path d="M4.788,9.996 C5.992,9.996 7.21,9.8 7.938,9.562 L7.938,4.242 L4.312,4.242 L4.312,6.02 L5.964,6.02 L5.964,8.12 C5.656,8.19 5.32,8.204 4.928,8.204 C3.01,8.204 2.324,7.574 2.324,4.998 C2.324,2.534 3.164,1.82 5.026,1.82 C5.866,1.82 6.748,1.946 7.476,2.212 L7.476,0.35 C6.874,0.14 5.796,0 4.858,0 C1.848,0 0,1.246 0,4.998 C0,9.058 1.792,9.996 4.788,9.996 Z" />
                                  <path d="M13.912,9.996 C16.754,9.996 18.322,8.96 18.322,4.998 C18.322,1.036 16.754,0 13.912,0 C11.098,0 9.502,1.036 9.502,4.998 C9.502,8.96 11.098,9.996 13.912,9.996 Z M13.912,8.218 C12.134,8.218 11.742,7.378 11.742,4.998 C11.742,2.632 12.134,1.736 13.912,1.736 C15.704,1.736 16.096,2.632 16.096,4.998 C16.096,7.378 15.704,8.218 13.912,8.218 Z" />
                                  <path d="M24.17,9.996 C27.012,9.996 28.58,8.96 28.58,4.998 C28.58,1.036 27.012,0 24.17,0 C21.356,0 19.76,1.036 19.76,4.998 C19.76,8.96 21.356,9.996 24.17,9.996 Z M24.17,8.218 C22.392,8.218 22,7.378 22,4.998 C22,2.632 22.392,1.736 24.17,1.736 C25.962,1.736 26.354,2.632 26.354,4.998 C26.354,7.378 25.962,8.218 24.17,8.218 Z" />
                                  <path d="M33.616,0.14 L30.284,0.14 L30.284,9.856 L33.616,9.856 C36.472,9.856 38.348,8.75 38.348,4.998 C38.348,0.952 36.472,0.14 33.616,0.14 Z M33.504,8.036 L32.412,8.036 L32.412,1.932 L33.504,1.932 C35.254,1.932 36.15,2.506 36.15,4.998 C36.15,7.364 35.296,8.036 33.504,8.036 Z" />
                                  <path d="M45.658,12.488 C47.744,12.488 48.99,11.396 48.99,9.156 L48.99,0.14 L46.876,0.14 L46.876,9.058 C46.876,10.15 46.554,10.808 45.462,10.808 C45.14,10.808 44.832,10.78 44.552,10.738 L44.552,12.418 C44.874,12.46 45.322,12.488 45.658,12.488 Z" />
                                  <path d="M55.034,9.996 C57.876,9.996 59.444,8.96 59.444,4.998 C59.444,1.036 57.876,0 55.034,0 C52.22,0 50.624,1.036 50.624,4.998 C50.624,8.96 52.22,9.996 55.034,9.996 Z M55.034,8.218 C53.256,8.218 52.864,7.378 52.864,4.998 C52.864,2.632 53.256,1.736 55.034,1.736 C56.826,1.736 57.218,2.632 57.218,4.998 C57.218,7.378 56.826,8.218 55.034,8.218 Z" />
                                  <path d="M61.148,9.856 L64.718,9.856 C67.546,9.856 68.344,8.82 68.344,7.056 C68.344,5.838 67.784,5.096 66.636,4.802 L66.636,4.746 C67.686,4.452 68.05,3.766 68.05,2.758 C68.05,1.008 67.266,0.14 64.424,0.14 L61.148,0.14 L61.148,9.856 Z M63.276,4.144 L63.276,1.834 L63.99,1.834 C65.39,1.834 65.95,1.974 65.95,2.982 C65.95,3.948 65.376,4.144 63.99,4.144 L63.276,4.144 Z M63.276,8.148 L63.276,5.684 L64.256,5.684 C65.768,5.684 66.188,6.006 66.188,6.916 C66.188,7.91 65.754,8.148 64.256,8.148 L63.276,8.148 Z" />
                              </g>
                              <rect id="矩形备份-8" fill="#FFCDA3" x="27" y="82" width="41" height="14" rx="7" />
                              <rect id="矩形备份-6" fill="#FFA552" x="20" y="96" width="30" height="14" rx="7" />
                              <rect id="矩形备份-9" fill="#FFCDA3" x="27" y="96" width="34" height="14" rx="7" />
                              <rect id="矩形备份-7" fill="#FFA552" x="20" y="109" width="30" height="14" rx="7" />
                              <rect id="矩形备份-10" fill="#FFCDA3" x="24" y="109" width="30" height="14" rx="7" />
                              <rect id="矩形备份-11" fill="#FFCDA3" x="34" y="69" width="34" height="14" rx="7" />
                              <path d="M27,55 L61,55 C61,62.7319865 54.7319865,69 47,69 L27,69 L27,69 L27,55 Z" fill="#FFCDA3" />
                          </g>
                          <g transform="translate(0.000000, 55.000000)">
                              <rect fill="#F7F7F7" x="21" y="0" width="67" height="41" />
                              <polygon fill="#EBECEC" points="88 0 115 27 115 68 88 41" />
                              <polygon fill="#C3C5C6" points="21 41 88 41 115 68 48 68" />
                              <rect fill="#FFCDA3" x="61" y="61" width="41" height="7" />
                              <circle fill="#181818" cx="27" cy="61" r="7" />
                              <circle fill="#EBECEC" cx="47" cy="61" r="7" />
                              <circle fill="#C3C5C6" cx="7" cy="61" r="7" />
                              <rect fill="#181818" x="27" y="7" width="54" height="27" />
                              <rect fill="#FFA552" x="34" y="21" width="6" height="13" />
                              <rect fill="#FFCDA3" x="47" y="20" width="7" height="14" />
                              <rect fill="#FFCDA3" x="61" y="14" width="7" height="20" />
                          </g>
                      </g>
                  </g>
              </g>
          </g>
        </svg>
        <div style={flexStyle}>
          <span style={titleStyle}>{intl('mse.msc.tips1')}{OpenVersionDesc[mscVersion].Title}{intl('mse.msc.tips2')}</span>
          {
            OpenVersionDesc[mscVersion] && OpenVersionDesc[mscVersion].Desc.map((desc, index) => (
              <span key={index} style={descStyle}>{ desc }</span>
            ))
          }
          <span style={{ ...descStyle, marginTop: 6 }}>
            {intl('mse.msc.tips3')}【
            <span
              style={{ color: '#0070cc', cursor: 'pointer' }}
              onClick={() => window.open('https://help.aliyun.com/document_detail/333528.html', '_blank')}
            >
              {intl('mse.msc.tips4')}
            </span>
            】{intl('mse.msc.tips5')}
          </span>
        </div>
      </div>
    </div>
  );
};

LastGovernNode.propTypes = {
  setLoading: PropTypes.func,
};

export default LastGovernNode;
