import React, { useEffect, useState, useRef, useMemo } from 'react';
import PropTypes from 'prop-types';
import { TableContainer, Button, Pagination } from '@ali/cn-design';
import services from 'utils/services';
import intl from '@ali/wind-intl';

const InsertAppList = (props) => {
  const { setLoading, setStep3Arrow } = props;
  const [refreshIndex, setRefreshIndex] = useState(0);


  const getApplicationList = async (params) => {
    const res = await services.getApplicationList({
      customErrorHandle: (err, data, callback) => {
        callback();
      },
      params: { ...params, Source: 'edasmsc', Region: window.regionId },
    });
    const { Result = [], TotalSize = 0 } = res;
    setStep3Arrow && setStep3Arrow(!Result.length);
    return {
      Data: Result,
      TotalCount: TotalSize,
    };
  };

  const columns = [
    {
      key: 'AppName',
      title: intl('widget.app.name'),
      dataIndex: 'AppName',
    },
    {
      key: 'Source',
      title: intl('mse.msc.app.sub.access.mode'),
      dataIndex: 'Source',
    },
    {
      key: 'InstancesNumber',
      title: intl('widget.app.instance_number'),
      dataIndex: 'InstancesNumber',
    },
  ];

  const search = {
    filterInfo: {
      filters: [
        {
          label: intl('widget.app.name'),
          value: 'AppName',
          placeholder: '',
        }
      ],
      defaultValue: 'AppName',
    },
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    isCanRefresh: true,
  };

  return (
    <div style={{ marginTop: 16 }}>
      <TableContainer
        primaryKey="AppId"
        size="small"
        isUseStorage
        affixActionBar
        search={search}
        columns={columns}
        pagination={{
          type: 'simple',
          hideOnlyOnePage: true,
        }}
        refreshIndex={refreshIndex}
        fetchData={getApplicationList}
        emptyContent={
          <div>
            {intl('mse.msc.restart_app')}
            <span
              style={{ color: '#0070cc' }}
              onClick={() => setRefreshIndex(Date.now())}
            >
              {intl('mse.common.refresh')}
            </span>
            {intl('mse.msc.confirm_access')}
          </div>
        }
      />
    </div>
  );
};

InsertAppList.propTypes = {
  setLoading: PropTypes.func,
  setStep3Arrow: PropTypes.func,
};

export default InsertAppList;
