import React, { useEffect, useState, useRef, useMemo } from 'react';
import PropTypes from 'prop-types';
import { IconButton } from '@ali/cn-design';
import services from 'utils/services';
import intl from '@ali/wind-intl';

const contanier = {
  background: '#f1f1f2',
  borderRadius: 2,
  fontSize: 12,
  height: 32,
  lineHeight: '32px',
  paddingLeft: 12,
};
const overview = {
  border: '1px solid #d1d5d9',
  borderRadius: 2,
  height: 112,
  marginTop: 16,
  display: 'flex',
};
const flexStyle = {
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
};
const unitStyle = {
  width: 120,
  color: '#666',
  fontSize: 14,
};
const countStyle = {
  color: '#333',
  fontSize: 36,
};

const InstallElement = (props) => {
  const { setLoading } = props;
  const [resource, setResource] = useState({});

  useEffect(() => {
    getOverview();
  }, []);

  const getOverview = async () => {
    setLoading && setLoading(true);
    const res = await services.getOverview({
      customErrorHandle: (err, data, callback) => {
        setLoading && setLoading(false);
        callback();
      },
      params: { Source: 'edasmsc', Period: 30, Region: window.regionId },
    });
    const _resource = JSON.parse(res || '{}');
    setResource(_resource);
    setLoading && setLoading(false);
  };

  return (
    <div style={{ marginTop: 16 }}>
      <div style={contanier}>
        <span>{intl('mse.msc.containers.market_install')}</span>
        <IconButton
          type="external-link-alt"
          direction="reverse"
          onClick={() => window.open('https://cs.console.aliyun.com/#/next/app-catalog/ack/incubator/ack-onepilot', '_blank')}
        >
          ack-onepilot {intl('mse.msc.containers.assembly')}
        </IconButton>
      </div>
      <div style={overview}>
        <div style={flexStyle}>
          <span style={unitStyle}>{intl('mse.overview.governance.app')}</span>
          <div style={{ width: 120, marginTop: 10 }}>
            <span style={countStyle}>{resource.ApplicationSize || '0'}</span>
            <span style={{ color: '#555', marginLeft: 8 }}>{intl('mse.msc.containers.individual')}</span>
          </div>
        </div>
        <div style={flexStyle}>
          <span style={unitStyle}>{intl('widget.home.instance')}</span>
          <div style={{ width: 120, marginTop: 10 }}>
            <span style={countStyle}>{resource.InstancesSize || '0'}</span>
            <span style={{ color: '#555', marginLeft: 8 }}>{intl('mse.msc.containers.individual')}</span>
          </div>
        </div>
        <div style={flexStyle}>
          <span style={unitStyle}>{intl('mse.register.monitor.service')}</span>
          <div style={{ width: 120, marginTop: 10 }}>
            <span style={countStyle}>
              {(parseInt(resource.SpringCloudServiceSize || '0', 10) + parseInt(resource.DubboServiceSize || '0', 10))}
            </span>
            <span style={{ color: '#555', marginLeft: 8 }}>{intl('mse.msc.containers.individual')}</span>
          </div>
        </div>
        <div style={flexStyle}>
          <span style={unitStyle}>{intl('widget.service_retry.tag')}</span>
          <div style={{ width: 120, marginTop: 10 }}>
            <span style={countStyle}>{resource.TagSize || '0'}</span>
            <span style={{ color: '#555', marginLeft: 8 }}>{intl('widget.home.item')}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

InstallElement.propTypes = {
  setLoading: PropTypes.func,
};

export default InstallElement;
