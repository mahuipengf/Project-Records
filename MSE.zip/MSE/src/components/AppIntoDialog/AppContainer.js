import React, {
  useEffect,
  useState,
  useRef,
  forwardRef,
  useImperativeHandle,
} from 'react';
import PropTypes from 'prop-types';
import { Step, Loading } from '@ali/cn-design';
import InstallElement from './InstallElement';
import K8sClusterDoc from './K8sClusterDoc';
import InsertAppList from './InsertAppList';
import LastGovernNode from './LastGovernNode';
import intl from '@ali/wind-intl';
const Steps = {
  Install: 0,
  Open: 1,
  Restart: 2,
  Govern: 3,
};
const StepOptions = [
  intl('mse.msc.containers.install_components'),
  intl('mse.msc.containers.enable_service_governance'),
  intl('mse.msc.containers.restart_app'),
  intl('mse.msc.containers.governance_capability'),
];

const AppContainer = (props, ref) => {
  const [loading, setLoading] = useState(false);
  const { activeIndex, setStep2Arrow, setStep3Arrow } = props;

  useImperativeHandle(ref, () => ({
    // test: () => console.log('test'),
  }));

  return (
    <Loading visible={loading} style={{ width: '100%', height: '100%' }}>
      <div>
        <Step
          size="small"
          shape="circle"
          current={activeIndex}
          labelPlacement="hoz"
        >
          {
            StepOptions.map((item, index) => (
              <Step.Item key={index} title={item} />
            ))
          }
        </Step>
        <If condition={activeIndex === Steps.Install}>
          <InstallElement setLoading={setLoading} />
        </If>
        <If condition={activeIndex === Steps.Open}>
          <K8sClusterDoc setLoading={setLoading} setStep2Arrow={setStep2Arrow} />
        </If>
        <If condition={activeIndex === Steps.Restart}>
          <InsertAppList setLoading={setLoading} setStep3Arrow={setStep3Arrow} />
        </If>
        <If condition={activeIndex === Steps.Govern}>
          <LastGovernNode setLoading={setLoading} />
        </If>
      </div>
    </Loading>
  );
};

AppContainer.propTypes = {
  activeIndex: PropTypes.number,
  setStep2Arrow: PropTypes.func,
  setStep3Arrow: PropTypes.func,
};

export default forwardRef(AppContainer);
