import React from 'react';
import { Dialog, Button } from '@ali/cn-design';
import AppContainer from './AppContainer';
import { includes } from 'lodash';
import intl from '@ali/wind-intl';
const Step = {
  Install: 0,
  Open: 1,
  Restart: 2,
  Govern: 3,
};

class AppIntoDialog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
      activeIndex: Step.Install,
      // 当为true时禁用
      step2Arrow: false,
      step3Arrow: false,
    };
  }

  open = callback => {
    this.setState(
      {
        activeIndex: Step.Install,
        visible: true,
      },
      callback
    );
  };

  close = () => {
    this.setState({
      visible: false,
    });
  };

  // 上一步
  nextStep = () => {
    const { activeIndex } = this.state;
    let _activeIndex = Step.Restart;
    switch (activeIndex) {
      case Step.Restart:
        _activeIndex = Step.Open;
        break;
      case Step.Open:
        _activeIndex = Step.Install;
        break;
      default:
        break;
    }
    this.setState({
      activeIndex: _activeIndex
    });
  };

  // 下一步
  prevStep = () => {
    const { activeIndex } = this.state;
    let _activeIndex = Step.Install;
    switch (activeIndex) {
      case Step.Install:
        _activeIndex = Step.Open;
        break;
      case Step.Open:
        _activeIndex = Step.Restart;
        break;
      case Step.Restart:
        _activeIndex = Step.Govern;
        break;
      default:
        break;
    }
    this.setState({
      activeIndex: _activeIndex
    });
  };

  renderFooter = () => {
    const { activeIndex, step2Arrow, step3Arrow } = this.state;
    return (
      <div style={{ textAligin: 'right' }}>
        <If condition={activeIndex === Step.Govern}>
          <Button
            type="primary"
            onClick={this.close}
          >
            {intl('mse.common.ok')}
          </Button>
        </If>
        <If condition={includes([Step.Open, Step.Restart], activeIndex)}>
          <Button
            onClick={this.nextStep}
          >
            {intl('mse.migrate.step.prev')}
          </Button>
        </If>
        <If condition={activeIndex !== Step.Govern}>
          <Button
            type="primary"
            disabled={(activeIndex === Step.Open && step2Arrow) || (activeIndex === Step.Restart && step3Arrow)}
            onClick={this.prevStep}
          >
            {intl('mse.migrate.step.next')}
          </Button>
        </If>
        <Button
          onClick={this.close}
        >
          {intl('mse.tag.dialog.cancel')}
        </Button>
      </div>
    );
  };

  render() {
    const { dialogStyle } = this.props;
    const { visible, activeIndex } = this.state;

    return (
      <Dialog
        title={intl('mse.msc.containers.new_app_access')}
        visible={visible}
        onOk={this.done}
        onCancel={this.close}
        onClose={this.close}
        style={{ width: 960, border: 'none', ...dialogStyle }}
        footer={this.renderFooter()}
        shouldUpdatePosition
      >
        <AppContainer
          ref={node => (this.container = node)}
          activeIndex={activeIndex}
          setStep2Arrow={(enable) => this.setState({ step2Arrow: enable })}
          setStep3Arrow={(enable) => this.setState({ step3Arrow: enable })}
        />
      </Dialog>
    );
  }
}

export default AppIntoDialog;

