import React from 'react';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
class LineChart extends React.Component {
  constructor(props) {
    super(props);
    this.tickCount = props.tickCount || 6;
    this.clearTime = null;
    this.series = {};
  }

  changeSize(size) {
    if (!this.g2Chart) {
      return;
    }
    if ((size.width || size.height) && this.g2Chart.changeSize) {
      this.g2Chart.changeSize(size.width, size.height);
    }
  }
  updateData = (data = []) => {
    const chartData = [];
    data.forEach(item => {
      (Object.keys(this.series) || []).forEach(value => {
        chartData.push({
          time: item.timePoint,
          type: this.series[value],
          value: item[value],
        });
      });
    });
    this.chart.changeData(chartData);
  };

  componentDidMount = () => {
    this.series = this.props.series;
    this.renderChart();
    console.log('000000000000000', this.props.data);
  };
  userUpdate(series) {
    this.series = series;
    this.updateData(this.props.data);
  }
  componentWillReceiveProps(nextProps) {
    if (!_.isEqual(nextProps.series, this.props.series)) {
      this.series = nextProps.series;
    }
  }
  renderChart = () => {
    const { id, padding, tickCount, color, series, formatterY } = this.props;
    let items = [];
    if (color) {
      // eslint-disable-next-line guard-for-in
      for (let key in color) {
        items.push({
          value: series[key],
          marker: {
            symbol: 'circle',
            fill: color[key],
          },
        });
      }
    }
    const G2_3 = window.G2_3;
    this.chart = new G2_3.Chart({
      container: id,
      forceFit: true,
      height: 210,
      padding,
    });
    this.chart.source([]);
    this.chart.scale('time', {
      type: 'time',
      mask: 'YYYY-MM-DD HH:mm',
      tickCount,
      nice: true,
    });
    this.chart.scale('value', {
      formatter: formatterY,
    });
    this.chart.tooltip(true, {
      useHtml: true,
      'g2-tooltip': {
        borderRadius: '4px',
        backgroundColor: '#9ca1b0',
        padding: 0,
        color: '#fff',
      },
      'g2-tooltip-title': {
        margin: 0,
        padding: '0 5px',
        lineHeight: '20px',
        fontSize: '12px',
        background: '#777d91',
        borderRadius: '4px 4px 0 0',
      },
      'g2-tooltip-list': {
        margin: 0,
        padding: '5px',
        listStyle: 'none',
      },
    });
    this.chart.legend('type', {
      custom: !!color,
      items,
      marker: 'circle',
      position: 'bottom-center',
    });
    this.chart.tooltip();
    this.chart
      .line()
      .position('time*value')
      .shape('spline')
      .color('type', ['#0070CC', '#00A263', '#98CF24', '#F0AD4E', '#FF730E', '#D9534F']);
    this.chart.render();
  };
  render() {
    const divStyle = {
      color: '#515151',
      backgroundColor: '#FFFFFF',
      marginBottom: 10,
      paddingTop: 10,
      border: '1px solid #E9E9E9',
      boxShadow: '2px 2px 1px rgba(191, 200, 209, 0.3)',
    };
    const { chartTitle, tip, id, margin } = this.props;
    return (
      <div style={divStyle}>
        <p style={{ fontSize: '14px', lineHeight: '20px', paddingLeft: 10 }}>{chartTitle}</p>
        <div id={id} style={{ margin }} />
        <p style={{ textAlign: 'center', color: '#73777a' }}>{tip}</p>
      </div>
    );
  }
}
LineChart.defaultProps = {
  data: [],
  tickCount: 8,
  margin: 0,
  padding: [20, 50, 70],
};

/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default LineChart;
