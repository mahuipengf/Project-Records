import React from 'react';
import PropTypes from 'prop-types';
import StatusIndicator from '@alicloud/console-components-status-indicator';
import { find } from 'lodash';
import { Empty } from '@ali/cn-design';

const Status = ({ value, dataSource = [] }) => {
  const item = find(dataSource, { value });
  return (
    <React.Fragment>
      <If condition={item}>
        <StatusIndicator type={item.type} shape="icon" style={{ whiteSpace: 'pre' }}>
          {item.label}
        </StatusIndicator>
      </If>
      <If condition={!item}>
        <Empty value={value}>{value}</Empty>
      </If>
    </React.Fragment>
  );
};

Status.propTypes = {
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number, PropTypes.bool]),
  dataSource: PropTypes.arrayOf(PropTypes.object),
};

export default Status;
