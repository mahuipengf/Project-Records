import React from 'react';
import Status from './index';
import intl from '@ali/wind-intl';

interface IProps {
  value?: boolean;
}
const CommonStatus = (props: IProps) => {
  const { value } = props;
  const dataSource = [
    {
      value: false,
      type: 'disabled',
      label: intl('widget.common.closed'),
    },
    {
      value: true,
      type: 'success',
      label: intl('widget.common.opened'),
    },
  ];

  return <Status value={value} dataSource={dataSource} />;
};

export default CommonStatus;
