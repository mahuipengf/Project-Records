import React from 'react';
import Status from './index';
import intl from '@ali/wind-intl';

interface IProps {
  value?: any;
}
const CommonStatusLine = (props: IProps) => {
  const { value } = props;
  const dataSource = [
    {
      value: 0,
      type: 'disabled',
      label: intl('widget.common.offline'),
    },
    {
      value: 1,
      type: 'success',
      label: intl('widget.common.launch'),
    },
    {
      value: 2,
      type: 'loading',
      label: intl('widget.common.offline.loading'),
    },
    {
      value: 3,
      type: 'loading',
      label: intl('widget.common.launch.loading'),
    },
  ];

  return <Status value={value} dataSource={dataSource} />;
};


export default CommonStatusLine;
