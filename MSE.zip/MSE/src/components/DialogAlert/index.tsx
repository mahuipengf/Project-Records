import { Dialog } from '@ali/cn-design';
import intl from '@ali/wind-intl';

const DialogAlert = (props: any) => Dialog.alert({
  ...props,
  okProps: { children: intl('widget.common.ok') },
  cancelProps: { children: intl('widget.common.cancel') },
});
export default DialogAlert;
