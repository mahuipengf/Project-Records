import React from 'react';
import CommonLoading from '../common/CommonLoading';
import EurekaServiceDetail from './EurekaServiceDetail';
import CommonDialog from '../base/CommonDialog';
import CommonBalloon from '../common/CommonBalloon';
import { Button, Icon, Table, Pagination } from '@ali/wind';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * eureka服务列表
 */

class EurekaService extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 1,
      total: 0,
      pageSize: 20,
      ipList: [],
      serviceTitle: '',
    };
  }
  componentDidMount = () => {
    this.getEruekaService();
  };
  getEruekaService = () => {
    const { pageSize, current } = this.state;
    const ClusterId = getParams('ClusterId');
    const InstanceId = getParams('InstanceId');
    window.request({
      url: 'com.alibaba.MSE.service.ListEurekaServices',
      data: {
        InstanceId,
        ClusterId,
        PageNum: current,
        PageSize: pageSize,
      },
      beforeSend: () => {
        this.loading && this.loading.openLoading();
      },
      success: res => {
        if (res.code === '200' && res.data) {
          const { Data, PageNumber, TotalCount } = res.data;
          this.setState({
            dataSource: Data,
            pageNumber: PageNumber,
            total: TotalCount,
          });
        }
      },
      complete: () => {
        this.loading && this.loading.closeLoading();
      },
    });
  };
  changePage = current => {
    this.setState(
      {
        current,
      },
      () => {
        this.getEruekaService();
      }
    );
  };

  getEurekaInstances = ServiceName => {
    const ClusterId = getParams('ClusterId');
    const InstanceId = getParams('InstanceId');
    window.request({
      url: 'com.alibaba.MSE.service.ListEurekaInstances',
      data: {
        InstanceId,
        ClusterId,
        PageNum: 1,
        PageSize: 20,
        ServiceName,
      },
      beforeSend: () => { },
      success: res => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          this.setState(
            {
              ipList: Data,
              serviceTitle: `${ServiceName}详情`,
            },
            () => {
              this.dialog.open();
            }
          );
        }
      },
      complete: () => { },
    });
  };
  renderOption = value => {
    return (
      <a href="javascript:;" onClick={() => this.getEurekaInstances(value)}>
        详情
      </a>
    );
  };
  renderFooter = () => {
    return (
      <div>
        <Button onClick={() => this.dialog.close()}>{intl('mse.tag.dialog.close')}</Button>
      </div>
    );
  };
  renderInstancesId = value => {
    let show = 'N/A';
    if (value.length > 0) {
      show = value.map(item => {
        return <div>{item}</div>;
      });
    }
    return <div>{show}</div>;
  };
  render() {
    const { dataSource = [], total, pageSize, ipList } = this.state;
    const { current, serviceTitle } = this.state;

    return (
      <div style={{ width: '100%', position: 'relative' }}>
        <CommonLoading ref={node => (this.loading = node)}>
          <Table dataSource={dataSource} hasBorder={false}>
            <Table.Column title="服务名" dataIndex="Name" />
            {/* <Table.Column title="实例列表" dataIndex="InstancesId" cell={this.renderInstancesId} /> */}
            <Table.Column
              title={
                <CommonBalloon content="健康实例数/总实例数">
                  提供者数量{' '}
                  <Icon
                    className="commonbuy-tip"
                    type="help"
                    size="small"
                    style={{
                      marginLeft: 5,
                      color: '#888888',
                    }}
                  />
                </CommonBalloon>
              }
              dataIndex="UpStatus"
            />
            <Table.Column title={intl('ahas_sentinel.systemGuard.flowControl.operating')} cell={this.renderOption} dataIndex="Name" />
          </Table>
          <div style={{ textAlign: 'right', marginTop: 8 }}>
            <Pagination
              current={current}
              pageSize={pageSize}
              total={total}
              onChange={this.changePage}
            />
          </div>
        </CommonLoading>
        <CommonDialog
          title={serviceTitle}
          style={{ width: 870 }}
          childStyle={{ height: 352, overflow: 'hidden' }}
          footer={this.renderFooter()}
          ref={node => (this.dialog = node)}
          shouldUpdatePosition
        >
          <EurekaServiceDetail ipList={ipList} />
        </CommonDialog>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default EurekaService;
