import React from 'react';
import ComIf from '../common/ComIf';
import { Table } from '@ali/wind';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * eureka服务列表详情
 */

class EurekaServiceDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  renderStatus = value => {
    return (
      <span>
        <ComIf if={value === 'UP'}>
          <span className="circle-status green" />
        </ComIf>
        <ComIf if={value !== 'UP'}>
          <span className="circle-status red" />
        </ComIf>
      </span>
    );
  };
  renderIpPort = (value, index, record) => {
    const { IpAddr, Port } = record;
    return (
      <span>
        {IpAddr}:{Port}
      </span>
    );
  };
  render() {
    const { ipList = [] } = this.props;
    return (
      <div style={{ width: '100%', position: 'relative' }} className="cluster-list">
        <Table dataSource={ipList} hasBorder={false} primaryKey={'InstanceId'} maxBodyHeight={300} fixedHeader>
          <Table.Column title="Ip:Port" dataIndex="IpAddr" cell={this.renderIpPort} />
          <Table.Column title="在线状态" dataIndex="Status" cell={this.renderStatus} />
          <Table.Column title="实例心跳间隔（s）" dataIndex="RenewalIntervalInSecs" />
          <Table.Column
            title="实例修改时间"
            dataIndex="LastDirtyTimestamp"
            cell={value => {
              return moment(value).format('YYYY-MM-DD HH:mm:ss');
            }}
          />
          <Table.Column
            title="最近一次的心跳时间"
            dataIndex="LastUpdatedTimestamp"
            cell={value => <span>{window.moment(value).format('YYYY-MM-DD HH:mm:ss')}</span>}
          />
        </Table>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default EurekaServiceDetail;
