import React, { Fragment } from 'react';

const If = (props: any) => {
  const { condition, children } = props;
  return (
    <Fragment>
      {
        condition && children
      }
    </Fragment>
  );
};
export default If;
