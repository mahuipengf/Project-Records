import React from 'react';
import PropTypes from 'prop-types';
import { withRouter } from 'dva/router';
import { Icon } from '@ali/wind';

const IconBack = ({ back, text, history, onClick }) => {
  return (
    <div style={{ display: 'flex', alignItems: 'center', height: 32 }}>
      <If condition={back}>
        <Icon style={{ cursor: 'pointer' }}
          type="arrow-alt-left" onClick={() => onClick ? onClick() : history.goBack()} />
      </If>
      <div style={{ fontSize: 28, marginLeft: 8, height: 28, lineHeight: '28px' }}>
        {text}
      </div>
    </div>
  );
};

IconBack.propTypes = {
  back: PropTypes.bool,
  text: PropTypes.string,
  history: PropTypes.shape(),
};

export default withRouter(IconBack);
