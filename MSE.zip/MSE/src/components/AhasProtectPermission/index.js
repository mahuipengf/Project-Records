import React, { useState, useEffect } from 'react';
import NoPermission from 'containers/AccountPermission/NoPermission';
import { Button } from '@alicloud/console-components';
import { useStateStore } from '../../store';
import { get, isEmpty } from 'lodash';
import intl from '@ali/wind-intl';

const Loading = () => {
  const [show, setShow] = useState(0);
  useEffect(() => {
    setTimeout(() => {
      setShow(true);
    }, 300);
  });
  return show ? 'Loading' : '';
};

const AhasPermissionOpen = ({ tag = '', goHistory = '' }) => {
  const state = useStateStore();
  const Version = get(state, 'MscAccount.Version');
  const Status = get(state, 'MscAccount.Status');
  const UserId = get(state, 'MscAccount.UserId');
  let openEnterpriseHref = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn';
  let upgradeEnterpriseHref = `https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn&orderType=UPGRADE&instanceId=synthetic_post_${UserId}`;
  let rechargeHref = 'https://usercenter2.aliyun.com/finance/fund-management/recharge';

  if (isEmpty(state)) {
    return <Loading />;
  }
  return (
    <div style={{ display: 'flex', justifyContent: 'center', margin: 100 }}>
      <NoPermission style={{ width: 120, height: 120, marginRight: 16 }} />
      <div>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 510, fontSize: 14 }}>
            {/* ahas 开通operate */}
            <If condition={Status === 1}>
              <If condition={!Version}>
                <If condition={tag === 'config'}>
                  {intl.html('mse.msc.switch.permission.open', { openEnterpriseHref })}
                </If>
                <If condition={tag === 'protect'}>
                  {intl.html('mse.msc.ahas.permission.open', { openEnterpriseHref })}
                </If>
                <If condition={tag === 'flow_protect'}>
                  {intl.html('mse.msc.ahas.flow.permission.open', { openEnterpriseHref })}
                </If>
                <If condition={tag === 'flow_protect_appList'}>
                  {intl.html('mse.msc.ahas.flow.permission.open', { openEnterpriseHref })}
                </If>
              </If>
            </If>
            {/* ahas 升级operate */}
            <If condition={Status === 2}>
              <If condition={!Version}>
                <If condition={tag === 'protect'}>
                  {intl.html('mse.msc.ahas.permission.upgrade_base', { upgradeEnterpriseHref })}
                </If>
                {/* <If condition={tag === 'config'}>
                  {intl.html('mse.msc.switch.permission.upgrade_base', { upgradeEnterpriseHref })}
                </If> */}
                <If condition={tag === 'flow_protect'}>
                  {intl.html('mse.msc.ahas.flow.permission.upgrade_base', { upgradeEnterpriseHref })}
                  <If condition={goHistory === 'appList'}>
                    <div style={{ borderRadius: '8px', marginTop: '8px', color: '#0064C8', display: 'inline-block', marginLeft: '-160px', cursor: 'pointer' }} onClick={() => { hashHistory.push('/msc/appList?base=list'); }}>{intl('mse.msc.ahas.goto.app.list')}</div>
                  </If>
                </If>
                <If condition={tag === 'flow_protect_appList'}>
                  {intl.html('mse.msc.ahas.flow.permission.upgrade_base', { upgradeEnterpriseHref })}
                  <If condition={goHistory === 'appList'}>
                    <div style={{ borderRadius: '8px', marginTop: '8px', color: '#0064C8', display: 'inline-block', marginLeft: '-160px', cursor: 'pointer' }} onClick={() => { hashHistory.push('/msc/appList?base=list'); }}>{intl('mse.msc.ahas.goto.app.list')}</div>
                  </If>
                </If>
              </If>
              <If condition={Version === 1}>
                <If condition={tag === 'protect'}>
                  {intl.html('mse.msc.ahas.permission.upgrade_professional', { upgradeEnterpriseHref })}
                </If>
                <If condition={tag === 'flow_protect'}>
                  {intl.html('mse.msc.ahas.flow.permission.upgrade_professional', { upgradeEnterpriseHref })}
                  <If condition={goHistory === 'appList'}>
                    <div style={{ borderRadius: '8px', marginTop: '8px', color: '#0064C8', display: 'inline-block', marginLeft: '-160px', cursor: 'pointer' }} onClick={() => { hashHistory.push('/msc/appList?base=list'); }}>{intl('mse.msc.ahas.goto.app.list')}</div>
                  </If>
                </If>
              </If>
            </If>
            {/* 欠费停机 */}
            <If condition={Status === 3}>
              <div style={{ marginTop: -8 }}>
                <h5 style={{ margin: '16px 0 0', color: '000', fontWeight: 'bold' }}>{intl('mse.account.promission.arrears')}</h5>
                <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500, fontSize: '12px' }}>{intl.html('widget.msc.account_status_3', { rechargeHref })}</div>
                <Button type="primary" style={{ padding: 0 }}>{intl.html('widget.msc.open_again', { rechargeHref })}</Button>
              </div>
            </If>
          </div>
        </div>
    </div>
  );
};

export default AhasPermissionOpen;
