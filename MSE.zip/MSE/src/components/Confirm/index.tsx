import intl from '@ali/wind-intl';
import { confirm } from '@ali/cn-design';

const myconfirm = (props: any) => {
  return confirm({
    okProps: { children: intl('widget.common.ok') },
    cancelProps: { children: intl('widget.common.cancel') },
    ...props,
  });
};

export default myconfirm;
