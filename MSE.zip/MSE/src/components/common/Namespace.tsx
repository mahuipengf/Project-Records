import React, { useEffect, useState } from 'react';
import { Select, Icon, Balloon, Message } from '@ali/cn-design';
import './Namespace.less';
import { useDispatch } from '@ali/sre-utils-dva';
import { isEmpty, map } from 'lodash';
import { queryEncode, queryDecodeHash } from 'utils/queryString_ahas';
import { lowerFirstData } from 'utils/transfer-data';
import DialogAlert from 'components/DialogAlert';
import intl from '@ali/wind-intl';

const parseUrl = (urlParams) => {
  let obj = {};
  let paramsArr = (urlParams && urlParams.split('&')) || [];
  for (let i = 0, len = paramsArr.length; i < len; i++) {
    let arr = paramsArr[i].split('=');
    obj[arr[0]] = arr[1];
  }
  paramsArr.forEach((t) => {
    let arr = t.split('=');
    obj[arr[0]] = arr[1];
  });
  return obj;
};
const { getParams, setParams } = window;

const Namespace = (props) => {
  const { disabled = false } = props;
  const dispatch = useDispatch();
  const region = window.regionId;
  const MscNamespace = localStorage.getItem('MscNamespace') || '';
  const urlObj: any = parseUrl(MscNamespace);
  const ns = MscNamespace ? urlObj.ns : getParams('ns');

  const [dataSource, setDataSource] = useState([]);
  const [curNamespace, setCurNamespace] = useState(ns || 'default');
  useEffect(() => {
    fetchQueryNamespace();
  }, []);
  useEffect(() => {
    fetchQueryNamespace();
  }, [getParams('ns')]);
  const fetchQueryNamespace = async () => {
    const { Data = [] } = await dispatch.flowAppModel.QueryNamespace({
      Region: region,
    });
    if (Data && Data.length > 0) {
      const lowData = lowerFirstData(Data);
      const newData =
        lowData &&
        lowData.length > 0 &&
        lowData.map((item) => {
          return {
            ...item,
            label: (
              <div>
                <Balloon align="l" trigger={item.namespace} closable={false}>
                  {item.namespace}
                </Balloon>
                {item.namespace !== 'default' && item.namespace !== curNamespace ? (
                  <Icon
                    type={'close'}
                    size={'xs'}
                    className={'container-icon'}
                    onClick={(e) => {
                      e.stopPropagation();
                      e.nativeEvent.stopImmediatePropagation();
                      handleToggleNamespaceManageDialog(item.namespace);
                    }}
                  />
                ) : (
                  ''
                )}
              </div>
            ),
            value: item.namespace,
          };
        });
      await setDataSource(newData);
      if (
        newData &&
        newData.some((item) => {
          return item.namespace === ns;
        })
      ) {
        (await ns) && setCurNamespace(ns);
        setParams('ns', curNamespace);
      } else {
        setCurNamespace('default');
        setParams('ns', 'default');
      }
    } else {
      setDataSource([{ namespace: 'default', label: 'default', value: 'default' }]);
      setCurNamespace('default');
      setParams('ns', 'default');
    }
  };
  const handleChange = async (val) => {
    const { search } = window.location;
    const urlParams = queryDecodeHash();
    delete urlParams.ns;
    urlParams.ns = val;
    const Params = queryEncode(urlParams);
    const hash = window.location.href.split('?');
    localStorage.setItem('MscNamespace', Params);
    setCurNamespace(val);
    if (search) {
      const [route, routeSearch] = hash;
      let href = `${route}?${routeSearch}?${Params}`;
      window.location.href = href;
    } else {
      const [route] = hash;
      let href = `${route}?${Params}`;
      window.location.href = href;
    }
  };

  // 删除或新增环境
  async function handleToggleNamespaceManageDialog(nameSpace: string) {
    const { Result = [] } = await dispatch.flowAppModel.getSystemGuardApp({
      PageNumber: 1,
      pageSize: 6,
      RegionId: region,
      Region: region,
      Namespace: nameSpace,
    });
    DialogAlert({
      title: intl('widget.common.delete'),
      content: isEmpty(Result)
        ? intl('mse.msc.namespace.delete.confirm')
        : intl('mse.msc.namespace.current.exist.application.msg'),
      onOk: async () => {
        if (isEmpty(Result)) {
          await dispatch.flowAppModel
            .DeleteNamespace({
              Region: region,
              Name: nameSpace,
            })
            .then((res) => {
              Message.success({
                title: intl('mse.common.delete_success'),
                duration: 3000,
              });
              fetchQueryNamespace();
            })
            .catch((err) => {
              Message.error({
                title: intl('widget.common.delete_failure'),
                duration: 3000,
              });
            });
        }
      },
      footerActions: ['ok', 'cancel'],
    });
  }

  return (
    <span className={'mse_namespace'}>
      <Select
        placeholder={curNamespace}
        dataSource={dataSource}
        value={curNamespace}
        onChange={handleChange}
        disabled={disabled}
        popupClassName="namespace"
        showSearch
        // itemRender={(obj) => { // 添加环境一期暂时不涉及
        //   const { label, value } = obj;
        //   console.log('obj', obj);
        //   if (value === 'addEnvironment') {
        //     return <div onClick={(e) => {
        //       e.stopPropagation();
        //       e.nativeEvent.stopImmediatePropagation();
        //       handleAddEnvironment();
        //   }}>{label}</div>;
        //   }
        //   if (value === 'default') {
        //     return <div>默认</div>
        //   }
        //   return <div>{label}</div>;
        // }}
      />
      <Balloon
        trigger={
          <Icon type="help" size="xs" style={{ marginLeft: 8, color: 'rgb(119, 119, 119)' }} />
        }
        closable={false}
      >
        {intl('mse.msc.namespace.tips')}
      </Balloon>
    </span>
  );
};

export default Namespace;
