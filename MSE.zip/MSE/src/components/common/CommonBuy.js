import React from 'react';
import ComIf from './ComIf';
import { Form, Balloon, Icon, Select, Input, Message, Field } from '@ali/wind';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 购买
 */

const FormItem = Form.Item;
const REGION_LIST = window.regionList || [];
const VERSION_LIST = [
  {
    name: '3.4.14 (推荐)',
    value: '3.4.14',
  },
];
const ENGINE_LIST = [
  {
    name: 'ZooKeeper',
    value: 'zookeeper',
  },
];
const NET_LIST = [
  {
    name: '公网实例',
    value: 'pubnet',
  },
  {
    name: '专有网络',
    value: 'privatenet',
  },
];

class CommonBuy extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      activeRegion: window.regionId || 'cn-hangzhou',
      activeVersion: '3.4.14',
      activeEngine: 'zookeeper',
      activeNet: 'pubnet',
      activePrivateNet: '',
      activeSwitch: '',
      privateNetList: [],
      vSwitchIds: [],
      moreEngineInput: false,
      moreEngines: [
        {
          name: 'Nacos',
          value: 'NACOS',
          like: false,
        },
        {
          name: 'Eureka',
          value: 'EUREKA',
          like: false,
        },
        {
          name: 'Consul',
          value: 'CONSUL',
          like: false,
        },
        {
          name: 'Apollo',
          value: 'APOLLP',
          like: false,
        },
      ],
    };
    this.field = new Field(this);
    this.vpcListMap = [];
  }
  componentDidMount = () => {
    this.getPrivateNetList();
    this.field.setValue('instanceCount', 3);
    this.field.setValue('cpuext', '1-2-60');
  };

  openLoading = () => {
    this.setState({
      loading: true,
    });
  };
  closeLoading = () => {
    this.setState({
      loading: false,
    });
  };
  choosRegion = activeRegion => {
    this.setState({
      activeRegion,
    });
    window.publicRegion.changeRegionBarRegionId(activeRegion); //切换头部的reigonId,并增加主regionId;
  };
  choosedEngine = activeEngine => {
    this.setState({
      activeEngine,
    });
  };
  choosedVersion = activeVersion => {
    this.setState({
      activeVersion,
    });
  };
  choosedNet = activeNet => {
    this.setState({
      activeNet,
    });
  };
  activePrivateSwitch = activeSwitch => {
    this.setState({
      activeSwitch,
    });
  };
  activePrivateNet = activePrivateNet => {
    let vSwitchIds = [];
    const vpcItem = this.vpcListMap[activePrivateNet];
    if (vpcItem) {
      const _vSwitchIds = vpcItem.VSwitchIds || {};
      vSwitchIds = _vSwitchIds.VSwitchId || [];
    }
    this.setState({
      activePrivateNet,
      activeSwitch: '',
      vSwitchIds: vSwitchIds.map(value => {
        return {
          label: value,
          value,
        };
      }),
    });
  };
  getPrivateNetList = () => {
    request({
      url: 'com.alibaba.MSE.service.describevpcs',
      data: {
        RegionId: window.regionId,
        PageNumber: 1,
      },
      product: 'vpc',
      special: true,
      success: res => {
        const { Vpcs = {} } = res.data;
        const vpc = Vpcs.Vpc || [];
        const privateNetList = vpc.map(item => {
          this.vpcListMap[item.VpcId] = item;
          return {
            label: item.VpcName,
            value: item.VpcId,
          };
        });

        this.setState({
          privateNetList,
        });
      },
    });
  };
  getFormValue = () => {
    const { activeEngine, activeRegion, activeVersion } = this.state;
    return { engine: activeEngine, region: activeRegion, version: activeVersion };
  };
  likeEngine = id => {
    const { moreEngines } = this.state;
    moreEngines.forEach(item => {
      if (item.value === id) {
        item.like = !item.like;
      }
    });
    this.setState({
      moreEngines,
    });
  };
  validate = () => {
    this.field.validate();
    const errors = this.field.getErrors();
    let validateOk = true;
    Object.keys(errors).forEach(key => {
      if (errors[key]) {
        validateOk = false;
      }
    });
    const { activeNet, activePrivateNet } = this.state;
    if (activeNet === 'privatenet' && !activePrivateNet) {
      validateOk = false;
      Message.show({
        type: 'error',
        title: '错误',
        content: '请选择专有网络类型',
        hasMask: false,
      });
    }
    return validateOk;
  };
  getValues = () => {
    const obj = this.field.getValues();
    const {
      activeEngine,
      activeRegion,
      activeVersion,
      activeNet,
      activePrivateNet,
      activeSwitch,
      moreEngines,
      moreEngineInput,
    } = this.state;
    const cpuext = obj.cpuext;
    const Cpu = cpuext.split('-')[0];
    const MemoryCapacity = cpuext.split('-')[1];
    const DiskCapacity = cpuext.split('-')[2];
    const NetType = activeNet;
    let VpcId = activePrivateNet;
    delete obj.cpuext;
    const likeEngines = [];
    moreEngines.forEach(item => {
      if (item.like) {
        likeEngines.push(item.value);
      }
    });
    if (moreEngineInput && this.customerEngine) {
      //如果打开了其他，并且用户输入了引擎
      likeEngines.push(this.customerEngine);
    }
    return Object.assign({}, obj, {
      Cpu,
      MemoryCapacity,
      DiskCapacity,
      ClusterType: activeEngine,
      AppVersion: activeVersion,
      Region: activeRegion,
      VpcId,
      VSwitchId: activeSwitch,
      NetType,
      LikeEngines: likeEngines,
      DiskType: 'alicloud-disk-common',
    });
  };
  setValues = values => {
    this.field.setValues(values);
  };
  toggleMoreInput = () => {
    const { moreEngineInput } = this.state;
    if (!moreEngineInput) {
      this.customerEngine = '';
    }
    this.setState({
      moreEngineInput: !moreEngineInput,
    });
  };
  setCustomerEngine = value => {
    this.customerEngine = value;
  };
  render() {
    const {
      activeEngine,
      activeRegion,
      activeVersion,
      moreEngines,
      activeNet,
      privateNetList,
      activePrivateNet,
      vSwitchIds,
      activeSwitch,
      moreEngineInput,
    } = this.state;
    return (
      <div>
        <Form field={this.field}>
          <div className="commonbuy-config-container">
            <div className="commonbuy-container" style={{ paddingTop: 10, paddingBottom: 10 }}>
              <div className="commonbuy-title-show" style={{ width: 228, top: 105, left: -125 }}>
                基本配置
              </div>
              <div className="commonbuy-label">地域：</div>
              <div className="commonbuy-content">
                <ul className="common-list">
                  {REGION_LIST.map(item => (
                    <li
                      className={
                        item.regionId === activeRegion ? 'common-item active' : 'common-item'
                      }
                      key={item.regionId}
                      id={item.regionId}
                      onClick={() => this.choosRegion(item.regionId)}
                    >
                      {item.regionName}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="commonbuy-container" style={{ paddingTop: 10, paddingBottom: 20 }}>
              <div className="commonbuy-label">引擎类型：</div>
              <div className="commonbuy-content">
                <ul className="common-list">
                  {ENGINE_LIST.map(item => (
                    <li
                      key={item.value}
                      onClick={() => this.choosedEngine(item.value)}
                      className={item.value === activeEngine ? 'common-item active' : 'common-item'}
                    >
                      {item.name}
                    </li>
                  ))}
                </ul>
                <div style={{ position: 'relative' }}>
                  <div style={{ fontSize: '12px' }}>
                    希望有更多的引擎？点击以下引擎告诉我们您的需求。
                  </div>
                  <ul className="tag-list">
                    {moreEngines.map(item => {
                      return (
                        <li
                          className="tag-item"
                          key={item.value}
                          onClick={() => this.likeEngine(item.value)}
                        >
                          {item.name}
                          <Icon type={item.like ? 'heart-solid' : 'heart-regular'} />
                        </li>
                      );
                    })}
                    <li className="tag-item" onClick={this.toggleMoreInput}>
                      其他
                    </li>
                  </ul>
                  <ComIf if={moreEngineInput}>
                    <div className="common-absolute" style={{ top: 26, left: 350 }}>
                      <Input
                        style={{ width: 145 }}
                        placeholder="请输入您想要的引擎"
                        onChange={this.setCustomerEngine}
                      />
                    </div>
                  </ComIf>
                </div>
              </div>
            </div>
            <div
              className="commonbuy-container"
              style={{ paddingTop: 20, paddingBottom: 20, marginBottom: 5 }}
            >
              <div className="commonbuy-label">版本：</div>
              <div className="commonbuy-content">
                <ul className="common-list">
                  {VERSION_LIST.map(item => (
                    <li
                      onClick={() => this.choosedVersion(item.value)}
                      className={
                        item.value === activeVersion ? 'common-item active' : 'common-item'
                      }
                      key={item.key}
                      id={item.value}
                    >
                      {item.name}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
          <div className="commonbuy-config-container" style={{ height: 100, marginBottom: 5 }}>
            <div
              className="commonbuy-container"
              style={{ paddingTop: 20, paddingBottom: 20, marginBottom: 5, height: 100 }}
            >
              <div className="commonbuy-title-show" style={{ width: 100, left: -61, top: 41 }}>
                网络
              </div>
              <div className="commonbuy-label">网络类型：</div>
              <div className="commonbuy-content" style={{ width: 700 }}>
                <div style={{ position: 'relative' }}>
                  <ul className="common-list">
                    {NET_LIST.map(item => (
                      <li
                        onClick={() => this.choosedNet(item.value)}
                        className={item.value === activeNet ? 'common-item active' : 'common-item'}
                        key={item.key}
                        id={item.value}
                      >
                        {item.name}
                      </li>
                    ))}
                  </ul>
                  <div style={{ position: 'absolute', top: 4, left: 220 }}>
                    <span style={{ fontSize: '12px' }}>{'教我选择>>'}</span>
                    <Balloon
                      trigger={
                        <Icon
                          className="commonbuy-tip"
                          type="help"
                          size="small"
                          style={{
                            marginLeft: 5,
                            color: '#888888',
                          }}
                        />
                      }
                      align="r"
                      closable={false}
                      style={{ marginRight: 5 }}
                      triggerType="hover"
                    >
                      <div className="net-description-container">
                        <ul>
                          <li className="net-description-item">
                            <span>网络类型</span>
                            ：仅是产品功能上区分，与运营商公网接入网络质量无关，任何网络类型的运营商接入均为
                            BGP 线路，请您放心使用，并根据自己需要进行选择。
                          </li>
                          <li className="net-description-item">
                            经典网络：IP
                            地址由阿里云统一分配，配置简便，使用方便，适合对操作易用性要求比较高、需要快速使用的用户。
                          </li>
                          <li className="net-description-item">
                            专有网络：是指逻辑隔离的私有网络，您可以自定义网络拓扑和 IP
                            地址，支持通过专线连接。适合于熟悉网络管理的用户。
                          </li>
                        </ul>
                      </div>
                    </Balloon>
                  </div>
                </div>

                <ComIf if={activeNet === 'privatenet'}>
                  <div style={{ marginTop: 5 }}>
                    {/* <div style={{ float: 'left', height: 31, lineHeight: '31px', marginRight: 10 }}>
                      vpc
                    </div> */}
                    <Select
                      name="cpuext"
                      placeholder="请选择VPC网络"
                      style={{
                        width: 200,
                        marginRight: 10,
                        float: 'left',
                        height: 28,
                        lineHeight: '28px',
                      }}
                      value={activePrivateNet}
                      dataSource={privateNetList}
                      onChange={this.activePrivateNet}
                    />
                    {/* <div style={{ float: 'left', height: 31, lineHeight: '31px', marginRight: 10 }}>
                      交换机
                    </div> */}
                    <Select
                      name="vSwitchId"
                      placeholder="请选择交换机"
                      style={{
                        width: 200,
                        marginRight: 10,
                        float: 'left',
                        height: 28,
                        lineHeight: '28px',
                      }}
                      dataSource={vSwitchIds}
                      value={activeSwitch}
                      onChange={this.activePrivateSwitch}
                    />
                    {/* <ul className="tag-list" style={{ float: 'left' }}>
                      {privateNetList.map(item => {
                        return (
                          <li
                            className={
                              activePrivateNet === item.VpcId ? 'tag-item active' : 'tag-item'
                            }
                            key={item.VpcId}
                            onClick={() => this.activePrivateNet(item.VpcId)}
                          >
                            {item.VpcName}
                          </li>
                        );
                      })}
                    </ul>
                    <div style={{ float: 'left', marginLeft: 10 }}>vswitch</div>
                    <ul className="tag-list" style={{ float: 'left', marginLeft: 10 }}>
                      {vSwitchIds.map(item => {
                        return (
                          <li
                            className={
                              activePrivateNet === item.VpcId ? 'tag-item active' : 'tag-item'
                            }
                            key={item.VpcId}
                            onClick={() => this.activePrivateNet(item.VpcId)}
                          >
                            {item.VpcName}
                          </li>
                        );
                      })}
                    </ul> */}
                  </div>
                </ComIf>
              </div>
            </div>
          </div>
          <div className="commonbuy-config-container">
            <div
              className="commonbuy-container"
              style={{ paddingTop: 20, paddingBottom: 20, marginBottom: 5 }}
            >
              <div className="commonbuy-title-show" style={{ width: 88, left: -55, top: 36 }}>
                实例规格
              </div>
              <div className="commonbuy-label">规格：</div>
              <div className="commonbuy-content" style={{ width: '70%' }}>
                <FormItem label="" hasFeedback requiredMessage="">
                  <Select name="cpuext" style={{ width: '80%', marginRight: 10 }}>
                    <Select.Option value="1-2-60">1核 2G （磁盘60G) </Select.Option>
                    <Select.Option value="2-4-60">2核 4G （磁盘60G) </Select.Option>
                  </Select>
                  <span>x 3个节点</span>
                </FormItem>
                {/* <FormItem label="集群实例个数 :" hasFeedback required requiredMessage="">
                <NumberPicker placeholder="" name="instanceCount" style={{ width: '100%' }} />
              </FormItem> */}
              </div>
            </div>
          </div>
        </Form>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default CommonBuy;
