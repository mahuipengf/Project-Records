import React from 'react';
import { Icon } from '@ali/cn-design';
import PropTypes from 'prop-types';

const IconBack = ({ children, goBack }) => {
  return (
    <div>
      <Icon
        type="wind-arrow-left"
        style={{ paddingRight: 8, cursor: 'pointer' }}
        onClick={goBack}
      />
      {children}
    </div>
  );
};

IconBack.propTypes = {
  goBack: PropTypes.func,
  children: PropTypes.element,
};

export default IconBack;
