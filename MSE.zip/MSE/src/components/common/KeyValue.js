import React, { useEffect, useState } from 'react';
import { Table, Field, Button, Icon, Input } from '@ali/cn-design';
import { uniqueId, filter, map } from 'lodash';
import PropTypes from 'prop-types';
import intl from '@ali/wind-intl';

const KeyValue = (props) => {
  const field = Field.useField();
  const { init } = field;
  const { value, onChange } = props;
  const [dataSource, setDataSource] = useState(value);

  useEffect(() => {
    setDataSource(value);
  }, [value]);

  const handleChange = (uid, obj) => {
    const newData = map(dataSource, (item) => (item.uid === uid ? { ...item, ...obj } : item));
    onChange(newData);
  };

  const handleDelete = (uid) => {
    const newData = filter(dataSource, (item) => item.uid !== uid);
    onChange(newData);
  };

  const handleAdd = () => {
    const newData = [...dataSource, { uid: uniqueId(), Key: '', Value: '' }];
    onChange(newData);
  };

  const columns = [
    {
      key: 'Key',
      title: 'KEY',
      dataIndex: 'Key',
      cell: (val, index, record) => (
        <React.Fragment>
          <Input
            {...init(`Key-${record.uid}`, {
              initValue: val,
              props: {
                onChange: (v) => handleChange(record.uid, { Key: v }),
              },
            })}
            placeholder="Key"
            style={{ width: '100%' }}
          />
        </React.Fragment>
      ),
    },
    {
      key: 'Value',
      title: 'VALUE',
      dataIndex: 'Value',
      cell: (val, index, record) => (
        <React.Fragment>
          <Input
            {...init(`Value-${record.uid}`, {
              initValue: val,
              props: {
                onChange: (v) => handleChange(record.uid, { Value: v }),
              },
            })}
            style={{ width: '100%' }}
            placeholder="Value"
          />
        </React.Fragment>
      ),
    },
    {
      key: 'operations',
      title: '',
      align: 'center',
      cell: (val, index, record) => (
        <Icon
          size="xs"
          type="delete"
          style={{ cursor: 'pointer' }}
          onClick={() => handleDelete(record.uid)}
        />
      ),
      width: 50,
    },
  ];

  return (
    <div>
      <Table dataSource={dataSource} size="small" emptyContent={<span>{intl('mse.common.no_data')}</span>}>
        <For each="item" of={columns}>
          <Table.Column {...item} />
        </For>
      </Table>
      <Button type="normal" style={{ marginTop: 8 }} onClick={handleAdd}>
        <Icon type="add" />
        {intl('mse.register.case.create')}
      </Button>
    </div>
  );
};

KeyValue.propTypes = {
  value: PropTypes.arrayOf(PropTypes.any),
  onChange: PropTypes.func,
};

export default KeyValue;
