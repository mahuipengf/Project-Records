import React from 'react';
import { Loading } from '@ali/wind';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * loading组件
 */
class CommonLoading extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
    };
  }
  openLoading = () => {
    this.setState({
      loading: true,
    });
  };
  closeLoading = () => {
    this.setState({
      loading: false,
    });
  };
  render() {
    const { loading } = this.state;

    return (
      <Loading
        style={{ position: 'relative', width: '100%' }}
        shape="flower"
        tip=""
        visible={loading}
      >
        {this.props.children}
      </Loading>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default CommonLoading;
