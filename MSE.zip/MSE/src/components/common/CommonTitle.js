import React from 'react';
import ComIf from './ComIf';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 公共标题组件
 */
class CommonTitle extends React.PureComponent {
  render() {
    const { title, extra } = this.props;

    return (
      <div style={{ width: '100%', position: 'relative' }}>
        <h3
          style={{
            fontSize: '28px',
            marginTop: 0,
            marginBottom: 16,
            height: 40,
            lineHeight: '40px',
          }}
        >
          {title}
        </h3>
        <ComIf if={extra}>
          <div style={{ position: 'absolute', right: 0, top: 0 }}>{extra}</div>
        </ComIf>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default CommonTitle;
