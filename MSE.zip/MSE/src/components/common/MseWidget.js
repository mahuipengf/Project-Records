import React, { useEffect } from 'react';
import { Widget } from '../../utils/loadWidget';
import { map, get } from 'lodash';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * widget
 */
const MseWidget = (props) => {
  const { component, namespaces = [], loadSuccess, activeNamespaceId } = props;
  const regions = get(window, 'ALIYUN_CONSOLE_CONFIG.STATIC_API.regions', []);
  return (
    <If condition={loadSuccess}>
      <Widget
        component={component}
        regions={map(regions, item => ({ ...item, name: item.regionName }))}
        namespaces={namespaces}
        activeNamespaceId={activeNamespaceId}
      />
    </If>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default MseWidget;
