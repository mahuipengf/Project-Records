import React from 'react';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * @author 丹坤
 * @desc 实现类似v-if指令的组件
 * @example
 * <ComIf
        if={ view }
        then={ EditComponent }
        else={ SaveComponent }
    />
 */
class ComIf extends React.Component {
  getConditionComponent(conditionComponent) {
    const avoidUndfinedComponent = com => (_.isUndefined(com) ? null : com);
    return _.isFunction(conditionComponent)
      ? avoidUndfinedComponent(conditionComponent())
      : conditionComponent;
  }
  render() {
    const { if: vif = false, then = null, else: nelse = null, children = null } = this.props;
    const getConditionComponent = this.getConditionComponent;
    if (children) {
      return vif ? children : null;
    }

    return vif ? getConditionComponent(then) : getConditionComponent(nelse);
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default ComIf;
