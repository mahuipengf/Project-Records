import React, { useState, forwardRef, useImperativeHandle } from 'react';
import PropTypes from 'prop-types';
import SlidePanel from '@alicloud/console-components-slide-panel';
import IconBack from './IconBack';
import { includes } from 'lodash';
import intl from '@ali/wind-intl';

const Panel = (props, ref) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const {
    onCancel,
    onOk,
    onClose,
    children,
    title,
    processingText,
    width,
    onMaskClickClose,
    footerAction,
    ...rest
  } = props;
  const [visible, setVisible] = useState(false);

  useImperativeHandle(ref, () => ({
    show: () => setVisible(true),
    hide: () => setVisible(false),
  }));

  const handleSubmit = async () => {
    try {
      if (onOk) {
        setIsProcessing(true);
        await onOk();
        setIsProcessing(false);
      }
      setVisible(false);
    } catch (err) {
      setIsProcessing(false);
    }
  };

  const handleCancel = () => {
    setIsProcessing(false);
    onCancel ? onCancel() : setVisible(false);
  };

  const handleClose = () => {
    setIsProcessing(false);
    onClose ? onClose() : setVisible(false);
  };

  return (
    <SlidePanel
      onMaskClick={onMaskClickClose ? () => handleClose() : () => console.log('onMaskClick')}
      title={<IconBack goBack={handleClose}>{title}</IconBack>}
      isShowing={visible}
      onOk={includes(footerAction, 'ok') && handleSubmit}
      onCancel={includes(footerAction, 'cancel') && handleCancel}
      onClose={handleClose}
      isProcessing={isProcessing}
      processingText={intl('mse.common.ok') || processingText}
      width={width || 780}
      okText={intl('mse.common.ok')}
      cancelText={intl('mse.common.cancel')}
      style={{ zIndex: 9999 }}
      {...rest}
    >
      {children}
    </SlidePanel>
  );
};

Panel.propTypes = {
  visible: PropTypes.bool,
  onClose: PropTypes.func,
  title: PropTypes.string,
  processingText: PropTypes.string,
  onOk: PropTypes.func,
  width: PropTypes.number,
  onCancel: PropTypes.func,
  onMaskClickClose: PropTypes.bool, // 点击遮罩层是否关闭
  children: PropTypes.element,
  footerAction: PropTypes.arrayOf(PropTypes.string), // ['ok', 'cancel']
};

export default forwardRef(Panel);
