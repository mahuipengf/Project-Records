import React, { FC, useEffect, useState } from 'react';
import copy from 'copy-to-clipboard';
import { Button, Dialog, Message } from '@alicloud/console-components';
import services from 'utils/services';
import intl from '@ali/wind-intl';

const SystemLicenseDialog = props => {
  const { onClose } = props;
  const [ license, setLicense ] = useState('');
  const regionId = window.regionId || 'cn-hangzhou';

  useEffect(() => {
    queryLicenseKey();
  }, [ ]);

  // 请求license
  async function queryLicenseKey() {
    const Data = await services.QueryLicenseKey({
      params: {
        // params: {},
        Source: "edasmsc",
        region: regionId,
        namespace: 'default',
      }
    });
    setLicense(Data);
  }

  // 复制license
  function copyCodeToClipboard() {
    copy(license);
    onClose();
    Message.success(intl('mse.common.copy_success'));
  }

  // 渲染footer
  const footer = (
    <Button
      type={'primary'}
      onClick={copyCodeToClipboard}
      disabled={!license}
    >
      {intl('mse.CopyLicenses')}
    </Button>
  );

  return (
    <Dialog
      {...props}
      title={intl('mse.viewLicense')}
      style={{ width: '600px' }}
      footer={footer}
    >
      <div>{intl('mse.CurrentLicense')}&nbsp;:&nbsp;
        <span
          id="licenseVal"
          style={{color: '#0070CC'}}
        >
          {license}
        </span>
      </div>
    </Dialog>
  );
};

export default SystemLicenseDialog;
