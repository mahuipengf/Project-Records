import React, { useState } from 'react';
import { uniqueId, isEmpty, get, includes } from 'lodash';
import CommonBalloon from './CommonBalloon';
import dingding from 'src/assets/dingding.png';
import seatadingding from 'src/assets/seatadingding.png';
import { Breadcrumb } from '@ali/wind';
import RegionNav from '../RegionNav';
import intl from '@ali/wind-intl';
import AccountUidDialog from '../../../src/pages/overview/AccountUidDialog';
import SystemLicenseDialog from './SystemLicenseDialog';
import Namespace from './Namespace';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 公共面包屑组件
 */
const { Item: BreadcrumbItem } = Breadcrumb;
const regionNavs = [
  '#/Home',
  '#/InstanceList',
  '#/Concats',
  '#/Alarm',
  '#/microgw',
  '#/microgwConcats',
  '#/microgwAlarm',
  '#/msc/home',
  '#/msc/app',
  '#/msc/k8s',
  '#/msc/service',
  '#/msc/route/tag',
  '#/msc/lossless',
  '#/msc/authentication',
  '#/msc/outlierEjection',
  '#/msc/eventCenter',
  '#/msc/services/test',
  '#/msc/services/stress',
  '#/msc/services/regression',
  '#/msc/services/regressionSetList',
  '#/msc/services/inspectionList',
  '#/msc/services/flowbox',
  '#/msc/mstMock',
  '#/msc/mock',
];

class BreadLayout extends React.PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      accountUidVisible: false,
      dialogLicense: false,
      navMenuTitleCss: '',
    };
  }
  generateUrlParams = () => {
    let [hash = '', params = ''] = window.location.hash.split('?');
    let queryParamsList = params.split('&') || [];
    // 不被过滤的参数名
    params = queryParamsList.join('&') || '';
    return { hash, params };
  };
  renderCsPic = () => {
    return (
      <div style={{ display: 'inline-flex' }}>
        <div>
          <img src={dingding} style={{ width: 150 }} />
          <div style={{ textAlign: 'center' }}>{intl('mse.common.ding_group')}</div>
        </div>
        {/* <div>
          <div style={{ height: 192, display: 'flex', alignItems: 'center' }}>
            <img
              src="https://yqfile.alicdn.com/b35318a3e1a70775eee7dcb295468d50f5d21abb.png"
              style={{ width: 150 }}
            />
          </div>
          <div style={{ textAlign: 'center' }}>微信群</div>
        </div> */}
      </div>
    );
  };

  renderSeataCsPic = () => {
    return (
      <div style={{ display: 'inline-flex' }}>
        <div>
          <img src={seatadingding} style={{ width: 150 }} />
          <div style={{ textAlign: 'center' }}>{intl('mse.common.ding_group')}</div>
        </div>
      </div>
    );
  };

  breadCrumbClick = (link, bool) => {
    if (link && bool) {
      hashHistory.push(link);
    }
  };

  // 打开、关闭查看主账号UID弹窗
  handleAccountUidChange = (val) => {
    this.setState({ accountUidVisible: val });
    if (val == 'closeClick' || val == 'false') {
      this.setState({ accountUidVisible: false });
    }
  };

  // 查看License弹窗
  handleLicenseDialog = (val) => {
    this.setState({ dialogLicense: val });
    if (val == 'closeClick' || val == 'false') {
      this.setState({ dialogLicense: false });
    }
  };
  componentDidMount = () => {
    this.hashHistoryEvent();
  }
  hashHistoryEvent = () => {
    hashHistory.listen((location) => {
      const path = location.pathname;
      if (path === '/msc/app/info') {
        this.setState({
          navMenuTitleCss: 'msc-app',
        });
      } else {
        this.setState({
          navMenuTitleCss: '',
        });
      }
    });
  };
  render() {
    const {
      style,
      breadCrumbList = [],
      breadCrumbExpand,
      productName = '',
      target = '',
      isShowNamespace,
      disabled,
    } = this.props;
    const { navMenuTitleCss } = this.state;
    const newBreadCrumbList = [
      {
        title: intl('mse.title'),
        link: '/',
      },
      ...breadCrumbList,
    ];
    const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
    const hashUri = window.location.hash;
    const navMenuTitleCssMargin = navMenuTitleCss === 'msc-app' ? '8px 0px 0px 0px' : '16px 0 8px';
    return (
      <div
        style={{
          width: '100%',
          position: 'relative',
          margin: navMenuTitleCssMargin,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <Breadcrumb style={style} separator="/">
              <For each="item" index="index" of={newBreadCrumbList}>
                <BreadcrumbItem
                  key={uniqueId()}
                  link={
                    item.link && index !== newBreadCrumbList.length - 1
                      ? 'javascript:void(0);'
                      : null
                  }
                  onClick={() =>
                    this.breadCrumbClick(item.link, index !== newBreadCrumbList.length - 1)
                  }
                  data-spm-click={
                    item.link
                      ? `gostr=/aliyun;locaid=breadcrumb-${item.link}`
                      : 'gostr=/aliyun;locaid=breadcrumb-/'
                  }
                >
                  {item.title}
                </BreadcrumbItem>
              </For>
            </Breadcrumb>
            <If condition={isShowNamespace}>
              <Namespace disabled={disabled} />
            </If>
            <If
              condition={
                (includes(window.location.hostname, 'mse4service') ||
                  includes(['JST', 'CAINIAO', 'NEW_RETAIL', 'LIGHTVOCTEST'], channel)) &&
                includes(regionNavs, hashUri)
              }
            >
              <RegionNav />
            </If>
          </div>
        </div>
        <div style={{ display: 'flex' }}>
          {breadCrumbExpand}
          <If condition={target === 'msc_home'}>
            <span
              style={{
                marginLeft: '16px',
                marginRight: '16px',
                cursor: 'pointer',
                color: '#0070cc',
              }}
              onClick={() => {
                this.handleLicenseDialog('true');
              }}
            >
              {intl('mse.viewLicense')}
            </span>
            <a
              style={{ marginRight: '16px', color: '#666', fontWeight: '500' }}
              target="_blank"
              onClick={() => {
                this.handleAccountUidChange('true');
              }}
            >
              {intl('MSE.ViewPrimaryAccountUID')}
            </a>
          </If>
          {/* <CommonBalloon
            content={productName === 'seata' ? this.renderSeataCsPic() : this.renderCsPic()}
            align="bl"
            style={{ maxWidth: 190, width: 190 }}
          >
            <span
              style={{
                color: '#888',
                fontSize: '12px',
                fontWeight: '550',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                marginLeft: 16,
              }}
            >
              <svg
                t="1595904944155"
                className="icon"
                viewBox="0 0 1024 1024"
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                p-id="3066"
                width="20"
                height="20"
              >
                <path
                  d="M187.960889 519.281778h147.285333v323.413333h-147.342222a89.088 89.088 0 0 1-88.348444-89.770667V459.434667h88.405333zM99.555556 459.434667C99.555556 228.124444 284.216889 40.618667 512 40.618667s412.444444 187.505778 412.444444 418.816h-88.405333c0-181.703111-145.066667-329.045333-324.039111-329.045334s-324.039111 147.342222-324.039111 329.045334z m824.888888 293.546666c0 41.870222-28.330667 77.084444-66.56 86.983111 0 79.644444-62.748444 143.36-140.117333 143.36-3.299556 0-6.485333-0.056889-9.671111-0.284444H552.106667a73.557333 73.557333 0 0 1-5.404445 0.170667H487.822222A74.24 74.24 0 0 1 414.151111 908.515556c0-41.301333 32.995556-74.808889 73.671111-74.808889H546.702222a73.955556 73.955556 0 0 1 72.135111 59.619555h103.992889c26.965333-2.275556 42.154667-22.072889 42.723556-50.631111h-76.8V519.338667h147.228444V459.434667h88.405334z"
                  p-id="3067"
                  fill="#777"
                />
              </svg>
              <span style={{ marginLeft: 4, marginBottom: 4 }}>
                {intl('mse.common.service.support')}
              </span>
            </span> */}
          {/* <a
              href="dingtalk://dingtalkclient/action/sendmsg?dingtalk_id=23371469"
              style={{
                display: 'inline-block',
                padding: '5px 0 5px 30px',
                background:
                  'url(https://g.alicdn.com/cm-design/arms/1.1.27/styles/arms/images/dingding.png) no-repeat left center',
                height: '24px',
                verticalAlign: 'middle',
              }}
            /> */}
          {/* </CommonBalloon> */}
        </div>
        {/* 查看主账号UID弹窗 */}
        {this.state.accountUidVisible && (
          <AccountUidDialog
            className={'dialogCustom'}
            visible={this.state.accountUidVisible}
            onClose={this.handleAccountUidChange}
          />
        )}
        {this.state.dialogLicense && (
          <SystemLicenseDialog
            visible={this.state.dialogLicense}
            onClose={this.handleLicenseDialog}
          />
        )}
      </div>
    );
  }
  componentWillUnmount = () => {
    this.hashHistoryEvent();
  }
}


BreadLayout.propTypes = {
  breadCrumbList: PropTypes.arrayOf(PropTypes.shape()),
  breadCrumbExpand: PropTypes.element,
  style: PropTypes.objectOf(PropTypes.any),
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default BreadLayout;
