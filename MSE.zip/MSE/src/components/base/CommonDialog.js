import React from 'react';
import { Dialog } from '@ali/wind';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
class CommonDialog extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      visible: false,
    };
  }
  open = callback => {
    this.setState(
      {
        visible: true,
      },
      callback
    );
  };
  close = () => {
    this.setState({
      visible: false,
    });
  };
  done = () => { };
  render() {
    const { visible } = this.state;
    const { title, style, children, footer, childStyle, shouldUpdatePosition } = this.props;
    const ComDialogStyle = Object.assign({ width: 550, border: 'none' }, { ...style });
    const ContainerStyle = Object.assign({ height: 500, overflow: 'auto' }, { ...childStyle });
    return (
      <Dialog
        title={title}
        visible={visible}
        onOk={this.done}
        onCancel={this.close}
        onClose={this.close}
        style={ComDialogStyle}
        footer={footer}
        shouldUpdatePosition={shouldUpdatePosition}
      >
        <div style={ContainerStyle}>{children}</div>
      </Dialog>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default CommonDialog;
