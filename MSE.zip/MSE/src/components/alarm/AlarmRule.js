import React from 'react';
import ComIf from '../common/ComIf';
import CommonLoading from '../common/CommonLoading';
import { Dialog, MenuButton, Table, Pagination } from '@ali/wind';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 告警列表
 */

const { Item } = MenuButton;
class AlarmRule extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 1,
      dataSource: [],
      pageSize: 10,
      total: 0,
      pageNumber: 1,
      loading: false,
    };
  }
  componentDidMount() {
    this.getAlarmRules();
  }

  getAlarmRules = (AlarmMseType = 'zk') => {
    request({
      url: 'com.alibaba.MSE.service.ListAlarmRules',
      data: {
        AlarmMseType,
        PageNum: 1,
        PageSize: 10,
      },
      beforeSend: () => {
        this.loading && this.loading.openLoading();
      },
      success: res => {
        if (res.code === '200' && res.data) {
          const { Data, PageNumber, TotalCount } = res.data;
          this.setState({
            dataSource: Data,
            pageNumber: PageNumber,
            total: TotalCount,
          });
        }
      },
      complete: () => {
        this.loading && this.loading.closeLoading();
      },
    });
  };
  deleteAlarmRule = AlarmRuleId => {
    Dialog.confirm({
      content: intl('mse.alarm.confirm.delete.rule'),
      onOk: () => {
        window.request({
          url: 'com.alibaba.MSE.service.DeleteAlarmRule',
          data: {
            AlarmRuleId,
          },
          success: () => {
            this.getAlarmRules();
          },
        });
      },
    });
  };
  renderOptions = (value, index, record) => {
    let { AlarmRuleId } = record;
    AlarmRuleId = parseInt(AlarmRuleId, 10);
    return (
      <div>
        <a
          href="javascript:;"
          onClick={() => {
            this.deleteAlarmRule([AlarmRuleId]);
          }}
        >
          {intl('mse.common.delete')}
        </a>
      </div>
    );
  };

  changePage = current => {
    this.setState({
      current,
    });
    this.getAlarmRules();
  };
  renderAlarmRule = value => {
    const alarmRuleList = value.split('\n') || [];
    return (
      <div>
        {alarmRuleList.map(item => (
          <div>{item}</div>
        ))}
      </div>
    );
  };
  renderStatus = value => {
    return (
      <span>
        <ComIf if={value === 'RUNNING'}>
          <span className="circle-status green" />
        </ComIf>
        <ComIf if={value !== 'RUNNING'}>
          <span className="circle-status red" />
        </ComIf>
      </span>
    );
  };
  render() {
    const { dataSource = [], total, pageSize, current } = this.state;

    return (
      <div style={{ width: '100%', position: 'relative', marginTop: 10 }}>
        <CommonLoading ref={node => (this.loading = node)}>
          <Table dataSource={dataSource} primaryKey="AlarmRuleId" hasBorder={false}>
            <Table.Column title={intl('mse.alarm.name')} dataIndex="AlarmName" />
            <Table.Column
              title={intl('mse.alarm.rule')}
              dataIndex="AlarmRuleDetail"
              cell={this.renderAlarmRule}
            />
            <Table.Column title={intl('mse.alarm.update.time')} dataIndex="CreateTime" />
            <Table.Column title={intl('mse.register.state')} dataIndex="AlarmStatus" cell={this.renderStatus} />
            <Table.Column title={intl('mse.common.operate')} cell={this.renderOptions} />
          </Table>
          <div style={{ textAlign: 'right', marginTop: 8 }}>
            <Pagination
              current={current}
              pageSize={pageSize}
              total={total}
              onChange={this.changePage}
            />
          </div>
        </CommonLoading>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AlarmRule;
