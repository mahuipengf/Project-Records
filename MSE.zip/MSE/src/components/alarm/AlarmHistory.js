import React from 'react';
import CommonLoading from '../common/CommonLoading';
import { Dialog, Button, Table, Select, Pagination } from '@ali/wind';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 告警列表
 */
const ALARM_TYPE = [
  {
    label: 'ZooKeeper',
    value: 'zk',
  },
  {
    label: 'Eureka',
    value: 'zk',
  },
  {
    label: 'Nacos',
    value: 'Nacos-Ans',
  },
];

class AlarmHistory extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 1,
      dataSource: [],
      pageSize: 20,
      total: 0,
      pageNumber: 1,
      loading: false,
      alarmHistory: [],
    };
    this.AlarmName = '';
  }
  componentDidMount() {
    this.listAlarmHistory();
    this.getAlarmRules();
  }
  getAlarmRules = (AlarmMseType = 'zk') => {
    request({
      url: 'com.alibaba.MSE.service.ListAlarmRules',
      data: {
        PageNum: 1,
        PageSize: 1000,
        AlarmMseType,
      },
      beforeSend: () => {
        this.loading && this.loading.openLoading();
      },
      success: res => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          const alarmRules = Data.map(item => {
            return {
              label: item.AlarmName,
              value: item.AlarmRuleId,
            };
          });
          this.setState({
            alarmRules,
          });
        }
      },
      complete: () => {
        this.loading && this.loading.closeLoading();
      },
    });
  };
  listAlarmHistory = (StartTime = '', EndTime = '') => {
    const { pageSize, pageNumber } = this.state;
    window.request({
      url: 'com.alibaba.MSE.service.ListAlarmHistorys',
      data: {
        PageNum: pageNumber,
        PageSize: pageSize,
        StartTime,
        EndTime,
        AlarmName: this.AlarmName,
      },
      beforeSend: () => {
        this.loading && this.loading.openLoading();
      },
      success: res => {
        const { Data } = res.data;
        this.setState({
          alarmHistory: Data,
        });
      },
      complete: () => {
        this.loading && this.loading.closeLoading();
      },
    });
  };
  changeAlarmName = AlarmName => {
    this.AlarmName = AlarmName;
  };
  deleteAlarmHistory = AlarmRuleId => {
    Dialog.confim({
      content: intl('mse.alarm.delete.history'),
      onOk: () => {
        request({
          url: 'com.alibaba.MSE.service.DeleteAlarmRule',
          data: {
            AlarmRuleId,
          },
          success: () => {
            this.getAlarmRules();
          },
        });
      },
    });
  };
  renderOptions = (value, index, record) => {
    return (
      <a
        href="javascript:;"
        onClick={() => {
          this.deleteAlarmHistory(record.AlarmRuleId);
        }}
      >
        {intl('mse.common.delete')}
      </a>
    );
  };

  changePage = current => {
    this.setState({
      current,
    });
    this.getAlarmRules();
  };
  renderPhoneAndDingDing = (value, index, record) => {
    const { AlarmPhone, AlarmDingDing } = record;
    return (
      <span>
        {AlarmPhone}/{AlarmDingDing}
      </span>
    );
  };
  render() {
    const { alarmHistory = [], total, pageSize, current, alarmRules } = this.state;

    return (
      <div style={{ width: '100%', position: 'relative', marginTop: 10 }}>
        <div className="common-clearfix" style={{ marginBottom: 8, height: 32 }}>
          {/* <span className="common-form-label">类型:</span>
          <Select
            className="common-float-left"
            dataSource={ALARM_TYPE}
            style={{ marginRight: 10, width: 200 }}
            onChange={this.changeAlarmMseType}
          /> */}
          <span className="common-form-label">{intl('mse.alarm.name')}:</span>
          <Select
            className="common-float-left"
            dataSource={alarmRules}
            style={{ marginRight: 10, width: 200 }}
            onChange={this.changeAlarmName}
          />
          <Button
            type="primary common-link-color"
            className="common-fl-ml10"
            onClick={() => this.listAlarmHistory()}
          >
            {intl('mse.common.search')}
          </Button>
        </div>
        <CommonLoading ref={node => (this.loading = node)}>
          <Table dataSource={alarmHistory} primaryKey="AlarmRuleId" hasBorder={false}>
            <Table.Column
              title={intl('mse.alarm.time')}
              dataIndex="AlarmTime"
              cell={value => <span>{moment(value).format('YYYY-MM-DD HH:mm:ss')}</span>}
            />
            <Table.Column title={intl('mse.alarm.contact.information')} cell={this.renderPhoneAndDingDing} />
            <Table.Column title={intl('mse.common.email')} dataIndex="AlarmEmail" />
            <Table.Column title={intl('mse.alarm.send.content')} dataIndex="AlarmContent" />
          </Table>
          <div style={{ textAlign: 'right', marginTop: 8 }}>
            <Pagination
              current={current}
              pageSize={pageSize}
              total={total}
              onChange={this.changePage}
            />
          </div>
        </CommonLoading>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AlarmHistory;
