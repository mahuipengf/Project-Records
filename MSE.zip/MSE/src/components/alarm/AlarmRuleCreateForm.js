import React from 'react';
import { Form, Checkbox, Select, Input, NumberPicker, Transfer, Field } from '@ali/wind';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 创建报警
 */
const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 20 },
};
const RowWrapperItemLayout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
  labelTextAlign: 'left',
};
const FormItem = Form.Item;

const { Group: CheckboxGroup } = Checkbox;

const NOTICE_CATEGORY = [
  {
    label: '短信',
    value: 'SMS',
  },
  {
    label: '邮件',
    value: 'MAIL',
  },
  {
    label: '钉钉',
    value: 'DING_ROBOT',
  },
];

const AGREE_AGATES = [
  {
    label: '总和',
    value: 'SUM',
  },
  {
    label: '平均值',
    value: 'AVG',
  },
  {
    label: '最大值',
    value: 'MAX',
  },
  {
    label: '最小值',
    value: 'MIN',
  },
];
const OPERATORS = [
  {
    label: '大于等于',
    value: 'CURRENT_GTE',
  },
  {
    label: '小于等于',
    value: 'CURRENT_LTE',
  },
  {
    label: '环比上升 %',
    value: 'PREVIOUS_UP',
  },
  {
    label: '环比下降 %',
    value: 'PREVIOUS_DOWN',
  },
  {
    label: '与上小时同比上升 %',
    value: 'HOH_UP',
  },
  {
    label: '与上小时同比下降 %',
    value: 'HOH_DOWN',
  },
  {
    label: '与昨日同比上升 %',
    value: 'DOD_UP',
  },
  {
    label: '与昨日同比下降 %',
    value: 'DOD_DOWN',
  },
];
const MAX_CLUSTER_NUM = 100;
class AlarmRuleCreateForm extends React.Component {
  constructor(props) {
    super(props);
    this.field = new Field(this);
    this.state = {
      clusterList: [],
      alarmItems: [],
      contactGroups: [],
    };
    this.mseTypeMap = {};
    this.allAlarmItem = [];
  }
  componentDidMount = () => {
    this.getClustersList(); // 查询集群列表
    this.getContactGroups(); // 查询通知对象
    this.getAlarmItems(); // 查询所有的告警实例列表
  };
  getAlarmItems = () => {
    window.request({
      url: 'com.alibaba.MSE.service.ListAlarmItems',
      data: {},
      success: res => {
        const { Data } = res.data;
        this.allAlarmItem = Data;
      },
    });
  };
  showAlarmItems = value => {
    const clusterObj = this.mseTypeMap[value] || {};
    const ClusterType = clusterObj.ClusterType;
    if (this.allAlarmItem.length > 0) {
      const newAlarmItems = this.allAlarmItem
        .filter(item => {
          return item.ClusterType === ClusterType;
        })
        .map(item => {
          return {
            label: item.AlarmDesc,
            value: item.AlarmCode,
          };
        });
      this.setState({
        alarmItems: newAlarmItems,
      });
    }
  };
  getClustersList = (pageNum = 1, clusterName = '') => {
    window.request({
      url: 'com.alibaba.MSE.service.clusterList',
      data: {
        clusterName,
        pageNum,
        pageSize: MAX_CLUSTER_NUM,
      },
      success: res => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          const clusterList = Data.map(item => {
            this.mseTypeMap[item.ClusterId] = item;
            return {
              label: item.ClusterAliasName,
              value: item.ClusterId,
            };
          });
          this.setState({
            clusterList,
          });
        }
      },
    });
  };
  /**
   * 查询通知对象
   */
  getContactGroups = () => {
    request({
      url: 'com.alibaba.MSE.service.ListAlarmContactGroups',
      data: {
        PageNum: 1,
        PageSize: MAX_CLUSTER_NUM,
      },
      success: res => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          const contactGroups = Data.map(item => {
            return {
              label: item.ContactGroupName,
              value: item.ContactGroupId,
            };
          });
          this.setState({
            contactGroups,
          });
        }
      },
    });
  };
  validate = () => {
    this.field.validate();
    let errors = this.field.getErrors();
    let isvalidate = true;
    Object.keys(errors).forEach(key => {
      if (errors[key]) {
        isvalidate = false;
      }
    });
    return isvalidate;
  };
  getValues = () => {
    const values = this.field.getValues();
    const { ClusterId } = values;
    const { InstanceId } = this.mseTypeMap[ClusterId] || {};
    return Object.assign({}, values, { InstanceId });
  };
  render() {
    const { init, getValue, getError } = this.field;
    const { clusterList, contactGroups, alarmItems } = this.state;
    return (
      <div style={{ width: '100%', position: 'relative' }} className="instance-form">
        <Form {...formItemLayout} field={this.field} labelAlign="left" labelTextAlign="left">
          <FormItem label="报警名称" required>
            <Input
              htmlType="text"
              {...init('AlarmAliasName', {
                rules: [
                  { required: true, message: '告警名不能为空' },
                  { maxLength: 30, message: '告警名长度不能超过30' },
                ],
              })}
            />
          </FormItem>
          <FormItem label="集群名" required>
            <Select
              {...init('ClusterId', {
                props: {
                  onChange: this.showAlarmItems,
                },
                rules: [{ required: true, message: '集群名不能为空' }],
              })}
              dataSource={clusterList}
              style={{ width: '100%' }}
            />
          </FormItem>
          <FormItem label="最近N分钟" required>
            <span style={{ marginRight: 5 }}>N=</span>
            <NumberPicker
              placeholder={'1-3600'}
              {...init('NValue', {
                rules: [{ required: true, message: '请填写最近N分钟' }],
              })}
              style={{ width: 90, marginRight: 5 }}
              min={1}
              max={3600}
            />

            <Select
              {...init('AlarmItem', {
                rules: [{ required: true, message: '' }],
              })}
              dataSource={alarmItems}
              style={{ width: 120, marginRight: 5 }}
            />
            <Select
              {...init('Aggregates', {
                rules: [{ required: true, message: '' }],
              })}
              dataSource={AGREE_AGATES}
              style={{ width: 100, marginRight: 5 }}
            />
            <Select
              {...init('Operator', {
                rules: [{ required: true, message: '' }],
              })}
              dataSource={OPERATORS}
              style={{ width: 155, marginRight: 5 }}
            />
            <NumberPicker
              {...init('Value', {
                rules: [{ required: true, message: '' }],
              })}
              style={{ width: 80, marginRight: 5 }}
              min={0}
            />
          </FormItem>
          <FormItem label="通知方式" required>
            <CheckboxGroup
              dataSource={NOTICE_CATEGORY}
              {...init('AlertWay', {
                initValue: ['SMS'],
                rules: [{ required: true, message: '请选择通知方式' }],
              })}
            />
          </FormItem>
          <FormItem label="通知对象" required>
            <Transfer
              dataSource={contactGroups}
              {...init('ContactGroupIds', {
                rules: [{ required: true, message: '请选择通知对象' }],
              })}
              titles={['已选联系组', '全部联系组']}
            />
          </FormItem>
        </Form>
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AlarmRuleCreateForm;
