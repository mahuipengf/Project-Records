import Dialog from '../Dialog';
import React, { useState } from 'react';

interface IImageEnlarge {
  src: string;
  style?: any;
  innerStyle?: any;
  width?: number | string;
}
const ImageEnlarge = (props: IImageEnlarge) => {
  const { src, style, innerStyle, width } = props;

  const [ active, setActive ] = useState(false);
  const handleClickDialog = () => {
    setActive(true);
  };

  return (
    <React.Fragment>
      <img src={src} width={width} style={style} onClick={handleClickDialog} />
      <Dialog
        visible={active}
        onClose={() => { setActive(false); }}
        footer={false}
      >
        <img src={src} style={{ width: 600, ...innerStyle }} />
      </Dialog>
    </React.Fragment>
  );
};
export default ImageEnlarge;
