import React from 'react';
import styles from './index.module.less';

interface ICard {
  children?: any;
  style?: any;
  title?: any;
  dataSource?: any;
  extra?: any;
}
const Card = (props:ICard) => {
  const { children, style, title, extra } = props;
  const extraRender = () => {
    return <div>{extra}</div>;
  };
  return (
    <div className={styles.cardContent} style={{ ...style }}>
      <div
        style={{
          color: '#333333',
          fontWeight: 'bold',
          fontSize: '14px',
          marginBottom: '16px',
          display: 'flex',
          justifyContent: 'space-between',
        }}>
        {title}
        {extraRender()}
        {/* <If condition={ dataSource && dataSource.length <= 0}>
          <span style={{ color: '#888', fontSize: '12px', marginLeft: 16 }}>(目前连接池洞察功能仅支持 Druid 数据源，且需要 agent 为最新版本)</span>
        </If> */}
      </div>
      {children}
    </div>
  );
};
export default Card;
