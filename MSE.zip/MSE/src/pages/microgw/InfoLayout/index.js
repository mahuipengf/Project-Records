import React, { Suspense, useEffect, useRef, useState } from 'react';
import { find, split, join, includes, get, forEach } from 'lodash';
import SubLayout from 'layouts/SubLayout';
import CommonLoading from 'components/common/CommonLoading';
import { queryEncode, queryDecodeHash, queryDecode } from 'utils/queryString';
import {
  GatewayInfo,
  RouterList,
  RouterInfo,
  RouterTest,
  AuthorityList,
  AuthorityInfo,
  SourceList,
  ServiceList,
  ServiceInfo,
  DomainInfo,
  DomainList,
  Monitor,
  Logs,
  DefenseList,
  Plugin,
  ParamsList,
  Trace,
  Diagnose,
  ResourceMonitor,
} from 'pages/microgw';
import intl from '@ali/wind-intl';
import IconBack from 'components/IconBack';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MICROGW } from 'constants';
import { Badge } from '@ali/wind';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

// 1、当channel === 'FINANCE'时，金融云，regionList列表为 ['cn-shanghai-finance-1', 'cn-shenzhen-finance-1', 'cn-beijing-finance-1']
// 2、当channel === 'BJ_GOV'时，政务云，regionList列表为 ['cn-north-2-gov-1']
// const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
// const FinanceOrGov = ['FINANCE', 'BJ_GOV'];
const FinanceOrGovRegion = [
  'cn-beijing-finance-1',
  'cn-shanghai-finance-1',
  'cn-shenzhen-finance-1',
  'cn-north-2-gov-1',
];

const getMenu = () => {
  let Params = queryEncode(queryDecodeHash());
  const paramsCollect = split(Params, '&');
  if (paramsCollect && paramsCollect.length === 5) {
    const [Name, Id] = paramsCollect;
    Params = join([Name, Id], '&');
  }
  const pluginParams = paramsCollect
    .filter((i) => !i.includes('CompType') && !i.includes('PluginId'))
    .join('&');
  const business = {
    key: '/gateway/observe/monitor',
    label: intl('mse.microgw.instance.observe.businessMonitor'),
    to: `/gateway/observe/monitor?${Params}`,
    activePathPatterns: ['/gateway/observe/monitor'],
  };

  const resource = {
    key: '/gateway/observe/resourceMonitor',
    label: intl('mse.microgw.instance.observe.resourceMonitor'),
    to: `/gateway/observe/resourceMonitor?${Params}`,
    activePathPatterns: ['/gateway/observe/resourceMonitor'],
    visible: window.regionId !== 'cn-beijing-finance-1',
  };

  const logs = {
    key: '/gateway/observe/logs',
    label: intl('mse.microgw.instance.observe.logs'),
    to: `/gateway/observe/logs?${Params}`,
    activePathPatterns: ['/gateway/observe/logs'],
  };

  const trace = {
    key: '/gateway/observe/trace',
    label: intl('mse.microgw.instance.observe.trace'),
    to: `/gateway/observe/trace?${Params}`,
    activePathPatterns: ['/gateway/observe/trace'],
  };

  let microObserve = [business, resource, logs, trace];

  if (includes(FinanceOrGovRegion, window.regionId)) {
    microObserve = [business, resource, logs];
  }

  const menus = [
    {
      key: '/gateway/basicInfo',
      label: intl('mse.microgw.instance.overview'),
      activePathPatterns: ['/gateway/basicInfo'],
      to: `/gateway/basicInfo?${Params}`,
      visible: true,
    },
    {
      key: '/gateway/service',
      label: intl('mse.microgw.instance.service'),
      activePathPatterns: ['/gateway/service'],
      to: `/gateway/service?${Params}`,
      visible: true,
      items: [
        {
          key: '/gateway/service/source',
          label: intl('mse.microgw.instance.service.source'),
          to: `/gateway/service/source?${Params}`,
          activePathPatterns: ['/gateway/service/source'],
        },
        {
          key: '/gateway/service/instance',
          label: intl('mse.microgw.instance.service.list'),
          to: `/gateway/service/instance?${Params}`,
          activePathPatterns: ['/gateway/service/instance', '/gateway/service/instance/detail'],
          sub: { link: '/gateway/service/instance/detail' },
        },
      ],
    },
    {
      key: '/gateway/domain',
      label: intl('mse.microgw.instance.domain'),
      activePathPatterns: ['/gateway/domain', '/gateway/domain/detail'],
      to: `/gateway/domain?${Params}`,
      sub: { link: '/gateway/domain/detail' },
      visible: true,
    },
    {
      key: '/gateway/router',
      label: intl('mse.microgw.instance.router'),
      activePathPatterns: ['/gateway/router'],
      to: `/gateway/router?${Params}`,
      visible: true,
      items: [
        {
          key: '/gateway/router/instance',
          label: intl('mse.microgw.instance.router.config'),
          to: `/gateway/router/instance?${Params}`,
          activePathPatterns: ['/gateway/router/instance', '/gateway/router/instance/detail'],
          sub: { link: '/gateway/router/instance/detail' },
        },
        {
          key: '/gateway/router/test',
          label: intl('mse.microgw.instance.router.debug'),
          to: `/gateway/router/test?${Params}`,
          activePathPatterns: ['/gateway/router/test'],
        },
      ],
    },
    {
      key: '/gateway/security',
      label: intl('mse.microgw.instance.security'),
      activePathPatterns: ['/gateway/security'],
      to: `/gateway/security?${Params}`,
      visible: true,
      items: [
        {
          key: '/gateway/security/defense',
          label: intl('mse.microgw.instance.security.defense'),
          to: `/gateway/security/defense?${Params}`,
          activePathPatterns: ['/gateway/security/defense'],
        },
        {
          key: '/gateway/security/authority',
          label: intl('mse.microgw.instance.security.auth'),
          to: `/gateway/security/authority?${Params}`,
          activePathPatterns: ['/gateway/security/authority', '/gateway/security/authority/detail'],
          sub: { link: '/gateway/security/authority/detail' },
          isUseNamespace: true,
        },
      ],
    },
    {
      key: '/gateway/diagnose',
      label: (
        <Badge
          content="new"
          style={{
            backgroundColor: '#f54743',
            color: '#fff',
            borderRadius: '10px',
            top: -10,
            right: -42,
          }}
        >
          {intl('mse.register.health')}
        </Badge>
      ),
      activePathPatterns: ['/gateway/diagnose'],
      to: `/gateway/diagnose?${Params}`,
      visible: window.regionId !== 'cn-north-2-gov-1', // cn-north-2-gov-1 政务云 暂不支持网关风险管理
    },
    {
      key: '/gateway/observe',
      label: intl('mse.microgw.instance.observe'),
      activePathPatterns: ['/gateway/observe'],
      to: `/gateway/observe?${Params}`,
      visible: true,
      items: [...microObserve],
    },
    {
      key: '/gateway/parameter',
      label: intl('mse.microgw.instance.observe.parameter'),
      activePathPatterns: ['/gateway/parameter'],
      to: `/gateway/parameter?${Params}`,
      visible: true,
    },
  ];

  const plugin = {
    key: '/gateway/plugin',
    label: intl('mse.microgw.instance.observe.plugin'),
    activePathPatterns: ['/gateway/plugin'],
    to: `/gateway/plugin?${pluginParams}`,
    visible: true,
  };

  if (includes(paramsCollect, 'SupportWasm=true')) {
    menus.splice(5, 0, plugin);
  }
  return menus;
};

const { Switch, Route, Router, Redirect } = window.ReactRouterDOM || window.ReactRouterDom || {};
const breadCrumbList = [
  {
    title: intl('mse.microgw.breadcrumb.instance'),
    link: '/microgw',
  },
];

const GatewaySubLayout = ({ history }) => {
  const { search } = history.location;
  const [menuItems, setMenuItems] = useState([]);

  useEffect(() => {
    setMenuItems(getMenu());
    eventEmitter.on(`${WIDGET_EDAS_MICROGW.id}:view-service-detail`, handleViewServiceDetail);
    eventEmitter.on(`${WIDGET_EDAS_MICROGW.id}:view-domain-detail`, handleViewDomainDetail);
    eventEmitter.on(`${WIDGET_EDAS_MICROGW.id}:view-router-detail`, handleViewRouterDetail);
    eventEmitter.on(`${WIDGET_EDAS_MICROGW.id}:view-router-test`, handleViewRouterTest);
    eventEmitter.on(`${WIDGET_EDAS_MICROGW.id}:view-authority-detail`, handleViewAuthorityDetail);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MICROGW.id}:view-service-detail`, handleViewServiceDetail);
      eventEmitter.off(`${WIDGET_EDAS_MICROGW.id}:view-domain-detail`, handleViewDomainDetail);
      eventEmitter.off(`${WIDGET_EDAS_MICROGW.id}:view-router-detail`, handleViewRouterDetail);
      eventEmitter.off(
        `${WIDGET_EDAS_MICROGW.id}:view-authority-detail`,
        handleViewAuthorityDetail
      );
    };
  }, []);

  useEffect(() => {
    window.CN_TRACKER.send({
      name: history.location.pathname,
      type: 'mse-microgw-menu',
    });
  }, [history.location.pathname]);

  const handleViewServiceDetail = (value = {}) => {
    const search = queryDecode();
    const { Id: ServiceId, Name: subTitle } = value;
    const newSearch = queryEncode({ ...search, ServiceId, subTitle });
    hashHistory.push(`/gateway/service/instance/detail?${newSearch}`);
  };

  const handleViewDomainDetail = (value = {}) => {
    const search = queryDecode();
    const { Id: DomainId, Name: subTitle } = value;
    const newSearch = queryEncode({ ...search, DomainId, subTitle });
    hashHistory.push(`/gateway/domain/detail?${newSearch}`);
  };

  const handleViewRouterDetail = (value = {}) => {
    const search = queryDecode();
    const { Id: RouteId, Name: subTitle } = value;
    const newSearch = queryEncode({ ...search, RouteId, subTitle });
    hashHistory.push(`/gateway/router/instance/detail?${newSearch}`);
  };

  const handleViewRouterTest = (value = {}) => {
    const search = queryDecode();
    const { Id: RouteId } = value;
    const newSearch = queryEncode({ ...search, RouteId });
    hashHistory.push(`/gateway/router/test?${newSearch}`);
  };

  const handleViewAuthorityDetail = (value = {}) => {
    const search = queryDecode();
    const { Id: AuthorityId, Name: subTitle } = value;
    const newSearch = queryEncode({ ...search, AuthorityId, subTitle });
    hashHistory.push(`/gateway/security/authority/detail?${newSearch}`);
  };

  const loadRef = useRef();

  const Layout = () => (
    <Switch>
      <Route path="/gateway/basicInfo" component={GatewayInfo} />
      <Route path="/gateway/service/instance/detail" component={ServiceInfo} />
      <Route path="/gateway/service/instance" component={ServiceList} />
      <Route path="/gateway/service/source" component={SourceList} />
      <Route path="/gateway/domain/detail" component={DomainInfo} />
      <Route path="/gateway/domain" component={DomainList} />
      <Route path="/gateway/router/instance/detail" component={RouterInfo} />
      <Route path="/gateway/router/instance" component={RouterList} />
      <Route path="/gateway/router/test" component={RouterTest} />
      <Route path="/gateway/security/defense" component={DefenseList} />
      <Route path="/gateway/security/authority/detail" component={AuthorityInfo} />
      <Route path="/gateway/security/authority" component={AuthorityList} />
      <Route path="/gateway/plugin" component={Plugin} />
      <Route path="/gateway/diagnose" component={Diagnose} />
      <Route path="/gateway/observe/monitor" component={Monitor} />
      {/* 华北金融云不放开资源监控 */}
      {window.regionId !== 'cn-beijing-finance-1' && (
        <Route path="/gateway/observe/resourceMonitor" component={ResourceMonitor} />
      )}
      <Route path="/gateway/observe/logs" component={Logs} />
      <Route path="/gateway/observe/trace" component={Trace} />
      <Route path="/gateway/parameter" component={ParamsList} />
      <Redirect to="/microgw" />
    </Switch>
  );

  useEffect(() => {
    Layout;
  }, [window?.regionId]);

  const composeList = (item, list, params) => {
    if (item.sub) {
      list.push({
        link: item.key,
        title: getParams('Name'),
      });
      const { subTitle } = queryDecode(search);
      list.push({
        ...item.sub,
        parent: { link: `${item.key}?${params}`, title: getParams('Name') },
        title: subTitle,
      });
    } else {
      list.push({ link: item.key, title: getParams('Name') });
    }
  };

  // 提取 menu，生成需要的数据格式
  const mapMenu = () => {
    const list = [];
    const params = queryEncode(queryDecodeHash());
    forEach(menuItems, (item) => {
      if (item.items) {
        forEach(item.items, (child) => {
          composeList(child, list, params);
        });
      } else {
        composeList(item, list, params);
      }
    });
    return list;
  };

  const sub = find(mapMenu(), (item) => history.location.pathname === item.link) || {};
  const newBreadCrumbList = sub.parent
    ? [...breadCrumbList, sub.parent, sub]
    : [...breadCrumbList, sub];
  const title = sub?.title;

  const subPathList = [
    '/gateway/service/instance/detail',
    '/gateway/domain/detail',
    '/gateway/router/instance/detail',
    '/gateway/security/authority/detail',
  ];

  return (
    <SubLayout
      breadCrumbList={newBreadCrumbList}
      items={menuItems}
      title={
        <IconBack
          back
          text={title}
          onClick={() => {
            if (subPathList.includes(history.location.pathname) && get(sub, 'parent.link')) {
              hashHistory.push(get(sub, 'parent.link'));
            } else {
              hashHistory.push('/microgw');
            }
          }}
        />
      }
      pathname={history.location.pathname}
    >
      <Suspense fallback="...">
        <CommonLoading ref={loadRef}>
          <Router history={history}>
            <Route path="/gateway" component={Layout} />
          </Router>
        </CommonLoading>
      </Suspense>
    </SubLayout>
  );
};

GatewaySubLayout.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default GatewaySubLayout;
