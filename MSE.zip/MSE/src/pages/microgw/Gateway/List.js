import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { MicrogwWidget, eventEmitter } from 'utils/loadWidget';
import AppLayout from 'containers/AppLayout';
import { WIDGET_EDAS_MICROGW } from 'constants';
import intl from '@ali/wind-intl';
import { forApp } from '@alicloud/console-base-messenger';

const breadCrumbList = [
  {
    title: intl('mse.microgw.menu.instance'),
  },
];
const widgetProps = {
  component: 'GatewayList',
  searchValues: {
    regionId: window.regionId,
  },
};

const GatewayList = (props) => {
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MICROGW.id}:go-to-GatewayInfo`, goToGatewayInfo);
    eventEmitter.on(`${WIDGET_EDAS_MICROGW.id}:go-to-Router`, goToRouter);
    eventEmitter.on(`${WIDGET_EDAS_MICROGW.id}:go-to-Monitor`, goToMonitor);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MICROGW.id}:go-to-GatewayInfo`, goToGatewayInfo);
      eventEmitter.off(`${WIDGET_EDAS_MICROGW.id}:go-to-Router`, goToRouter);
      eventEmitter.off(`${WIDGET_EDAS_MICROGW.id}:go-to-Monitor`, goToMonitor);
    };
  }, []);

  useEffect(() => {
    if (localStorage.getItem('microgwResourceCount')) {
      forApp.setRegionResourceCount(JSON.parse(localStorage.getItem('microgwResourceCount')));
    }
  });

  const goToGatewayInfo = (payload) => {
    const { history } = props;
    const { Name, GatewayUniqueId, GatewayVersion, MustUpgrade, InitConfig = {}, SupportWasm } = payload;
    const { SupportWaf = false, EnableWaf = false } = InitConfig;
    history.push({
      pathname: '/gateway/basicInfo',
      search: `?Name=${Name}&Id=${GatewayUniqueId}&Version=${GatewayVersion}&MustUpgrade=${MustUpgrade}&SupportWaf=${SupportWaf}&EnableWaf=${EnableWaf}&SupportWasm=${SupportWasm}`,
    });
  };

  const goToRouter = (payload) => {
    const { history } = props;
    const { Name, GatewayUniqueId, GatewayVersion, MustUpgrade, InitConfig = {}, SupportWasm } = payload;
    const { SupportWaf = false, EnableWaf = false } = InitConfig;
    history.push({
      pathname: '/gateway/router/instance',
      search: `?Name=${Name}&Id=${GatewayUniqueId}&Version=${GatewayVersion}&MustUpgrade=${MustUpgrade}&SupportWaf=${SupportWaf}&EnableWaf=${EnableWaf}&SupportWasm=${SupportWasm}`,
    });
  };

  const goToMonitor = (payload) => {
    const { history } = props;
    const { Name, GatewayUniqueId, GatewayVersion, MustUpgrade, InitConfig = {}, SupportWasm } = payload;
    const { SupportWaf = false, EnableWaf = false } = InitConfig;
    history.push({
      pathname: '/gateway/observe/monitor',
      search: `?Name=${Name}&Id=${GatewayUniqueId}&Version=${GatewayVersion}&MustUpgrade=${MustUpgrade}&SupportWaf=${SupportWaf}&EnableWaf=${EnableWaf}&SupportWasm=${SupportWasm}`,
    });
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {/* {intl('mse.common.dingding')}：
          <img
            style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
            src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
          />
          <span style={{ color: '#0070cc', marginRight: 8 }}> 34754806 </span> */}
          {intl('mse.common.document')}：
          <a target="_blank" href="https://help.aliyun.com/document_detail/250952.html">
            {intl('mse.microgw.use')}
          </a>
        </div>
      }
      title={intl('mse.microgw.menu.instance')}
      message={
        [{
          type: 'notice',
          text: intl.html('mse.microgw.notice1'),
        }, {
          type: 'notice',
          text: intl.html('mse.microgw.notice2'),
        }]
      }
      data-spm="microgw-instance"
    >
      <MicrogwWidget {...widgetProps} />
    </AppLayout>
  );
};

GatewayList.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default GatewayList;
