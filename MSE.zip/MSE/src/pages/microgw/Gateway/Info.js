import React from 'react';
import { MicrogwWidget } from 'utils/loadWidget';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 网关详情
 */
const REGION_ID = window.regionId;
const GatewayInfo = () => {
  const GatewayUniqueId = getParams('Id');
  const GatewayVersion = getParams('Version');
  const SupportWaf = getParams('SupportWaf');
  const EnableWaf = getParams('EnableWaf');
  const MustUpgrade = getParams('MustUpgrade');

  const widgetProps = {
    component: 'GatewayInfo',
    searchValues: {
      regionId: REGION_ID,
      GatewayUniqueId,
      GatewayVersion,
      SupportWaf: SupportWaf === 'true',
      EnableWaf: EnableWaf === 'true',
      MustUpgrade: MustUpgrade === 'true',
    },
  };

  return <MicrogwWidget {...widgetProps} />;
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default GatewayInfo;
