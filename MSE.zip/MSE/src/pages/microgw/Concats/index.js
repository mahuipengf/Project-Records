import React, { useEffect, useRef } from 'react';
import AppLayout from 'containers/AppLayout';
import CommonLoading from '../../../components/common/CommonLoading';
import './index.less';
import intl from '@ali/wind-intl';
import { getCurrentRegion } from 'utils';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 基础信息页面
 */
const Concats = () => {
  const refLoading = useRef(null);

  useEffect(() => {
    refLoading && refLoading.current.openLoading();
  }, []);

  const onConcatsLoad = () => {
    refLoading && refLoading.current.closeLoading();
  };

  const breadCrumbList = [
    {
      title: intl('mse.microgw.menu.concats'),
    },
  ];

  let domain = 'arms.console.aliyun.com';
  const regionId = getCurrentRegion();
  if (regionId === 'cn-north-2-gov-1') {
    domain = 'arms-gov.console.aliyun.com';
  }
  if (regionId === 'cn-shenzhen-finance-1' || regionId === 'cn-shanghai-finance-1') {
    domain = 'arms4finance.console.aliyun.com';
  }

  return (
    <AppLayout breadCrumbList={breadCrumbList} title={intl('mse.microgw.menu.concats')}>
      <div className="alarm-loading">
        <CommonLoading ref={refLoading}>
          <iframe
            onLoad={onConcatsLoad}
            onError={onConcatsLoad}
            src={`https://${domain}/?iframeMode=true&hideHeader=true#/alarm/notifyObject`}
            style={{ width: '100%', border: 'none', height: 'calc(100% + 60px)', marginTop: -10 }}
          />
        </CommonLoading>
      </div>
    </AppLayout>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default Concats;
