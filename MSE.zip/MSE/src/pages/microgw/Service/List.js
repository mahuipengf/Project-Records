import React from 'react';
import { MicrogwWidget } from 'utils/loadWidget';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 服务管理
 */
 const REGION_ID = window.regionId;
 const ServiceList = () => {
   const GatewayUniqueId = getParams('Id');
   const GatewayVersion = getParams('Version');
   const SupportWaf = getParams('SupportWaf');
   const EnableWaf = getParams('EnableWaf');
   const MustUpgrade = getParams('MustUpgrade');

   const widgetProps = {
     component: 'ServiceList',
     searchValues: {
       regionId: REGION_ID,
       GatewayUniqueId,
       GatewayVersion,
       MustUpgrade: MustUpgrade === 'true',
       SupportWaf: SupportWaf === 'true',
       EnableWaf: EnableWaf === 'true',
     },
   };

   return <MicrogwWidget {...widgetProps} />;
 };
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default ServiceList;
