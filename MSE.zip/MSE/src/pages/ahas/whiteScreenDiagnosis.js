import React, { useEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
import Iframe from 'components/Iframe';
import intl from '@ali/wind-intl';

const WhiteScreenDiagnosis = ({ AppName = '', urlParams = '' }) => {
  const params = `MseImplant=true&source=publicPts&hideSidebar=true&MseTitle=${intl(
    'mse.title'
  )}&MseMenuTitle=全链路流量日志详情&MseKey=whiteScreenDiagnosis`;
  useEffect(() => {
    fetchPostMessage();
  }, []);
  const logId = getParams('logId') || '';
  const fetchPostMessage = () => {
    window.addEventListener('message', (event) => {
      const data = event.data.BreadCrumb && event.data.BreadCrumb.key;
      if (data === 'home') {
        hashHistory.push('/home');
      }
    });
  };
  const mse_x_acs_debug_http_host = sessionStorage.getItem('mse_x_acs_debug_http_host');
  return (
    // <AhasPermission urlParams={urlParams} tag="config" >
      <Iframe
        params={`https://ahasnext.console.aliyun.com/logGovernance/whiteScreenDiagnosis?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}&logId=${logId}`}
        styles={{ width: '100%', border: 'none', height: 'calc(100vh - 50px)' }}
      />
    // </AhasPermission>
  );
};
export default WhiteScreenDiagnosis;
