import React, { useEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
import { createAlfaApp } from '@alicloud/alfa-react';
import { createEventBus } from '@ali/xconsole/alfa';
import { Message } from '@ali/cn-design';
import { useStateStore } from '../../../store';
import { get } from 'lodash';

const emitter = createEventBus();
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 */
const AppConfig = ({ AppName = '', urlParams = '', history, AppId = '' }) => {
  window.addEventListener('message', (event) => {
    const data = event.data && event.data.MseKey;
    const params = event.data.MseUrlParams;
    if (data === 'history' && params) {
      hashHistory.push(`/msc/app/info/switch/history?${params}`);
    }
  });
  const AlfaApp = createAlfaApp({
    name: '@ali/alfa-cloud-mse-widget-mse-ahas'
  });
  const Source = getParams('accessType');
  const params = {
    component: 'Interface',
    window,
    searchValues: {
      regionId: window.regionId,
      appId: AppId,
    },
  };
  useEffect(() => {
    emitter.on('mse_nodeDetail_machine', (e) => {
      const { val = '' } = e;
      // if (val === 'machine_governance') {
      //   history.push({
      //     pathname: '/msc/app/info/machineDetails',
      //     search: `?appId=${AppId}&appName=${AppName}&accessType=${Source}&type=${'dynameic_line'}&activeType=behavior`,
      //   });
      // }
      if (val === 'action_details') {
        history.push({
          pathname: '/msc/app/info/set/flowSetting',
          search: `?appId=${AppId}&appName=${AppName}&accessType=${Source}&type=dynameic_line&bricks=wll`,
        });
      }
    });
  }, []);
  const state = useStateStore();
  const Version = get(state, 'MscAccount.Version');
  const Status = get(state, 'MscAccount.Status');
  return (
    <React.Fragment>
      <If condition={aliwareGetCookieByKeyName('aliyun_site') !== 'INTL'}>
        <If condition={(Status === 2 && Version !== 2)}>
          <Message type="notice" style={{ color: '#f68300', margin: '4px 0 16px' }}>
            <div>
              MSE 微服务治理于 2022.06.07 重磅升级，在流量治理方面进行更细粒度、更全方位的升级，深度支持 Sentinel ，使用体验更加平滑顺畅。如果您的应用只有 QPS 数据，且希望体验到更多的流量防护能力以及监控数据，您可以升级至<a href="https://help.aliyun.com/document_detail/421923.html" target="_blank">企业版</a>。
            </div>
          </Message>
        </If>
      </If>
        <AlfaApp {...params} sandbox={{ externalsVars: ['location', 'regionId', 'MSE_ENV_CONFIG', 'parent', 'goldlog'] }} id="@ali/alfa-cloud-mse-widget-mse-ahas" />
    </React.Fragment>

  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AppConfig;
