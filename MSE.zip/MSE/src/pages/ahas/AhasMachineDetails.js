import React, { useEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
import { createAlfaApp } from '@alicloud/alfa-react';
import utilMethod from '../../utils/utils';
import { createEventBus } from '@ali/xconsole/alfa';


/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * SWITCH应用配置
 */
const AppConfig = ({ AppName = '', urlParams = '', AppId = '' }) => {
  const emitter = createEventBus();
  window.addEventListener('message', (event) => {
    const data = event.data && event.data.MseKey;
    const params = event.data.MseUrlParams;
    if (data === 'history' && params) {
      hashHistory.push(`/msc/app/info/switch/history?${params}`);
    }
  });
  const AlfaApp = createAlfaApp({
    name: '@ali/alfa-cloud-mse-widget-mse-ahas'
  });
  const params = {
    component: 'SystemGuardMachineDetails',
    window,
    searchValues: {
      regionId: window.regionId,
      appId: AppId,
      appName: AppName,
    },
    parent: window,
  };
  return (
    <React.Fragment>
      <AhasPermission urlParams={urlParams} tag="protect" >
        <AlfaApp {...params} sandbox={{ externalsVars: ['location', 'regionId', 'MSE_ENV_CONFIG', 'parent', 'window', 'goldlog'] }} id="@ali/alfa-cloud-mse-widget-mse-ahas" />
      </AhasPermission>
    </React.Fragment>

  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AppConfig;
