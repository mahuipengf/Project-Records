import React, { useEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
import Iframe from 'components/Iframe';
import intl from '@ali/wind-intl';

const AccessLogMarket = ({ AppName = '', urlParams = '' }) => {
  const params = `MseImplant=true&source=publicPts&hideSidebar=true&MseTitle=${intl(
    'mse.title'
  )}&MseMenuTitle=流量日志大盘&MseKey=accessLogMarket`;
  useEffect(() => {
    fetchPostMessage();
  }, []);
  const fetchPostMessage = () => {
    window.addEventListener('message', (event) => {
      const data = event.data.BreadCrumb && event.data.BreadCrumb.key;
      if (data === 'home') {
        hashHistory.push('/home');
      }
    });
  };
  const mse_x_acs_debug_http_host = sessionStorage.getItem('mse_x_acs_debug_http_host'); // mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}
  return (
    <AhasPermission urlParams={urlParams} tag="config" >
      <Iframe
        params={`https://ahasnext.console.aliyun.com/logGovernance/accessLogMarket?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`}
        styles={{ width: '100%', border: 'none', height: 'calc(100vh - 50px)' }}
      />
    </AhasPermission>
  );
};
export default AccessLogMarket;
