import React, { useEffect } from 'react';



const MockUser = (props) => {

    useEffect(() => {
        const href = (window.location.href).toString();
        if( href.includes('uid') ) {
          let reg, uid, puid;
          if( href.includes('puid') ) {
            puid = href.split("puid=")[1];
            window.MSE_INNER_ALIYUN_PK_PARENT = puid;
            uid = href.split("?uid=")[1].split("&")[0];
          } else {
            uid = href.split("?uid=")[1];
          }
          window.MSE_INNER_ALIYUN_PK = uid;
          localStorage.setItem("MseSessionId",`${uid}_${new Date().valueOf()}`);
          hashHistory.push({
              pathname: '/overview',
          });
          location.reload();
        } else {
          hashHistory.push({
            pathname: '/overview',
          });
        }
        
    })


  return (
    <div className="main_mockuser">
    </div>
  );
};

export default MockUser;
