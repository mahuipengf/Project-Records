import React, { useEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
import Iframe from 'components/Iframe';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * SWITCH应用配置
 */
const AppConfig = ({ AppName = '', urlParams = '' }) => {
  const params = `MseImplant=true&source=publicPts&hideSidebar=true&MseKey=history&MseUrlParams=${urlParams}`;

  window.addEventListener('message', (event) => {
    const data = event.data && event.data.MseKey;
    const params = event.data.MseUrlParams;
    if (data === 'history' && params) {
      hashHistory.push(`/msc/app/info/switch/history?${params}`);
    }
  });

  return (
    <React.Fragment>
      <AhasPermission urlParams={urlParams} tag="config" >
        <Iframe
          params={`https://ahasnext.console.aliyun.com/switch/app/switchlist/${AppName}?ahasAppName=&ns=default&region=${window.regionId}&${params}`}
          styles={{ width: '100%', border: 'none', height: 'calc(100vh - 100px)', marginTop: -16 }}
        />
      </AhasPermission>
    </React.Fragment>

  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AppConfig;
