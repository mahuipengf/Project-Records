import React from 'react';
import WidgetPermission from 'containers/WidgetPermission';

const EventCenterList = ({ message }) => {
  const appId = getParams('appId');

  const widgetProps = {
    component: 'EventCenterList',
    searchValues: {
      regionId: window.regionId,
      appId
    },
  };
  return (
    <WidgetPermission widget="msc" widgetProps={widgetProps} />
  );
};

export default EventCenterList;
