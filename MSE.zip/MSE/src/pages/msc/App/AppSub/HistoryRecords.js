import React from 'react';
import AhasPermission from 'containers/AhasPermission';
import Iframe from 'components/Iframe';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 历史记录
 */
const HistoryRecords = ({ AppName = '', urlParams = '' }) => {
  const params = 'MseImplant=true&source=publicPts&hideSidebar=true';

  return (
    <AhasPermission urlParams={urlParams} tag="config" >
      <Iframe
        params={`https://ahasnext.console.aliyun.com/switch/app/history/${AppName}?ahasAppName=&ns=default&region=${window.regionId}&${params}`}
        styles={{ width: '100%', border: 'none', height: 'calc(100vh - 100px)' }}
      />
    </AhasPermission>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default HistoryRecords;
