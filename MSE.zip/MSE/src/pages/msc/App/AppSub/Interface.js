import React from 'react';
import WidgetPermission from 'containers/WidgetPermission';

const Interface = ({ message }) => {
  const appId = getParams('appId');

  const widgetProps = {
    component: 'Interface',
    searchValues: {
      regionId: window.regionId,
      appId
    },
  };
  return (
    <WidgetPermission widget="msc" widgetProps={widgetProps} />
  );
};

export default Interface;
