import React from 'react';
import WidgetPermission from 'containers/WidgetPermission';

const REGION_ID = window.regionId;
const AppInfo = () => {
  const AppId = getParams('appId');
  const AppName = getParams('appName')|| getParams('ahasAppName')||'';

  const widgetProps = {
    component: 'AppInfo',
    searchValues: {
      regionId: REGION_ID,
      appId: AppId,
      appName: AppName,
    },
  };

  return (
    <WidgetPermission widget="msc" widgetProps={widgetProps} />
  );
};

export default AppInfo;
