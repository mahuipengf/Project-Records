import React from 'react';
import AhasPermission from 'containers/AhasPermission';
import AhasPermissionOpen from 'components/AhasProtectPermission';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * AHAS应用防护
 */
const AppProtect = ({ AppName = '', urlParams = '' }) => {
  const params = 'tabKey=0&MseImplant=true&source=publicPts&hideSidebar=true';

  return (
    <React.Fragment>
      <AhasPermission urlParams={urlParams} tag="protect" >
        <iframe
          id="ahas"
          src={`https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardApiDetails?ahasAppName=&appName=${AppName}&ns=default&region=${window.regionId}&${params}`}
          style={{ width: '100%', border: 'none', height: 'calc(100vh - 100px)', marginTop: -16 }}
        />
      </AhasPermission>
    </React.Fragment>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AppProtect;
