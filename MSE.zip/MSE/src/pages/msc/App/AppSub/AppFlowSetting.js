import React, { useEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
import WidgetPermission from 'containers/WidgetPermission';


/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 */
const AppFlowSetting = ({ AppName = '', urlParams = '', history, AppId = '' }) => {
  const widgetProps = {
    component: 'FlowSetting',
    searchValues: {
        regionId: window.regionId,
        appId: AppId,
      },
  };
  const flag = getParams('bricks');
  if (flag) setParams('activeType', 'behavior');
  return (
    <React.Fragment>
      <AhasPermission urlParams={urlParams} tag="protect" >
          <WidgetPermission widget="msc" widgetProps={widgetProps} />
      </AhasPermission>
    </React.Fragment>

  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AppFlowSetting;
