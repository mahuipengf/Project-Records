import React from 'react';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * SWITCH应用配置
 */
const AppOpen = ({ AppName = '' }) => {
  const params = 'MseImplant=true&source=publicPts&hideSidebar=true';
  return (
      <iframe
        id="switch"
        src={`https://ahasnext.console.aliyun.com/switch/app/switchlist/${AppName}?ahasAppName=&ns=default&region=${window.regionId}&${params}`}
        style={{ width: '100%', border: 'none', height: 'calc(100%)' }}
      />
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AppOpen;
