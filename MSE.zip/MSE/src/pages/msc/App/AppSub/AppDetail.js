import React, { useEffect, useMemo } from 'react';
import WidgetPermission from 'containers/WidgetPermission';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import { Message } from '@ali/cn-design';
import { useStateStore } from '../../../../store';
import { get } from 'lodash';

let firstAramsLinkTracker = 0;
const REGION_ID = window.regionId;
const AppDetail = (props) => {
  const state = useStateStore();
  const Version = get(state, 'MscAccount.Version');
  const Status = get(state, 'MscAccount.Status');
  const UserId = get(state, 'MscAccount.UserId');
  const AppId = getParams('appId');
  const AppName = getParams('appName')|| getParams('ahasAppName')||'';
  const { message, history } = props;
  useEffect(() => {
    if (getParams('spmSource') === 'arms' && firstAramsLinkTracker <= 0) {
      window.CN_TRACKER.send({
        name: 'offline_dump_form_arms',
        type: 'spm_source',
      });
    }
    firstAramsLinkTracker += 1;
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-fullLinkGrayscalekHome`, fullLinkGrayscalekHome);
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AppFlowSetting`, goToAppFlowSetting);
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AppEventCenter`, goToEventCenter);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-fullLinkGrayscalekHome`, fullLinkGrayscalekHome);
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AppFlowSetting`, goToAppFlowSetting);
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AppEventCenter`, goToEventCenter);
    };
  }, []);
  const widgetProps = {
    component: 'AppDetail',
    searchValues: {
      regionId: REGION_ID,
      appId: AppId,
      appName: AppName,
    },
  };
  const goToEventCenter = (payload) => {
    const { AppId, AppName, Source, Type } = payload;
    history.push({
      pathname: '/msc/app/info/eventCenter',
      search: `?appId=${AppId}&appName=${AppName}&accessType=${Source}&type=${Type || 'dynameic_line'}`,
    });
  };
  const goToAppFlowSetting = (payload) => {
    const { AppId, AppName, Source, Type } = payload;
    history.push({
      pathname: '/msc/app/info/set/flowSetting',
      search: `?appId=${AppId}&appName=${AppName}&accessType=${Source}&type=${Type || 'dynameic_line'}&activeType=behavior`,
    });
  };
  const fullLinkGrayscalekHome = () => {
    history.push({
      pathname: '/msc/grayscale',
    });
  };
  return (
    <div>
      <If condition={aliwareGetCookieByKeyName('aliyun_site') !== 'INTL'}>
        <If condition={(Status === 2 && Version !== 2)}>
          <Message type="notice" style={{ color: '#f68300', margin: '4px 0 16px' }}>
            <div>
              MSE 微服务治理于 2022.06.07 重磅升级，在流量治理方面进行更细粒度、更全方位的升级，深度支持 Sentinel ，使用体验更加平滑顺畅。如果您的应用只有 QPS 数据，且希望体验到更多的流量防护能力以及监控数据，您可以升级至<a href="https://help.aliyun.com/document_detail/421923.html" target="_blank">企业版</a>。
            </div>
          </Message>
        </If>
      </If>
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </div>
  );
};

export default AppDetail;
