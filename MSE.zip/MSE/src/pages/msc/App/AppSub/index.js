import React, { Suspense, useEffect, useState, useRef, useMemo } from 'react';
import SubLayout from 'layouts/SubLayout';
import IconBack from 'components/IconBack';
import { queryEncode, queryDecodeHash, changeQuery } from 'utils/queryString';
import { head, find, assign, filter, forEach, map, get } from 'lodash';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import EventCenterList from './EventCenter';
import Interface from './Interface';
import AppDetail from './AppDetail';
import AppProtect from './AppProtect';
import AppConfig from './AppConfig';
import services from 'utils/services';
import { AhasPublic } from 'pages/msc/Ahas';
import AhasMachineDetails from 'pages/ahas/AhasMachineDetails';
import AhasInterface from 'pages/ahas/AhasInterface';
import AppFlowSetting from './AppFlowSetting';
import intl from '@ali/wind-intl';

// ahas
import HistoryRecords from './HistoryRecords';
import NodeList from './NodeList';

const { Switch, Route, Router, Redirect } = window.ReactRouterDOM || window.ReactRouterDom || {};

const AppInfoSub = ({ history }) => {
  const Params = queryEncode(queryDecodeHash());
  const AppId = getParams('appId');
  const [AppName, setAppName] = useState(getParams('appName')|| getParams('ahasAppName')||'');

  useEffect(() => {
    if (!AppId) {
      history.push('/msc/app');
      return;
    }
    if (AppId && !AppName) {
      fetchAppInfo();
    }

    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AuthenticationList`, goToAuthenticationList);
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-RouteTagList`, goToRouteTagList);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AuthenticationList`, goToAuthenticationList);
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-RouteTagList`, goToRouteTagList);
    };
  }, []);

  const goToAuthenticationList = () => {
    history.push('/msc/authentication');
  };

  const goToRouteTagList = () => {
    history.push('/msc/route/tag');
  };

  const fetchAppInfo = async () => {
    const { AppName, Source } = await services.GetApplicationDetail({
      params: {
        AppId,
        Region: window.regionId
      }
    });
    if (AppName || Source) {
      // setParams('appName', AppName);
      changeQuery({ appName: AppName, accessType: Source });
      setAppName(AppName);
    }
  };

  const Menu = [
    // {
    //   key: '/msc/app/info/information',
    //   label: '应用信息',
    //   activePathPatterns: ['/msc/app/information'],
    //   visible: true,
    //   items: [
    //   ]
    // },
    {
      key: '/msc/app/info',
      label: intl('mse.msc.app.sub.application.details'),
      activePathPatterns: ['/msc/app/info'],
      to: `/msc/app/info?${Params}`,
      visible: true,
    },
    // {
    //   key: '/msc/app/info/machineDetails',
    //   label: '单机治理',
    //   tag: 'protect',
    //   to: `/msc/app/info/machineDetails?${Params}`,
    //   visible: true,
    // },
  ];
  const msc_app_ahas_protect = {
    key: '/msc/app/info/sentinel',
    label: intl('mse.msc.menu.protect'),
    activePathPatterns: ['/msc/app/sentinel'],
    visible: true,
    items: [
      {
        key: '/msc/app/info/sentinel/app',
        label: intl('mse.msc.protect.overview'),
        tag: 'protect',
        to: `/msc/app/info/sentinel/app?${Params}`,
        visible: true,
      },
      {
        key: '/msc/app/info/sentinel/apiDetails',
        label: intl('mse.msc.protect.apiDetails'),
        tag: 'apiDetails',
        to: `/msc/app/info/sentinel/apiDetails?${Params}`,
        visible: true,
      },
      {
        key: '/msc/app/info/sentinel/hotSpotMonitor',
        label: intl('mse.msc.protect.hotSpotMonitor'),
        tag: 'hotSpotMonitor',
        to: `/msc/app/info/sentinel/hotSpotMonitor?${Params}`,
        visible: true,
      },
      {
        key: '/msc/app/info/sentinel/machineManage',
        label: intl('mse.msc.protect.machineManage'),
        tag: 'machineManage',
        to: `/msc/app/info/sentinel/machineManage?${Params}`,
        visible: true,
      },
      {
        key: '/msc/app/info/sentinel/ruleManage',
        label: intl('mse.msc.protect.ruleManage'),
        tag: 'ruleManage',
        to: `/msc/app/info/sentinel/ruleManage?${Params}`,
        visible: true,
      },
      {
        key: '/msc/app/info/sentinel/sence',
        label: intl('mse.msc.protect.sence'),
        visible: true,
        tag: 'sence',
        items: [
          {
            key: '/msc/app/info/sentinel/sence/web',
            label: intl('mse.msc.protect.sence.web'),
            tag: 'sence_web',
            to: `/msc/app/info/sentinel/sence/web?${Params}`,
            visible: true,
          }
        ]
      },
      {
        key: '/msc/app/info/sentinel/appManage',
        label: intl('mse.msc.protect.appManage'),
        tag: 'appManage',
        to: `/msc/app/info/sentinel/appManage?${Params}`,
        visible: true,
      },
      {
        key: '/msc/app/info/sentinel/clusterControl',
        label: intl('mse.msc.protect.clusterControl'),
        tag: 'clusterControl',
        visible: true,
        items: [
          {
            key: '/msc/app/info/sentinel/clusterControl/config',
            label: intl('mse.msc.protect.clusterControl.config'),
            tag: 'clusterControl_config',
            to: `/msc/app/info/sentinel/clusterControl/config?${Params}`,
            visible: true,
          },
          {
            key: '/msc/app/info/sentinel/clusterControl/details',
            label: intl('mse.msc.protect.clusterControl.details'),
            tag: 'clusterControl_details',
            to: `/msc/app/info/sentinel/clusterControl/details?${Params}`,
            visible: true,
          }
        ]
      },
      {
        key: '/msc/app/info/sentinel/alarmManage',
        label: intl('mse.msc.protect.alarmManage'),
        tag: 'alarmManage',
        visible: true,
        items: [
          {
            key: '/msc/app/info/sentinel/alarmManage/rule',
            label: intl('mse.msc.protect.alarmManage.rule'),
            tag: 'alarmManage_rule',
            to: `/msc/app/info/sentinel/alarmManage/rule?${Params}`,
            visible: true,
          },
          {
            key: '/msc/app/info/sentinel/alarmManage/alarmdetails',
            label: intl('mse.msc.protect.alarmManage.details'),
            tag: 'alarmManage_details',
            to: `/msc/app/info/sentinel/alarmManage/alarmdetails?${Params}`,
            visible: true,
          }
        ]
      },
    ]
  };
  const msc_app_switch_config = {
    key: '/msc/app/info/switch',
    label: intl('mse.msc.menu.config'),
    activePathPatterns: ['/msc/app/info/switch'],
    visible: true,
    items: [
      {
        key: '/msc/app/info/switch/open',
        label: intl('mse.msc.config.applist'),
        activePathPatterns: ['/msc/app/info/switch/open'],
        to: `/msc/app/info/switch/open?${Params}`,
        tag: 'open',
        visible: true,
      },
      {
        key: '/msc/app/info/switch/history',
        label: intl('mse.msc.config.histroy'),
        activePathPatterns: ['/msc/app/info/switch/history'],
        to: `/msc/app/info/switch/history?${Params}`,
        tag: 'history',
        visible: true,
      },
      {
        key: '/msc/app/info/switch/nodelist',
        label: intl('mse.msc.config.nodelist'),
        activePathPatterns: ['/msc/app/info/switch/nodelist'],
        to: `/msc/app/info/switch/nodelist?${Params}`,
        tag: 'nodelist',
        visible: true,
      },
    ]
  };
  const msc_app_alfa_interface = {
    key: '/msc/app/info/information/interface',
    label: intl('mse.msc.app.sub.interface.details'),
    tag: 'protect',
    to: `/msc/app/info/information/interface?${Params}`,
    visible: true,
  };
  const msc_app_interface_intl = {
    key: '/msc/app/info/interface',
    label: intl('mse.msc.app.sub.interface.details'),
    activePathPatterns: ['/msc/app/info/interface'],
    to: `/msc/app/info/interface?${Params}`,
    visible: true,
  };
  const msc_app_info_set = {
    key: '/msc/app/info/set',
    label: '应用设置',
    activePathPatterns: ['/msc/app/set'],
    visible: true,
    items: [
      {
        key: '/msc/app/info/eventCenter',
        label: intl('mse.msc.app.sub.eventcenter'),
        activePathPatterns: ['/msc/app/info/eventCenter'],
        to: `/msc/app/info/eventCenter?${Params}`,
        visible: true,
      },
      {
        key: '/msc/app/info/set/flowSetting',
        label: '流控设置',
        activePathPatterns: ['/msc/app/info/set/flowSetting'],
        to: `/msc/app/info/set/flowSetting?${Params}&activeType=base`,
        visible: true,
      },
    ]
  };
  const msc_app_event_center = {
    key: '/msc/app/info/eventCenter',
    label: intl('mse.msc.app.sub.eventcenter'),
    activePathPatterns: ['/msc/app/info/eventCenter'],
    to: `/msc/app/info/eventCenter?${Params}`,
    visible: true,
  };
  if (aliwareGetCookieByKeyName('aliyun_site') !== 'INTL') {
    // Menu.splice(2, 0, msc_app_ahas_protect);
    Menu.splice(1, 0, msc_app_alfa_interface);
    Menu.splice(2, 0, msc_app_info_set);
    Menu.splice(3, 0, msc_app_switch_config);
  }
  if (aliwareGetCookieByKeyName('aliyun_site') === 'INTL') {
    Menu.splice(1, 0, msc_app_interface_intl);
    Menu.splice(2, 0, msc_app_event_center);
  }
  const Layout = () => (
    <Switch>
      <Route path="/msc/app/info/eventCenter" component={EventCenterList} />
      <Route path="/msc/app/info/interface" component={Interface} />
      <Route path="/msc/app/info/sentinel/:iframe" component={(props) => <AhasPublic {...props} AppName={AppName} urlParams={Params} />} />
      <Route path="/msc/app/info/switch/open" component={(props) => <AppConfig {...props} AppName={AppName} urlParams={Params} />} />
      <Route path="/msc/app/info/switch/history" component={(props) => <HistoryRecords {...props} AppName={AppName} urlParams={Params} />} />
      <Route path="/msc/app/info/switch/nodelist" component={(props) => <NodeList {...props} AppName={AppName} urlParams={Params} />} />
      <Route path="/msc/app/info/machineDetails" component={(props) => <AhasMachineDetails {...props} AppName={AppName} urlParams={Params} AppId={AppId} />} />
      <Route path="/msc/app/info/information/interface" component={(props) => <AhasInterface {...props} AppName={AppName} urlParams={Params} AppId={AppId} />} />
      <Route path="/msc/app/info/set/flowSetting" component={(props) => <AppFlowSetting {...props} AppName={AppName} urlParams={Params} />} />
      <Route path="/msc/app/info" component={AppDetail} />
      <Redirect to="/overview" />
    </Switch>
  );

  const newBreadCrumbList = [{
    title: intl('mse.msc.app.sub.applist'),
    link: '/msc/appList?base=list',
  }];

  const mapMenu = () => map(Menu, item => ({ link: item.key, title: item.label, isUseNamespace: item.isUseNamespace }));
  const mapMenus = (menu) => {
    let arr = [];
    forEach(menu, item => {
      if (item.items) {
        arr = arr.concat(mapMenus(item.items));
      }
      arr.push({ link: item.key, title: item.label, isUseNamespace: item.isUseNamespace });
    });
    return arr;
  };
  const subs = find(mapMenu(), item => history.location.pathname === item.link) || {};
  const sub = find(mapMenus(Menu), item => {
    return history.location.pathname === item.link;
  }) || {};
  const getMessage = () => {
    const pathname = get(history, 'location.pathname');
    //   return [
    //     {
    //       type: 'notice',
    //       text: <div>MSE 服务治理可观测能力目前处于公测中，若您对该能力感兴趣，欢迎提工单，或者加群咨询。</div>
    //     }
    //   ];
    // }
    return [];
  };

  const getBreadCrumbExpand = () => {
    const pathname = get(history, 'location.pathname');
    if (pathname === '/msc/app/info' || pathname === '/msc/app/info/interface') {
      return (
        <React.Fragment>
          {intl.html('mse.msc.app.sub.micro.service.exchange.group')}
        </React.Fragment>
      );
    }
  };
  return useMemo(() => (
    <SubLayout
      breadCrumbList={[...newBreadCrumbList, sub]}
      breadCrumbExpand={getBreadCrumbExpand()}
      items={Menu}
      message={getMessage()}
      navTag="app"
      title={
        <IconBack
          back
          text={`${sub.title || ''}(${AppName})`}
          onClick={() => {
            hashHistory.push('/msc/appList?base=list');
          }}
        />
      }
    >
      <Suspense fallback="...">
        <Router history={history}>
          <Layout />
          {/* <Route path="/msc/app/info" component={Layout} /> */}
        </Router>
      </Suspense>
    </SubLayout>
  ), []);
};

export default AppInfoSub;
