import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import AppLayout from 'containers/AppLayout';
import WidgetPermission from 'containers/WidgetPermission';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.app.sub.applist'),
  },
];
const REGION_ID = window.regionId;
const widgetProps = {
  component: 'AppList',
  searchValues: {
    regionId: REGION_ID,
  },
};

const AppList = (props) => {
  const { message, history, SwitchVersionDom = '' } = props;
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AppAccessType`, goToAccessType);
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AppInfo`, goToAppInfo);
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AppGovernance`, goToAppGovernance);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AppAccessType`, goToAccessType);
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AppInfo`, goToAppInfo);
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AppGovernance`, goToAppGovernance);
    };
  }, []);

  const goToAccessType = () => {
    history.push('/msc/appList/accessType');
  };

  const goToAppInfo = (payload) => {
    const { appId, appName, source, type } = payload;
    const link = aliwareGetCookieByKeyName('aliyun_site') !== 'INTL' ? 'dynameic_line' : 'canary';
    history.push({
      pathname: '/msc/app/info',
      search: `?appId=${appId}&appName=${appName}&accessType=${source}&type=${type || link}`,
    });
  };

  const goToAppGovernance = (payload) => {
    const { appId, appName, source, type } = payload;
    history.push({
      pathname: '/msc/app/info',
      search: `?appId=${appId}&appName=${appName}&accessType=${source}&type=${type || 'tag'}`,
    });
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      isShowNamespace
      title={intl('mse.msc.app.sub.applist')}
      message={message ? [message] : []}
    >
      <If condition={SwitchVersionDom}>
        {SwitchVersionDom}
      </If>
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

AppList.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default AppList;
