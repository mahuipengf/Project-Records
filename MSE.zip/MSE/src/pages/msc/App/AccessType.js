import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { eventEmitter } from 'utils/loadWidget';
import AppLayout from 'containers/AppLayout';
import IconBack from 'components/IconBack';
import { WIDGET_EDAS_MSC } from 'constants';
import WidgetPermission from 'containers/WidgetPermission';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.app.sub.applist'),
    link: '/msc/appList?base=list',
  },
  {
    title: intl('mse.msc.app.sub.access.mode'),
  },
];
const widgetProps = {
  component: 'AppAccessType',
  searchValues: {
    regionId: window.regionId,
  },
};

const AppAccessType = (props) => {
  const { message } = props;
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AppList`, goToAppList);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AppList`, goToAppList);
    };
  }, []);

  const goToAppList = (payload) => {
    const { history } = props;
    history.push('/msc/appList?base=list');
  };
  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={
        <IconBack
          back
          text={intl('mse.msc.app.sub.access.mode')}
        />
      }
      message={message ? [message] : []}
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

AppAccessType.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default AppAccessType;
