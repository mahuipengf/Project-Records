import React from 'react';
import WidgetPermission from 'containers/WidgetPermission';
import AppLayout from 'containers/AppLayout';
import { isEmpty } from 'lodash';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.mock'),
  },
];
const widgetProps = {
  component: 'MstMockList',
  searchValues: {
    regionId: window.regionId,
  },
};

  // 下线公告
  const getMessage = () => {
    const item = {
      type: 'notice',
      text: intl.html('mse.msc.automated_regression.notice')
    };
    return [
      item
    ];
  };

const MockList = ({ message }) => (
  <AppLayout
    breadCrumbList={breadCrumbList}
    // breadCrumbExpand={
    //   <div style={{ height: 16 }}>
    //     微服务引擎钉钉交流群：
    //     <img
    //       style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
    //       src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
    //     />
    //     <span style={{ color: '#0070cc', marginRight: 8 }}> 34754806 </span>
    //     帮助文档：
    //       <a target="_blank" href="https://help.aliyun.com/document_detail/187129.html">配置服务降级</a>
    //   </div>
    // }
    title={intl('mse.msc.menu.mock')}
    message={message ? [message] : getMessage()}
  >
    <WidgetPermission widget="msc" widgetProps={widgetProps} />
  </AppLayout>
);

export default MockList;
