import React from 'react';
import WidgetPermission from 'containers/WidgetPermission';
import AppLayout from 'containers/AppLayout';
import { isEmpty } from 'lodash';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.degrade'),
  },
];
const widgetProps = {
  component: 'MockList',
  searchValues: {
    regionId: window.regionId,
  },
};

const MockList = ({ message }) => (
  <AppLayout
    breadCrumbList={breadCrumbList}
    breadCrumbExpand={
      <div style={{ height: 16 }}>
        {/* {intl('mse.common.dingding')}：
        <img
          style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
          src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
        />
        <span style={{ color: '#0070cc', marginRight: 8 }}> 34754806 </span> */}
        {intl('mse.common.document')}：
          {intl.html('mse.msc.config.degrade')}
      </div>
    }
    title={intl('mse.msc.menu.degrade')}
    message={message ? [message] : []}
  >
    <WidgetPermission widget="msc" widgetProps={widgetProps} />
  </AppLayout>
);

export default MockList;
