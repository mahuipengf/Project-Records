import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import AppLayout from 'containers/AppLayout';
import IconBack from 'components/IconBack';
import WidgetPermission from 'containers/WidgetPermission';
import intl from '@ali/wind-intl';

const REGION_ID = window.regionId;

const Info = (props) => {
  const ClusterName = getParams('ClusterName');
  const ClusterId = getParams('ClusterId');
  const { history, message } = props;

  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-K8sClusterList`, handleGoToList);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-K8sClusterList`, handleGoToList);
    };
  }, []);

  const handleGoToList = () => {
    history.push('/msc/k8s');
  };

  const breadCrumbList = [
    {
      title: intl('mse.msc.k8sCluster.list'),
      link: '/msc/k8s',
    },
    {
      title: intl('mse.common.cluster.details'),
    },
  ];

  const widgetProps = {
    component: 'K8sClusterInfo',
    searchValues: {
      regionId: REGION_ID,
      ClusterId,
    },
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={
        <IconBack
          back
          text={`${intl('mse.common.cluster.details')}（${ClusterName || ''}）`}
        />
      }
      message={message ? [message] : []}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/170446.html"> {intl('mse.msc.k8s')}</a>
        </div>
      }
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

Info.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default Info;
