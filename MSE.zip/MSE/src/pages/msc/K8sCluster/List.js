import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import AppLayout from 'containers/AppLayout';
import WidgetPermission from 'containers/WidgetPermission';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.k8s'),
  },
];
const REGION_ID = window.regionId;
const widgetProps = {
  component: 'K8sClusterList',
  searchValues: {
    regionId: REGION_ID,
  },
};

const AppList = (props) => {
  const { message } = props;
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-K8sClusterInfo`, handleGoToInfo);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-K8sClusterInfo`, handleGoToInfo);
    };
  }, []);

  const handleGoToInfo = (payload) => {
    const { ClusterId, ClusterName } = payload;
    const { history } = props;
    history.push({
      pathname: '/msc/k8s/info',
      search: `?ClusterId=${ClusterId}&ClusterName=${ClusterName}`,
    });
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.msc.menu.k8s')}
      message={message ? [message] : []}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/170446.html"> {intl('mse.msc.k8s')}</a>
        </div>
      }
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

AppList.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default AppList;
