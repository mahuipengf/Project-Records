import React, { useEffect, useState } from 'react';
import AppLayout from 'containers/AppLayout';
import WidgetPermission from 'containers/WidgetPermission';
import MscPermissionPublic from 'components/MscPermissionPublic';
import intl from '@ali/wind-intl';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import SlidePanel from 'components/SlidePanel';
import Iframe from 'components/Iframe';
import { Icon, Loading } from '@ali/cn-design';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.lossless'),
  },
];
const widgetProps = {
  component: 'LosslessLineList',
  searchValues: {
    regionId: window.regionId,
  },
};

const LosslessList = (props) => {
  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:trigger-lossless-details`, handleShowSlidePanel);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:trigger-lossless-details`, handleShowSlidePanel);
    };
  }, []);
  const handleClose = () => setVisible(false);
  const handleShowSlidePanel = (payload) => {
    console.log('hahahaha 我触发了', payload);
    const { visible: mscVisible } = payload;
    setVisible(mscVisible);
  };
  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.msc.menu.lossless')}
      message={props.message ? [props.message('losslessTest')] : []}
    >
      <MscPermissionPublic tag={'lossless'}>
        <WidgetPermission widget="msc" widgetProps={widgetProps} />
      </MscPermissionPublic>
      <SlidePanel
        title={<div style={{ cursor: 'pointer' }} onClick={handleClose}><Icon type="wind-arrow-left" size="medium" style={{ marginRight: '8px', fontSize: '18px' }} />详情</div>}
        isShowing={visible}
        // onOk={handleSubmit}
        onClose={handleClose}
        // onCancel={handleClose}
        // isProcessing={loading}
        width={'1300px'}
      >
        <Loading visible={loading} style={{ width: '100%' }}>
          <Iframe
            scrolling="auto"
            params="https://tracing.console.aliyun.com/xtrace/#/callChain/cn-hangzhou/ce1a00008316674416852221005d0001/1667440385222/1667440985222"
            styles={{ width: '100%', border: 'none', height: 'calc(100vh - 50px)' }}
            onLoad={() => setLoading(false)}
          />
        </Loading>
      </SlidePanel>
    </AppLayout>
  );
};

export default LosslessList;
