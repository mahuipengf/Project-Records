import React from 'react';
import PropTypes from 'prop-types';
import AppLayout from 'containers/AppLayout';
import IconBack from 'components/IconBack';
import WidgetPermission from 'containers/WidgetPermission';
import intl from '@ali/wind-intl';

const REGION_ID = window.regionId;

const Info = (props) => {
  const { message } = props;
  const breadCrumbList = [
    {
      title: intl('mse.msc.menu.micro_test'),
      link: '/msc/services/test',
    },
    {
      title: intl('mse.msc.service.select.method'),
    },
  ];

  const formatterParams = (str) => {
    const arr = str.slice(1).split('&');
    const obj = {};
    for (let i in arr) {
      const arri = arr[i].split('=');
      obj[arri[0]] = arri[1] === 'undefined' ? undefined : arri[1];
    }
    return obj;
  }

  const widgetProps = {
    component: 'MethodTestPage',
    searchValues: {
      serviceType: 'springCloud',
      regionId: REGION_ID,
      value: formatterParams(props.location.search)
    },
  };


  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {/* {intl('mse.common.ding.communication.group')}
          <img
            style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
            src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
          />
          <span style={{ color: '#0070cc', marginRight: 8 }}> 31180380 </span> */}
          {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/186039.html">{intl('mse.common.test')} Spring Cloud {intl('mse.common.service')}</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/186040.html">{intl('mse.common.test')} Dubbo {intl('mse.common.service')}</a>
        </div>
      }
      title={
        <IconBack
          back
          text={intl('mse.msc.service.select.method')}
        />
      }
      message={message ? [message] : []}
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

Info.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default Info;
