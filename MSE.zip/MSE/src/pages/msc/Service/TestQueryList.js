import React, { useEffect, useState } from 'react';
import WidgetPermission from 'containers/WidgetPermission';
import { eventEmitter } from 'utils/loadWidget';
import PropTypes from 'prop-types';
import { WIDGET_EDAS_MSC } from 'constants';
import AppLayout from 'containers/AppLayout';
import { Empty } from '@ali/cn-design';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.service'), // intl('mse.msc.menu.micro_test')
  },
];
const REGION_ID = window.regionId;
const ServiceTestList = (props) => {
  const { message, history } = props;
  const widgetProps = {
    component: 'ServiceTestList',
    searchValues: {
      serviceType: 'springCloud',
      regionId: REGION_ID,
    },
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-MethodTestPage`, gotoMethodTestPage);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-MethodTestPage`, gotoMethodTestPage);
    };
  }, []);
  const formatterQuery = (obj) => {
    const arr1 = Object.keys(obj);
    const arr2 = Object.values(obj);
    let str = '';
    for (let i in arr1) {
      str += arr1[i] + '=' + arr2[i] + '&'
    }
    return str.slice(0, str.length - 1);
  }

  const gotoMethodTestPage = (payload) => {
    history.push(`/msc/services/query?${formatterQuery(payload)}`);
  }
  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {intl('mse.common.dingding')}：
          <img
            style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
            src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
          />
          <span style={{ color: '#0070cc', marginRight: 8 }}> 31180380 </span> {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/186039.html">测试 Spring Cloud 服务</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/186040.html">测试 Dubbo 服务</a>
        </div>
      }
      title={intl('mse.msc.menu.service')}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
      {/* <Empty showIcon emptyMessage="即将上线，敬请期待" /> */}
    </AppLayout>
  );
};
ServiceTestList.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};

export default ServiceTestList;
