import React, { useEffect } from 'react';
import WidgetPermission from 'containers/WidgetPermission';
import AppLayout from 'containers/AppLayout';
import PropTypes from 'prop-types';
import intl from '@ali/wind-intl';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import services from '../../../utils/services';
import { get, filter } from 'lodash';
import { lowerFirstData } from '../../../utils/transfer-data';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.service'),
  },
];
const REGION_ID = window.regionId;
const ServiceList = (props) => {
  const { message, history } = props;
  const widgetProps = {
    component: 'ServiceList',
    searchValues: {
      serviceType: 'springCloud',
      regionId: REGION_ID,
    },
  };
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-MethodTestPage`, gotoMethodTestPage);
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AppInfo`, goToAppInfo);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-MethodTestPage`, gotoMethodTestPage);
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AppInfo`, goToAppInfo);
    };
  }, []);
  const goToAppInfo = async (payload) => {
    const { edasAppId = '' } = lowerFirstData(payload);

    const res = await services.GetAppList({
      params: {
        PageNumber: 1,
        PageSize: 500,
        Region: window.regionId,
      },
    });
    const result = get(res, 'Result', []);
    const { appId, appName, source, type, namespace, regionId } = lowerFirstData(filter(result, items => items.AppId === edasAppId))[0];
    const link = aliwareGetCookieByKeyName('aliyun_site') !== 'INTL' ? 'dynameic_line' : 'canary';
    history.push({
      pathname: '/msc/appList/info',
      search: `?armsAppId=${appId}&appName=${appName}&accessType=${source}&ns=${namespace}&region=${regionId}&ahasAppName=${appName}`, // &type=${type || link}
    });
  };
  const formatterQuery = (obj) => {
    const arr1 = Object.keys(obj);
    const arr2 = Object.values(obj);
    let str = '';
    for (let i in arr1) {
      str += arr1[i] + '=' + arr2[i] + '&';
    }
    return str.slice(0, str.length - 1);
  };
  const gotoMethodTestPage = (payload) => {
    history.push(`/msc/services/query?${formatterQuery(payload)}`);
  };
  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {/* {intl('mse.common.dingding')}：
          <img
            style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
            src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
          />
          <span style={{ color: '#0070cc', marginRight: 8 }}> 34754806 </span>  */}
          {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/170451.html">{intl('msc.common.query')} Spring Cloud {intl('mse.common.service')}</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/170458.html">{intl('msc.common.query')} Dubbo {intl('mse.common.service')}</a>
        </div>
      }
      title={intl('mse.msc.menu.service')}
      message={message ? [message] : []}
      isShowNamespace
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};
ServiceList.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};

export default ServiceList;
