import React, { useEffect } from 'react';
import intl from '@ali/wind-intl';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import AppLayout from 'containers/AppLayout';
import PropTypes from 'prop-types';
import IconBack from 'components/IconBack';
import WidgetPermission from 'containers/WidgetPermission';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.outlier'),
    link: '/msc/outlierEjection',
  },
  {
    title: intl('mse.msc.outelierEjection.create.outlier'),
  },
];
const REGION_ID = window.regionId;
const OutlierEjectionNew = (props) => {
  const { history, message } = props;
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-OutlierEjectionList`, goToList);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-OutlierEjectionList`, goToList);
    };
  }, []);

  const goToList = () => {
    history.push('/msc/outlierEjection');
  };

  const widgetProps = {
    component: 'OutlierEjectionNew',
    editValues: {
      regionId: REGION_ID,
      rpcType: 25, // 被调用服务应用框架，7-dubbo，25-spring cloude
    },
  };
  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={<IconBack back text={intl('mse.msc.outelierEjection.create.outlier')} />}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

OutlierEjectionNew.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default OutlierEjectionNew;
