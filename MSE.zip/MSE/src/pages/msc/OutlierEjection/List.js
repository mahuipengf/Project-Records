import React, { useEffect } from 'react';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSC } from 'constants';
import AppLayout from 'containers/AppLayout';
import PropTypes from 'prop-types';
import WidgetPermission from 'containers/WidgetPermission';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.outlier'),
  },
];
const REGION_ID = window.regionId;
const OutlierEjection = (props) => {
  const { history, message } = props;
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-OutlierEjectionNew`, goToNew);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-OutlierEjectionNew`, goToNew);
    };
  }, []);

  const goToNew = () => {
    history.push('/msc/outlierEjection/new');
  };

  const widgetProps = {
    component: 'OutlierEjectionList',
    searchValues: {
      regionId: REGION_ID,
    },
  };
  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      // breadCrumbExpand={
      //   <div style={{ height: 16 }}>
      //     {intl('mse.common.dingding')}：
      //     <img
      //       style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
      //       src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
      //     />
      //     <span style={{ color: '#0070cc', marginRight: 8 }}> 34754806 </span> {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/170452.html">Spring Cloud {intl('mse.msc.menu.outlier')}</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/170459.html">Dubbo {intl('mse.msc.menu.outlier')}</a>
      //   </div>
      // }
      title={intl('mse.msc.menu.outlier')}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};
OutlierEjection.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default OutlierEjection;
