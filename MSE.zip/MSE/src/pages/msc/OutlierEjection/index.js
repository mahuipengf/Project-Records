import OutilierEjectionList from './List';
import OutilierEjectionNew from './New';

export {
  OutilierEjectionList,
  OutilierEjectionNew,
};
