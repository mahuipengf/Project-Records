import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_EDAS_MSC } from 'constants';
import { eventEmitter } from 'utils/loadWidget';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.grayscale'),
  },
];
const widgetProps = {
  component: 'FullLinkGrayscalekHome',
  searchValues: {
    regionId: window.regionId,
  },
};

const FullLinkGrayscale = (props) => {
  const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-SwimminLaneMonitorList`, goToSwimminLaneMonitor);
    return () => {
      return eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-SwimminLaneMonitorList`, goToSwimminLaneMonitor);
    };
  }, []);
  const goToSwimminLaneMonitor = (payload) => {
    const { history } = props;
    history.push({
      pathname: '/msc/monitor',
    });
  };
    return (
      <AppLayout
        breadCrumbList={breadCrumbList}
        breadCrumbExpand={
          <div style={{ height: 16 }}>
            {/* {intl('mse.common.dingding')}：
        <img
          style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
          src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
        />
        <span style={{ color: '#0070cc', marginRight: 8 }}> 34754806 </span>  */}
            {intl('mse.common.document')}：
            {aliyunSite === 'INTL' && (
              <span
                style={{ color: '#0070cc', cursor: 'pointer' }}
                onClick={() =>
                  window.open(
                    'https://www.alibabacloud.com/help/en/microservices-engine/latest/end-to-end-canary-release?disableWebsiteRedirect=true',
                    '_blank'
                  )
                }
              >
                {intl('mse.msc.grayscale')}
              </span>
            )}
            {aliyunSite !== 'INTL' && (
              <span
                style={{ color: '#0070cc', cursor: 'pointer' }}
                onClick={() =>
                  window.open('https://help.aliyun.com/document_detail/475424.html', '_blank')
                }
              >
                {intl('mse.msc.grayscale')}
              </span>
            )}
          </div>
        }
        title={intl('mse.msc.grayscale')}
        message={props.message ? [props.message('grayscaleTest')] : []}
        isShowNamespace
      >
        <WidgetPermission widget="msc" widgetProps={widgetProps} />
      </AppLayout>
    );
};

export default FullLinkGrayscale;
