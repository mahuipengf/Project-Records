import FullLinkGrayscaleList from './List';

export {
    FullLinkGrayscaleList,
};
