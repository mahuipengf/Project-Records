import React from 'react';
import AppLayout from 'containers/AppLayout';
import WidgetPermission from 'containers/WidgetPermission';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.grayscale'),
  },
];
const widgetProps = {
  component: 'SwimminLaneMonitorList',
  searchValues: {
    regionId: window.regionId,
  },
};

const SwimminLaneMonitorList = (props) => {
  return (
  <AppLayout
    breadCrumbList={breadCrumbList}
    title={intl('mse.msc.grayscale')}
    message={props.message ? [props.message] : []}
  >
    <WidgetPermission widget="msc" widgetProps={widgetProps} />
  </AppLayout>
  );
};

export default SwimminLaneMonitorList;
