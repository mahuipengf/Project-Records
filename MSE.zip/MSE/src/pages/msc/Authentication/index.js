import AuthenticationList from './List';

export {
  AuthenticationList,
};
