import React from 'react';
import AppLayout from 'containers/AppLayout';
import WidgetPermission from 'containers/WidgetPermission';
import intl from '@ali/wind-intl';

const REGION_ID = window.regionId;
const breadCrumbList = [
  {
    title: intl('mse.msc.menu.auth'),
  },
];
const widgetProps = {
  component: 'AuthenticationList',
  searchValues: {
    regionId: REGION_ID,
  },
};

const Authentication = ({ message }) => {
  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {/* {intl('mse.common.dingding')}：
          <img
            style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
            src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
          />
          <span style={{ color: '#0070cc', marginRight: 8 }}> 34754806 </span> */}
          {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/170450.html">Spring Cloud {intl('mse.common.service.authentication')}</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/170457.html">Dubbo {intl('mse.common.service.authentication')}</a>
        </div>
      }
      title={intl('mse.msc.menu.auth')}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default Authentication;
