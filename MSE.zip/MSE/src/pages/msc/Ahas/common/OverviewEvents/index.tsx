import ChartsDialog from '../ChartsDialog';
import React, { FC, useState } from 'react';
import moment from 'moment';
import styles from './index.module.less';
import { Balloon } from '@alicloud/console-components';
import { pushUrl } from '@ali/sre-utils';
import { useDispatch } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';
import intl from '@ali/wind-intl';

interface IDataSource {
  app: string;
  gmtCreate: number;
  gmtModified: number;
  resource: string;
  eventType: number;
}
interface EventsProps {
  appEvents: IDataSource[];
}

const getParams = window.getParams;
const OverviewEvents: FC<EventsProps> = props => {
  const dispatch = useDispatch();
  const history = useHistory();
  const { appEvents } = props;
  const appName = getParams('appName')|| getParams('ahasAppName') || null;
  const ns = getParams('ns') || null;
  const region = getParams('region') || null;
  const [ visible, setVisible ] = useState(false);
  const [ resources, setResources ] = useState('');
  const [ endTime, setEndTime ] = useState(Date.parse(new Date().toString()));
  const [ startTime, setStartTime ] = useState(Date.parse(new Date().toString()) - (1000 * 60 * 30));
  const [ dialogTitle, setDialogTitle ] = useState('接口名');

  // 渲染事件类型
  function renderEventType(type: number) {
    switch (type) {
      case 0 :
        return '[限流]';
      case 1 :
        return '[调用异常]';
      case 2 :
        return '[CPU利用率过高]';
      case 3 :
        return '[熔断]';
      case 4 :
        return '[系统保护]';
      case 5 :
        return '[热点流控]';
      case 6 :
        return '[主动降级]';
      default:
        return '[--]';
    }
  }

  // 打开历史弹窗
  function handleOpenDialog(resources: string, startTime: number, endTime: number) {
    setResources(resources);
    setStartTime(startTime);
    setEndTime(endTime);
    setVisible(true);
    setDialogTitle(resources);
  }

  // 关闭历史弹窗
  function handleHiddin() {
    setVisible(false);
  }

  // 历史数据请求接口
  function getApi() {
    return dispatch.flowAppModel.getQueryAppResourceMetrics;
  }

  // 跳转至事件中心
  function handleGoEventsCenter() {
    window.goldlog.record('/ahas-flow.guard_api_details.browse_events_center', 'CLK', '', 'GET');
    pushUrl(history, '/msc/appList/info/eventCenter', {
      appName,
      ns,
      region,
      tabKey: 2,
      accessType: getParams('accessType'),
      armsAppId: getParams('armsAppId'),
      ahasAppName: getParams('ahasAppName') || getParams('appName') || '',
    });
  }

  const goEventList = (record) => {
    const EventType = {
      FlowRule: 'flow_control',
      IsolationRules: 'quarantine',
      CircuitBreakerRules: 'downGrade',
      HotParamRules: 'hotSpot',
      SentinelBlockFallbackDefinitions: 'behavior',
    }
    pushUrl(history, '/msc/appList/info/flowGovernment', {
      appName: getParams('appName') || getParams('ahasAppName') || '',
      ns: getParams('ns') || 'default',
      region: getParams('region') || '',
      accessType: getParams('accessType'),
      armsAppId: getParams('armsAppId') || '',
      ahasAppName: getParams('ahasAppName') || getParams('appName') || '',
      type: 'flowProtection',
      activeType: EventType[record?.EventType || 'flow_control'],
    });
  };
  return (
    <>
      <div className={styles.content}>
        <div className={styles.contentEventsTitle}>
          {intl('ahas.page.Topology.doc1')}
          <Balloon
            trigger={
              <i
                className={'iconfont icon-Ahas_chakanquanbushijian'}
                onClick={handleGoEventsCenter}
              />
            }
            closable={false}
          >
            查看事件中心
          </Balloon>
        </div>
        <ul className={styles.contentEventsBox}>
          {
            appEvents.length > 0  && (
              <div className={`${styles['event-li']} ${styles['event-header']}`}>
                <span className={styles['event-type']}>{intl('ahas.page.interface.detailsevent.type')}</span>
                <span className={styles['event-time']}>{intl('ahas.page.interface.details.event.type')}</span>
                <span className={styles['event-node']}>{intl('ahas.page.interface.details.event.node')}</span>
                <span className={styles['event-id']}>{intl('ahas.page.interface.details.event.ruleid')}</span>
              </div>
            )
          }
          {
            appEvents.length > 0 ? (
              appEvents.map((item: any, index) => {
              return (
                <li key={index} className={styles['event-li']}>
                  <Balloon
                    trigger={
                      <span className={styles['event-type']}>{item.EventType}</span>
                    }
                    closable={false}
                  >
                    {item.EventType}
                  </Balloon>
                  <Balloon
                    trigger={
                      <span className={styles['event-time']}>{moment(new Date(item.TimeStamp)).format('HH:mm:ss')}</span>
                    }
                    closable={false}
                  >
                    {moment(new Date(item.TimeStamp)).format('YYYY-MM-DD HH:mm:ss')}
                  </Balloon>
                  <Balloon
                    trigger={
                      <span
                        className={styles['event-node']}
                        // onClick={() => handleOpenDialog(item.resource, item.gmtCreate, item.gmtModified)}
                      >{item.InstanceId}</span>
                    }
                    closable={false}
                  >
                    {item.InstanceId}
                  </Balloon>
                  <Balloon
                    trigger={
                      <span onClick={() => goEventList(item)} className={styles['event-id']}>{item.ExtraInfo}</span>
                      
                    }
                    closable={false}
                  >
                    {item.ExtraInfo}
                  </Balloon>
                </li>
              );
            })
            ) : (
              <div className={styles.contentEventsNoData}>{intl('mse.common.no_data')}</div>
            )
          }
        </ul>
      </div>
      <ChartsDialog
        dialogTitle={dialogTitle}
        visible={visible}
        typeCharts={'all'}
        handleHiddin={handleHiddin}
        getApi={getApi}
        resource={resources}
        startTime={startTime}
        endTime={endTime}
        title={'api'}
      />
    </>
  );
};

export default OverviewEvents;
