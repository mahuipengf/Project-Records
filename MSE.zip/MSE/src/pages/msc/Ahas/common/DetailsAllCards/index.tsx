import OverviewAllCharts from './OverviewAllCharts';
import React, { FC, useEffect, useMemo, useState } from 'react';
import _ from 'lodash';
import styles from './index.module.less';
import { Loading, Pagination } from '@alicloud/console-components';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';
import { If } from 'components/tsx-control';
import Cookie from 'js-cookie';
import intl from '@ali/wind-intl';

interface AllCardsProps {
  pageType: string;
  resourceType?: number;
  tabType?: string;
  qpsType?: string;
  nodeShowType?: string;
  routeName?: string;
  dataBase?: string;
}

interface IDataSource {
  type: number;
  resource: string;
  hasRule: boolean;
  favorite: boolean;
  processConfigurationId?: string;
}

interface IMachineData {
  privateIp: string;
  processConfigurationId: string;
  pid: number;
  parentIp: string;
  vpcId: string;
  resource: string;
  quotaList: any;
  hostname: string;
}

const DetailsAllCards: FC<AllCardsProps> = props => {
  const getParams = window.getParams;
  const { pageType, resourceType, tabType, qpsType, routeName, nodeShowType, dataBase } = props;
  const dispatch = useDispatch();
  const appName = getParams('appName')|| getParams('ahasAppName')||'';
  const appId = getParams('armsAppId');
  const ns = Cookie.get('curNamespace') || getParams('ns') || 'default';
  const region = getParams('region');
  const detailsChildTabIdx = Number(getParams('detailsChildTabIdx'));
  const [topListArr, setTopListArr] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [pageIndex, setPageIndext] = useState(1);
  const [lastTime, setLastTime] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const { backTime } = useSelector(({ flowAppModel }) => flowAppModel.apiShowTime);
  const { sortIndex, descType } = useSelector(({ flowAppModel }) => flowAppModel.sortDesc);
  const { fullScreenApi, fullScreenMac } = useSelector(({ flowAppModel }) => flowAppModel.fullScreen);
  const fullScreen = fullScreenApi || fullScreenMac;
  const pageSizeCount = fullScreen ? 12 : 6;
  const trafficType = (tabType === 'guardApp' && Number(resourceType) === -1) ? '1' : '';

  const appType = getParams('appType');
  
  useEffect(() => {
    setIsLoading(true);
    setLastTime(1);
    pageType === 'api' ? getApiTopList() : getMacTopList();
  }, [resourceType, pageIndex, backTime, sortIndex, descType, fullScreenApi, fullScreenMac, detailsChildTabIdx, nodeShowType]);

  // setInterval(() => {
  //   // 轮询请求接口charts数据
  //   pageType === 'api' ? getApiTopList() : getMacTopList();
  //   setLastTime(lastTime + 1);
  // }, 10000);

  // 请求全部接口
  async function getApiTopList() {
    if (resourceType === 1) {
      const { Data: Result = { } } = await dispatch.flowAppModel.getServicesList({
        ServiceType: resourceType === 1 ? 'springCloud' : 'dubbo',
        AppId: appId,
        PageNumber: 1,
        PageSize: 10,
        Region: region,
        Source: 'edasmsc',
        Namespace: ns,
        RegionId: region,
        AhasRegionId: region,
      });
      const serviceData = Result?.Result;
      if (serviceData.length <= 0) {
        setIsLoading(false);
        return;
      }
      const { Data } = await dispatch.flowAppModel.getServiceMethodPageWithMetrics({
        AppId: appId,
        ServiceType: dataBase === 'SQL' ? 'sql' : 'springCloud',
        ServiceName: serviceData.length > 0 && serviceData[0].ServiceName || '',
        ServiceVersion: '',
        ServiceGroup: '',
        PageSize: 10,
        PageNumber: pageIndex,
        Source: 'edasmsc',
        Region: region,
        Namespace: ns,
        RegionId: region,
        AhasRegionId: region,
        AppType:appType,
      });
      const TotalSize = _.get(Data, 'TotalSize', 0);
      const listTopData =Data.Result;
      if (listTopData.length > 0) {
        setTotalCount(TotalSize);
        setTopListArr(listTopData);
      } else {
        setTotalCount(0);
        setTopListArr([]);
      }
    } else {
      const { Data: Result = { } } = await dispatch.flowAppModel.getDubboServicePageWithMetrics({
        ServiceType: 'dubbo',
        AppId: appId,
        PageNumber: pageIndex,
        PageSize: 10,
        Region: region,
        Source: 'edasmsc',
        Namespace: ns,
        RegionId: region,
        AhasRegionId: region,
      });
      const TotalSize = _.get(Result, 'TotalSize', 0);
      const serviceData = Result?.Result || [];
      if (serviceData.length <= 0) {
        setIsLoading(false);
        return;
      }
      const listTopData = serviceData;
      if (listTopData.length > 0) {
        setTotalCount(TotalSize);
        setTopListArr(listTopData);
      } else {
        setTotalCount(0);
        setTopListArr([]);
      }
    }
    setIsLoading(false);
  }

  // 请求全部机器
  async function getMacTopList() {
    const { Result = [] } = await dispatch.flowAppModel.GetApplicationInstanceList({
      AppName: appName,
      AppId: appId,
      PageNumber: 1,
      PageSize: 10,
      Region: region,
    });
    const resultData = Result?.Result;
    resultData && resultData.length > 0 && resultData.forEach((itm: any) => {
      itm.hostname = itm.HostName;
      itm.privateIp = itm.Ip;
      itm.pid = itm.Pid;
      itm.processConfigurationId = itm.HostName;
    });
    if (resultData && resultData.length > 0) {
      setTotalCount(resultData.length);
      setTopListArr(resultData);
    } else {
      setTotalCount(0);
      setTopListArr([]);
    }
    setIsLoading(false);
  }

  // 渲染api卡片
  const renderApiCards = useMemo(() => {
    const emptyElementName = fullScreen ? styles.emptyElementFull : styles.emptyElement;
    const apiTopListNone = fullScreen ? styles.apiTopListNoneFull : styles.apiTopListNone;
    return (
      <React.Fragment>
        <If condition={topListArr.length > 0}>
            {
              topListArr.map((item: IDataSource) => {
                return (
                  <OverviewAllCharts
                    key={pageType === 'api' ? item.resource : item.processConfigurationId}
                    lastTime={lastTime}
                    dataSource={item}
                    chartDialogtitle={pageType === 'api' ? 'api' : 'machine'}
                    renderMachineName={renderMachineName}
                    RefuseQps={'show'}
                    qpsType={qpsType}
                    dataBase={dataBase}
                  />
                );
              })
            }
            <span className={emptyElementName} />
            <span className={emptyElementName} />
            <span className={emptyElementName} />
        </If>
        <If condition={!(topListArr.length > 0)}>
          <div className={apiTopListNone}>{intl('mse.common.no_data')}</div>
        </If>
      </React.Fragment>
    );
  }, [topListArr, lastTime, resourceType, nodeShowType]);

  function initMachineAllName() {
    const allMachineName:Array<string> = [];

    !!topListArr && topListArr?.forEach((item: IMachineData) => {
      item.privateIp !== '_all' && allMachineName.push(item.privateIp);
    });

    return allMachineName;
  }

  function countOccurences(ary: Array<string>, value: string) {
    return ary.reduce((a, v) => (v === value ? a + 1 : a + 0), 0);
  }

  function renderMachineName(data: IMachineData) {
    const allMachineName = initMachineAllName();
    if (countOccurences(allMachineName, data.privateIp) > 1) {
      return (
        <div className={styles.machineTitle}>
          <span>
            {data.privateIp}
          </span>
          <span className={styles.pidNum}>
            进程号:{data.pid}
          </span>
        </div>
      );
    }

    return (
      <div className={styles.textEllipsis}>
        {nodeShowType === 'hostName' ? data.hostname : data.privateIp}
      </div>
    );
  }

  // 翻页
  function handlePageIndexChange(current: number) {
    setPageIndext(current);
  }

  // 渲染排序分页
  function renderSortPagination() {
    return (
      <Pagination
        className={fullScreen ? styles.sortPaginationFull : styles.sortPagination}
        onChange={handlePageIndexChange}
        current={pageIndex}
        total={totalCount}
        pageSize={pageSizeCount}
        shape="normal"
        type="normal"
        totalRender={totalCount => `${intl('mse.register.trace.total_tip', { totalCount })}`}
      />
    );
  }

  return (
    <div className={styles.content}>
      <Loading
        visible={isLoading}
        className={styles.loadingCover}
      >
        {renderApiCards}
      </Loading>
      {!!totalCount && renderSortPagination()}
    </div>
  );
};

export default DetailsAllCards;
