import React, { FC } from 'react';
import intl from '@ali/wind-intl';
import styles from './index.module.less';

interface VersionTabProps {
  sdkVersion: string;
  agentVersion: string;
  StatusStatistics?: boolean;
}

const VersionTab: FC<VersionTabProps> = props => {
  const fixedSDKVersion = intl('ahas_sentinel.SystemGuardMachineDetails.java.sdk.version');
  const fixedAGENTVersion = intl('ahas_sentinel.SystemGuardMachineDetails.java.agent.version');
  const { sdkVersion, agentVersion, StatusStatistics } = props;

  function renderCentent() {
    if (!sdkVersion && agentVersion) {
      return (
        <>'         '<span>{'该功能，需 AHAS Java SDK 版本 >= '}</span>'
         '<span style={{ color: '#0070CC' }}>{fixedSDKVersion}</span>'

         '<span>{'或者 AHAS Java Agent 版本 >= '}</span>'
         '<span style={{ color: '#0070CC' }}>{fixedAGENTVersion}</span>'

         '<span>{'才能生效，当前 AHAS Java Agent 版本为: '}</span>'
         '<span style={{ color: '#0070CC' }}>{agentVersion}</span>'       '</>
      );
    }

    if (!sdkVersion && !agentVersion) {
      return '该功能当前仅支持JAVA应用，其他应用支持后续更新';
    }

    return (
      <>'       '<span>{'该功能，需 AHAS Java SDK 版本 >= '}</span>'
       '<span style={{ color: '#0070CC' }}>{fixedSDKVersion}</span>'

       '<span>{'或者 AHAS Java Agent 版本 >= '}</span>'
       '<span style={{ color: '#0070CC' }}>{fixedAGENTVersion}</span>'

       '<span>{'才能生效，当前 AHAS Java SDK 版本为: '}</span>'
       '<span style={{ color: '#0070CC' }}>{sdkVersion}</span>'     '</>
    );
  }

  return (
    <React.Fragment>
      <div
        className={StatusStatistics ? styles.StatusContent : styles.content}
      >
          {
            renderCentent()
          }
        </div>
      </React.Fragment>
  );
};

export default VersionTab;
