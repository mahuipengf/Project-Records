import ActionStepThree from './ActionStepThree';
// import AlarmRulesStepFour from './AlarmRulesStepFour';
import ConfigurationPreview from './ConfigurationPreview';
import FlowRulesSceneStepTwo from './FlowRulesSceneStepTwo';
import ProtectionSceneStepOne from './ProtectionSceneStepOne';
import React, { FC, useEffect, useRef, useState } from 'react';
import intl from '@ali/wind-intl';
import styles from './index.module.less';
import { Button, Dialog, Message, Step } from '@alicloud/console-components';
import { FLOW_RULES_SCENE_STEPTWO, PROTECTION_MANAGEMENT_STEPS, PROTECTION_MANAGEMENT_STEPS_ACTIVE, PROTECTION_MANAGEMENT_STEPS_SQL } from 'config/constants/flow';
import { IBindSentinelBlockFallbackDefinition } from 'config/interfaces/flowProtection';
import { If } from 'components/tsx-control';
import { compare } from 'utils/util_ahas';
import { pushUrl } from '@ali/sre-utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';

const { Item: StepItem } = Step;
const { Group: ButtonGroup } = Button;

interface IProps {
  record: any;
  onCancel: () => void;
  updateRulesList?: () => void;
  handleRuleCheck?: (value: string) => void;
  selectModel?: number;
  selectModelEnable?: boolean;
  activeType?: number;
  resource?: string;
  isGwRules?:boolean;
  isWebParamsRule?: boolean;
  dataBase?: string;
  isHotspotRulesTab?: boolean
}

const ConfigurationDialog: FC<IProps> = props => {
  const { getParams } = window;
  const { record, onCancel, updateRulesList, handleRuleCheck, selectModel, selectModelEnable, activeType = 1, resource: isApiDetails = '', isGwRules = false, isWebParamsRule = false, dataBase, isHotspotRulesTab = false } = props;
  const dispatch = useDispatch();
  const containerRef = useRef < any > (null);
  const appName = getParams('appName') || getParams('ahasAppName')|| '';
  const appId = getParams('armsAppId');
  const resType = Number(getParams('resType')) || -1;
  const [currentStep, setCurrentStep] = useState(0);
  const [visible, setVisible] = useState(false);
  const { activeResourceName, favorite, hasRule, type, pResourceName } = useSelector(({ flowAppModel }) => flowAppModel.apiDetails);
  const protectionSceneDataStepOne = JSON.parse(useSelector(({ flowAppModel }) => flowAppModel.protectionSceneDataStepOne)); // 选择防护场景数据
  const flowRuleOptionsDataStepTwo = JSON.parse(useSelector(({ flowAppModel }) => flowAppModel.flowRuleOptionsDataStepTwo)); // 配置防护规则数据
  const actionDataStepThree = JSON.parse(useSelector(({ flowAppModel }) => flowAppModel.actionDataStepThree)) || {}; // 关联的行为数据
  const { protectionType = 1, resources = '' } = protectionSceneDataStepOne;
  const { id: ruleId = 0, ruleId: webRuleId } = flowRuleOptionsDataStepTwo;
  const STEP_ITEM = checkStepsItem(protectionType);
  const STEPS_COUNT = STEP_ITEM.length;
  const isEdit = !!record;
  const sdkVersion = sessionStorage.getItem('sdkVersion') || '1.0.0';
  const fixedSDKVersion = '1.9.8';
  const agentVersion = sessionStorage.getItem('agentVersion') || '1.0.0';
  const fixedAgentVersion = '1.10.4';
  const isPassVersion = compare(sdkVersion, fixedSDKVersion) || compare(agentVersion, fixedAgentVersion);
  const isNeedUpdateWebVersion = FLOW_RULES_SCENE_STEPTWO[protectionType] === 'hotspot' && isGwRules && isWebParamsRule && !isPassVersion;
  useEffect(() => {
    isApiDetails && setStepOneData();
  }, [isApiDetails]);

  function setStepOneData() {
    const stepOneDate = {
      resources: isApiDetails,
      protectionType: activeType,
    };
    dispatch.flowAppModel.setProtectionSceneDataStepOne(JSON.stringify(stepOneDate));
  }

  useEffect(() => {
    if (record || isApiDetails) {
      const { resource = '' } = record;
      const resourceName = resource || isApiDetails;
      // querySentinelGetResourceFallback(resourceName);
      setCurrentStep(1);
    }
    return () => {
      // 清除store
      dispatch.flowAppModel.clear('protectionSceneDataStepOne');
      dispatch.flowAppModel.clear('flowRuleOptionsDataStepTwo');
      dispatch.flowAppModel.clear('actionDataStepThree');
    };
  }, []);

  // useEffect(() => {
  //   resources && querySentinelGetResourceFallback(resources);
  // }, [resources]);

  // 查询当前接口所属接口类型
  async function querySentinelGetResourceFallback(resourceName: string) {
    const defaultApiType = (resType === 1 || resType === 2) ? resType : -1;
    const { Data = {}, Success = false } = await dispatch.flowAppModel.querySentinelGetResourceFallback({
      AppName: appName,
      Resource: protectionType === 3 ? '__system_block_exception_resource__' : resourceName,
      BlockType: protectionType ? isWebParamsRule ? 11 : protectionType : 1,
    });
    let apiType = defaultApiType;
    let fallbackId = 0;
    if (Success && Data) {
      const { ResourceClassification = defaultApiType, Id = 0 } = Data;
      apiType = ResourceClassification;
      fallbackId = Id;
    }
    actionDataStepThree.TargetType = apiType;
    actionDataStepThree.FallbackId = fallbackId;
    dispatch.flowAppModel.setActionDataStepThree(JSON.stringify(actionDataStepThree));
  }

  // 校验步骤
  function checkStepsItem(type: number) {
    if (dataBase === 'SQL') {
      switch (type) {
        case 0: case 1: case 2: case 3: case 4:
          return PROTECTION_MANAGEMENT_STEPS_SQL;
        case 5: return PROTECTION_MANAGEMENT_STEPS_ACTIVE;
        case 6: return PROTECTION_MANAGEMENT_STEPS.slice(0, 2);
        default: return PROTECTION_MANAGEMENT_STEPS;
      }
    } else {
      switch (type) {
        case 0: case 1: case 3: case 4:
          return PROTECTION_MANAGEMENT_STEPS;
        case 2: return PROTECTION_MANAGEMENT_STEPS.slice(0, 2);
        case 5: return PROTECTION_MANAGEMENT_STEPS_ACTIVE;
        case 6: return PROTECTION_MANAGEMENT_STEPS.slice(0, 2);
        default: return PROTECTION_MANAGEMENT_STEPS;
      }
    }
  }

  // 步骤标题
  const steps = STEP_ITEM.map((item, index) => (
    <StepItem key={index} title={item.title} />
  ));

  // 触发校验
  function handleRuleCheckDialog() {
    let allNext = false;
    if (containerRef.current.handleCheckRuleInput) {
      allNext = containerRef.current.handleCheckRuleInput();
    }
    return allNext;
  }

  // 下一步
  function handleNextStep() {
    if (handleRuleCheckDialog()) {
      const nextStep = currentStep + 1;
      setCurrentStep(nextStep > STEPS_COUNT ? STEPS_COUNT : nextStep);
    }
  }

  // 上一步
  function handlePrevStep() {
    const prevStep = currentStep - 1;
    setCurrentStep(prevStep < 0 ? 0 : prevStep);
  }

  // 校验规则种类
  function checkRulesType() {
    switch (FLOW_RULES_SCENE_STEPTWO[protectionType]) {
      case 'flow': return fetchFlowRules;
      case 'isolate': return fetchIsolate;
      case 'fuse': return fetchFuseRules;
      case 'system': return fetchSystemRules;
      case 'hotspot': return isGwRules ? isWebParamsRule ? fetchWebParamsRules : fetchGwFlowRules : fetchHotspotRules;
      case 'activeDemote': return fetchActiveDemoteRules;
      case 'autoRetry': return fetchAutoRetryRules;
      default: return fetchFlowRules;
    }
  }

  // 新增、编辑防护规则
  function handleAddProtectionRules() {
    checkRulesType()();
  }

  // 单独步骤保存规则
  function handleEditProtectionRulesAnyStep() {
    if (handleRuleCheckDialog()) {
      // checkRulesType()();
    }
  }

  // 新增/更新流控规则
  async function fetchFlowRules() {
    let resData: any = {};
    if (!isEdit) {
      resData = await dispatch.flowAppModel.getSentinelFlowRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.RuleId = ruleId;
      resData = await dispatch.flowAppModel.getSentinelFlowRuleEdit(flowRuleOptionsDataStepTwo);
    }
    const { Code, Success = false, Message: msg = '操作失败' } = resData;
    if (Success && hasRule === false) {
      dispatch.flowAppModel.setApiActiveName({ activeResourceName, hasRule: true, favorite, type, pResourceName });
    }
    handleMessAge(Code, msg, Success);
  }

  // 新增/更新隔离规则
  async function fetchIsolate() {
    let resData: any = {};
    if (!isEdit) {
      resData = await dispatch.flowAppModel.getSentinelIsolationRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.RuleId = ruleId;
      resData = await dispatch.flowAppModel.getSentinelIsolationRuleEdit(flowRuleOptionsDataStepTwo);
    }
    const { Code, Success = false, Message: msg = '操作失败' } = resData;
    if (Success && hasRule === false) {
      dispatch.flowAppModel.setApiActiveName({ activeResourceName, hasRule: true, favorite, type, pResourceName });
    }
    handleMessAge(Code, msg, Success);
  }

  // 查看集群配置
  function handleGoClusterProtection() {
    pushUrl(history, '/flowProtection/systemGuard/systemGuardClusterProtection', {
      appName,
    });
  }

  // 流控、隔离规则返回提示校验
  function handleMessAge(Code: string, msgPointText: string, success: boolean) {
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msgPointText);
      onCancel();
    } else if (Code === 'sentinel.cluster.app.level.illegal') {
      Message.warning(intl('ahas_sentinel.systemGuard.currentLim')); // 应用需开启高级防护才能使用集群限流功能
    } else if (Code === 'sentinel.cluster.commercial.noBelonging') {
      Message.help(<span style={{ cursor: 'pointer', color: '#0070cc' }} onClick={handleGoClusterProtection}>
        该应用没有对应的集群，请先创建对应的集群或在现有集群中指定该应用(点击跳转)
      </span>);
    } else if (Code === 'sentinel.cluster.commercial.quota.insufficient') {
      Message.warning(intl('ahas_sentinel.systemGuard.insufficient')); // '该应用所在集群的 QPS 总量不足，请调整集群最大 QPS'
    } else if (Code === 'sentinel.rule.flow.estimatedMaxClusterQps.tooLarge') {
      Message.warning(intl('ahas_sentinel.systemGuard.tooLarge')); // 接口集群总 QPS过大，请确认输入是否正确'
    } else if (Code === 'sentinel.cluster.still.disabled') {
      Message.warning(intl('ahas_sentinel.systemGuard.disabled')); // '请开启集群后创建流控规则'
    } if (success) {
      if (dataBase === 'SQL') {
        const msgTips = isEdit ? intl('widget.common.save') : intl('ahas_sentinel.systemGuard.flowControl.Add');
        if (success) {
          Message.success(`${msgTips}成功`);
          updateRulesList && updateRulesList();
          onCancel();
        } else {
          Message.error(`${msgTips}失败，请重试`);
          onCancel();
        }
      } else {
        onBindSentinelBlockFallbackDefinition();
      }
    }
  }

  // 新增/更新熔断规则
  async function fetchFuseRules() {
    let resData: any = {};
    if (flowRuleOptionsDataStepTwo.timeType === 'minute') {
      flowRuleOptionsDataStepTwo.statIntervalMs *= 60;
    }
    if (!isEdit) {
      resData = await dispatch.flowAppModel.getSentinelDegradeRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      flowRuleOptionsDataStepTwo.resource = record.Resource;
      resData = await dispatch.flowAppModel.getSentinelDegradeRuleEdit(flowRuleOptionsDataStepTwo);
    }
    const { Code, Success = false, Message: msg = '操作失败' } = resData;
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msg);
      onCancel();
    } else if (Success) {
      if (dataBase === 'SQL') {
        const msgTips = isEdit ? intl('widget.common.save') : intl('ahas_sentinel.systemGuard.flowControl.Add');
        if (Success) {
          Message.success(`${msgTips}成功`);
          updateRulesList && updateRulesList();
          onCancel();
        } else {
          Message.error(`${msgTips}失败，请重试`);
          onCancel();
        }
      } else {
        onCancel();
        updateRulesList && updateRulesList();
        // if (isEdit) {
        //   actionDataStepThree.Resource = record.Resource;
        // }
        // onBindSentinelBlockFallbackDefinition();
      }
    } else {
      Message.error(msg);
    }
  }

  // 新增/更新系统规则
  async function fetchSystemRules() {
    let resData: any = {};
    if (!isEdit) {
      resData = await dispatch.flowAppModel.getSentinelSystemRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await dispatch.flowAppModel.getSentinelSystemRuleEdit(flowRuleOptionsDataStepTwo);
    }
    const { Code, Success = false, Message: msg = '操作失败' } = resData;
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msg);
      onCancel();
    } else if (Code === 'sentinel.rule.system.duplicate') {
      handleRuleCheck && handleRuleCheck(msg);
      onCancel();
    } else if (Success) {
      onBindSentinelBlockFallbackDefinition();
    } else {
      Message.error(msg);
    }
  }

  // 新增/更新热点规则
  async function fetchHotspotRules() {
    let resData: any = {};
    const newHotData: any = {
      AppName: flowRuleOptionsDataStepTwo.appName,
      RegionId: window.regionId || getParams('region'),
      AppId: getParams('armsAppId'),
      Namespace: getParams('ns'),
      Resource: activeResourceName,
      MetricType: flowRuleOptionsDataStepTwo.grade,
      Threshold: flowRuleOptionsDataStepTwo.count,
      StatIntervalMs: flowRuleOptionsDataStepTwo.durationInSec,
      burst: flowRuleOptionsDataStepTwo.burstCount,
      MaxQueueingTimeMs: flowRuleOptionsDataStepTwo.maxQueueingTimeMs,
      Enable: flowRuleOptionsDataStepTwo.enable,
      ParamIdx: flowRuleOptionsDataStepTwo.paramIdx,
      controlBehavior: flowRuleOptionsDataStepTwo.controlBehavior,
    };
    if (!isEdit) {
      resData = await dispatch.flowAppModel.CreateHotParamRule(newHotData);
    } else {
      newHotData.id = ruleId;
      resData = await dispatch.flowAppModel.UpdateHotParamRule(newHotData);
    }
    const { Code, Success = false, Message: msg = '操作失败' } = resData;
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msg);
      onCancel();
    } else if (Success) {
      if (dataBase === 'SQL') {
        const msgTips = isEdit ? intl('widget.common.save') : intl('ahas_sentinel.systemGuard.flowControl.Add');
        if (Success) {
          Message.success(`${msgTips}成功`);
          updateRulesList && updateRulesList();
          onCancel();
        } else {
          Message.error(`${msgTips}失败，请重试`);
          onCancel();
        }
      } else {
        onBindSentinelBlockFallbackDefinition();
      }
    } else {
      Message.error(msg);
    }
    if (Success && hasRule === false) {
      dispatch.flowAppModel.setApiActiveName({ activeResourceName, hasRule: true, favorite, type, pResourceName });
    }
  }

  // 新增/更新主动降级规则
  async function fetchActiveDemoteRules() {
    const { AppName, Resource, FallbackId, Id, Enabled = false } = actionDataStepThree;
    const submitData: any = {
      AppName,
      Resource,
      Enabled,
      FallbackId,
    };
    let resData: any = {};
    if (!isEdit) {
      resData = await dispatch.flowAppModel.createSentinelManualDegradeRule(submitData);
    } else {
      submitData.Id = Id;
      resData = await dispatch.flowAppModel.updateSentinelManualDegradeRule(submitData);
    }
    const msgTips = isEdit ? intl('widget.common.save') : intl('ahas_sentinel.systemGuard.flowControl.Add');
    const { Code, Success = false, Message: msg = '' } = resData;
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msg);
    } else if (Code === 'sentinel.rule.manualDegrade.resourceDuplicate') {
      Message.warning(intl('ahas_sentinel.systemGuard.FuseRules.Onlyone'));
    } else if (Success) {
      Message.success(`${msgTips}成功`);
      updateRulesList && updateRulesList();
    } else {
      Message.error(`${msgTips}失败，请重试`);
    }
    onCancel();
  }

  // 新增/更新自动重试规则
  async function fetchAutoRetryRules() {
    let resData: any = {};
    if (!isEdit) {
      resData = await dispatch.flowAppModel.getCreateSentinelRetryRule(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await dispatch.flowAppModel.getUpdateSentinelRetryRule(flowRuleOptionsDataStepTwo);
    }
    const msgTips = isEdit ? intl('widget.common.save') : intl('ahas_sentinel.systemGuard.flowControl.Add');
    const { Code, Success = false, Message: msg = '' } = resData;
    if (Code === 'sentinel.rulecount.exceed') {
      handleRuleCheck && handleRuleCheck(msg);
    } else if (Success) {
      Message.success(`${msgTips}成功`);
      updateRulesList && updateRulesList();
    } else {
      Message.error(`${msgTips}失败，请重试`);
    }
    onCancel();
  }

  // 新增/更新API流控规则
  async function fetchGwFlowRules() {
    let resData: any = {};
    if (!isEdit) {
      resData = await dispatch.flowGwModel.getSentinelGatewayFlowRuleNew(flowRuleOptionsDataStepTwo);
    } else {
      flowRuleOptionsDataStepTwo.id = ruleId;
      resData = await dispatch.flowGwModel.getSentinelGatewayFlowRuleEdit(flowRuleOptionsDataStepTwo);
    }
    const { Success = false, Message: msg = '' } = resData;
    if (Success) {
      onBindSentinelBlockFallbackDefinition();
    } else {
      Message.error(msg);
    }
  }

  // 新增/更新web参数限流规则
  async function fetchWebParamsRules() {
    let resData: any = {};
    const newWebData: any = {
      AppName: flowRuleOptionsDataStepTwo.appName,
      RegionId: window.regionId || getParams('region'),
      AppId: getParams('armsAppId'),
      Namespace: getParams('ns'),
      Resource: activeResourceName,
      MetricType: flowRuleOptionsDataStepTwo.grade,
      Threshold: flowRuleOptionsDataStepTwo.count,
      Burst: flowRuleOptionsDataStepTwo.burst,
      MaxQueueingTimeMs: flowRuleOptionsDataStepTwo.maxQueueingTimeoutMs,
      Enable: flowRuleOptionsDataStepTwo.enable,
      ParamIdx: flowRuleOptionsDataStepTwo.paramIdx,
      ControlBehavior: flowRuleOptionsDataStepTwo.controlBehavior,
      ResourceMode: flowRuleOptionsDataStepTwo.resourceMode,
      ParamItem: {
        fieldName: flowRuleOptionsDataStepTwo.fieldName,
        matchStrategy: flowRuleOptionsDataStepTwo.matchStrategy,
        parseStrategy: flowRuleOptionsDataStepTwo.parseStrategy,
        pattern: flowRuleOptionsDataStepTwo.pattern,
      },
      StatIntervalMs: flowRuleOptionsDataStepTwo.intervalSec * 1000,
    };
    if (!isEdit) {
      resData = await dispatch.flowAppModel.CreateWebFlowRule(newWebData);
    } else {
      newWebData.ruleId = record.ruleId || 0;
      resData = await dispatch.flowAppModel.UpdateWebFlowRule(newWebData);
    }
    const { Success = false, Message: msg = '' } = resData;
    if (Success) {
      onBindSentinelBlockFallbackDefinition();
      dispatch.flowAppModel.setApiActiveName({ activeResourceName, hasRule: true, favorite, type, pResourceName });
    } else {
      Message.error(msg);
    }
  }

  // 绑定限流行为
  async function onBindSentinelBlockFallbackDefinition() {
    const submitData: any = { ...actionDataStepThree };
    submitData.TargetType = protectionType ? isWebParamsRule ? 11 : protectionType : 1;
    if (protectionType === 3) {
      submitData.Resource = '__system_block_exception_resource__';
    }
    submitData.AppId = appId;
    submitData.FallbackId = actionDataStepThree.FallbackId;

    const msgTips = isEdit ? intl('widget.common.save') : intl('ahas_sentinel.systemGuard.flowControl.Add');
    const { Success = false } = await dispatch.flowAppModel.queryBindSentinelBlockFallbackDefinition(submitData);
    if (Success) {
      Message.success(`${msgTips}成功`);
      updateRulesList && updateRulesList();
    } else {
      Message.error(`${msgTips}失败，请重试`);
    }
    onCancel();
  }

  // 配置预览
  function handleConfigurationPreview() {
    setVisible(!visible);
  }

  return (
    <div className={styles.content}>
      <div className={styles.stepTitle}>
        <Step
          current={currentStep}
          direction="ver"
          shape="circle"
          readOnly
          animation
        >
          {steps}
        </Step>
      </div>
      <div className={styles.stepItem}>
        <If condition={dataBase !== 'SQL'}>
          <div className={styles.configurationContent}>
            {currentStep === 0 && <ProtectionSceneStepOne
              isEdit={isEdit}
              record={protectionSceneDataStepOne}
              wrapRef={containerRef}
              isGwRules={isGwRules}
              isWebParamsRule={isWebParamsRule}
            />}
            {currentStep === 1 && (protectionType === 5 ? <ActionStepThree
              isEdit={isEdit}
              record={actionDataStepThree}
              wrapRef={containerRef}
              isGwRules={isGwRules}
              isWebParamsRule={isWebParamsRule}
              isHotspotRulesTab={isHotspotRulesTab}
            /> : <FlowRulesSceneStepTwo
              record={flowRuleOptionsDataStepTwo}
              wrapRef={containerRef}
              handleRuleCheck={handleRuleCheck}
              selectModel={selectModel}
              selectModelEnable={selectModelEnable}
              isGwRules={isGwRules}
              isWebParamsRule={isWebParamsRule}
            />)}
            {currentStep >= 2 && (protectionType === 2 && <div style={{position: 'relative'}}>
              <div style={{position: 'absolute', width: '100%', height: '100%', zIndex: 9999, cursor: 'not-allowed'}}></div>
              <FlowRulesSceneStepTwo
                record={flowRuleOptionsDataStepTwo}
                wrapRef={containerRef}
                handleRuleCheck={handleRuleCheck}
                selectModel={selectModel}
                selectModelEnable={selectModelEnable}
                isGwRules={isGwRules}
                isWebParamsRule={isWebParamsRule}
              />
            </div>)}
            {currentStep >= 2 && (protectionType !== 6 && protectionType !== 2 && <ActionStepThree
              isEdit={isEdit}
              record={actionDataStepThree}
              wrapRef={containerRef}
              isGwRules={isGwRules}
              isWebParamsRule={isWebParamsRule}
              isHotspotRulesTab={isHotspotRulesTab}
            />)}
          </div>
        </If>
        <If condition={dataBase === 'SQL'}>
          <div className={styles.configurationContent}>
            {currentStep === 0 && <ProtectionSceneStepOne
              isEdit={isEdit}
              record={protectionSceneDataStepOne}
              wrapRef={containerRef}
              isGwRules={isGwRules}
              isWebParamsRule={isWebParamsRule}
            />}
            {currentStep >= 1 && <FlowRulesSceneStepTwo
              record={flowRuleOptionsDataStepTwo}
              wrapRef={containerRef}
              handleRuleCheck={handleRuleCheck}
              selectModel={selectModel}
              selectModelEnable={selectModelEnable}
              isGwRules={isGwRules}
              isWebParamsRule={isWebParamsRule}
            />}
          </div>
        </If>
        <ButtonGroup>
          {false && <Button onClick={handleConfigurationPreview} type="primary" disabled={currentStep === 0}> 规则预览</Button>}
          <Button onClick={handlePrevStep} type="primary" disabled={currentStep === 0 || (record && currentStep === 1 )}>{intl('widget.common.pre_step')}</Button>
          <Button onClick={handleNextStep} type="primary" disabled={currentStep === STEPS_COUNT}>{intl('widget.common.next_step')}</Button>
          {false && isEdit && (currentStep < STEPS_COUNT) && <Button onClick={() => handleEditProtectionRulesAnyStep()} type="primary">{intl('widget.common.save')}</Button>}
          {currentStep === STEPS_COUNT && <Button onClick={() => {
            handleAddProtectionRules();
            window.CN_TRACKER.send({ name:'addrule' , type:'mse-msc-addrule'},{})
            }} type="primary">{isEdit ? intl('widget.common.save') : intl('ahas_sentinel.systemGuard.flowControl.Add')}</Button>}
          <Button onClick={() => onCancel()} type="normal">{intl('mse.common.cancel')}</Button>
        </ButtonGroup>
      </div>
      {/* 配置预览弹窗 */}
      <Dialog
        title={'规则配置预览'}
        visible={visible}
        onClose={handleConfigurationPreview}
        footer={<></>}
        shouldUpdatePosition
        className={styles.addOrEditDialog}
      >
        <ConfigurationPreview />
      </Dialog>
    </div>
  );
};

export default ConfigurationDialog;
