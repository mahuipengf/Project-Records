import React, { FC } from 'react';
import styles from './index.module.less';
import { Button, Dialog, Icon } from '@alicloud/console-components';
import intl from '@ali/wind-intl';

interface AdaptiveFlowDialogProps {
  adaptiveFlowDialogVisible: boolean;
  handleDialogHidden: () => void;
  handleOk: () => void;
  adaptiveFlow: boolean;
}

const AdaptiveFlowDialog: FC<AdaptiveFlowDialogProps> = props => {
  const {
    adaptiveFlowDialogVisible,
    handleDialogHidden,
    handleOk,
    adaptiveFlow,
  } = props;

  return (
    <React.Fragment>
      <Dialog
        visible={adaptiveFlowDialogVisible}
        onClose={handleDialogHidden}
        className={styles.dialog}
        footer={
            <div>
              <Button type="primary" onClick={handleOk}>
                {adaptiveFlow ? '确定关闭' : '确定开启'}
              </Button>
              <Button onClick={handleDialogHidden}>{intl('mse.common.cancel')}</Button>
            </div>
          }
      >
          <div className={styles.dialog_content}>
            <div>
              <Icon type="warning" size="large" />
              <span className={styles.iconText}>
                你确定
                <span className={styles.iconSpan}>
                  {adaptiveFlow ? intl('mse.tag.dialog.close') : intl('ahas_sentinel.systemGuard.flowControl.Turnon')}
                </span>
                自适应流控吗？
              </span>
            </div>

            <p>
              {adaptiveFlow
                ? '关闭自适应流控之后，需要您手动在规则设置-自适应流控中设置系统规则。'
                : '开启自适应流控之后，原先手动设置的系统规则将不生效。'}
            </p>
            <p>
              详情请
              <Button
                style={{ fontSize: 12 }}
                type="primary"
                text
                onClick={() =>
                  window.open('https://help.aliyun.com/document_detail/101079.html')
                }
              >
                查看文档
              </Button>
            </p>
          </div>
        </Dialog>
      </React.Fragment>
  );
};

export default AdaptiveFlowDialog;
