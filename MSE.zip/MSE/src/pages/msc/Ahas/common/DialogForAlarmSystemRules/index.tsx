import AlarmSystemRulesAddOrEdit from '../AlarmSystemRulesAddOrEdit';
import React, { FC, useEffect, useImperativeHandle, useState } from 'react';
import styles from './index.module.less';
import { Dialog, Tab } from '@alicloud/console-components';
import { getParams } from '@ali/sre-utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';

interface IDataSource {
  type: number;
  resource: string;
  hasRule: boolean;
  favorite: boolean;
  processConfigurationId?: string;
}

interface IHaveNameGroup {
  label: string;
  value: string;
}

interface IProps {
  wrapRef: any;
  updataQueryAlertsList?: () => void;
}

const DialogForAlarmSystemRules:FC<IProps> = props => {
  const { wrapRef, updataQueryAlertsList } = props;
  const dispatch = useDispatch();
  const appName = getParams('edasAppId') || getParams('appName') || getParams('ahasAppName')|| '';
  const { activeResourceName: resourceName } = useSelector(({ flowAppModel }) => flowAppModel.apiDetails);
  const [ visibleAlerts, setVisibleAlerts ] = useState(false);
  const [ alertsType, setAlertsType ] = useState('QPS');
  const [ webApiList, setWebApiList ] = useState<IHaveNameGroup[]>([]);

  useEffect(() => {
    queryWebApiList();
  }, []);

  /* 将子组件的方法暴露给父组件 */
  useImperativeHandle(wrapRef, () => ({
    handleAddAlertsDialog,
  }));

  // 获取web场景接口list
  async function queryWebApiList() {
    const submitData: any = {
      AppName: appName,
      PageIndex: 1,
      PageSize: 1000,
      OrderBy: 0,
      Desc: true,
      AhasTimestamp: new Date().getTime(),
      ResourceType: 1,
      TrafficType: '',
    };

    const { metrics: listTopData = [] } = await dispatch.flowAppModel.getSentinelMetricListTopNResourceName(submitData);
    const resourcesData: IHaveNameGroup[] = [];
    if (listTopData.length) {
      listTopData.forEach((item: IDataSource) => {
        resourcesData.push({
          label: item.resource,
          value: item.resource,
        });
      });
    }

    if (resourcesData.length > 0) {
      setWebApiList(resourcesData);
    }
  }

  // 打开、关闭新增告警规则弹窗
  function handleAddAlertsDialog() {
    setVisibleAlerts(!visibleAlerts);
    visibleAlerts && setAlertsType('QPS');
  }

  // 切换告警类型tab
  function handleAlertsTypeChange(key: string) {
    setAlertsType(key);
  }

  return (
    <>
      {/* 新增、编辑规则 */}
      <Dialog
        title={'新增告警规则'}
        visible={visibleAlerts}
        onClose={handleAddAlertsDialog as any}
        footer={<></>}
        shouldUpdatePosition={true}
        className={styles.addOrEditDialog}
      >
        <Tab
          activeKey={alertsType}
          onChange={handleAlertsTypeChange as any}
          shape='wrapped'
          size='small'
        >
          <Tab.Item title={'流量'} key={'QPS'}></Tab.Item>
          <Tab.Item title={'时延'} key={'RT'}></Tab.Item>
        </Tab>
        <AlarmSystemRulesAddOrEdit
          type={alertsType}
          onCloseDialog={handleAddAlertsDialog}
          upDataSource={updataQueryAlertsList}
          webApiList={webApiList}
          resourceName={resourceName}
          isWebScene
        />
      </Dialog>
    </>
  );
};

export default DialogForAlarmSystemRules;
