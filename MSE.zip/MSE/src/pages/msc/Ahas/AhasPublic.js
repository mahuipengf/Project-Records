import React, { useEffect, useState, useLayoutEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
import Iframe from 'components/Iframe';

let tabKey;
const AhasPublic = ({ AppName = '', urlParams = '' }) => {
  const [_src, setSrc] = useState(null);
  const params = `MseDetailImplant=true&MseImplant=true&source=publicPts&hideSidebar=true&MseKey=appManage&MseUrlParams=${urlParams}&MseDetailsKey=apiDetails`;
  useEffect(() => {
    iframePath();
  }, []);
  window.addEventListener('message', (event) => {
    const data = event.data && event.data.MseKey;
    const params = event.data && event.data.MseUrlParams;
    const detailsKey = event.data && event.data.MseDetailsKey;
    tabKey = event.data && event.data.tabKey;
    if (data === 'appManage' && params && tabKey && detailsKey !== 'apiDetails') {
      hashHistory.push(`/msc/app/info/sentinel/appManage?${params}&tabKey=${tabKey}`);
    } else if (detailsKey === 'apiDetails' && params) {
      hashHistory.push(`/msc/app/info/sentinel/apiDetails?${params}`);
    }
  });
  const mse_x_acs_debug_http_host = sessionStorage.getItem('mse_x_acs_debug_http_host'); // mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}
  const map_src = {
    app: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardSummary?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    apiDetails: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardApiDetails?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    hotSpotMonitor: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemHotSpotMonitor?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    machineManage: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardMachineDetails?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    ruleManage: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/setRules?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    web: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardWebSceneOriented?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    appManage: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardGeneral?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    config: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardClusterProtection?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    details: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardClusterDetails?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    rule: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardAlarmRules?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
    alarmdetails: `https://ahasnext.console.aliyun.com/flowProtection/systemGuard/systemGuardAlarmDetails?ahasAppName=&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`,
  };
  const iframePath = () => {
    const arr = hashHistory.location.pathname && hashHistory.location.pathname.split('/');
    const tag = arr.length > 0 ? arr[arr.length - 1] : '';
    setSrc(map_src[tag]);
  };
  return (
    <AhasPermission tag="protect" urlParams={urlParams}>
      <Iframe
        params={_src}
        styles={{ width: '100%', border: 'none', height: 'calc(100vh - 100px)' }}
      />
    </AhasPermission>
  );
};

export default AhasPublic;
