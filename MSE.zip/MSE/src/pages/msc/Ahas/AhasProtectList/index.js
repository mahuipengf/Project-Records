import React from 'react';
import AhasPermission from 'containers/AhasPermission';
import Appcard from '../AppCard';

const AhasProtectList = (props) => {
  const { history } = props;

  return (
    <React.Fragment>
      <AhasPermission tag="flow_protect_appList" goHistory="appList">
        <Appcard history={history} />
      </AhasPermission>
    </React.Fragment>
  );
};

export default AhasProtectList;
