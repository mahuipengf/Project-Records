import React, { useState, useEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
// import { Message } from '@ali/wind';
import intl from '@ali/wind-intl';

const AhasIngressNginx = () => {
  const params = `MseImplant=true&source=publicPts&hideSidebar=true&MseTitle=${intl(
    'mse.title'
  )}&MseMenuTitle=${intl('mse.msc.menu.ingress.nginx')}&MseKey=ingressNginx`;
  window.addEventListener('message', (event) => {
    const data = (event.data.BreadCrumb && event.data.BreadCrumb.key) || '';
    if (data === 'home') {
      hashHistory.push('/home');
    } else if (data === 'ingressNginx') {
      hashHistory.push('/msc/sentinel/ingressNginx');
    }
  });
  // const message = [
  //   {
  //     type: 'notice', // intl.html('mse.msc.ahas.notice.protect')
  //     text: <div>新增了应用防护功能，该功能正在灰度中，如果需要使用欢迎提工单或者加入微服务引擎钉钉交流群：34754806，联系相关开发帮忙单独升级后再进行试用。建议在使用前先阅读相关 [<a href="https://help.aliyun.com/document_detail/416054.html" target="_blank">应用防护的使用文档</a>]。</div>
  //   }
  // ];
  const mse_x_acs_debug_http_host = sessionStorage.getItem('mse_x_acs_debug_http_host'); // mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}
  return (
    <React.Fragment>
      {/* <div style={{ paddingTop: 8, paddingLeft: 24, paddingRight: 24 }}>
        <For each="item" index="index" of={message}>
          <Message key="index" type={item.type} style={{ color: '#f68300', margin: '8px 0 8px' }}>
            {item.text}
          </Message>
        </For>
      </div> */}
      <AhasPermission tag="protect">
        <iframe
          id="ahas"
          src={`https://ahasnext.console.aliyun.com/flowProtection/systemGuardNginx?ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`}
          style={{ width: '100%', border: 'none', height: 'calc(100%)', marginTop: 8 }}
        />
      </AhasPermission>
    </React.Fragment>
  );
};

export default AhasIngressNginx;
