import React, { useState, useEffect } from 'react';
import AhasPermission from 'containers/AhasPermission';
import intl from '@ali/wind-intl';

const AhasAlarm = () => {
  const params = `MseImplant=true&source=publicPts&hideSidebar=true&MseTitle=${intl(
    'mse.title'
  )}&MseMenuTitle=${intl('mse.msc.menu.alarm')}&MseKey=alarm`;

  window.addEventListener('message', (event) => {
    const data = (event.data.BreadCrumb && event.data.BreadCrumb.key) || '';
    if (data === 'home') {
      hashHistory.push('/home');
    } else if (data === 'alarm') {
      hashHistory.push('/msc/alarm');
    }
  });
  const mse_x_acs_debug_http_host = sessionStorage.getItem('mse_x_acs_debug_http_host'); // mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}
  return (
    <React.Fragment>
      <AhasPermission tag="flow_protect">
        <iframe
          id="alarm"
          src={`https://ahasnext.console.aliyun.com/manage/alarm?iis=null&ns=default&mse_x_acs_debug_http_host=${mse_x_acs_debug_http_host}&region=${window.regionId}&${params}`}
          style={{ width: '100%', border: 'none', height: 'calc(100%)', marginTop: 8 }}
        />
      </AhasPermission>
    </React.Fragment>
  );
};

export default AhasAlarm;
