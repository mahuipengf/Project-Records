import DialogForConfiguration from '../../common/DialogForConfiguration';
import React, { FC, ReactNode, useEffect, useRef, useState } from 'react';
import SytemGuardGwChildTable from './SytemGuardGwChildTable';
import styles from './index.module.less';
import { BATCH_CLOSE, BATCH_OPEN, GRADE_TYPE, PARSE_STRATEGY_TYPE, RESOURCE_TYPE, TIMR_INTERVAL_SEC } from 'config/constants/flow';
import { Balloon, Button, Checkbox, Dialog, Message, Pagination, Search, Switch, Table } from '@alicloud/console-components';
import { IFlowRuleListAll, IGuardGwFlow, ISentinelGatewayFlowRuleList, Lengthwise } from 'config/interfaces/flowProtection';
import { compare, contentTextOfBehaviorDesc, getAppNameOnlyUseShow } from 'utils/util_ahas';
import { pushUrl } from '@ali/sre-utils';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';
import { lowerFirstData } from 'utils/transfer-data';
import intl from '@ali/wind-intl';

interface IModelList {
  AppName: string;
  Model: number;
  Enable: boolean;
  ModelName: string;
  Namespace: string;
}

interface IProps {
  resource?: string;
  showHead?: boolean; // 是否展示面包屑和title部分东西
  isGateWay?: boolean;
  setRulesCount?: (val: number) => void;
  selectModel?: number;
  selectModelEnable?: boolean;
  modelList?: IModelList[];
  isScene?: boolean;
  isWebResource?: boolean;
  isInterfaceDetails?: boolean;
}

const SystemGuardGwFlow: FC<IProps> = props => {
  const { getParams } = window;
  const { resource = '', showHead = true, isGateWay = true, selectModel, selectModelEnable, modelList, setRulesCount, isScene = false, isWebResource = false, isInterfaceDetails } = props;
  const containerRef = useRef<any>(null);
  const appName = getParams('appName') || getParams('ahasAppName')|| '';
  const ns = getParams('ns') || null;
  const region = getParams('region') || null;
  const appId = getParams('armsAppId') || '';
  const dispatch = useDispatch();
  const history = useHistory();
  let timer: NodeJS.Timeout;
  const { activeResourceName, favorite, hasRule, type, pResourceName } = useSelector(({ flowAppModel }) => flowAppModel.apiDetails);
  const [ isLoading, setIsLoading ] = useState<boolean>(true);
  const [ flowRuleList, setFlowRuleList ] = useState<any>([]);
  const [ searchValue, setSearchValue ] = useState<string>('');
  const [ page, setPage ] = useState(1);
  const [ apiItems, setApiItems ] = useState<ISentinelGatewayFlowRuleList[]>();
  const [ pageIndex, setPageIndex ] = useState(1);
  const [ totalCount, setTotalCount ] = useState(0);
  const [ checkboxChecked, setCheckboxChecked ] = useState(false);
  const [ indeterminate, setIndeterminate ] = useState(false);
  const [ switchIds, setSwitchIds ] = useState<number[]>([]);
  const { activeResourceName: resourceName } = useSelector(({ flowAppModel }) => flowAppModel.apiDetails);
  const locationSystemGuardApiDetails = window.location.hash.indexOf('systemGuardApiDetails')
  const lang = window?.aliwareGetCookieByKeyName('aliyun_lang') || 'zh'
  const comma = lang === 'zh' ? '：':':';
  const { backTime } = useSelector(({ flowAppModel }) => flowAppModel.apiShowTime);
  const endTime = new Date().getTime();

  useEffect(() => {
    isGateWay && queryGateWayList();
  }, []);

  useEffect(() => {
    !isGateWay && queryWebParamsList();
  }, [ selectModel, pageIndex, searchValue, resourceName ]);

  // 获取网关api列表数据
  async function queryGateWayList() {
    setIsLoading(true);
    const flowRuleList = await dispatch.flowGwModel.getSentinelGatewayFlowRuleListAll({
      AppName: appName,
    });
    setFlowRuleList(flowRuleList);
    if (flowRuleList.length / 10 === 1) {
      const currentPage = Math.ceil(flowRuleList.length / 10);
      setPage(Number(currentPage));
    }
    setIsLoading(false);
  }

  // 获取web参数配置列表数据
  async function queryWebParamsList() {
    setIsLoading(true);
    const { Data = {} } = await dispatch.flowAppModel.ListWebFlowRules({
      AppName: appName,
      AppId: appId,
      Model: selectModel || 0,
      ResourceSearchKey: searchValue,
      SearchKey: searchValue,
      PageIndex: pageIndex,
      PageSize: 10,
      Namespace: ns,
      Resource: resourceName && resourceName !== '_all' ? resourceName : '',
      EndTime: backTime || endTime,
    });
    const { Result = [], TotalSize: TotalCount = 0 } = Data;
    const flowRules = !isInterfaceDetails ? (lowerFirstData(Result) || []) : (resourceName ? (lowerFirstData(Result) || []) : [])
    const newflowRules = flowRules.map(item => ({ ...item, id: item.ruleId }))
    setRulesCount && setRulesCount(flowRules.length || 0);
    setFlowRuleList(newflowRules);
    setTotalCount(TotalCount);
    setIsLoading(false);
  }

  // 搜索
  function handleChange(value: ReactNode) {
    if (timer) {
      clearTimeout(timer);
    }
    setPageIndex(1);
    timer = setTimeout(() => {
      // setPage(1);
      setSearchValue(String(value));
    }, 300);
  }

  // 表格数据
  const dataSourceFilter = () => {
    return flowRuleList
      .filter(item => item.resource.indexOf(searchValue) !== -1)
      .filter((item, idx) => idx >= (page - 1) * 10 && idx < page * 10);
  };

  // 页码
  function handleOnChangePage(pageIndex: number) {
    if (isGateWay) {
      setPage(pageIndex);
    } else {
      setSwitchIds([]);
      setCheckboxChecked(false);
      setIndeterminate(false);
      setPageIndex(pageIndex);
    }
  }

  // 状态
  function renderStatus(value: boolean, index: string, record: any) {
    return (!!modelList?.length && !selectModelEnable) ? (
      <Balloon
        trigger={
          <Switch
            checked={value}
            disabled={!!modelList?.length && !selectModelEnable}
          />
        }
        closable={false}
      >
        当前规则所属方案已关闭，请开启对应方案后再进行此操作
      </Balloon>
    ) : (
      <Switch
        checked={value}
        onChange={() => handleToggleStatusOpt(value, record.ruleId)}
        disabled={!!modelList?.length && !selectModelEnable}
      />
    );
  }

  // 状态开启/关闭
  function handleToggleStatusOpt(value: boolean, id?: string | number) {
    if (!id && !switchIds.length) return;
    console.log(id ? [ id ] : switchIds, 'id ? [ id ] : switchIds-data');
    Dialog.confirm({
      content: (
        <>
          <span>{`确认${
            value
              ? intl('mse.tag.dialog.close') : intl('ahas_sentinel.systemGuard.flowControl.Turnon')}以下规则吗？`}</span>
          <br />
          {ruleIdsToStringArr(id ? [ id ] : switchIds)}
        </>
      ),
      title: intl('ahas_sentinel.systemGuard.flowControl.Tips'),
      onOk: () => { handleToggleStatus(value, id); },
    });
  }

  function findRuleById(id: number) {
    for (let i = 0; i < flowRuleList.length; i++) {
      if (flowRuleList[i].ruleId === id) {
        return flowRuleList[i];
      }
    }
    return undefined;
  }

  function flowRuleToString(rule: any) {
    const { resource, controlBehavior, threshold, paramItem = {}, burst } = rule;
    const { parseStrategy = 0 } = paramItem;
    const parseStrategyText = PARSE_STRATEGY_TYPE[parseStrategy];
    const behavior = controlBehavior ? intl('ahas_sentinel.systemGuard.flowControl.WaitingInLine') : intl('ahas_sentinel.systemGuard.flowControl.FailFast');
    return (
      `${intl('mse.apiDetail.requestGroupName')}` + comma + resource +
      `，${intl('mse.apiDetail.parameterProperties')}` + comma + parseStrategyText +
      `，${intl('ahas_sentinel.systemGuard.flowControl.FlowControlEffect')}` + comma + behavior +
      `，${intl('ahas_sentinel.systemGuard.flowControl.SingleThreshold')}` + comma + threshold +
      `，Burst Size`+ comma + burst
    );
  }

  function ruleIdsToStringArr<T extends Lengthwise>(ids: T): ReactNode {
    if (ids.length === 0) {
      return [];
    }
    const str = [];
    for (let i = 0; i < ids.length; i++) {
      const rule = findRuleById(ids[i]);
      if (rule) {
        str.push(
          <p style={{ maxWidth: '600px', wordBreak: 'break-all' }}>
            {flowRuleToString(rule)}
          </p>,
        );
      }
    }
    return str;
  }

  async function handleToggleStatus(value: boolean, id?: any) {
    let resData: any = {};
    const idz: string | number[] = id || switchIds;
    const ids =
      encodeURIComponent('[') +
      encodeURIComponent(idz as any) +
      encodeURIComponent(']');
    resData = await dispatch.flowAppModel.UpdateWebFlowRulesStatus({
      Ids: ids,
      RegionId: window.regionId,
      Status: value ? 0 : 1,
      AppName: appName,
    });
    // if (value) {
    //   if (isGateWay) {
    //     resData = await dispatch.flowGwModel.getSentinelGatewayFlowRuleOff(submitData);
    //   } else {
    //     resData = await dispatch.flowAppModel.querySentinelWebFlowRuleOffBatch({
    //       Ids: ids,
    //     });
    //   }
    // } else {
    //   if (isGateWay) {
    //     resData = await dispatch.flowGwModel.getSentinelGatewayFlowRuleOn(submitData);
    //   } else {
    //     resData = await dispatch.flowAppModel.querySentinelWebFlowRuleOnBatch({
    //       Ids: ids,
    //     });
    //   }
    // }

    const { Success = false } = resData;
    const tips = value ? intl('widget.common.close_successful') : intl('widget.common.open_successful');
    if (Success) {
      Message.success(tips);
    }

    isGateWay ? queryGateWayList() : queryWebParamsList();
  }
  // 操作
  function renderOperation(value: string, index: number, record: any) {
    return (
      <div className={styles.operation}>
        <a onClick={() => { onOpenConfigurationDialog(record); window.CN_TRACKER.send({ name:'apiDetail-webRule-webEdit' , type:'mse-msc-web-edit'},{});}}>{intl('ahas_sentinel.systemGuard.flowControl.edit')}</a>|
        <a onClick={() => { handleDeleteRule(record.ruleId); window.CN_TRACKER.send({ name: 'apiDetail-webRule-webDelete', type:'mse-msc-web-delete'},{});}}>{intl('mse.common.delete')}</a>
      </div>
    );
  }

  // 删除
  function handleDeleteRule(id: number) {
    Dialog.confirm({
      content: (
        <div>
          <span>
          {intl('mse.apiDetail.sureDeleteThisRule')}
        </span>
          {ruleIdsToStringArr([id])}
        </div>
      ),
      title: intl('ahas_sentinel.systemGuard.flowControl.Tips'),
      onOk: () => { handleDeleteOpt(id); },
    });
  }
  async function getRuleList(Resource) {
    const [flowData, IsolationData, hotData, webData] = await Promise.all([
      dispatch.flowAppModel.getSentinelFlowRuleListByPage({
        AppName: appName,
        Resource,
        MetricType: 1,
        Model: 0,
        PageIndex: 1,
        PageSize: 100,
        ResourceSearchKey: '',
        EndTime: backTime || endTime,
      }),
      dispatch.flowAppModel.getSentinelIsolationRuleListByPage({
        AppName: appName,
        Resource,
        MetricType: 0,
        Model: 0,
        PageIndex: 1,
        PageSize: 100,
        ResourceSearchKey: '',
        EndTime: backTime || endTime,
      }),
      dispatch.flowAppModel.ListHotParamRules({
        AppName: appName,
        Tags: '',
        AppId: appId,
        RegionId: region,
        Model: 0,
        PageIndex: 1,
        PageSize: 100,
        SearchKey: null,
        Resource,
        Namespace: ns,
        EndTime: backTime || endTime,
      }),
      dispatch.flowAppModel.ListWebFlowRules({
        AppName: appName,
        AppId: appId,
        Model: 0,
        ResourceSearchKey: '',
        SearchKey: '',
        PageIndex: 1,
        PageSize: 10,
        Namespace: ns,
        Resource,
        EndTime: backTime || endTime,
      })
    ]);
    const flowListData = flowData.Data.Result;
    const IsolationListData = IsolationData.Data.Result;
    const hotListData = hotData.Data.ParamFlowRules;
    const webListData = webData.Data.Result;
    return flowListData.concat(IsolationListData).concat(hotListData).concat(webListData);
  }

  async function handleDeleteOpt(id: number) {
    let resData: any = {};
    const submitData = {
      Id: id,
      Ids: [ id ],
      AppName: appName,
    };
    if (isGateWay) {
      resData = await dispatch.flowGwModel.getSentinelGatewayFlowRuleDelete(submitData);
    } else {
      resData = await dispatch.flowAppModel.DeleteWebFlowRules(submitData);
    }

    const { Success = false } = resData;
    if (Success) {
      Message.success(intl('mse.common.delete_success'));
      const ruleList =  await getRuleList(activeResourceName)
      if(ruleList && ruleList.length === 0) {
        dispatch.flowAppModel.setApiActiveName({ activeResourceName, hasRule: false, favorite, type, pResourceName });
      }
    }
    isGateWay ? queryGateWayList() : queryWebParamsList();
  }

  // API 类型/查看详情
  function renderTableType(val: number) {
    return (
      <div>
        {RESOURCE_TYPE[(val as 0 | 1)]}
      </div>
    );
  }

  // 渲染匹配类型
  const renderMatchDetails = (val: number, index: number, record: IGuardGwFlow) => {
    if (val) {
      return <Balloon
        align='l'
        trigger={<span className={styles.matchDetails}>{intl('ahas_sentinel.systemGuard.seeDetails')}</span>}
        closable={false}
      >
        <SytemGuardGwChildTable record={record} apiItemsed={apiItems}/>
      </Balloon>;
    }
    return <>--</>;
  };

  // 渲染参数属性
  const renderParseStrategy = (val: number, index: number, record: IGuardGwFlow) => {
    const { paramItem } = record;
    const { parseStrategy = 0 } = paramItem ? JSON.parse(paramItem) : {};
    return <span>{PARSE_STRATEGY_TYPE[parseStrategy]}</span>;
  };

  // 渲染单机阈值
  const renderCount = (val: number, index: number, record: any) => {
    const { statIntervalMs = 1, metricType = 0 } = record;
    const intervalSec = statIntervalMs / 1000;
    const tips = val + '个请求 / ' + TIMR_INTERVAL_SEC[intervalSec];
    return <span>{metricType ? tips : val}</span>;
  };

  // 查看行为
  function handleGoToActionDetails(record: any) {
    pushUrl(history, '/msc/appList/info/flowGovernment', {
      appName: getParams('appName') || getParams('ahasAppName') || '',
      ns: getParams('ns') || 'default',
      region: getParams('region') || '',
      accessType: getParams('accessType'),
      armsAppId: getParams('armsAppId') || '',
      ahasAppName: getParams('ahasAppName') || getParams('appName') || '',
      type: 'flowProtection',
      activeType: 'behavior',
    });
  }

  // 渲染行为描述
  function renderBehaviorDesc(record: any) {
    return <div className={styles.contentTextBalloon}>
      <span>{contentTextOfBehaviorDesc(record)}</span>
      <p onClick={() => handleGoToActionDetails(record)}>{intl('ahas_sentinel.systemGuard.flowControl.viewBehaviorDetail')}</p>
    </div>;
  }

  // 渲染行为名称
  const renderFallbackName = (value: string) => {
    const record = value ? JSON.parse(value) : {};
    const { name = intl('ahas_sentinel.systemGuard.flowControl.behaviorDefault') } = record;
    return (
      <Balloon
        trigger={
          <div className={styles.contentText}>
            {name}
          </div>
        }
        closable={false}
        align='t'
      >
        {renderBehaviorDesc(record)}
      </Balloon>
    );
  };

  // 新建、编辑规则
  function onOpenConfigurationDialog(record?: any) {
    if (containerRef.current.onOpenConfigurationDialog) {
      containerRef.current.onOpenConfigurationDialog(record);
    }
  }

  function handleSelectAll() {
    if (checkboxChecked) {
      setIndeterminate(false);
      setCheckboxChecked(!checkboxChecked);
      setSwitchIds([]);
    } else {
      const switchIds:Array<number> = [];
      dataSourceFilter().forEach(item => {
        if (item.ruleId) {
          switchIds.push(item.ruleId);
        }
      });
      setIndeterminate(false);
      setCheckboxChecked(!checkboxChecked);
      setSwitchIds(switchIds);
    }
  }

  function onChange(records: Array<number>) {
    // 批量开启/关闭
    setSwitchIds(records);
  }

  function onSelectAll() {
    setIndeterminate(false);
    setCheckboxChecked(!checkboxChecked);
  }

  function onSelect(selected: boolean, record: any, records: any) {
    setCheckboxChecked(false);
    if (records.length === flowRuleList.length) {
      setIndeterminate(false);
      setCheckboxChecked(true);
      return;
    } else if (records.length) {
      setIndeterminate(true);
    } else {
      setIndeterminate(false);
    }
  }

  // 添加名称提示框
  function renderRequestGroupNameCell(
    value: string,
    index: number,
    record: { resource: string },
  ) {
    return (
      <Balloon
        trigger={
          <div className={styles.apiName}>
            {record.resource}
          </div>
        }
        closable={false}
        align='tl'
      >
        {record.resource}
      </Balloon>
    );
  } 

  const ruleType = isGateWay ? intl('mse.apiDetail.gatewayRule') : intl('mse.apiDetail.HotspotParameterProtection.HTTP');

  return (
    <div>
      <div className={isScene ? styles.searSceneObt : styles.searObt}>
        <Button
          className={styles.obtRight}
          type="primary"
          onClick={() => {
            onOpenConfigurationDialog();
            window.CN_TRACKER.send({ name: 'WebRule', type:'mse-msc-apiDetail-WebRule'},{});
          }}
        >
          {`${intl('ahas_sentinel.systemGuard.flowControl.Add')} ${ruleType}`}
        </Button>
        {locationSystemGuardApiDetails==-1 && <Search
          className={styles.serchLeft}
          key="2"
          shape="simple"
          placeholder={`${intl('ahas_sentinel.systemGuard.pleaseenter')} ${ruleType} ${intl('widget.common.name')}`}
          hasIcon={false}
          onChange={handleChange}
        />}
      </div>
      <Table
        loading={isLoading}
        dataSource={isGateWay ? dataSourceFilter() : flowRuleList}
        hasBorder={false}
        className={styles.tableHeight}
        expandedRowIndent={[ 0, 0 ]}
        rowSelection={isGateWay ? {} : { onChange, onSelectAll, onSelect, selectedRowKeys: switchIds }}
        // expandedRowRender={renderExpandedRow as any}
      >
        <Table.Column
          title={'id'}
          dataIndex="ruleId"
          width={'60px'}
        />
        <Table.Column
          title={intl('mse.apiDetail.requestGroupName')}
          dataIndex={'resource'}
          style={{ width: '120px' }}
          align={'center'}
          cell={renderRequestGroupNameCell}
        />
        {isGateWay && <Table.Column
          title={intl('mse.apiDetail.requestGroupType')}
          dataIndex={'resourceMode'}
          align={'center'}
          cell={renderTableType}
        />}
        {isGateWay && <Table.Column
          title={intl('mse.apiDetail.matchingDetails')}
          dataIndex={'resourceMode'}
          align={'center'}
          cell={renderMatchDetails}
        />}
        {isGateWay && <Table.Column
          title={intl('ahas_sentinel.systemGuard.flowControl.ThresholdType')}
          dataIndex={'grade'}
          align={'center'}
          cell={(val: number) => GRADE_TYPE[(val as 0 | 1)]}
        />}
        {!isGateWay && <Table.Column
          title={intl('mse.apiDetail.parameterProperties')}
          dataIndex="paramItem"
          align={'center'}
          cell={renderParseStrategy}
        />}
        {!isGateWay && <Table.Column
          title={intl('ahas_sentinel.systemGuard.flowControl.FlowControlEffect')}
          dataIndex="controlBehavior"
          align={'center'}
          cell={(val: number) => { return val ? intl('ahas_sentinel.systemGuard.flowControl.WaitingInLine') : intl('ahas_sentinel.systemGuard.flowControl.FailFast'); }}
        />}
        <Table.Column
          title={intl('ahas_sentinel.systemGuard.flowControl.SingleThreshold')}
          dataIndex={'threshold'}
          align={'center'}
          cell={renderCount}
        />
        {!isGateWay && <Table.Column
          title={'Burst Size'}
          dataIndex="burst"
          align={'center'}
        />}
        <Table.Column
          title={intl('ahas_sentinel.systemGuard.flowControl.behaviorName')}
          dataIndex="fallbackObject"
          align={'center'}
          cell={renderFallbackName}
        />
        <Table.Column
          title={intl('widget.common.state')}
          cell={renderStatus}
          dataIndex={'enable'}
          align={'center'}
        />
        <Table.Column
          title={intl('ahas_sentinel.systemGuard.flowControl.operating')}
          cell={renderOperation}
          align={'center'}
        />
      </Table>
      <div className={styles.bottomCon} data-wrapper="mse-msc-web-batch">
        {!isGateWay && <div className={styles.batchObt}>
          <Checkbox style={{ marginLeft: '16px' }} onClick={handleSelectAll} checked={checkboxChecked} indeterminate={indeterminate}/>

          <Button
            type="primary"
            style={{ margin: '0 8px 0 32px' }}
            onClick={() => {
              handleToggleStatusOpt(false);
            }}
            disabled={!!modelList?.length && !selectModelEnable}
            data-tracker={(!!modelList?.length && !selectModelEnable) || !switchIds?.length ? undefined : 'batchopen'}
          >
            {BATCH_OPEN}
          </Button>
          <Button
            onClick={() => {
              handleToggleStatusOpt(true);
            }}
            disabled={!!modelList?.length && !selectModelEnable}
            data-tracker={(!!modelList?.length && !selectModelEnable) || !switchIds?.length ? undefined : 'batchclose'}
          >
            {BATCH_CLOSE}
          </Button>
        </div>}
        <Pagination
          onChange={handleOnChangePage}
          className={styles.obtPage}
          pageSize={10}
          defaultCurrent={1}
          total={isGateWay ? flowRuleList.length : totalCount}
          totalRender={(total: number) => (
            <span
              style={{
                fontSize: '12px',
                color: '#555',
              }}
            >
              {intl('mse.register.trace.total_tip', { total })}
            </span>
          )}
        />
      </div>
      <DialogForConfiguration
        resource={resource}
        wrapRef={containerRef}
        updateRulesList={isGateWay ? queryGateWayList : queryWebParamsList}
        isGateWay={isGateWay}
        selectModel={selectModel}
        isWebResource={true}
        selectModelEnable={selectModelEnable}
      />
    </div>
  );
};

export default SystemGuardGwFlow;
