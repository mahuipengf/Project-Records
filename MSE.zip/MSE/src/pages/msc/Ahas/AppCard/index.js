import React, { FC, ReactNode, useEffect, useState, useRef } from 'react';
import SystemGuardPreview from './SystemGuardPreview';
import styles from './index.module.less';
import { Button, Icon, Loading, Message, Pagination, Search } from '@alicloud/console-components';
import { getCookie, setCookie } from '@ali/console-base-cookie';
import { useInterval } from '@ali/sre-utils-hooks';
import services from 'utils/services';
import AppLayout from 'containers/AppLayout';
import intl from '@ali/wind-intl';
import AppIntoDialog from 'components/AppIntoDialog';
// 应用列表父组件
const AppCard = (props) => {
  const getParams = window.getParams;
  const { message, history } = props;
  let globalData = {
    ahasAgentLivedCount: 0,
    ahasProEnable: false,
    ahasStatus: '',
    commercialSwitch: false,
    instanceCount: 0,
    onlineTime: 0,
    remainingTime: 0,
    remainingDate: 0,
    sentinelResPackCount: 0,
    sentinelRemainingResPack: 0,
    sub: false,
  };
  const [protecList, setProtecList] = useState([]);
  const [totalCount, setTotalCount] = useState(0);
  const [PageNumber, setPageNumber] = useState(1);
  const [searchValue, setSearchValue] = useState('');
  const [loading, setLoading] = useState(true);
  const [dialogType, setDialogType] = useState(false); // 进来加载弹窗
  const [alertMessage, setAlertMessage] = useState(null);
  const [postBuyUrl, setPostBuyUrl] = useState(''); // 开通专业版url
  const dialogRef = useRef();
  let timer;
  const region = getCookie('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const ns = getCookie('curNamespace') || getParams('ns') || 'default';
  const breadCrumbList = [
    {
      title: intl('mse.msc.app.sub.applist'),
    },
  ];

  useEffect(() => {
    queryCommonBuyUrl();
  }, []);

  useEffect(() => {
    setLoading(true);
    queryList();
  }, [PageNumber, searchValue, ns]);

  useInterval(() => {
    // 轮询请求接口charts数据
    queryList();
  }, 10000);

  // 接口请求；
  async function queryList() {
    const { Result = [], TotalSize = 0 } = await services.GetSystemGuardApp({
      params: {
        PageNumber,
        pageSize: 6,
        AppName: searchValue,
        RegionId: region,
        Region: region,
        Namespace: ns,
      },
    });
    if (Result && Result.length) {
      setTimeout(() => {
        setLoading(false);
      }, 200);
    } else {
      setLoading(false);
    }
    Result.length > 0 &&
      Result.forEach((element) => {
        if (element.CurMetrics && element.CurMetrics.length > 0) {
          element.CurMetrics.forEach((item) => {
            item.passedQps = item.PassQps;
            item.blockedQps = item.BlockQps;
            item.exception = item.ExpQps;
            item.timestamp = item.Timestamp;
            item.qps = item.Qps;
          });
        }
        element.app = element.AppName;
        element.latestPassQps = element.PassQps;
        element.latestBlockedQps = element.BlockQps;
        element.metric = element.CurMetrics;
      });
    setProtecList(Result);
    setTotalCount(TotalSize);
  }

  // 开通url
  function queryCommonBuyUrl() {
    const { ALIYUN_CONSOLE_CONFIG = {} } = window;
    const { CHANNEL_LINKS = {} } = ALIYUN_CONSOLE_CONFIG;
    const { post_buy = '' } = CHANNEL_LINKS;
    if (post_buy) {
      setPostBuyUrl(post_buy);
    }
  }
  // 是否要弹弹窗
  function handleTipsDialog(type) {
    if (type === 'fromKeyboard' || dialogType) {
      setCookie('isShowTpRd', '1', { domain: '', path: '', days: 5 });
    }
    setDialogType(!dialogType);
  }

  function onPaginationChange(value) {
    setPageNumber(value);
  }

  // 新应用接入
  function handleToggleInstall() {
    history.push('/msc/appList/accessType');
  }

  // 搜索
  function handleSearch(value) {
    setSearchValue(value);
  }

  function handleChange(value) {
    setPageNumber(1);
    if (timer) {
      clearTimeout(timer);
    }
    timer = setTimeout(() => {
      setSearchValue(String(value));
    }, 300);
  }
  function chartContent() {
    if (protecList && protecList.length) {
      return (
        <Loading visible={loading} style={{ width: '100%' }}>
          <div style={{ margin: '16px 0 16px 0', display: 'flow-root' }}>
            <ul className={styles.box}>
              {protecList &&
                protecList.length &&
                protecList.map((item, index) => {
                  return (
                    <li className={styles.chartCard} key={index * 2}>
                      <SystemGuardPreview
                        key={item.app}
                        appData={item}
                        appType={item.AppType}
                        isFavorite={item.favorite}
                        queryList={queryList}
                        armsAppId={item.AppId}
                        appName={item.AppName}
                        accessType={item.accessType || ''}
                      />
                    </li>
                  );
                })}
            </ul>
            <Pagination
              total={totalCount}
              current={PageNumber}
              pageSize={6}
              onChange={onPaginationChange}
              style={{ float: 'right' }}
              className={styles.obtPage}
              totalRender={(total) => (
                <span className={styles.totalInfo}>
                  {/* 共有{total}条 */}
                  {intl('mse.register.trace.total_tip', { total })}
                </span>
              )}
            />
          </div>
        </Loading>
      );
    } else if (!loading) {
      return (
        <div className={styles.noData}>
          <div className={styles.noDataImg}>
            <img src="https://img.alicdn.com/tfs/TB1fN8awFY7gK0jSZKzXXaikpXa-268-258.png" />
          </div>
          <p>{intl('ahas_sentinel.systemGuard.appCard.noDataMeaage1')}</p>
          <p>{intl('ahas_sentinel.systemGuard.appCard.noDataMeaage2')}</p>
          <p>{intl('ahas_sentinel.systemGuard.appCard.noDataMeaage3')}</p>
          <Button
            type="primary"
            style={{ marginLeft: 18 }}
            onClick={() => {
              window.goldlog.record('/ahas-switch.app_demo.check_doc', 'CLK', '', 'GET');
              window.open('https://help.aliyun.com/document_detail/170445.html');
            }}
          >
            {intl('ahas_sentinel.systemGuard.flowControl.document')}
          </Button>
        </div>
      );
    }
  }
  const { commercialSwitch, ahasStatus } = globalData;
  const shouldAlert =
    ahasStatus === '00' || ahasStatus === '01' || ahasStatus === '02' || ahasStatus === '11';
  // const handleClickOldAppList = () => {
  //   changeVTag('appList');
  //   setParams('base', 'list');
  // };
  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.msc.app.sub.applist')}
      message={message ? [message] : []}
      isShowNamespace
    >
      <div style={{ color: '#555' }}>
        <div>
          {intl.html('mse.flow.governance.ack-onepilot.version.tips')}
        </div>
      </div>
      <div>
        {commercialSwitch && shouldAlert && (
          <Message type="notice" closeable style={{ margin: '16px 0' }}>
            {alertMessage}
          </Message>
        )}
        <div style={{ marginTop: '10px' }}>
          <Button
            type="primary"
            style={{ marginRight: 8 }}
            onClick={() => dialogRef.current.open()}
          >
            {intl('mse.flow.governance.ack.app.insert')}
          </Button>
          <Button type="primary" style={{ marginRight: 8 }} onClick={handleToggleInstall}>
            {intl('ahas_sentinel.systemGuard.appCard.addApp')}
          </Button>
          <Search
            key="2"
            shape="simple"
            onSearch={handleSearch}
            onChange={handleChange}
            placeholder={intl('widget.common.input_app_name')}
            style={{ width: '30%' }}
          />
        </div>
        <div>{chartContent()}</div>
        <AppIntoDialog ref={dialogRef} />
      </div>
    </AppLayout>
  );
};

export default AppCard;
