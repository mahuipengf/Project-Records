import DataSet from '@antv/data-set';
import React, { PropsWithChildren, useEffect, useState } from 'react';
import intl from '@ali/wind-intl';
import moment from 'moment';
import './styles.less';
import { Balloon, Grid, Icon, Message } from '@alicloud/console-components';
import { compare } from '../../../../../utils/utils';
import { intlNumberUnit } from '@ali/sre-utils';
import { isEmpty, get } from 'lodash';
import { Axis, Chart, Geom, Tooltip } from 'bizcharts';
import services from 'utils/services';
import { getCookie } from '@ali/console-base-cookie';
import { signFigures } from 'utils/index';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import DialogAlert from 'components/DialogAlert';
import { useStateStore } from 'store';

// 应用列表
const { Row, Col } = Grid;

const serviceMeshSvg = <svg style={{ float: 'right' }} viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2129" width="25" height="25"><path d="M189.866667 622.933333v78.933334l328.533333 189.866666 206.933333-119.466666 21.333334 36.266666L518.4 938.666667 149.333333 725.333333v-102.4h40.533334zM518.4 166.4c19.2 0 34.133333 14.933333 34.133333 34.133333 0 14.933333-10.666667 27.733333-25.6 32v61.866667c10.666667 2.133333 19.2 12.8 23.466667 23.466667l204.8 25.6c4.266667-12.8 17.066667-21.333333 32-21.333334 19.2 0 34.133333 14.933333 34.133333 34.133334 0 19.2-14.933333 34.133333-34.133333 34.133333h-4.266667l-76.8 189.866667c8.533333 6.4 14.933333 17.066667 14.933334 27.733333 0 4.266667 0 8.533333-2.133334 10.666667l44.8 25.6c6.4-6.4 14.933333-10.666667 25.6-10.666667 19.2 0 34.133333 14.933333 34.133334 34.133333 0 19.2-14.933333 34.133333-34.133334 34.133334-19.2 0-34.133333-14.933333-34.133333-34.133334v-8.533333l-46.933333-25.6c-4.266667 4.266667-12.8 6.4-21.333334 6.4-4.266667 0-10.666667 0-14.933333-2.133333l-128 164.266666c4.266667 6.4 6.4 12.8 6.4 21.333334 0 19.2-14.933333 34.133333-34.133333 34.133333s-34.133333-14.933333-34.133334-34.133333c0-8.533333 2.133333-14.933333 6.4-21.333334L362.666667 637.866667c-4.266667 2.133333-8.533333 2.133333-12.8 2.133333-8.533333 0-17.066667-4.266667-23.466667-8.533333l-44.8 25.6c0 2.133333 2.133333 6.4 2.133333 8.533333 0 19.2-14.933333 34.133333-34.133333 34.133333s-36.266667-14.933333-36.266667-34.133333 14.933333-34.133333 34.133334-34.133333c8.533333 0 19.2 4.266667 23.466666 10.666666l44.8-25.6c0-4.266667-2.133333-6.4-2.133333-10.666666 0-10.666667 4.266667-21.333333 12.8-27.733334l-76.8-189.866666h-2.133333c-19.2 0-34.133333-14.933333-34.133334-34.133334s14.933333-34.133333 34.133334-34.133333c14.933333 0 25.6 8.533333 32 21.333333l204.8-25.6c4.266667-10.666667 12.8-21.333333 25.6-23.466666v-61.866667c-14.933333-4.266667-25.6-17.066667-25.6-32 0-17.066667 14.933333-32 34.133333-32z m0 635.733333c-10.666667 0-21.333333 8.533333-21.333333 21.333334 0 10.666667 8.533333 21.333333 21.333333 21.333333s21.333333-8.533333 21.333333-21.333333c-2.133333-12.8-10.666667-21.333333-21.333333-21.333334z m136.533333-183.466666H379.733333c-2.133333 4.266667-2.133333 6.4-6.4 8.533333l130.133334 162.133333c4.266667-2.133333 8.533333-2.133333 12.8-2.133333s8.533333 0 12.8 2.133333l128-164.266666c2.133333 0 0-4.266667-2.133334-6.4z m21.333334-441.6l211.2 121.6v426.666666L810.666667 770.133333l-21.333334-36.266666 55.466667-32V322.133333l-192-110.933333 23.466667-34.133333z m-428.8 469.333333c-10.666667 0-21.333333 8.533333-21.333334 21.333333s8.533333 21.333333 21.333334 21.333334 21.333333-8.533333 21.333333-21.333334-10.666667-21.333333-21.333333-21.333333z m541.866666 0c-10.666667 0-21.333333 8.533333-21.333333 21.333333s8.533333 21.333333 21.333333 21.333334c10.666667 0 21.333333-8.533333 21.333334-21.333334s-10.666667-21.333333-21.333334-21.333333z m-102.4-59.733333c-10.666667 0-21.333333 8.533333-21.333333 21.333333s8.533333 21.333333 21.333333 21.333333c10.666667 0 21.333333-8.533333 21.333334-21.333333s-8.533333-21.333333-21.333334-21.333333z m-337.066666 0c-10.666667 0-21.333333 8.533333-21.333334 21.333333s8.533333 21.333333 21.333334 21.333333c10.666667 0 21.333333-8.533333 21.333333-21.333333s-10.666667-21.333333-21.333333-21.333333z m168.533333-226.133334c-4.266667 0-8.533333 0-10.666667-2.133333l-132.266666 224c4.266667 4.266667 6.4 10.666667 8.533333 17.066667h270.933333c0-6.4 4.266667-12.8 8.533334-17.066667l-132.266667-226.133333c-4.266667 4.266667-8.533333 4.266667-12.8 4.266666z m-34.133333-25.6l-202.666667 25.6c-2.133333 10.666667-6.4 19.2-14.933333 23.466667l76.8 189.866667h4.266666c4.266667 0 8.533333 0 10.666667 2.133333L490.666667 352c-2.133333-6.4-4.266667-10.666667-6.4-17.066667z m59.733333 14.933334L676.266667 576c4.266667-2.133333 6.4-2.133333 10.666666-2.133333h4.266667L768 384c-6.4-6.4-12.8-12.8-12.8-23.466667l-202.666667-25.6c-2.133333 4.266667-4.266667 10.666667-8.533333 14.933334zM518.4 85.333333l91.733333 53.333334-21.333333 36.266666-70.4-40.533333-328.533333 187.733333v224H149.333333V298.666667L518.4 85.333333z m268.8 249.6c-10.666667 0-21.333333 8.533333-21.333333 21.333334s8.533333 21.333333 21.333333 21.333333 21.333333-8.533333 21.333333-21.333333-10.666667-21.333333-21.333333-21.333334z m-537.6 0c-10.666667 0-21.333333 8.533333-21.333333 21.333334s8.533333 21.333333 21.333333 21.333333c10.666667 0 21.333333-8.533333 21.333333-21.333333s-10.666667-21.333333-21.333333-21.333334z m268.8-27.733333c-10.666667 0-21.333333 8.533333-21.333333 21.333333 0 10.666667 8.533333 21.333333 21.333333 21.333334s21.333333-8.533333 21.333333-21.333334c-2.133333-12.8-10.666667-21.333333-21.333333-21.333333z m0-128c-10.666667 0-21.333333 8.533333-21.333333 21.333333s8.533333 21.333333 21.333333 21.333334 21.333333-8.533333 21.333333-21.333334-10.666667-21.333333-21.333333-21.333333z" fill="#2B85FB" p-id="2130"></path></svg>;

const SystemGuardPreview = (props) => {
  const { appData, isFavorite, queryList, armsAppId, accessType, appName, record = {}, appType } = props;
  const { metric = [], app = '', ahasAppName = '', clientVersion = {}, CurMetricsFm = {}, Source, AppId } = appData;
  const { sdkVersion = '1.0.0', agentVersion = '1.0.0' } = clientVersion;
  const stressSdkVersion = intl('ahas_sentinel.SystemGuardPreview.stressVersion'); // 1.8.5
  const stressAgentVersion = intl('ahas_sentinel.SystemGuardPreview.stressAgentVersion'); // 1.8.4
  const isPassVersion = compare(sdkVersion, stressSdkVersion) || compare(agentVersion, stressAgentVersion);
  const [fiveStars, setFiveStars] = useState(isFavorite);
  const [charList, setCharList] = useState([]);
  const { DataView } = DataSet;
  const DATUM_VERSION = intl('ahas_sentinel.SystemGuardPreview.appNewVersion'); // 1.8.6
  const isNewVersion = compare(sdkVersion, DATUM_VERSION);
  const regionId = getParams('region') !== 'public';
  const isPtsMicro = getParams('ptsMicro') === 'true';
  const region = getCookie('currentRegionId') || getParams('region') || 'cn-hangzhou';
  const ns = getParams('ns') || 'default';
  const state = useStateStore();
  const MscAccount = get(state, 'MscAccount');
  // status 2 是开通 1未开通 ，version 0 基础班 1专业版 2企业版
  const Version = get(MscAccount, 'Version');
  const cols = {
    count: {
      min: 0,
      tickCount: 5,
    },
    time: {
      alias: '时间',
      type: 'time',
      mask: 'HH:mm',
      tickCount: 5,
    },
  };

  useEffect(() => {
    initsetCharListData(metric);
  }, [metric]);

  // 跳转概览页
  async function handleGoSummary() {
    const params = `?accessType=${accessType}&armsAppId=${armsAppId || AppId}&ahasAppName=${appName}&region=${window.regionId}&appName=${appName}&ns=${ns}&appType=${appType}`;
    hashHistory.push(`/msc/appList/info${params}`);
    // if (getParams('IsImplant') || getParams('hideSidebar')) {
    //   removeParams('hideSidebar');
    // }
    // if (getParams('MseImplant') || getParams('hideSidebar')) {
    //   removeParams('hideSidebar');
    // }
    // const {
    //   Data: result = {},
    // } = await services.getSentinelQueryAppPriceLevel({
    //   params: {
    //     AppName: app,
    //     RegionId: region,
    //     Region: region,
    //     Namespace: ns,
    //     NameSpace: ns,
    //   }
    // });
    // const { CurrentLevel = 1 } = result; // 0 高级防护 1 入门级防护

    // if (isPassVersion && !CurrentLevel && regionId) {
    //   sessionStorage.setItem('isStressTab', 'true');
    // }
    // if (regionId) {
    //   sessionStorage.setItem('isStress', 'true');
    // }
    // if (isNewVersion) {
    //   sessionStorage.setItem('isNewVersion', 'true');
    // }
    // sessionStorage.setItem('CurrentAppType', appType + '');

    // sessionStorage.setItem('sdkVersion', sdkVersion);
    // sessionStorage.setItem('agentVersion', agentVersion);
    // sessionStorage.setItem('currentLevel', CurrentLevel);
    // const { Data = {}, Success = false } = await services.getGetSentinelClientVersionOfAppPage({
    //   params: {
    //     AppName: app,
    //     RegionId: region,
    //     Region: region,
    //     Namespace: ns,
    //     NameSpace: ns,
    //   }
    // });
    // if (Data && Success) {
    //   const { VersionMap = {} } = Data;
    //   // 判断是否是纯纯纯纯GO_SDK应用
    //   if (!isEmpty(VersionMap.GO_SDK) && isEmpty(VersionMap.JAVA_SDK) && isEmpty(VersionMap.JAVA_AGENT)) {
    //     sessionStorage.setItem('isOnlyGOSDK', 'true');
    //   } else {
    //     sessionStorage.setItem('isOnlyGOSDK', 'false');
    //   }
    // } else {
    //   sessionStorage.setItem('isOnlyGOSDK', 'false');
    // }
  }

  function initsetCharListData(metric) {
    let prevMetric = null;
    const qps_rt = [];
    metric.forEach((item) => {
      if (prevMetric) {
        if (item.timestamp - prevMetric.timestamp > 1000 * 10) {
          qps_rt.push({
            time: item.timestamp,
            type: intl('ahas_sentinel.systemGuard.appCard.paasQps'),
            count: 0,
          });

          qps_rt.push({
            time: item.timestamp,
            type: intl('ahas_sentinel.systemGuard.appCard.blockQps'),
            count: 0,
          });
          qps_rt.push({
            time: item.timestamp,
            type: intl('ahas_sentinel.systemGuard.appCard.paasQps'),
            count: 0,
          });

          qps_rt.push({
            time: item.timestamp,
            type: intl('ahas_sentinel.systemGuard.appCard.blockQps'),
            count: 0,
          });
        }
      }
      if (Version) {
        qps_rt.push({
          time: item.timestamp,
          type: intl('ahas_sentinel.systemGuard.appCard.paasQps'),
          count: item.passedQps,
        });
        qps_rt.push({
          time: item.timestamp,
          type: intl('ahas_sentinel.systemGuard.appCard.blockQps'),
          count: item.blockedQps,
        });
        qps_rt.push({
          time: item.timestamp,
          type: intl('ahas_sentinel.systemGuard.appCard.AllQps'),
          count: item.qps,
        });
      }
      qps_rt.push({
        time: item.timestamp,
        type: intl('ahas_sentinel.systemGuard.appCard.AllQps'),
        count: item.qps,
      });
      prevMetric = item;
      setCharList(qps_rt);
    });
  }

  // 收藏点击
  // async function switchStarFilling(e, app) {
  //   e.stopPropagation();
  //   setFiveStars(!fiveStars);
  //   if (!fiveStars) {
  //     const res = await services.getSentinelFavoriteAddFavoriteApp({
  //       params: {
  //         AppName: app,
  //         AppType: appType,
  //         RegionId: region,
  //         Region: region,
  //         Namespace: ns,
  //         NameSpace: ns,
  //       },
  //     });
  //     if (res) {
  //       Message.success(intl('ahas_sentinel.systemGuard.appCard.Collection'));
  //       queryList();
  //     }
  //   } else {
  //     const res = await services.getSentinelFavoriteDeleteFavoriteApp({
  //       params: {
  //         AppName: app,
  //         AppType: appType,
  //         RegionId: region,
  //         Region: region,
  //         Namespace: ns,
  //         NameSpace: ns,
  //       },
  //     });
  //     if (res) {
  //       Message.success(intl('ahas_sentinel.systemGuard.appCard.CancelCollection'));
  //       queryList();
  //     }
  //   }
  // }


  // 删除应用
  const handleDelete = () => {
    const dialog = DialogAlert({
      title: intl('widget.common.delete'),
      content: intl.html('widget.app.has_instance_hint', { appName }),
      onOk: () =>services.RemoveApplication({
        params: { AppId: armsAppId, Region: region }
      }).then((res) => {
        if (res) {
          Message.success(intl('widget.common.delete_successful'));
          dialog.hide()
          queryList();
        } else {
          DialogAlert({
            title: intl('widget.common.tips'),
            content: intl('widget.app.has_instance_can_not_delete'),
          });
        }
      }),
      footerActions: ['ok', 'cancel']
    });
  };

  function flowFormat(size) {
    if (!size) { return '0B'; }

    const num = 1024.00; // byte

    if (size < num) { return size + 'B'; }
    if (size < Math.pow(num, 2)) { return (size / num).toFixed(2) + 'KB'; } // kb
    if (size < Math.pow(num, 3)) { return (size / Math.pow(num, 2)).toFixed(2) + 'MB'; } // M
    if (size < Math.pow(num, 4)) { return (size / Math.pow(num, 3)).toFixed(2) + 'GB'; } // G
    return (size / Math.pow(num, 4)).toFixed(2) + 'TV'; // T
  }

  const dv = new DataView();
  dv.source(charList);
  const tagNum = appData?.Tags.length > 0 && typeof appData?.Tags[0] === 'string' ? (JSON.parse(appData.Tags[0]).length + 1) : 1;
  return (
    <>
      <div
        className={'charBox'}
        onClick={handleGoSummary}
      >
        <div>
          <p
            className={'collect'}
          >
            {/* <span
              style={{
                display: 'inline-block',
                width: '25px',
                height: '25px',
              }}
              onClick={e => switchStarFilling(e, app)}
            >
              <Icon
                type={'favorites-filling'}
                size={'small'}
                className={
                  fiveStars ? 'addCollection' : 'cancelCollection'
                }
              />
            </span> */}
            {/* 网关应用添加标记 */}
            {appType === 2 &&<img src='https://img.alicdn.com/imgextra/i3/O1CN01jXq4p01MMrdsDuKAt_!!6000000001421-2-tps-64-64.png' style={{width: '30px',height:'20px'}}/>}

            <span style={{ marginLeft: '6PX' }}>
              {ahasAppName ? ahasAppName : app}
            </span>
            {/* {appType === 2 && <Balloon type="normal" trigger={serviceMeshSvg} closable={false}>
              <div>{intl('ahas_sentinel.systemGuard.appCard.accesseFromASM')}</div>
            </Balloon>} */}
            <div
              className={'operate'}
              onClick={(e) => {
                return e.stopPropagation();
              }}>
              <Actions
                threshold={0}
                wrap="true"
                menuProps={{ style: { maxWidth: '200px' } }}
              >
                <If condition={!!record.instancesNumber}>
                  <LinkButton key="4" onClick={handleDelete} disabled>
                    <Balloon
                      align="t"
                      trigger={intl('mse.card.delete')}
                      triggerType="hover"
                    >
                      {intl('widget.app.has_instance_can_not_delete')}
                    </Balloon>
                  </LinkButton>
                </If>
                <If condition={!record.instancesNumber}>
                  <LinkButton key="4" onClick={handleDelete} >{intl('mse.card.delete')}</LinkButton>
                </If>
              </Actions>
            </div>

          </p>
          <div className={'ulRule'}>
            <Row className={'rowRule'}>
              <Col
                className={'colClor'}
                span="5"
              >
                {intl('ahas_sentinel.systemGuard.appCard.accesseType')}
              </Col>
              <Col span="7">
                <Balloon
                  closable={false}
                  offset={[10, 0]}
                  trigger={Source === 'edasmsc'? intl('mse.msc.access_method.agent_heartbeat'): (Source === 'ACK'?'ack-onepilot':Source)}
                  triggerType="hover"
                  align="r"
                >
                  {Source === 'edasmsc'? intl('mse.msc.access_method.agent_heartbeat'): (Source === 'ACK'?'ack-onepilot':Source)}
                </Balloon>
              </Col>
              <Col
                className={'colClor'}
                span={'8'}
              >
                {intl('ahas_sentinel.systemGuard.appCard.FmQps')}
              </Col>
              <Col span={'4'}>
                <Balloon
                  closable={false}
                  offset={[10, 0]}
                  trigger={CurMetricsFm.Qps}
                  triggerType="hover"
                  align="r"
                >
                  {CurMetricsFm.Qps}
                </Balloon>
              </Col>
            </Row>
            <Row className={'rowRule'}>
              <Col
                className={'colClor'}
                span="5"
              >
                {intl('ahas_sentinel.systemGuard.appCard.instanceNum')}
              </Col>
              <Col span="7">
                <Balloon
                  closable={false}
                  offset={[10, 0]}
                  trigger={appData.InstancesNumber}
                  triggerType="hover"
                  align="r"
                >
                  {appData.InstancesNumber}
                </Balloon>
              </Col>
              <Col
                className={'colClor'}
                span={'8'}
              >
                {intl('ahas_sentinel.systemGuard.appCard.FmBlockQps')}
              </Col>
              <Col span={'4'}>
                <Balloon
                  closable={false}
                  offset={[10, 0]}
                  trigger={CurMetricsFm.ExpQps}
                  triggerType="hover"
                  align="r"
                >
                  {CurMetricsFm.ExpQps}
                </Balloon>
              </Col>
            </Row>
            <Row className={'rowRule'}>
              <Col
                className={'colClor'}
                span="5"
              >
                {intl('ahas_sentinel.systemGuard.appCard.TagNum')}
              </Col>
              <Col span="7">
                <Balloon
                  closable={false}
                  offset={[10, 0]}
                  trigger={tagNum}
                  triggerType="hover"
                  align="r"
                >
                  {tagNum}
                </Balloon>
              </Col>
              <Col
                className={'colClor'}
                span={'8'}
              >
                {intl('ahas_sentinel.systemGuard.appCard.FmAverageRT')}
              </Col>
              {/* <Col span={'4'}>
                <Balloon
                  closable={false}
                  offset={[ 10, 0 ]}
                  trigger={CurMetricsFm.Rt}
                  triggerType="hover"
                  align="r"
                >
                  <React.Fragment>{CurMetricsFm.Rt} ms</React.Fragment>
                </Balloon>
              </Col> */}
              <Col span={'4'}>
                <Balloon
                  closable={false}
                  offset={[10, 0]}
                  trigger={<React.Fragment>{signFigures(Number(CurMetricsFm.Rt).toFixed(2)) || 0} ms</React.Fragment>}
                  triggerType="hover"
                  align="r"
                >
                  <React.Fragment>{signFigures(Number(CurMetricsFm.Rt).toFixed(2)) || 0} ms</React.Fragment>
                </Balloon>
              </Col>
            </Row>
          </div>
        </div>
        <div
          className={'straightline'}
        ></div>
        {charList && charList.length ? (
          <Chart
            height={165}
            data={dv}
            scale={cols}
            forceFit
            padding="auto"
          >
            <Axis
              name="time"
              line={{
                stroke: '#C4CFF3',
              }}
              tickLine={{
                stroke: '#C4CFF3',
              }}
              label={{
                textStyle: {
                  fill: '#555',
                },
              }}
            />
            <Axis
              name="count"
              grid={null}
              label={{
                textStyle: {
                  fill: '#555',
                },
                formatter: (val) => {
                  return intlNumberUnit(Number(val).toFixed(2), 1);
                },
              }}
            />
            <Tooltip />
            <Geom
              type="line"
              position="time*count"
              color={['type', ['#0070cc', '#FECB00', '#FF7D51', '#826AF9', '#5B6E90']]}
              tooltip={['time*count*type*name', (time, count, type, name) => {
                if (name === 'network') {
                  return {
                    name: type,
                    title: moment(new Date(time)).format('YYYY-MM-DD HH:mm:ss'),
                    value: flowFormat(count),
                  };
                }
                return {
                  name: type,
                  title: moment(new Date(time)).format('YYYY-MM-DD HH:mm:ss'),
                  value: count,
                };
              }]}
            />
          </Chart>
        ) : (
          <div className={'charNoData'}>
            <p>{intl('ahas_sentinel.systemGuard.flowControl.noData')}</p>
          </div>
        )}
      </div>
    </>
  );
};

export default SystemGuardPreview;
