import React, { FC, useState } from 'react';
import {
  Balloon,
  Button,
  Dialog,
  Icon,
  Radio,
} from '@alicloud/console-components';
import { DialogProps } from '@alicloud/console-components/types/dialog';
import intl from '@ali/wind-intl';
import styles from './index.module.less';

import SystemGuardFlowRuleAdd from '../../common/SystemGuardFlowRuleAdd';
import SystemGuardLevelRules from '../../common/SystemGuardLevelRules';
import {
  dialogFlowTips,
} from 'config/constants/flow';

const RadioGroup = Radio.Group;

interface DialogAndFormProps extends DialogProps {
  type: string;
  handleOpen: (type: string, value: string) => void;
  resource: string;
  onCloseDialog: () => void;
  handleRuleCheck: (val: string) => void;
}

const RuleForm: FC<DialogAndFormProps> = props => {
  const [count, setCount] = useState(1);
  const {
    type,
    handleOpen,
    resource,
    onCloseDialog,
    visible,
    handleRuleCheck,
  } = props;

  function renderForm() {
    switch (type) {
      case 'flowControl':
        return (
          <SystemGuardFlowRuleAdd
            activeType={0}
            resource={resource}
            onCloseDialog={onCloseDialog}
            noRederict={true}
            handleRuleCheck={handleRuleCheck}
            refresh={refresh}
            isQuote={true}
          />
        );
      case 'downgrade':
        return (
          <SystemGuardFlowRuleAdd
            activeType={1}
            resource={resource}
            onCloseDialog={onCloseDialog}
            noRederict={true}
            handleRuleCheck={handleRuleCheck}
            refresh={refresh}
            isQuote={true}
          />
        );
      case 'isolation':
        return (
          <SystemGuardLevelRules
            resource={resource}
            onCloseDialog={onCloseDialog}
            noRederict={true}
            handleRuleCheck={handleRuleCheck}
          />
        );
      default:
        return;
    }
  }

  function renderTitle() {
    return (
      <>
        {intl('mse.apiDetail.addRule')}&nbsp;
        <Balloon
          trigger={<Icon type="help" size="xs" style={{ marginRight: 8 }} />}
          closable={false}
          align={'r'}
        >
          <div>
            <p>
              {dialogFlowTips}
              <a href="https://help.aliyun.com/document_detail/421958.html" >
                {intl('ahas_sentinel.systemGuard.flowControlRule.document')}
              </a>
              <Icon type="external-link" size="xs" />
            </p>
            <p>
              {intl('ahas_sentinel.systemGuard.IsolationRules')}
              <a href="https://help.aliyun.com/document_detail/421959.html" >
                {intl('ahas_sentinel.systemGuard.isolation.document')}
              </a>
                <Icon type="external-link" size="xs" />
            </p>
          </div>
        </Balloon>
      </>
    );
  }

  function handleChange(value: string | number | boolean) {
    handleOpen(String(value), resource);
  }

  function refresh() {
    setCount(count + 1);
  }

  return (
    <>
      <Dialog
        title={renderTitle()}
        visible={visible}
        onClose={onCloseDialog}
        footer={false}
        shouldUpdatePosition={true}
        className={styles.dialogPanle}
      >
        <RadioGroup
          value={type}
          shape="button"
          size="small"
          onChange={value => handleChange(value as string)}
        >
          <Radio value="flowControl">流控规则</Radio>
          <Radio value="downgrade">隔离规则</Radio>
          {/* <Radio value="isolation">熔断规则</Radio> */}
        </RadioGroup>
        <div className={styles.formCard}>{renderForm()}</div>
      </Dialog>
    </>
  );
};

export default RuleForm;
