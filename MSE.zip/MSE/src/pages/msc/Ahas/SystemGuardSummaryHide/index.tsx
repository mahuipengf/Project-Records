import React, { FC, useEffect, useState } from 'react';
import { Balloon, Button, Dialog, Icon } from '@alicloud/console-components';
import { DEFAULT_BREADCRUMB_ITEM as defaultBreadCrumb } from 'config/constants';
import { getCurrentRegion } from 'utils/index';
import { useDispatch } from '@ali/sre-utils-dva';

import styles from './index.module.less';

import ChartsCard from './ChartsCard';
import DataShowCard from './DataShowCard';
import RuleForm from './RuleForm';
import StatusStatisticsTab from '../common/StatusStatisticsTab';
import SystemGuardRuleCheck from '../common/SystemGuardRuleCheck';
import SystemGuardSystemRules from '../common/SystemGuardSystemRules';
import SystemLoadCard from './SystemLoadCard';

interface IProps {
  isTop?: boolean;
}

const getParams = window.getParams;

const SystemGuardSummaryHide: FC<IProps> = props => {
  const appName = getParams('appName') || getParams('ahasAppName') || '';
  const ahasAppName = getParams('ahasAppName') || getParams('appName') || '';
  const regionId = getCurrentRegion();
  const dirtyLevel = Number(getParams('dirtyLevel'));
  const { isTop = false } = props;
  const dispatch = useDispatch();
  const [openType, setOpenType] = useState('');
  const [visible, setVisible] = useState(false);
  const [systemGuardFormVisible, setSystemGuardFormVisible] = useState(false);
  const [resource, setResource] = useState('');

  const [dialogRuleCheck, setDialogRuleCheck] = useState < boolean > (false);
  const [msgPointText, setMsgPointText] = useState < string > ('');

  useEffect(() => {
    // 设置header

    // 校验是否为sae嵌入链接
    const saeAppName = getParams('saeAppName') || null;
  }, []);

  function renderDialogTitle() {
    return (
      <React.Fragment>
        新增系统保护规则&nbsp;
        <Balloon
          trigger={<Icon type="help" size="xs" style={{ marginRight: 8 }} />}
          closable={false}
          align={'r'}
        >
          <div>
            <p>
              系统保护规则可以从系统指标维度来进行流量控制，如系统的整体
              QPS、RT、负载等。
            </p>
            <p>
              注意：系统规则只针对入口资源生效，且每种相同类型的系统保护规则最多只能存在一条。
            </p>
            <p>
              {`注意：Load 模式会在当前系统 load1
              超过阈值，且系统当前的并发线程数超过系统的容量（maxQps * minRt)
              时才会触发系统保护。`}
            </p>
            <p>
              <span>
                <Button type="primary" text>
                  点击此处查看流控规则文档。
                </Button>
                <Icon type="external-link" size="xs" className={styles.icon} />
              </span>
            </p>
          </div>
        </Balloon>
      </React.Fragment>
    );
  }

  function handleOpen(type: string, value: string) {
    setResource(value);
    switch (type) {
      case 'flowControl':
        window.goldlog.record(
          '/ahas-flow.app_summary.api_flow_btn',
          'CLK',
          '',
          'GET',
        );
        setOpenType('flowControl');
        setVisible(true);
        break;
      case 'downgrade':
        window.goldlog.record(
          '/ahas-flow.app_summary.api_degrade_btn',
          'CLK',
          '',
          'GET',
        );
        setOpenType('downgrade');
        setVisible(true);
        break;
      case 'isolation':
        window.goldlog.record(
          '/ahas-flow.app_summary.api_isolate_btn',
          'CLK',
          '',
          'GET',
        );
        setOpenType('isolation');
        setVisible(true);
        break;
      case 'systemGuard':
        setSystemGuardFormVisible(true);
        break;
      default:
    }
  }

  function handleClose() {
    setVisible(false);
  }

  function handleSystemClose() {
    setSystemGuardFormVisible(false);
  }

  function closeRuleCheck() {
    setDialogRuleCheck(false);
  }

  function handleRuleCheck(val: string) {
    setDialogRuleCheck(true);
    setMsgPointText(val);
  }

  return (
    <div>
      {!isTop && <ChartsCard />}
      {!isTop && <SystemLoadCard />}

      {
        !isTop && <div className={styles.panel}>
          <StatusStatisticsTab tabType="statusStatistics" />
        </div>
      }

      <DataShowCard handleOpen={handleOpen} isTop={isTop} />

      <RuleForm
        onCloseDialog={handleClose}
        visible={visible}
        type={openType}
        handleOpen={handleOpen}
        resource={resource}
        handleRuleCheck={handleRuleCheck}
      />

      <Dialog
        title={renderDialogTitle()}
        visible={systemGuardFormVisible}
        onClose={handleSystemClose}
        footer={false}
        className={styles.dialogPanle}
      >
        <SystemGuardSystemRules
          resource={resource}
          onCloseDialog={handleSystemClose}
          noRederict
          handleRuleCheck={handleRuleCheck}
        />
      </Dialog>

      <Dialog
        title="提示"
        visible={dialogRuleCheck}
        onClose={closeRuleCheck}
        footer={
          <Button onClick={closeRuleCheck} type="primary">
            确定
          </Button>
        }
      >
        <SystemGuardRuleCheck
          onCloseDialog={closeRuleCheck}
          appName={appName}
          msgPointText={msgPointText}
          regionId={regionId}
          dirtyLevel={dirtyLevel}
        />
      </Dialog>
    </div>
  );
};

export default SystemGuardSummaryHide;
