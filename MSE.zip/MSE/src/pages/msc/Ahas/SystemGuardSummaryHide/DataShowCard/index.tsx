import React, { FC, useEffect, useState } from 'react';
import styles from './index.module.less';
import {
  ISentinelMetricListTopNResourcesMetricSimpleReq,
  ISentinelResourceTopNMacsWithMetricsReq,
  IThermodynamicDataReq,
} from 'config/interfaces';
import { Loading, Tab } from '@alicloud/console-components';
import { SUMMARY_TAB_DEFAULT, SUMMARY_TAB_TOP } from 'config/constants/flow';
import {  pushUrl } from '@ali/sre-utils';
import { useDispatch } from '@ali/sre-utils-dva';
import { useHistory } from 'dva';
import { useInterval } from '@ali/sre-utils-hooks';

import ChartsDialog from '../../common/ChartsDialog';
import TabItem from './TabItem';
import { get } from 'lodash';
import intl from '@ali/wind-intl';

interface DataShowCardProps {
  handleOpen: (type: string, value: string) => void;
  isTop?: boolean;
}

const DataShowCard: FC<DataShowCardProps> = props => {
  const getParams = window.getParams;
  const appName = getParams('appName')|| getParams('ahasAppName') || null;
  const isPtsApp = getParams('ptsApp') === 'true' || getParams('ptsMicro') === 'true';
  const resource = '__app_summary_metric_resource_name__';
  const { handleOpen, isTop = false } = props;
  const dispatch = useDispatch();
  const history = useHistory();
  const [ type, setType ] = useState('passedQps');
  const appId = getParams('armsAppId');

  const [ heatMapData, setHeatMapData ] = useState<object[]>([]);
  const [ apiTopTableData, setApiTopTableData ] = useState<object[]>([]);
  const [ nodeTopTableData, setNodeTopTableData ] = useState<object[]>([]);
  const [ loading, setLoading ] = useState(false);
  const [ mean, setMean ] = useState(0);
  const [ mode, setMode ] = useState(0);
  // const [ dataMode, setDataMode ] = useState(0);

  const [ heatMapVisible, setHeatMapVisible ] = useState<boolean>(false);
  const [ processConfigurationId, setProcessConfigurationId ] = useState('');
  const [ dialogTitle, setDialogTitle ] = useState<string>();
  const CHECK_TAB = isTop ? SUMMARY_TAB_TOP : SUMMARY_TAB_DEFAULT;
  const SHOW_TAB_ITEM = CHECK_TAB;

  const typeStatusMap: { [key: string]: string } = {
    passedQps: 'pQps',
    blockedQps: 'bQps',
    exceptionQps: 'tQps',
    rt: 'avgRt',
  };

  const MseImplant = getParams('MseImplant') === 'true' || sessionStorage.getItem('MseImplant') === 'true';

  useEffect(() => {
    if (type !== 'systemLoad' && type !== 'statusStatistics') {
      togetherQuery();
    }
  }, [ type ]);

  useInterval(() => {
    if (type !== 'systemLoad' && type !== 'statusStatistics') {
      togetherQuery();
    }
  }, 10000);


  // 查询TOP接口数据
  async function doQueryApiTop() {
    const queryApiTopParams: any = {
      AppName: appName,
      PageIndex: 1,
      PageSize: 15,
      Type: typeStatusMap[type] ? typeStatusMap[type] : 'pQps',
      Desc: true,
      Timestamp: new Date().getTime() - (5 * 60 * 1000),
      AppId: appId,
    };

    const {
      Data = {},
    } = await dispatch.flowAppModel.getQueryResourceTopN(
      queryApiTopParams,
    );
    const ResourceOfTopNList = get(Data, 'ResourceOfTopNList', []);

    return await ResourceOfTopNList;
  }

  // 查询TOP节点数据
  async function doQueryNodeTop() {
    const timestamp = Date.parse(new Date().toString());
    const queryNodeTopParams: ISentinelResourceTopNMacsWithMetricsReq = {
      AppName: appName,
      PageIndex: 1,
      PageSize: 5,
      Type: typeStatusMap[type] ? typeStatusMap[type] : 'pQps',
      Desc: true,
      AhasTimestamp: timestamp,
      resource,
    };

    const {
      metrics: metricsNodeTop,
    } = await dispatch.flowAppModel.getSentinelResourceTopNMacsWithMetrics(
      queryNodeTopParams,
    );
    setNodeTopTableData(metricsNodeTop);

    return await metricsNodeTop;
  }

  // 数据整体查询
  async function togetherQuery() {
    const [ metricsApiTop ] = await Promise.all([
      doQueryApiTop(),
    ]);
    setApiTopTableData(metricsApiTop);
  }


  // 热力图色块颜色
  function initColor(arr: number[]) {
    // 去重
    function unique(arr: number[]) {
      return Array.from(new Set(arr));
    }
    // 判断排序
    function sortNumber(a: number, b: number) {
      return a - b;
    }

    const result = []; // 存分成10份的数组
    let endAry = []; // 如果分为10~19组时，最后几组进行合并，保证有十组
    let colorData = {}; // 最终数据
    const colorAry = [
      '#8ACFEC',
      '#89C9ED',
      '#87C2EC',
      '#85BBEB',
      '#83B5EA',
      '#82AEEB',
      '#7FA8EA',
      '#7DA2E9',
      '#7C9CE9',
      '#7B95EA',
    ];

    if (!!arr && arr.length) {
      arr = unique(arr);

      const l = arr.length;
      if (l > 10) {
        arr.sort(sortNumber);

        const sum = Math.floor(l / 10);

        for (let i = 0, len = l; i < len; i += sum) {
          result.push(arr.slice(i, i + sum));
        }

        if (result.length > 10) {
          endAry = result.splice(9, result.length - 1);
          endAry = endAry
            .toString()
            .split(',')
            .map(item => {
              return +item;
            });
          result.push(endAry);
        }
        if (result.length === 10) {
          for (let i = 0; i < 10; i++) {
            const dataArr = result[i];
            if (!!dataArr && dataArr.length) {
              for (let j = 0; j < dataArr.length; j++) {
                colorData = {
                  ...colorData,
                  [dataArr[j]]: colorAry[i],
                };
              }
            }
          }
        }
      } else {
        for (let i = 0; i < l; i++) {
          colorData = {
            ...colorData,
            [arr[i]]: colorAry[i],
          };
        }
      }
      return colorData;
    }
  }

  function initHeatMapData(data: any) {
    const chartData: object[] = [];
    const numAry: number[] = [];

    function histogramChartData() {
      data.forEach((item: any) => {
        const { innerMetric } = item;
        const { passedQps, rt, blockedQps, exception } = innerMetric;

        switch (type) {
          case 'passedQps': {
            item.passedQps = Number(passedQps);
            chartData.push(item.passedQps);
            break;
          }
          case 'blockedQps': {
            item.blockedQps = Number(blockedQps);
            chartData.push(item.blockedQps);
            break;
          }
          case 'exceptionQps': {
            item.exception = Number(exception);
            chartData.push(item.exception);
            break;
          }
          case 'rt': {
            item.rt = Number(rt);
            chartData.push(item.rt);
            break;
          }
          case 'totalQps': {
            item.passedQps = Number(rt);
            chartData.push(item.passedQps);
            break;
          }
          case 'thread': {
            item.passedQps = Number(rt);
            chartData.push(item.passedQps);
            break;
          }
          default:
            return;
        }
      });
    }

    function heatMapData() {
      !!data &&
        data.forEach((item: any) => {
          const { innerMetric, processConfigurationId } = item;
          const { passedQps, rt, blockedQps, exception } = innerMetric;

          item.pid = Number(item.pid);

          const dataSource = {
            pid: item.pid,
            deviceId: item.deviceId,
            parentIp: item.parentIp,
            privateIp: item.privateIp,
            processConfigurationId,
          };

          let colorData: any;
          switch (type) {
            case 'passedQps': {
              item.passedQps = Number(passedQps);
              numAry.push(item.passedQps);
              colorData = initColor(numAry);
              chartData.push({
                mapTitle: intl('mse.appOverview.paasQps'),
                activeIndex: 0,
                bgc: colorData[item.passedQps],
                passedQps: item.passedQps,
                ...dataSource,
              });

              break;
            }
            case 'blockedQps': {
              item.blockedQps = Number(blockedQps);
              numAry.push(item.blockedQps);
              colorData = initColor(numAry);

              chartData.push({
                mapTitle: intl('ahas_sentinel.systemGuard.flowControl.FlowControlQPS'),
                activeIndex: 1,
                bgc: colorData[item.blockedQps],
                blockedQps: item.blockedQps,
                ...dataSource,
              });
              break;
            }
            case 'exceptionQps': {
              item.exception = Number(exception);
              numAry.push(item.exception);
              colorData = initColor(numAry);

              chartData.push({
                mapTitle: intl('mse.appOverview.exception'),
                activeIndex: 2,
                bgc: colorData[item.exception],
                exception: item.exception,
                ...dataSource,
              });
              break;
            }
            case 'rt': {
              item.rt = Number(rt);
              numAry.push(item.rt);
              colorData = initColor(numAry);

              chartData.push({
                mapTitle: '平均RT',
                activeIndex: 3,
                bgc: colorData[item.rt],
                rt: item.rt,
                ...dataSource,
              });
              break;
            }
            default:
              return;
          }
        });
    }

    if (!!data && data.length > 190) {
      histogramChartData();
    } else {
      heatMapData();
    }

    setHeatMapData(chartData);
  }

  function initStddevData(data: any) {
    if (!data) return;
    if (data && !data.length) return;

    const heatArr: any = [];
    let mean = 0; // 平均值
    const sumFn = (x: number, y: number) => {
      return x + y;
    };

    data.forEach((item: any) => {
      const { innerMetric } = item;
      const { passedQps, rt, blockedQps, exception } = innerMetric;

      if (type === 'cpu' || type === 'load' || type === 'passedQps') {
        heatArr.push(passedQps);
      } else if (type === 'rt') {
        heatArr.push(rt);
      } else if (type === 'blockedQps') {
        // 流控qps
        heatArr.push(blockedQps);
      } else if (type === 'exceptionQps') {
        // 异常qps
        heatArr.push(exception);
      } else {
        heatArr.push(passedQps);
      }
    });

    if (heatArr.length > 1) {
      mean = heatArr.reduce(sumFn) / heatArr.length;
      mean = Number(mean.toFixed(2));
    } else {
      mean = heatArr[0];
    }

    setMean(mean);
  }

  // 下版迭代使用
  // const renderExtra = () => {
  //   return (
  //     <>
  //       <span
  //         className={styles.modeBtn}
  //         style={{
  //           color: dataMode === 0 ? '#0070cc' : '#555',
  //           borderColor: dataMode === 0 ? '#0070cc' : '#dedede',
  //           borderRightWidth: dataMode === 0 ? 1 : 0,
  //           marginLeft: 16,
  //         }}
  //         onClick={() => handleModeChange(0)}
  //       >
  //         实时数据
  //       </span>
  //       <span
  //         className={styles.modeBtn}
  //         style={{
  //           color: dataMode === 1 ? '#0070cc' : '#555',
  //           borderColor: dataMode === 1 ? '#0070cc' : '#dedede',
  //           borderLeftWidth: dataMode === 1 ? 1 : 0,
  //         }}
  //         onClick={() => handleModeChange(1)}
  //       >
  //         周期数据
  //       </span>
  //     </>
  //   );
  // };

  // function handleModeChange(dataMode: number) {
  //   setDataMode(dataMode);
  // }

  const renderExtra = () => {
    return (
      !isPtsApp && isTop ? <a style={{ float: 'right', cursor: 'pointer' }} onClick={handelViewApiAll}>
        {intl('ahas_sentinel.systemGuard.viewAll')}
      </a> : ''
    );
  };

  function handelViewApiAll() {
    window.goldlog.record(
      '/ahas-flow.app_summary.api_view_all',
      'CLK',
      '',
      'GET',
    );
    const params = {
      accessType: getParams('accessType'),
      armsAppId: getParams('armsAppId'),
      ahasAppName: getParams('ahasAppName')|| getParams('appName') || '',
      region: getParams('region'),
      ns: getParams('ns'),
    };
    pushUrl(history, '/msc/appList/info/systemGuardApiDetails', {
      appName,
      ...params
    });
  }

  function handleTabChange(type: string) {
    console.log('type', type);
    setType(type);
    setMode(0);
    setHeatMapData([]);
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 800);
  }


  function handleHeatMapOpen() {
    setHeatMapVisible(true);
  }

  function handleHeatMapHidden() {
    setHeatMapVisible(false);
  }

  function getApi() {
    return dispatch.flowAppModel.getAppResourceMetricsByInstance;
  }

  function initProcessConfigurationId(val: string) {
    setProcessConfigurationId(val);
  }

  function initDialogTitle(val: string) {
    setDialogTitle(val);
  }

  return (
    <div className={!isTop ? styles.tableGroupPanel : ''}>
      <Tab
        activeKey={type}
        onChange={handleTabChange as any}
        extra={renderExtra()}
        style={{display:'inline', float:'left'}}
        // className={styles.extraPanle}
      >
        {SHOW_TAB_ITEM.map((item: any) => {
          return (
            <Tab.Item title={item.content} key={item.key}>
              <div className={styles.loadingBody}>
                <Loading visible={loading}>
                  <TabItem
                    handleOpen={handleOpen}
                    type={type}
                    mean={mean}
                    doQueryNodeTop={doQueryNodeTop}
                    mode={mode}
                    setMode={setMode}
                    apiTopTableData={apiTopTableData}
                    nodeTopTableData={nodeTopTableData}
                    handleHeatMapOpen={handleHeatMapOpen}
                    initProcessConfigurationId={initProcessConfigurationId}
                    initDialogTitle={initDialogTitle}
                    heatMapData={heatMapData}
                    isTop={isTop}
                  />
                </Loading>
              </div>
            </Tab.Item>
          );
        })}
      </Tab>

      <ChartsDialog
        handleHiddin={handleHeatMapHidden}
        visible={heatMapVisible}
        style={{
          minWidth: 960,
        }}
        typeCharts="allQps"
        resource="__total_inbound_traffic__"
        getApi={getApi}
        Loop={true}
        ProcessConfigurationId={processConfigurationId}
        dialogTitle={dialogTitle}
      />
    </div>
  );
};

export default DataShowCard;
