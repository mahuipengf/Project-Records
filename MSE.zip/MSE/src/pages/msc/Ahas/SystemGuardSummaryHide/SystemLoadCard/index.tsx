import React, { FC, useEffect, useRef, useState } from 'react';
import { Grid, Message, Switch } from '@alicloud/console-components';
import { SYSTEM_LOAD_LIST } from 'config/constants/flow';
import { compare } from 'utils/util_ahas';
import { debounce } from 'lodash';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';

import styles from './index.module.less';

import AdaptiveFlowDialog from '../../common/AdaptiveFlowDialog';
import ChartsDialog from '../../common/ChartsDialog';
import DetailItem from './DetailItem';
import VersionDialog from '../../common/VersionDialog';
import intl from '@ali/wind-intl';

interface IPointData {
  x?: number;
  y?: number;
}

const { Row, Col } = Grid;

const SystemLoadCard: FC = () => {
  const getParams = window.getParams;
  const fixedSDKVersion = '1.7.1';
  const dispatch = useDispatch();
  const appName = getParams('appName')|| getParams('ahasAppName') || '';

  const { backTime } = useSelector(({ flowAppModel }) => flowAppModel.apiShowTime);
  const [ cpuMode, setCpuMode ] = useState(1);
  const [ memMode, setMemMode ] = useState(1);
  const [ loadMode, setLoadMode ] = useState(1);
  const [ visible, setVisible ] = useState<boolean>(false);
  const [ dialogTitle, setDialogTitle ] = useState<string>();
  const [ group, setGroup ] = useState('');
  const [ resource, setResource ] = useState('');
  const [ cpuMean, setCpuMean ] = useState(0);
  const [ cpuStddev, setCpuStddev ] = useState(0);
  const [ memoryMean, setMemoryMean ] = useState(0);
  const [ memoryStddev, setMemoryStddev ] = useState(0);
  const [ loadMean, setLoadMean ] = useState(0);
  const [ loadStddev, setLoadStddev ] = useState(0);
  const [ heatMapCpuData, setHeatMapCpuData ] = useState<object[]>([]);
  const [ heatMapemoryData, setHeatMapemoryData ] = useState<object[]>([]);
  const [ heatMapLoadData, setHeatMapLoadData ] = useState<object[]>([]);
  const [ processConfigurationId, setProcessConfigurationId ] = useState('');
  const [ heatMapVisible, setHeatMapVisible ] = useState<boolean>(false);
  const [ adaptiveFlow, setAdaptiveFlow ] = useState(false);
  const [ version, setVersion ] = useState<string>();
  const [ versionDialogVisible, setVersionDialogVisible ] = useState(false);
  const [ adaptiveFlowDialogVisible, setAdaptiveFlowDialogVisible ] = useState(false);
  // 获取g2图表实例
  const charts = useRef<any>({ current: {} });

  useEffect(() => {
    // 获取自适应流控配置
    (async function() {
      const { EnableAutoSystemAdaptive } = await dispatch.flowAppModel.getSentinelAdaptiveFlowSettingOfApp({
        AppName: appName,
      });

      if (EnableAutoSystemAdaptive !== undefined) {
        setAdaptiveFlow(EnableAutoSystemAdaptive);
      }
    })();
  }, []);


  function handleModeChange(mode: number, group: string) {
    let thermodynamicChartResource = 'system.cpu.user';

    switch (group) {
      case 'system_cpu':
        setCpuMode(mode);
        thermodynamicChartResource = 'system.cpu.user';
        break;
      case 'system_memory':
        setMemMode(mode);
        thermodynamicChartResource = 'system.mem.used';
        break;
      case 'system_load':
        setLoadMode(mode);
        thermodynamicChartResource = 'system.load.1min';
        break;
      default: null;
    }

    if (mode === 0) {
      window.goldlog.record(
        '/ahas-flow.app_summary.node_chart_btn',
        'CLK',
        '',
        'GET',
      );
      doQueryThermodynamicChart(thermodynamicChartResource, group);
    }
    if (mode === 1) {
      window.goldlog.record(
        '/ahas-flow.app_summary.node_table_btn',
        'CLK',
        '',
        'GET',
      );
    }
  }

  // 查询热力图数据
  async function doQueryThermodynamicChart(thermodynamicChartResource: string, group: string) {

    const queryThermodynamicChartParams: any = {
      AppName: appName,
      Group: group,
      Resource: thermodynamicChartResource,
    };

    const thermodynamicChartData = await dispatch.flowAppModel.getQuerySystemStatResourceMetricOfResource(
      queryThermodynamicChartParams,
    );

    initHeatMapData(thermodynamicChartData, group);
    initStddevData(thermodynamicChartData, group);
  }

  function initProcessConfigurationId(val: string) {
    setProcessConfigurationId(val);
  }

  function initHeatMapData(data: any, type: string) {
    const chartData: object[] = [];
    const numAry: number[] = [];

    const { StatusMacPoints } = data;

    function heatMapData() {
      !!StatusMacPoints &&
      StatusMacPoints.forEach((item: any) => {
        item.pid = Number(item.Pid);

        const dataSource = {
          pid: item.pid,
          parentIp: item.ParentId,
          privateIp: item.Hostname,
          processConfigurationId: item.ProcessConfigurationId,
        };

        let colorData: any;
        switch (type) {
          case 'system_cpu': {
            item.val = Number(item.Val);
            numAry.push(item.val);
            colorData = initColor(numAry);

            chartData.push({
              mapTitle: 'CPU',
              activeIndex: 4,
              bgc: colorData[item.val],
              val: item.val,
              ...dataSource,
            });
            break;
          }
          case 'system_memory': {
            item.val = Number(item.Val);
            numAry.push(item.val);
            colorData = initColor(numAry);

            chartData.push({
              mapTitle: 'MEM',
              activeIndex: 5,
              bgc: colorData[item.val],
              val: item.val,
              ...dataSource,
            });
            break;
          }
          case 'system_load': {
            item.val = Number(item.Val);
            numAry.push(item.val);
            colorData = initColor(numAry);

            chartData.push({
              mapTitle: 'Load',
              activeIndex: 6,
              bgc: colorData[item.val],
              val: item.val,
              ...dataSource,
            });
            break;
          }
          default:
            return;
        }
      });
    }

    heatMapData();

    switch (type) {
      case 'system_cpu':
        setHeatMapCpuData(chartData);
        break;
      case 'system_memory':
        setHeatMapemoryData(chartData);
        break;
      case 'system_load':
        setHeatMapLoadData(chartData);
        break;
      default: null;
    }
  }

  // 热力图色块颜色
  function initColor(arr: number[]) {
    // 去重
    function unique(arr: number[]) {
      return Array.from(new Set(arr));
    }
    // 判断排序
    function sortNumber(a: number, b: number) {
      return a - b;
    }

    const result = []; // 存分成10份的数组
    let endAry = []; // 如果分为10~19组时，最后几组进行合并，保证有十组
    let colorData = {}; // 最终数据
    const colorAry = [
      '#8ACFEC',
      '#89C9ED',
      '#87C2EC',
      '#85BBEB',
      '#83B5EA',
      '#82AEEB',
      '#7FA8EA',
      '#7DA2E9',
      '#7C9CE9',
      '#7B95EA',
    ];

    if (!!arr && arr.length) {
      arr = unique(arr);

      const l = arr.length;
      if (l > 10) {
        arr.sort(sortNumber);

        const sum = Math.floor(l / 10);

        for (let i = 0, len = l; i < len; i += sum) {
          result.push(arr.slice(i, i + sum));
        }

        if (result.length > 10) {
          endAry = result.splice(9, result.length - 1);
          endAry = endAry
            .toString()
            .split(',')
            .map(item => {
              return +item;
            });
          result.push(endAry);
        }
        if (result.length === 10) {
          for (let i = 0; i < 10; i++) {
            const dataArr = result[i];
            if (!!dataArr && dataArr.length) {
              for (let j = 0; j < dataArr.length; j++) {
                colorData = {
                  ...colorData,
                  [dataArr[j]]: colorAry[i],
                };
              }
            }
          }
        }
      } else {
        for (let i = 0; i < l; i++) {
          colorData = {
            ...colorData,
            [arr[i]]: colorAry[i],
          };
        }
      }
      return colorData;
    }
  }

  function initStddevData(data: any, group: string) {
    const { ValAvg, ValStd } = data;

    switch (group) {
      case 'system_cpu':
        setCpuMean(ValAvg);
        setCpuStddev(ValStd);
        break;
      case 'system_memory':
        setMemoryMean(ValAvg);
        setMemoryStddev(ValStd);
        break;
      case 'system_load':
        setLoadMean(ValAvg);
        setLoadStddev(ValStd);
        break;
      default:
        return;
    }
  }

  function handleChartOpen(type: string, resource: string) {
    if (type === 'systemCpu') {
      setGroup('system_cpu');
      setDialogTitle('CPU(%)');
      setResource(resource);
    }

    if (type === 'systemMemory') {
      setGroup('system_memory');
      setDialogTitle('MEM(%)');
      setResource(resource);
    }

    if (type === 'systemLoad') {
      setGroup('system_load');
      setDialogTitle('Load1');
      setResource(resource);
    }

    setVisible(true);
  }

  function handleChartHidden() {
    setVisible(false);
  }

  function getApi() {
    return dispatch.flowAppModel.getQueryAppResourceMetrics;
  }

  function getThermodynamicApi() {
    return dispatch.flowAppModel.getQuerySystemResourceMetricOfGroup;
  }

  function renderResource(val: string) {
    switch (val) {
      case 'system_cpu':
        return 'system.cpu.user';
      case 'system_memory':
        return 'system.mem.used';
      case 'system_load':
        return 'system.load.1min';
      default:
        return '';
    }
  }

  function renderMode(val: string) {
    switch (val) {
      case 'system_cpu':
        return cpuMode;
      case 'system_memory':
        return memMode;
      case 'system_load':
        return loadMode;
      default :
        return 0;
    }
  }

  function renderHeatMapData(val: string) {
    switch (val) {
      case 'system_cpu':
        return heatMapCpuData;
      case 'system_memory':
        return heatMapemoryData;
      case 'system_load':
        return heatMapLoadData;
      default :
        return 0;
    }
  }

  function renderMean(val: string) {
    switch (val) {
      case 'system_cpu':
        return cpuMean;
      case 'system_memory':
        return memoryMean;
      case 'system_load':
        return loadMean;
      default :
        return 0;
    }
  }

  function renderStddev(val: string) {
    switch (val) {
      case 'system_cpu':
        return cpuStddev;
      case 'system_memory':
        return memoryStddev;
      case 'system_load':
        return loadStddev;
      default :
        return 0;
    }
  }

  function handleHeatMapOpen(val: string) {
    setGroup(val);
    setHeatMapVisible(true);
  }

  function handleHeatMapHidden() {
    setHeatMapVisible(false);
  }

  function initDialogTitle(val: string) {
    setDialogTitle(val);
  }

  function handleSwitchBtn() {
    if (version) {
      if (!compare(version, fixedSDKVersion)) {
        setVersionDialogVisible(true);
      } else {
        setAdaptiveFlowDialogVisible(true);
      }
    } else {
      setAdaptiveFlowDialogVisible(true);
    }
  }

  function handleVersionDialogHidden() {
    setVersionDialogVisible(false);
  }

  function handleAdaptiveFlowDialogHidden() {
    setAdaptiveFlowDialogVisible(false);
  }

  async function handleOk() {
    setAdaptiveFlowDialogVisible(false);
    setAdaptiveFlow(!adaptiveFlow);

    const { Success, Data } = await dispatch.flowAppModel.getUpdateSentinelAdaptiveFlowSettingOfApp({
      AppName: appName,
      EnableAutoSystemAdaptive: !adaptiveFlow,
    });

    const { EnableAutoSystemAdaptive } = Data;

    if (Success === true) {
      if (EnableAutoSystemAdaptive) {
        Message.success('开启成功');
      } else {
        Message.success('关闭成功');
      }
    } else {
      Message.error('设置失败');
    }
  }

  function onTooltipChange(tooltips: any) {
    const { systemCpuChart, systemLoadChart, systemMemoryChart } = charts.current;

    const { x, y } = tooltips; // tooltip显示的项

    const pointData: IPointData = {};

    // 面积图point会是个数组，数组取第一项的值
    function isAry(val: any) {
      return Object.prototype.toString.call(val) === '[object Array]';
    }

    if (isAry(x)) {
      pointData.x = x[0];
    } else {
      pointData.x = x;
    }

    if (isAry(y)) {
      pointData.y = y[0];
    } else {
      pointData.y = y;
    }

    systemCpuChart?.showTooltip(pointData);
    systemLoadChart?.showTooltip(pointData);
    systemMemoryChart?.showTooltip(pointData);
  }

  const onTooltip = debounce(onTooltipChange, 0);

  // 鼠标离开图标时，隐藏所有的tooltip
  function onPlotLeave(plot: any) {
    const { systemCpuChart, systemLoadChart, systemMemoryChart } = charts.current;

    const id = plot.toElement?.getAttribute('id');
    if (id && id?.indexOf('canvas') !== -1) {
      systemCpuChart?.hideTooltip();
      systemLoadChart?.hideTooltip();
      systemMemoryChart?.hideTooltip();
    }
  }

  function getG2Charts(type: string, chart: any) {
    switch (type) {
      case 'system_cpu':
        charts.current.systemCpuChart = chart;
        break;
      case 'system_load':
        charts.current.systemLoadChart = chart;
        break;
      case 'system_memory':
        charts.current.systemMemoryChart = chart;
        break;
      default:
        return;
    }
  }

  function renderDialogResource() {
    if (group === 'system_memory') {
      return 'system_memory';
    }
    if (group === 'system_cpu') {
      return '__cpu_usage__';
    }
    if (group === 'system_load') {
      return '__system_load__';
    }
  }

  function renderTypeCharts() {
    if (group === 'system_memory') {
      return 'ststemLoadsystem_memory';
    }
    if (group === 'system_cpu') {
      return 'cpu';
    }
    if (group === 'system_load') {
      return 'load';
    }
    return '';
  }

  return (
    <>
      <div className={styles.panel}>
        <div className={styles.adaptiveFlow}>
          <span className={styles.cardTitle}>系统资源</span>
          <Switch
            checked={adaptiveFlow}
            onClick={() => {
              handleSwitchBtn();
            }}
            style={{ marginRight: '8px' }}
          />
        自适应流控{adaptiveFlow ? `${intl('widget.common.opened')}，生效中` : intl('widget.common.closed')}
        </div>

        <Row>
          {
            SYSTEM_LOAD_LIST.map((item, index) => {
              return (
                <Col span="8" style={{ paddingRight: '13px' }} key={index}>
                  <DetailItem
                    mode={renderMode(item)}
                    group={item}
                    resource={renderResource(item)}
                    handleModeChange={handleModeChange}
                    handleChartOpen={handleChartOpen}
                    mean={renderMean(item)}
                    stddev={renderStddev(item)}
                    heatMapData={renderHeatMapData(item)}
                    initProcessConfigurationId={initProcessConfigurationId}
                    handleHeatMapOpen={handleHeatMapOpen}
                    initDialogTitle={initDialogTitle}
                    onTooltipChange={onTooltip}
                    onPlotLeave={onPlotLeave}
                    getG2Charts={getG2Charts}
                  />
                </Col>
              );
            })
          }
        </Row>

        {/* 查看区间信息 */}
        <ChartsDialog
          typeCharts={renderTypeCharts()}
          visible={visible}
          dialogTitle={dialogTitle}
          handleHiddin={handleChartHidden}
          getApi={getApi}
          apiNew={group === 'system_memory'}
          group={group}
          resource={renderDialogResource()}
          systemLoadResource={resource}
          style={{
            minWidth: 960,
          }}
        />

        {/* 热力图信息 */}
        <ChartsDialog
          dialogTitle={dialogTitle}
          visible={heatMapVisible}
          typeCharts={group}
          handleHiddin={handleHeatMapHidden}
          getApi={getThermodynamicApi}
          endTime={backTime}
          apiNew={true}
          group={group}
          processConfigurationId={processConfigurationId}
        />

        {/* 自适应流控 */}

        <AdaptiveFlowDialog
          adaptiveFlowDialogVisible={adaptiveFlowDialogVisible}
          handleDialogHidden={handleAdaptiveFlowDialogHidden}
          handleOk={handleOk}
          adaptiveFlow={adaptiveFlow}
        />

        {version && <VersionDialog
          version={version}
          versionDialogVisible={versionDialogVisible}
          handleDialogHidden={handleVersionDialogHidden}
        />}
      </div>
    </>
  );
};

export default SystemLoadCard;
