import React, { FC, useEffect, useRef, useState } from 'react';
import { Grid } from '@alicloud/console-components';
import {
  IAppData,
  IChartDataSource,
  IMetricsData,
} from 'config/interfaces/flowProtection';
import { SUMMARY_PAGE_STEPS_TIPS } from 'config/constants/flow';
import { debounce } from 'lodash';
import { useDispatch } from '@ali/sre-utils-dva';
import { useInterval } from '@ali/sre-utils-hooks';

import styles from './index.module.less';

import AllQpsDetailCard from './AllQpsDetailCard';
import ChartsDialog from '../../common/ChartsDialog';
import ProtectiveEvents from './ProtectiveEvents';
import ResponseTimeCard from './ResponseTimeCard';
import SantaIntroTips from 'components/SantaIntroTips';
import intl from '@ali/wind-intl';

const { Row, Col } = Grid;

interface IPointData {
  x?: number;
  y?: number;
}

const ChartsCard: FC = () => {
  const getParams = window.getParams;
  const appName = getParams('edasAppId') || getParams('appName')|| getParams('ahasAppName') || null;
  const dispatch = useDispatch();
  const time = '5';

  const [ visible, setVisible ] = useState(false);
  const [ data, setData ] = useState<IAppData | undefined>();
  const [ curMeticsData, setCurMeticsData ] = useState<
  Array<Array<IChartDataSource>>
  >([]);
  const [ typeCharts, setTypeCharts ] = useState<string>('');
  const [ dialogTitle, setDialogTitle ] = useState<string>();
  const [ appEvents, setAppEvents ] = useState([]);

  // 获取g2图表实例
  const charts = useRef<any>({ current: {} });

  useEffect(() => {
    togetherQuery();
  }, []);

  useEffect(() => {
    // 请求防护事件数据
    (async function() {
      let evevtsList = [];
      const {
        datas: evevtsData = [],
      } = await dispatch.flowAppModel.getSentinelAppEvents({
        AppName: appName,
        pageSize: 7,
        pageIndex: 1,
      });
      evevtsList = evevtsData;
      setAppEvents(evevtsList);
    })();
  }, []);

  // 轮询
  useInterval(() => {
    togetherQuery();
  }, 10000);

  // 请求5分钟内的数据
  async function pollingQueryingQps() {
    const data = await dispatch.flowAppModel.getQuerySentinelAppSummaryMetricOverview(
      {
        AppName: appName,
      },
    );
    return data;
  }

  // 等待数据全部拿到以后，一起写入图表。
  async function togetherQuery() {
    const [ data ] = await Promise.all([
      pollingQueryingQps(),
    ]);
    const { curMetics } = data;
    initcurMeticsData(curMetics);
    setData(data);
  }

  function initcurMeticsData(curMetics: object[]) {
    const allQps: IChartDataSource[] = []; // 表1大流量,通过QPS和拒绝QPS
    const rtAndThread: IChartDataSource[] = []; // 表2并发线程,平均RT和并发

    !!curMetics &&
      curMetics.forEach((item: IMetricsData) => {
        item.passedQps = Number(item.passedQps); // 通过QPS
        item.blockedQps = Number(item.blockedQps); // 拒绝QPS
        item.exception = Number(item.exception); // 异常QPS
        item.allQps = Number(item.allQps); // 总流量
        item.rt = Number(item.rt); // 平均RT
        item.thread = Number(item.thread); // 并发

        allQps.push({
          time: item.timestamp || 0,
          type: intl('mse.appOverview.paasQps'),
          count: item.passedQps,
        });

        allQps.push({
          time: item.timestamp || 0,
          type: intl('ahas_sentinel.systemGuard.flowControl.RejectQPS'),
          count: item.blockedQps,
        });

        allQps.push({
          time: item.timestamp || 0,
          type: intl('mse.appOverview.exception'),
          count: item.exception,
        });
        item.allQps && allQps.push({
          time: item.timestamp || 0,
          type: intl('mse.appOverview.allQps'),
          count: item.allQps,
        });

        if (item.grayStatistics) {
          for (const a in item.grayStatistics) {
            allQps.push({
              time: item.timestamp || 0,
              type: a === 'NoneAM' ? '基础流量' : a,
              count: item.grayStatistics[a],
            });
          }
        }

        rtAndThread.push({
          time: item.timestamp || 0,
          type: 'RT(ms)',
          count: item.rt,
        });

        rtAndThread.push({
          time: item.timestamp || 0,
          type: intl('ahas_sentinel.systemGuard.flowControl.Concurrents'),
          count: item.thread,
        });
      });
    setCurMeticsData([ allQps, rtAndThread ]);
  }

  function handleOpen(type: string) {
    setTypeCharts(type);
    setVisible(true);
  }

  function handleHiddin() {
    setVisible(false);
  }

  function getApi() {
    return dispatch.flowAppModel.getQueryAppResourceMetrics;
  }

  function onTooltipChange(tooltips: any) {
    const { allQpsChart, rtAndThread } = charts.current;

    const { x, y } = tooltips; // tooltip显示的项

    const pointData: IPointData = {};

    // 面积图point会是个数组，数组取第一项的值
    function isAry(val: any) {
      return Object.prototype.toString.call(val) === '[object Array]';
    }

    if (isAry(x)) {
      pointData.x = x[0];
    } else {
      pointData.x = x;
    }

    if (isAry(y)) {
      pointData.y = y[0];
    } else {
      pointData.y = y;
    }

    allQpsChart?.showTooltip(pointData);
    rtAndThread?.showTooltip(pointData);
  }

  const onTooltip = debounce(onTooltipChange, 0);

  // 鼠标离开图标时，隐藏所有的tooltip
  function onPlotLeave(plot: any) {
    const { allQpsChart, rtAndThread } = charts.current;

    const id = plot.toElement?.getAttribute('id');
    if (id && id?.indexOf('canvas') !== -1) {
      allQpsChart?.hideTooltip();
      rtAndThread?.hideTooltip();
    }
  }

  function getG2Charts(type: string, chart: any) {
    switch (type) {
      case 'allQPS':
        charts.current.allQpsChart = chart;
        break;
      case 'rtAndThread':
        charts.current.rtAndThread = chart;
        break;
      default:
        return;
    }
  }

  function renderDialogTitle(val: string) {
    setDialogTitle(val);
  }

  return (
    <div className={styles.headerPanel}>
      <span className={styles.title}>时间周期：{time}分钟</span>
      <span className={styles.title} style={{ paddingLeft: 24 }}>
        节点总数：{data ? data.machineCount : 0}
      </span>
      <span className={styles.title} style={{ paddingLeft: 24 }}>
        应用概览中涉及到的QPS/RT/并发线程均为应用入口接口的统计，不包括应用内部方法调用的统计。
      </span>
      <div className={styles.chartsPanel}>
        <Row>
          <Col
            span="8"
            className={styles.chartsCard}
            style={{ paddingLeft: 0 }}
          >
            <div id={'summary_page_show_dashboard'}>
              <AllQpsDetailCard
                typeCard={'allQPS'}
                handleOpen={handleOpen}
                data={data}
                curMeticsData={curMeticsData}
                renderDialogTitle={renderDialogTitle}
                onTooltipChange={onTooltip}
                onPlotLeave={onPlotLeave}
                getG2Charts={getG2Charts}
              />
            </div>
            <SantaIntroTips
              stepsArr={SUMMARY_PAGE_STEPS_TIPS}
              storageKey={'summary_page_intro'}
              durationTime={500}
            />
          </Col>

          <Col
            span="8"
            className={styles.chartsCard}
            style={{ paddingLeft: 0 }}
          >
            <ResponseTimeCard
              typeCard={'rtAndThread'}
              handleOpen={handleOpen}
              data={data}
              onTooltipChange={onTooltip}
              curMeticsData={curMeticsData}
              onPlotLeave={onPlotLeave}
              getG2Charts={getG2Charts}
              renderDialogTitle={renderDialogTitle}
            />
          </Col>

          <Col
            span="8"
            className={styles.chartsCard}
            style={{ paddingLeft: 0 }}
          >
            <ProtectiveEvents appEvents={appEvents} />
          </Col>
        </Row>
      </div>

      <ChartsDialog
        visible={visible}
        typeCharts={typeCharts}
        handleHiddin={handleHiddin}
        getApi={getApi}
        dialogTitle={dialogTitle}
      />
    </div>
  );
};

export default ChartsCard;
