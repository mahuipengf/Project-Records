import React, { FC, useEffect, useRef, useState } from 'react';
import SummaryCore from './SummaryCore';
// import SummaryException from '../../common/ExceptionStatistics';
import SummaryJvm from './SummaryJvm';
import SummaryNetWork from './SummaryNetWork';
import SummarySystem from './SummarySystem';
import SummaryTopOfResource from './SummaryTopOfResource';
import styles from './index.module.less';
import { debounce, isEmpty, get } from 'lodash';
import { useDispatch } from '@ali/sre-utils-dva';
import { useStateStore } from 'store';

interface IPointData {
  x?: number;
  y?: number;
}

const SystemGuardCard: FC = () => {
  const getParams = window.getParams;
  const dispatch = useDispatch();
  const appName = getParams('appName')|| getParams('ahasAppName') || '';
  const isPtsMicro = getParams('ptsMicro') === 'true';
  const [isOnlyGOSDK, setisOnlyGOSDK] = useState(false);
  const state = useStateStore();
  const MscAccount = get(state, 'MscAccount');
  // status 2 是开通 1未开通 ，version 0 基础班 1专业版 2企业版
  const isMscAccount = MscAccount.Version === 1;
  const Version = get(MscAccount, 'Version');


  // 获取g2图表实例
  const charts = useRef < any > ({ current: {} });

  // 渲染系统相关Tooltip
  function onSystemTooltipChange(tooltips: any) {
    const { loadCharts, systemMemoryChart, systemDiskChart } = charts.current;

    const { x, y } = tooltips; // tooltip显示的项

    const pointData: IPointData = {};

    // 面积图point会是个数组，数组取第一项的值
    function isAry(val: any) {
      return Object.prototype.toString.call(val) === '[object Array]';
    }

    if (isAry(x)) {
      pointData.x = x[0];
    } else {
      pointData.x = x;
    }

    if (isAry(y)) {
      pointData.y = y[0];
    } else {
      pointData.y = y;
    }

    loadCharts?.showTooltip(pointData);
    systemMemoryChart?.showTooltip(pointData);
    systemDiskChart?.showTooltip(pointData);
  }

  // 渲染JVM相关Tooltip
  function onJvmTooltipChange(tooltips: any) {
    const { jvmGcChart, jvmGcTimeChart, jvmHeapChart, jvmNoneHeapChart, jvmThreadCountChart } = charts.current;

    const { x, y } = tooltips; // tooltip显示的项

    const pointData: IPointData = {};

    // 面积图point会是个数组，数组取第一项的值
    function isAry(val: any) {
      return Object.prototype.toString.call(val) === '[object Array]';
    }

    if (isAry(x)) {
      pointData.x = x[0];
    } else {
      pointData.x = x;
    }

    if (isAry(y)) {
      pointData.y = y[0];
    } else {
      pointData.y = y;
    }

    jvmGcChart?.showTooltip(pointData);
    jvmGcTimeChart?.showTooltip(pointData);
    jvmHeapChart?.showTooltip(pointData);
    jvmNoneHeapChart?.showTooltip(pointData);
    jvmThreadCountChart?.showTooltip(pointData);
  }

  // 渲染网络相关Tooltip
  function onNetworkTooltipChange(tooltips: any) {
    const { systemNetworkChart, systemNetworkDataPackChart } = charts.current;

    const { x, y } = tooltips; // tooltip显示的项

    const pointData: IPointData = {};

    // 面积图point会是个数组，数组取第一项的值
    function isAry(val: any) {
      return Object.prototype.toString.call(val) === '[object Array]';
    }

    if (isAry(x)) {
      pointData.x = x[0];
    } else {
      pointData.x = x;
    }

    if (isAry(y)) {
      pointData.y = y[0];
    } else {
      pointData.y = y;
    }

    systemNetworkChart?.showTooltip(pointData);
    systemNetworkDataPackChart?.showTooltip(pointData);
  }

  const onSystemTooltip = debounce(onSystemTooltipChange, 0);
  const onJvmTooltip = debounce(onJvmTooltipChange, 0);
  const onNetworkTooltip = debounce(onNetworkTooltipChange, 0);


  // 鼠标离开图标时，隐藏所有的tooltip
  function onPlotLeave(plot: any) {
    const { loadCharts, systemMemoryChart, jvmGcChart, jvmGcTimeChart, jvmHeapChart, jvmNoneHeapChart, jvmThreadCountChart, systemDiskChart, systemNetworkChart, systemNetworkDataPackChart } = charts.current;

    const id = plot.toElement?.getAttribute('id');
    if (id && id?.indexOf('canvas') !== -1) {
      loadCharts?.hideTooltip();
      systemMemoryChart?.hideTooltip();
      jvmGcChart?.hideTooltip();
      jvmGcTimeChart?.hideTooltip();
      jvmHeapChart?.hideTooltip();
      jvmNoneHeapChart?.hideTooltip();
      jvmThreadCountChart?.hideTooltip();
      systemDiskChart?.hideTooltip();
      systemNetworkChart?.hideTooltip();
      systemNetworkDataPackChart?.hideTooltip();
    }
  }

  function getG2Charts(type: string, chart: any) {
    switch (type) {
      case 'load':
        charts.current.loadCharts = chart;
        break;
      case 'system_memory':
        charts.current.systemMemoryChart = chart;
        break;

      case 'jvm_gc':
        charts.current.jvmGcChart = chart;
        break;
      case 'jvm_gc_time':
        charts.current.jvmGcTimeChart = chart;
        break;
      case 'jvm_heap':
        charts.current.jvmHeapChart = chart;
        break;
      case 'jvm_none_heap':
        charts.current.jvmNoneHeapChart = chart;
        break;
      case 'jvm_thread_count':
        charts.current.jvmThreadCountChart = chart;
        break;

      // case 'system_disk':
      //   charts.current.systemDiskChart = chart;
      //   break;
      case 'system_network':
        charts.current.systemNetworkChart = chart;
        break;
      case 'system_network_data_pack':
        charts.current.systemNetworkDataPackChart = chart;
        break;
      default:
    }
  }

  return (
    <div className={styles.content}>
      <SummaryCore />
      {/* {!isMscAccount && !isPtsMicro && <SummaryTopOfResource />} */}
      {Version === 2 && <SummaryTopOfResource />}
      {/* {!isMscAccount && !isOnlyGOSDK && <SummaryException />} */}
      {Version > 0 && <SummarySystem
        onTooltipChange={onSystemTooltip}
        onPlotLeave={onPlotLeave}
        getG2Charts={getG2Charts}
      />
      }
      

      {Version === 2 && !isOnlyGOSDK && <SummaryJvm
        onTooltipChange={onJvmTooltip}
        onPlotLeave={onPlotLeave}
        getG2Charts={getG2Charts}
      />}
      {/* 网络流量 网络数据包 */}
      {/* {!isOnlyGOSDK && <SummaryNetWork
        onTooltipChange={onNetworkTooltip}
        onPlotLeave={onPlotLeave}
        getG2Charts={getG2Charts}
      />} */}
    </div>
  );
};

export default SystemGuardCard;
