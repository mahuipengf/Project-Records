// import DyncamicLine from './DynamicLine';
import React, { FC, useEffect, useState } from 'react';
import SystemGuardCard from './SystemGuardCard';
import { Dialog, Message } from '@alicloud/console-components';
import { getCurrentRegion } from 'utils/index';
import { If } from 'components/tsx-control';
import { Loading } from '@ali/cn-design';

const SystemGuardOverview: FC = () => {
  const getParams = window.getParams;
  const MseImplant = getParams('MseImplant') === 'true' || sessionStorage.getItem('MseImplant') === 'true';
  const MseDetailImplant = getParams('MseDetailImplant') === 'true' || sessionStorage.getItem('MseDetailImplant') === 'true';
  const accountUid = window.ALIYUN_CONSOLE_CONFIG?.MAIN_ACCOUNT_PK || '';
  const region = getParams('region') || getCurrentRegion() || '';
  const ns = getParams('ns') || '';
  const [isNeedOpenArms, setIsNeedOpenArms] = useState < boolean > (false);


  useEffect(() => {
    // 设置header

    // 校验是否为sae、pts嵌入链接
    const saeAppName = getParams('saeAppName') || null;
    // 校验是否为sae、pts嵌入链接
    const isPtsApp = getParams('ptsApp') === 'true';
    const isPtsMicro = getParams('ptsMicro') === 'true';
    if (isPtsApp || isPtsMicro) {
      sessionStorage.setItem('isStress', 'true');
      sessionStorage.setItem('sdkVersion', '9.9.9');
      sessionStorage.setItem('agentVersion', '9.9.9');
      sessionStorage.setItem('currentLevel', '0');
    }
  }, [MseImplant, MseDetailImplant]);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    setTimeout(() => setLoading(false), 500);
  }, []);


  return (
    <div >
      <Loading visible={loading} style={{ width: 'calc( 100vw - 234px)', height: 'calc(100vh - 150px)' }}>
        <If condition={!loading}>
          <SystemGuardCard />
        </If>
      </Loading>
    </div>
  );
};

export default SystemGuardOverview;
