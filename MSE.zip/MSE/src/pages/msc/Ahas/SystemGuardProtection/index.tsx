import AppCard from './AppCard';
import React, { FC } from 'react';
import { If } from 'components/tsx-control';

const { getParams } = window;
const SystemGuard: FC = () => {
  if (getParams('MseImplant') === 'true') {
    window.top.postMessage(
      {
        currentPathName: window.location.pathname,
      },
      '*',
    );
  }

  const handleClickOldAppList = () => {
    window.top.postMessage(
      {
        goBackVersionTab: 'appList',
      },
      '*',
    );
  };

  return (
    <div>
      <If condition={getParams('MseKey') === 'app'}>
        <div style={{ color: '#555' }}>
          <div>说明：确定您的 ack-onepilot 版本是 3.0.3 以上并且您的应用在 2022-11-15 之后重启过才能在新版应用列表中查到，点此<span style={{ color: '#0070cc', cursor: 'pointer' }} onClick={handleClickOldAppList}>切换旧版本</span></div>
        </div>
      </If>
      <AppCard/>
    </div>
  );
};

export default SystemGuard;
