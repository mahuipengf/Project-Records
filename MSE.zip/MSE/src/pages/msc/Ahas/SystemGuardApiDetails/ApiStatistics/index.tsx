import ChartsDialog from '../../common/ChartsDialog';
import React, { FC, useCallback, useEffect, useState } from 'react';
import styles from './index.module.less';
import { IApiStatisticsRecord } from 'config/interfaces';
import { Pagination, Progress, Table } from '@alicloud/console-components';
import { RENDER_API_ICON_TYPE } from 'config/constants/flow';
import { useDispatch, useSelector } from '@ali/sre-utils-dva';
import intl from '@ali/wind-intl';

interface StatisticsProps {
  resourceType: number;
}

const { getParams } = window;
const ApiStatistics: FC<StatisticsProps> = props => {
  const { resourceType } = props;
  const appName = getParams('edasAppId') || getParams('appName')|| getParams('ahasAppName')||'';
  const dispatch = useDispatch();
  const [pageIndex, setPageIndext] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [metricListTop, setMetricListTop] = useState([]);
  const [isAgainRender, setIsAgainRender] = useState < boolean > (false); // 刷新视图
  const [visible, setVisible] = useState(false);
  const [resourceName, setResourceName] = useState('');
  const {
    statisticsEndTime = Date.parse(new Date().toString()) - 1000 * 60 * 60 * 24,
  } = useSelector(({ flowAppModel }) => flowAppModel.apiShowTime);
  useEffect(() => {
    // 请求接口Top列表数据
    (async function() {
      setIsLoading(true);
      const {
        totalCount = 0,
        metrics: listTopData = [],
      } = await dispatch.flowAppModel.getSentinelResourcesPercentage({
        AppName: appName,
        PageIndex: pageIndex,
        PageSize: 10,
        SearchKey: '',
        StartTime: statisticsEndTime - 1000 * 60 * 60 * 24,
        EndTime: statisticsEndTime,
        OrderBy: 0,
        ResourceType: resourceType,
      });
      setTotalCount(totalCount);
      setMetricListTop(listTopData);
      setIsLoading(false);
    })();
  }, [resourceType, pageIndex, statisticsEndTime]);

  // 渲染接口名
  function renderResourceName(
    value: string,
    index: number,
    record: IApiStatisticsRecord,
  ) {
    const { type } = record;
    return (
      <span className={styles.resourceName}>
        <i className={RENDER_API_ICON_TYPE[type]} />
        {value}
      </span>
    );
  }

  // 渲染操作
  function renderOperate(value: string) {
    return (
      <span
        className={styles.operateBtn}
        onClick={() => handleOpenDialog(value)}
      >
        {intl('mse.apiDetail.sectionDetails')}
      </span>
    );
  }

  // 渲染占比
  function renderProportion(
    value: number,
    index: number,
    record: IApiStatisticsRecord,
  ) {
    const { percentage } = record;
    return <Progress percent={percentage * 100} size="small" />;
  }

  // 渲染通过请求数
  function renderPQpsRequests(
    value: number,
    index: number,
    record: IApiStatisticsRecord,
  ) {
    const { passedQps } = record;
    return (
      // <span>{passedQps}  ( {sum} )</span>
      <span>{passedQps}</span>
    );
  }

  // 渲染拒绝请求数
  function renderBQpsRequests(
    value: number,
    index: number,
    record: IApiStatisticsRecord,
  ) {
    const { blockedQps } = record;
    return <span>{blockedQps}</span>;
  }

  // 渲染异常请求数
  function renderEQpsRequests(
    value: number,
    index: number,
    record: IApiStatisticsRecord,
  ) {
    const { exception } = record;
    return <span>{exception}</span>;
  }

  // 翻页
  function handlePageIndexChange(current: number) {
    setPageIndext(current);
  }

  // 排序
  const onSort = useCallback(
    (dataIndex: string, order: string) => {
      setMetricListTop(
        metricListTop.sort((a: any, b: any) => {
          if (a[dataIndex] > b[dataIndex]) {
            return order === 'asc' ? 1 : -1;
          }
          return order === 'asc' ? -1 : 1;
        }),
      );
      setIsAgainRender(!isAgainRender);
    },
    [metricListTop, isAgainRender],
  );

  // 打开历史弹窗
  function handleOpenDialog(value: string) {
    setResourceName(value);
    setVisible(true);
  }

  // 关闭历史弹窗
  function handleHiddin() {
    setVisible(false);
  }

  // 历史数据请求接口
  function getApi() {
    return dispatch.flowAppModel.getQueryAppResourceMetrics;
  }

  function renderNoData() {
    return <div className={styles.emptyData}>{intl('widget.common.no_data')}</div>;
  }

  return (
    <>'     '<div className={styles.content}>
        <Table
          dataSource={metricListTop}
          isZebra={false}
          hasBorder={false}
          loading={isLoading}
          onSort={onSort}
          emptyContent={renderNoData()}
        >
          <Table.Column
            title={intl('mse.apiDetail.apiName')}
            width={'25%'}
            dataIndex="resource"
            align={'left'}
            cell={renderResourceName}
          />
          <Table.Column
            title={intl('mse.apiDetail.indicatorsProportion')}
            width={'16%'}
            cell={renderProportion}
            dataIndex="percentage"
            align={'left'}
            sortable
          />
          <Table.Column
            title={intl('mse.apiDetail.paasAllQPS')}
            width={'16%'}
            cell={renderPQpsRequests}
            dataIndex="passedQps"
            align={'left'}
            sortable
          />
          <Table.Column
            title={intl('mse.apiDetail.blockAllQPS')}
            width={'16%'}
            cell={renderBQpsRequests}
            dataIndex="blockedQps"
            align={'left'}
            sortable
          />
          <Table.Column
            title={intl('mse.apiDetail.exception')}
            width={'16%'}
            cell={renderEQpsRequests}
            dataIndex="exception"
            align={'left'}
            sortable
          />
          {false && (
            <Table.Column
              title={intl('widget.common.operating')}
              dataIndex="resource"
              cell={renderOperate}
              align={'left'}
            />
          )}
        </Table>

        {!!metricListTop.length && (
          <Pagination
            className={styles.tablePagination}
            current={pageIndex}
            onChange={handlePageIndexChange}
            size="medium"
            shape="arrow-only"
            total={totalCount}
            pageSize={10}
            totalRender={totalCount => `${intl('mse.register.trace.total_tip', { totalCount })}`}
          />
        )}

        <ChartsDialog
          visible={visible}
          typeCharts={'all'}
          handleHiddin={handleHiddin}
          getApi={getApi}
          resource={resourceName}
          startTime={statisticsEndTime - 1000 * 60 * 60 * 24}
          endTime={statisticsEndTime}
          title={'api'}
        />
      </div>'   '</>
  );
};

export default ApiStatistics;
