import ApiDetails from './ApiDetails';
import ApiStatistics from './ApiStatistics';
import React, { FC, ReactNode, useEffect, useState } from 'react';
import styles from './index.module.less';
import { API_TAB_DEFAULT, GATEWAY_TAB_DEFAULT, new_API_TAB_DEFAULT } from 'config/constants/flow';
import { Tab } from '@alicloud/console-components';
import { useDispatch } from '@ali/sre-utils-dva';
import { If } from 'components/tsx-control';
import { useStateStore } from 'store';
import { get } from 'lodash';
import { Loading } from '@ali/cn-design';


interface ApiDetailsProps {
  pageType? : string;
}

const SystemGuardApiDetails: FC<ApiDetailsProps> = props => {
  const { getParams, setParams, removeParams } = window;
  const state = useStateStore();
  const appName = getParams('appName')|| getParams('ahasAppName') || '';
  const { pageType = 'guardApp' } = props;
  const dispatch = useDispatch();
  const [showType, setShowType] = useState('details');
  const fullScreenApi = getParams('fullScreenApi');
  const activeResourceName = getParams('activeResourceName') || '';
  const apiShowType = getParams('apiShowType') || 'details';
  const [resourceType, setResourceType] = useState(Number(1));
  const MscAccount = get(state, 'MscAccount');
  // status 2 是开通 1未开通 ，version 0 基础班 1专业版 2企业版
  const isMscAccount = MscAccount.Version === 1;
  const TabItem = (pageType === 'gateWay') ? GATEWAY_TAB_DEFAULT : isMscAccount ? new_API_TAB_DEFAULT : API_TAB_DEFAULT;
  const MseImplant = getParams('MseImplant') === 'true' || sessionStorage.getItem('MseImplant') === 'true';
  const MseDetailImplant = getParams('MseDetailImplant') === 'true' || sessionStorage.getItem('MseDetailImplant') === 'true';

  const appType = getParams('appType')

  useEffect(() => {
    const isPtsApp = getParams('ptsApp') === 'true';
    const isPtsMicro = getParams('ptsMicro') === 'true';
    if (isPtsApp || isPtsMicro) {
      sessionStorage.setItem('isStress', 'true');
      sessionStorage.setItem('sdkVersion', '9.9.9');
      sessionStorage.setItem('agentVersion', '9.9.9');
      sessionStorage.setItem('currentLevel', '0');
    }
  }, [pageType, MseImplant]);

  useEffect(() => {
    dispatch.flowAppModel.setSystemGuardPageType(pageType === 'gateWay' ? 'pageGateWay' : 'pageApp');
    dispatch.flowAppModel.setFullScreen({
      fullScreenApi: fullScreenApi === 'true',
      fullScreenMac: false,
    });
    activeResourceName && dispatch.flowAppModel.setApiActiveName({ activeResourceName, favorite: false, hasRule: false, type: 0, pResourceName: '' });
    return () => {
      // 删除url地址栏参数
      removeParams('fullScreenApi');
      removeParams('activeResourceName');
      removeParams('apiShowType');
      removeParams('showModels');
      removeParams('resType');
      // 清除store
      dispatch.flowAppModel.clear('apiShowTime');
      dispatch.flowAppModel.clear('showModelstype');
      dispatch.flowAppModel.clear('systemGuardPageType');
      dispatch.flowAppModel.clear('chartsFilter');
      dispatch.flowAppModel.clear('fullScreen');
    };
  }, []);

  useEffect(() => {
    setParams('resType', resourceType);
    return () => {
      // 清除选中store
      dispatch.flowAppModel.clear('apiDetails');
    };
  }, [resourceType]);


  useEffect(() => {
    setShowType(apiShowType);
  }, [MseImplant, MseDetailImplant]);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    setTimeout(() => setLoading(false), 500);
  }, []);


  // 切换接口Tab
  function hendleResourceTypeChange(key: ReactNode) {
    // setResourceType(Number(key));
    // setParams('resType', key);
    setResourceType(Number(key));
    setParams('resType', key);
    removeParams('activeTabKey');
  }

  function renderTabItem() {
    return (
      <React.Fragment>
          {appType === '1' && <Tab
            shape={'wrapped'}
            activeKey={resourceType}
            className={styles.tabContent}
            onChange={hendleResourceTypeChange}
          >
          {TabItem.map((item: any) => {
            return (
              <Tab.Item
                key={item.key}
                title={
                  <span className={styles.tabItem}>
                    <i className={item.value} />
                    {item.title}
                  </span>
                }
              >
                {resourceType === Number(item.key) && showType === 'details' && (
                  <ApiDetails
                    resourceType={resourceType}
                    pageType={pageType}
                  />
                )}
                {resourceType === Number(item.key) && showType === 'statistics' && (
                  <ApiStatistics
                    resourceType={resourceType}
                  />
                )}
              </Tab.Item>
            );
          })}
        </Tab>}
        
         { appType === '2' && showType === 'details' && (
            <ApiDetails
              resourceType={resourceType}
              pageType={pageType}
            />
          )}
      </React.Fragment>
    );
  }

  return (
    <div className={styles.content}>
      <Loading visible={loading} style={{ width: 'calc(100vw - 234px)', height: 'calc(100vh - 150px)' }}>
       <If condition={!loading}>
        {renderTabItem()}
       </If>
      </Loading>
    </div>
  );
};

export default SystemGuardApiDetails;
