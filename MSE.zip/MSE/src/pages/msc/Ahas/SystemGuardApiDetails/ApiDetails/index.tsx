import { } from '@alicloud/console-components';
import ApiDetailsCard from './ApiDetailsCard';
import ApiDetailsListTop from '../../common/DetailsListTop';
import React, { FC, useState } from 'react';
import styles from './index.module.less';

interface DetailsProps {
  resourceType: number;
  pageType?: string;
  dataBase?: string;
}

const ApiDetails: FC<DetailsProps> = props => {
  const { resourceType, pageType, dataBase } = props;
  const [activeResource, setActiveResource] = useState < any > ({});
  const [traffic, setTraffic] = useState < any > ('provider');

  const getActiveResource = (val: any) => {
    setActiveResource(val);
  };

  const getTraffic = (val: any) => {
    setTraffic(val);
  }

  return (
    <div className={styles.content}>
      <div className={styles.contentListTop}>
        <ApiDetailsListTop
          resourceType={resourceType}
          detailsType={'api'}
          pageType={pageType}
          changeActiveResource={getActiveResource}
          changeTraffic={getTraffic}
          dataBase={dataBase}
        />
      </div>
      <div className={styles.contentListDetails}>
        <ApiDetailsCard
          resourceType={resourceType}
          pageType={pageType}
          dataBase={dataBase}
          activeResource={activeResource}
          traffic={traffic}
        />
      </div>
    </div>
  );
};

export default ApiDetails;
