import React from 'react';
import intl from '@ali/wind-intl';

const AckUserGuide = () => {
  return (
    <div style={{ padding: 16, height: '100%', position: 'relative', background: '#f5f6fa', display: 'flex', justifyContent: 'center' }}>
      <div style={{ marginTop: 50 }}>
        <h4>{intl('mse.msc.AckUseGuide.fail.title')}</h4>
        <p>{intl('mse.msc.AckUseGuide.check.sequence')}</p>
        <ul style={{ listStyle: 'inside', listStyleType: 'auto', lineHeight: '24px', marginBottom: 16 }}>
          <li>{intl('mse.msc.AckUseGuide.li.one.message')}</li>
          <li>{intl('mse.msc.AckUseGuide.li.two.message')}</li>
          <li>{intl('mse.msc.AckUseGuide.li.three.message')}</li>
        </ul>
        {intl.html('mse.msc.AckUseGuide.access.document')}
      </div>
    </div>
  );
};

export default AckUserGuide;
