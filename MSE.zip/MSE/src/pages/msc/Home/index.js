import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { eventEmitter } from 'utils/loadWidget';
import AppLayout from 'containers/AppLayout';
import { WIDGET_EDAS_MSC } from 'constants';
import { isEmpty, get } from 'lodash';
import WidgetPermission from 'containers/WidgetPermission';
import { useStateStore } from '../../../store';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.overview'),
  },
];
const REGION_ID = window.regionId;
const widgetProps = {
  component: 'Home',
  searchValues: {
    regionId: REGION_ID,
  },
};
const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
const AppList = (props) => {
  const { message } = props;
  const state = useStateStore();
  const Status = get(state, 'MscAccount.Status');
  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-AppList`, goToAppList);
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-RouteTagList`, goToRouteTagList);
    eventEmitter.on(`${WIDGET_EDAS_MSC.id}:go-to-ServiceList`, goToServiceList);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-AppList`, goToAppList);
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-RouteTagList`, goToRouteTagList);
      eventEmitter.off(`${WIDGET_EDAS_MSC.id}:go-to-ServiceList`, goToServiceList);
    };
  }, []);

  const goToAppList = () => {
    const { history } = props;
    history.push('/msc/appList');
  };

  const goToServiceList = () => {
    const { history } = props;
    history.push('/msc/service');
  };

  const goToRouteTagList = () => {
    const { history } = props;
    history.push('/msc/appList');
  };
  const getMessage = () => {
    const item = {
      type: 'notice',
      text: intl.html('mse.msc.overview.notice1')
    };
    const item1 = {
      type: 'notice',
      text: intl.html('mse.msc.overview.notice')
    };
    if (isEmpty(message) && aliyunSite === 'INTL') {
      return [
        item,
      ];
    }
    if (aliyunSite !== 'INTL') {
      if (isEmpty(message)) {
        return [
          item,
          item1,
          // {
          //   type: 'notice',
          //   text: intl.html('mse.msc.overview.notice4')
          // },
        ];
      }
      return [
        item,
        item1,
        message,
        // {
        //   type: 'notice',
        //   text: intl.html('mse.msc.overview.notice4')
        // },
      ];
    }
    return [
      item,
      item1,
      message
    ];
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.msc.menu.overview')}
      message={aliyunSite === 'INTL' ? '' : getMessage()}
      target={'msc_home'}
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

AppList.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default AppList;
