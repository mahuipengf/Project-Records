import React from 'react';
import PropTypes from 'prop-types';
import WidgetPermission from 'containers/WidgetPermission';
import AppLayout from 'containers/AppLayout';
import intl from '@ali/wind-intl';

const REGION_ID = window.regionId;
const breadCrumbList = [
  {
    title: intl('mse.msc.menu.route'),
  },
];
const widgetProps = {
  component: 'NewRouteTagList',
  searchValues: {
    regionId: REGION_ID,
  },
};

const RouteTagList = (props) => {
  const { history, message } = props;
  const goToOldTag = () => {
    sessionStorage.setItem('mseShowOldTagRoute', true);
    history.push('/msc/route/tag');
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      // breadCrumbExpand={
      //   <div style={{ height: 16 }}>
      //     {intl('mse.common.ding.communication.group')}
      //     <img
      //       style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
      //       src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
      //     />
      //     <span style={{ color: '#0070cc', marginRight: 8 }}> 34754806 </span> {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/170454.html">Spring Cloud {intl('mse.msc.menu.route')}</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/170461.html">Dubbo {intl('mse.msc.menu.route')}</a>
      //   </div>
      // }
      title={
        <div style={{ height: 40 }}>
          {intl('mse.msc.menu.route')}
          <span className="link-primary" style={{ fontSize: 12, marginLeft: 4 }} onClick={goToOldTag}>{intl('mse.msc.router.old.version')}</span>
          {/* </span> */}
        </div>
      }
      message={message ? [message] : []}
    >
      <WidgetPermission widget="msc" widgetProps={widgetProps} />
    </AppLayout>
  );
};

RouteTagList.propTypes = {
  history: PropTypes.objectOf(PropTypes.any),
};
export default RouteTagList;
