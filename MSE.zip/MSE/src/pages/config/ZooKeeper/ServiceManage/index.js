import React, { useRef } from 'react';
import { TableContainer, Dialog, Message, Slider } from '@ali/cn-design';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import services from 'utils/services';
import intl from '@ali/wind-intl';
import AppIntoDialog from 'components/AppIntoDialog';

const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';

const slides = [
  {
    url:
      'https://img.alicdn.com/imgextra/i4/O1CN01i9bMvT1Y1acCQvUak_!!6000000002999-2-tps-1203-674.png',
    text: '接口详情',
  },
  {
    url:
      'https://img.alicdn.com/imgextra/i2/O1CN018m2KZc1gmJx9AyDnI_!!6000000004184-2-tps-816-191.png',
    text: '无损上下线',
  },
  {
    url:
      'https://img.alicdn.com/imgextra/i2/O1CN01Hmry3f1HQ0GEPyyRM_!!6000000000751-2-tps-788-246.png',
    text: '无损上下线',
  },
  {
    url:
      'https://img.alicdn.com/imgextra/i2/O1CN01CoB0eG1isOR6TSJEA_!!6000000004468-2-tps-791-406.png',
    text: '全链路灰度',
  },
];

const ServiceManage = () => {
  const dialogRef = useRef(null);
  const columns = [
    {
      key: 'Name',
      title: intl('mse.register.service.name'),
      dataIndex: 'Name',
      width: 300,
      cell: (value, index, record) => (
        <LinkButton onClick={() => goServiceDetail(record)}>{value}</LinkButton>
      ),
    },
    {
      key: 'ServiceType',
      title: intl('mse.register.service.zk.service_type'),
      dataIndex: 'ServiceType',
      width: 300,
    },
    {
      key: 'Action',
      title: intl('mse.common.operate'),
      dataIndex: 'Action',
      width: 200,
      cell: (value, index, record) => (
        <Actions>
          <LinkButton onClick={() => goServiceDetail(record)}>{intl('mse.common.view')}</LinkButton>
          <LinkButton onClick={() => getInstances(record)}>
            {intl('mse.register.service.zk.api_detail')}
          </LinkButton>
        </Actions>
      ),
    },
  ];

  const fetchData = async (tableParams) => {
    const { pageNumber: PageNum, pageSize: PageSize, ...extraParams } = tableParams;
    const InstanceId = getParams('InstanceId');
    const { Data = [], TotalCount } = await services.listZookeeperServices({
      params: {
        PageNum,
        PageSize,
        InstanceId,
        ServiceType: 'dubbo',
        ...extraParams,
      },
    });
    return {
      Data,
      TotalCount,
    };
  };

  const search = {
    filterInfo: {
      filters: [
        {
          label: intl('mse.register.service.name'),
          value: 'ServiceName',
        },
      ],
      defaultValue: 'ServiceName',
      placeholder: intl('mse.register.service.name_search'),
    },
    isCanRefresh: true,
  };

  const goServiceDetail = (record) => {
    const { Name = '' } = record;
    const ClusterId = getParams('ClusterId');
    const ClusterName = getParams('ClusterName');
    const ClusterType = getParams('ClusterType');
    const InstanceId = getParams('InstanceId');
    const AppVersion = getParams('AppVersion');
    const MseVersion = getParams('MseVersion');
    hashHistory.push(
      `/Instance/DataManager/ServiceDetail?ClusterId=${ClusterId}&ClusterName=${ClusterName}&ClusterType=${ClusterType}&InstanceId=${InstanceId}&AppVersion=${AppVersion}&MseVersion=${MseVersion}&ServiceName=${Name}&subTitle=${Name}`
    );
  };

  const getInstances = async (record) => {
    const { Name = '' } = record;
    const InstanceId = getParams('InstanceId');
    const data = await services.queryZookeeperProviders({
      params: {
        InstanceId,
        ServiceName: Name,
        Type: 'dubbo',
      },
    });
    const keys = Object.keys(data);
    const url = data[keys[0]][0]?.Url;
    const metadata = url
      .split('?')?.[1]
      ?.split('&')
      ?.map((item) => {
        const param = item.split('=');
        return { key: param[0], value: param[1] };
      });
    const appId = metadata.find((i) => i.key === '__micro.service.app.id__')?.value;
    if (appId) {
      window.open(
        `https://mse.console.aliyun.com/#/msc/app/info/information/interface?appId=${appId}`,
        'top'
      );
    } else {
      Dialog.confirm({
        type: 'warning',
        title: intl('mse.common.tips'),
        content: (
          <div style={{ width: 700, lineHeight: '18px' }}>
            <div style={{ marginBottom: 16 }}>{intl('mse.register.service.zk.api_message')}</div>
            <a
              target="_blank"
              href={
                aliyunSite === 'CN'
                  ? 'https://help.aliyun.com/document_detail/421977.html'
                  : 'https://www.alibabacloud.com/help/microservices-engine/latest/view-the-application-list'
              }
              style={{ marginRight: 16 }}
            >
              {intl('mse.register.service.zk.api_help1')}
            </a>
            <a
              href="javascript:;"
              onClick={() => dialogRef.current.open()}
              style={{ marginRight: 12 }}
            >
              {intl('mse.register.service.zk.api_help2')}
            </a>
            <a
              target="_blank"
              href={
                aliyunSite === 'CN'
                  ? 'https://help.aliyun.com/document_detail/170445.html'
                  : 'https://www.alibabacloud.com/help/microservices-engine/latest/overview-of-getting-started-with-microservice-centers'
              }
              style={{ marginRight: 16 }}
            >
              {intl('mse.register.service.zk.api_help3')}
            </a>
            <a target="_blank" href={'https://help.aliyun.com/document_detail/477794.html'}>
              {intl('mse.register.monitor.notice.learnmore')}
            </a>
            <div style={{ marginTop: 12 }}>
              <Slider arrows={false}>
                <div>
                  <img src={slides[0].url} alt={slides[0].text} style={{ width: '100%' }} />
                </div>
                <div>
                  <img src={slides[1].url} alt={slides[1].text} style={{ width: '100%' }} />
                  <img src={slides[2].url} alt={slides[2].text} style={{ width: '100%' }} />
                </div>
                <div>
                  <img src={slides[3].url} alt={slides[3].text} style={{ width: '100%' }} />
                </div>
              </Slider>
            </div>
          </div>
        ),
        messageProps: {
          type: 'warning',
        },
        footerActions: ['ok'],
        okProps: { children: intl('mse.common.ok') },
      });
    }
  };

  return (
    <React.Fragment>
      <If condition={getParams('MseVersion') === 'mse_dev'}>
        <Message type="notice" style={{ marginBottom: 8 }}>
          {intl.html('mse.register.service.zk.dev_message', {
            url:
              aliyunSite === 'CN'
                ? 'https://common-buy.aliyun.com/?commodityCode=mse_prepaid_public_cn&regionId=cn-hangzhou#/buy'
                : 'https://common-buy-intl.alibabacloud.com/?commodityCode=mse_prepaid_public_intl',
          })}
        </Message>
      </If>
      <TableContainer fetchData={fetchData} fixedFooter columns={columns} search={search} />
      <AppIntoDialog ref={dialogRef} />
    </React.Fragment>
  );
};

export default ServiceManage;
