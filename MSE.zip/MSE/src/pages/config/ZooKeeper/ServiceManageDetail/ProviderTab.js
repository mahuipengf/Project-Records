import React, { useState, useRef } from 'react';
import {
  NumberPicker,
  Button,
  Dialog,
  Balloon,
  Icon,
  CopyContent,
  Table,
  Message,
  Tag,
  Slider,
} from '@ali/cn-design';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import services from 'utils/services';
import intl from '@ali/wind-intl';
import CommonDialog from 'components/base/CommonDialog';
import ResourceTag from 'components/TagsResource/ResourceTag';
import CommonBalloon from 'components/common/CommonBalloon';
import { getCurrentRegion } from 'src/utils/index';
import AppIntoDialog from 'components/AppIntoDialog';

const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';

const slides = [
  {
    url:
      'https://img.alicdn.com/imgextra/i4/O1CN01i9bMvT1Y1acCQvUak_!!6000000002999-2-tps-1203-674.png',
    text: '接口详情',
  },
  {
    url:
      'https://img.alicdn.com/imgextra/i2/O1CN018m2KZc1gmJx9AyDnI_!!6000000004184-2-tps-816-191.png',
    text: '无损上下线',
  },
  {
    url:
      'https://img.alicdn.com/imgextra/i2/O1CN01Hmry3f1HQ0GEPyyRM_!!6000000000751-2-tps-788-246.png',
    text: '无损上下线',
  },
  {
    url:
      'https://img.alicdn.com/imgextra/i2/O1CN01CoB0eG1isOR6TSJEA_!!6000000004468-2-tps-791-406.png',
    text: '全链路灰度',
  },
];

const ProviderTab = ({ dataSource, loading, onRefresh, apiMetadata, serviceParams, appName }) => {
  const weightRef = useRef(null);
  const dialogRef = useRef(null);
  const [weight, setWeight] = useState(0);
  const [weightLoading, setWeightLoading] = useState(false);
  const [currentRecord, setCurrentRecord] = useState({});

  const columns = [
    {
      key: 'Ip',
      dataIndex: 'Ip',
      title: 'IP:Port',
      width: 200,
      cell: (value, index, record) => {
        const url = record.Url;
        return (
          <div>
            <span style={{ marginRight: 8 }}>
              {value}:{record.Port}
            </span>
            <Balloon
              trigger={<Icon type="connection" size="small" style={{ cursor: 'pointer' }} />}
              triggerType="hover"
              closable={false}
              align="r"
            >
              <CopyContent visibility text={url.repeat(1)}>
                {url.repeat(1)}
              </CopyContent>
            </Balloon>
          </div>
        );
      },
    },
    {
      key: 'Serialization',
      dataIndex: 'Serialization',
      title: intl('mse.register.service.zk.serialization'),
      width: 100,
    },
    {
      key: 'Disabled',
      title: intl('mse.register.cluster.app.enabled'),
      dataIndex: 'Disabled',
      width: 150,
      align: 'center',
      cell: (value) => (
        <span>
          <If condition={value}>
            <span className="circle-status red" />
          </If>
          <If condition={!value}>
            <span className="circle-status green" />
          </If>
        </span>
      ),
    },
    {
      key: 'Timeout',
      dataIndex: 'Timeout',
      title: intl('mse.register.service.zk.timeout'),
      width: 150,
    },
    {
      key: 'Weight',
      dataIndex: 'Weight',
      title: intl('mse.register.cluster.app.weight'),
      width: 150,
    },
    {
      key: 'Meta',
      title: intl('mse.register.cluster.app.meta'),
      dataIndex: 'Meta',
      align: 'center',
      width: 400,
      cell: (value, index, record) => renderMeta(record),
    },
    {
      key: 'Action',
      dataIndex: 'Action',
      title: intl('mse.common.operate'),
      width: 200,
      cell: (value, index, record) => (
        <Actions>
          {/* <LinkButton onClick={() => handleOpenWeight(record)}>
            {intl('mse.register.service.provider.weight_edit')}
          </LinkButton> */}
          <If condition={record.Disabled}>
            <LinkButton onClick={() => handleLineStatus(record)}>
              {intl('mse.register.cluster.action.online')}
            </LinkButton>
          </If>
          <If condition={!record.Disabled}>
            <LinkButton onClick={() => handleLineStatus(record)}>
              {intl('mse.register.cluster.action.offline')}
            </LinkButton>
          </If>
        </Actions>
      ),
    },
  ];

  const apiMetaDataColumns = [
    {
      key: 'name',
      dataIndex: 'name',
      title: intl('mse.register.service.zk.method_name'),
      width: 300,
    },
    {
      key: 'parameterTypes',
      dataIndex: 'parameterTypes',
      title: intl('mse.register.service.zk.params_list'),
      width: 300,
    },
    {
      key: 'returnType',
      dataIndex: 'returnType',
      title: intl('mse.register.service.zk.return_type'),
      width: 300,
    },
  ];

  const renderMeta = (record) => {
    const metadata = record?.Url.split('?')?.[1]
      ?.split('&')
      ?.map((item) => {
        const param = item.split('=');
        return { key: param[0], value: param[1] };
      });
    return (
      <div>
        <If condition={metadata.length}>
          {metadata.slice(0, 2).map((data) => {
            return (
              <ResourceTag keyLabel={data.key} valueLabel={data.value} style={{ marginRight: 4 }} />
            );
          })}
          <If condition={metadata.length > 2}>
            <CommonBalloon
              align="r"
              content={metadata.map((data) => {
                return (
                  <ResourceTag
                    keyLabel={data.key}
                    valueLabel={data.value}
                    style={{ marginRight: 4 }}
                  />
                );
              })}
            >
              <Tag size="small">...</Tag>
            </CommonBalloon>
          </If>
        </If>
        <If condition={!metadata.length}>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            {intl('mse.common.empty')}
          </div>
        </If>
      </div>
    );
  };
  const renderWeightFooter = () => {
    return (
      <div style={{ textAligin: 'right' }}>
        <Button
          type="primary"
          style={{ marginRight: 4 }}
          onClick={handleEditWeight}
          loading={weightLoading}
        >
          {intl('mse.common.ok')}
        </Button>
        <Button
          onClick={() => {
            weightRef.current.close();
          }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );
  };

  const handleOpenWeight = (record) => {
    weightRef.current.open();
    setWeight(record.Weight);
    setCurrentRecord(record);
  };

  const changeWeight = (value) => {
    setWeight(value);
  };

  const handleEditWeight = async () => {
    const ClusterId = getParams('ClusterId');
    const InstanceId = getParams('InstanceId');
    const ServiceName = getParams('ServiceName');
    const { Ip, Port } = currentRecord;
    setWeightLoading(true);
    const params = {
      ClusterId,
      ServiceName,
      InstanceId,
      Weight: weight,
      Type: 'dubbo',
      Address: `${Ip}:${Port}`,
      ...serviceParams,
    };
    await services.updateZookeeperProvider({
      params,
      customErrorHandle: (err, data, callback) => {
        weightRef.current.close();
        setWeightLoading(false);
        callback();
      },
    });
    weightRef.current.close();
    setWeightLoading(false);
    onRefresh();
  };

  // const handleLineStatus = (record, type) => {
  //   Dialog.confirm({
  //     title:
  //       type === 'on'
  //         ? intl('mse.register.service.provider.online_title')
  //         : intl('mse.register.service.provider.offline_title'),
  //     content:
  //       type === 'on'
  //         ? intl('mse.register.service.provider.online_tip')
  //         : intl('mse.register.service.provider.offline_tip'),
  //     onOk: async () => {
  //       const ClusterId = getParams('ClusterId');
  //       const InstanceId = getParams('InstanceId');
  //       const ServiceName = getParams('ServiceName');
  //       const { Ip, Port } = record;
  //       const params = {
  //         ClusterId,
  //         ServiceName,
  //         InstanceId,
  //         Weight: weight,
  //         Type: 'dubbo',
  //         Address: `${Ip}:${Port}`,
  //         ...serviceParams,
  //         Disabled: type === 'off',
  //       };
  //       await services.updateZookeeperProvider({
  //         params,
  //         customErrorHandle: (err, data, callback) => {
  //           callback();
  //         },
  //       });
  //       onRefresh();
  //     },
  //     okProps: { children: intl('mse.common.ok') },
  //     cancelProps: { children: intl('mse.common.cancel') },
  //   });
  // };

  const handleLineStatus = async (record) => {
    const { Metadata = '{}' } = record;
    const region = getCurrentRegion();
    const metadata = JSON.parse(Metadata)?.parameters;
    if (metadata?.hasOwnProperty('__micro.service.app.id__')) {
      const appId = metadata['__micro.service.app.id__'];
      const { Result = [] } = await services.getApplicationList({
        params: {
          PageSize: 10,
          PageNumber: 1,
          AppId: appId,
          Region: region,
        },
      });
      const ns = Result[0]?.Namespace;
      window.open(
        `https://mse.console.aliyun.com/#/msc/appList/info/nodeDetails?accessType=&armsAppId=${appId}&ahasAppName=${appName}&region=${region}&appName=${appName}&ns=${ns}`,
        'top'
      );
    } else {
      Dialog.confirm({
        type: 'warning',
        title: intl('mse.common.tips'),
        content: (
          <div style={{ width: 700, lineHeight: '18px' }}>
            <div style={{ marginBottom: 16 }}>{intl('mse.register.service.zk.api_message')}</div>
            <a
              target="_blank"
              href={
                aliyunSite === 'CN'
                  ? 'https://help.aliyun.com/document_detail/421977.html'
                  : 'https://www.alibabacloud.com/help/microservices-engine/latest/view-the-application-list'
              }
              style={{ marginRight: 16 }}
            >
              {intl('mse.register.service.zk.api_help1')}
            </a>
            <a
              href="javascript:;"
              onClick={() => dialogRef.current.open()}
              style={{ marginRight: 12 }}
            >
              {intl('mse.register.service.zk.api_help2')}
            </a>
            <a
              target="_blank"
              href={
                aliyunSite === 'CN'
                  ? 'https://help.aliyun.com/document_detail/170445.html'
                  : 'https://www.alibabacloud.com/help/microservices-engine/latest/overview-of-getting-started-with-microservice-centers'
              }
              style={{ marginRight: 16 }}
            >
              {intl('mse.register.service.zk.api_help3')}
            </a>
            <a target="_blank" href={'https://help.aliyun.com/document_detail/477794.html'}>
              {intl('mse.register.monitor.notice.learnmore')}
            </a>
            <div style={{ marginTop: 12 }}>
              <Slider arrows={false}>
                <div>
                  <img src={slides[1].url} alt={slides[1].text} style={{ width: '100%' }} />
                  <img src={slides[2].url} alt={slides[2].text} style={{ width: '100%' }} />
                </div>
                <div>
                  <img src={slides[0].url} alt={slides[0].text} style={{ width: '100%' }} />
                </div>
                <div>
                  <img src={slides[3].url} alt={slides[3].text} style={{ width: '100%' }} />
                </div>
              </Slider>
            </div>
          </div>
        ),
        messageProps: {
          type: 'warning',
        },
        footerActions: ['ok'],
        okProps: { children: intl('mse.common.ok') },
      });
    }
  };

  return (
    <div style={{ marginTop: 12 }}>
      {/* <Message type="notice" style={{ marginBottom: 12 }}>
        {intl.html('mse.register.service.zk.message1', {
          url1:
            aliyunSite === 'CN'
              ? 'https://help.aliyun.com/document_detail/190106.html'
              : 'https://www.alibabacloud.com/help/microservices-engine/latest/configure-dynamic-timeout',
          url2:
            aliyunSite === 'CN'
              ? 'https://help.aliyun.com/document_detail/475425.html '
              : 'https://www.alibabacloud.com/help/microservices-engine/latest/test',
        })}
      </Message> */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 8 }}>
        <Button
          onClick={onRefresh}
          style={{
            width: 32,
            height: 32,
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Icon type="refresh" />
        </Button>
      </div>
      <Table columns={columns} dataSource={dataSource} loading={loading} hasBorder={false} />
      <div>
        <h3>{intl('widget.service.interface_metadata')}</h3>
        <Table
          columns={apiMetaDataColumns}
          dataSource={apiMetadata}
          loading={loading}
          hasBorder={false}
        />
      </div>
      <CommonDialog
        title={intl('mse.register.service.provider.weight_edit')}
        style={{ width: 480 }}
        childStyle={{ height: 100, overflowX: 'hidden' }}
        footer={renderWeightFooter()}
        ref={weightRef}
        shouldUpdatePosition
      >
        <div>
          <span style={{ fontSize: 12, marginRight: 24 }}>
            {intl('mse.register.cluster.app.weight')}
          </span>
          <NumberPicker value={weight} onChange={changeWeight} min={0} max={10000} type="inline" />
          <p style={{ fontSize: 12, marginLeft: 44, marginTop: 8, color: '#666' }}>
            {intl('mse.register.cluster.weight_hint')}
          </p>
        </div>
      </CommonDialog>
      <AppIntoDialog ref={dialogRef} />
    </div>
  );
};

export default ProviderTab;
