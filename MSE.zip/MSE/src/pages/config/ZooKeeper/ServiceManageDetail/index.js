import React, { useState, useEffect } from 'react';
import services from 'utils/services';
import intl from '@ali/wind-intl';
import { Tab, Grid, Loading, TableContainer, Select } from '@ali/cn-design';
import { get, uniqBy } from 'lodash';
import ProviderTab from './ProviderTab';

const { Row, Col } = Grid;

const commonStyle = {
  labelStyle: {
    color: '#111111',
  },
  contentStyle: {
    color: '#555555',
  },
  rowStyle: {
    lineHeight: '20px',
    fontSize: '12px',
    marginBottom: 8,
    display: 'flex',
    alignItems: 'center',
  },
};

let timer = null;

const ServiceManageDetail = () => {
  const [loading, setLoading] = useState(false);
  const [basicInfo, setBasicInfo] = useState({});
  const [allProviderListData, setAllProviderListData] = useState({});
  const [providerListData, setProviderListData] = useState([]);
  const [apiMetadata, setApiMetadata] = useState([]);
  const [groupList, setGroupList] = useState([]);
  const [versionList, setVersionList] = useState([]);
  const [allFilterList, setAllFilterList] = useState([]);
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [activeKey, setActiveKey] = useState('provider');
  const [hasLoading, setHasLoading] = useState(true);

  const ConsumerColumns = [
    {
      key: 'Ip',
      dataIndex: 'Ip',
      title: 'IP',
      width: 300,
    },
    {
      key: 'Application',
      dataIndex: 'Application',
      title: intl('mse.common.app.name'),
      width: 300,
    },
  ];

  const getProviders = async (hasLoading = true) => {
    setHasLoading(hasLoading);
    hasLoading && setLoading(true);
    const InstanceId = getParams('InstanceId');
    const ServiceName = getParams('ServiceName');
    const data = await services.queryZookeeperProviders({
      params: {
        InstanceId,
        ServiceName,
        Type: 'dubbo',
      },
    });
    hasLoading && setLoading(false);
    setAllProviderListData(data);
    const keys = Object.keys(data);
    if (keys.length) {
      const { Group = '', Version = '' } = basicInfo;
      const Application = data[keys[0]][0].Application;
      const Service = data[keys[0]][0].Service;
      const _Group = Group || data[keys[0]][0].Group;
      const _Version = Version || data[keys[0]][0].Version;
      const MetaData = data[keys[0]][0].Metadata;
      setBasicInfo({
        Service,
        Application,
        Group: _Group,
        Version: _Version,
      });
      if (MetaData) {
        setApiMetadata(JSON.parse(MetaData)?.methods);
      }
      if (!Group && !Version) {
        setProviderListData(data[keys[0]]);
      }
      const allFilters = keys.map((key) => {
        const group = key.split('/')[1];
        const version = key.split(':')[1];
        return { group, version, key };
      });
      const groups = uniqBy(allFilters, 'group').map((i) => {
        return { label: i.group, value: i.group };
      });
      const versions = allFilters
        .filter((i) => i.group === _Group)
        .map((i) => {
          return { label: i.version, value: i.version };
        });
      setAllFilterList(allFilters);
      setVersionList(versions);
      setGroupList(groups);
    }
  };

  const getFilterProviders = () => {
    hasLoading && setLoading(true);
    const { Group = '', Version = '' } = basicInfo;
    const key = allFilterList.find((i) => i.group === Group && i.version === Version)?.key;
    const versions = allFilterList
      .filter((i) => i.group === Group)
      .map((i) => {
        return { label: i.version, value: i.version };
      });
    setVersionList(versions);
    setProviderListData(allProviderListData[key]);
    hasLoading &&
      setTimeout(() => {
        setLoading(false);
      }, 1000);
  };

  const getConsumers = async () => {
    const InstanceId = getParams('InstanceId');
    const ServiceName = getParams('ServiceName');
    const Data = await services.queryZookeeperConsumers({
      params: {
        InstanceId,
        ServiceName,
        Type: 'dubbo',
        ServiceVersion: basicInfo?.Version,
        ServiceGroup: basicInfo?.Group,
      },
    });
    return {
      Data,
      TotalCount: Data.length,
    };
  };

  const onChangeGroup = (value) => {
    if (timer) {
      clearInterval(timer);
      setHasLoading(true);
    }
    const version = allFilterList.find((i) => i.group === value)?.version;
    setBasicInfo({ ...basicInfo, Group: value, Version: version });
  };

  const onChangeVersion = (value) => {
    if (timer) {
      clearInterval(timer);
      setHasLoading(true);
    }
    setBasicInfo({ ...basicInfo, Version: value });
  };

  const onRefresh = () => {
    timer && clearInterval(timer);
    let count = 10;
    timer = setInterval(() => {
      if (count === 10) {
        getProviders(true);
      }
      count--;
      if (count <= 0) {
        clearInterval(timer);
      }
      getProviders(false);
    }, 1000);
  };

  useEffect(() => {
    getFilterProviders();
  }, [basicInfo]);

  useEffect(() => {
    activeKey === 'consumer' && setRefreshIndex(Date.now());
  }, [basicInfo, activeKey]);

  useEffect(() => {
    const ServiceName = getParams('ServiceName');
    ServiceName && getProviders();
  }, []);

  return (
    <div className="mse-nacos-service-detail">
      <div style={{ marginBottom: 16 }}>
        <Loading visible={loading} style={{ width: '100%' }}>
          <div
            style={{
              border: '1px solid rgb(220, 223, 230)',
              background: 'rgb(249, 249, 249)',
              padding: '16px 24px',
            }}
          >
            <Row style={commonStyle.rowStyle}>
              <Col span={3} style={commonStyle.labelStyle}>
                {intl('mse.register.service.name')}
              </Col>
              <Col span={9} style={commonStyle.contentStyle}>
                {get(basicInfo, 'Service', '-')}
              </Col>
              <Col span={3} style={commonStyle.labelStyle}>
                {intl('mse.register.service.group')}
              </Col>
              <Col span={9} style={commonStyle.contentStyle}>
                <If condition={basicInfo.Group}>
                  <Select
                    dataSource={groupList}
                    value={basicInfo?.Group}
                    style={{ width: 200 }}
                    hasBorder={false}
                    onChange={onChangeGroup}
                  />
                </If>
                <If condition={!basicInfo.Group}>-</If>
              </Col>
            </Row>
            <Row style={commonStyle.rowStyle}>
              <Col span={3} style={commonStyle.labelStyle}>
                {intl('mse.common.app.name')}
              </Col>
              <Col span={9} style={commonStyle.contentStyle}>
                {get(basicInfo, 'Application', '-')}
              </Col>
              <Col span={3} style={commonStyle.labelStyle}>
                {intl('mse.register.version')}
              </Col>
              <Col span={9} style={commonStyle.contentStyle}>
                <If condition={basicInfo.Version}>
                  <Select
                    dataSource={versionList}
                    value={basicInfo?.Version}
                    style={{ width: 200 }}
                    hasBorder={false}
                    onChange={onChangeVersion}
                  />
                </If>
                <If condition={!basicInfo.Version}>-</If>
              </Col>
            </Row>
          </div>
        </Loading>
      </div>
      <div>
        <Tab shape="wrapped" activeKey={activeKey} onChange={(key) => setActiveKey(key)}>
          <Tab.Item title={intl('mse.register.service.provider')} key="provider">
            <ProviderTab
              dataSource={providerListData}
              loading={loading}
              onRefresh={onRefresh}
              apiMetadata={apiMetadata}
              serviceParams={{ ServiceVersion: basicInfo?.Version, ServiceGroup: basicInfo?.Group }}
              appName={basicInfo?.Application}
            />
          </Tab.Item>
          <Tab.Item title={intl('mse.register.service.subscriber')} key="consumer">
            <div style={{ marginTop: 12 }}>
              <TableContainer
                refreshIndex={refreshIndex}
                columns={ConsumerColumns}
                fetchData={getConsumers}
                search={{ isCanRefresh: true }}
                pagination={{ hideOnlyOnePage: true, pageSize: 10000 }}
              />
            </div>
          </Tab.Item>
        </Tab>
      </div>
    </div>
  );
};

export default ServiceManageDetail;
