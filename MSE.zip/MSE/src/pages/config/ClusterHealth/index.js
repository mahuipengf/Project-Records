import React, { useEffect, useState, useCallback, useRef } from 'react';
import intl from '@ali/wind-intl';
import { Loading, Button, Grid, Switch, Pagination, Message, BalloonIcon } from '@ali/cn-design';
import { trim, includes, get, isObject, isEmpty, map } from 'lodash';
import moment from 'moment';
import services from 'utils/services';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import Status from 'components/Status';
import { EngineSpecs, CheckStatus } from './constants';
import './index.less';

const { Row, Col } = Grid;
const commonStyle = {
  labelStyle: {
    color: '#333333',
    fontWeight: 500,
  },
  contentStyle: {
    color: '#333333',
    fontWeight: 400,
  },
  rowStyle: {
    lineHeight: '20px',
    fontSize: '12px',
    marginBottom: 8,
  },
};

const defaultTask = {
  InstanceId: '-',
  Spec: '-',
  Replica: '-',
  AppVersion: '-',
  Status: '-',
  Score: '-',
  TotalRisk: 0,
  RiskList: [],
  CreateTime: '0000-00-00 00:00:00',
};

const ClusterHealth = (props) => {
  const InstanceId = getParams('InstanceId');
  const [clusterTasks, setClusterTasks] = useState([]);
  const [taskOverview, setTaskOverview] = useState(defaultTask);
  const [HealthColor, updateHealthColor] = useState('#c1c1c1');
  const [CheckColor, updateCheckColor] = useState('#0070cc');
  const [HealthText, updateHealthText] = useState('-');
  const [currentRiskCode, setCurrentRiskCode] = useState();
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalSize, setTotalSize] = useState(0);

  // 定时器
  const timerRef = useRef(null);

  useEffect(() => {
    getClusterHealthTask();
  }, [refreshIndex, currentPage]);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, []);

  const getClusterHealthTask = async (isSeo) => {
    const PageNum = isSeo ? 0 : currentPage - 1;
    const { Result: res, TotalSize: _totalSize = 0 } = await services.getClusterHealthCheckTask({
      customErrorHandle: (err, data, callback) => {
        callback();
      },
      params: { InstanceId, PageNum, PageSize: 10 },
    });
    const _clusterTasks = res || [];
    setClusterTasks(_clusterTasks);
    setTotalSize(_totalSize);
    if (currentPage !== 1) return;
    // 如果是首屏显示 展示以下逻辑
    const [_taskOverview = defaultTask] = res;
    const { Score, Status } = _taskOverview;
    const { healthText, healthColor, checkColor } = getHealthSetColor(Score, Status);
    setTaskOverview(_taskOverview);
    updateHealthColor(healthColor);
    updateHealthText(healthText);
    updateCheckColor(checkColor);
    if (Status === 'SUCCESS' && timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const getHealthSetColor = (score, status) => {
    let healthText = '-';
    let healthColor = '#c1c1c1';
    let checkColor = '#0070cc';
    if (status !== 'SUCCESS') {
      return { healthText, healthColor, checkColor };
    }
    if (status === 'SUCCESS' && score >= 0 && score <= 59) {
      healthText = intl('mse.register.risk.level_high');
      healthColor = '#d93026';
      checkColor = '#d93026';
    }
    if (status === 'SUCCESS' && score >= 60 && score <= 79) {
      healthText = intl('mse.register.risk.level_mid');
      healthColor = '#f1a600';
      checkColor = '#f1a600';
    }
    if (status === 'SUCCESS' && score >= 80 && score <= 99) {
      healthText = intl('mse.register.risk.level_low');
      healthColor = '#b38300';
      checkColor = '#b38300';
    }
    if (status === 'SUCCESS' && score === 100) {
      healthText = intl('mse.register.risk.level_health');
      healthColor = '#009940';
      checkColor = '#009940';
    }
    return { healthText, healthColor, checkColor };
  };

  const riskOptionLinks = (links) =>
    map(links, (link) => {
      const { type, desc, value } = link;
      if (type === 'url') {
        return <LinkButton data-tracker="health-url" onClick={() => window.open(value)}>{desc}</LinkButton>;
      }
      if (type === 'upgrade') {
        // 升配
        return <LinkButton data-tracker="health-upgrade" onClick={() => changeUpgrade()}>{desc}</LinkButton>;
      }
    });

  const useRiskMark = (mark) => {
    if (mark === 'HIGH') {
      return (
        <div style={{ backgroundColor: '#fff0f0', display: 'flex', justifyContent: 'center' }}>
          <div style={{ color: '#d93026' }}>{intl('mse.register.risk.level_high')}</div>
        </div>
      );
    }
    if (mark === 'MID') {
      return (
        <div style={{ backgroundColor: '#fff2e6', display: 'flex', justifyContent: 'center' }}>
          <div style={{ color: '#f1a600' }}>{intl('mse.register.risk.level_mid')}</div>
        </div>
      );
    }
    if (mark === 'LOW') {
      return (
        <div style={{ backgroundColor: '#fffae0', display: 'flex', justifyContent: 'center' }}>
          <div style={{ color: '#b38300' }}>{intl('mse.register.risk.level_low')}</div>
        </div>
      );
    }
  };

  const changeUpgrade = () => {
    const { ChargeType } = taskOverview;
    if (ChargeType === 'POSTPAY') {
      changeUpPOSTPAYGrade();
    }
    if (ChargeType === 'PREPAY') {
      changeUpPREPAYGrade();
    }
  };

  const changeUpPREPAYGrade = () => {
    let commodityCode = 'mse_prepaid_public_cn';
    let changeDomain = 'https://common-buy.aliyun.com';
    const VirtualNetwork = ['JST', 'CAINIAO', 'NEW_RETAIL'];
    const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
    const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
    const isIntl = aliyunSite === 'INTL';
    if (includes(VirtualNetwork, channel)) {
      commodityCode = 'mse_prepaid_public_cn';
      changeDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      commodityCode = 'mse_prepaid_public_intl';
      changeDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    const uppriceUrl = `${changeDomain}/?commodityCode=${commodityCode}&orderType=upgrade&instanceId=${InstanceId}&upgradeType=upgrade`;
    window.open(uppriceUrl);
  };

  const changeUpPOSTPAYGrade = () => {
    let commodityCode = 'mse';
    let upgradeDomain = 'https://common-buy.aliyun.com';
    const VirtualNetwork = ['JST', 'CAINIAO', 'NEW_RETAIL'];
    const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
    const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
    const isIntl = aliyunSite === 'INTL';
    if (includes(VirtualNetwork, channel)) {
      commodityCode = 'mse';
      upgradeDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      commodityCode = 'mse_msepost_public_intl';
      upgradeDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    const uppriceUrl = `${upgradeDomain}/?commodityCode=${commodityCode}&orderType=upgrade&instanceId=${InstanceId}&upgradeType=upgrade`;
    window.open(uppriceUrl);
  };

  const orderClusterAlarmNotice = async (checked, risk) => {
    const { RiskCode } = risk;
    setCurrentRiskCode(RiskCode);
    const res = await services.orderClusterRiskNotice({
      customErrorHandle: (err, data, callback) => {
        setCurrentRiskCode();
        callback();
      },
      params: { InstanceId, RiskCode, Mute: !checked },
    });
    setCurrentRiskCode();
    setCurrentPage(1);
    setRefreshIndex(Date.now());
  };

  const putClusterHealthCheck = async () => {
    const { Status: _Status } = taskOverview;
    if (_Status === 'CREATE' || _Status === 'RUNNING') {
      Message.warning(
        intl.html('mse.register.risk.launch.warn', { state: _Status === 'CREATE' ? intl('mse.register.risk.check.create') : intl('mse.register.risk.check.run') })
      );
      return;
    }
    setIsLoading(true);
    const res = await services.putClusterHealthCheck({
      customErrorHandle: (err, data, callback) => {
        setIsLoading(false);
        callback();
      },
      params: { InstanceId },
    });
    setIsLoading(false);
    setCurrentPage(1);
    setRefreshIndex(Date.now());
    if (!timerRef.current) {
      timerRef.current = setInterval(() => {
        getClusterHealthTask(true);
      }, 1000 * 10);
    }
  };

  const {
    Score,
    TotalRisk,
    InstanceId: _InstanceId,
    Spec,
    Replica,
    AppVersion,
    Status: _Status,
    RiskList,
    CreateTime,
  } = taskOverview;

  return (
    <div data-wrapper="mse-config-health-risk">
      <div className="sky-card">
        <div className="card-head">
          <div className="card-title">{intl('mse.register.risk.title')}</div>
        </div>
        <div className="card-content">
          <div className="sas-score-container" style={{ '--bgColor': HealthColor }}>
            <div className="score-chart">
              <div className="circle-wave">
                <div className="circle-wave-bg" />
                <div className="circle-wave-inner">
                  <div className="circle-wave-value">
                    <span>{ _Status === 'SUCCESS' ? Score : '-' }</span>
                    <div className="unit">{intl('mse.register.risk.score.unit')}</div>
                  </div>
                  <div className="circle-wave-desc">{HealthText}</div>
                </div>
              </div>
            </div>
            <div className="extra-info">
              <div className="title">
                <p className="risk-title">
                  {intl.html('mse.register.risk.question.nums', { num: _Status === 'SUCCESS' ? TotalRisk : '-', color: HealthColor })}
                </p>
                <span className="risk-desc">{intl.html('mse.register.risk.create', { time: CreateTime })}</span>
              </div>
              <Button
                className="check"
                style={{ '--buttonColor': CheckColor }}
                loading={isLoading}
                onClick={putClusterHealthCheck}
                data-tracker="health-check"
              >
                {intl('mse.register.risk.launch')}
              </Button>
            </div>
          </div>
          <div className="sas-info-container">
            <div className="info-content">
              <Row style={commonStyle.rowStyle}>
                <Col span={3} style={commonStyle.labelStyle}>
                  {intl('mse.register.risk.instance.id')}
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {_InstanceId}
                </Col>
                <Col span={3} style={commonStyle.labelStyle}>
                  {intl('mse.register.risk.instance.specs')}
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {EngineSpecs(intl).get(Spec) || Spec || '-'}
                </Col>
              </Row>
              <Row style={commonStyle.rowStyle}>
                <Col span={3} style={commonStyle.labelStyle}>
                  {intl('mse.register.risk.instance.replica')}
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {Replica || '-'}
                </Col>
                <Col span={3} style={commonStyle.labelStyle}>
                  {intl('mse.register.risk.instance.engine')}
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  {AppVersion || '-'}
                </Col>
              </Row>
              <Row style={commonStyle.rowStyle}>
                <Col span={3} style={commonStyle.labelStyle}>
                  {intl('mse.register.risk.instance.check')}
                </Col>
                <Col span={9} style={commonStyle.contentStyle}>
                  <Status value={_Status} dataSource={CheckStatus(intl)} />
                </Col>
              </Row>
            </div>
          </div>
        </div>
      </div>

      <div className="est-content">
        <If condition={clusterTasks.length}>
          <div className="est-left">
            <If condition={!RiskList.length}>
              <div className="no-data-bg">
                <img
                  src="https://img.alicdn.com/tfs/TB1QbgAeQL0gK0jSZFAXXcA9pXa-160-144.png"
                  style={{ height: 96, marginBottom: 12 }}
                />
                <div className="no-data-text">{intl('mse.register.risk.no_data')}</div>
              </div>
            </If>
            <If condition={RiskList.length}>
              {map(RiskList, (risk) => {
                const {
                  RiskName = '-',
                  Description,
                  Situation,
                  Suggestion,
                  Mute = false,
                  RiskCode,
                  RiskLevel,
                  NoticeFeature = true,
                } = risk;
                const _Description = JSON.parse(Description) || { desc: '' };
                const { desc: RiskDesc, links: DescLinks = [] } = _Description;
                const _Situation = JSON.parse(Situation) || { desc: '' };
                const { desc: RiskSite, links: SiteLinks = [] } = _Situation;
                const _Suggestion = JSON.parse(Suggestion) || { desc: '' };
                const { desc: RiskSuggest, links: SuggestLinks = [] } = _Suggestion;
                return (
                  <div className="est-option" style={{ '--bgColor': HealthColor }}>
                    <div className="opt-head">
                      <div className="opt-title">{RiskName}</div>
                      <div className="opt-mark">{useRiskMark(RiskLevel)}</div>
                    </div>
                    <div className="opt-content">
                      <div className="opt-left-container">
                        <div className="opt-desc">
                          {RiskDesc}
                          <If condition={DescLinks.length}>
                            <Actions
                              threshold={3}
                              style={{ display: 'inline-block', marginLeft: 10 }}
                            >
                              {riskOptionLinks(DescLinks)}
                            </Actions>
                          </If>
                        </div>
                        <If condition={NoticeFeature}>
                          <div className="opt-msg">
                            <span style={{ color: "#333'", marginRight: 0 }}>{intl('mse.register.risk.receive.note')}</span>
                            <BalloonIcon
                              icon="help"
                              align="r"
                              style={{
                                color: '#808080',
                                fontSize: '12px',
                                marginLeft: '5px',
                              }}
                              text={intl.html('mse.register.risk.receive.note.tip')}
                            />
                            <Switch
                              checked={!Mute}
                              loading={currentRiskCode === RiskCode}
                              style={{ marginLeft: 16 }}
                              onChange={(v) => orderClusterAlarmNotice(v, risk)}
                            />
                          </div>
                        </If>
                      </div>
                      <div className="opt-right-container">
                        <div className="opt-item" style={{ marginBottom: 10 }}>
                          <span className="opt-item-title">{intl('mse.register.risk.present')}</span>
                          <span className="opt-item-desc">
                            {RiskSite}
                            <If condition={SiteLinks.length}>
                              <Actions
                                threshold={3}
                                style={{ display: 'inline-block', marginLeft: 10 }}
                              >
                                {riskOptionLinks(SiteLinks)}
                              </Actions>
                            </If>
                          </span>
                        </div>
                        <div className="opt-item">
                          <span className="opt-item-title">{intl('mse.register.risk.suggest')}</span>
                          <span className="opt-item-desc">
                            {RiskSuggest}
                            <If condition={SuggestLinks.length}>
                              <Actions
                                threshold={3}
                                style={{ display: 'inline-block', marginLeft: 10 }}
                              >
                                {riskOptionLinks(SuggestLinks)}
                              </Actions>
                            </If>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </If>
          </div>
          <div className="est-right">
            <div className="est-title">{intl('mse.register.risk.history')}</div>
            <div className="est-check">
              {map(clusterTasks, (task) => {
                const { Id, TotalRisk, Score, Status, CreateTime } = task;
                const { healthColor } = getHealthSetColor(Score, Status);
                return (
                  <div key={Id} className="check-item">
                    <div className="check-title">
                      {intl.html('mse.register.risk.question.num', { num: Status === 'SUCCESS' ? TotalRisk : '-' })}
                      <span style={{ color: healthColor }}>
                        {intl.html('mse.register.risk.score', { score: Status === 'SUCCESS' ? Score : '-' })}
                      </span>
                    </div>
                    <div className="check-date">{CreateTime}</div>
                  </div>
                );
              })}
            </div>
            <Pagination
              current={currentPage}
              pageSizePosition="end"
              shape="no-border"
              type="simple"
              total={totalSize}
              pageSize={10}
              onChange={(current) => setCurrentPage(current)}
            />
          </div>
        </If>
        <If condition={!clusterTasks.length}>
          <div className="no-data-bg">
            <img
              src="https://img.alicdn.com/tfs/TB1QbgAeQL0gK0jSZFAXXcA9pXa-160-144.png"
              style={{ height: 96, marginBottom: 12 }}
            />
            <div className="no-data-text">{intl('mse.register.risk.no_data')}</div>
          </div>
        </If>
      </div>
    </div>
  );
};

export default ClusterHealth;
