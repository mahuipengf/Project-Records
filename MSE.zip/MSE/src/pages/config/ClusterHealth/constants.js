export const EngineSpecs = (intl) => new Map()
  .set('MSE_SC_1_2_60_c', intl('mse.register.specs.1c2g'))
  .set('MSE_SC_2_4_60_c', intl('mse.register.specs.2c4g'))
  .set('MSE_SC_4_8_60_c', intl('mse.register.specs.4c8g'))
  .set('MSE_SC_8_16_60_c', intl('mse.register.specs.8c16g'))
  .set('MSE_SC_16_32_60_c', intl('mse.register.specs.16c32g'));


export const CheckStatus = (intl) => (
  [
    {
      value: 'CREATE',
      type: 'loading',
      label: intl('mse.register.risk.check.create'),
    },
    {
      value: 'FAIL',
      type: 'error',
      label: intl('mse.register.risk.check.fail'),
    },
    {
      value: 'RUNNING',
      type: 'loading',
      label: intl('mse.register.risk.check.run'),
    },
    {
      value: 'SUCCESS',
      type: 'success',
      label: intl('mse.register.risk.check.success'),
    },
  ]
);
