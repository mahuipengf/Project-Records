import React from 'react';
import MonitorComponent from 'components/monitor/MonitorComponent';
import MonitorProfessZk from 'components/monitor/MonitorProfessZk';
import MonitorProfessNacos from 'components/monitor/MonitorProfessNacos';
import { Tab, Balloon, Icon } from '@ali/wind';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 基础信息页面
 */
class Monitor extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
    };
    this.ClusterType = getParams('ClusterType') || 'ZooKeeper';
    this.VersionType = getParams('MseVersion') || 'mse_pro';
    this.AppVersion = getParams('AppVersion') || '';
    this.InstanceId = getParams('InstanceId') || '';
  }

  componentDidMount() {}

  renderContent = () => {
    const { ...rest } = this.props;
    let currentComponent = <MonitorComponent VersionType={this.VersionType} ClusterType={this.ClusterType} AppVersion={this.AppVersion} InstanceId={this.InstanceId} />;
    if (this.ClusterType === 'ZooKeeper' || (this.ClusterType === 'Nacos-Ans' && !this.props.prometheusVersion)) {
      switch (this.VersionType) {
        case 'mse_basic':
          break;
        case 'mse_pro':
        case 'mse_dev':
          currentComponent = <MonitorProfessZk />;
          break;
        default:
          break;
      }
    } else if (this.ClusterType === 'Nacos-Ans') {
      switch (this.props.prometheusVersion) {
        case 'basic':
          break;
        case 'pro':
        case 'dev':
          currentComponent = <MonitorProfessNacos prometheusVersion={this.props.prometheusVersion} />;
          break;
        default:
          break;
      }
    }

    return currentComponent;
  };

  render() {
    return (
      <div style={{ position: 'relative' }}>
        <If condition={this.ClusterType === 'ZooKeeper'}>{this.renderContent()}</If>
        <If condition={this.ClusterType === 'Nacos-Ans' && (this.props.prometheusVersion === 'pro' || this.props.prometheusVersion === 'dev')}>{this.renderContent()}</If>
        <If condition={!(this.ClusterType === 'Nacos-Ans' && (this.props.prometheusVersion === 'pro' || this.props.prometheusVersion === 'dev')) && this.ClusterType !== 'ZooKeeper'}>
          <MonitorComponent VersionType={this.VersionType} ClusterType={this.ClusterType} AppVersion={this.AppVersion} InstanceId={this.InstanceId} />
        </If>
        {/* <Tab shape="wrapped">
          <Tab.Item title={intl('mse.register.monitor')} key="monitor">
            <If condition={this.ClusterType === 'ZooKeeper'}>{this.renderContent()}</If>
            <If condition={this.ClusterType !== 'ZooKeeper'}>
              <MonitorComponent />
            </If>
          </Tab.Item>
        </Tab>
        <If condition={this.ClusterType === 'ZooKeeper' && this.VersionType === 'mse_basic'}>
          <Balloon
            trigger={
              <div style={{ position: 'absolute', top: 0, left: 80 }}>
                <Icon type="prompt" size="small" style={{ color: '#0064c8', margin: 8 }} />
                <span>ZooKeeper专业版升级</span>
              </div>
            }
            align="r"
            alignEdge
            closable={false}
          >
            ZooKeeper专业版提供更丰富的业务监控看板，包含70余项指标，并支持用户集成到自定义大盘。此外专业版性能及稳定性更优于基础版，<a target="_blank" href="https://help.aliyun.com/document_detail/216036.html">了解更多</a>
          </Balloon>
        </If> */}
      </div>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default Monitor;
