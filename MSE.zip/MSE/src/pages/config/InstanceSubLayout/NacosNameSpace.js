import React from 'react';
import CommonLoading from 'components/common/CommonLoading';
import CommonDialog from 'components/base/CommonDialog';
import NameSpaceCreate from 'components/nacos/NameSpaceCreate';
import NamespaceInfo from 'components/nacos/NamespaceInfo';
import { map } from 'lodash';
import { Dialog, Button, Icon, Table, Message } from '@ali/wind';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import intl from '@ali/wind-intl';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * nacos命名空间服务
 */

class NacosNameSpace extends React.Component {
  constructor(props) {
    super(props);
    this.AppVersion = getParams('AppVersion');
    this.state = {
      namespaces: [],
      current: 1,
      PageSize: 1000,
      dialogTitle: intl('mse.register.namespace.create'),
      loading: false,
    };
  }

  changePage = current => {
    this.setState({
      current,
    });
  };
  openEdit = values => {
    const { Namespace, NamespaceDesc, NamespaceShowName } = values;
    this.setState({
      dialogTitle: intl('mse.register.namespace.edit'),
    });
    this.dialog.open(() => {
      this.nscreate.setValues({
        Name: NamespaceShowName,
        Desc: NamespaceDesc,
        Id: Namespace,
      });
    });
  };
  openCreate = () => {
    this.setState({
      dialogTitle: intl('mse.register.namespace.create'),
    });
    this.dialog.open();
  };
  openInfo = values => {
    const { Namespace, NamespaceDesc, NamespaceShowName } = values;
    this.setState({
      dialogTitle: intl('mse.register.namespace.view'),
    });
    this.dialogInfo.open(() => {
      this.nscinfo.setValues({
        Name: NamespaceShowName,
        Desc: NamespaceDesc,
        Id: Namespace,
      });
    });
  };
  renderOption = (value, index, record) => {
    return (
      <span>
        {/* {' '}
        <a>详情</a>
        <span style={{ fontWeight: 'bold', marginLeft: 5, marginRight: 5, color: '#D8D8D8' }}>
          |
        </span> */}
        <a href="javascript:;" onClick={() => this.openEdit(record)}>
          {intl('mse.common.edit')}
        </a>
      </span>
    );
  };
  saveNameSpace = () => {
    if (this.nscreate.validate()) { // 校验合法性
      const values = this.nscreate.getValues();
      const ClusterId = getParams('ClusterId');
      const InstanceId = getParams('InstanceId');
      let url = 'com.alibaba.MSE.service.CreateEngineNamespace';
      if (this.state.dialogTitle === intl('mse.register.namespace.edit')) {
        url = 'com.alibaba.MSE.service.UpdateEngineNamespace';
      }
      request({
        url,
        data: {
          ClusterId,
          InstanceId,
          ...values,
          ServiceCount: 1000,
        },
        beforeSend: () => {
          this.setState({ loading: true });
        },
        success: res => {
          if (res.code === '200' && res.data) {
            const { fetchNamespaces } = this.props;
            fetchNamespaces && fetchNamespaces();
            this.dialog.close();
          }
        },
        complete: () => {
          this.setState({ loading: false });
        },
      });
    }
  };
  renderFooter = () => {
    return (
      <div style={{ textAligin: 'right' }}>
        <Button type="primary" style={{ marginRight: 10 }} onClick={this.saveNameSpace} loading={this.state.loading}>
          {intl('mse.common.ok')}
        </Button>
        <Button
          onClick={() => {
            this.dialog.close();
          }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );
  };
  render() {
    const { dialogTitle } = this.state;
    const { namespaces = [], fetchNamespaces } = this.props;
    const columnsOld = [
      {
        title: intl('mse.register.namespace.id'),
        dataIndex: 'Namespace',
        cell: val => (val === 'public' ? '' : val)
      }, {
        title: intl('mse.register.namespace.name'),
        dataIndex: 'NamespaceShowName',
      }, {
        title: intl('mse.register.namespace.from'),
        dataIndex: 'SourceType',
        cell: (val) => (
          <span>
            {(val && val.toUpperCase()) || 'MSE'}
          </span>
        )
      }, {
        title: intl('mse.register.namespace.desc'),
        dataIndex: 'NamespaceDesc',
      }, {
        title: intl('mse.register.namespace.service'),
        dataIndex: 'ServiceCount',
      }, {
        title: intl('mse.common.operate'),
        cell: (val, index, record) => (
          <a href="javascript:;" onClick={() => this.openEdit(record)}>
            {intl('mse.common.edit')}
          </a>
        )
      }
    ];
    const columnsNew = [
      {
        title: intl('mse.register.namespace.id'),
        dataIndex: 'Namespace',
        cell: val => (val === 'public' ? '' : val)
      }, {
        title: intl('mse.register.namespace.name'),
        dataIndex: 'NamespaceShowName',
      }, {
        title: intl('mse.register.namespace.from'),
        dataIndex: 'SourceType',
        cell: (val) => (
          <span>
            {(val && val.toUpperCase()) || 'MSE'}
          </span>
        )
      }, {
        title: intl('mse.register.namespace.config'),
        cell: (val, index, record) => `${record.ConfigCount || 0}/ ${record.Quota || 0}`
      }, {
        title: intl('mse.register.namespace.service'),
        dataIndex: 'ServiceCount',
        cell: val => val || 0
      }, {
        title: intl('mse.common.operate'),
        cell: (val, index, record) => (
          <Actions expandTriggerType="hover">
            <LinkButton key="1" onClick={() => this.openInfo(record)}>
              {intl('mse.common.view')}
              </LinkButton>
            <LinkButton disabled={record.Type === 0} key="2" onClick={() => this.openEdit(record)}>
              {intl('mse.common.edit')}
              </LinkButton>
            <LinkButton disabled={record.Type === 0} key="3" onClick={() => handleDelete(record)}>
              {intl('mse.common.delete')}
              </LinkButton>
          </Actions>
        )
      }
    ];

    const handleDelete = (record) => {
      Dialog.confirm({
        type: 'warning',
        title: intl('mse.common.delete'),
        content: (
          <div style={{ width: 500 }}>{intl.html('mse.common.delete_confirm', { name: record.NamespaceShowName })}</div>
        ),
        onOk: () => {
          return new Promise(async (resolve, reject) => {
            request({
              url: 'com.alibaba.MSE.service.DeleteEngineNamespace',
              data: {
                ClusterId: getParams('ClusterId'),
                InstanceId: getParams('InstanceId'),
                Id: record.NamespaceId,
              },
              success: res => {
                if (res.code === '200' && res.data) {
                  resolve();
                  Message.success(intl('mse.common.delete_success'));
                  const { fetchNamespaces } = this.props;
                  fetchNamespaces && fetchNamespaces();
                }
              },
            });
          });
        },
        messageProps: {
          type: 'warning',
        },
        okProps: { children: intl('mse.common.ok') },
        cancelProps: { children: intl('mse.common.cancel') },
      });
    };

    return (
      <React.Fragment>
        <CommonLoading ref={node => (this.loading = node)}>
          <div className="common-clearfix" style={{ marginBottom: 8, height: 32 }}>
            <Button
              type="primary common-link-color"
              className="common-mr-10"
              onClick={this.openCreate}
              data-spm-click="gostr=/aliyun;locaid=create-namespace"
            >
              {intl('mse.register.namespace.create')}
              </Button>
            <div className="common-absolute">
              <Button type="normal" onClick={() => fetchNamespaces()}>
                <Icon type="refresh" />
              </Button>
            </div>
          </div>
          <div style={{ width: '100%', position: 'relative' }}>
            <Table dataSource={namespaces} hasBorder={false}>
              {
                map(this.AppVersion === '1.1.3' ? columnsOld : columnsNew, item => (
                  <Table.Column {...item} />
                ))
              }
            </Table>
          </div>
        </CommonLoading>
        <CommonDialog
          title={dialogTitle}
          style={{ width: 670 }}
          childStyle={{ height: 200, overflowX: 'hidden' }}
          footer={this.renderFooter()}
          ref={node => (this.dialog = node)}
          shouldUpdatePosition
        >
          <NameSpaceCreate ref={node => (this.nscreate = node)} title={dialogTitle} />
        </CommonDialog>
        <CommonDialog
          title={dialogTitle}
          style={{ width: 670 }}
          childStyle={{ height: 200, overflowX: 'hidden' }}
          footer={false}
          ref={node => (this.dialogInfo = node)}
          shouldUpdatePosition
        >
          <NamespaceInfo ref={node => (this.nscinfo = node)} />
        </CommonDialog>
      </React.Fragment>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default NacosNameSpace;
