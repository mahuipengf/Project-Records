import React from 'react';
import ComIf from 'components/common/ComIf';
import ParameterTable from 'components/parameter/ParameterTable';
import ParameterEdit from 'components/parameter/ParameterEdit';
import ParameterRunningTable from 'components/parameter/ParameterRunningTable';
import { compareVersion } from 'utils/utils';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 集群参数设置
 */
class ParameterSetting extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataSource: [],
      paramsConfig: {},
      tableVisible: false, // table loading
      paramsRunningConfig: {},
    };
  }

  componentDidMount() {
    this.timmer = setTimeout(() => {
      this.setState(
        { tableVisible: true },
        () => {
          this.getParameters();
        },
        500
      );
    });
  }
  componentWillUnmount = () => {
    this.timmer && clearTimeout(this.timmer);
  };
  openEdit = () => {
    const { paramsConfig } = this.state;
    this.pe.openDialog(paramsConfig);
  };
  getParameters = () => {
    const clusterId = getParams('clusterId');
    const InstanceId = getParams('InstanceId');
    const clusterType = getParams('ClusterType');
    const appVersion = getParams('AppVersion');
    const params = { clusterId, InstanceId };
    if (clusterType === 'Nacos-Ans' && compareVersion(appVersion, '2.1.0.2') > -1) {
      params.NeedRunningConf = true;
    }
    this.openTableLoading();
    request({
      url: 'com.alibaba.MSE.service.configquery',
      data: params,
      success: (res) => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          this.setState({
            paramsConfig: Data,
            paramsRunningConfig: Data?.NacosRunningEnv || { },
          });
        }
      },
      complete: () => {
        this.closeTableLoading();
      },
    });
  };

  openTableLoading = () => {
    this.setState({
      tableVisible: true,
    });
  };

  closeTableLoading = () => {
    this.setState({
      tableVisible: false,
    });
  };

  render() {
    const { paramsConfig, paramsRunningConfig, tableVisible } = this.state;
    const clusterType = getParams('ClusterType');
    return (
      <ComIf if={clusterType === 'ZooKeeper' || clusterType === 'Nacos-Ans'}>
        <div style={{ marginBottom: 12 }}>
          <ParameterTable
            paramsConfig={paramsConfig}
            getParameters={this.getParameters}
            tableVisible={tableVisible}
            openEdit={this.openEdit}
            openTableLoading={this.openTableLoading}
            closeTableLoading={this.closeTableLoading}
            clusterType={clusterType}
          />
          <ParameterEdit
            ref={(node) => (this.pe = node)}
            paramsConfig={paramsConfig}
            getParameters={this.getParameters}
          />
        </div>

        <If condition={clusterType === 'Nacos-Ans'}>
          <ParameterRunningTable
            paramsConfig={paramsRunningConfig}
            tableVisible={tableVisible}
            getParameters={this.getParameters}
          />
        </If>
      </ComIf>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default ParameterSetting;
