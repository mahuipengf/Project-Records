import React, { Suspense, useEffect, useState, useRef, Fragment } from 'react';
import { head, find, assign, includes, forEach, mapValues, sortBy, get } from 'lodash';
import DataManager from './DataManager';
import SubLayout from 'layouts/SubLayout';
import MseWidget from 'components/common/MseWidget';
import CommonLoading from 'components/common/CommonLoading';
import { queryDecode, queryEncode, queryDecodeHash, changeQuery } from 'utils/queryString';
import BasicInfo from './BasicInfo';
import NacosNameSpace from './NacosNameSpace';
import Monitor from './Monitor';
import ParameterSetting from './ParameterSetting';
import { eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_MSE } from 'constants';
import IconBack from 'components/IconBack';
import { Select, Message, Badge } from '@ali/wind';
import intl from '@ali/wind-intl';
import { CopyContent, Icon } from '@ali/cn-design';
import services from 'utils/services';
import ServiceTrace from '../Trace';
import ClusterHealth from '../ClusterHealth';
import NacosInstanceDetail from 'components/nacos/NacosInstanceDetail';
import NacosInstanceDetailTrack from 'components/nacos/NacosInstanceDetail/NacosInstanceDetailTrack';
import ZooKeeperServiceManage from '../ZooKeeper/ServiceManage';
import ZooKeeperServiceManageDetail from '../ZooKeeper/ServiceManageDetail';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const VersionCate = new Map()
  .set('Profess', 'mse_pro')
  .set('Basic', 'mse_basic')
  .set('Develop', 'mse_dev');

const hasNamespaceCluster = [
  'Nacos-Ans',
  'Diamond-Over-Nacos2',
  'ConfigServer-Over-Nacos2',
  'VipServer-Over-Nacos2',
]; // 展示 命名空间 的集群类型

const DetailRollBackUrl = [
  '/Instance/Config/Detail',
  '/Instance/Service/Detail',
  '/Instance/DataManager/ServiceDetail',
]; //详情页返回
const EmptyPageUrl = ['/Instance/Service/Subscriber/Trace']; //无侧边栏空白页面

const getMenu = (ClusterType, AppVersion) => {
  const Params = queryEncode(queryDecodeHash());
  const CLUSTER_NAME_MAP = mapValues(window.CLUSTER_NAME_MAP, (value) => value.name);
  return [
    {
      key: '/Instance/BasicInfo',
      label: intl('mse.register.basicinfo'),
      activePathPatterns: ['/Instance/BasicInfo'],
      to: `/Instance/BasicInfo?${Params}`,
      visible: true,
    },
    {
      key: '/Instance/NacosNameSpace',
      label: intl('mse.register.namespace'),
      activePathPatterns: ['/Instance/NacosNameSpace'],
      to: `/Instance/NacosNameSpace?${Params}`,
      visible: _.includes(hasNamespaceCluster, ClusterType),
    },
    {
      key: '/Instance/DataManager',
      label: CLUSTER_NAME_MAP[ClusterType] || '',
      activePathPatterns: ['/Instance/DataManager'],
      to: `/Instance/DataManager?${Params}`,
      visible:
        window.CLUSTER_NAME_MAP[ClusterType] && ClusterType !== 'Nacos-Ans'
          ? window.CLUSTER_NAME_MAP[ClusterType].visible
          : false,
      isUseNamespace: ClusterType === 'Nacos-Ans', // 这个字段用来判断，是否存在命名空间的选择框
    },
    {
      key: '/Instance/Service',
      label: CLUSTER_NAME_MAP[ClusterType] || '',
      activePathPatterns: ['/Instance/Service'],
      to: `/Instance/Service?${Params}`,
      visible:
        window.CLUSTER_NAME_MAP[ClusterType] && ClusterType === 'Nacos-Ans'
          ? window.CLUSTER_NAME_MAP[ClusterType].visible
          : false,
      items: [
        {
          key: '/Instance/Service/List',
          label: intl('mse.register.service.list'),
          to: `/Instance/Service/List?${Params}`,
          activePathPatterns: ['/Instance/Service/List', '/Instance/Service/Detail'],
          isUseNamespace: true, // 这个字段用来判断，是否存在命名空间的选择框
          sub: { link: '/Instance/Service/Detail' },
        },
        {
          key: '/Instance/Service/Trace',
          label: intl('mse.register.config_trace'),
          to: `/Instance/Service/Trace?${Params}`,
          activePathPatterns: ['/Instance/Service/Trace'],
          isUseNamespace: true, // 这个字段用来判断，是否存在命名空间的选择框
        },
      ],
    },
    {
      key: '/Instance/Config',
      label: intl('mse.register.config'),
      activePathPatterns: ['/Instance/Config'],
      to: `/Instance/Config?${Params}`,
      visible: _.includes(hasNamespaceCluster, ClusterType) && AppVersion !== '1.1.3',
      items: [
        {
          key: '/Instance/Config/List',
          label: intl('mse.register.config_list'),
          to: `/Instance/Config/List?${Params}`,
          activePathPatterns: ['/Instance/Config/List', '/Instance/Config/Detail'],
          isUseNamespace: true,
          sub: { link: '/Instance/Config/Detail' },
        },
        {
          key: '/Instance/Config/History',
          label: intl('mse.register.config_history'),
          to: `/Instance/Config/History?${Params}`,
          activePathPatterns: ['/Instance/Config/History'],
          isUseNamespace: true,
        },
        {
          key: '/Instance/Config/Query',
          label: intl('mse.register.config_query'),
          to: `/Instance/Config/Query?${Params}`,
          activePathPatterns: ['/Instance/Config/Query'],
          isUseNamespace: true,
        },
        {
          key: '/Instance/Config/Trace',
          label: intl('mse.register.config_trace'),
          to: `/Instance/Config/Trace?${Params}`,
          activePathPatterns: ['/Instance/Config/Trace'],
          isUseNamespace: true,
        },
      ],
    },
    {
      key: '/Instance/Health',
      label: intl('mse.register.health'),
      activePathPatterns: ['/Instance/Health'],
      to: `/Instance/Health?${Params}`,
      visible:
        window.regionId.indexOf('finance') === -1 &&
        includes(['Nacos-Ans', 'ZooKeeper'], ClusterType),
    },
    {
      key: '/Instance/Monitor',
      label: intl('mse.register.monitor'),
      activePathPatterns: ['/Instance/Monitor'],
      to: `/Instance/Monitor?${Params}`,
      visible: window.regionId.indexOf('finance') === -1,
    },
    {
      key: '/Instance/ParameterSetting',
      label: intl('mse.register.params'),
      activePathPatterns: ['/Instance/ParameterSetting'],
      to: `/Instance/ParameterSetting?${Params}`,
      visible:
        ClusterType === 'ZooKeeper' || (ClusterType === 'Nacos-Ans' && AppVersion !== '1.1.3'),
    },
  ];
};

const { Switch, Route, Router, Redirect } = window.ReactRouterDOM || window.ReactRouterDom || {};
const breadCrumbList = [
  {
    title: intl('mse.register.menu.instance'),
    link: '/InstanceList',
  },
];

const InstanceSubLayout = ({ history }) => {
  const { search } = history.location;
  const { namespaceId: defaultActiveNamespaceId } = queryDecode(search);
  const [namespace, setNamespace] = useState({
    namespaces: [],
    activeNamespaceId: defaultActiveNamespaceId,
  });

  const [loadSuccess, setLoadSuccess] = useState(false);
  const [ClusterType] = useState(getParams('ClusterType') || 'ZooKeeper');
  const loadRef = useRef();
  const [AppVersion] = useState(getParams('AppVersion'));
  const [prometheusVersion, setPrometheusVersion] = useState('basic');
  const [menuItems, setMenuItems] = useState([]);
  const menuAttrRef = useRef(new Map());

  const Params = queryEncode(queryDecodeHash());
  const BASEICINFO = {
    key: '/Instance/BasicInfo',
    label: intl('mse.register.basicinfo'),
    activePathPatterns: ['/Instance/BasicInfo'],
    to: `/Instance/BasicInfo?${Params}`,
    visible: true,
  };
  const NAMESPACE = {
    key: '/Instance/NacosNameSpace',
    label: intl('mse.register.nacos.namespace'),
    activePathPatterns: ['/Instance/NacosNameSpace'],
    to: `/Instance/NacosNameSpace?${Params}`,
    visible: true,
  };
  const SERVICE = {
    key: '/Instance/Service',
    label: intl('mse.register.instance.service'),
    activePathPatterns: ['/Instance/Service'],
    to: `/Instance/Service?${Params}`,
    visible:
      window.CLUSTER_NAME_MAP[ClusterType] && ClusterType === 'Nacos-Ans'
        ? window.CLUSTER_NAME_MAP[ClusterType].visible
        : false,
    items: [
      {
        key: '/Instance/Service/List',
        label: intl('mse.register.service.list'),
        to: `/Instance/Service/List?${Params}`,
        activePathPatterns: ['/Instance/Service/List', '/Instance/Service/Detail'],
        isUseNamespace: true, // 这个字段用来判断，是否存在命名空间的选择框
        sub: { link: '/Instance/Service/Detail' },
      },
      {
        key: '/Instance/Service/Trace',
        label: intl('mse.register.config_trace'),
        to: `/Instance/Service/Trace?${Params}`,
        activePathPatterns: ['/Instance/Service/Trace'],
        isUseNamespace: true, // 这个字段用来判断，是否存在命名空间的选择框
      },
    ],
  };
  const DATA = {
    key: '/Instance/DataManager',
    label: intl('mse.register.data'),
    activePathPatterns: ['/Instance/DataManager'],
    to: `/Instance/DataManager?${Params}`,
    visible: true,
    items: [],
  };
  const DATAMANAGER = {
    key: '/Instance/DataManager/Node',
    label: intl('mse.register.znode'),
    to: `/Instance/DataManager/Node?${Params}`,
    activePathPatterns: ['/Instance/DataManager/Node'],
  };
  const DATATRACE = {
    key: '/Instance/DataManager/Trace',
    label: intl('mse.register.trace'),
    to: `/Instance/DataManager/Trace?${Params}`,
    activePathPatterns: ['/Instance/DataManager/Trace'],
  };
  const ZKSERVICE = {
    key: '/Instance/DataManager/Service',
    label: intl('mse.register.service'),
    to: `/Instance/DataManager/Service?${Params}`,
    activePathPatterns: ['/Instance/DataManager/Service', '/Instance/DataManager/ServiceDetail'],
    sub: { link: '/Instance/DataManager/ServiceDetail' },
  };
  const CONFIGLIST = {
    key: '/Instance/Config/List',
    label: intl('mse.register.config_list'),
    to: `/Instance/Config/List?${Params}`,
    activePathPatterns: ['/Instance/Config/List', '/Instance/Config/Detail'],
    isUseNamespace: true,
    sub: { link: '/Instance/Config/Detail' },
  };
  const CONFIGHISTORY = {
    key: '/Instance/Config/History',
    label: intl('mse.register.config_history'),
    to: `/Instance/Config/History?${Params}`,
    activePathPatterns: ['/Instance/Config/History'],
    isUseNamespace: true,
  };
  const CONFIGLISTENER = {
    key: '/Instance/Config/Query',
    label: intl('mse.register.config_query'),
    to: `/Instance/Config/Query?${Params}`,
    activePathPatterns: ['/Instance/Config/Query'],
    isUseNamespace: true,
  };
  const CONFIGTRACE = {
    key: '/Instance/Config/Trace',
    label: intl('mse.register.config_trace'),
    to: `/Instance/Config/Trace?${Params}`,
    activePathPatterns: ['/Instance/Config/Trace'],
    isUseNamespace: true,
  };
  const CONFIG = {
    key: '/Instance/Config',
    label: intl('mse.register.config'),
    activePathPatterns: ['/Instance/Config'],
    to: `/Instance/Config?${Params}`,
    visible: _.includes(hasNamespaceCluster, ClusterType) && AppVersion !== '1.1.3',
    items: [],
  };

  const BASICMONITOR = {
    key: '/Instance/Monitor',
    label: intl('mse.register.observe.monitor'),
    activePathPatterns: ['/Instance/Monitor'],
    to: `/Instance/Monitor?${Params}`,
    visible: true,
  };
  const PROFESSMONITOR = {
    key: '/Instance/Observe',
    label: intl('mse.register.observe.monitor'),
    activePathPatterns: ['/Instance/Observe'],
    to: `/Instance/Observe?${Params}`,
    visible: true,
    items: [
      {
        key: '/Instance/Observe/Monitor',
        label: intl('mse.register.observe.monitor_center'),
        to: `/Instance/Observe/Monitor?${Params}`,
        activePathPatterns: ['/Instance/Observe/Monitor'],
      },
    ],
  };
  const DEVMONITOR = {
    key: '/Instance/Observe',
    label: intl('mse.register.observe.monitor'),
    activePathPatterns: ['/Instance/Observe'],
    to: `/Instance/Observe?${Params}`,
    visible: true,
    items: [
      {
        key: '/Instance/Observe/Monitor',
        label: intl('mse.register.observe.monitor_center'),
        to: `/Instance/Observe/Monitor?${Params}`,
        activePathPatterns: ['/Instance/Observe/Monitor'],
      },
    ],
  };
  const HEALTHCHECK = {
    key: '/Instance/Health',
    label: (
      <Badge
        content="new"
        style={{
          backgroundColor: '#f54743',
          color: '#fff',
          borderRadius: '10px',
          top: -10,
          right: -42,
        }}
      >
        {intl('mse.register.health')}
      </Badge>
    ),
    activePathPatterns: ['/Instance/Health'],
    to: `/Instance/Health?${Params}`,
    visible: true,
  };
  const PARAMETERSET = {
    key: '/Instance/ParameterSetting',
    label: intl('mse.register.params'),
    activePathPatterns: ['/Instance/ParameterSetting'],
    to: `/Instance/ParameterSetting?${Params}`,
    visible: true,
  };

  const MenuCollect = new Map()
    .set('regcenter_zookeeper_detail', BASEICINFO)
    .set('regcenter_zookeeper_datamanage', DATAMANAGER)
    .set('regcenter_zookeeper_prometheus_basic', BASICMONITOR)
    .set('regcenter_zookeeper_prometheus_dev', DEVMONITOR)
    .set('regcenter_zookeeper_configTrace', DATATRACE)
    .set('regcenter_zookeeper_service', ZKSERVICE)
    .set('regcenter_zookeeper_prometheus_pro', PROFESSMONITOR)
    .set('regcenter_zookeeper_healthCheck', HEALTHCHECK)
    .set('regcenter_zookeeper_settings', PARAMETERSET);

  const MenuCollectNacos = new Map()
    .set('regcenter_nacos_detail', BASEICINFO)
    .set('regcenter_nacos_namespace', NAMESPACE)
    .set('regcenter_nacos_service', SERVICE)
    .set('regcenter_nacos_configList', CONFIGLIST)
    .set('regcenter_nacos_configHistory', CONFIGHISTORY)
    .set('regcenter_nacos_configListener', CONFIGLISTENER)
    .set('regcenter_nacos_configTrace', CONFIGTRACE)
    .set('regcenter_nacos_prometheus_basic', BASICMONITOR)
    .set('regcenter_nacos_prometheus_pro', PROFESSMONITOR)
    .set('regcenter_nacos_prometheus_dev', DEVMONITOR)
    .set('regcenter_nacos_healthCheck', HEALTHCHECK)
    .set('regcenter_nacos_settings', PARAMETERSET);

  useEffect(() => {
    if (_.includes(hasNamespaceCluster, ClusterType)) {
      fetchNamespaces();
    }
    if (ClusterType === 'ZooKeeper' || ClusterType === 'Nacos-Ans') {
      getClusterMenus(ClusterType);
    } else {
      setMenuItems(getMenu(ClusterType, AppVersion));
    }
  }, [ClusterType]);

  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_MSE.id}:view-config-detail`, handleViewConfigDetail);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_MSE.id}:view-config-detail`, handleViewConfigDetail);
    };
  }, []);

  useEffect(() => {
    window.CN_TRACKER.send({
      name: history.location.pathname,
      type: 'mse-config-menu',
    });
  }, [history.location.pathname]);

  const handleViewConfigDetail = (value = {}, tab = 'content') => {
    const search = queryDecode();
    //将DataId放到url中，方便详情页中取到作为标题
    const { DataId: dataId, Group: group, DataId: subTitle } = value;
    const newSearch = queryEncode({ ...search, dataId, group, tab, subTitle });
    hashHistory.push(`/Instance/Config/Detail?${newSearch}`);
  };

  const fetchNamespaces = async () => {
    const ClusterId = getParams('ClusterId');
    const InstanceId = getParams('InstanceId');
    request({
      url: 'com.alibaba.MSE.service.ListEngineNamespaces',
      data: {
        PageNum: 1,
        PageSize: 1000,
        ClusterId,
        InstanceId,
      },
      beforeSend: () => {
        loadRef.current && loadRef.current.openLoading();
      },
      success: (res) => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          const namespaces = Data.map((item) => {
            return {
              ...item,
              label: item.NamespaceShowName,
              value: item.Namespace || item.NamespaceShowName,
              Namespace: item.Namespace || item.NamespaceShowName,
              NamespaceId: item.Namespace || item.NamespaceShowName,
            };
          });
          if (!namespace.activeNamespaceId && namespaces.length) {
            setNamespace({
              namespaces,
              activeNamespaceId: head(namespaces).value,
            });
          } else {
            setNamespace(
              assign({}, namespace, {
                namespaces,
              })
            );
          }
          setLoadSuccess(true);
        }
      },
      complete: () => {
        loadRef.current && loadRef.current.closeLoading();
      },
    });
  };

  const getClusterMenus = async (clusterType) => {
    if (clusterType === 'ZooKeeper') {
      const InstanceId = getParams('InstanceId');
      const MseVersion = getParams('MseVersion');
      const res = await services.getClusterFeature({
        customErrorHandle: (err, data, callback) => {
          const MONITOR = includes(
            [VersionCate.get('Develop'), VersionCate.get('Profess')],
            MseVersion
          )
            ? PROFESSMONITOR
            : BASICMONITOR;
          setMenuItems([BASEICINFO, DATAMANAGER, MONITOR, PARAMETERSET]);
          callback();
        },
        params: {
          InstanceId,
        },
      });
      let _menuItems = [];
      const sortItems = sortBy(res, ['OrderNum']) || [];
      let datamanager = false;
      forEach(sortItems, (item) => {
        const { FeatureId, Status } = item;
        if (MenuCollect.has(FeatureId) && Status !== 'disabled') {
          if (
            FeatureId.indexOf('regcenter_zookeeper_configTrace') !== -1 ||
            FeatureId.indexOf('regcenter_zookeeper_datamanage') !== -1 ||
            FeatureId.indexOf('regcenter_zookeeper_service') !== -1
          ) {
            datamanager = true;
            DATA.items.push(MenuCollect.get(FeatureId));
          } else {
            if (datamanager) {
              _menuItems.push(DATA);
              datamanager = false;
            }
            _menuItems.push(MenuCollect.get(FeatureId));
            menuAttrRef.current.set(FeatureId, { Status });
          }
        }
      });

      // zk menus返回为空 适配菜单
      if (!_menuItems.length) {
        _menuItems = [BASEICINFO];
      }
      setMenuItems(_menuItems);
    } else {
      const InstanceId = getParams('InstanceId');
      const MseVersion = getParams('MseVersion');
      const res = await services.getClusterFeature({
        customErrorHandle: (err, data, callback) => {
          const MONITOR = includes(
            [VersionCate.get('Develop'), VersionCate.get('Profess')],
            MseVersion
          )
            ? PROFESSMONITOR
            : BASICMONITOR;
          setMenuItems([BASEICINFO, DATAMANAGER, MONITOR, PARAMETERSET]);
          callback();
        },
        params: {
          InstanceId,
        },
      });
      res &&
        res.forEach((item, index) => {
          if (
            item.FeatureId.indexOf('regcenter_nacos_prometheus') !== -1 &&
            item.Status === 'enabled'
          ) {
            setPrometheusVersion(item.FeatureId.split('regcenter_nacos_prometheus_')[1]);
            setParams('prometheusVersion', prometheusVersion);
          }
        });
      let _menuItems = [];
      const sortItems = sortBy(res, ['OrderNum']) || [];
      let config = false;
      forEach(sortItems, (item) => {
        const { FeatureId, Status } = item;
        if (MenuCollectNacos.has(FeatureId) && Status !== 'disabled') {
          if (FeatureId.indexOf('regcenter_nacos_config') !== -1) {
            config = true;
            CONFIG.items.push(MenuCollectNacos.get(FeatureId));
          } else {
            if (config) {
              _menuItems.push(CONFIG);
              config = false;
            }
            _menuItems.push(MenuCollectNacos.get(FeatureId));
            menuAttrRef.current.set(FeatureId, { Status });
          }
        }
      });
      if (config) {
        _menuItems.push(CONFIG);
      }
      // nacos menus返回为空 适配菜单
      if (!_menuItems.length) {
        _menuItems = [BASEICINFO];
      }
      setMenuItems(_menuItems);
    }
  };

  const Layout = () => (
    <Switch>
      <Route
        path="/Instance/BasicInfo"
        component={() => {
          let basicinfo = { Status: 'enabled' };
          if (menuAttrRef.current.has('regcenter_zookeeper_detail')) {
            basicinfo = { ...menuAttrRef.current.get('regcenter_zookeeper_detail') };
          }
          return <BasicInfo {...basicinfo} />;
        }}
      />
      <Route
        path="/Instance/NacosNameSpace"
        component={() => (
          <NacosNameSpace namespaces={namespace.namespaces} fetchNamespaces={fetchNamespaces} />
        )}
      />
      <Route
        path="/Instance/Monitor"
        component={() => {
          let monitor = { Status: 'enabled' };
          if (menuAttrRef.current.has('regcenter_zookeeper_prometheus_basic')) {
            monitor = { ...menuAttrRef.current.get('regcenter_zookeeper_prometheus_basic') };
          }
          if (menuAttrRef.current.has('regcenter_zookeeper_prometheus_pro')) {
            monitor = { ...menuAttrRef.current.get('regcenter_zookeeper_prometheus_pro') };
          }
          if (menuAttrRef.current.has('regcenter_nacos_prometheus_dev')) {
            monitor = { ...menuAttrRef.current.get('regcenter_nacos_prometheus_dev') };
          }
          if (menuAttrRef.current.has('regcenter_nacos_prometheus_pro')) {
            monitor = { ...menuAttrRef.current.get('regcenter_nacos_prometheus_pro') };
          }
          return (
            <Monitor {...monitor} ClusterType={ClusterType} prometheusVersion={prometheusVersion} />
          );
        }}
      />
      <Route
        path="/Instance/Observe/Monitor"
        component={() => {
          let monitor = { Status: 'enabled' };
          if (menuAttrRef.current.has('regcenter_zookeeper_prometheus_basic')) {
            monitor = { ...menuAttrRef.current.get('regcenter_zookeeper_prometheus_basic') };
          }
          if (menuAttrRef.current.has('regcenter_zookeeper_prometheus_pro')) {
            monitor = { ...menuAttrRef.current.get('regcenter_zookeeper_prometheus_pro') };
          }
          if (menuAttrRef.current.has('regcenter_nacos_prometheus_dev')) {
            monitor = { ...menuAttrRef.current.get('regcenter_nacos_prometheus_dev') };
          }
          if (menuAttrRef.current.has('regcenter_nacos_prometheus_pro')) {
            monitor = { ...menuAttrRef.current.get('regcenter_nacos_prometheus_pro') };
          }
          return (
            <Monitor {...monitor} ClusterType={ClusterType} prometheusVersion={prometheusVersion} />
          );
        }}
      />
      <Route
        path="/Instance/ParameterSetting"
        component={() => {
          let params = { Status: 'enabled' };
          if (menuAttrRef.current.has('regcenter_zookeeper_settings')) {
            params = { ...menuAttrRef.current.get('regcenter_zookeeper_settings') };
          }
          return <ParameterSetting {...params} />;
        }}
      />
      <If condition={includes(['Nacos-Ans', 'ZooKeeper'], getParams('ClusterType'))}>
        <Route path="/Instance/Health" component={() => <ClusterHealth />} />
      </If>
      <If condition={getParams('ClusterType') === 'Nacos-Ans'}>
        <Route
          path="/Instance/Service/List"
          component={() => {
            let data = { Status: 'enabled' };
            if (menuAttrRef.current.has('regcenter_zookeeper_datamanage')) {
              data = { ...menuAttrRef.current.get('regcenter_zookeeper_datamanage') };
            }
            return (
              <DataManager
                activeNamespaceId={namespace.activeNamespaceId}
                namespaces={namespace.namespaces}
                loadSuccess={loadSuccess}
                {...data}
              />
            );
          }}
        />
        <Route
          path="/Instance/Service/Detail"
          component={() => {
            return (
              <NacosInstanceDetail
                activeNamespaceId={namespace.activeNamespaceId}
                loadSuccess={loadSuccess}
              />
            );
          }}
        />
        <Route
          path="/Instance/Service/Trace"
          component={() => {
            return (
              <ServiceTrace
                activeNamespaceId={namespace.activeNamespaceId}
                loadSuccess={loadSuccess}
              />
            );
          }}
        />
      </If>
      <If condition={getParams('ClusterType') === 'Eureka'}>
        <Route
          path="/Instance/DataManager"
          component={() => {
            let data = { Status: 'enabled' };
            return (
              <DataManager
                activeNamespaceId={namespace.activeNamespaceId}
                namespaces={namespace.namespaces}
                loadSuccess={loadSuccess}
                {...data}
              />
            );
          }}
        />
      </If>
      <Route
        path="/Instance/DataManager/Node"
        component={() => {
          let data = { Status: 'enabled' };
          if (menuAttrRef.current.has('regcenter_zookeeper_datamanage')) {
            data = { ...menuAttrRef.current.get('regcenter_zookeeper_datamanage') };
          }
          return (
            <DataManager
              activeNamespaceId={namespace.activeNamespaceId}
              namespaces={namespace.namespaces}
              loadSuccess={loadSuccess}
              {...data}
            />
          );
        }}
      />
      <Route
        path="/Instance/DataManager/Trace"
        component={() => (
          <MseWidget
            component="DataTrack"
            namespaces={namespace.namespaces}
            loadSuccess
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />
      <Route
        path="/Instance/DataManager/Service"
        component={() => (
          <ZooKeeperServiceManage
            namespaces={namespace.namespaces}
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />
      <Route
        path="/Instance/DataManager/ServiceDetail"
        component={() => (
          <ZooKeeperServiceManageDetail
            namespaces={namespace.namespaces}
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />

      <Route
        path="/Instance/Config/List"
        component={() => (
          <MseWidget
            component="ConfigurationManagement"
            namespaces={namespace.namespaces}
            loadSuccess={loadSuccess}
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />
      <Route
        path="/Instance/Config/Detail"
        component={() => (
          <MseWidget
            component="ConfigurationDetail"
            namespaces={namespace.namespaces}
            loadSuccess={loadSuccess}
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />
      <Route
        path="/Instance/Config/History"
        component={() => (
          <MseWidget
            component="HistoryRollback"
            namespaces={namespace.namespaces}
            loadSuccess={loadSuccess}
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />
      <Route
        path="/Instance/Config/Query"
        component={() => (
          <MseWidget
            component="ListeningToQuery"
            namespaces={namespace.namespaces}
            loadSuccess={loadSuccess}
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />
      <Route
        path="/Instance/Config/Trace"
        component={() => (
          <MseWidget
            component="PushTrajectory"
            namespaces={namespace.namespaces}
            loadSuccess={loadSuccess}
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />
      <Route
        path="/Instance/Config"
        component={() => (
          <MseWidget
            component="ConfigurationManagement"
            namespaces={namespace.namespaces}
            loadSuccess={loadSuccess}
            activeNamespaceId={namespace.activeNamespaceId}
          />
        )}
      />
      <Redirect to="/overview" />
    </Switch>
  );

  const handleChangeNamespace = (val) => {
    if (val) {
      changeQuery({ namespaceId: val });
      setNamespace(
        assign({}, namespace, {
          activeNamespaceId: val,
        })
      );
      eventEmitter.refresh(WIDGET_EDAS_MSE.id);
    }
  };

  // 提取 menu，生成需要的数据格式
  const mapMenu = () => {
    const list = [];
    const params = queryEncode(queryDecodeHash());
    forEach(menuItems, (item) => {
      if (item.items) {
        forEach(item.items, (child) => {
          if (child.sub) {
            list.push({
              link: child.key,
              title: getParams('ClusterName'),
              isUseNamespace: child.isUseNamespace,
            });
            const { subTitle } = queryDecode(search);
            list.push({
              ...child.sub,
              parent: { link: `${child.key}?${params}`, title: getParams('ClusterName') },
              title: subTitle,
            });
            return;
          }
          list.push({
            link: child.key,
            title: getParams('ClusterName'),
            isUseNamespace: child.isUseNamespace,
          });
        });
      }
      list.push({
        link: item.key,
        title: getParams('ClusterName'),
        isUseNamespace: item.isUseNamespace,
      });
    });
    return list;
  };
  const sub = find(mapMenu(), (item) => history.location.pathname === item.link) || {};
  const newBreadCrumbList = sub.parent
    ? [...breadCrumbList, sub.parent, sub]
    : [...breadCrumbList, sub];
  const title = sub?.title;
  return (
    <React.Fragment>
      <If condition={EmptyPageUrl.includes(hashHistory.location.pathname)}>
        {hashHistory.location.pathname === '/Instance/Service/Subscriber/Trace' && (
          <NacosInstanceDetailTrack />
        )}
      </If>
      <If condition={!EmptyPageUrl.includes(hashHistory.location.pathname)}>
        <SubLayout
          breadCrumbList={newBreadCrumbList}
          items={menuItems}
          title={
            <IconBack
              back
              text={title}
              onClick={() => {
                if (
                  DetailRollBackUrl.includes(hashHistory.location.pathname) &&
                  get(sub, 'parent.link')
                ) {
                  hashHistory.push(get(sub, 'parent.link'));
                  window?.removeParams('subTitle');
                } else {
                  hashHistory.push('/InstanceList');
                }
              }}
            />
          }
          pathname={history.location.pathname}
        >
          <If
            condition={
              get(hashHistory, 'location.pathname', '').indexOf('/Instance/Service/Trace') > -1
            }
          >
            <If condition={getParams('MseVersion') === 'mse_dev'}>
              <Message type="notice" style={{ color: '#f68300', margin: '0px 0 8px' }}>
                {intl.html('mse.register.trace.discrp_dev')}
              </Message>
            </If>
            <If condition={getParams('MseVersion') === 'mse_basic'}>
              <Message type="notice" style={{ color: '#f68300', margin: '0px 0 8px' }}>
                {intl.html('mse.register.trace.basic_notice', {
                  instanceId: getParams('InstanceId') || '',
                })}
              </Message>
            </If>
            <If condition={getParams('MseVersion') === 'mse_pro'}>
              <Message type="notice" style={{ color: '#f68300', margin: '0px 0 8px' }} closeable>
                {intl.html('mse.register.trace.lower_version_notice')}
              </Message>
            </If>
          </If>
          <If
            condition={
              get(hashHistory, 'location.pathname', '').indexOf('/Instance/Config/Trace') > -1
            }
          >
            <If condition={getParams('MseVersion') === 'mse_dev'}>
              <Message type="notice" style={{ color: '#f68300', margin: '0px 0 8px' }}>
                {intl.html('mse.register.trace.discrp_dev')}
              </Message>
            </If>
            <If condition={getParams('MseVersion') === 'mse_basic'}>
              <Message type="notice" style={{ color: '#f68300', margin: '0px 0 8px' }}>
                {intl.html('mse.register.trace.config.basic_notice', {
                  instanceId: getParams('InstanceId') || '',
                })}
              </Message>
            </If>
          </If>
          <If condition={sub.isUseNamespace}>
            <div style={{ marginBottom: 16 }}>
              <span style={{ marginRight: 16 }}>{intl('mse.register.namespace')}</span>
              <Select
                showSearch
                dataSource={namespace.namespaces}
                onChange={handleChangeNamespace}
                value={namespace.activeNamespaceId}
                style={{ marginRight: 10, width: 220 }}
                itemRender={(item) => {
                  const { NamespaceShowName, SourceType = 'MSE' } = item;
                  return (
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                      }}
                    >
                      <span style={{ flex: 4, overflowX: 'hidden', textOverflow: 'ellipsis' }}>
                        {NamespaceShowName}
                      </span>
                      <If condition={SourceType.toUpperCase() !== 'MSE'}>
                        <span style={{ flex: 1, marginRight: 6, marginLeft: 6, color: '#c1c1c1' }}>
                          {SourceType.toUpperCase()}
                        </span>
                      </If>
                    </div>
                  );
                }}
              />
              <span style={{ margin: '0px 16px' }}>{intl('mse.register.namespace.id')}</span>
              <div
                style={{
                  display: 'inline-block',
                  height: 32,
                  lineHeight: '32px',
                  background: '#eff3f8',
                  padding: '0 16px',
                  minWidth: 220,
                }}
              >
                <If condition={namespace.activeNamespaceId !== 'public'}>
                  <CopyContent
                    visibility
                    text={namespace.activeNamespaceId}
                    icon={<Icon style={{ marginLeft: 4 }} type="copy" size="xs" />}
                  >
                    <span style={{ minWidth: 164, fontWeight: 700 }}>
                      {namespace.activeNamespaceId}
                    </span>
                  </CopyContent>
                </If>
                <If condition={namespace.activeNamespaceId === 'public'}>
                  <span style={{ color: '#c1c1c1' }}>{intl('mse.register.namespace.public')}</span>
                </If>
              </div>
            </div>
          </If>

          <Suspense fallback="...">
            <CommonLoading ref={loadRef}>
              <Router history={history}>
                <Route path="/Instance" component={Layout} />
              </Router>
            </CommonLoading>
          </Suspense>
        </SubLayout>
      </If>
    </React.Fragment>
  );
};

/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default InstanceSubLayout;
