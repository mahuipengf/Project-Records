import React from 'react';
import DataTreeShow from 'components/data/DataTreeShow';
import EurekaService from 'components/engine-service/EurekaService';
import NacosServiceList from 'components/nacos/NacosServiceList';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 服务管理
 */

class DataManager extends React.Component {
  constructor(props) {
    super(props);
    this.ClusterType = getParams('ClusterType') || 'ZooKeeper';
  }

  componentDidMount() { }

  renderContent = () => {
    const { ...rest } = this.props;
    let currentComponent = <DataTreeShow ref={node => (this.datainstance = node)} />;
    switch (this.ClusterType) {
      case 'ZooKeeper':
        break;
      case 'Eureka':
        currentComponent = <EurekaService />;
        break;
      case 'Nacos-Ans':
        currentComponent = <NacosServiceList {...rest} />;
        break;
      default:
        break;
    }
    return currentComponent;
  };
  render() {
    return this.renderContent();
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default DataManager;
