import React from 'react';
import BasicDetail from 'components/basicinfo/BasicDetail';
import CommonLoading from 'components/common/CommonLoading';
import { Dialog } from '@ali/wind';
import intl from '@ali/wind-intl';
import services from 'utils/services';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 基础信息页面
 */
class BasicInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      clusterModel: [],
    };
    this.loopDetailInfo = null;
  }

  componentDidMount() {
    this.getClusterDetail(true);
    this.loopDetailInfo = setInterval(() => {
      this.getClusterDetail(false);
    }, 5 * 60 * 1000);
  }

  componentWillUnmount() {
    clearInterval(this.loopDetailInfo);
  }

  open = () => {
    this.instance.open();
  };

  getClusterDetail = async (refresh, callstate) => {
    const InstanceId = getParams('InstanceId');
    if (!InstanceId) return;
    refresh && this.loading && this.loading.openLoading();
    const res = await services.getClusterInfo({
      customErrorHandle: (err, data, callback) => {
        !refresh && callstate();
        refresh && this.loading && this.loading.closeLoading();
        callback();
      },
      params: { InstanceId },
    });
    this.setState({
      clusterModel: res,
    });
    const { ClusterVersion } = res;
    localStorage.setItem('ClusterVersion', ClusterVersion);
    !refresh && callstate();
    refresh && this.loading && this.loading.closeLoading();
  };

  getBasicInfo = () => {
    // const clusterId = getParams('clusterId');
    const InstanceId = getParams('InstanceId');
    if (!InstanceId) return;
    request({
      url: 'com.alibaba.MSE.service.clusterDetail',
      data: { InstanceId },
      beforeSend: () => {
        this.loading && this.loading.openLoading();
      },
      success: (res) => {
        if (res.code === '200' && res.data) {
          const { Data } = res.data;
          const { ClusterName = '', ClusterType = '', ClusterId = '' } = Data; // 为了兼容诺曼底跳转增加的冗余代码
          if (!getParams('ClusterName')) {
            setParams('ClusterName', ClusterName);
          }
          if (!getParams('ClusterType')) {
            setParams('ClusterType', ClusterType);
          }
          setParams('clusterId', ClusterId);
          this.setState({
            clusterModel: Data,
          });
        }
      },
      complete: () => {
        this.loading && this.loading.closeLoading();
      },
    });
  };

  restartInstance = (callback) => {
    Dialog.confirm({
      content: intl('mse.register.restart'),
      onOk: () => {
        const ClusterId = getParams('clusterId');
        const InstanceId = getParams('InstanceId');
        request({
          url: 'com.alibaba.MSE.service.restart',
          data: {
            ClusterId,
            requestId: '',
            InstanceId,
          },
          success: (res) => {
            if (res.code === '200' && res.data) {
              this.getBasicInfo();
              callback && callback();
            }
          },
        });
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
  };

  render() {
    const { clusterModel } = this.state;
    return (
      <CommonLoading ref={(node) => (this.loading = node)}>
        <BasicDetail
          clusterModel={clusterModel}
          getBasicInfo={this.getClusterDetail}
          restartInstance={this.restartInstance}
        />
      </CommonLoading>
    );
  }
}
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default BasicInfo;
