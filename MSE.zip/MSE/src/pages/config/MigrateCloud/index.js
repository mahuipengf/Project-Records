import React from 'react';
import AppLayout from 'containers/AppLayout';
import { Message } from '@ali/cn-design';
import List from './components/List';
import intl from '@ali/wind-intl';

const MigrateCloud = () => {
  const breadCrumbList = [
    {
      title: intl('mse.migrate.title'),
    },
  ];
  return (
    <AppLayout breadCrumbList={breadCrumbList} title={intl('mse.migrate.title')}>
      <Message
        title={intl('mse.migrate.message1.title')}
        type="notice"
        style={{ marginBottom: 12 }}
      >
        {intl('mse.migrate.message1.content')}
        <a href="https://help.aliyun.com/document_detail/454740.html" target="_blank">
          {intl('mse.migrate.message1.link')}
        </a>
      </Message>
      <List />
    </AppLayout>
  );
};

export default MigrateCloud;
