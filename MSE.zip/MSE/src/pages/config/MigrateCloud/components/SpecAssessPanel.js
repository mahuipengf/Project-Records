import React, { useState, useEffect, useRef } from 'react';
import {
  Message,
  Form,
  Radio,
  Grid,
  Field,
  NumberPicker,
  Button,
  Divider,
  BalloonIcon,
  Loading,
} from '@ali/cn-design';
import Panel from '../../../../components/common/Panel';
import SourceInstanceType from './SourceInstanceType';
import { getCurrentRegion } from 'utils';
import { get } from 'lodash';
import intl from '@ali/wind-intl';

const FormItem = Form.Item;
const { Row, Col } = Grid;
const FormItemLabel = (text = '', popCtx = '') => (
  <span>
    <span style={{ fontSize: '13px', color: '#333' }}>{text}</span>
    <BalloonIcon
      icon="help"
      align="r"
      style={{
        color: popCtx ? '#808080' : 'transparent',
        fontSize: '12px',
        marginLeft: '5px',
      }}
      text={popCtx}
    />
  </span>
);

const commonStyle = {
  labelStyle: {
    color: '#333333',
    fontWeight: 500,
  },
  contentStyle: {
    color: '#333333',
  },
  rowStyle: {
    lineHeight: '20px',
    marginBottom: 8,
  },
};

const NacosAppAssess = [
  {
    min: 0,
    max: 500,
    scale: '1核2G',
    nodeCount: 3,
  },
  {
    min: 500,
    max: 1500,
    scale: '2核4G',
    nodeCount: 3,
  },
  {
    min: 1500,
    max: 3000,
    scale: '4核8G',
    nodeCount: 3,
  },
  {
    min: 3000,
    max: 6000,
    scale: '8核16G',
    nodeCount: 3,
  },
  {
    min: 6000,
    max: 12000,
    scale: '16核32G',
    nodeCount: 3,
  },
];
const ZooKeeperAppAssess = [
  {
    min: 0,
    max: 2000,
    scale: '2核4G',
    nodeCount: 3,
  },
  {
    min: 2000,
    max: 3000,
    scale: '4核8G',
    nodeCount: 3,
  },
  {
    min: 3000,
    max: 6000,
    scale: '8核16G',
    nodeCount: 3,
  },
  {
    min: 6000,
    max: 12000,
    scale: '16核32G',
    nodeCount: 3,
  },
];

const EngineSpecificationEnum = {
  '1核2G': 'MSE_SC_1_2_60_c',
  '2核4G': 'MSE_SC_2_4_60_c',
  '4核8G': 'MSE_SC_4_8_60_c',
  '8核16G': 'MSE_SC_8_16_60_c',
  '16核32G': 'MSE_SC_16_32_60_c',
};

const SelfCPUAssess = [1, 2, 4, 8, 16];
const SelfMemoryAssess = [2, 4, 8, 16, 32];

const SpecAssessPanel = (props) => {
  const { showIndex } = props;
  const [assessType, setAssessType] = useState('self');
  const [showResult, setShowResult] = useState(false);
  const [loading, setLoading] = useState(false);
  const [buyUrl, setBuyUrl] = useState('');
  const [spec, setSpec] = useState({
    scale: '',
    type: '',
    nodeCount: 0,
  });
  const [disabled, setDisabled] = useState(false);
  const refPanel = useRef(null);
  const field = Field.useField();
  const { init, validate } = field;

  useEffect(() => {
    if (showIndex) {
      refPanel.current.show();
      field.setValue('ClusterType', 'Nacos-Ans');
      setShowResult(false);
      setAssessType('self');
    }
  }, [showIndex]);

  useEffect(() => {
    const { CPU = 0, Memory = 0, SelfNodeCount = 0 } = field.getValues();
    if (assessType === 'self' && CPU <= 12 && Memory <= 32 && SelfNodeCount <= 9) {
      setDisabled(false);
    }
  }, [field.getValues()]);

  const onChangeAssessType = (val) => {
    setAssessType(val);
    setDisabled(false);
  };

  const handleSubmit = () => {
    validate((errors, values) => {
      if (!errors) {
        const { ClusterType, AssessType, AppNodeCount, CPU, Memory, SelfNodeCount } = values;
        let specContent = {};
        setLoading(true);
        if (AssessType === 'app') {
          //按应用规模评估
          const count = AppNodeCount * 2;
          if (ClusterType !== 'ZooKeeper') {
            const res = NacosAppAssess.find((i) => i.min <= count && i.max >= count);
            specContent = {
              scale: get(res, 'scale', '16核32G'),
              nodeCount: get(res, 'nodeCount', 3),
              type: 'Nacos',
            };
          } else {
            const res = ZooKeeperAppAssess.find((i) => i.min <= count && i.max >= count);
            specContent = {
              scale: get(res, 'scale', '16核32G'),
              nodeCount: get(res, 'nodeCount', 3),
              type: 'ZooKeeper',
            };
          }
        } else {
          //按自建实例评估
          let count;
          let memory;
          let cpu;
          if (SelfNodeCount <= 3) {
            count = 3;
          } else if (SelfNodeCount > 3 && SelfNodeCount % 2 === 0) {
            count = SelfNodeCount + 1 > 9 ? 9 : SelfNodeCount + 1;
          } else if (SelfNodeCount > 3 && SelfNodeCount % 2 === 1) {
            count = SelfNodeCount > 9 ? 9 : SelfNodeCount;
          }
          if (Memory / 2 >= CPU) {
            memory = SelfMemoryAssess.find((i) => i >= Memory) || 32;
            cpu = memory / 2;
          } else {
            cpu = SelfCPUAssess.find((i) => i >= CPU) || 16;
            memory = cpu * 2;
          }
          specContent = {
            scale: `${cpu}核${memory}G`,
            nodeCount: count,
            type: ClusterType === 'ZooKeeper' ? 'ZooKeeper' : 'Nacos',
          };
        }
        const engineType = ClusterType === 'ZooKeeper' ? 'ZooKeeper' : 'Nacos-Ans';
        const engineVersion = ClusterType === 'ZooKeeper' ? 'ZooKeeper_3_8_0' : 'NACOS_2_0_0';
        const engineSpecification = EngineSpecificationEnum[specContent.scale];
        const url = `https://common-buy.aliyun.com/?commodityCode=mse_prepaid_public_cn&request=%7B%22mse_version%22:%22mse_pro%22,%22engine_type%22:%22${engineType}%22,%22engine_version%22:%22${engineVersion}%22,%22engine_specification%22:%22${engineSpecification}%22,%22engine_hosts%22:${
          specContent.nodeCount
        }%7D&regionId=${getCurrentRegion()}`;
        setBuyUrl(url);
        setSpec(specContent);
        setTimeout(() => {
          setLoading(false);
          setShowResult(true);
        }, 500);
      }
    });
  };

  const checkCpu = (rule, val, callback) => {
    if (val > 16) {
      setDisabled(true);
      return callback(intl('mse.migrate.assess.validate1'));
    } else {
      return callback();
    }
  };

  const checkMemory = (rule, val, callback) => {
    if (val > 32) {
      setDisabled(true);
      return callback(intl('mse.migrate.assess.validate1'));
    } else {
      return callback();
    }
  };

  const checkSelfNode = (rule, val, callback) => {
    if (val > 9) {
      setDisabled(true);
      return callback(intl('mse.migrate.assess.validate2'));
    } else {
      return callback();
    }
  };

  const checkAppNode = (rule, val, callback) => {
    if (val > 6000) {
      setDisabled(true);
      return callback(intl('mse.migrate.assess.validate2'));
    } else {
      setDisabled(false);
      return callback();
    }
  };

  return (
    <Panel
      ref={refPanel}
      title={intl('mse.migrate.button2')}
      customFooter={
        <React.Fragment>
          <Button type="primary" onClick={handleSubmit} disabled={disabled}>
            {intl('mse.migrate.button2')}
          </Button>
          <Button
            onClick={() => {
              refPanel.current.hide();
              setDisabled(false);
            }}
          >
            {intl('mse.common.cancel')}
          </Button>
        </React.Fragment>
      }
    >
      <Loading visible={loading} style={{ width: '100%' }}>
        <If condition={showResult}>
          <Message
            title={intl('mse.migrate.assess.message1.title')}
            type="success"
            style={{ marginBottom: 12 }}
          >
            {intl.html('mse.migrate.assess.message1', { buyUrl: buyUrl || '' })}
          </Message>
          <div>
            <h3>{intl('mse.migrate.assess.recommend_spec')}</h3>
            <Row style={commonStyle.rowStyle}>
              <Col span={6} style={commonStyle.labelStyle}>
                {intl('mse.register.instance.version')}
              </Col>
              <Col span={6} style={commonStyle.contentStyle}>
                {intl('mse.register.instance.version_profess')}
              </Col>
              <Col span={6} style={commonStyle.labelStyle}>
                {intl('mse.migrate.assess.cluster.spec')}
              </Col>
              <Col span={6} style={commonStyle.contentStyle}>
                {spec.scale}
              </Col>
            </Row>
            <Row style={commonStyle.rowStyle}>
              <Col span={6} style={commonStyle.labelStyle}>
                {intl('mse.register.cluster')}
              </Col>
              <Col span={6} style={commonStyle.contentStyle}>
                {spec.type}
              </Col>
              <Col span={6} style={commonStyle.labelStyle}>
                {intl('mse.migrate.assess.cluster.node_count')}
              </Col>
              <Col span={6} style={commonStyle.contentStyle}>
                {spec.nodeCount}
              </Col>
            </Row>
          </div>
          <Divider />
        </If>
        <If condition={!showResult}>
          <Message
            title={intl('mse.migrate.assess.message2.title')}
            type="notice"
            style={{ marginBottom: 12 }}
          >
            {intl.html('mse.migrate.assess.message2')}
          </Message>
        </If>

        <Form field={field}>
          <FormItem label={intl('mse.migrate.column.source_instance_type')}>
            <SourceInstanceType
              {...init('ClusterType', {
                initValue: 'Nacos-Ans',
              })}
            />
          </FormItem>
          <FormItem label={intl('mse.migrate.assess.mode')}>
            <Radio.Group
              {...init('AssessType', {
                initValue: 'self',
                props: {
                  onChange: onChangeAssessType,
                },
              })}
            >
              <Radio value="self">{intl('mse.migrate.assess.self')}</Radio>
              <Radio value="app">{intl('mse.migrate.assess.app')}</Radio>
            </Radio.Group>
          </FormItem>
          <If condition={assessType === 'self'}>
            <FormItem label={intl('mse.migrate.assess.self.node_spce')} required>
              <Row gutter={8}>
                <Col span={12}>
                  <FormItem label="">
                    <NumberPicker
                      {...init('CPU', {
                        rules: [
                          { required: true, message: intl('mse.migrate.assess.self.cpu_validate') },
                          { validator: checkCpu },
                        ],
                      })}
                      style={{ width: '100%' }}
                      min={1}
                      addonTextAfter={`CPU(${intl('mse.migrate.cpu.nucleus')})`}
                    />
                  </FormItem>
                </Col>
                <Col span={12}>
                  <FormItem label="">
                    <NumberPicker
                      {...init('Memory', {
                        rules: [
                          {
                            required: true,
                            message: intl('mse.migrate.assess.self.memory_validate'),
                          },
                          { validator: checkMemory },
                        ],
                      })}
                      min={1}
                      style={{ width: '100%' }}
                      addonTextAfter={intl('mse.migrate.memory.text')}
                    />
                  </FormItem>
                </Col>
              </Row>
            </FormItem>
            <FormItem label={FormItemLabel(intl('mse.migrate.assess.self.node_count'))} required>
              <Row>
                <Col span={12}>
                  <FormItem label="">
                    <NumberPicker
                      {...init('SelfNodeCount', {
                        rules: [
                          {
                            required: true,
                            message: intl('mse.migrate.assess.self.node_validate'),
                          },
                          { validator: checkSelfNode },
                        ],
                      })}
                      min={1}
                      style={{ width: '100%' }}
                    />
                  </FormItem>
                </Col>
              </Row>
            </FormItem>
          </If>
          <If condition={assessType === 'app'}>
            <FormItem
              label={FormItemLabel(
                intl('mse.migrate.assess.app.node_count'),
                intl('mse.migrate.assess.app.node_count_tip')
              )}
              required
            >
              <Row>
                <Col span={12}>
                  <FormItem label="">
                    <NumberPicker
                      {...init('AppNodeCount', {
                        rules: [
                          {
                            required: true,
                            message: intl('mse.migrate.assess.app.node_count_validate'),
                          },
                          { validator: checkAppNode },
                        ],
                      })}
                      min={1}
                      style={{ width: '100%' }}
                    />
                  </FormItem>
                </Col>
              </Row>
            </FormItem>
          </If>
        </Form>
      </Loading>
    </Panel>
  );
};

export default SpecAssessPanel;
