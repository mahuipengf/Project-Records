import React from 'react';
import { Message, Step, CopyContent, Icon } from '@ali/cn-design';
import intl from '@ali/wind-intl';

const MethodA = [
  {
    step: 'Step1',
    title: intl.html('mse.migrate.step1.methoda.title1'),
    content:
      'docker run -td -e MYSQL_URL="jdbc:mysql://mse.sync.mysql.svc:3306/msesync" -e MYSQL_USER_NAME="username" -e MYSQL_PASSWORD="password" msecrinstance-registry.cn-hangzhou.cr.aliyuncs.com/mse-demo/mse-sync:least',
  },
  {
    step: 'Step2',
    title: intl('mse.migrate.step1.methoda.title2'),
    conetntWrap: true,
    content: `kubectl apply -f - <<EOF
    apiVersion: apps/v1
    kind: Deployment
    metadata:
      labels:
        app.kubernetes.io/name: mse-sync
      name: mse-sync-svc
    spec:
      replicas: 3
      selector:
        matchLabels:
          app.kubernetes.io/name: mse-sync
      template:
        metadata:
          labels:
            app.kubernetes.io/name: mse-sync
        spec:
          containers:
          - name: mse-sync
            image: msecrinstance-registry.cn-hangzhou.cr.aliyuncs.com/mse-demo/mse-sync:latest
            ports:
            - containerPort: 8000
            env:
            - name: MYSQL_URL
              value: "jdbc:mysql://mse.sync.mysql.svc:3306/sync"
            - name: MYSQL_USER_NAME
              value: "mse-sync"
            - name: MYSQL_PASSWORD
              value: password
    EOF`,
  },
];
const MethodB = [
  {
    step: 'Step1',
    title: intl('mse.migrate.step1.methodb.title1'),
    content: 'curl https://msesync.oss-cn-hangzhou.aliyuncs.com/MseSync.zip --output msesync.zip',
  },
  {
    step: 'Step2',
    title: intl('mse.migrate.step1.methodb.title2'),
    content: 'unzip ./msesync.zip',
  },
  {
    step: 'Step3',
    title: intl('mse.migrate.step1.methodb.title3'),
    // message: intl('mse.migrate.step1.methodb.message3'),
    conetntWrap: true,
    content: `    ${intl('mse.migrate.step3.content')}
    export MYSQL_URL=""
    export MYSQL_USER_NAME=""
    export MYSQL_PASSWORD=""`,
  },
  {
    step: 'Step4',
    title: intl('mse.migrate.step1.methodb.title4'),
    content: './MseSync/bin/startup.sh start',
  },
];

const FirstStepConfig = () => {
  const renderTitle = (step, title, message) => {
    return (
      <div style={{ fontWeight: 'normal' }}>
        <span
          style={{
            marginRight: 20,
            color: '#999',
          }}
        >
          {step}
        </span>
        <span>{title}</span>
        <span style={{ marginLeft: 8, color: '#D93026' }}>{message}</span>
      </div>
    );
  };

  const renderContent = (content, isWrap = false) => {
    return (
      <div
        style={{
          marginLeft: 50,
          width: 660,
          backgroundColor: '#F7F9FA',
          padding: '8px 12px',
          borderRadius: 2,
          display: 'flex',
        }}
      >
        <CopyContent
          text={content}
          style={{ width: '100%' }}
          visibility
          icon={
            <div>
              <span>{intl('mse.migrate.copy')}</span>
              <Icon style={{ marginLeft: 4 }} type="copy" size="xs" />
            </div>
          }
        >
          <div style={{ width: 600, whiteSpace: isWrap ? 'pre' : 'normal' }}>{content}</div>
        </CopyContent>
      </div>
    );
  };
  return (
    <div style={{ paddingTop: 12 }}>
      <Message type="notice">{intl('mse.migrate.step1.message')}</Message>
      <div>
        <h3 style={{ marginBottom: 12 }}>{intl('mse.migrate.step1.methoda')}</h3>
        <Step current={2} direction="ver" shape="dot" animation={false}>
          {MethodA.map((item) => {
            return (
              <Step.Item
                key={item.step}
                title={renderTitle(item.step, item.title)}
                content={renderContent(item.content, item.conetntWrap)}
              />
            );
          })}
          <Step.Item key={2} title="The End" />
        </Step>
      </div>
      <div>
        <h3 style={{ marginBottom: 12 }}>{intl('mse.migrate.step1.methodb')}</h3>
        <Step current={4} direction="ver" shape="dot" animation={false}>
          {MethodB.map((item) => {
            return (
              <Step.Item
                key={item.step}
                title={renderTitle(item.step, item.title, item.message)}
                content={renderContent(item.content, item.conetntWrap)}
              />
            );
          })}
          <Step.Item key={4} title="The End" />
        </Step>
      </div>
    </div>
  );
};

export default FirstStepConfig;
