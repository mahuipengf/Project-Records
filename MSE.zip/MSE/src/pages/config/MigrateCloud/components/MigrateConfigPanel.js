import React, { useState, useEffect, useRef } from 'react';
import { Step, Button } from '@ali/cn-design';
import Panel from '../../../../components/common/Panel';
import FirstStepConfig from './FirstStepConfig';
import SecondStepConfig from './SecondStepConfig';
import ThirdStepConfig from './ThirdStepConfig';
import services from 'utils/services';
import intl from '@ali/wind-intl';

const PanelSteps = [
  {
    title: intl('mse.migrate.step1.title'),
    key: 0,
  },
  {
    title: intl('mse.migrate.step2.title'),
    key: 1,
  },
  {
    title: intl('mse.migrate.step3.title'),
    key: 2,
  },
];

const MigrateConfigPanel = (props) => {
  const { showIndex, onRefresh, sourceData } = props;
  const title = sourceData ? intl('mse.migrate.button1.edit') : intl('mse.migrate.button1');
  const [currentStep, setCurrentStep] = useState(0);
  const [loading, setLoading] = useState(false);
  const [configValues, setConfigValues] = useState({});
  const [sourceConfig, setSourceConfig] = useState('');
  const refPanel = useRef(null);
  const secondRef = useRef(null);

  useEffect(() => {
    if (showIndex) {
      refPanel.current.show();
      setSourceConfig('');
      setCurrentStep(0);
    }
  }, [showIndex]);

  useEffect(() => {
    if (sourceData) {
      setSourceConfig(sourceData);
      setCurrentStep(1);
    } else {
      setCurrentStep(0);
    }
  }, [sourceData]);

  const goNext = () => {
    const step = currentStep < 2 ? currentStep + 1 : currentStep;
    if (step === 2) {
      const validateOk = secondRef.current.onValidate();
      validateOk && handleSubmit();
    } else {
      setCurrentStep(step);
    }
  };
  const goPrev = () => {
    const step = currentStep > 0 ? currentStep - 1 : 0;
    setCurrentStep(step);
  };

  const handleSubmit = async () => {
    const values = secondRef.current.getValues();
    setConfigValues(values);
    setLoading(true);
    if (sourceConfig) {
      const { Id } = sourceConfig;
      const res = await services.updateMigrationTask({
        customErrorHandle: (err, data, callback) => {
          setLoading(false);
          callback();
        },
        params: { ...values, Id },
      });
      setSourceConfig(res);
    } else {
      const res = await services.addMigrationTask({
        customErrorHandle: (err, data, callback) => {
          setLoading(false);
          callback();
        },
        params: { ...values },
      });
      setSourceConfig(res);
    }
    setCurrentStep(2);
    setLoading(false);
    onRefresh();
  };

  return (
    <Panel
      ref={refPanel}
      title={title}
      customFooter={
        <React.Fragment>
          <Button onClick={goPrev}>{intl('mse.migrate.step.prev')}</Button>
          <If condition={currentStep !== 2}>
            <Button type="primary" onClick={goNext} loading={loading}>
              {intl('mse.migrate.step.next')}
            </Button>
          </If>
          <Button onClick={() => refPanel.current.hide()}>
            {currentStep === 2 ? intl('mse.tag.dialog.close') : intl('mse.common.cancel')}
          </Button>
        </React.Fragment>
      }
    >
      <Step current={currentStep} shape="circle" size="small">
        {PanelSteps.map((step) => {
          return <Step.Item key={step.key} title={step.title} />;
        })}
      </Step>
      <If condition={currentStep === 0}>
        <FirstStepConfig />
      </If>
      <If condition={currentStep === 1}>
        <SecondStepConfig ref={secondRef} sourceData={sourceConfig} />
      </If>
      <If condition={currentStep === 2}>
        <ThirdStepConfig config={configValues} />
      </If>
    </Panel>
  );
};

export default MigrateConfigPanel;
