import React, { useState, useEffect } from 'react';
import { Icon, Balloon } from '@ali/cn-design';
import './index.less';
import intl from '@ali/wind-intl';

const SourceInstanceType = (props) => {
  const { value, onChange } = props;
  const [type, setType] = useState('Nacos');
  const dataSource = [
    {
      title: 'Nacos',
      value: 'Nacos-Ans',
      tip: intl('mse.migrate.nacos.tip'),
    },
    {
      title: 'Eureka',
      value: 'Eureka',
      tip: intl('mse.migrate.eureka.tip'),
    },
    {
      title: 'ZooKeeper',
      value: 'ZooKeeper',
      tip: intl('mse.migrate.zk.tip'),
    },
  ];

  const onChangeType = (value) => {
    setType(value);
    onChange(value);
  };

  useEffect(() => {
    value ? setType(value) : onChange('Nacos');
  }, [value]);

  return (
    <div className="source-instance-box">
      {dataSource.map((item) => {
        return (
          <div
            className={type === item.value ? 'source-instance-card-active' : 'source-instance-card'}
            onClick={() => onChangeType(item.value)}
          >
            <div>
              <span style={{ marginRight: 8 }}> {item.title}</span>
              <Balloon
                trigger={<Icon type="exclamation-circle" size="xs" />}
                closable={false}
                align="t"
              >
                {item.tip}
              </Balloon>
            </div>
            <If condition={type === item.value}>
              <Icon type="success" style={{ color: 'rgba(0,112,204,1)' }} size="small" />
            </If>
          </div>
        );
      })}
    </div>
  );
};

export default SourceInstanceType;
