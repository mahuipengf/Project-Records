import React, { useState, useEffect, useImperativeHandle } from 'react';
import { Form, Select, Input, Field, Loading } from '@ali/cn-design';
import SourceInstanceType from './SourceInstanceType';
import services from 'utils/services';
import intl from '@ali/wind-intl';
import { get } from 'lodash';

const FormItem = Form.Item;

const SecondStepConfig = React.forwardRef((props, ref) => {
  const { sourceData = '' } = props;
  const [loading, setLoading] = useState(false);
  const [clusterType, setClusterType] = useState('Nacos-Ans');
  const [instanceList, setInstanceList] = useState([]);
  const [clusterName, setClusterName] = useState('');
  const [clusterUrl, setClusterUrl] = useState('');
  const [type, setType] = useState('');
  const field = Field.useField();
  const { init, validate } = field;

  const onValidate = () => {
    let validateOk = true;
    validate((errors, values) => {
      if (errors) {
        validateOk = false;
      }
    });
    return validateOk;
  };

  const getValues = () => {
    if (onValidate) {
      const values = field.getValues();
      const result = {
        ...values,
        TargetClusterName: clusterName,
        TargetClusterUrl: clusterUrl,
        OriginInstanceName: get(values, 'OriginInstanceName', `${values.ClusterType}-src`),
        Type: type,
      };
      return result;
    }
  };

  useImperativeHandle(ref, () => ({
    onValidate,
    getValues,
  }));

  const onChangeClusterType = (val) => {
    setClusterType(val);
    field.setValue('TargetInstanceId', undefined);
    getClusterList(val);
  };

  const getClusterList = async (_clusterType) => {
    setLoading(true);
    const Data = await services.getListClusterSelection({
      customErrorHandle: (err, data, callback) => {
        setLoading(false);
        callback();
      },
      params: {
        ClusterType: _clusterType ?? clusterType,
      },
    });
    const result = Data.map((i) => {
      return {
        label: i.ClusterAliasName,
        value: i.InstanceId,
        url: i.ClusterUrl,
        type: i.ClusterType,
      };
    });
    setInstanceList(result);
    setLoading(false);
  };

  const onChangeTargetInstance = (val, _type, item) => {
    const { label = '', url = '', type = '' } = item;
    setClusterName(label);
    setClusterUrl(url);
    setType(type);
  };

  const renderInstanceItem = (item) => {
    return (
      <div>
        <span style={{ marginRight: 8 }}> {item.label}</span> /
        <span
          style={{
            fontStyle: 'oblique',
            color: '#333',
            display: 'inline-block',
            transform: 'scale(0.9)',
          }}
        >
          {item.value}
        </span>
      </div>
    );
  };

  useEffect(() => {
    if (sourceData) {
      field.setValues(sourceData);
      const { TargetClusterName = '', TargetClusterUrl = '', ClusterType = '' } = sourceData;
      setClusterName(TargetClusterName);
      setClusterUrl(TargetClusterUrl);
      setClusterType(ClusterType);
      getClusterList(ClusterType);
    }
  }, [sourceData]);

  useEffect(() => {
    !sourceData && getClusterList();
  }, []);

  useEffect(() => {
    if (instanceList && instanceList.length && sourceData) {
      const { TargetClusterName = '' } = sourceData;
      const res = instanceList.find((v) => v.label === TargetClusterName);
      setType(get(res, 'type', ''));
    }
  }, [instanceList]);

  return (
    <div style={{ padding: 8 }}>
      <Form field={field}>
        <FormItem label={intl('mse.migrate.column.source_instance_type')}>
          <SourceInstanceType
            {...init('ClusterType', {
              initValue: 'Nacos-Ans',
              props: {
                onChange: onChangeClusterType,
              },
            })}
          />
        </FormItem>
        <FormItem
          label={intl('mse.migrate.column.source_instance_node_address')}
          required
          help={intl('mse.migrate.node_address_help')}
        >
          <Input.TextArea
            {...init('OriginInstanceAddress', {
              rules: [{ required: true, message: intl('mse.migrate.node_address_validate') }],
            })}
            rows={3}
          />
        </FormItem>
        <FormItem label={intl('mse.migrate.column.source_instance')}>
          <Input
            {...init('OriginInstanceName', {
              rules: [
                // { required: true, message: intl('mse.migrate.source_instance_name_validate') },
                {
                  pattern: /^[0-9a-zA-Z\-_]{3,15}$/,
                  message: intl('mse.migrate.source_instance_name_placeholder'),
                },
              ],
            })}
            style={{ width: '100%' }}
            placeholder={intl('mse.migrate.source_instance_name_placeholder')}
          />
        </FormItem>
        <If condition={clusterType === 'Nacos-Ans'}>
          <FormItem
            label={intl('mse.migrate.namespace_list')}
            help={intl('mse.migrate.namespace_list_help')}
          >
            <Input.TextArea
              {...init('OriginInstanceNamespace')}
              style={{ width: '100%' }}
              rows={3}
              placeholder={intl('mse.migrate.namespace_list_placeholder')}
            />
          </FormItem>
        </If>

        <Loading style={{ width: '100%' }} visible={loading}>
          <FormItem
            label={
              <span>
                {intl('mse.migrate.column.target_instance')}
                <span style={{ marginLeft: 8, color: '#D93026', fontWeight: 'normal' }}>
                  {intl('mse.migrate.target_instance_help')}
                </span>
              </span>
            }
            required
          >
            <Select
              showSearch
              hasClear
              autoHighlightFirstItem={false}
              valueRender={renderInstanceItem}
              itemRender={renderInstanceItem}
              placeholder={intl('mse.migrate.target_instance_placeholder')}
              {...init('TargetInstanceId', {
                rules: [
                  { required: true, message: intl('mse.migrate.target_instance_placeholder') },
                ],
                props: {
                  onChange: onChangeTargetInstance,
                },
              })}
              style={{ width: '100%' }}
              dataSource={instanceList}
            />
          </FormItem>
        </Loading>
        <FormItem label={intl('mse.migrate.column.description')}>
          <Input.TextArea
            {...init('ProjectDesc')}
            style={{ width: '100%' }}
            rows={3}
            maxLength={64}
            showLimitHint
            placeholder={intl('mse.migrate.description.placeholder')}
          />
        </FormItem>
        <FormItem>
          <p>{intl.html('mse.migrate.description.doc')}</p>
        </FormItem>
      </Form>
    </div>
  );
});

export default SecondStepConfig;
