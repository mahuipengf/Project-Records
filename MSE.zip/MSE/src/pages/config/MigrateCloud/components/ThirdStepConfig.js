import React from 'react';
import { Step, CopyContent, Icon } from '@ali/cn-design';
import './config.less';
import yaml from 'js-yaml';
import intl from '@ali/wind-intl';

const TerminalCommand = {
  step1: "./bin/msesyncCMD.sh apply -f {'{保存的迁移文件的路径}'}",
  step3: './bin/msesyncCMD.sh check sync-finished',
  step4: './bin/shutdown.sh',
};

const ThirdStepConfig = (props) => {
  const { config } = props;
  const renderTitle = (step, title) => {
    return (
      <div>
        <span
          style={{
            marginRight: 20,
            color: '#999',
            fontWeight: 'normal',
          }}
        >
          {step}
        </span>
        <span style={{ fontSize: 14, fontWeight: 500 }}>{title}</span>
      </div>
    );
  };

  const renderStep1 = () => {
    return (
      <div style={{ lineHeight: '26px' }}>
        <div style={{ marginBottom: 8 }}>
          <div>{intl('mse.migrate.step3.step1.methoda.title')}</div>
          <div style={{ marginLeft: 48 }}>
            <div>
              1.
              <a href="javascript:;" onClick={handleExportConfig}>
                {intl('mse.migrate.step3.step1.methoda.content1')}
              </a>
            </div>
            <div> 2.{intl('mse.migrate.step3.step1.methoda.content2')}</div>
            {renderContent(TerminalCommand.step1)}
          </div>
        </div>
        <div>
          <div>{intl('mse.migrate.step3.step1.methodb.title')}</div>
          <div style={{ marginLeft: 50 }}>
            <div>1.{intl('mse.migrate.step3.step1.methodb.content1')}</div>
            <div>2.{intl('mse.migrate.step3.step1.methodb.content2')}</div>
          </div>
        </div>
      </div>
    );
  };

  const renderStep3 = () => {
    return (
      <div style={{ marginLeft: 50, lineHeight: '26px' }}>
        <div>1.{intl('mse.migrate.step3.step3.content1')}</div>
        <div>2.{intl('mse.migrate.step3.step3.content2')}</div>
        {renderContent(TerminalCommand.step3)}
        <div>{intl('mse.migrate.step3.step3.content3')}</div>
      </div>
    );
  };

  const renderStep4 = () => {
    return (
      <div style={{ marginLeft: 50, lineHeight: '26px' }}>
        <div>1.{intl('mse.migrate.step3.step4.content1')}</div>
        <div>2.{intl('mse.migrate.step3.step4.content2')}</div>
        {renderContent(TerminalCommand.step4)}
      </div>
    );
  };

  const renderContent = (content) => {
    return (
      <div className="config-content">
        <CopyContent
          text={content}
          style={{ width: '100%' }}
          visibility
          icon={
            <div>
              <span>{intl('mse.migrate.copy')}</span>
              <Icon style={{ marginLeft: 4 }} type="copy" size="xs" />
            </div>
          }
        >
          <div style={{ width: 600 }}>{content}</div>
        </CopyContent>
      </div>
    );
  };

  const fakeClick = (obj) => {
    let ev = document.createEvent('MouseEvents');
    ev.initMouseEvent(
      'click',
      true,
      false,
      window,
      0,
      0,
      0,
      0,
      0,
      false,
      false,
      false,
      false,
      0,
      null
    );
    obj.dispatchEvent(ev);
  };

  const exportRaw = (name, data) => {
    let urlObject = window.URL || window.webkitURL || window;
    let export_blob = new Blob([data]);
    let save_link = document.createElementNS('http://www.w3.org/1999/xhtml', 'a');
    save_link.href = urlObject.createObjectURL(export_blob);
    save_link.download = name;
    fakeClick(save_link);
  };

  // jsonStr 为字符串形式的json数据
  const json2yaml = (jsonStr) => {
    return yaml.dump(JSON.parse(jsonStr));
  };

  const handleExportConfig = () => {
    const {
      TargetClusterUrl,
      TargetClusterName,
      TargetInstanceId,
      ClusterType,
      OriginInstanceName,
      OriginInstanceAddress,
      OriginInstanceNamespace = '',
      Type,
    } = config;
    const TypeEnum = {
      'Nacos-Ans': 'NACOS',
      Eureka: 'EUREKA',
      ZooKeeper: 'ZK',
    };
    const type1 = Type === 'ZooKeeper' ? 'ZK' : 'NACOS';
    const type2 = TypeEnum[ClusterType];
    const addressList = OriginInstanceAddress.split('\n');
    const contentJson = {
      clusters: [
        { clusterName: TargetInstanceId, connectKeyList: [TargetClusterUrl], clusterType: type1 },
        {
          clusterName: OriginInstanceName,
          connectKeyList: addressList,
          clusterType: type2,
          namespace: OriginInstanceNamespace,
        },
      ],
      tasks: [
        {
          source: OriginInstanceName,
          destination: TargetInstanceId,
        },
      ],
    };

    const content = json2yaml(JSON.stringify(contentJson));
    exportRaw('迁移配置.yaml', content);
  };

  return (
    <div style={{ paddingTop: 12 }}>
      <div>
        <Step current={4} direction="ver" shape="dot" animation={false}>
          <Step.Item
            key={1}
            title={renderTitle('Step1', intl('mse.migrate.step3.step1.title'))}
            content={renderStep1()}
          />
          <Step.Item key={2} title={renderTitle('Step2', intl('mse.migrate.step3.step2.title'))} />
          <Step.Item
            key={3}
            title={renderTitle('Step3', intl('mse.migrate.step3.step3.title'))}
            content={renderStep3()}
          />
          <Step.Item
            key={4}
            title={renderTitle('Step4', intl('mse.migrate.step3.step4.title'))}
            content={renderStep4()}
          />
          <Step.Item key={5} title="The End" />
        </Step>
      </div>
    </div>
  );
};

export default ThirdStepConfig;
