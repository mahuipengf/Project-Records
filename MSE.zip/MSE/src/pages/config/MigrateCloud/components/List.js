import React, { useState, useEffect } from 'react';
import { TableContainer, Button, Balloon, Dialog, CopyContent } from '@ali/cn-design';
import SpecAssessPanel from './SpecAssessPanel';
import MigrateConfigPanel from './MigrateConfigPanel';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import Truncate from '@alicloud/console-components-truncate';
import services from 'utils/services';
import moment from 'moment';
import { formatDate } from 'utils';
import intl from '@ali/wind-intl';

const List = () => {
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [showIndex, setShowIndex] = useState(0);
  const [configShowIndex, setConfigShowIndex] = useState(0);
  const [sourceData, setSourceData] = useState('');

  const columns = [
    {
      title: intl('mse.migrate.column.target_instance'),
      dataIndex: 'TargetInstanceId',
      width: 250,
      lock: 'left',
      cell: (val, index, record) => renderInstance(record),
    },
    {
      title: intl('mse.migrate.column.target_instance_type'),
      dataIndex: 'TargetInstanceType',
      width: 110,
      cell: (val, index, record) => renderTargetInstanceType(record),
    },
    {
      title: intl('mse.migrate.column.source_instance'),
      dataIndex: 'OriginInstanceName',
      width: 100,
    },
    {
      title: intl('mse.migrate.column.source_instance_node'),
      dataIndex: 'OriginInstanceAddress',
      width: 150,
      cell: (val) => renderOriginInstanceAddress(val),
    },
    {
      title: intl('mse.migrate.column.source_instance_type'),
      dataIndex: 'ClusterType',
      width: 100,
      cell: (val) => renderClusterType(val),
    },
    {
      title: intl('mse.migrate.column.namespace'),
      dataIndex: 'OriginInstanceNamespace',
      width: 160,
      cell: (val, index, record) => renderNamespace(val, record),
    },
    {
      title: intl('mse.migrate.column.description'),
      dataIndex: 'ProjectDesc',
      width: 160,
      cell: (val) => (
        <Truncate
          type="width"
          threshold={150}
          tooltipMaxWidth={300}
          popupStyle={{ wordBreak: 'break-all' }}
        >
          {val || '-'}
        </Truncate>
      ),
    },
    {
      title: intl('mse.common.create.time'),
      dataIndex: 'GmtCreate',
      width: 170,
      cell: (val) => <span>{formatDate(moment(val))}</span>,
    },
    {
      title: intl('mse.common.operate'),
      dataIndex: 'Actions',
      width: 100,
      lock: 'right',
      cell: (val, index, record) => (
        <Actions>
          <LinkButton onClick={() => handleEdit(record)}>{intl('mse.common.edit')}</LinkButton>
          <LinkButton onClick={() => handleDelete(record)}>{intl('mse.common.delete')}</LinkButton>
        </Actions>
      ),
    },
  ];

  const fetchData = async (params) => {
    const { pageNumber, pageSize, OriginInstanceName } = params;
    const { Data = [], TotalCount } = await services.getListMigrationTask({
      params: {
        PageNum: pageNumber,
        PageSize: pageSize,
        OriginInstanceName,
      },
    });
    return {
      Data,
      TotalCount,
    };
  };

  const renderInstance = (record) => {
    const { TargetInstanceId, TargetClusterName } = record;
    return (
      <div>
        <div>{TargetClusterName}</div>
        <CopyContent
          text={TargetInstanceId}
          style={{ color: 'black', display: 'block' }}
          truncateProps={{ type: 'width', threshold: '200', tooltipMaxWidth: 500 }}
        >
          {TargetInstanceId}
        </CopyContent>
      </div>
    );
  };

  const renderTargetInstanceType = (record) => {
    const { ClusterType, TargetClusterUrl } = record;
    const reg1 = /8848$/;
    const reg2 = /2181$/;
    const test1 = reg1.test(TargetClusterUrl);
    const test2 = reg2.test(TargetClusterUrl);
    if (test1) {
      return 'Nacos';
    } else if (test2) {
      return 'ZooKeeper';
    } else {
      return '-';
    }
  };
  const renderClusterType = (val) => {
    if (val === 'Nacos-Ans') {
      return 'Nacos';
    } else {
      return val;
    }
  };
  const renderNamespace = (val, record) => {
    const { ClusterType } = record;
    if (ClusterType !== 'Nacos-Ans' || !val) {
      return '-';
    } else {
      return (
        <Truncate
          type="width"
          threshold={150}
          tooltipMaxWidth={300}
          popupStyle={{ wordBreak: 'break-all' }}
        >
          {val}
        </Truncate>
      );
    }
  };

  const renderOriginInstanceAddress = (val) => {
    const contentArr = val.split('\n');
    if (contentArr.length < 3) {
      return contentArr.map((item) => <div> {item} </div>);
    } else {
      return (
        <div>
          {contentArr.slice(0, 2).map((item) => (
            <div> {item} </div>
          ))}
          <div>
            <Balloon
              align="t"
              closable={false}
              trigger={<div style={{ cursor: 'pointer', width: 20 }}>...</div>}
            >
              {contentArr.map((item) => (
                <div> {item} </div>
              ))}
            </Balloon>
          </div>
        </div>
      );
    }
  };

  const handleEdit = (record) => {
    setSourceData(record);
    setConfigShowIndex(Date.now());
  };

  const handleDelete = (record) => {
    const { Id } = record;
    Dialog.confirm({
      title: intl('mse.migrate.delete'),
      content: intl('mse.migrate.delete_confirm'),
      onOk: async () => {
        await services.deleteMigrationTask({
          params: {
            Id,
          },
          customErrorHandle: (err, data, callback) => {
            callback();
          },
        });
        setRefreshIndex(Date.now());
      },
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
  };

  const search = {
    filterInfo: {
      filters: [
        {
          label: intl('mse.migrate.instance.name'),
          value: 'OriginInstanceName',
        },
      ],
      defaultValue: 'OriginInstanceName',
      placeholder: intl('mse.migrate.instance.name.placeholder'),
    },
    isCanRefresh: true,
  };

  return (
    <React.Fragment>
      <TableContainer
        fetchData={fetchData}
        columns={columns}
        refreshIndex={refreshIndex}
        operation={() => (
          <React.Fragment>
            <Button
              type="primary"
              style={{ marginRight: 8 }}
              onClick={() => {
                setConfigShowIndex(Date.now);
                setSourceData('');
              }}
            >
              {intl('mse.migrate.button1')}
            </Button>
            <Button onClick={() => setShowIndex(Date.now)}> {intl('mse.migrate.button2')}</Button>
          </React.Fragment>
        )}
        search={search}
        affixActionBar
      />
      <MigrateConfigPanel
        showIndex={configShowIndex}
        onRefresh={() => setRefreshIndex(Date.now)}
        sourceData={sourceData}
      />
      <SpecAssessPanel showIndex={showIndex} />
    </React.Fragment>
  );
};

export default List;
