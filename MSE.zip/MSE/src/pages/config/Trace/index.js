import React, { useEffect, useState } from 'react';
import intl from '@ali/wind-intl';
import { RemoteSelect, DatePicker, BalloonIcon } from '@ali/cn-design';
import { Input, Search, Icon, Button, Table, Message, Pagination, Select } from '@ali/wind';
import { trim, includes, isArray, isObject, isEmpty, get } from 'lodash';
import moment from 'moment';
import services from 'utils/services';
import './index.less';

const { RangePicker } = DatePicker;

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const ServiceTrace = (props) => {
  const {
    activeNamespaceId,
    namespaces,
    loadSuccess,
    refer = 'menu',
    serviceDetailParams,
    refreshIndex,
  } = props;
  const InstanceId = getParams('InstanceId');
  let nowTime = new Date();
  const [query, setQuery] = useState('config');
  const [curServiceName, setCurServiceName] = useState(
    get(hashHistory, 'location.state.serviceName', '')
  );
  const [curGroup, setCurGroup] = useState(get(hashHistory, 'location.state.groupName', ''));
  const [curIp, setCurIp] = useState('');
  const [tableList, setTableList] = useState([]);
  const [tableLoading, setTableLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [isInit, setInit] = useState(true);
  const [format, setFormat] = useState('YYYY-MM-DD');
  const [activeTime, setActiveTime] = React.useState('halfhour');
  const [rangeValue, setRangeValue] = React.useState([
    moment(new Date(nowTime.getTime() - 30 * 60 * 1000), 'YYYY-MM-DD'),
    moment(new Date(nowTime.getTime()), 'YYYY-MM-DD'),
  ]);
  const [cacheServices, setCacheServices] = useState([]);
  const [cacheGroup, setCacheGroup] = useState([]);

  useEffect(() => {
    // 命名空间改变的话。页面中所有内容还原成初始的样子
    // 值都为初始值，似乎默认会是重新加载对应的当前页面
  }, [activeNamespaceId]);

  useEffect(() => {
    const lang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
    lang !== 'zh' && setFormat('LLL');
  }, [aliwareGetCookieByKeyName('aliyun_lang')]);

  useEffect(() => {
    if (refreshIndex) {
      handleSearch();
    }
  }, [refreshIndex]);

  useEffect(() => {
    // 从服务列表跳转过来时有带serviceName，此时触发刷新请求
    if (curServiceName || serviceDetailParams) {
      handleSearch();
    }
  }, []);

  const getTableData = async (params = {}) => {
    setTableLoading(true);
    const res = await services.ListNamingTrack({
      params,
      customErrorHandle: (err, data, callback) => {
        setTableList([]);
        setTotal(0);
        setTableLoading(false);
        callback();
      },
    });
    if (isObject(res) && !isEmpty(res)) {
      const { TotalCount = 0, Traces = [] } = res;
      setTableList(Traces);
      setTotal(TotalCount);
    } else {
      setTableList([]);
      setTotal(0);
    }
    cacheSearchValues({
      ServiceName: params.ServiceName || '',
      GroupName: params.Group || ''
    });
    setTableLoading(false);
  };

  const cacheSearchValues = (searchValues) => {
    // eslint-disable-next-line no-shadow
    const { ServiceName, GroupName } = searchValues;
    if (!ServiceName && !GroupName) return;
    const MAX_CACHE_NUM = 20;
    // 过滤缓存key 除去value为undefined 和 空字符串
    const cacheKeys = ['ServiceName', 'GroupName'].filter(key => {
      const value = searchValues[key];
      return value && value.trim();
    });

    for (let i = 0; i < cacheKeys.length; i++) {
      const key = cacheKeys[i];
      const value = searchValues[key];
      const cacheValue = JSON.parse(localStorage.getItem(key) || '[]');

      // 1、如果有重复的不再添加
      const _value = cacheValue && cacheValue.find(val => val === value.trim());

      // eslint-disable-next-line no-continue
      if (_value) continue;

      // 2、将超出缓存数量的记录 从数组末尾删除
      if (cacheValue.length >= MAX_CACHE_NUM) cacheValue.pop();

      // 将最新的插入头部
      cacheValue.unshift(value.trim());
      localStorage.setItem(key, JSON.stringify(cacheValue));
    }
  };

  const handleSearch = (curPage = 1, curStartTs, curEndTs) => {
    if (query === 'config') {
      if (!curServiceName && !serviceDetailParams) {
        Message.warning(intl('mse.register.trace.search_config.tip'));
        return;
      }
    }
    if (query === 'ip') {
      if (!curIp && !serviceDetailParams) {
        Message.warning(intl('mse.register.trace.search_ip.tip'));
        return;
      }
    }
    // 参数中curStartTs，curEndTs存在时使用参数中的
    // 没有时，请求时可使用rangeValue的startTime和endTime，对值进行校验提示
    let newStartTs = '';
    let newEndTs = '';
    try {
      if (curStartTs && curEndTs) {
        newStartTs = moment(moment(curStartTs).format('YYYY-MM-DD HH:mm:ss')).valueOf() / 1000;
        newEndTs = moment(moment(curEndTs).format('YYYY-MM-DD HH:mm:ss').valueOf()) / 1000;
      } else {
        if (rangeValue[0]) {
          newStartTs = moment(rangeValue[0].format('YYYY-MM-DD HH:mm:ss')).valueOf() / 1000;
        }
        if (rangeValue[1]) {
          newEndTs = moment(rangeValue[1].format('YYYY-MM-DD HH:mm:ss')).valueOf() / 1000;
        }
      }
    } catch (error) {
      newStartTs = '';
      newEndTs = '';
    }
    if (!newStartTs || !newEndTs) {
      Message.warning(intl('mse.register.trace.search_time.tip'));
      return;
    }
    if (newStartTs >= newEndTs) {
      Message.warning(intl('mse.register.trace.outer_range_time.one'));
      return;
    }
    if (newEndTs - newStartTs > 24 * 60 * 60) {
      Message.warning(intl('mse.register.trace.outer_range_time'));
      return;
    }
    // 将页数置为1
    setPage(curPage);
    let params = {
      InstanceId,
      NamespaceId: activeNamespaceId === 'public' ? '' : activeNamespaceId,
      StartTs: newStartTs,
      EndTs: newEndTs,
      PageSize: pageSize,
      PageNum: curPage,
      Reverse: true,
    };

    if (serviceDetailParams) {
      const { type, serviceName = '', groupName = '', ip = '', namespaceId } = serviceDetailParams;
      params.NamespaceId = namespaceId === 'public' ? '' : namespaceId;
      if (type === 'config') {
        params.ServiceName = serviceName;
        params.Group = groupName;
      }
      if (type === 'ip') {
        params.Ip = ip;
      }
    } else {
      if (query === 'config') {
        params.ServiceName = curServiceName || '';
        params.Group = curGroup || '';
      }
      if (query === 'ip') {
        params.Ip = curIp || '';
      }
    }
    getTableData(params);
  };

  useEffect(() => {
    // query改变时如果之前选择的配置或者ip有值，切换回去时重新请求
    // 初始化页面时不需要执行，设置一个开关
    if (isInit) {
      setInit(false);
    } else if ((query === 'config' && curServiceName) || (query === 'ip' && curIp)) {
        let newStartTs = '';
        let newEndTs = '';
        try {
          if (rangeValue[0]) {
            newStartTs = moment(rangeValue[0].format('YYYY-MM-DD HH:mm:ss')).valueOf() / 1000;
          }
          if (rangeValue[1]) {
            newEndTs = moment(rangeValue[1].format('YYYY-MM-DD HH:mm:ss')).valueOf() / 1000;
          }
        } catch (error) {
          newStartTs = '';
          newEndTs = '';
        }
        if (newStartTs && newEndTs) {
          handleSearch(1);
        } else {
          setTotal(0);
          setTableList([]);
        }
      } else {
        setTotal(0);
        setTableList([]);
      }
  }, [query]);

  const handleActiveTime = (time) => {
    setActiveTime(time);
    // 改变选择的时间
    const now = new Date();
    let num = -1;
    if (time === 'halfhour') {
      num = 30;
    } else if (time === 'onehour') {
      num = 60;
    } else if (time === 'oneday') {
      num = 24 * 60;
    }
    if (num > -1) {
      let startTime = moment(new Date(now.getTime() - num * 60 * 1000), 'YYYY-MM-DD');
      let endTime = moment(new Date(now.getTime()), 'YYYY-MM-DD');
      setRangeValue([startTime, endTime]);
      // 同步更新时将startTime和endTime当作参数先传递
      handleSearch(1, startTime, endTime);
    }
  };

  const onRangeChange = (v) => {
    setRangeValue(v);
    if (includes(['halfhour', 'onehour', 'oneday'], activeTime)) {
      setActiveTime('null');
    }
  };

  //分页
  const onChange = (page) => {
    handleSearch(page);
  };

  // Disable all dates before today
  const disabledDate = function (date) {
    const currentDate = moment();
    return (
      date.valueOf() > currentDate.valueOf() ||
      date.valueOf() < currentDate.valueOf() - 7 * 24 * 60 * 60 * 1000
    );
  };

  return (
    <div className="mse-register-service-trace">
      <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap' }}>
        <If condition={!serviceDetailParams}>
          <div style={{ marginBottom: '8px' }}>
            <RemoteSelect
              dataSource={[
                { label: intl('mse.register.trace.query_dimension_service'), value: 'config' },
                { label: intl('mse.register.trace.query_dimension_ip'), value: 'ip' },
              ]}
              value={query}
              width={'140px'}
              disabled={refer === 'tab' || getParams('MseVersion') !== 'mse_pro'}
              onChange={(val) => {
                setQuery(val);
                window.CN_TRACKER.send({
                  name: val,
                  type: 'register-service-trace-query-dimension',
                });
              }}
            />
            <If condition={query === 'config'}>
              <Select.AutoComplete
                hasClear
                label={intl('mse.register.service.name')}
                dataSource={cacheServices}
                placeholder={intl('mse.register.trace.please_search')}
                onChange={(val) => setCurServiceName(trim(val))}
                style={{ marginLeft: 8, width: 250 }}
                onPressEnter={() => handleSearch(1)}
                disabled={refer === 'tab' || getParams('MseVersion') !== 'mse_pro'}
                onFocus={() => {
                  const _cacheData = JSON.parse(localStorage.getItem('ServiceName') || '[]');
                  setCacheServices(_cacheData);
                }}
              />

              <Select.AutoComplete
                hasClear
                label={intl('mse.register.service.group')}
                dataSource={cacheGroup}
                placeholder={'DEFAULT_GROUP'}
                onChange={(val) => setCurGroup(trim(val))}
                style={{ marginLeft: 8, width: 250 }}
                onPressEnter={() => handleSearch(1)}
                disabled={refer === 'tab' || getParams('MseVersion') !== 'mse_pro'}
                onFocus={() => {
                  const _cacheData = JSON.parse(localStorage.getItem('GroupName') || '[]');
                  setCacheGroup(_cacheData);
                }}
              />
            </If>
            <If condition={query === 'ip'}>
              <span className="custom_span" style={{ margin: '0px 8px 0px 8px' }}>
                IP
              </span>
              <Input
                value={curIp}
                disabled={refer === 'tab' || getParams('MseVersion') !== 'mse_pro'}
                onChange={(val) => setCurIp(trim(val))}
                style={{ width: 160 }}
                placeholder={intl('mse.register.trace.please_search')}
                onPressEnter={() => handleSearch(1)}
              />
            </If>
          </div>
        </If>

        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
          <Button.Group>
            <Button
              type={activeTime === 'halfhour' ? 'secondary' : 'normal'}
              disabled={getParams('MseVersion') !== 'mse_pro'}
              onClick={() => handleActiveTime('halfhour')}
            >
              {intl('mse.register.trace.half_hour')}
            </Button>
            <Button
              type={activeTime === 'onehour' ? 'secondary' : 'normal'}
              disabled={getParams('MseVersion') !== 'mse_pro'}
              onClick={() => handleActiveTime('onehour')}
            >
              {intl('mse.register.trace.one_hour')}
            </Button>
            <Button
              type={activeTime === 'oneday' ? 'secondary' : 'normal'}
              disabled={getParams('MseVersion') !== 'mse_pro'}
              onClick={() => handleActiveTime('oneday')}
            >
              {intl('mse.register.trace.one_day')}
            </Button>
          </Button.Group>
          <span className="custom_span" style={{ margin: '0px 8px 0px 8px' }}>
            {intl('mse.register.trace.search_custom_time')}
            <BalloonIcon
              icon="help"
              align="r"
              style={{
                fontSize: '12px',
                marginLeft: '5px',
              }}
              text={intl('mse.register.trace.search_custom_time_tips')}
            />
          </span>
          <RangePicker
            showTime={{
              format: 'HH:mm:ss',
            }}
            format={format}
            onChange={(v) => onRangeChange(v)}
            value={rangeValue}
            style={{ marginRight: '8px' }}
            disabledDate={disabledDate}
            disabled={getParams('MseVersion') !== 'mse_pro'}
          />
          <Button
            type="primary"
            disabled={getParams('MseVersion') !== 'mse_pro'}
            onClick={() => {
              window.CN_TRACKER.send({
                type: 'register-trace-search',
              });
              handleSearch(1);
            }}
          >
            {intl('mse.register.trace.search_btn')}
          </Button>
        </div>
      </div>
      <Table dataSource={tableList} loading={tableLoading} hasBorder={false}>
        <Table.Column
          title={intl('mse.register.trace.push_time')}
          dataIndex="PushTime"
          cell={(value, index, record) => {
            return value ? <span>{value}</span> : '--';
          }}
        />
        <Table.Column title={intl('mse.register.trace.client_ip')} dataIndex="ClientIp" />
        <Table.Column title={intl('mse.register.trace.service_name')} dataIndex="ServerName" />
        <Table.Column title={intl('mse.register.trace.group_name')} dataIndex="Group" />
        <Table.Column title={intl('mse.register.trace.instance_size')} dataIndex="InstanceSize" />
        <Table.Column title={intl('mse.register.trace.node_name')} dataIndex="NodeName" />
      </Table>
      <div style={{ marginTop: '8px', display: 'flex', justifyContent: 'flex-end' }}>
        <Pagination
          total={total}
          current={page}
          pageSize={pageSize}
          onChange={onChange}
          totalRender={() => (
            <div style={{ color: '#888', fontSize: '12px' }}>
              {intl('mse.register.trace.total_tip', { total })}
            </div>
          )}
        />
      </div>
    </div>
  );
};

/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default ServiceTrace;
