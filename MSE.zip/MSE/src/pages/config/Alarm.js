import React, { useEffect, useState, useRef } from 'react';
import AppLayout from 'containers/AppLayout';
import { getCurrentRegion } from 'utils';
import CommonLoading from '../../components/common/CommonLoading';
import './Alarm.less';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 告警页面
 */
const ArmsDomains = {
  // 华东1（杭州预发）
  // 'cn-hangzhou': { RegionId: 'cn-hangzhou', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'c87a28ba064024ec8b432172ab9e43b9c' },
  // 华东1（杭州）
  'cn-hangzhou': { RegionId: 'cn-hangzhou', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'ce35bb9667ac44635877aa2c64a03f550' },
  // 华东2（上海）
  'cn-shanghai': { RegionId: 'cn-shanghai', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'cf09705f5a82f454db0d50420b6b4e904' },
  // 华北1（青岛）
  'cn-qingdao': { RegionId: 'cn-qingdao', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'c85521feded594fab85f11690d0d1056c' },
  // 华北2（北京）
  'cn-beijing': { RegionId: 'cn-beijing', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'cb1926867369e4000b68e8529a7c135ed' },
  // 华北3（张家口）
  'cn-zhangjiakou': { RegionId: 'cn-zhangjiakou', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'c7881148582a144049027f67d23fcd760' },
  // 华北5（呼和浩特）
  'cn-huhehaote': { RegionId: 'cn-huhehaote', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'ca62b864a20ee4551aabd083bf26a2823' },
  // 华南1（深圳）
  'cn-shenzhen': { RegionId: 'cn-shenzhen', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'ce5504be053e1481d95cb5850d8ca1708' },
  // 华南2（河源）
  'cn-heyuan': { RegionId: 'cn-heyuan', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'cc23cfd1fd9c64e72823b9f7dae4175fa' },
  // 华南3（广州）
  'cn-guangzhou': { RegionId: 'cn-guangzhou', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'c70bc7d9a3a514f1997484354812cef25' },
  // 西南1（成都）
  'cn-chengdu': { RegionId: 'cn-chengdu', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'cf538c05d18ea4bbeb9ce15e3e0c14497' },
  // 中国（香港）
  'cn-hongkong': { RegionId: 'cn-hongkong', Domain: 'https://arms.console.aliyun.com', PrometheusId: 'c6c5ddd2040a545bfbb9021253fa0ab99' },
  // 新加坡
  'ap-southeast-1': { RegionId: 'ap-southeast-1', Domain: 'https://arms-ap-southeast-1.console.aliyun.com', PrometheusId: 'cfa73532495d6489c8c518192564b7496' },
  // 澳大利亚（悉尼）暂时没有
  'ap-southeast-2': { RegionId: 'ap-southeast-2', Domain: 'https://arms-ap-southeast-1.console.aliyun.com', PrometheusId: 'pidcj9by0x' },
  // 马来西亚（吉隆坡）
  'ap-southeast-3': { RegionId: 'ap-southeast-3', Domain: 'https://arms-ap-southeast-1.console.aliyun.com', PrometheusId: 'c28b596831544452c9ab1ac40ac87aa9b' },
  // 印度尼西亚（雅加达）
  'ap-southeast-5': { RegionId: 'ap-southeast-5', Domain: 'https://arms-ap-southeast-1.console.aliyun.com', PrometheusId: 'ca6e1ebd110ca460baaf5a5f102f9ae53' },
  // 日本（东京）
  'ap-northeast-1': { RegionId: 'ap-northeast-1', Domain: 'https://arms-jp.console.aliyun.com', PrometheusId: 'c898b1f9e2ec1450e8e3ed04d20488ef9' },
  // 德国（法兰克福）
  'eu-central-1': { RegionId: 'eu-central-1', Domain: 'https://arms-eu.console.aliyun.com', PrometheusId: 'cc47af75260554356b46797e7ad46b495' },
  // 英国（伦敦）
  'eu-west-1': { RegionId: 'eu-west-1', Domain: 'https://arms-eu.console.aliyun.com', PrometheusId: 'c25bc6660747246ddae3c6a2765a57a1a' },
  // 美国（硅谷）
  'us-west-1': { RegionId: 'us-west-1', Domain: 'https://arms-us-west-1.console.aliyun.com', PrometheusId: 'cb74f5a40c74b4ec29e07954c2c6c3931' },
  // 美国（弗尼吉亚）
  'us-east-1': { RegionId: 'us-east-1', Domain: 'https://arms-us-west-1.console.aliyun.com', PrometheusId: 'c6192e5954a104b28888862282796c36c' },
  // 印度（孟买）
  'ap-south-1': { RegionId: 'ap-south-1', Domain: 'https://arms-ap-southeast-1.console.aliyun.com', PrometheusId: 'c306d372325e84793977055b98d21f62b' },
  // 政务云
  'cn-north-2-gov-1': { RegionId: 'cn-north-2-gov-1', Domain: 'https://arms-gov.console.aliyun.com', PrometheusId: 'c486cfd36b934499097b70a90fcdb17ca' },
  // 金融云 华东2
  'cn-shanghai-finance-1': { RegionId: 'cn-shanghai-finance-1', Domain: 'https://arms4finance.console.aliyun.com', PrometheusId: 'c8853a457a9e1405784e131fc3795ee7a' },
  // 金融云 华南1
  'cn-shenzhen-finance-1': { RegionId: 'cn-shenzhen-finance-1', Domain: 'https://arms4finance.console.aliyun.com', PrometheusId: 'c16044e8a942a4c088e1ebff13008ef7a' },
};

const Alarm = () => {
  const regionId = getCurrentRegion();
  const refLoading = useRef(null);
  const iframeRef = useRef(null);
  const [alarmUri, setAlarmUri] = useState();

  useEffect(() => {
    const armsParams = ArmsDomains[regionId];
    clusterInstanceValues(armsParams);
    iframeRef.current.addEventListener('load', onLoad);
    iframeRef.current.addEventListener('error', onLoad);
    return () => {
      iframeRef.current.removeEventListener('load', onLoad);
      iframeRef.current.addEventListener('error', onLoad);
    };
  }, [regionId]);

  const clusterInstanceValues = async (armsParams) => {
    refLoading && refLoading.current.openLoading();
    const { RegionId, Domain, PrometheusId } = armsParams;
    const result = await getClustersList();
    const _clusters = [];
    const { Data } = result;
    Data.forEach(cluster => {
      const { ClusterName, ClusterAliasName, ClusterType, MseVersion } = cluster;
      let _label = `${ClusterAliasName}(${ClusterType})`;
      if (ClusterType === 'ZooKeeper' && MseVersion === 'mse_pro') {
        _label = `${ClusterAliasName}(${ClusterType}专业版)`;
      }
      _clusters.push({ value: ClusterName, label: _label });
    });
    const search = `?iframeMode=true&productCode=mse&customCluster={"showCluster":false,"value":"${PrometheusId}","content":[{"value":"${PrometheusId}","label":"mse"}]}&customFilter=[{"params":["mse_pod_name"],"type":"number","showFilter":false,"showInput":true,"filterLabel":"clusterId","filterDimName":"${intl('mse.register.alarm.cluster')}","filterDim":"service_cluster_id","value":"","valueType":"string","opt":"=~","supportOpts":[{"value":"=~","label":"正则匹配"}],"values":${JSON.stringify(_clusters)}}]&listTitle=${intl('mse.register.alarm.list')}&alertTitle=${intl('mse.register.alarm.rules')}&newPage=false&alertType=0`;
    const hash = `#/prom/alert/${RegionId}`;
    const _alarmUri = `${Domain}${search}${hash}`;
    setAlarmUri(_alarmUri);
    // refLoading && refLoading.current.closeLoading();
  };

  const getClustersList = () => {
    return new Promise((resolve, reject) => {
      request({
        url: 'com.alibaba.MSE.service.clusterList',
        data: {
          pageNum: 1,
          pageSize: 100,
        },
        noerror: false,
        beforeSend: () => { },
        success: (res) => {
          if (res.code === '200' && res.data) {
            let { Data, TotalCount } = res.data;
            const result = {
              Data,
              TotalCount,
            };
            resolve(result);
          }
        },
        complete: (res) => {
          if (res.responseJSON.code === 'InvalidRegion' || res.responseJSON.data.ErrorCode === 'NoPermission') {
            const result = {
              Data: [],
              TotalCount: 0,
            };
            resolve(result);
          }
        },
      });
    });
  };

  const onLoad = () => {
    refLoading && refLoading.current.closeLoading();
  };

  const breadCrumbList = [
    {
      title: intl('mse.register.menu.alarm_policy'),
    },
  ];

  return (
    <AppLayout breadCrumbList={breadCrumbList} title="" isKeepCrumb={false}>
      <div className="alarm-loading">
        <CommonLoading ref={refLoading}>
          <iframe
            src={alarmUri}
            ref={iframeRef}
            style={{ width: '100%', border: 'none', height: 'calc(100% + 16px)', marginTop: -16 }}
          />
        </CommonLoading>
      </div>
    </AppLayout>
  );
};

export default Alarm;
