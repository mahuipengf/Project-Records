import React, { useEffect, useState } from 'react';
import InstanceList from '../../containers/InstanceList/index';
import AppLayout from 'containers/AppLayout';
import services from 'utils/services';
import { get, map } from 'lodash';
import intl from '@ali/wind-intl';
import { forApp } from '@alicloud/console-base-messenger';
import { Balloon } from '@ali/cn-design';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const status = {
  2: { type: 'danger' },
  0: { type: 'warning' },
  3: { type: 'info' },
  1: { type: 'success' },
};
const aliyun_lang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
const Index = () => {
  const [noticeList, setNoticeList] = useState([]);
  const breadCrumbList = [
    {
      title: intl('mse.register.menu.instance'),
    },
  ];
  const regionId = window.regionId || 'cn-hangzhou';

  useEffect(() => {
    if (localStorage.getItem('configResourceCount')) {
      forApp.setRegionResourceCount(JSON.parse(localStorage.getItem('configResourceCount')));
    }
  }, []);

  const fetchAnnouncement = async () => {
    const res = await services.fetchAnnouncement({
      params: {
        id: 'mse',
      },
    });
    const data = get(res, 'data.data.notice.announcement.data', []);
    const newData = map(data, (item) => ({ ...item, ...(status[item.alert_type] || {}) }));
    setNoticeList(newData);
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.register.menu.instance')}
      // announcement={noticeList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {intl('mse.common.document')}：
          <a
            target="_blank"
            href={
              aliyun_lang === 'zh'
                ? 'https://help.aliyun.com/document_detail/476467.html '
                : 'https://www.alibabacloud.com/help/en/microservices-engine/latest/registered-configuration-enter-faq'
            }
            onClick={() => {
              window.CN_TRACKER.send({
                name: 'instance-list-help',
                type: 'instance-list',
              });
            }}
          >
            FAQ
          </a>
          <Balloon
            trigger={
              <a
                style={{ marginLeft: 12 }}
                target="_blank"
                href={
                  aliyun_lang === 'zh'
                    ? 'https://help.aliyun.com/document_detail/606689.html?spm=5176.mse-prod.help.dexternal.5959142fayfMUn'
                    : 'https://www.alibabacloud.com/help/en/microservices-engine/latest/install-and-use-mseutil'
                }
              >
                {intl('mse.register.diagnostic_tool')}
              </a>
            }
            align="l"
            closable={false}
          >
            {intl('mse.register.diagnostic_tool_hint')}
          </Balloon>
        </div>
      }
      message={[
        {
          type: 'notice',
          text: intl.html('mse.register.notice1'),
        },
        {
          type: 'notice',
          text:
            aliyun_lang === 'zh'
              ? intl.html('mse.register.notice2')
              : intl.html('mse.register.notice2_intl'),
        },
      ]}
    >
      <InstanceList regionId={regionId} />
    </AppLayout>
  );
};

/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default Index;
