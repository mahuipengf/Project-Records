import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.micro_flowbox'),
  },
];
const REGION_ID = window.regionId;
const ServiceFlowBoxList = (props) => {
  const { message } = props;
  const widgetProps = {
    component: 'Traffic',
    defaultValue: {
      regionId: REGION_ID,
    },
  };

  const goToRecordDetail = (payload) => {
    console.log('ready to goto recordDetailPage');
    let ServiceName = payload.ServiceName;
    let ApplicationName = payload.AppName;
    let AppId = payload.AppId;
    let ConfigData = payload.ConfigData;

    const { history } = props;
    history.push({
      pathname: '/msc/services/recordDetail',
      search: `?ServiceName=${ServiceName}&ApplicationName=${ApplicationName}&AppId=${AppId}&ConfigData=${ConfigData}`,
    });
  };

  const goToPerformanceRecordDetail = (payload) => {
    console.log('ready to goto PerformancerecordDetailPage');
    let ServiceName = payload.ServiceName;
    let ApplicationName = payload.AppName;
    let AppId = payload.AppId;
    let ConfigData = payload.ConfigData;

    const { history } = props;
    history.push({
      pathname: '/msc/services/performanceRecordDetail',
      search: `?ServiceName=${ServiceName}&ApplicationName=${ApplicationName}&AppId=${AppId}&ConfigData=${ConfigData}`,
    });
  };
  const goToRepeatDetail = (payload) => {
    console.log('ready to goto recordRepeatPage');
    let ServiceName = payload.ServiceName;
    let ApplicationName = payload.AppName;
    const { history } = props;
    history.push({
      pathname: '/msc/services/repeatDetail',
      search: `?ServiceName=${ServiceName}&ApplicationName=${ApplicationName}`,
    });
  };
  const goToPerformanceDetail = (payload) => {
    console.log('ready to goto recordRepeatPage');
    let scenarioId = payload.ScenarioId;

    const { history } = props;
    history.push({
      pathname: 'msc/services/stress/info',
      search: `?scenarioId=${scenarioId}`,
    });
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-RecordDetail`, goToRecordDetail);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-PerformanceRecordDetail`, goToPerformanceRecordDetail);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-RepeatDetail`, goToRepeatDetail);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-PerformanceDetail`, goToPerformanceDetail);

    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-RecordDetail`, goToRecordDetail);
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-PerformanceRecordDetail`, goToPerformanceRecordDetail);
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-RepeatDetail`, goToRepeatDetail);
      eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-PerformanceDetail`, goToPerformanceDetail);

    };
  }, []);

  // 下线公告
  const getMessage = () => {
    const item = {
      type: 'notice',
      text: intl.html('mse.msc.automated_regression.notice')
    };
    return [
      item
    ];
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      // breadCrumbExpand={
      //   <div style={{ height: 16 }}>
      //     智能流量测试功能正在公测中，如果您有使用需求，请加入钉钉交流群：
      //     <img
      //       style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
      //       src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
      //     />
      //     <span style={{ color: '#0070cc', marginRight: 8 }}> 31180380 </span> 帮助文档：<a target="_blank" href="https://help.aliyun.com/document_detail/215584.html">智能流量测试 Spring Cloud 服务</a>
      //   </div>
      // }
      title={intl('mse.msc.menu.micro_flowbox')}
      message={message ? [message] : getMessage()}
    >

      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default ServiceFlowBoxList;
