import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';

const breadCrumbList = [
  {
    title: '性能场景',
  },
];
const REGION_ID = window.regionId;
const PerformanceDetail = ({ message }) => {
  const widgetProps = {
    component: 'PerformanceRecord',
    defaultValue: {
      regionId: REGION_ID,
    },
  };

  // const handleGoToPerformanceDetail = (payload) => {
  //   const { history } = props;
  //   history.push({
  //     pathname: '/msc/services/stress',
  //   });
  // };

  useEffect(() => {
    // eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-FlowBoxList`, handleGoToPerformanceDetail);
    return () => {
      // eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-FlowBoxList`, handleGoToPerformanceDetail);
    };
  }, []);

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title="性能场景"
      message={message ? [message] : []}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default PerformanceDetail;
