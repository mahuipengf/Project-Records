import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.micro_stress'),
  },
];
const REGION_ID = window.regionId;
const ServiceStressInfo = (props) => {
  const ScenarioId = getParams('scenarioId');
  const { history, message } = props;
  console.log(ScenarioId);
  const widgetProps = {
    component: 'ScenarioList',
    defaultValue: {
      regionId: REGION_ID,
      scenarioId: ScenarioId
    },
  };

  console.log(widgetProps);

  const goToIntelligentFlowList = (payload) => {
    console.log('goToIntelligentFlowList from info ');
    history.push('/msc/services/flowbox');
  };


  const goToPerformanceScenarioEdit = (payload) => {
    const { AppId, AppName, Source } = { appId: 1, AppName: '123', Source: 'mse' };
    const { history } = props;
    history.push({
      pathname: '/msc/services/stressEdit',
      search: `?AppId=${AppId}&AppName=${AppName}&Source=${Source}`,
    });
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-PerformanceScenarioEdit`, goToPerformanceScenarioEdit);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-IntelligentFlowList`, goToIntelligentFlowList);
    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-PerformanceScenarioEdit`, goToPerformanceScenarioEdit);
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-IntelligentFlowList`, goToIntelligentFlowList);
    };
  }, []);

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          微服务引擎钉钉交流群：
          <img
            style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
            src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
          />
          <span style={{ color: '#0070cc', marginRight: 8 }}> 31180380 </span> 帮助文档：<a target="_blank" href="https://help.aliyun.com/document_detail/189233.html">压测 Spring Cloud 服务</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/189234.html">压测 Dubbo 服务</a>
        </div>
      }
      title={intl('mse.msc.menu.micro_stress')}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default ServiceStressInfo;
