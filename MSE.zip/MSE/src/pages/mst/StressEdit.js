import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.micro_stress'),
  },
];
const REGION_ID = window.regionId;
const ServiceStressEdit = (props) => {
  const { message } = props;
  const widgetProps = {
    component: 'ScenarioEdit',
    defaultValue: {
      regionId: REGION_ID,
    },
  };


  const goToPerformanceScenarioList = (payload) => {
    const { history } = props;
    history.push({
      pathname: '/msc/services/stress'
    });
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-PerformanceScenarioList`, goToPerformanceScenarioList);
    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-PerformanceScenarioList`, goToPerformanceScenarioList);
    };
  }, []);


  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.msc.menu.micro_stress')}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default ServiceStressEdit;
