import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';

const breadCrumbList = [
  {
    title: '性能流量录制',
  },
];
const REGION_ID = window.regionId;
const ServicePerformanceRecordDetail = (props) => {
  const { message } = props;
  const widgetProps = {
    component: 'PerformanceRecordDetail',
    defaultValue: {
      regionId: REGION_ID,
    },
  };

  const handleGoToInspectionTaskList = (payload) => {

    const { history } = props;
    history.push({
      pathname: '/msc/services/flowbox',

    });
  };

  const handleGoToperformancePage = (payload) => {
    console.log('ready to goto handleGoToperformancePage');
    let scenarioId = payload.ScenarioId;
    const { history } = props;
    history.push({
      pathname: '/msc/services/stress/info',
      search: `?scenarioId=${scenarioId}`,

    });
  };
  const handleGoAutomationPage = (payload) => {
    console.log('ready to goto handleGoToperformancePage');
    let scenarioId = payload.ScenarioId;
    const { history } = props;
    history.push({
      pathname: '/msc/services/stress/info',
      search: `?scenarioId=${scenarioId}`,

    });
  };
  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-FlowBoxList`, handleGoToInspectionTaskList);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-FlowBoxPerformList`, handleGoToperformancePage);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-FlowBoxAutomation`, handleGoAutomationPage);

    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-FlowBoxList`, handleGoToInspectionTaskList);
      eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-FlowBoxPerformList`, handleGoToperformancePage);
      eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-FlowBoxAutomation`, handleGoAutomationPage);

    };
  }, []);

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      // breadCrumbExpand={
      //   <div style={{ height: 16 }}>
      //     智能流量测试功能正在公测中，如果您有使用需求，请加入钉钉交流群：
      //     <img
      //       style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
      //       src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
      //     />
      //     <span style={{ color: '#0070cc', marginRight: 8 }}> 31180380 </span> 帮助文档：<a target="_blank" href="https://help.aliyun.com/document_detail/215584.html">智能流量测试 Spring Cloud 服务</a>
      //   </div>
      // }
      title="性能流量录制"
      message={message ? [message] : []}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default ServicePerformanceRecordDetail;
