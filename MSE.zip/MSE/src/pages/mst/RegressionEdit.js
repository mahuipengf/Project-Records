import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.micro_regress'),
  },
];
const REGION_ID = window.regionId;
const ServiceRegressionEdit = (props) => {
  const { message } = props;
  const widgetProps = {
    component: 'TestCaseEdit',
    defaultValue: {
      regionId: REGION_ID,
    },
  };

  const goToTestCaseList = (payload) => {
    const { history } = props;
    history.push({
      pathname: '/msc/services/regression'
    });
  };

  const goToTestCaseEdit = (payload) => {
    console.log("goToTestCaseEdit payload=" + JSON.stringify(payload));
    let caseId = -1;
    if (payload != null && payload != {}) {
      caseId = payload.CaseId;
    }
    const { history } = props;
    if (caseId > 0) {
      history.push({
        pathname: '/msc/services/regressionEdit',
        search: `?id=${caseId}`,
      });
    }
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-TestCaseList`, goToTestCaseList);
    // eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-TestCasedit`, goToTestCaseEdit);
    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-TestCaseList`, goToTestCaseList);
      // eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-TestCasedit`, goToTestCaseEdit);
    };
  }, []);

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.msc.menu.micro_regress')}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default ServiceRegressionEdit;
