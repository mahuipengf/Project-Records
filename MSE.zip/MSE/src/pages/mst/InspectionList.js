import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.micro_inspect'),
  },
];
const REGION_ID = window.regionId;
const ServiceInspectionList = (props) => {
  const { message } = props;
  const widgetProps = {
    component: 'InspectionTaskList',
    defaultValue: {
      regionId: REGION_ID,
    },
  };

  const goToWarnningList = (payload) => {
    console.log("goToTestCaseEdit payload=" + JSON.stringify(payload));
    let caseName = payload.TaskName;
    console.log('caseName');
    console.log(caseName);
    const { history } = props;
    history.push({
      pathname: '/msc/services/warnningList',
      search: `?TaskName=${caseName}`,
    });
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-WarnningList`, goToWarnningList);
    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-WarnningList`, goToWarnningList);
    };
  }, []);

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {/* {intl('mse.common.dingding')}：
          <img
            style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
            src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
          />
          <span style={{ color: '#0070cc', marginRight: 8 }}> 31180380 </span> */}
          {intl('mse.common.document')}：<a target="_blank" href="https://help.aliyun.com/document_detail/189570.html">巡检 Dubbo 服务</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/189569.html">巡检 Spring Cloud 服务</a>
        </div>
      }
      title={intl('mse.msc.menu.micro_inspect')}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />

    </AppLayout>
    // <AppLayout
    //   breadCrumbList={breadCrumbList}
    //   title="服务巡检"
    // >
    //   <h4>功能正在开发中，敬请期待 ...</h4>
    //   <h2>功能介绍</h2>
    //   <h4>云原生时代下应用微服务化是趋势，如何保障线上服务可靠性，主动感知线上服务异常，提前暴露风险。服务巡检帮助您对在线服务进行7*24小时的秒级探测，实时了解服务的健康度，且当服务异常时及时告警，尽快恢复，降低损失。</h4>
    //   <h2>微服务测试交流群</h2>
    //   <h4>如果您在微服务引擎MSE使用微服务测试过程中有任何疑问，欢迎您使用钉钉扫描下方的二维码或搜索钉钉群号 31180380 加入钉钉群进行反馈。</h4>
    //   <img width='250' src='https://img.alicdn.com/tfs/TB1BBo117Y2gK0jSZFgXXc5OFXa-858-1034.png' />
    // </AppLayout>
  );
};

export default ServiceInspectionList;
