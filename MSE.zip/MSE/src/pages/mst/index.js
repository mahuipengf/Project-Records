import ServiceStressList from './StressList';
import ServiceStressInfo from './StressInfo';
import ServiceStressEdit from './StressEdit';
import ServiceRegressionList from './RegressionList';
import ServiceRegressionEdit from './RegressionEdit';
import ServiceRegressionSetList from './RegressionSetList';
import ServiceRegressionSetDetail from './RegressionSetDetail';
import ServiceInspectionList from './InspectionList';
import ServiceWarnningList from './WarnningList';
import ServiceFlowBoxList from './FlowBoxList';
import ServiceRecordDetail from './RecordDetail';
import ServicePerformanceRecordDetail from './PerformanceRecordDetail';

import ServiceRepeatDetail from './RepeatDetail';

export {
  ServiceStressList,
  ServiceStressInfo,
  ServiceStressEdit,
  ServiceRegressionList,
  ServiceRegressionEdit,
  ServiceRegressionSetList,
  ServiceRegressionSetDetail,
  ServiceInspectionList,
  ServiceWarnningList,
  ServiceFlowBoxList,
  ServiceRecordDetail,
  ServicePerformanceRecordDetail,
  ServiceRepeatDetail
};
