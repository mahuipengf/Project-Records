import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.micro_setlist'),
  },
];
const REGION_ID = window.regionId;
const ServiceRegressionSetDetail = (props) => {
  const { message } = props;
  const widgetProps = {
    component: 'TestSetDetail',
    defaultValue: {
      regionId: REGION_ID,
    },
  };

  const goToTestSetList = (payload) => {
    const { history } = props;
    history.push({
      pathname: '/msc/services/regressionSetList'
    });
  };

  const goToTestSetCaseEdit = (payload) => {
    console.log("goToTestSetCaseEdit-setdetail payload=" + JSON.stringify(payload));
    let caseId = -1;
    let testSetId = -1;
    if (payload != null && payload != {}) {
      caseId = payload.CaseId;
      testSetId = payload.testSetId;
    }

    const { history } = props;
    if (caseId == -1 || caseId == undefined) {
      if (testSetId == -1 || testSetId == undefined) {
        history.push({
          pathname: '/msc/services/regressionEdit',
          search: ``,
        });
      } else {
        history.push({
          pathname: '/msc/services/regressionEdit',
          search: `?testSetId=${testSetId}`,
        });
      }
    } else {
      if (testSetId == -1 || testSetId == undefined) {
        history.push({
          pathname: '/msc/services/regressionEdit',
          search: `?id=${caseId}`,
        });
      } else {
        history.push({
          pathname: '/msc/services/regressionEdit',
          search: `?id=${caseId}&testSetId=${testSetId}`,
        });
      }

    }
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-TestSetList`, goToTestSetList);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-TestSetCasedit`, goToTestSetCaseEdit);
    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-TestSetList`, goToTestSetList);
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-TestSetCasedit`, goToTestSetCaseEdit);
    };
  }, []);

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.msc.menu.micro_setlist')}
      message={message ? [message] : []}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default ServiceRegressionSetDetail;
