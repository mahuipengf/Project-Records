import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.micro_inspect'),
  },
];
const REGION_ID = window.regionId;
const ServiceWarnningList = (props) => {
  const widgetProps = {
    component: 'WarnningList',
    defaultValue: {
      regionId: REGION_ID,
    },
  };

  const handleGoToInspectionTaskList = (payload) => {
    const { history } = props;
    history.push({
      pathname: '/msc/services/inspectionList',
    });
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-InspectionTaskList`, handleGoToInspectionTaskList);
    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-InspectionTaskList`, handleGoToInspectionTaskList);
    };
  }, []);

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.msc.menu.micro_inspect')}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
  );
};

export default ServiceWarnningList;
