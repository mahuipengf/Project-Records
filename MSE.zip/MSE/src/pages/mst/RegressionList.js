import React, { useEffect } from 'react';
import AppLayout from 'containers/AppLayout';
import { eventEmitter } from 'utils/loadWidget';
import WidgetPermission from 'containers/WidgetPermission';
import { WIDGET_MSE_MST } from 'constants';
import intl from '@ali/wind-intl';

const breadCrumbList = [
  {
    title: intl('mse.msc.menu.micro_regress'),
  },
];
const REGION_ID = window.regionId;
const ServiceRegressionList = (props) => {
  const { history, message } = props;
  const widgetProps = {
    component: 'TestCaseList',
    defaultValue: {
      regionId: REGION_ID,
    },
  };

  const goToTestCaseEdit = (payload) => {
    console.log("goToTestCaseEdit-setlist payload=" + JSON.stringify(payload));
    let caseId = -1;
    if (payload != null && payload != {}) {
      caseId = payload.CaseId;
    }

    if (caseId == -1 || caseId == undefined) {
      history.push({
        pathname: '/msc/services/regressionEdit',
        search: ``,
      });
    } else {
      history.push({
        pathname: '/msc/services/regressionEdit',
        search: `?id=${caseId}`,
      });
    }
  };

  //跳转到创建好的压测场景
  const handleGoToperformancePage = (payload) => {
    console.log('ready to goto handleGoToperformancePage');
    let scenarioId = payload.ScenarioId;
    const { history } = props;
    history.push({
      pathname: '/msc/services/stress/info',
      search: `?scenarioId=${scenarioId}`,

    });
  };

  const goToIntelligentFlowList = (payload) => {
    console.log('goToIntelligentFlowList');
    history.push('/msc/services/flowbox');
  };

  useEffect(() => {
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-TestCasedit`, goToTestCaseEdit);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-IntelligentFlowList`, goToIntelligentFlowList);
    eventEmitter.on(`${WIDGET_MSE_MST.id}:go-to-PerformanceScenarioEdit`, handleGoToperformancePage);
    return () => {
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-TestCasedit`, goToTestCaseEdit);
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-IntelligentFlowList`, goToIntelligentFlowList);
      eventEmitter.off(`${WIDGET_MSE_MST.id}:go-to-PerformanceScenarioEdit`, handleGoToperformancePage);
    };
  }, []);

  // 下线公告
  const getMessage = () => {
    const item = {
      type: 'notice',
      text: intl.html('mse.msc.automated_regression.notice')
    };
    return [
      item
    ];
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      breadCrumbExpand={
        <div style={{ height: 16 }}>
          {/* 微服务引擎钉钉交流群：
          <img
            style={{ verticalAlign: 'middle', height: 24, marginTop: -4 }}
            src="https://img.alicdn.com/tfs/TB1xya8o.T1gK0jSZFhXXaAtVXa-32-32.png"
          />
          <span style={{ color: '#0070cc', marginRight: 8 }}> 31180380 </span> */}
          {intl('mse.overview.help_doc')}:<a target="_blank" href=" https://help.aliyun.com/document_detail/189651.html">{intl('mse.msc.spring_cloud_services')}</a>，<a target="_blank" href="https://help.aliyun.com/document_detail/189652.html">{intl('mse.msc.dubbo_service')}</a>
        </div>
      }
      title={intl('mse.msc.menu.micro_regress')}
      message={message ? [message] : getMessage()}
    >
      <WidgetPermission widget="mst" widgetProps={widgetProps} />
    </AppLayout>
    // <AppLayout
    //   breadCrumbList={breadCrumbList}
    //   title="自动化回归"
    // >
    //   <h4>功能正在开发中，敬请期待 ...</h4>
    //   <h2>功能介绍</h2>
    //   <h4>基于微服务契约信息快速编排被测服务、管理自动化测试用例。可视化用例编辑界面，丰富的预置检查点、内置变量，支持自定义变量、参数传递、持续自动化测试，帮助您高效管理、回归业务测试场景，帮助业务快速验证、快速交付。</h4>
    //   <h2>微服务测试交流群</h2>
    //   <h4>如果您在微服务引擎MSE使用微服务测试过程中有任何疑问，欢迎您使用钉钉扫描下方的二维码或搜索钉钉群号 31180380 加入钉钉群进行反馈。</h4>
    //   <img width='250' src='https://img.alicdn.com/tfs/TB1BBo117Y2gK0jSZFgXXc5OFXa-858-1034.png' />
    // </AppLayout>
  );
};

export default ServiceRegressionList;
