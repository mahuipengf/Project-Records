import React, { useEffect, useState } from 'react';
import AppLayout from 'containers/AppLayout';
import { SeataWidget, eventEmitter } from 'utils/loadWidget';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const breadCrumbList = [
  {
    title: intl('mse.seata.menu.monitor_center')
  },
];

const widgetProps = {
  component: 'MonitorCenter',
  searchValues: {
    regionId: window.regionId || 'cn-hangzhou',
  },
};

const MonitorCenter = () => {

  useEffect(() => {
  }, []);

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.seata.menu.monitor_center')}
      productName="seata"
    >
      <SeataWidget {...widgetProps} />
    </AppLayout>
  );
};

/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default MonitorCenter;
