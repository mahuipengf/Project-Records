import React, { useEffect, useState, useRef } from 'react';
import services from 'utils/services';
import AppLayout from 'containers/AppLayout';
import CommonLoading from '../../../components/common/CommonLoading';
import './index.less';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * 告警管理策略页面
 */
const Alarm = () => {
  const refLoading = useRef(null);
  const iframeRef = useRef(null);
  const [alarmUri, setAlarmUri] = useState();

  useEffect(() => {
    getGatewayAlarms();
    iframeRef.current.addEventListener('load', onLoad);
    iframeRef.current.addEventListener('error', onLoad);
    return () => {
      iframeRef.current.removeEventListener('load', onLoad);
      iframeRef.current.addEventListener('error', onLoad);
    };
  }, []);

  const onLoad = () => {
    refLoading && refLoading.current.closeLoading();
  };

  const getGatewayAlarms = async () => {
    refLoading && refLoading.current.openLoading();
    const res = await services.fetchSeataAlarms({
      customErrorHandle: (err, data, callback) => {
        refLoading && refLoading.current.closeLoading();
        callback();
      },
    });
    setAlarmUri(res);
    // refLoading && refLoading.current.closeLoading();
  };

  const breadCrumbList = [
    {
      title: intl('mse.seata.menu.alarm_policy'),
    },
  ];
  return (
    <AppLayout breadCrumbList={breadCrumbList} title="" isKeepCrumb={false}>
      <div className="alarm-loading">
        <CommonLoading ref={refLoading}>
          <iframe
            src={alarmUri}
            ref={iframeRef}
            style={{ width: '100%', border: 'none', height: 'calc(100% + 16px)', marginTop: -16 }}
          />
        </CommonLoading>
      </div>
    </AppLayout>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default Alarm;
