import React, { useEffect, useState } from 'react';
import AppLayout from 'containers/AppLayout';
import intl from '@ali/wind-intl';
import { SeataWidget, eventEmitter } from 'utils/loadWidget';
import { WIDGET_EDAS_SEATA } from 'constants';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
const breadCrumbList = [
  {
    title: intl('mse.seata.menu.instance.list')
  },
];

const widgetProps = {
  component: 'InstanceList',
  searchValues: {
    regionId: window.regionId || 'cn-hangzhou',
  },
};

const InstanceList = (props) => {
  const { history } = props;

  useEffect(() => {
    eventEmitter.on(`${WIDGET_EDAS_SEATA.id}:go-to-InstanceInfo`, goToInstanceInfo);
    return () => {
      eventEmitter.off(`${WIDGET_EDAS_SEATA.id}:go-to-InstanceInfo`, goToInstanceInfo);
    };
  }, []);

  const goToInstanceInfo = (payload) => {
    const { SeataServerUniqueId='', Name } = payload;
    history.push({
      pathname: '/seata/instanceDetail',
      search: `?instanceId=${encodeURIComponent(SeataServerUniqueId)}`,
    });
  };

  return (
    <AppLayout
      breadCrumbList={breadCrumbList}
      title={intl('mse.seata.menu.instance.list')}
      productName="seata"
      message={
        [{
          type: 'notice',
          text: '分布式事务服务停止新建实例，并计划于2022年7月25日结束公测，届时已建实例将无法使用。该功能暂不进行商业化。',
        }]
      }
    >
      <SeataWidget {...widgetProps} />
    </AppLayout>
  );
};

/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default InstanceList;
