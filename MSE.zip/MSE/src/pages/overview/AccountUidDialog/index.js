import React from 'react';
import copy from 'copy-to-clipboard';
import styles from './index.css';
import { Button, Dialog, Message } from '@alicloud/console-components';
import intl from '@ali/wind-intl';

const AccountUidDialog = props => {
  const { onClose } = props;
  const accountUid = window.ALIYUN_CONSOLE_CONFIG?.MAIN_ACCOUNT_PK || '';

  // 复制license
  function copyCodeToClipboard() {
    copy(accountUid);
    onClose('false');
    Message.success(intl('mse.common.copy_success'));
  }

  // 渲染footer
  const footer = (
    <Button
      type={'primary'}
      onClick={copyCodeToClipboard}
      disabled={!accountUid}
    >
      {intl('MSE.CopyPrimaryAccountUID')}
    </Button>
  );

  return (
    <Dialog
      {...props}
      title={intl('MSE.ViewPrimaryAccountUID')}
      style={{ width: '400px' }}
      footer={footer}
    >
      <div>{intl('PrimaryAccountUID')} &nbsp;:&nbsp;
        <span
          id="licenseVal"
          className={styles.accountUid}
        >
          {accountUid}
        </span>
      </div>
    </Dialog>
  );
};

export default AccountUidDialog;
