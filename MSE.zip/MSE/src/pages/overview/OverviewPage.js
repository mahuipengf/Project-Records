import React, { useEffect, useState, Fragment } from 'react';
import { Breadcrumb, Button, Icon, Slider, Step, Tab, Search, Loading } from '@ali/wind';
import { isEmpty, Table } from '@ali/cn-design';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import { uniqueId, isArray, map, isObject, get, cloneDeep } from 'lodash';
import { Wcount } from '@alife/aisc-widgets';
import intl from '@ali/wind-intl';
import services from 'utils/services';
import { forApp } from '@alicloud/console-base-messenger';
import { REGION_LIST } from './contants';
import nacossvg from '../../assets/nacos.svg';
import dubbosvg from '../../assets/dubbo.svg';
import springcloudsvg from '../../assets/springcloud.svg';
import seatasvg from '../../assets/seata.svg';
import zookeepersvg from '../../assets/zookeeper.svg';
import dingdingsvg from '../../assets/ding_logo.svg';
import messagesvg from '../../assets/icon_info.svg';
import opensergosvg from '../../assets/opensergo.svg';
import envoysvg from '../../assets/envoy.svg';
import higresssvg from '../../assets/higress.svg';
import sentinelpng from '../../assets/sentinel.png';
import PreEnvSelector from 'components/PreEnvSelector';
import { IS_PRE_OR_LOCAL, UID } from 'constants';
import './index.less';
import AccountUidDialog from './AccountUidDialog';
import { timeFmtC } from 'utils/time';
import { formatUpdateDate } from 'utils';

const aliyun_lang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';

const { Item: BreadcrumbItem } = Breadcrumb;

const breadCrumbList = [
  {
    title: intl('mse.title'),
  },
  {
    title: intl('mse.menu.guide'),
  },
];
const REGION_ID = window.regionId;
const LAND = window.ALIYUN_CONSOLE_CONFIG.LANG;

const OverviewPage = (props) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [activeKey, setActiveKey] = useState('resourceInstance');
  const [searchInstanceValue, setSearchInstanceValue] = useState('');
  const [searchAppValue, setSearchAppValue] = useState('');
  const [messageIndex, setMessageIndex] = useState(1);
  const [totalLoading, setTotalLoading] = useState(false);
  const [resourceLoading, setResourceLoading] = useState(false);
  const [messageLoading, setMessageLoading] = useState(false);
  const [newsLoading, setNewsLoading] = useState(false);
  const [practiceLoading, setPracticeLoading] = useState(false);
  const [errorRegionList, setErrorRegionList] = useState([]);
  const [originResourceList, setOriginResourceList] = useState([]);
  const [originAppList, setOriginAppList] = useState([]);
  const [resourceList, setResourceList] = useState([]);
  const [appList, setAppList] = useState([]);
  const [totalObj, setTotalObj] = useState({
    gateWayInstanceCount: 0,
    gateWayRouterCount: 0,
    gateWayServiceCount: 0,
    gateWayApiCount: 0,
    nacosInstanceCount: 0,
    seataInstanceCount: 0,
    zookeeperInstanceCount: 0,
    governanceAppCount: 0,
    governanceServiceCount: 0,
    governanceDubboCount: 0,
    governanceSpringCloudCount: 0,
    governanceIstioCount: 0,
    governanceVersion: -1,
  });
  const [isOpen, setIsOpen] = useState(-1);
  const [accountUidVisible, setAccountUidVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      setMessageIndex((pre) => pre + 1);
    }, 100);
  }, []);

  useEffect(() => {
    if (isArray(REGION_LIST) && REGION_LIST.length) {
      getPageData();
    }
  }, []);

  const getPageData = async () => {
    setTotalLoading(true);
    setResourceLoading(true);
    let curData = REGION_LIST.map((item) => {
      return {
        regionName: aliyun_lang === 'en' ? item.EnName : item.CnName,
        regionId: item.Name,
      };
    });
    let requestErrorRegion = [];
    let requestResourceRegion = [];
    let requestAppRegion = [];
    let requestGateWayInstanceCount = 0;
    let requestGateWayRouterCount = 0;
    let requestGateWayServiceCount = 0;
    let requestGateWayApiCount = 0;
    let requestNacosInstanceCount = 0;
    let requestSeataInstanceCount = 0;
    let requestZookeeperInstanceCount = 0;
    let requestGovernanceAppCount = 0;
    let requestGovernanceServiceCount = 0;
    let requestGovernanceDubboCount = 0;
    let requestGovernanceSpringCloudCount = 0;
    let requestGovernanceIstioCount = 0;
    let requestGovernanceVersion = -1;
    let curIsOpen = -1;
    let requestGovernanceFreeVersion = -1;
    let requestGovernanceFreeOpen = 0;
    const microgwResourceCount = {}; //注册配置中心地区实例个数列表
    const configResourceCount = {}; ///网关地区实例个数列表
    // 请求接口、拼接data数据
    await Promise.all(
      map(curData, async (item) => {
        const res = await services.QueryMseHomeDetail({
          params: { RegionId: item.regionId, DynamicRegion: true },
          customErrorHandle: (err, data, callback) => {
            requestErrorRegion.push({ ...item });
          },
        });
        if (isObject(res) && !isEmpty(res)) {
          let {
            DncsTotalInfo = {},
            GatewayTotalInfo = {},
            GovernanceTotalInfo = {},
            NacosTotalInfo = {},
            SeataTotalInfo = {},
            ZookeeperTotalInfo = {},
          } = res;
          let configNum =
            NacosTotalInfo.InstanceCount +
            ZookeeperTotalInfo.InstanceCount +
            DncsTotalInfo.InstanceCount;
          let microgwNum = GatewayTotalInfo.InstanceCount;
          // window.CONFIG_RESOURCE_COUNT[item.regionId] = configNum;
          // window.MICROGW_RESOURCE_COUNT[item.regionId] = microgwNum;
          configResourceCount[item.regionId] = configNum;
          microgwResourceCount[item.regionId] = microgwNum;
          if (
            typeof GatewayTotalInfo.InstanceCount === 'number' &&
            GatewayTotalInfo.InstanceCount
          ) {
            requestGateWayInstanceCount += GatewayTotalInfo.InstanceCount;
            requestGateWayRouterCount += GatewayTotalInfo.RouterCount;
            requestGateWayServiceCount += GatewayTotalInfo.ServiceCount;
            requestGateWayApiCount += GatewayTotalInfo.ApiCount;
            requestResourceRegion.push({ ...item, ...GatewayTotalInfo });
          }
          if (typeof NacosTotalInfo.InstanceCount === 'number' && NacosTotalInfo.InstanceCount) {
            requestNacosInstanceCount += NacosTotalInfo.InstanceCount;
            requestResourceRegion.push({ ...item, ...NacosTotalInfo });
          }
          if (typeof SeataTotalInfo.InstanceCount === 'number' && SeataTotalInfo.InstanceCount) {
            requestSeataInstanceCount += SeataTotalInfo.InstanceCount;
            requestResourceRegion.push({ ...item, ...SeataTotalInfo });
          }
          if (
            typeof ZookeeperTotalInfo.InstanceCount === 'number' &&
            ZookeeperTotalInfo.InstanceCount
          ) {
            requestZookeeperInstanceCount += ZookeeperTotalInfo.InstanceCount;
            requestResourceRegion.push({ ...item, ...ZookeeperTotalInfo });
          }
          if (curIsOpen === -1) {
            curIsOpen = GovernanceTotalInfo.Status;
          }
          if (requestGovernanceVersion === -1) {
            requestGovernanceVersion = GovernanceTotalInfo.Version;
          }
          // 试用版
          if (requestGovernanceFreeVersion === -1) {
            requestGovernanceFreeVersion = GovernanceTotalInfo.FreeVersion || 0;
          }
          if (requestGovernanceFreeOpen === 0) {
            requestGovernanceFreeOpen = GovernanceTotalInfo.FreeOpen || 0; // 1665302176417
          }
          if (typeof GovernanceTotalInfo.AppCount === 'number' && GovernanceTotalInfo.AppCount) {
            const [res1, res2] = await Promise.all([
              services.QuerySentinelRuleInfo({
                params: {
                  Namespace: 'default',
                  SourceType: 'MSE',
                  Source: 'edasmsc',
                  RegionId: item.regionId,
                  DynamicRegion: true,
                },
                customErrorHandle: (err, data, callback) => {},
              }),
              services.GetUserSummary({
                params: {
                  Namespace: 'default',
                  SourceType: 'MSE',
                  NameSpace: 'default',
                  Source: 'edasmsc',
                  RegionId: item.regionId,
                  DynamicRegion: true,
                },
                customErrorHandle: (err, data, callback) => {},
              }),
            ]);
            let allRulesCount = 0;
            if (isObject(res1) && !isEmpty(res1)) {
              allRulesCount = get(res1, 'AllRulesCount', 0);
            }
            let switchCount = 0;
            if (isObject(res2) && !isEmpty(res2)) {
              switchCount = get(res2, 'SwitchCount', 0);
            }
            requestGovernanceAppCount += GovernanceTotalInfo.AppCount;
            requestGovernanceServiceCount += GovernanceTotalInfo.ServiceCount;
            requestGovernanceDubboCount += GovernanceTotalInfo.DubboCount;
            requestGovernanceSpringCloudCount += GovernanceTotalInfo.SpringCloudCount;
            requestGovernanceIstioCount += GovernanceTotalInfo.IstioCount;
            requestAppRegion.push({
              ...item,
              ...GovernanceTotalInfo,
              SentinelRuleInfo: allRulesCount,
              SwitchCount: switchCount,
            });
          }
        }
      })
    );
    // 请求报错的region列表
    setErrorRegionList(requestErrorRegion);
    // 资源概况列表数据
    setOriginAppList(requestAppRegion);
    setOriginResourceList(requestResourceRegion);
    setAppList(requestAppRegion);
    setResourceList(requestResourceRegion);
    // 服务治理是否开通
    setIsOpen(curIsOpen);
    // 总数相关
    let curTotalObj = {
      gateWayInstanceCount: requestGateWayInstanceCount,
      gateWayRouterCount: requestGateWayRouterCount,
      gateWayServiceCount: requestGateWayServiceCount,
      gateWayApiCount: requestGateWayApiCount,
      nacosInstanceCount: requestNacosInstanceCount,
      seataInstanceCount: requestSeataInstanceCount,
      zookeeperInstanceCount: requestZookeeperInstanceCount,
      governanceAppCount: requestGovernanceAppCount,
      governanceServiceCount: requestGovernanceServiceCount,
      governanceDubboCount: requestGovernanceDubboCount,
      governanceSpringCloudCount: requestGovernanceSpringCloudCount,
      governanceIstioCount: requestGovernanceIstioCount,
      governanceVersion: requestGovernanceVersion,
      governanceFreeVersion: requestGovernanceFreeVersion,
      governanceFreeOpen: requestGovernanceFreeOpen,
    };
    setTotalObj(curTotalObj);
    setTotalLoading(false);
    setResourceLoading(false);
    //将注册中心与网关的地域实例数量保存在localStorage中
    localStorage.setItem('configResourceCount', JSON.stringify(configResourceCount));
    localStorage.setItem('microgwResourceCount', JSON.stringify(microgwResourceCount));
  };

  const breadCrumbClick = (link, bool) => {
    if (link && bool) {
      hashHistory.push(link);
    }
  };

  let AllSteps = [
    {
      title: intl('mse.overview.news.one.title'),
      href: intl('mse.overview.news.one.href'),
      time: formatUpdateDate(intl('mse.overview.news.one.time')),
    },
    {
      title: intl('mse.overview.news.two.title'),
      href: intl('mse.overview.news.two.href'),
      time: formatUpdateDate(intl('mse.overview.news.two.time')),
    },
    {
      title: intl('mse.overview.news.three.title'),
      href: intl('mse.overview.news.three.href'),
      time: formatUpdateDate(intl('mse.overview.news.two.time')),
    },
  ];

  // 打开、关闭查看主账号UID弹窗
  function handleAccountUidChange() {
    setAccountUidVisible(!accountUidVisible);
  }

  const steps = AllSteps.map((item, index) => (
    <Step.Item
      key={index}
      status={index === currentIndex ? 'process' : 'wait'}
      className={index === currentIndex ? 'active' : ''}
      title={
        <a
          style={{ color: index === currentIndex ? '#0064C8' : '#666666' }}
          href={aliyun_lang === 'zh' ? item.href : 'javascript:;'}
          target={aliyun_lang === 'zh' ? '_blank' : '_self'}
          onClick={() => handleChangeCurrent(index)}
        >
          {item.title}
        </a>
      }
      content={item.time}
      onClick={(v) => {
        handleChangeCurrent(v);
      }}
    />
  ));

  const handleChangeCurrent = (v) => {
    setCurrentIndex(v);
  };

  const handleChange = (key) => {
    setActiveKey(key);
  };

  const onSearchInstanceChange = async (v) => {
    await setSearchInstanceValue(v);
    // 过滤数据
    if (v) {
      let newList = cloneDeep(originResourceList);
      newList = newList.filter((item) => {
        let str = '';
        try {
          const {
            regionName = '',
            InstanceCount = '',
            InstanceType = '',
            WarnStatusCount = '',
            ErrorStatusCount = '',
            InfoStatusCount = '',
          } = item;
          str =
            regionName +
            InstanceCount +
            InstanceType +
            WarnStatusCount +
            ErrorStatusCount +
            InfoStatusCount;
        } catch (error) {}
        if (str.toLowerCase().indexOf(v.toLowerCase()) > -1) {
          return true;
        }
        return false;
      });
      setResourceList(newList);
    } else {
      setResourceList(originResourceList);
    }
  };

  const onSearchAppChange = async (v) => {
    await setSearchAppValue(v);
    // 过滤数据
    if (v) {
      let newList = cloneDeep(originAppList);
      newList = newList.filter((item) => {
        let str = '';
        try {
          const {
            regionName = '',
            InstanceCount = '',
            AppCount = '',
            ServiceCount = '',
            SwimmingLaneGroupCount = '',
            LosslessRulesCount = '',
            SentinelRuleInfo = '',
            SwitchCount = '',
          } = item;
          str =
            regionName +
            InstanceCount +
            AppCount +
            ServiceCount +
            SwimmingLaneGroupCount +
            LosslessRulesCount +
            SentinelRuleInfo +
            SwitchCount;
        } catch (error) {}
        if (str.toLowerCase().indexOf(v.toLowerCase()) > -1) {
          return true;
        }
        return false;
      });
      setAppList(newList);
    } else {
      setAppList(originAppList);
    }
  };

  const reloadPage = () => {
    window.location.reload();
  };

  const handleHashPushSeata = async (url) => {
    // 分布式事务创建跳转：默认北京地区分布式事务列表页吧。
    if (!IS_PRE_OR_LOCAL && REGION_ID !== 'cn-beijing') {
      forApp.setRegionId('cn-beijing');
      hashHistory.push(url);
      reloadPage();
    } else {
      hashHistory.push(url);
    }
  };

  const handleInstanceCount = async (record = {}) => {
    const { InstanceType } = record;
    if (InstanceType === 'Nacos' || InstanceType === 'Zookeeper' || InstanceType === 'ZooKeeper') {
      if (record.regionId && record.regionId !== REGION_ID) {
        forApp.setRegionId(record.regionId);
        hashHistory.push('/InstanceList');
        reloadPage();
      } else {
        hashHistory.push('/InstanceList');
      }
    }
    if (InstanceType === 'Seata') {
      if (record.regionId && record.regionId !== REGION_ID) {
        forApp.setRegionId(record.regionId);
        hashHistory.push('/seata/instanceList');
        reloadPage();
      } else {
        hashHistory.push('/seata/instanceList');
      }
    }
    // 后端直接返回的中文 云原生网关
    if (InstanceType === 'Gateway' || InstanceType === '云原生网关') {
      if (record.regionId && record.regionId !== REGION_ID) {
        forApp.setRegionId(record.regionId);
        hashHistory.push('/microgw');
        reloadPage();
      } else {
        hashHistory.push('/microgw');
      }
    }
  };

  const handleAppCount = async (record = {}) => {
    const { url = '' } = record;
    if (url) {
      if (record.regionId && record.regionId !== REGION_ID) {
        forApp.setRegionId(record.regionId);
        hashHistory.push(url);
        reloadPage();
      } else {
        hashHistory.push(url);
      }
    }
  };

  const columnsInstance = [
    {
      key: 'regionName',
      title: intl('mse.overview.column.region'),
      dataIndex: 'regionName',
    },
    {
      key: 'InstanceType',
      title: intl('mse.overview.column.InstanceType'),
      dataIndex: 'InstanceType',
    },
    {
      key: 'InstanceCount',
      title: intl('mse.overview.column.InstanceCount'),
      dataIndex: 'InstanceCount',
      cell: (v, index, record) => {
        return (
          <Button
            type="primary"
            text
            onClick={() => {
              window.CN_TRACKER.send({
                name: record.regionId,
                type: 'overview-list-instance',
              });
              handleInstanceCount(record);
            }}
          >
            {v}
          </Button>
        );
      },
    },
    {
      key: 'regionName',
      title: intl('mse.overview.column.ClusterStatus'),
      dataIndex: 'regionName',
      cell: (v, index, record) => {
        return (
          <div className="status_container">
            <If condition={record.InfoStatusCount > 0}>
              <span className="status status_running">{record.InfoStatusCount}</span>
            </If>
            <If condition={record.WarnStatusCount > 0}>
              <span className="status status_stoped">{record.WarnStatusCount}</span>
            </If>
            <If condition={record.ErrorStatusCount > 0}>
              <span className="status status_failed">{record.ErrorStatusCount}</span>
            </If>
          </div>
        );
      },
    },
  ];

  const columnsApp = [
    {
      key: 'regionName',
      title: intl('mse.overview.column.region'),
      dataIndex: 'regionName',
      width: '100px',
    },
    {
      key: 'AppCount',
      title: intl('mse.overview.column.AppCount'),
      dataIndex: 'AppCount',
      width: '80px',
      cell: (v, index, record) => {
        return (
          <Button
            type="primary"
            text
            onClick={() => {
              window.CN_TRACKER.send({
                name: `${record.regionId}-appcount`,
                type: 'overview-list-service',
              });
              handleAppCount({ ...record, url: '/msc/app' });
            }}
          >
            {v}
          </Button>
        );
      },
    },
    {
      key: 'ServiceCount',
      title: intl('mse.overview.column.ServiceCount'),
      dataIndex: 'ServiceCount',
      width: '80px',
      cell: (v, index, record) => {
        return (
          <Button
            type="primary"
            text
            onClick={() => {
              window.CN_TRACKER.send({
                name: `${record.regionId}-servicecount`,
                type: 'overview-list-service',
              });
              handleAppCount({ ...record, url: '/msc/service' });
            }}
          >
            {v}
          </Button>
        );
      },
    },
    {
      key: 'InstanceCount',
      title: intl('mse.overview.column.app_InstanceCount'),
      dataIndex: 'InstanceCount',
      width: '100px',
      cell: (v, index, record) => {
        return (
          <Button
            type="primary"
            text
            onClick={() => {
              window.CN_TRACKER.send({
                name: `${record.regionId}-instancecount`,
                type: 'overview-list-service',
              });
              handleAppCount({ ...record, url: '/msc/app' });
            }}
          >
            {v}
          </Button>
        );
      },
    },
    {
      key: 'SwimmingLaneGroupCount',
      title: intl('mse.overview.column.SwimmingLaneGroupCount'),
      dataIndex: 'SwimmingLaneGroupCount',
      width: '100px',
      cell: (v, index, record) => {
        return (
          <Button
            type="primary"
            text
            onClick={() => {
              window.CN_TRACKER.send({
                name: `${record.regionId}-swimminglanggroupcount`,
                type: 'overview-list-service',
              });
              handleAppCount({ ...record, url: '/msc/grayscale' });
            }}
          >
            {v}
          </Button>
        );
      },
    },
    {
      key: 'LosslessRulesCount',
      title: intl('mse.overview.column.LosslessRulesCount'),
      dataIndex: 'LosslessRulesCount',
      width: '120px',
      cell: (v, index, record) => {
        return (
          <Button
            type="primary"
            text
            onClick={() => {
              window.CN_TRACKER.send({
                name: `${record.regionId}-losslessrulescount`,
                type: 'overview-list-service',
              });
              handleAppCount({ ...record, url: '/msc/lossless' });
            }}
          >
            {v}
          </Button>
        );
      },
    },
    {
      key: 'SentinelRuleInfo',
      title: intl('mse.overview.column.SentinelRuleTotal'),
      dataIndex: 'SentinelRuleInfo',
      width: '120px',
      cell: (v, index, record) => {
        return (
          <Button
            type="primary"
            text
            onClick={() => {
              window.CN_TRACKER.send({
                name: `${record.regionId}-sentinelruleinfo`,
                type: 'overview-list-service',
              });
              handleAppCount({ ...record, url: '/msc/appList' });
            }}
          >
            {v}
          </Button>
        );
      },
    },
    {
      key: 'SwitchCount',
      title: intl('mse.overview.column.SwitchCount'),
      dataIndex: 'SwitchCount',
      width: '100px',
    },
  ];

  const handleOpenUrl = (url, newTab) => {
    if (url) {
      if (newTab === 'no') {
        // help文档链接 不打开新页面
        let aLink = document.createElement('a');
        aLink.href = url;
        aLink.target = '_blank';
        document.body.appendChild(aLink);
        aLink.click();
        setTimeout(() => {
          document.body.removeChild(aLink);
        }, 1500);
      } else {
        window.open(url, '_blank');
      }
    }
  };

  useEffect(() => {
    function refreshMessage() {
      let collapsed = window.sessionStorage.getItem('overviewCollapsed');
      setTimeout(() => {
        setMessageIndex(new Date().valueOf());
      }, 600);
    }
    window.addEventListener('storage', refreshMessage);
    return () => {
      window.removeEventListener('storage', refreshMessage);
    };
  }, []);

  const getVersion = () => {
    if (isOpen !== 1 && isOpen !== -1) {
      const CountDown =
        new Date().getTime() - Number(totalObj.governanceFreeOpen) <= 30 * 24 * 60 * 60 * 1000; // 试用版是否超过15天
      if (totalObj.governanceFreeVersion === 1 && aliyunSite === 'CN') {
        // 国内开通试用版
        return (
          <span style={{ position: 'absolute', top: '0px', left: '0px' }}>
            <img
              style={{ position: 'relative', zIndex: 2 }}
              src={
                LAND === 'zh'
                  ? 'https://img.alicdn.com/imgextra/i4/O1CN01on9HX81IMcvDK1bIz_!!6000000000879-55-tps-109-35.svg'
                  : 'https://img.alicdn.com/imgextra/i4/O1CN01ICO3yq1hYruMZVGwV_!!6000000004290-55-tps-140-35.svg'
              }
            />
          </span>
        );
      }
      if (totalObj.governanceVersion === 1) {
        return (
          <span style={{ position: 'absolute', top: '0px', left: '0px' }}>
            <img
              style={{ position: 'relative', zIndex: 2 }}
              src={
                LAND === 'zh'
                  ? 'https://img.alicdn.com/imgextra/i1/O1CN01bIj3Uj1I5gEjBlvdD_!!6000000000842-55-tps-109-35.svg'
                  : 'https://img.alicdn.com/imgextra/i4/O1CN01enHaZH1dihwDYF0n5_!!6000000003770-55-tps-169-35.svg'
              }
            />
          </span>
        );
      } else if (totalObj.governanceVersion === 2) {
        return (
          <span style={{ position: 'absolute', top: '0px', left: '0px' }}>
            <img
              style={{ position: 'relative', zIndex: 2 }}
              src={
                LAND === 'zh'
                  ? 'https://img.alicdn.com/imgextra/i1/O1CN01nj5JQj1JGxbhU8F1W_!!6000000001002-55-tps-109-35.svg'
                  : 'https://img.alicdn.com/imgextra/i4/O1CN01oKWTs71aBKDkQX0ST_!!6000000003291-55-tps-159-35.svg'
              }
            />
          </span>
        );
      } else {
        return (
          <span style={{ position: 'absolute', top: '0px', left: '0px' }}>
            <img
              style={{ position: 'relative', zIndex: 2 }}
              src={
                LAND === 'zh'
                  ? 'https://img.alicdn.com/imgextra/i4/O1CN01UKWd9R1igU4dnv6Zk_!!6000000004442-55-tps-109-35.svg'
                  : 'https://img.alicdn.com/imgextra/i4/O1CN01dnZ84n1J48XI48rzS_!!6000000000974-55-tps-139-35.svg'
              }
            />
          </span>
        );
      }
    }
    return null;
  };
  const CountDown =
    new Date().getTime() - Number(totalObj.governanceFreeOpen) <= 15 * 24 * 60 * 60 * 1000;

  return (
    <div className="main_overview">
      <div className="header_flex">
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <Breadcrumb separator="/">
            <For each="item" index="index" of={breadCrumbList}>
              <BreadcrumbItem
                key={uniqueId()}
                link={
                  item.link && index !== breadCrumbList.length - 1 ? 'javascript:void(0);' : null
                }
                onClick={() => breadCrumbClick(item.link, index !== breadCrumbList.length - 1)}
                data-spm-click={
                  item.link
                    ? `gostr=/aliyun;locaid=breadcrumb-${item.link}`
                    : 'gostr=/aliyun;locaid=breadcrumb-/'
                }
              >
                {item.title}
              </BreadcrumbItem>
            </For>
          </Breadcrumb>
        </div>
        <div data-wrapper="overview-help">
          <a
            style={{ color: '#333', fontWeight: '500' }}
            // href="https://help.aliyun.com/product/123350.html"
            target="_blank"
            onClick={handleAccountUidChange}
          >
            {intl('MSE.ViewPrimaryAccountUID')}
          </a>
          <a
            style={{ marginLeft: '16px', color: '#333', fontWeight: '500' }}
            href="https://help.aliyun.com/document_detail/277001.html"
            target="_blank"
          >
            {intl('mse.overview.beginner_guide')}
          </a>
          <a
            style={{ marginLeft: '16px', color: '#333', fontWeight: '500' }}
            href="https://help.aliyun.com/product/123350.html"
            target="_blank"
          >
            {intl('mse.overview.help_doc')}
          </a>
        </div>
      </div>
      <div className="content">
        <div className="content_left">
          <div className="ovcard message" style={{ margin: '16px 0px' }}>
            <Loading style={{ width: '100%' }} visible={messageLoading}>
              <Slider
                key={`message${messageIndex}`}
                triggerType="click"
                arrows={false}
                style={{ width: '100%' }}
                autoplay
                autoplaySpeed={5000}
                infinite={false}
              >
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <img style={{ height: '20px', marginRight: '4px' }} src={messagesvg} />
                  {intl.html('mse.overview.ceiling.one')}
                </div>
              </Slider>
            </Loading>
          </div>
          <Loading visible={totalLoading} style={{ width: '100%' }} data-wrapper="overview-create">
            <div className="product_ovcard">
              <div className="left" style={{display:'flex', flexDirection:'column'}}>
                {/* 云原生网关 */}
                <div style={{ flex: 2, display: 'flex', justifyContent:'space-between' }}>
                  <If condition={get(totalObj, 'gateWayInstanceCount', 0) > 0}>
                    <div className="ovcard ovcard1" style={{ flex: 1 }}>
                      <div
                        className="ovcard1_line"
                        style={{ marginBottom: 16, display: 'flex', alignItems: 'center' }}
                      >
                        <p className="title" style={{ marginBottom: 0 }}>
                          {intl('mse.overview.title.gateway')}
                        </p>
                        <img style={{ height: 20, width: 90, marginLeft: 10 }} src={higresssvg} />
                      </div>
                      <div className="ovcard1_line">
                        <p className="title1">
                          <Wcount start={0} end={get(totalObj, 'gateWayInstanceCount', 0)} />
                        </p>
                        <span className="span1" style={{ marginRight: '46px' }}>
                          {intl('mse.overview.gateway.instance')}
                        </span>
                        <p className="title1">
                          <Wcount start={0} end={get(totalObj, 'gateWayRouterCount', 0)} />
                        </p>
                        <span className="span1" style={{ marginRight: '46px' }}>
                          {intl('mse.overview.gateway.router')}
                        </span>
                        <p className="title1">
                          <Wcount start={0} end={get(totalObj, 'gateWayServiceCount', 0)} />
                        </p>
                        <span className="span1">{intl('mse.overview.gateway.service')}</span>
                      </div>
                    </div>
                  </If>
                  <If condition={get(totalObj, 'gateWayInstanceCount', 0) <= 0}>
                    <div className="ovcard gatewaybg">
                      <p className="title" style={{ marginBottom: '0px' }}>
                        {intl('mse.overview.title.gateway')}
                      </p>
                      <p style={{ width: '60%', margin: '8px 0px' }} className="color_gray">
                        {intl('mse.overview.gateway.desc')}
                        <a
                          href="https://help.aliyun.com/document_detail/250954.html"
                          target="_blank"
                          style={{ marginLeft: 4 }}
                        >
                          {intl('mse.overview.help_doc')}
                          <Icon type="external-link-alt" size="xs" style={{ marginLeft: 4 }} />
                        </a>
                      </p>
                      <Button
                        type="primary"
                        size="small"
                        data-tracker="overview-create-gateway"
                        onClick={() =>
                          aliyunSite === 'CN'
                            ? window.open(
                                'https://common-buy.aliyun.com/?commodityCode=mse_ingresspre_public_cn',
                                '_blank'
                              )
                            : window.open(
                                'https://common-buy-intl.alibabacloud.com/?commodityCode=mse_ingresspre_public_intl',
                                '_blank'
                              )
                        }
                      >
                        {intl('mse.overview.gateway.create')}
                      </Button>
                    </div>
                  </If>
                  <div className="dianbox">
                    <div className="dian1 dian" />
                    <div className="dian2 dian" />
                    <div className="dian3 dian" />
                  </div>
                </div>
                <div className="dianbox1">
                  <div className="dian1 dian" />
                  <div className="dian2 dian" />
                  <div className="dian3 dian" />
                </div>
                {/* 应用框架 */}
                <div style={{ display: 'flex', flex: 1 }}>
                  <div
                    className="ovcard"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      flex: 1,
                    }}
                  >
                    <span
                      style={{
                        marginRight: '12px',
                        fontSize: '14px',
                        fontWeight: '500',
                        lineHeight: '22px',
                      }}
                    >
                      {intl('mse.overview.title.app_framework')}
                    </span>
                    <span style={{ fontSize: 14, fontWeight: '500', color: '#333' }}>
                      <Wcount start={0} end={get(totalObj, 'governanceDubboCount', 0)} />
                    </span>
                    <span style={{ color: '#555', marginLeft: 4, marginRight: 20 }}>
                      <img style={{ height: 12 }} src={dubbosvg} />
                    </span>
                    <span style={{ fontSize: 14, fontWeight: '500', color: '#333' }}>
                      <Wcount start={0} end={get(totalObj, 'governanceSpringCloudCount', 0)} />
                    </span>
                    <span style={{ color: '#555', marginLeft: 4, marginRight: 20 }}>
                      <img style={{ height: 12 }} src={springcloudsvg} />
                    </span>
                  </div>
                  <div className="dianbox">
                    <div className="dian1 dian" />
                    <div className="dian2 dian" />
                    <div className="dian3 dian" />
                  </div>
                </div>
                <div className="dianbox1">
                  <div className="dian1 dian" />
                  <div className="dian2 dian" />
                  <div className="dian3 dian" />
                </div>
                {/* 注册配置中心 分布式事务 */}
                <div style={{ display: 'flex', flexDirection: 'row',flex: 2 }}>
                  {/* 注册配置中心 */}
                  <If
                    condition={
                      get(totalObj, 'nacosInstanceCount', 0) +
                        get(totalObj, 'zookeeperInstanceCount', 0) >
                      0
                    }
                  >
                    <div className="ovcard ovcard1" style={{ flex: 1 }}>
                      <div className="ovcard1_line">
                        <p className="title">{intl('mse.overview.title.register_cfg_center')}</p>
                        <span style={{ color: '#999' }}>
                          （{intl('mse.overview.title.instance_count')}）
                        </span>
                      </div>
                      <div className="ovcard1_line">
                        <p className="title1">
                          <Wcount start={0} end={get(totalObj, 'nacosInstanceCount', 0)} />
                        </p>
                        <span className="span1">
                          <img style={{ height: 12, marginRight: 46 }} src={nacossvg} />
                        </span>
                        <p className="title1">
                          <Wcount start={0} end={get(totalObj, 'zookeeperInstanceCount', 0)} />
                        </p>
                        <span className="span1">
                          <img
                            style={{ height: 40, width: 26, marginBottom: -4 }}
                            src={zookeepersvg}
                          />
                        </span>
                      </div>
                    </div>
                  </If>
                  <If
                    condition={
                      get(totalObj, 'nacosInstanceCount', 0) +
                        get(totalObj, 'zookeeperInstanceCount', 0) <=
                      0
                    }
                  >
                    <div className="ovcard" style={{ flex: 1 }}>
                      <div className="ovcard_line">
                        <p className="title" style={{ marginBottom: '0px' }}>
                          {intl('mse.overview.title.register_cfg_center')}
                        </p>
                        <span style={{ color: '#999' }}>
                          （{intl('mse.overview.title.instance_count')}）
                        </span>
                      </div>
                      <p style={{ width: '100%', margin: '8px 0px' }} className="color_gray">
                        {intl('mse.overview.register_cfg_center.desc')}
                        <a
                          href="https://help.aliyun.com/document_detail/126736.html"
                          target="_blank"
                        >
                          {intl('mse.overview.help_doc')}
                          <Icon type="external-link-alt" size="xs" style={{ marginLeft: 4 }} />
                        </a>
                      </p>
                      <Button
                        type="primary"
                        size="small"
                        data-tracker="overview-create-instance"
                        onClick={() =>
                          aliyunSite === 'CN'
                            ? window.open(
                                'https://common-buy.aliyun.com/?commodityCode=mse_prepaid_public_cn&regionId=cn-hangzhou#/buy',
                                '_blank'
                              )
                            : window.open(
                                'https://common-buy-intl.alibabacloud.com/?commodityCode=mse_prepaid_public_intl',
                                '_blank'
                              )
                        }
                      >
                        {intl('mse.overview.instance.create')}
                      </Button>
                    </div>
                  </If>
                  <div className="dianbox">
                    <div className="dian1 dian" />
                    <div className="dian2 dian" />
                    <div className="dian3 dian" />
                  </div>
                </div>
              </div>
              {/* 服务治理 */}
              <If condition={get(totalObj, 'governanceAppCount', 0) > 0}>
                <div
                  className="right ovcard"
                  style={{
                    position: 'relative',
                    paddingTop: isOpen !== 1 && isOpen !== -1 ? '36px' : '16px',
                  }}
                >
                  {getVersion()}
                  <If condition={totalObj.governanceFreeVersion === 1 && aliyunSite === 'CN'}>
                    <div style={{ margin: '8px 0px 4px 0px' }}>
                      <span
                        style={{
                          fontFamily: 'PingFangSC',
                          fontSize: '14px',
                          fontWeight: 500,
                          lineHeight: '18px',
                          top: '6px',
                        }}
                      >
                        {timeFmtC(Number(totalObj.governanceFreeOpen) + 30 * 24 * 60 * 60 * 1000)}
                        {intl('mse.common.expire')}
                      </span>
                    </div>
                  </If>
                  <div className="servicemng" style={{ paddingBottom : '70px'}}>
                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}
                    >
                      <p className="title" style={{ marginBottom: '0px' }}>
                        {intl('mse.overview.title.governance')}
                      </p>
                      <Actions>
                        <If condition={totalObj.governanceFreeVersion !== 1}>
                          <If
                            condition={
                              totalObj.governanceVersion !== 2 && totalObj.governanceVersion !== -1
                            }
                          >
                            <LinkButton
                              onClick={() =>
                                aliyunSite === 'CN'
                                  ? handleOpenUrl(
                                      `https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn&orderType=UPGRADE&instanceId=synthetic_post_${UID}`
                                    )
                                  : handleOpenUrl(
                                      `https://common-buy-intl.alibabacloud.com/?commodityCode=mse_basic_public_intl&orderType=UPGRADE&instanceId=synthetic_post_${UID}`
                                    )
                              }
                              // 国际站试用版   暂且不上
                            >
                              {intl('mse.overview.governance.upgrade')}
                            </LinkButton>
                          </If>
                          <LinkButton
                            data-tracker="overview-governance-renewal"
                            onClick={() =>
                              aliyunSite === 'CN'
                                ? window.open(
                                    'https://usercenter2.aliyun.com/finance/fund-management/recharge',
                                    '_blank'
                                  )
                                : window.open('https://usercenter2-intl.aliyun.com/renew', '_blank')
                            }
                          >
                            {intl('mse.overview.governance.renewal')}
                          </LinkButton>
                        </If>
                        <If condition={totalObj.governanceFreeVersion === 1 && aliyunSite === 'CN'}>
                          <LinkButton
                            data-tracker="overview-governance-after-open-trial-version&type=overview-create" // 开通正式版
                            onClick={() =>
                              aliyunSite === 'CN'
                                ? window.open(
                                    'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn',
                                    '_blank'
                                  )
                                : window.open(
                                    'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn',
                                    '_blank'
                                  )
                            }
                          >
                            {intl('mse.overview.governance.opened')}
                          </LinkButton>
                        </If>
                      </Actions>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'baseline', marginTop: '16px' }}>
                      <p
                        style={{
                          color: '#333',
                          fontWeight: '500',
                          lineHeight: '36px',
                          fontSize: '24px',
                        }}
                      >
                        <Wcount start={0} end={get(totalObj, 'governanceAppCount', 0)} />
                      </p>
                      <span style={{ color: '#999', marginLeft: '4px' }}>
                        {intl('mse.overview.governance.app')}
                      </span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'baseline', marginTop: '12px' }}>
                      <p
                        style={{
                          color: '#333',
                          fontWeight: '500',
                          lineHeight: '36px',
                          fontSize: '24px',
                        }}
                      >
                        <Wcount start={0} end={get(totalObj, 'governanceServiceCount', 0)} />
                      </p>
                      <span style={{ color: '#999', marginLeft: '4px' }}>
                        {intl('mse.overview.governance.service')}
                      </span>
                    </div>
                  </div>
                  <div style={{ position: 'absolute', left: '16px', bottom: '10px' }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', marginTop: '12px' }}>
                      <img src={opensergosvg} style={{ width: '120px' }} />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'baseline' }}>
                      <img src={sentinelpng} style={{ width: '120px', marginLeft: '-7px' }} />
                    </div>
                  </div>
                </div>
              </If>
              <If condition={get(totalObj, 'governanceAppCount', 0) <= 0}>
                <div
                  className="right ovcard"
                  style={{
                    position: 'relative',
                    paddingTop: isOpen !== 1 && isOpen !== -1 ? '36px' : '16px',
                  }}
                >
                  {getVersion()}
                  <If condition={totalObj.governanceFreeVersion === 1 && aliyunSite === 'CN'}>
                    <div style={{ margin: '8px 0px 4px 0px' }}>
                      <span
                        style={{
                          fontFamily: 'PingFangSC',
                          fontSize: '14px',
                          fontWeight: 500,
                          lineHeight: '18px',
                          top: '6px',
                        }}
                      >
                        {timeFmtC(Number(totalObj.governanceFreeOpen) + 30 * 24 * 60 * 60 * 1000)}
                        {intl('mse.common.expire')}
                      </span>
                    </div>
                  </If>
                  <div className="servicemng" style={{ marginBottom : '70px'}}>
                    <p className="title" style={{ marginBottom: '0px' }}>
                      {intl('mse.overview.title.governance')}
                    </p>
                    <p style={{ margin: '8px 0px 0px' }} className="color_gray">
                      {intl('mse.overview.governance.desc')}
                      <a href="https://help.aliyun.com/document_detail/170447.html" target="_blank">
                        {intl('mse.overview.help_doc')}
                        <Icon type="external-link-alt" size="xs" style={{ marginLeft: 4 }} />
                      </a>
                    </p>
                    <div className="tag_container" style={{ marginTop: '8px' }}>
                      <span className="alert alert_running">
                        {intl('mse.overview.governance.feature.one')}
                      </span>
                      <span className="alert alert_running">
                        {intl('mse.overview.governance.feature.two')}
                      </span>
                      <span className="alert alert_running">
                        {intl('mse.overview.governance.feature.three')}
                      </span>
                    </div>
                    {(isOpen === 1 || totalObj.governanceFreeVersion === 1) && (
                      <div style={{ display: 'flex' }}>
                        <Button
                          type="normal"
                          size="small"
                          style={{ display: 'block', marginTop: '16px' }}
                          data-tracker="overview-governance-open"
                          onClick={() =>
                            aliyunSite === 'CN'
                              ? window.open(
                                  'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn',
                                  '_blank'
                                )
                              : window.open(
                                  'https://common-buy-intl.alibabacloud.com/?commodityCode=mse_basic_public_intl',
                                  '_blank'
                                )
                          }
                        >
                          {intl('mse.overview.governance.opened')}
                        </Button>
                        {aliyunSite === 'CN' && totalObj.governanceFreeVersion === 0 && (
                          <Button
                            type="normal"
                            size="small"
                            style={{ display: 'block', marginTop: '16px', marginLeft: '16px' }}
                            data-tracker="overview-governance-trial-open&type=overview-create"
                            onClick={() =>
                              aliyunSite === 'CN'
                                ? window.open(
                                    'https://common-buy.aliyun.com/?commodityCode=mse_sergofree_public_cn',
                                    '_blank'
                                  )
                                : window.open(
                                    'https://common-buy.aliyun.com/?commodityCode=mse_sergofree_public_cn',
                                    '_blank'
                                  )
                            }
                          >
                            {intl('mse.common.free.trial')}
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                  <div style={{ position: 'absolute', left: '16px', bottom: '10px' }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', marginTop: '12px' }}>
                      <img src={opensergosvg} style={{ width: '120px' }} />
                    </div>
                    <div style={{ display: 'flex', alignItems: 'baseline' }}>
                      <img src={sentinelpng} style={{ width: '120px', marginLeft: '-7px' }} />
                    </div>
                  </div>
                </div>
              </If>
            </div>
          </Loading>
          <div className="ovcard m-t-16">
            <p className="title">{intl('mse.overview.title.resource_distribution')}</p>
            <Loading style={{ width: '100%', minHeight: '200px' }} visible={resourceLoading}>
              <Tab activeKey={activeKey} onChange={handleChange}>
                <Tab.Item
                  key="resourceInstance"
                  title={intl('mse.overview.title.resource_instance')}
                />
                <Tab.Item key="appService" title={intl('mse.overview.title.app_service')} />
              </Tab>
              {activeKey === 'resourceInstance' && (
                <div>
                  <Search
                    key="2"
                    shape="simple"
                    onChange={onSearchInstanceChange}
                    style={{ width: '100%', margin: '16px 0px 8px' }}
                    placeholder={intl('mse.overview.title.resource_instance.filter_tip')}
                  />
                  <Table
                    style={{ minHeight: '160px', width: '100%' }}
                    className="overview-table"
                    maxBodyHeight={380}
                    dataSource={resourceList}
                    fixedHeader
                    hasBorder={false}
                    columns={columnsInstance}
                    emptyContent={<span>{intl('mse.common.no_data')}</span>}
                  />
                </div>
              )}
              {activeKey === 'appService' && (
                <div>
                  <Search
                    key="2"
                    shape="simple"
                    onChange={onSearchAppChange}
                    style={{ width: '100%', margin: '16px 0px 8px' }}
                    placeholder={intl('mse.overview.title.app_service.filter_tip')}
                  />
                  <Table
                    style={{ minHeight: '160px', width: '100%' }}
                    className="overview-table"
                    maxBodyHeight={380}
                    dataSource={appList}
                    fixedHeader
                    hasBorder={false}
                    columns={columnsApp}
                    emptyContent={<span>{intl('mse.common.no_data')}</span>}
                  />
                </div>
              )}
            </Loading>
          </div>
        </div>
        <div className="content_right">
          <div className="ovcard quick_start m-t-16" data-wrapper="overview-start">
            <p className="title">{intl('mse.overview.title.quick_start')}</p>
            <div className="flex_between">
              <Button
                type="primary"
                data-tracker="overview-create-gateway"
                onClick={() =>
                  aliyunSite === 'CN'
                    ? window.open(
                        'https://common-buy.aliyun.com/?commodityCode=mse_ingresspre_public_cn',
                        '_blank'
                      )
                    : window.open(
                        'https://common-buy-intl.alibabacloud.com/?commodityCode=mse_ingresspre_public_intl',
                        '_blank'
                      )
                }
              >
                {intl('mse.overview.quick_start.create')}
              </Button>
              <Button
                data-tracker="overview-start-product"
                onClick={() =>
                  aliyun_lang === 'zh'
                    ? handleOpenUrl('https://help.aliyun.com/document_detail/126761.html', 'no')
                    : window.open(
                        'https://www.alibabacloud.com/help/en/microservices-engine/latest/what-is-mse',
                        '_blank'
                      )
                }
              >
                {intl('mse.overview.quick_start.product')}
              </Button>
            </div>
            <div className="flex_between m-t-8">
              <Button
                data-tracker="overview-start-start"
                onClick={() =>
                  aliyun_lang === 'zh'
                    ? handleOpenUrl('https://help.aliyun.com/document_detail/277001.html', 'no')
                    : window.open(
                        'https://www.alibabacloud.com/help/en/microservices-engine/latest/quickstart-1',
                        '_blank'
                      )
                }
              >
                {intl('mse.overview.quick_start.start')}
              </Button>
              <Button
                data-tracker="overview-start-free"
                onClick={() =>
                  (aliyun_lang === 'zh'
                  ? handleOpenUrl(
                    'https://developer.aliyun.com/adc/scenario/dcd7abe6f8334ec39eca415a5ddaa98d'
                  )
                  : window.open(
                      'https://www.alibabacloud.com/help/en/microservices-engine/latest/enable-full-link-phased-release-through-ingress-nginx-2',
                      '_blank'
                    ))
                }
              >
                {intl('mse.overview.quick_start.use_free')}
              </Button>
            </div>
            <div className="flex_between m-t-8">
              <Button
                data-tracker="overview-start-api"
                onClick={() =>
                  aliyun_lang === 'zh'
                    ? handleOpenUrl('https://help.aliyun.com/document_detail/393484.html', 'no')
                    : window.open(
                        'https://www.alibabacloud.com/help/en/microservices-engine/latest/api-reference',
                        '_blank'
                      )
                }
              >
                OpenAPI
              </Button>
              <Button
                data-tracker="overview-start-sdk"
                onClick={() =>
                  aliyun_lang === 'zh'
                    ? handleOpenUrl(
                        'https://next.api.aliyun.com/api-tools/sdk/mse?version=2019-05-31&language=java-tea'
                      )
                    : handleOpenUrl('https://next.api.alibabacloud.com/api-tools/sdk/mse?version=2019-05-31&language=java-tea&tab=primer-doc')
                }
              >
                {intl('mse.overview.quick_start.sdk')}
              </Button>
            </div>
          </div>
          <div className="ovcard news m-t-16" data-wrapper="overview-news">
            <div className="header_flex" style={{ alignItems: 'flex-start' }}>
              <p className="title">{intl('mse.overview.title.news')}</p>
              <div>
                <a
                  style={{ marginLeft: '16px' }}
                  href="https://help.aliyun.com/document_detail/196147.html"
                  target="_blank"
                >
                  {intl('mse.overview.more')}
                  <Icon type="external-link-alt" size="xs" style={{ marginLeft: 4 }} />
                </a>
              </div>
            </div>
            <Loading style={{ width: '100%', minHeight: '100px' }} visible={newsLoading}>
              <Step current={currentIndex} direction="vertical" shape="dot" animation={false}>
                {steps}
              </Step>
            </Loading>
          </div>
          <div className="ovcard product m-t-16" data-wrapper="overview-product">
            <div className="header_flex" style={{ alignItems: 'flex-start' }}>
              <p className="title">{intl('mse.overview.related.product')}</p>
            </div>
            <Loading style={{ width: '100%', minHeight: '60px' }} visible={practiceLoading}>
              <ul>
                <li>
                  <div
                    className="product"
                    onClick={() => {
                      window.CN_TRACKER.send({
                        name: 'overview-related',
                        type: 'overview',
                      });
                      aliyunSite === 'CN'
                        ? window.open(
                            'https://common-buy.aliyun.com/?spm=5176.8140086.J_5253785160.3.ce52be45kN0LkL&commodityCode=arms',
                            '_blank'
                          )
                        : window.open(
                            'https://common-buy-intl.alibabacloud.com/?commodityCode=arms_intl#/open',
                            '_blank'
                          );
                    }}
                  >
                    <div className="title">
                      <svg
                        t="1671536814328"
                        className="icon"
                        viewBox="0 0 1024 1024"
                        version="1.1"
                        xmlns="http://www.w3.org/2000/svg"
                        p-id="2494"
                        width="26"
                        height="26"
                      >
                        <path
                          d="M873.216 277.333a108.31 108.31 0 0 0-108.33 108.331c0 18.048 4.48 35.221 12.48 49.92l-176.534 174.55a62.805 62.805 0 0 0-31.424-8.022c-7.147 0-13.824 1.344-20.053 3.35l-71.126-97.409c0.662-3.349 0.662-6.698 0.662-10.026a64.213 64.213 0 0 0-64.192-64.214 64.405 64.405 0 0 0-64.427 64.214v1.109L247.296 599.211h-85.141a64.427 64.427 0 0 0-54.827-30.976 64.683 64.683 0 0 0-64.661 64.64 64.683 64.683 0 0 0 64.64 64.64 65.067 65.067 0 0 0 56.618-33.43h110.571l111.445-108.33c9.152 4.672 19.179 7.125 29.44 7.125 7.339 0 14.486-1.344 20.715-3.797l70.23 96.746a62.976 62.976 0 0 0-1.131 11.158 64.213 64.213 0 0 0 64.213 64.192 64.341 64.341 0 0 0 64.192-62.635l188.587-187.03a108.31 108.31 0 0 0 159.146-95.637 108.16 108.16 0 0 0-108.117-108.544z m1.557 154.475a46.144 46.144 0 0 1-45.909-45.91c-0.427-25.429 20.501-45.93 45.91-45.93 25.429 0 45.93 20.736 45.93 45.93a45.867 45.867 0 0 1-45.93 45.91z"
                          fill="#00C1DE"
                          p-id="2495"
                        />
                      </svg>
                      <span>{intl('mse.overview.related.product.arms')}</span>
                    </div>
                    <span>{intl('mse.overview.related.product.arms_tip')}</span>
                  </div>
                </li>
              </ul>
            </Loading>
          </div>
          <div className="ovcard practice m-t-16" data-wrapper="overview-best">
            <div className="header_flex" style={{ alignItems: 'flex-start' }}>
              <p className="title">
                <span>{intl('mse.overview.title.practice')}</span>
              </p>
              <div>
                <a
                  style={{ marginLeft: '16px' }}
                  href="https://help.aliyun.com/document_detail/294430.html"
                  target="_blank"
                >
                  {intl('mse.overview.more')}
                  <Icon type="external-link-alt" size="xs" style={{ marginLeft: 4 }} />
                </a>
              </div>
            </div>
            <Loading style={{ width: '100%', minHeight: '100px' }} visible={practiceLoading}>
              <ul>
                <li>
                  <a href="https://help.aliyun.com/document_detail/359851.html" target="_blank">
                    {intl('mse.overview.practice.one')}
                  </a>
                </li>
                <li>
                  <a href="https://help.aliyun.com/document_detail/375330.html" target="_blank">
                    {intl('mse.overview.practice.two')}
                  </a>
                </li>
                <li>
                  <a href="https://help.aliyun.com/document_detail/359858.html" target="_blank">
                    {intl('mse.overview.practice.eight')}
                  </a>
                </li>
                <li>
                  <a href="https://help.aliyun.com/document_detail/347790.html" target="_blank">
                    {intl('mse.overview.practice.three')}
                  </a>
                </li>
                <li>
                  <a href="https://help.aliyun.com/document_detail/409450.html" target="_blank">
                    {intl('mse.overview.practice.four')}
                  </a>
                </li>
                <li>
                  <a href="https://help.aliyun.com/document_detail/397319.html" target="_blank">
                    {intl('mse.overview.practice.five')}
                  </a>
                </li>
                <li>
                  <a href="https://help.aliyun.com/document_detail/338358.html" target="_blank">
                    {intl('mse.overview.practice.six')}
                  </a>
                </li>
                <li>
                  <a href="https://help.aliyun.com/document_detail/314237.html" target="_blank">
                    {intl('mse.overview.practice.seven')}
                  </a>
                </li>
              </ul>
            </Loading>
          </div>
        </div>
      </div>
      <If condition={IS_PRE_OR_LOCAL}>
        <PreEnvSelector />
      </If>
      {/* 查看主账号UID弹窗 */}
      {accountUidVisible && (
        <AccountUidDialog
          className={'dialogCustom'}
          visible={accountUidVisible}
          onClose={handleAccountUidChange}
        />
      )}
    </div>
  );
};

export default OverviewPage;
