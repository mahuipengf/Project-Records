import dva from 'dva';
import { createHashHistory } from 'history';
import { withProvider } from '@ali/wind-intl';
import './utils/globalLib';
import Router from './router';
import './styles/index.less';
import './utils/emitter';
import models from './models';
import './index.less';
import '@alife/aisc-widgets/build/index.css';
import './config/styles/index.less';


const app = dva({
  history: createHashHistory(),
  // onError(err) {
	// 	// 在这里进行错误处理
	// 	console.log(err);
	// },
});
// app.use(createLoading())
models.forEach(model => {
  app.model(model);
});
app.router(Router);
// const App = app.start();
const App = withProvider()(app.start());

export default App;
