import React from 'react';
import { render } from 'react-dom';
import cnTracker from '@ali/cn-tracker';
module.hot && module.hot.accept();
// import './utils/wind';
import './initializer';
import App from './app';
import './index.less';
import '@alicloud/console-components/dist/wind.css';


window.ALIYUN_CONSOLE_GLOBAL = window.ALIYUN_CONSOLE_GLOBAL || {};

cnTracker.init('mse', {
  enable: window.ALIYUN_CONSOLE_GLOBAL.environment === 'production', // window.ALIYUN_CONSOLE_GLOBAL.environment === 'production'
  xhrError: true,
  excludeMainUids: window.ALIYUN_CONSOLE_GLOBAL.excludeMainUids
});

if( localStorage && localStorage.getItem('MseSessionId') ) {
  const html = `<div id="mseMonitorUser" style="position: absolute; left: 30%; top: 67px; font-size: 14px; font-weight: bold; z-index: 1000;">
                  <span style="color: red;">正在模拟用户${localStorage.getItem('MseSessionId').split('_')[0]}视角，谨慎操作！禁止截图或录屏！</span>
                  <input type="button" id="mseMonitorUserBtn" value="退出用户视角" style="color: blue; margin-left: 25px;"/>			
                </div>`;

  $( document ).ready( function() {
    $('#root').append(html);
    $("#mseMonitorUserBtn").click(function(){
      localStorage.removeItem('MseSessionId');
      $('#mseMonitorUser').hide();
    });
  })
}


render(<App />, document.getElementById('root'));
