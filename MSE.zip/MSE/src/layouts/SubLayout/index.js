import React, { Suspense, useRef, useEffect, useState, memo, useMemo } from 'react';
import PropTypes from 'prop-types';
import Page from '@ali/wind-rc-page';
import { Message } from '@ali/wind';
import BreadLayout from '../../components/common/BreadLayout';
import { isEmpty } from 'lodash';
import { Icon } from '@ali/cn-design';
import { IS_IFRAME } from 'src/constants';
import './index.less';

import Nav from './Nav';
import NewNav from './NewNav';

const SubLayout = (props) => {
  const {
    breadCrumbList = [],
    breadCrumbExpand,
    title = '',
    children,
    message,
    items = [],
    navTag = '',
    pathname,
    isShowNamespace,
    disabled,
  } = props;

  const [offsetHeight, setoffSetHeight] = useState(0);
  const [navVisible, setNavVisible] = useState(true);

  const headerElment = useRef(null);

  useEffect(() => {
    setoffSetHeight(headerElment.current.offsetHeight);
  }, [pathname]);

  //数组中的路由在列表详情中不显示L2菜单
  useEffect(() => {
    const unvisibleList = [
      '/gateway/service/instance/detail',
      '/gateway/domain/detail',
      '/gateway/router/instance/detail',
      '/Instance/Config/Detail',
      '/Instance/Service/Detail',
      '/Instance/DataManager/ServiceDetail',
      '/gateway/security/authority/detail',
    ];
    setNavVisible(!unvisibleList.includes(pathname));
  }, [pathname]);

  return (
    <div style={{ position: 'relative', height: '100%' }}>
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          padding: '0 24px',
          background: '#fff',
          zIndex: 12,
          boxShadow: '0 4px 8px -5px rgba(0, 0, 0, 0.1)',
        }}
        ref={headerElment}
      >
        <If condition={!isEmpty(message)}>
          <div style={{ paddingTop: 8 }}>
            <For each="item" index="index" of={message}>
              <Message
                key="index"
                type={item.type}
                style={{ color: '#f68300', margin: '8px 0 8px' }}
              >
                {item.text}
              </Message>
            </For>
          </div>
        </If>
        <BreadLayout
          breadCrumbList={breadCrumbList}
          breadCrumbExpand={breadCrumbExpand}
          isShowNamespace={isShowNamespace}
          disabled={disabled}
        />
        <div className="mse_pageHeaderSub">
          <Page.Header title={title} childrenAlign="left" style={{ padding: 0, width: '100%' }} />
        </div>
      </div>
      <Page.Content
        style={{ height: '100%', paddingTop: offsetHeight, overflow: 'auto' }}
        className="console-nav"
      >
        {navVisible && (
          <div
            style={{
              width: 160,
              position: 'absolute',
              left: '20px',
              top: '105px',
              bottom: '40px',
              zIndex: '2',
            }}
          >
            <If condition={navTag !== 'app'}>
              <Nav items={items} />
            </If>
            <If condition={navTag === 'app'}>
              {useMemo(
                () => (
                  <NewNav items={items} />
                ),
                []
              )}
            </If>
          </div>
        )}
        <div style={{ width: '100%', position: 'relative', minHeight: '100%' }}>
          <div
            style={{
              marginLeft: navVisible ? '160px' : '0px',
              padding: navVisible ? '16px 0 16px 24px' : '16px 0',
            }}
          >
            <Suspense fallback="...">{children}</Suspense>
          </div>
        </div>
      </Page.Content>
    </div>
  );
};

export default SubLayout;
