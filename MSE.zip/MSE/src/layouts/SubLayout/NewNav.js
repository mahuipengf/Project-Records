import React, { useState, useEffect } from 'react';
import { Nav, Radio } from '@ali/cn-design';
import { map } from 'lodash';
import Page from '@ali/wind-rc-page';

let status = [];
const { Item, SubNav } = Nav;
const { Menu } = Page;
const NavBar = (props) => {
  const { items = [] } = props;
  const [openkeys, setOpenKeys] = useState(status);
  const pathname = hashHistory.location.pathname;

  const NavComponent = () => {
    return map(items, _t => {
      if (_t.items && _t.items.length > 0) {
        return (
          <SubNav
            label={_t.label}
            key={_t.key}
          >
            {
              map(_t.items, _d => {
                if (_d.items && _d.items.length > 0) {
                  return (
                    <SubNav
                      label={_d.label}
                      key={_d.key}
                    >
                      {
                        map(_d.items, _m => {
                          return <Item
                            onClick={(e) => {
                              goPushHistory(_m.to);
                            }}
                            key={_m.key}
                          >
                            {_m.label}
                          </Item>;
                        })
                      }
                    </SubNav>
                  );
                }
                return <Item
                  onClick={(e) => {
                    goPushHistory(_d.to);
                }}
                  key={_d.key}
                >
                  {_d.label}
                </Item>;
              })
            }
          </SubNav>
        );
      }
      // style={{ color: `${_t.key === pathname ? '#0064c8' : '#111'}`, fontWeight: `${_t.key === pathname ? '700' : 'none'}` }}
      return (
        <Item onClick={() => goPushHistory(_t.to)} key={_t.key}>{_t.label}</Item>
      );
    });
  };
  const goPushHistory = (route) => {
    hashHistory.push(route);
  };
  const callback = (key, extart) => {
    if (key) {
      status = key;
      setOpenKeys(key);
    }
    // if (key === pathname && !extart.open) {
    //   status = false;
    //   setChildStatus(false);
    // }
  };
  return (
      <Nav
        key="nav"
        style={{
        width: 160,
        paddingTop: 8,
        height: 'calc(100% + 40px)',
        boxShadow: 'none',
        borderTop: 'none',
        borderBottom: 'none',
        borderLeft: 'none',
        }}
        iconOnly={false}
        hasArrow
        hasTooltip={false}
        activeDirection="right"
        items={items}
        selectedKeys={pathname}
        defaultSelectedKeys={pathname}
        openKeys={openkeys} // ['/msc/app/info/test']
        onOpen={callback}
      >
        {NavComponent()}
        </Nav>
  );
};
export default NavBar;
