import React from 'react';
import RoutableMenu from '@ali/wind-rc-console-menu/RoutableMenu';

const Nav = ({ items, ...rest }) => (
  <RoutableMenu
    style={{ paddingTop: 8, height: 'calc(100% + 40px)' }}
    type="secondary"
    items={items}
    {...rest}
  />
);

export default Nav;
