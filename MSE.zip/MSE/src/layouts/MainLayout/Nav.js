import React, { useEffect, useState } from 'react';
import RoutableMenu from '@ali/wind-rc-console-menu/RoutableMenu';
import items from '../../menu';
import intl from '@ali/wind-intl';

const Nav = ({ ...rest }) => {
  return <RoutableMenu
    header={intl('mse.title')}
    items={items}
    data-spm="mse-menu"
    {...rest}
  />;
};

export default Nav;
