import React, { useState, useEffect } from 'react';
import AppLayout from '@ali/wind-rc-app-layout';

import Nav from './Nav';

const MainLayout = (props) => {
  const { children } = props;
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    fetchPostMessage();
    hashHistoryEvent();
    return () => {
      hashHistoryEvent();
    };
  }, []);

  const hashHistoryEvent = () => {
    hashHistory.listen((location) => {
      const path = location.pathname;
      if (path.indexOf('/Instance/') > -1 || path.indexOf('/gateway/') > -1 || path.indexOf('msc/app/info') > -1 || path.indexOf('msc/systemGuard') > -1 || path.indexOf('/msc/appList/info') > -1) {
        setCollapsed(true);
      } else {
        setCollapsed(false);
      }
    });
  };
  const fetchPostMessage = () => {
    window.addEventListener('message', (event) => {
      if (event.data.currentPathName) {
        const data = event.data.currentPathName || '';
        const judgeData = data.indexOf('/flowProtection/systemGuard/systemGuardSummary') > -1 || data.indexOf('/flowProtection/systemGuard/SystemGuardSummary') > -1 || data.indexOf('/flowProtection/systemGuard/systemGuardApiDetails') > -1 || data.indexOf('/flowProtection/systemGuard/systemHotSpotMonitor') > -1 || data.indexOf('/flowProtection/systemGuard/systemGuardMachineDetails') > -1 || data.indexOf('/flowProtection/systemGuard/setRules') > -1 || data.indexOf('/flowProtection/systemGuard/systemGuardWebSceneOriented') > -1 || data.indexOf('/flowProtection/systemGuard/systemGuardGeneral') > -1 || data.indexOf('/flowProtection/systemGuard/systemGuardClusterProtection') > -1 || data.indexOf('/flowProtection/systemGuard/systemGuardClusterDetails') > -1 || data.indexOf('/flowProtection/systemGuard/systemGuardAlarmRules') > -1 || data.indexOf('/flowProtection/systemGuard/systemGuardAlarmDetails') > -1 || data.indexOf('/flowProtection/systemGuard/systemServiceStress') > -1 || data.indexOf('/switch/app/switchlist') > -1 || data.indexOf('/switch/app/history') > -1 || data.indexOf('/switch/app/appadmin') > -1 || data.indexOf('flowProtection/systemGuardGw/systemGuardGwGeneral') > -1 || data.indexOf('flowProtection/systemGuardGw/systemGuardGwApiDetails') > -1 || data.indexOf('flowProtection/systemGuardGw/systemGuardGwMachineDetails') > -1 || data.indexOf('flowProtection/systemGuardGw/SystemGuardGwApi') > -1 || data.indexOf('flowProtection/systemGuardGw/systemGuardGwSetRules') > -1 || data.indexOf('flowProtection/systemGuardGw/systemGuardGwClusterProtection') > -1 || data.indexOf('/flowProtection/systemGuard/SystemGuardMachineDetails') > -1;
        if (judgeData) {
          setCollapsed(true);
        } else {
          setCollapsed(false);
        }
        // hashHistoryEvent();
      }
    });
  };

  useEffect(() => {
    window.sessionStorage.setItem('overviewCollapsed', collapsed);
    window.dispatchEvent(new Event('storage'));
  }, [collapsed]);

  return (
    <React.Fragment>
      <AppLayout
        navCollapsed={collapsed}
        onNavCollapseTriggerClick={prevCollapsed => {
          setCollapsed(!prevCollapsed);
        }}
        style={{ background: '#fff' }}
        nav={<Nav />}
      >
        {children}
      </AppLayout>
    </React.Fragment>
  );
};

export default MainLayout;

