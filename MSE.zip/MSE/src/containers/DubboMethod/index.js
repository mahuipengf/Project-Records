/**
 * dubbo 方法选择
 */
import React, { useEffect } from 'react';
import { Select } from '@ali/cn-design';
import { find, get, head, isEmpty, split } from 'lodash';

const DubboMethod = ({ onChange, value, fetchData, dataSource, hasDefault = true }) => {
  useEffect(() => {
    if (!fetchData) return;
    fetchData();
  }, []);

  useEffect(() => {
    if (!hasDefault) return;
    if (!value && !isEmpty(dataSource)) {
      const first = head(dataSource);
      if (!isEmpty(first)) {
        const method = get(first, 'methods[0]', {});
        onChange(`${first.value}:${method.value}`);
      }
    }
  }, [dataSource]);

  const handleChange = (val) => {
    onChange(val);
  };

  const handleChangeServiceName = (val) => {
    const ServiceNameItem = find(dataSource, { value: val });
    const firstItem = get(ServiceNameItem, 'methods[0]', {});
    handleChange(`${val}:${firstItem.value}`);
  };

  const [serviceName = '', version = '', group = '', name = '', parameterTypes = [], returnType = ''] = split(value, ':');
  const a = serviceName ? `${serviceName}:${version}:${group}` : undefined;
  const b = name ? `${name}:${parameterTypes}${returnType ? `:${returnType}` : ''}` : undefined; // 有些地方无returnTyppe，服务鉴权有returnType

  return (
    <React.Fragment>
      <Select
        showSearch
        style={{ width: 'calc(50% - 4px)', marginRight: 8 }}
        onChange={(val) => handleChangeServiceName(val)}
        dataSource={dataSource}
        value={a}
        followTrigger
      />
      <Select
        showSearch
        style={{ width: 'calc(50% - 4px)' }}
        onChange={(val) => handleChange(`${a}:${val}`)}
        dataSource={find(dataSource, { value: a })?.methods}
        value={b}
        followTrigger
      />
    </React.Fragment>
  );
};

export default DubboMethod;
