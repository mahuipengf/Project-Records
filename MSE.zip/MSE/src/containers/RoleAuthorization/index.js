import React, { useEffect, useState } from 'react';
import { Button, Loading, Message, Dialog, Step } from '@ali/wind';
import services from 'utils/services';
import { get } from 'lodash';
import './index.less';
import intl from '@ali/wind-intl';

const RoleAuthorization = () => {
  const [current, setCurrent] = useState(0);
  const [role, setRole] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    CheckRole();
  }, []);

  const CheckRole = async () => {
    setLoading(true);
    const { HasServiceLinkRole } = await services.CheckSlrRole();
    if (HasServiceLinkRole) {
      window.hasRole = true;
    } else {
      window.hasRole = false;
    }
    setLoading(false);

    if (!HasServiceLinkRole && current !== 0) {
      setCurrent(0);
      return;
    }
    if (HasServiceLinkRole) {
      setCurrent(1);
    }
  };

  const handleOpenCreateSlrRole = () => {
    Dialog.confirm({
      title: intl('mse.common.authorization'),
      content: intl.html('mse.common.confirm.authorization.role'),
      onOk: () => CreateSlrRole(),
      okProps: { children: intl('mse.common.ok') },
      cancelProps: { children: intl('mse.common.cancel') },
    });
  };

  const CreateSlrRole = async () => {
    const res = await services.CreateSlrRole({
      customErrorHandle: (err, response, callback) => {
        const code = get(err, 'code');
        if (code === 441) {
          Dialog.alert({
            title: intl('mse.service.association.role'),
            content: (
              <div>
                <p>{intl('mse.service.association.role.message.one')}</p>
                <p>{intl('mse.service.association.role.message.two')}</p>
                <p>{intl('mse.service.association.role.message.three')}</p>
                <p>{intl('mse.service.association.role.message.four')}</p>
                <p>{intl('mse.service.association.role.message.five')}</p>
              </div>
            ),
          });
          throw new Error();
        } else {
          callback();
        }
      },
    });
    Message.success(intl('mse.common.authorization.success'));
    setRole(true);
    window.hasRole = true;
  };

  const handleChangeStep = (newStep) => {
    setCurrent(newStep);
  };

  const steps = [
    {
      title: intl('mse.create.service.association.role'),
      comp: (
        <React.Fragment>
          <p style={{ marginTop: 24 }}>
            {role
              ? intl('mse.created.service.association.role')
              : intl('mse.create.service.association.role_no')}
          </p>
          <p>{intl('mse.role.authorization.message1')}</p>
          <p>{intl('mse.role.authorization.message2')}</p>
          <p>{intl('mse.role.authorization.message3')}</p>
          <p>{intl.html('mse.role.authorization.message4')}</p>
          <Button
            onClick={handleOpenCreateSlrRole}
            type="primary"
            style={{ marginTop: 16 }}
            disabled={role}
          >
            {role ? intl('mse.common.authorized') : intl('mse.common.authorize.now')}
          </Button>
          <div style={{ textAlign: 'right', marginTop: 16 }}>
            <Button
              type="primary"
              onClick={() => handleChangeStep(1)}
              style={{ marginRight: 8 }}
              disabled={!role}
            >
              {intl('mse.common.step')}
            </Button>
            <Button onClick={CheckRole}>{intl('mse.common.refresh')}</Button>
          </div>
        </React.Fragment>
      ),
    },
    {
      title: intl('mse.common.complete'),
      comp: (
        <React.Fragment>
          <p style={{ marginTop: 24 }}>{intl('mse.role.authorization.success.open')}</p>
          <div style={{ textAlign: 'right', marginTop: 16 }}>
            <Button type="primary" onClick={() => hashHistory.push('/msc/home')}>
              {intl('mse.role.authorization.experience.now.service.engine')}
            </Button>
          </div>
        </React.Fragment>
      ),
    },
  ];

  return (
    <Loading visible={loading} style={{ width: '100%' }}>
      <div className="role-authorization">
        <div className="background" />
        <div className="content">
          <div style={{ paddingBottom: 16 }}>
            <h4 style={{ fontSize: 28, margin: '16px 0' }}>{intl('mse.register.service.engine.message.one')}</h4>
            <p>{intl('mse.register.service.engine.message.two')}</p>
            <p>{intl('mse.register.service.engine.message.three')}</p>
          </div>
          <Step current={current} shape="circle" size="small" >
            <For each="item" index="index" of={steps}>
              <Step.Item
                key={index}
                title={item.title}
              />
            </For>
          </Step>
          {steps[current].comp}
        </div>
      </div>
    </Loading>
  );
};

export default RoleAuthorization;
