import React, { useMemo, useState } from 'react';
import { get } from 'lodash';
import { Message, Card, Button } from '@ali/cn-design';
import { useStateStore } from '../../store';
import intl from '@ali/wind-intl';
import Cookie from 'js-cookie';
import styles from './index.module.less';
import ImageEnlarge from 'components/ImageEnlarge';

const aliyunLang = Cookie.get('aliyun_lang') || 'zh';
const aliyunSite = window.aliwareGetCookieByKeyName('aliyun_site') || 'CN';
const RoleAuth = (WrapComp, component) => (props) => {
  const state = useStateStore();
  const Version = get(state, 'MscAccount.Version', 0);
  const UserId = get(state, 'MscAccount.UserId');
  let upgradeHref = `https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn&orderType=UPGRADE&instanceId=synthetic_post_${UserId}`;
  if (aliyunSite === 'INTL') {
    upgradeHref = 'https://common-buy-intl.alibabacloud.com/?commodityCode=mse_basic_public_intl';
  }

  const [viewStatus, setViewStatus] = useState('view'); // [view 视图] [preview 预览]

  const ROLEAUTHDATA = {
    FullLinkGrayscalekHome: {
      img_cn:
        'https://img.alicdn.com/imgextra/i4/O1CN01NpCsyK1tsM6EOYOwZ_!!6000000005957-55-tps-975-308.svg',
      img_intl:
        'https://img.alicdn.com/imgextra/i1/O1CN01mgzBRz1ykB79nQ4pq_!!6000000006616-55-tps-1019-321.svg',
      width: '',
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.full.link.graycale.base.upgrade.tips'),
    }, // 专业版 全链路灰度透出
    NewRouteTagList: {
      img_cn:
        'https://img.alicdn.com/imgextra/i4/O1CN019TxHBh1awV4sXMVbG_!!6000000003394-0-tps-1112-818.jpg',
      img_intl: 'https://img.alicdn.com/imgextra/i4/O1CN019TxHBh1awV4sXMVbG_!!6000000003394-0-tps-1112-818.jpg',
      width: '500',
      innerStyle: { width: '600px' },
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.new.route.tag.base.upgrade.tips'),
      title: intl('mse.msc.menu.route'),
    }, // 专业版 标签路由
    TableContainerExample: {
      img_cn:
        'https://img.alicdn.com/imgextra/i1/O1CN01aMeJdz1FSAvGzizWl_!!6000000000485-0-tps-1020-822.jpg',
      img_intl: 'https://img.alicdn.com/imgextra/i1/O1CN01aMeJdz1FSAvGzizWl_!!6000000000485-0-tps-1020-822.jpg',
      width: '450',
      innerStyle: { width: '600px' },
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.service.authentication.base.upgrade.tips'),
      title: intl('mse.msc.menu.auth'),
    }, // 专业版 服务鉴权
    AZ: {
      img_cn:
        'https://img.alicdn.com/imgextra/i3/O1CN01lg0zlS1mFF3bs0vMm_!!6000000004924-0-tps-1832-926.jpg',
      img_intl: 'https://img.alicdn.com/imgextra/i3/O1CN01lg0zlS1mFF3bs0vMm_!!6000000004924-0-tps-1832-926.jpg',
      width: '700',
      innerStyle: { width: '800px' },
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.az.base.upgrade.tips'),
      title: intl('widget.msc.AZ_java'),
    }, // 专业版 同可用区优先
    OutlierEjectionList: {
      img_cn:
        'https://img.alicdn.com/imgextra/i3/O1CN01kbpSdy1TFim1DJ4Om_!!6000000002353-2-tps-535-309.png',
      img_intl: 'https://img.alicdn.com/imgextra/i3/O1CN01kbpSdy1TFim1DJ4Om_!!6000000002353-2-tps-535-309.png',
      width: '600',
      innerStyle: { width: '700px' },
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.outlier.ejection.base.upgrade.tips'),
      title: intl('mse.msc.menu.outlier'),
    }, // 专业版 离群实例摘除
    RocketMQRoute: {
      img_cn:
        'https://img.alicdn.com/imgextra/i1/O1CN016nback1kCpk48aorT_!!6000000004648-0-tps-2160-1036.jpg',
      img_intl: 'https://img.alicdn.com/imgextra/i1/O1CN016nback1kCpk48aorT_!!6000000004648-0-tps-2160-1036.jpg',
      width: '800',
      innerStyle: { width: '900px' },
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.rocket.mq.route.base.upgrade.tips'),
      title: intl('widget.app.mq_tag_route'),
    }, // 专业版 消息灰度
    PushAirProtection: {
      img_cn:
        'https://img.alicdn.com/imgextra/i2/O1CN01jCZXnD1EyrZacP6eX_!!6000000000421-0-tps-464-452.jpg',
      img_intl: 'https://img.alicdn.com/imgextra/i2/O1CN01jCZXnD1EyrZacP6eX_!!6000000000421-0-tps-464-452.jpg',
      width: '500',
      innerStyle: { width: '600px' },
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.push.air.protection.base.upgrade.tips'),
      title: intl('widget.app.push_air_protection'),
    }, // 专业版 推空保护
    RuleList: {
      img_cn:
        'https://img.alicdn.com/imgextra/i3/O1CN01gJpHWw1vK7p5bYTCN_!!6000000006153-0-tps-1848-687.jpg',
      img_intl: 'https://img.alicdn.com/imgextra/i1/O1CN01sMsyAe1kpJ1A5RF1U_!!6000000004732-0-tps-1848-680.jpg',
      width: '900',
      innerStyle: { width: '900px' },
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.rule.list.base.upgrade.tips'),
      title: intl('mse.msc.log.governance.rule.list'),
    }, // 专业版 规则列表
    LinkPresentation: {
      img_cn:
        'https://img.alicdn.com/imgextra/i3/O1CN01gJpHWw1vK7p5bYTCN_!!6000000006153-0-tps-1848-687.jpg',
      img_intl: 'https://img.alicdn.com/imgextra/i1/O1CN01sMsyAe1kpJ1A5RF1U_!!6000000004732-0-tps-1848-680.jpg',
      width: '900',
      innerStyle: { width: '1000px' },
      message: intl.html('mse.msc.base.professional.edition.upgrade.message', { upgradeHref }),
      tips: intl('mse.msc.link.presentation.base.upgrade.tips'),
      title: intl('mse.msc.menu.linkPresentation'),
    }, // 专业版 链路追踪
  };

  const commonProps = {
    style: { width: '100%' },
    title: ROLEAUTHDATA[component].title,
    showTitleBullet: false,
    showHeadDivider: false,
  };

  const renderComponents = useMemo(() => {
    if (component === 'FullLinkGrayscalekHome') {
      return (
        <div>
          <Message type="notice" style={{ margin: '8px 0px 16px 0px' }}>
            {ROLEAUTHDATA[component].message}
          </Message>
          <div className={styles['flow-line-chart']}>
            <div style={{ fontSize: '12px', color: '#555' }}>{ROLEAUTHDATA[component].tips}</div>
            <div className={styles['flex-img-box']}>
              <img
                src={
                  aliyunLang === 'en'
                    ? ROLEAUTHDATA[component].img_intl
                    : ROLEAUTHDATA[component].img_cn
                }
              />
            </div>
          </div>
        </div>
      );
    }
    // return (
    //   <div>
    //     <Message type="notice" style={{ margin: '8px 0px 16px 0px' }}>
    //       {ROLEAUTHDATA[component].message}
    //     </Message>
    //     <div className={styles['flow-line-chart']}>
    //       <div style={{ fontSize: '12px', color: '#555', marginBottom: '16px' }}>{ROLEAUTHDATA[component].tips}</div>
    //       <div className={styles['flex-img-box']}>
    //         <img
    //           width={ROLEAUTHDATA[component].width}
    //           src={
    //             aliyunLang === 'en'
    //               ? ROLEAUTHDATA[component].img_intl
    //               : ROLEAUTHDATA[component].img_cn
    //           }
    //         />
    //       </div>
    //     </div>
    //   </div>
    // );
    return (
        <Card {...commonProps} contentHeight="auto">
        <div style={{ display: 'flex', padding: '8px 16px 2px 0px' }} >
          <div style={{ width: '30%', margin: '0px 16px 16px 0px ' }} className={styles['rule-auth-content']}>
            <Message type="notice" style={{ margin: '16px 0px' }} title={intl('mse.msc.base.professional.not.supported.current.func')}>
              {ROLEAUTHDATA[component].message}
            </Message>
            <div style={{ fontWeight: 'bold', lineHeight: '24px' }}>{intl('mse.msc.rule.auth.description')}</div>
            <div style={{ fontSize: '12px', color: '#555' }}>{ROLEAUTHDATA[component].tips}</div>
            <div>
              <div
                className={`${styles['component-btn']} ${
                  viewStatus === 'view' ? styles['component-btn-selected'] : ''
                }`}
                onClick={() => setViewStatus('view')}
              >
                <span>{intl('mse.msc.rule.auth.logical.view')}</span>
                <span className={styles['click-view']}>{intl('mse.msc.role.auth.cleck.view')}</span>
              </div>
              <div
                className={`${styles['component-btn']} ${
                  viewStatus === 'preview' ? styles['component-btn-selected'] : ''
                }`}
                onClick={() => setViewStatus('preview')}
              >
                <span>{intl('mse.msc.role.auth.func.preview')}</span>
                <span className={styles['click-view']}>{intl('mse.msc.role.auth.cleck.view')}</span>
              </div>
            </div>
            <div className={styles['component-btn-upgrade']}>
              <Button
                type="primary"
                onClick={(e) => {
                  e.stopPropagation();
                  window.open(upgradeHref);
                }}
              >
                {intl('mse.msc.role.auth.upgrade.experience')}
              </Button>
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <div className={styles['content-box']}>
              <div className={styles['flex-img-box']}>
                {
                  <ImageEnlarge
                    width={ROLEAUTHDATA[component].width}
                    src={
                      aliyunLang === 'en'
                        ? ROLEAUTHDATA[component].img_intl
                        : ROLEAUTHDATA[component].img_cn
                    }
                    innerStyle={{ ...ROLEAUTHDATA[component].innerStyle }}
                  />
                }
              </div>
            </div>
          </div>
        </div>
      </Card>
    );
  }, [viewStatus]);

  if (Version === 0) {
    return renderComponents;
  }
  return <WrapComp {...props} />;
};

export default RoleAuth;
