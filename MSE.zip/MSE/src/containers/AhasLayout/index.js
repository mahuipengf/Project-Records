import React, { useState, useEffect } from 'react';
import { Menu } from '@ali/cn-design';
import AppLayout from '../AppLayout';
import IconBack from 'components/IconBack';
import intl from '@ali/wind-intl';

const { Item, SubMenu } = Menu;
const AhasLayout = ({ menu = [], map = {}, map_title = {}, initial = '', title = '', url = '', breadCrumbSubsetTitle = [] }) => {
  const [tag, setTag] = useState('');
  const breadCrumbList = [
    ...breadCrumbSubsetTitle,
    {
      title: map_title[tag],
    },
  ];
  useEffect(() => {
    setTag(initial);
  }, []);
  const onItemClick = (key) => {
    setTag(key);
  };
  return (
    <div style={{ display: 'flex', height: '100%' }}>
         <div style={{ width: '200px', height: 'calc(100%)' }}>
            <Menu onItemClick={onItemClick} style={{ height: 'calc(100vh - 50px)', position: 'relative', zIndex: 99, boxShadow: 'none' }}>
              <For each="item" index="index" of={menu}>
                  <If condition={item.items}>
                  <SubMenu key={item.tag} label={item.label}>
                      <For each="t" index="i" of={item.items}>
                          <Item key={t.tag} style={{ color: `${tag === t.tag ? '#0070cc' : '#333'}` }}>{t.label}</Item>
                      </For>
                  </SubMenu>
                  </If>
                  <If condition={!item.items}>
                      <Item key={item.tag} style={{ color: `${tag === item.tag ? '#0070cc' : '#333'}` }}>{item.label}</Item>
                    </If>
              </For>
            </Menu>
          </div>
          <div style={{ flex: 1 }}>
            <AppLayout
              breadCrumbList={breadCrumbList}
              breadCrumbSubsetTitle={breadCrumbSubsetTitle}
              title={<IconBack
                back
                text={`${map_title[tag] || ''}(${title})`}
                onClick={() => {
                  hashHistory.push(url);
                }}
              />}
            >
             {map[tag]}
            </AppLayout>
          </div>
    </div>
  );
};

export default AhasLayout;