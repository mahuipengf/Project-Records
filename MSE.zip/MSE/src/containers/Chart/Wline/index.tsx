import React from 'react';
import intl from '@ali/wind-intl';
import { Empty, Icon } from '@ali/cn-design';
import { If } from 'components/tsx-control';
import { Wcontainer, Wline, Wplaceholder } from '@alife/aisc-widgets';
import { assign, find, isEmpty } from 'lodash';

interface ILine {
  data?: any;
  height?: string;
  style?: any;
  title?: string;
  titleStyle?: any;
  option?: any;
  getChartInstance?: any;
  loading?: boolean;
  paths?: string;
  requestMethods?: string;
  handleDelete?: any;
  uId?: string;
  fixingNail?: any;
  nail?: boolean;
}
const defaultOptions = {
  tooltip: {},
  // area: true,
  // colors: ['#0077cc'],
  // areaColors: ['l(90) 0:#0077cc 1:#0077cc00'], // 颜色渐变
  xAxis: {
    mask: 'HH:mm:ss',
    // type: 'timeCat',
  },
  yAxis: [
    {
      min: 0,
      labelFormatter: (value: any) => {
        if (value >= 1000) return `${(value / 1000).toFixed(1)}k`;
        return value;
      },
    },
  ],
  padding: [ 16, 32, 48, 48 ],
};
const Line = (props: ILine) => {
  const { data, option, title, height, style, titleStyle, getChartInstance, loading, paths = undefined, requestMethods = undefined, handleDelete, uId, fixingNail, nail } = props;
  const newOption = assign({}, defaultOptions, option);
  return (
    <div>
      <If condition={!loading}>
        <If condition={!!paths && !!requestMethods}>
          <div style={{ display: 'flex', alignItems: 'center', marginLeft: '35px' }}>
            <span style={{ height: '24px', width: '52px', background: '#EFF3F8', border: '1px solid #0064C8', borderRadius: '12px', fontSize: '12px', fontFamily: 'PingFangSC-Medium', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>{requestMethods}</span>
            <span style={{ marginLeft: '8px', fontSize: '14px', fontFamily: 'PingFangSC-Medium' }}>{paths}</span>
            <span style={{ flex: 1, textAlign: 'right' }}>
              <If condition={nail} >
                <span onClick={() => fixingNail(false, uId)} style={{ marginRight: '27px', fontFamily: 'PingFangSC-Medium', fontSize: '12px', color: '#0064C8' }} ><Icon type="nail" style={{ marginRight: '6px' }} />{intl('widget.msc.containers.pinned')}</span>
              </If>
              <If condition={!nail} >
                <span onClick={() => fixingNail(true, uId)} style={{ marginRight: '27px', fontFamily: 'PingFangSC-Medium', fontSize: '12px', color: '#0064C8' }} ><Icon type="nail" style={{ marginRight: '6px', transform: 'rotate(-45deg)' }} />{intl('widget.msc.containers.nailed.head')}</span>
              </If>
              <span style={{ background: '#666', marginRight: '24px', fontSize: '12px' }}><Icon type="times" onClick={() => handleDelete(uId)} /></span></span>
          </div>
        </If>
      </If>
      <If condition={loading}>
        <Wcontainer>
          <Wplaceholder
            loading
            style={{ transform: 'scale(3)' }}
            // locale={{ loading: 'loading...', error: '数据异常' }}
            height={height}
          />
        </Wcontainer >
      </If>
      <If condition={!loading}>
        <If condition={isEmpty(data) || !find(data, item => !isEmpty(item.data))}>
          <div style={{ height, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Empty showIcon />
          </div>
        </If>
        <If condition={!isEmpty(data) && find(data, item => !isEmpty(item.data))}>
          <Wcontainer
            title={title}
            titleStyle={{ fontSize: 14, ...titleStyle }}
            style={{ padding: '0 16px', ...style }}
          >
            <Wline getChartInstance={getChartInstance} config={newOption} data={data} height={height} />
          </Wcontainer>
        </If>
      </If>
    </div >
  );
};


export default Line;
