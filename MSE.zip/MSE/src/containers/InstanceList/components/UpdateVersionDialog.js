import React, { useState } from 'react';
import { Dialog, Button, Message, Radio, Icon } from '@ali/wind';
import services from 'utils/services';
import intl from '@ali/wind-intl';

const UpdateVertionDialog = ({ onOk, onClose, visible, value = {} }) => {
  const [loading, setLoading] = useState(false);
  const { MaxVersionCode, MaxVersionChangelogUrl, MaxVersionFullShowName, CurrentVersionFullShowName, ClusterId, InstanceCount, ClusterType } = value;

  const handlerClose = () => {
    onClose();
  };

  const handleOk = async () => {
    setLoading(true);
    const res = await services.UpdateImage({
      params: { ClusterId, VersionCode: MaxVersionCode },
      customErrorHandle: (err, response, callback) => {
        setLoading(false);
        callback();
      }
    });
    setLoading(false);
    if (res && !res.Success) {
      onClose();
      window.showErrorMessage(res.Message);
    } else {
      Message.success(intl('mse.microgw.instance.upgrade_success'));
      onOk();
    }
  };

  const updateExplain = () => {
    const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
    const isIntl = aliyunSite === 'INTL';
    let updateUri = 'https://help.aliyun.com/document_detail/181111.html?spm=cpm._customer-service-intelligence_knowledge-base.0.0.dacb70a5qRUmPB#section-1tw-fw8-8h6';
    if (ClusterType === 'Nacos-Ans' && !isIntl) {
      updateUri = 'https://help.aliyun.com/document_detail/181111.html?spm=cpm._customer-service-intelligence_knowledge-base.0.0.dacb70a5qRUmPB#section-1tw-fw8-8h6';
    }
    if (ClusterType === 'Nacos-Ans' && isIntl) {
      updateUri = 'https://www.alibabacloud.com/help/microservices-engine/latest/instance-upgrade-nacos#section-1tw-fw8-8h6';
    }

    if (ClusterType === 'ZooKeeper' && !isIntl) {
      updateUri = 'https://help.aliyun.com/document_detail/384045.html#section-70n-qbh-7u6';
    }
    if (ClusterType === 'ZooKeeper' && isIntl) {
      updateUri = 'https://www.alibabacloud.com/help/zh/microservices-engine/latest/upgrade-the-engine-version-1#section-70n-qbh-7u6';
    }
    window.open(updateUri, '_blank');
  };

  return (
    <Dialog
      title={
        <div>
          <Icon type="warning" size="small" style={{ color: '#ffc440', marginRight: 8 }} />
          {intl('mse.instancelist.cluster.upgrade')}
        </div>
      }
      okProps={{ loading }}
      visible={visible}
      onOk={handleOk}
      onCancel={handlerClose}
      onClose={handlerClose}
    >
      <div style={{ fontSize: 12 }}>
        <div style={{ display: 'flex', marginTop: 8, width: 472 }}>
          <span style={{ marginRight: 8 }}>{intl('mse.instancelist.cluster.version')}<span>{CurrentVersionFullShowName || ''}</span></span>
          <p>{intl('mse.instancelist.upgradeable')}</p>
          <div style={{ fontSize: 12 }}>
            <Radio.Group
              shape="button"
              size="small"
            // onChange={(checked) => setUpdateClusterVerion(checked)}
            >
              <If condition={MaxVersionCode}>
                <Radio id={MaxVersionCode} value={MaxVersionCode}>
                  {MaxVersionFullShowName}
                </Radio>
                <If condition={MaxVersionChangelogUrl}>
                  <a
                    href={MaxVersionChangelogUrl}
                    target="_blank"
                    style={{ marginLeft: 8 }}
                  >
                    {intl('mse.instancelist.version.descript')}<Icon size="xs" type="external-link-alt" />
                  </a>
                </If>
                <p style={{ marginTop: 8 }} />
              </If>
            </Radio.Group>
          </div>
        </div>
        <div style={{ marginTop: 8, width: 472 }}>
          <span>升级过程10分钟左右，3节点及以上的实例，升级对业务运行无损，建议在业务低峰期时操作，详情参考</span>
          <span
            onClick={updateExplain}
            style={{ color: '#0070cc', cursor: 'pointer', marginLeft: 8 }}
          >
            <span>升级说明</span>
            <Icon size="xs" type="external-link-alt" />
          </span>
        </div>
        <If condition={InstanceCount < 3}>
          <div style={{ marginTop: 16, color: 'red' }}>{intl('mse.instancelist.upgrade.information.tips')}</div>
        </If>
      </div>
    </Dialog>
  );
};

export default UpdateVertionDialog;
