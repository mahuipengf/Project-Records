import React, { useState } from 'react';
import Actions, { LinkButton } from '@ali/wind-rc-actions';
import services from 'utils/services';
import { Dialog, Button, Message } from '@ali/wind';
import { get, includes } from 'lodash';
import UpdateVersionDialog from './UpdateVersionDialog';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

/** 操作 */
const RenderOptions = (props) => {
  const { setRefreshIndex } = props;
  const VirtualNetwork = ['JST', 'CAINIAO', 'NEW_RETAIL'];
  const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
  const aliyunLang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';
  const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
  const isEn = aliyunLang === 'en';
  const isIntl = aliyunSite === 'INTL';
  const [upVisible, setUpVisible] = useState(false);
  const [clusterData, setClusterData] = useState({});

  const goDetailMonitor = async (cluster) => {
    const {
      ClusterName,
      ClusterId,
      ClusterType,
      InstanceId,
      AppVersion,
      MseVersion,
      ChargeType,
    } = cluster;
    //请求列表接口获取监控信息
    const res = await services.getClusterFeature({
      customErrorHandle: (err, data, callback) => {
        callback();
      },
      params: {
        InstanceId,
      },
    });
    //是否存在监控
    let monitor = true;
    //监控类型是否为基础版
    let monitorVersionBasic = false;
    res &&
        res.forEach((item, index) => {
          if (
            item.FeatureId.indexOf('_prometheus') !== -1 &&
            item.Status === 'enabled'
          ) {
            monitorVersionBasic = item.FeatureId.split('_prometheus_')[1] === 'basic';
          } else if (
            item.FeatureId.indexOf('_prometheus') !== -1 &&
            item.Status === 'disabled'
          ) {
            monitor = false;
            Dialog.alert({
              title: intl('mse.errormessage.wrong'),
              content: intl(item?.Message || intl('mse.monitor.disabled')),
            });
          }
        });

    //接口无返回值，则跳转至基础版监控
    if (!res || !res.length) {
      hashHistory.push(
        `/Instance/Monitor?ClusterId=${ClusterId}&ClusterName=${ClusterName}&ClusterType=${ClusterType}&InstanceId=${InstanceId}&AppVersion=${AppVersion}&MseVersion=${MseVersion}&ChargeType=${ChargeType}`
      );
    } else {
      monitor && (
      monitorVersionBasic ?
        //监控为基础版
        hashHistory.push(
          `/Instance/Monitor?ClusterId=${ClusterId}&ClusterName=${ClusterName}&ClusterType=${ClusterType}&InstanceId=${InstanceId}&AppVersion=${AppVersion}&MseVersion=${MseVersion}&ChargeType=${ChargeType}`
        )
        :
        //监控为开发版或专业版
        hashHistory.push(
          `/Instance/Observe/Monitor?ClusterId=${ClusterId}&ClusterName=${ClusterName}&ClusterType=${ClusterType}&InstanceId=${InstanceId}&AppVersion=${AppVersion}&MseVersion=${MseVersion}&ChargeType=${ChargeType}`
        )
    );
  }
  };

  const goDetailParams = (cluster) => {
    const {
      ClusterName,
      ClusterId,
      ClusterType,
      InstanceId,
      AppVersion,
      MseVersion,
      ChargeType,
    } = cluster;
    hashHistory.push(
      `/Instance/ParameterSetting?ClusterId=${ClusterId}&ClusterName=${ClusterName}&ClusterType=${ClusterType}&InstanceId=${InstanceId}&AppVersion=${AppVersion}&MseVersion=${MseVersion}&ChargeType=${ChargeType}`
    );
  };

  // 续费
  const renew = (cluster) => {
    const { InstanceId } = cluster;
    let commodityCode = 'mse_prepaid_public_cn';
    let renewDomain = 'https://common-buy.aliyun.com';
    if (includes(VirtualNetwork, channel)) {
      commodityCode = 'mse_prepaid_public_cn';
      renewDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      commodityCode = 'mse_prepaid_public_intl';
      renewDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    const renewUrl = `${renewDomain}/?commodityCode=${commodityCode}&orderType=RENEW&instanceId=${InstanceId}#/renew`;
    window.open(renewUrl);
  };

  // 重试选中实例
  const retryCluster = (ClusterId) => {
    Dialog.confirm({
      content: '确定重试该实例吗？',
      onOk: () => {
        const options = {
          url: 'com.alibaba.MSE.service.RetryCluster',
          data: {
            ClusterId,
          },
          success: (res) => {
            setRefreshIndex();
          },
        };
        window.request(options);
      },
    });
  };

  // 转包年包月
  const transFormYM = (cluster) => {
    let commodityCode = 'mse';
    let convertCommodityCode = 'mse_prepaid_public_cn';
    let convertDomain = 'https://common-buy.aliyun.com';
    if (includes(VirtualNetwork, channel)) {
      commodityCode = 'mse';
      convertCommodityCode = 'mse_prepaid_public_cn';
      convertDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      commodityCode = 'mse_msepost_public_intl';
      convertCommodityCode = 'mse_prepaid_public_intl';
      convertDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    const transFormYMUrl = `${convertDomain}/?commodityCode=${commodityCode}&orderType=CONVERT&instanceId=${cluster.InstanceId}&convertCommodityCode=${convertCommodityCode}#/convert`;
    window.open(transFormYMUrl);
  };

  // 升级引擎版本
  const updateClusterVersion = async (cluster) => {
    const { VersionCode, ClusterId, InstanceCount } = cluster;
    const Data = await services.GetImage({
      params: { VersionCode },
    });
    setClusterData({ ...Data, ClusterId, InstanceCount });
    setUpVisible(true);
  };

  // 实例规格变更
  const changePrice = (cluster) => {
    let commodityCode = 'mse';
    let upgradeDomain = 'https://common-buy.aliyun.com';
    if (includes(VirtualNetwork, channel)) {
      commodityCode = 'mse';
      upgradeDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      commodityCode = 'mse_msepost_public_intl';
      upgradeDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    const changePriceUrl = `${upgradeDomain}/?commodityCode=${commodityCode}&orderType=upgrade&instanceId=${cluster.InstanceId}&upgradeType=upgrade`;
    window.open(changePriceUrl);
  };

  const changeUpPREPAYPrice = (cluster) => {
    let commodityCode = 'mse_prepaid_public_cn';
    let changeDomain = 'https://common-buy.aliyun.com';
    if (includes(VirtualNetwork, channel)) {
      commodityCode = 'mse_prepaid_public_cn';
      changeDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      commodityCode = 'mse_prepaid_public_intl';
      changeDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    const upPriceUrl = `${changeDomain}/?commodityCode=${commodityCode}&orderType=upgrade&instanceId=${cluster.InstanceId}&upgradeType=upgrade`;
    window.open(upPriceUrl);
  };

  const changeDownPREPAYPrice = (cluster) => {
    let commodityCode = 'mse_prepaid_public_cn';
    let changeDomain = 'https://common-buy.aliyun.com';
    if (includes(VirtualNetwork, channel)) {
      commodityCode = 'mse_prepaid_public_cn';
      changeDomain = 'https://common-buy4service.aliyun.com';
    }
    if (isIntl) {
      commodityCode = 'mse_prepaid_public_intl';
      changeDomain = 'https://common-buy-intl.alibabacloud.com';
    }
    const downPriceUrl = `${changeDomain}/?commodityCode=${commodityCode}&orderType=DOWNGRADE&instanceId=${cluster.InstanceId}`;
    window.open(downPriceUrl);
  };

  // 释放实例 弹出框
  const destroyCluster = (cluster) => {
    const handleDialog = Dialog.confirm({
      title: intl('mse.microgw.instance.release'),
      content: intl.html('mse.microgw.instance.release_confirm', { name: cluster.ClusterName }),
      footer: (
        <div className="common-align-right">
          <Button
            type="primary"
            className="common-mr-10"
            onClick={() => {
              handleDialog.hide();
              releaseInstance(cluster.ClusterId, cluster.InstanceId);
            }}
          >
            {intl('mse.common.ok')}
          </Button>
          <Button
            type="normal"
            onClick={() => {
              handleDialog.hide();
            }}
          >
            {intl('mse.common.cancel')}
          </Button>
        </div>
      ),
    });
  };

  // 释放实例操作
  const releaseInstance = (ClusterId, InstanceId) => {
    const options = {
      url: 'com.alibaba.MSE.service.destroycluster',
      data: {
        ClusterId,
        InstanceId,
      },
      success: (res) => {
        setRefreshIndex();
      },
    };
    window.request(options);
  };

  const updateCluster = ({ InstanceId, ClusterName }) => {
    Dialog.confirm({
      title: intl('mse.microgw.instance.upgrade'),
      content: intl.html('mse.microgw.instance.upgrade_confirm', { name: ClusterName }),
      onOk: () =>
        services
          .UpgradeCluster({
            params: { InstanceId, UpgradeVersion: '1.2.1' },
          })
          .then(() => {
            Message.success(intl('mse.microgw.instance.upgrade_success'));
            setRefreshIndex();
          }),
    });
  };

  // 获得Actions组建的内容
  const getJsxTemplate = (record) => {
    const { InitStatus, ChargeType, AppVersion, ClusterType, CanUpdate } = record,
      enableManage =
        InitStatus === 'INIT_SUCCESS' ||
        InitStatus === 'RESTART_SUCCESS' ||
        InitStatus === 'SCALE_SUCCESS',
      showRestart =
        InitStatus === 'RESTART_FAILED' ||
        InitStatus === 'INIT_FAILED' ||
        InitStatus === 'INIT_TIME_OUT',
      showRelase =
        InitStatus === 'DESTROY_FAILED' ||
        (ChargeType !== 'PREPAY' &&
          (InitStatus === 'INIT_SUCCESS' ||
            InitStatus === 'SCALE_SUCCESS' ||
            InitStatus === 'STOPED' ||
            InitStatus === 'RESTART_SUCCESS')) ||
        (showRestart && ChargeType === 'POSTPAY'); // 所有失败案例以及成功并且不是预付费的都可以显示释放
    const showRecharge = ChargeType === 'POSTPAY' && InitStatus === 'STOPED';
    let tempList = [
      // <LinkButton onClick={() => goDetail(record)} disabled={!enableManage}>{intl('mse.register.action.manage')}</LinkButton>
      <LinkButton onClick={() => goDetailMonitor(record)} disabled={!enableManage}>
        {intl('mse.register.monitor')}
      </LinkButton>,
    ];

    if (ClusterType !== 'Eureka') {
      tempList.push(
        <LinkButton onClick={() => goDetailParams(record)} disabled={!enableManage}>
          {intl('mse.register.params')}
        </LinkButton>,
      );
    }

    // 重试 操作
    if (showRestart) {
      tempList.push(
        <LinkButton
          onClick={() => retryCluster(record.ClusterId)}
          disabled={!(enableManage || showRestart)}
        >
          {intl('mse.register.action.retry')}
        </LinkButton>
      );
    }

    //续费 操作
    if (record.ChargeType === 'PREPAY') {
      tempList.push(
        <LinkButton
          onClick={() => renew(record)}
          disabled={!(enableManage || InitStatus === 'STOPED')}
        >
          {intl('mse.register.action.renew')}
        </LinkButton>
      );
      tempList.push(
        <LinkButton onClick={() => changeUpPREPAYPrice(record)} disabled={!enableManage}>
          {intl('mse.register.action.update')}
        </LinkButton>
      );
      tempList.push(
        <LinkButton onClick={() => changeDownPREPAYPrice(record)} disabled={!enableManage}>
          {intl('mse.register.action.downgrade')}
        </LinkButton>
      );
    }

    // 转包年包月 && 实例规格变更 操作
    if (record.ChargeType === 'POSTPAY') {
      tempList.push(
        <LinkButton onClick={() => transFormYM(record)} disabled={!enableManage}>
          {intl('mse.register.action.prepay')}
        </LinkButton>
      );
      tempList.push(
        <LinkButton onClick={() => changePrice(record)} disabled={!enableManage}>
          {intl('mse.register.action.upgrade_downgrade')}
        </LinkButton>
      );
    }

    // nacos 1.1.3升级1.2.1
    if (AppVersion === '1.1.3.0' && ClusterType === 'Nacos-Ans') {
      tempList.push(
        <LinkButton onClick={() => updateCluster(record)} disabled={!enableManage}>
          {intl('mse.register.action.upgrade')}
        </LinkButton>
      );
    }

    // 升级引擎版本
    if (CanUpdate) {
      tempList.push(
        <LinkButton onClick={() => updateClusterVersion(record)} disabled={!enableManage}>
          {intl('mse.register.action.upgrade_engine_version')}
        </LinkButton>
      );
    }

    //释放实例 操作
    if (showRelase) {
      tempList.push(
        <LinkButton onClick={() => destroyCluster(record)}>
          {intl('mse.register.action.release')}
        </LinkButton>
      );
    }

    if (showRecharge) {
      tempList.push(
        <LinkButton
          onClick={() =>
            window.open('https://usercenter2.aliyun.com/finance/fund-management/recharge', '_blank')
          }
        >
          充值恢复服务
        </LinkButton>
      );
    }

    return tempList;
  };

  const tempList = getJsxTemplate(props.value);

  return (
    <div style={{ width: '150px' }}>
      <Actions
        threshold={2}
        wrap="true"
        menuProps={{ style: { maxWidth: '200px' } }}
        expandTriggerType="hover"
      >
        {tempList.map((item) => {
          return item;
        })}
      </Actions>
      <UpdateVersionDialog
        visible={upVisible}
        value={clusterData}
        onOk={() => {
          setUpVisible(false);
          setRefreshIndex();
        }}
        onCancel={() => setUpVisible(false)}
        onClose={() => setUpVisible(false)}
      />
    </div>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default RenderOptions;
