import React from 'react';
import { CopyContent } from '@ali/cn-design';
import ComIf from '../../../components/common/ComIf';
import { includes } from 'lodash';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const RenderAliasName = (props) => {
  const goDetail = (cluster) => {
    const {
      ClusterAliasName,
      ClusterId,
      ClusterType,
      InstanceId,
      AppVersion,
      MseVersion,
      ChargeType,
    } = cluster;
    window.CN_TRACKER.send({
      name: InstanceId,
      type: 'mse-instancelist-godetail-renderaliasname',
    });
    hashHistory.push(
      `/Instance/BasicInfo?ClusterId=${ClusterId}&ClusterName=${ClusterAliasName}&ClusterType=${ClusterType}&InstanceId=${InstanceId}&AppVersion=${AppVersion}&MseVersion=${MseVersion}&ChargeType=${ChargeType}`
    );
  };

  const { InitStatus } = props.value;
  const record = props.value;

  return (
    <div style={{ color: '#0070cc' }}>
      <ComIf if={!includes(['INIT_ING', 'STOPED'], InitStatus)}>
        <span>
          <div>
          <CopyContent
              text={record.ClusterAliasName}
              truncateProps={{ type: 'width', threshold: '200', tooltipMaxWidth: 500 }}
            >
              <a
                href="javascript:;"
                onClick={() => goDetail(record)}
                data-spm-click="gostr=/aliyun;locaid=index-cluster-aliname"
              >
                {record.ClusterAliasName}
              </a>
            </CopyContent>
            <CopyContent
              text={record.InstanceId}
              style={{color: 'black', display: 'block'}}
              truncateProps={{ type: 'width', threshold: '200', tooltipMaxWidth: 500 }}
            >
              {record.InstanceId}
            </CopyContent>
          </div>
        </span>
      </ComIf>
      <ComIf if={includes(['INIT_ING', 'STOPED'], InitStatus)}>
        <span>
          <div>
            <a href="javascript:;" style={{ color: '#ccc', cursor: 'not-allowed' }}>
              <CopyContent
                text={record.ClusterAliasName}
                truncateProps={{ type: 'width', threshold: '200', tooltipMaxWidth: 500 }}
              >
                {record.ClusterAliasName}
              </CopyContent>
              <CopyContent
                style={{style: 'block'}}
                text={record.InstanceId}
                truncateProps={{ type: 'width', threshold: '200', tooltipMaxWidth: 500 }}
              >
                {record.InstanceId}
              </CopyContent>
            </a>
          </div>
        </span>
      </ComIf>
    </div>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default RenderAliasName;
