import React from 'react';
import { Icon, Button, Dialog } from '@ali/wind';
import intl from '@ali/wind-intl';
/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

const RenderStatus = (props) => {
  const value = props.value;
  const setRefreshIndex = props.setRefreshIndex;
  const record = props.record;
  const { ClusterId } = record;
  const statusObj = window.STATUS_MAP[value] || {};

  // 重试选中实例
  const retryCluster = () => {
    Dialog.confirm({
      content: '确定重试该实例吗？',
      onOk: () => {
        const options = {
          url: 'com.alibaba.MSE.service.RetryCluster',
          data: {
            ClusterId,
          },
          success: (res) => {
            setRefreshIndex();
          },
        };
        window.request(options);
      },
    });
  };

  return (
    <div>
      <span style={{ whiteSpace: 'nowrap' }}>
        <Icon
          type={statusObj.icon}
          className="instance-icon"
          style={{ color: statusObj.color }}
        />
        {statusObj.name || ''}
      </span>
      <If condition={value === 'INIT_TIME_OUT'}>
        <Button
          style={{ display: 'block', paddingLeft: 20 }}
          type="primary"
          text
          onClick={() => retryCluster()}
        >
          {intl('mse.register.action.retry')}
        </Button>
      </If>
    </div>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default RenderStatus;
