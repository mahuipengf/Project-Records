import React from 'react';
import intl from '@ali/wind-intl';
import CommonBalloon from '../../../components/common/CommonBalloon';
import { Icon } from '@ali/wind';
import { get, includes } from 'lodash';

const VersionCate = new Map()
  .set('mse_pro', intl('mse.register.version.pro'))
  .set('mse_basic', intl('mse.register.version.basic'))
  .set('mse_dev', intl('mse.register.version.dev'));

const HelpUrl = {
  'Nacos-Ans': 'https://help.aliyun.com/document_detail/181111.html#section-5hv-8no-b8w',
  ZooKeeper: 'https://help.aliyun.com/document_detail/384045.html',
};
const VirtualNetwork = ['JST', 'CAINIAO', 'NEW_RETAIL'];
const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');

const RenderMseVersion = (props) => {
  const { record, isBasic = false } = props;
  const { MseVersion, ClusterType, AppVersion, InstanceId, ChargeType } = record;
  const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
  const isIntl = aliyunSite === 'INTL';

  const changeUpVersion = () => {
    if (ChargeType === 'PREPAY') {
      let commodityCode = 'mse_prepaid_public_cn';
      let changeDomain = 'https://common-buy.aliyun.com';
      if (includes(VirtualNetwork, channel)) {
        commodityCode = 'mse_prepaid_public_cn';
        changeDomain = 'https://common-buy4service.aliyun.com';
      }
      if (isIntl) {
        commodityCode = 'mse_prepaid_public_intl';
        changeDomain = 'https://common-buy-intl.alibabacloud.com';
      }
      const upPriceUrl = `${changeDomain}/?commodityCode=${commodityCode}&orderType=upgrade&instanceId=${InstanceId}&upgradeType=upgrade`;
      window.open(upPriceUrl);
    } else {
      let commodityCode = 'mse';
      let upgradeDomain = 'https://common-buy.aliyun.com';
      if (includes(VirtualNetwork, channel)) {
        commodityCode = 'mse';
        upgradeDomain = 'https://common-buy4service.aliyun.com';
      }
      if (isIntl) {
        commodityCode = 'mse_msepost_public_intl';
        upgradeDomain = 'https://common-buy-intl.alibabacloud.com';
      }
      const changePriceUrl = `${upgradeDomain}/?commodityCode=${commodityCode}&orderType=upgrade&instanceId=${InstanceId}&upgradeType=upgrade`;
      window.open(changePriceUrl);
    }
  };

  const MseBasicShowState = () => {
    if (
      (ClusterType === 'Nacos-Ans' || ClusterType === 'ZooKeeper') &&
      MseVersion === 'mse_basic'
    ) {
      if (ClusterType === 'Nacos-Ans' && (AppVersion === '1.1.3' || AppVersion === '1.1.3.0')) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  };

  return (
    <React.Fragment>
      <div>
        <span style={{ marginRight: 5 }}>{MseVersion ? VersionCate.get(MseVersion) : '-'}</span>
        <If condition={MseBasicShowState()}>
          <span style={{ color: '#FF0000' }}>
            <If condition={isBasic}>
              ({intl('mse.register.instance.mse_version.notice1')}
              <span style={{ color: '#0070CC', cursor: 'pointer' }} onClick={changeUpVersion}>
                {intl('mse.register.instance.upgrade')}
              </span>
              {intl('mse.register.instance.mse_version.notice2')} )
            </If>
            <If condition={!isBasic}>
              ({intl('mse.register.instance.mse_version.notice3')}
              <span style={{ color: '#0070CC', cursor: 'pointer' }} onClick={changeUpVersion}>
                {intl('mse.register.instance.upgrade')}
              </span>
              )
            </If>

            <CommonBalloon
              align="r"
              content={intl.html('mse.register.mse_version.up.message1', {
                type: HelpUrl[ClusterType],
              })}
            >
              <Icon type="help" className="common-help-icon" />
            </CommonBalloon>
          </span>
        </If>
      </div>
    </React.Fragment>
  );
};
export default RenderMseVersion;
