import React, { Component } from 'react';
import CommonBalloon from '../../../components/common/CommonBalloon';
import { Icon } from '@ali/wind';
import intl from '@ali/wind-intl';
import { CopyContent } from '@ali/cn-design';


/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

/**访问方式 */
const RenderIp = (props) => {
  const { InternetDomain, IntranetDomain } = props.value;
  return (
    <div>
      <div>
        {InternetDomain ? (
          <div >
            {InternetDomain ? (
              <CommonBalloon
                align="r"
                content={<span style={{ marginLeft: 5 }}>{intl.html('mse.register.outer_hint')}</span>}
              >
                <Icon type="help" className="common-help-icon" />
              </CommonBalloon>
            ) : (
              ''
            )}

            <CopyContent
              text={InternetDomain ? InternetDomain : ''}
            >
              {InternetDomain ? `(${intl('mse.register.outer')})${InternetDomain}` : ''}{' '}
            </CopyContent>
          
        </div>
        ) : (
          ''
        )}
        { IntranetDomain ? (
          <div>
            <CopyContent
              text={IntranetDomain ? IntranetDomain : ''}
              style={{color: 'black', display: 'block'}}
            >
              ({intl('mse.register.inner')}){IntranetDomain}
            </CopyContent>
          </div>
        ) : ''}
      </div>
    </div>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default RenderIp;
