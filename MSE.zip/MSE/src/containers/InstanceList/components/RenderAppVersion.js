import React, { useState } from 'react';
import UpdateVersionDialog from './UpdateVersionDialog';
import CommonBalloon from '../../../components/common/CommonBalloon';
import { Icon, Dialog, Message } from '@ali/wind';
import services from 'utils/services';
import intl from '@ali/wind-intl';

const RenderAppVersion = (props) => {
  const { record, setRefreshIndex } = props;
  const { AppVersion, CanUpdate, InitStatus, ClusterType, InstanceId, ClusterName, VersionCode, ClusterId, InstanceCount } = record;
  const [clusterData, setClusterData] = useState({});
  const [upVisible, setUpVisible] = useState(false);

  const updateCluster = async() => {
    if (ClusterType === 'Nacos-Ans' && (AppVersion === '1.1.3.0' || AppVersion === '1.1.3')) {
      Dialog.confirm({
      title: intl('mse.microgw.instance.upgrade'),
      content: intl.html('mse.microgw.instance.upgrade_confirm', { name: ClusterName }),
      onOk: () =>
        services
          .UpgradeCluster({
            params: { InstanceId, UpgradeVersion: '1.2.1' },
          })
          .then(() => {
            Message.success(intl('mse.microgw.instance.upgrade_success'));
            setRefreshIndex();
          }),
     });
    } else {
      const Data = await services.GetImage({
        params: { VersionCode },
      });
      setClusterData({ ...Data, ClusterId, InstanceCount, ClusterType });
      setUpVisible(true);
    }
  };

  return (
    <React.Fragment>
      <div>
        <span>{AppVersion || '-'}</span>
        <If condition={CanUpdate}>
          <a
            style={{ color: 'red', cursor: 'pointer', marginLeft: 4 }}
            onClick={updateCluster}
            disabled={
              InitStatus === 'INIT_SUCCESS' ||
              InitStatus === 'RESTART_SUCCESS' ||
              InitStatus === 'SCALE_SUCCESS'
            }
          >
            ({intl('mse.register.instance.upgradeable')})
          </a>
        </If>
        <If
          condition={
            ClusterType === 'Nacos-Ans' && (AppVersion === '1.1.3.0' || AppVersion === '1.1.3')
          }
        >
          <span style={{ color: '#FF0000', marginLeft: 4 }}>
            ({intl('mse.register.instance.app_version.notice1')}
            <span style={{ color: '#0070CC', cursor: 'pointer' }} onClick={updateCluster}>
              {intl('mse.register.instance.upgrade')}
            </span>
            )
            <CommonBalloon align="r" content={intl.html('mse.register.app_version.up.message1')}>
              <Icon type="help" className="common-help-icon" />
            </CommonBalloon>
          </span>
        </If>
      </div>
      <UpdateVersionDialog
        visible={upVisible}
        value={clusterData}
        onOk={() => {
          setUpVisible(false);
          setRefreshIndex();
        }}
        onCancel={() => setUpVisible(false)}
        onClose={() => setUpVisible(false)}
      />
    </React.Fragment>
  );
};

export default RenderAppVersion;
