import React from 'react';
import { mapValues } from 'lodash';

/**实例类型 */
const RenderClusterType = ({ value }) => {
  const CLUSTER_NAME_MAP = mapValues(window.CLUSTER_NAME_MAP, value => value.label);
  return <span>{CLUSTER_NAME_MAP[value] || ''}</span>;
};

export default RenderClusterType;
