import React from 'react';
import intl from '@ali/wind-intl';
import { formatDate } from 'utils';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/

// 付款方式
const RenderPayType = (props) => {
  const { payType, CreateTime, EndDate } = props.value;
  if (payType === 'POSTPAY') {
    // 按量付费
    return (
      <div>
        <div>{intl('mse.register.payment.postpay')}</div>
        <div>
          {intl('mse.common.create.time')}：{formatDate(CreateTime)}
        </div>
      </div>
    );
  }
  if (payType === 'PREPAY') {
    let islastday = false;
    if (EndDate) {
      islastday = window.moment().isAfter(EndDate);
    }
    return (
      <div style={{ minWidth: 136 }}>
        <div>{intl('mse.register.payment.prepay')}</div>
        <div>
          {intl('mse.common.create.time')}：{formatDate(CreateTime)}
        </div>
        <div>
          {intl('mse.common.expire.time')}：
          <span style={{ color: 'green' }}>{formatDate(EndDate)}</span>{' '}
          <If condition={islastday}>
            <span style={{ color: 'red' }}>{intl('mse.common.expired')}</span>{' '}
          </If>
        </div>
      </div>
    );
  }
  return <span>{intl('mse.common.beta')}</span>;
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default RenderPayType;
