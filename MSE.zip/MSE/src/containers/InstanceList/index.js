import React, { useState, useEffect, useRef } from 'react';
import { TableContainer, TagContainer } from '@ali/cn-design';
import RenderAliasName from './components/RenderAliasName';
import RenderClusterType from './components/RenderClusterType';
import RenderStatus from './components/RenderStatus';
import RenderIp from './components/RenderIp';
import RenderPayType from './components/RenderPayType';
import RenderOptions from './components/RenderOptions';
import RenderMseVersion from './components/RenderMseVersion';
import RenderAppVersion from './components/RenderAppVersion';
import { includes, find, get, map, concat } from 'lodash';
import { Button } from '@ali/wind';
import services from 'utils/services';
import UpdateVertionDialog from './components/UpdateVersionDialog';
import TagsResourceDialog from '../../components/TagsResource/TagsResourceDialog';
import SearchTag from '../../components/TagsResource/SearchTag';
import intl from '@ali/wind-intl';
import { IS_SAU_BUSINESS } from 'constants/index.js';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
const { ColumnTag } = TagContainer;
const { MultipleSearchTag } = TableContainer;

const ResourceGroupId = aliwareGetCookieByKeyName('console_base_resource_group_id') || '';
const InstanceList = (props) => {
  const [refreshIndex, setRefreshIndex] = useState(0);
  const [loop, setLoop] = useState({ enable: false, time: 3000 });
  const [clusterData, setClusterData] = useState({});
  const [updateVertionDialogVisible, setUpdateVertionDialogVisible] = useState(false);
  const [tagsDialogVisible, setTagsDialogVisible] = useState(false);
  const [tags, setTags] = useState([]);
  const [filterTags, setFilterTags] = useState([]);
  const [instanceIdGroup, setInstanceIdGroup] = useState([]);
  const [tagKeys, setTagKeys] = useState([]);
  const [tagValues, setTagValues] = useState([]);
  const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
  const isIntl = aliyunSite === 'INTL';

  /**获取数据 */
  const getClustersList = ({
    params: { pageNumber = 1, pageSize = 10, ClusterAliasName = '', ...params },
    noerror = false,
  }) => {
    return new Promise((resolve, reject) => {
      request({
        url: 'com.alibaba.MSE.service.clusterList',
        data: {
          ClusterAliasName,
          pageNum: pageNumber,
          pageSize,
          ...params,
        },
        noerror,
        beforeSend: () => {},
        success: (res) => {
          if (res.code === '200' && res.data) {
            let { Data, TotalCount } = res.data;
            Data.forEach((item) => {
              /**组装 【实例ID/名称】 数据 */
              item.InstanceCollection = {
                InstanceId: item.InstanceId,
                ClusterAliasName: item.ClusterAliasName,
                ClusterId: item.ClusterId,
                ClusterType: item.ClusterType,
                AppVersion: item.AppVersion,
                InitStatus: item.InitStatus,
                MseVersion: item.MseVersion,
                ChargeType: item.ChargeType,
              };
              /**组装 【访问方式】 数据 */
              item.visitMethodCollection = {
                InternetDomain: item.InternetDomain,
                IntranetDomain: item.IntranetDomain,
              };
              /**组装 【付款方式】 数据 */
              item.payTypeCollection = {
                payType: item.ChargeType,
                CreateTime: item.CreateTime,
                EndDate: item.EndDate,
              };
              /**组装 【操作】数据 */
              item.operationsCollection = {
                ClusterName: item.ClusterAliasName,
                ClusterType: item.ClusterType,
                AppVersion: item.AppVersion,
                ChargeType: item.ChargeType,
                InstanceId: item.InstanceId,
                ClusterId: item.ClusterId,
                InitStatus: item.InitStatus,
                CanUpdate: item.CanUpdate,
                VersionCode: item.VersionCode,
                MseVersion: item.MseVersion,
              };
            });
            const result = {
              Data,
              TotalCount,
            };
            // setCurrentData(result);
            resolve(result);
          }
        },
        complete: (res) => {
          if (
            res.responseJSON.code === 'InvalidRegion' ||
            res.responseJSON.data.ErrorCode === 'NoPermission'
          ) {
            const result = {
              Data: [],
              TotalCount: 0,
            };
            // setCurrentData(result);
            resolve(result);
          }
        },
      });
    });
  };

  const fetchData = async (params) => {
    const tagsObj = {};
    if (filterTags && filterTags.length) {
      filterTags.forEach((item, index) => {
        tagsObj[`Tag.${index + 1}.Key`] = item.key;
        tagsObj[`Tag.${index + 1}.Value`] = item.value;
      });
    }
    const { pageSize = 10, pageNumber = 1, InstanceCollection = '' } = params;
    const result = await getClustersList({
      params: {
        pageSize,
        pageNumber,
        ClusterAliasName: InstanceCollection,
        ResourceGroupId: ResourceGroupId,
        ...tagsObj,
      },
    });
    const successArr = ['INIT_ING', 'DESTROY_ING', 'RESTART_ING', 'SCALE_ING'];
    const hasIng = find(result.Data, (item) => includes(successArr, item.InitStatus));
    if (hasIng) {
      setLoop({ enable: true, time: 10000 });
    } else {
      setLoop({ enable: false, time: 10000 });
    }
    return {
      Data: result.Data,
      TotalCount: result.TotalCount,
    };
  };

  const updateCluster = async ({ VersionCode, ClusterId, InstanceCount }) => {
    const Data = await services.GetImage({
      params: { VersionCode },
    });
    setClusterData({ ...Data, ClusterId, InstanceCount });
    setUpdateVertionDialogVisible(true);
  };

  const { regionId } = props;

  /**TableContainer设置列表显示项 */
  const columns = [
    {
      key: 'InstanceCollection',
      title: intl('mse.register.instance'),
      dataIndex: 'InstanceCollection',
      lock: 'left',
      width: 250,
      cell: (value) => <RenderAliasName value={value} />,
    },
    {
      key: 'Tags',
      title: intl('mse.tag.button'),
      dataIndex: 'Tags',
      width: 80,
      cell: (value, index, record) => {
        const values = value ?? {};
        const data = Object.keys(values).map((i) => {
          return { key: i, value: value[i] };
        });
        const customKeys = data.filter((i) => !i.key.includes('acs:'));
        return (
          <ColumnTag dataSource={data} onClick={() => handleOpenTagsDialog(customKeys, record)} />
        );
      },
    },
    {
      key: 'MseVersion',
      title: intl('mse.register.instance.version'),
      dataIndex: 'MseVersion',
      width: 150,
      cell: (value, index, record) => <RenderMseVersion record={record} />,
    },
    {
      key: 'ClusterType',
      width: 100,
      title: intl('mse.register.cluster'),
      dataIndex: 'ClusterType',
      cell: (value) => <RenderClusterType value={value} />,
    },
    {
      key: 'AppVersion',
      title: intl('mse.register.instance.engine'),
      dataIndex: 'AppVersion',
      width: 100,
      cell: (value, index, record) => (
        <RenderAppVersion record={record} setRefreshIndex={() => setRefreshIndex(Date.now())} />
      ),
    },
    {
      key: 'InitStatus',
      title: intl('mse.register.state'),
      dataIndex: 'InitStatus',
      width: 120,
      cell: (value, index, record) => (
        <RenderStatus
          value={value}
          record={record}
          setRefreshIndex={() => setRefreshIndex(Date.now())}
        />
      ),
    },
    {
      key: 'visitMethodCollection',
      title: intl('mse.register.access'),
      dataIndex: 'visitMethodCollection',
      width: 350,
      cell: (value) => <RenderIp value={value} />,
    },
    {
      key: 'payTypeCollection',
      title: intl('mse.register.payment'),
      dataIndex: 'payTypeCollection',
      width: 250,
      cell: (value) => <RenderPayType value={value} />,
    },
    {
      key: 'operationsCollection',
      title: intl('mse.common.operate'),
      dataIndex: 'operationsCollection',
      width: 180,
      lock: 'right',
      cell: (value) => (
        <RenderOptions value={value} setRefreshIndex={() => setRefreshIndex(Date.now())} />
      ),
    },
  ];

  const getTagkeys = async () => {
    const params = {
      RegionId: window.regionId,
      ResourceType: 'ALIYUN::MSE::CLUSTER',
    };
    const {
      Keys: { Key = [] },
    } = await services.ListTagKeys({
      params: params,
    });
    const res = Key.map((k) => k.Key);
    setTagKeys(res);
  };

  const getTagValues = async (key) => {
    const params = {
      RegionId: window.regionId,
      ResourceType: 'ALIYUN::MSE::CLUSTER',
      Key: key,
    };
    const {
      Values: { Value = [] },
    } = await services.ListTagValues({ params: params });
    setTagValues(Value);
  };

  const handleChangeSearchKey = (key) => {
    getTagValues(key);
  };

  const handleConfirmTags = (val) => {
    const data = filterTags.find((tag) => tag.key === val.key);
    if (data) {
      const res = filterTags.map((tag) => {
        return tag.key === val.key ? { key: tag.key, value: val.value } : tag;
      });
      setFilterTags(res);
    } else {
      const res = concat(filterTags, val);
      setFilterTags(res);
    }
  };

  const onRemoveTag = (index, value, item) => {
    const res = filterTags.filter((tag) => {
      return !(tag.key === item.key && tag.value === item.value);
    });
    setFilterTags(res);
    setRefreshIndex(Date.now());
  };

  const onRemoveAllTags = () => {
    setFilterTags([]);
    setRefreshIndex(Date.now());
  };

  /**TableContainer设置搜索栏 */
  const search = (intl) => ({
    filterInfo: {
      filters: [
        {
          label: intl('mse.register.instance'),
          value: 'InstanceCollection',
          placeholder: intl('mse.register.instance_placeholder'),
        },
      ],
      defaultValue: 'InstanceCollection',
    },
    renderChildren: (
      <div style={{ display: 'flex', float: 'left', marginRight: 12 }}>
        <SearchTag
          tagKeys={tagKeys}
          tagValues={tagValues}
          onClick={getTagkeys}
          onChangeKey={handleChangeSearchKey}
          onConfirm={handleConfirmTags}
        />
      </div>
    ),
    renderMultipleSearch: () => (
      <MultipleSearchTag
        dataSource={map(filterTags, (item) => {
          const { key, value } = item;
          return {
            label: `${intl('mse.tag.key')}：${key}`,
            key,
            value,
            valueLabel: value ? `${intl('mse.tag.value')}：${value}` : '',
          };
        })}
        onRemove={(index, value, item) => onRemoveTag(index, value, item)}
        onRemoveAll={onRemoveAllTags}
      />
    ),
    isCanCustomColumns: true,
    isCanMultipleSearch: true,
    isCanRefresh: true,
  });

  /**创建实例 */
  const createInstance = () => {
    const VirtualNetwork = ['JST', 'CAINIAO', 'NEW_RETAIL'];
    const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
    let commodityCode = 'mse_prepaid_public_cn';
    let createDomain = 'https://common-buy.aliyun.com';
    if (includes(VirtualNetwork, channel)) {
      createDomain = 'https://common-buy4service.aliyun.com';
      if (channel === 'CAINIAO') {
        commodityCode = 'mse_prepaid_public_cn_cainiao';
      }
    }
    let createUrl = `${createDomain}/?spm=ntm.workbench-commodities-list.0.0.d7ef19afimDPmG&commodityCode=${commodityCode}&regionId=${regionId}#/buy`;
    if (isIntl) {
      commodityCode = 'mse_prepaid_public_intl';
      createDomain = 'https://common-buy-intl.alibabacloud.com';
      createUrl = `${createDomain}/?commodityCode=${commodityCode}`;
    }
    if (IS_SAU_BUSINESS) {
      createUrl = `https://common-buy-intl4service.alibabacloud.com/?commodityCode=mse_prepaid_public_intl&regionId=me-central-1`;
    }
    window.open(createUrl);
  };

  const handleOpenTagsDialog = (data, record) => {
    setInstanceIdGroup([{ resourceId: record.InstanceId, resourceName: record.ClusterAliasName }]);
    setTags(data);
    setTagsDialogVisible(true);
  };

  const handleRefresh = () => {
    setRefreshIndex(Date.now());
    getTagkeys();
  };

  useEffect(() => {
    if (filterTags && filterTags.length) {
      setRefreshIndex(Date.now());
    }
  }, [filterTags]);

  useEffect(() => {
    if (ResourceGroupId) {
      setRefreshIndex(Date.now());
    }
  }, [ResourceGroupId]);

  return (
    <React.Fragment>
      <TableContainer
        fetchData={fetchData}
        primaryKey="InstanceId"
        columns={columns}
        search={search(intl)}
        refreshIndex={refreshIndex}
        pagination={{ hideOnlyOnePage: false, pageSize: 10 }}
        loop={loop}
        operation={() => (
          <Button type="primary" onClick={createInstance}>
            {intl('mse.register.create')}
          </Button>
        )}
        emptyContent={<span>{intl('mse.common.no_data')}</span>}
      />
      <UpdateVertionDialog
        visible={updateVertionDialogVisible}
        value={clusterData}
        onOk={() => {
          setUpdateVertionDialogVisible(false);
          setRefreshIndex(Date.now());
        }}
        onCancel={() => setUpdateVertionDialogVisible(false)}
        onClose={() => setUpdateVertionDialogVisible(false)}
      />
      <TagsResourceDialog
        visible={tagsDialogVisible}
        onCancel={() => setTagsDialogVisible(false)}
        onClose={() => setTagsDialogVisible(false)}
        dataSource={tags}
        resourceGroup={instanceIdGroup}
        onRefresh={handleRefresh}
      />
    </React.Fragment>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default InstanceList;
