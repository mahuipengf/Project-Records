import React from 'react';
import AhasLayout from '../AhasLayout';
import {
  AhasProtect,
  AhasApiDetails,
  AhasHotSpotMonitor,
  AhasMachineManage,
  AhasRuleManage,
  AhasSenceWeb,
  AhasAppManage,
  AhasClusterControlConfig,
  AhasClusterControlDetails,
  AhasAlarmManageRule,
  AhasAlarmManageDetails,
  AhasSingleChip,
} from 'pages/msc/Ahas';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * AHAS应用防护
 */
const AppProtect = ({ AppName = '', breadCrumbSubsetTitle = [] }) => {
  const menu = [
      {
        key: '/ahas/protect',
        label: intl('mse.msc.protect.overview'),
        tag: 'protect',
        visible: true,
      },
      {
        key: '/ahas/protect/apiDetails',
        label: intl('mse.msc.protect.apiDetails'),
        tag: 'apiDetails',
        visible: true,
      },
      {
        key: '/ahas/protect/hotSpotMonitor',
        label: intl('mse.msc.protect.hotSpotMonitor'),
        tag: 'hotSpotMonitor',
        visible: true,
      },
      {
        key: '/ahas/protect/machineManage',
        label: intl('mse.msc.protect.machineManage'),
        tag: 'machineManage',
        visible: true,
      },
      {
        key: '/ahas/protect/ruleManage',
        label: intl('mse.msc.protect.ruleManage'),
        tag: 'ruleManage',
        visible: true,
      },
      {
        key: '/ahas/protect/sence',
        label: intl('mse.msc.protect.sence'),
        visible: true,
        tag: 'sence',
        items: [
          {
            key: '/ahas/protect/sence/web',
            label: intl('mse.msc.protect.sence.web'),
            tag: 'sence_web',
            visible: true,
          }
        ]
      },
      {
        key: '/ahas/protect/appManage',
        label: intl('mse.msc.protect.appManage'),
        tag: 'appManage',
        visible: true,
      },
      {
        key: '/ahas/protect/clusterControl',
        label: intl('mse.msc.protect.clusterControl'),
        tag: 'clusterControl',
        visible: true,
        items: [
          {
            key: '/ahas/protect/clusterControl/config',
            label: intl('mse.msc.protect.clusterControl.config'),
            tag: 'clusterControl_config',
            visible: true,
          },
          {
            key: '/ahas/protect/clusterControl/details',
            label: intl('mse.msc.protect.clusterControl.details'),
            tag: 'clusterControl_details',
            visible: true,
          }
        ]
      },
      {
        key: '/ahas/protect/alarmManage',
        label: intl('mse.msc.protect.alarmManage'),
        tag: 'alarmManage',
        visible: true,
        items: [
          {
            key: '/ahas/protect/alarmManage/rule',
            label: intl('mse.msc.protect.alarmManage.rule'),
            tag: 'alarmManage_rule',
            visible: true,
          },
          {
            key: '/ahas/protect/alarmManage/details',
            label: intl('mse.msc.protect.alarmManage.details'),
            tag: 'alarmManage_details',
            visible: true,
          }
        ]
      },
      {
        key: '/ahas/protect/singleChip',
        label: intl('mse.msc.protect.singleChip'),
        tag: 'singleChip',
        visible: true,
      }
  ];
  const map = {
    protect: <AhasProtect AppName={AppName} />,
    apiDetails: <AhasApiDetails AppName={AppName} />,
    hotSpotMonitor: <AhasHotSpotMonitor AppName={AppName} />,
    machineManage: <AhasMachineManage AppName={AppName} />,
    ruleManage: <AhasRuleManage AppName={AppName} />,
    sence_web: <AhasSenceWeb AppName={AppName} />,
    appManage: <AhasAppManage AppName={AppName} />,
    clusterControl_config: <AhasClusterControlConfig AppName={AppName} />,
    clusterControl_details: <AhasClusterControlDetails AppName={AppName} />,
    alarmManage_rule: <AhasAlarmManageRule AppName={AppName} />,
    alarmManage_details: <AhasAlarmManageDetails AppName={AppName} />,
    singleChip: <AhasSingleChip AppName={AppName} />,
  };
  const map_title = {
    protect: intl('mse.msc.protect.overview'),
    apiDetails: intl('mse.msc.protect.apiDetails'),
    hotSpotMonitor: intl('mse.msc.protect.hotSpotMonitor'),
    machineManage: intl('mse.msc.protect.machineManage'),
    ruleManage: intl('mse.msc.protect.ruleManage'),
    sence_web: intl('mse.msc.protect.sence.web'),
    appManage: intl('mse.msc.protect.appManage'),
    clusterControl_config: intl('mse.msc.protect.clusterControl.config'),
    clusterControl_details: intl('mse.msc.protect.clusterControl.details'),
    alarmManage_rule: intl('mse.msc.protect.alarmManage.rule'),
    alarmManage_details: intl('mse.msc.protect.alarmManage.details'),
    singleChip: intl('mse.msc.protect.singleChip')
  };
  return (
    <div style={{ height: '100%' }}>
        <AhasLayout
          menu={menu}
          map={map}
          title={AppName}
          map_title={map_title}
          initial="protect"
          url="/msc/protect"
          breadCrumbSubsetTitle={breadCrumbSubsetTitle}
        />
    </div>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AppProtect;
