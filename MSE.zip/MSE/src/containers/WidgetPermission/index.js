import React, { useEffect, useState } from 'react';
import { MstWidget, MscWidget } from 'utils/loadWidget';
import { isEmpty, includes, get } from 'lodash';
import AccountPermission from '../AccountPermission';
import { useStateStore } from '../../store';
// import RoleHoc from '../RoleHoc';
import RoleAuth from '../RoleAuth';

// const MstHoc = RoleHoc(MstWidget); // mst 的 widget 属于专业版才有的功能
const Loading = () => {
  const [show, setShow] = useState(0);
  useEffect(() => {
    setTimeout(() => {
      setShow(true);
    }, 300);
  });
  return show ? 'Loading' : '';
};

export default ({ widget, widgetProps }) => {
  const MscAuth = RoleAuth(MscWidget, widgetProps.component); // 专业版才有的功能
  const state = useStateStore();

  if (isEmpty(state)) {
    return <Loading />;
  }

  const Status = get(state, 'MscAccount.Status');
  const TimeLeft = get(state, 'MscAccount.TimeLeft', 0);

  return (
    <React.Fragment>
      {/* 公测过期，新用户，欠费停机 */}
      <If condition={(Status === 0 && TimeLeft === 0) || Status === 1 || Status === 3}>
        <If condition={!includes(['Home', 'AppList', 'AppAccessType'], widgetProps.component)}>
          <AccountPermission />
        </If>
        <If condition={includes(['Home', 'AppList', 'AppAccessType'], widgetProps.component)}>
          <MscWidget {...widgetProps} />
        </If>
      </If>
      {/* 公测有效期，商业化版可用 */}
      <If condition={(Status === 0 && TimeLeft > 0) || Status === 2}>
        <If condition={widget === 'mst'}>
          <MstWidget {...widgetProps} />
        </If>
        <If condition={widget === 'msc'}>
          {/* 专业版 */}
          <If condition={includes(['FullLinkGrayscalekHome'], widgetProps.component)}>
            <MscAuth {...widgetProps} />
          </If>
          {/* 基础版 */}
          <If condition={!includes(['FullLinkGrayscalekHome'], widgetProps.component)}>
            <MscWidget {...widgetProps} />
          </If>
        </If>
      </If>
    </React.Fragment>
  );
};

