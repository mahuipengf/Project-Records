// sc 的 path 选择输入组件
import React, { useState } from 'react';
import intl from '@ali/wind-intl';
import { Input, Select } from '@ali/cn-design';

const ScPath = (props) => {
  const { value, dataSource = [], ...rest } = props;
  const [isSelect, setIsSelect] = useState(true);

  return (
    <React.Fragment>
      <If condition={isSelect}>
        <Select value={value} dataSource={dataSource} followTrigger {...rest} />
      </If>
      <If condition={!isSelect}>
        <Input value={value} {...rest} />
      </If>
      <span style={{ marginLeft: 4 }} className="link-primary" onClick={() => setIsSelect(!isSelect)}>{isSelect ? intl('widget.sc_change_input') : intl('widget.sc_change_select')}</span>
    </React.Fragment>
  );
};

export default ScPath;
