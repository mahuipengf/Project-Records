import ConditionList from 'containers/ConditionList';
import DataFields from 'components/DataFields';
import IstioTagTable from '../../../src/pages/msc/Ahas/AppList/AppListSub/FlowGovernment/RouteManage/components/IstioTagTable';
import React, { useEffect, useState } from 'react';
import intl from '@ali/wind-intl';
import { Empty, Loading } from '@ali/cn-design';
import { If } from 'components/tsx-control';
import { get, isEmpty, map } from 'lodash';
import { lowerFirstData } from 'utils/transfer-data';
import { mapConditions } from 'utils/index.js';
import { useDispatch } from '@ali/sre-utils-dva';

interface IRouteInfo {
  id?: number;
  appId?: string;
  style?: any;
  value?: any;
  callback?: any;
}
const RouteInfo = (props: IRouteInfo) => {
  const getParams = window.getParams;
  const { id, appId, style, callback, value } = props;
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState(value || {});
  const regionId = getParams('region');
  const namespaceId = getParams('namespaceId');
  const dispatch = useDispatch();

  useEffect(() => {
    if (id) {
      fetchData(id);
    }
  }, [id]);

  useEffect(() => {
    if (appId) {
      fetchCanaryPolicy(appId);
    }
  }, [appId]);

  const fetchCanaryPolicy = async (Id: any) => {
    const params = {
      regionId,
      namespaceId,
      appId: Id,
    };
    setIsLoading(true);
    const { Data: res } = await dispatch.flowAppModel.getCanaryPolicy({
      ...params,
    }) || {};
    const { id } = lowerFirstData(res);
    if (id) {
      fetchData(id);
    } else {
      setIsLoading(false);
    }
  };

  const fetchData = async (Id: any) => {
    const params = {
      regionId,
      namespaceId,
      policyId: Id,
    };
    setIsLoading(true);
    let { Data: res } = await dispatch.flowAppModel.getRoutePolicy({
      ...params,
    }) || {};
    res = lowerFirstData(res) || {};
    setIsLoading(false);
    const scRules = get(res, 'scRules', []);
    const newScRules = map(scRules, item => {
      const conditions = mapConditions(item.restItems);
      return { ...item, conditions, protocol: 'springCloud' };
    });
    const dubboArgRules = get(res, 'dubboArgRules', []);
    const newDubboRules = map(dubboArgRules, item => {
      const conditions = mapConditions(item.argumentItems);
      return { ...item, conditions, protocol: 'dubbo' };
    });
    callback && callback({ ...res, rules: [...newScRules, ...newDubboRules] });
    setData({ ...res, rules: [...newScRules, ...newDubboRules], isIstioApp: !isEmpty(res.istioRules) });
  };

  const CONDITION = { OR: intl('widget.route.condition_or'), AND: intl('widget.route.condition_and') };

  const protocol = { springCloud: 'Spring Cloud', dubbo: 'Dubbo' };

  const getItems = (item: any) => [
    {
      dataIndex: 'protocol',
      label: intl('widget.route.frame_type'),
      visible: true,
      render: val => protocol[val],
    },
    {
      dataIndex: 'condition',
      label: intl('widget.route.condition_mode'),
      visible: true,
    },
    {
      dataIndex: 'path',
      label: intl('widget.route.path'),
      visible: item.protocol === 'springCloud',
    },
    {
      dataIndex: 'service',
      label: intl('widget.app.service_method'),
      visible: item.protocol === 'dubbo',
      span: 24,
    },
    {
      dataIndex: 'conditions',
      label: intl('widget.route.condition_list'),
      visible: !item.isIstioApp,
      span: 24,
      render: (val: any) => <ConditionList value={val} show protocol={item.protocol} />,
    },
  ];

  return (
    <Loading style={{ width: '100%', ...style }} visible={isLoading}>
      <If condition={isEmpty(data)}>
        <Empty showIcon emptyMessage={intl('widget.common.no_data')} />
      </If>
      <If condition={!isEmpty(data)}>
        <If condition={!data.isIstioApp && data.triggerPolicy === 'CONTENT'}>
          {
            map(data.rules, (item: any, index: any) => {
              return (
                <div key={index} className="common-box">
                  <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.app.flow_rule', { n: index + 1 })}</div>
                  <DataFields
                    key={index}
                    dataSource={{
                      condition: CONDITION[item.condition],
                      path: item.path,
                      service: `${item.serviceName || ''}:${item.version || ''}:${item.group || ''} / ${item.methodName || ''} (${item.paramTypes || ''})`,
                      conditions: item.conditions || [],
                      protocol: item.protocol,
                    }}
                    items={getItems(item)}
                    style={{ padding: '8px 0', borderBottom: 0 }}
                  />
                </div>
              );
            })
          }
          {/* <For each="item" index="index" of={data.rules}>
            <div key={index} className="common-box">
              <div style={{ margin: '-8px -16px 0', background: '#f2f2f2', padding: '8px 16px', borderBottom: '1px solid #eee' }}>{intl('widget.app.flow_rule', { n: index + 1 })}</div>
              <DataFields
                key={index}
                dataSource={{
                  condition: CONDITION[item.condition],
                  path: item.path,
                  service: `${item.serviceName || ''}:${item.version || ''}:${item.group || ''} / ${item.methodName || ''} (${item.paramTypes || ''})`,
                  conditions: item.conditions || [],
                  protocol: item.protocol,
                }}
                items={getItems(item)}
                style={{ padding: '8px 0', borderBottom: 0 }}
              />
            </div>
          </For> */}
        </If>
        <If condition={data.isIstioApp}>
          <IstioTagTable appId={data.appId} show />
        </If>
      </If>
    </Loading>
  );
};

export default RouteInfo;
