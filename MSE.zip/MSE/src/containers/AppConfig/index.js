import React from 'react';
import AppOpen from 'pages/msc/App/AppSub/AppOpen';
import HistoryRecords from 'pages/msc/App/AppSub/HistoryRecords';
import NodeList from 'pages/msc/App/AppSub/NodeList';
import AhasLayout from '../AhasLayout';
import intl from '@ali/wind-intl';

/*****************************此行为标记行, 请勿删和修改此行, 文件和组件依赖请写在此行上面, 主体代码请写在此行下面的class中*****************************/
/**
 * SWITCH应用配置
 */
const AppConfig = ({ AppName = '', breadCrumbSubsetTitle = [] }) => {
  const menu = [
    {
      key: '/msc/config/open',
      label: intl('mse.msc.config.applist'),
      activePathPatterns: ['/msc/config/open'],
      to: '/msc/config/open',
      tag: 'open',
      visible: true,
    },
    {
      key: '/msc/config/histroy',
      label: intl('mse.msc.config.histroy'),
      activePathPatterns: ['/msc/config/history'],
      to: '/msc/config/history',
      tag: 'history',
      visible: true,
    },
    {
      key: '/msc/config/nodelist',
      label: intl('mse.msc.config.nodelist'),
      activePathPatterns: ['/msc/config/nodelist'],
      to: '/msc/config/nodelist',
      tag: 'nodelist',
      visible: true,
    },
  ];
  const map = {
    open: <AppOpen AppName={AppName} />,
    history: <HistoryRecords AppName={AppName} />,
    nodelist: <NodeList AppName={AppName} />
  };
  const map_title = {
    open: intl('mse.msc.config.applist'),
    history: intl('mse.msc.config.histroy'),
    nodelist: intl('mse.msc.config.nodelist'),
  };
  return (
      <div style={{ height: '100%' }}>
          <AhasLayout
            menu={menu}
            map={map}
            map_title={map_title}
            initial="open"
            title={AppName}
            url={'/msc/config'}
            breadCrumbSubsetTitle={breadCrumbSubsetTitle}
          />
      </div>
  );
};
/*****************************此行为标记行, 请勿删和修改此行, 主体代码请写在此行上面的class中, 组件导出语句及其他信息请写在此行下面*****************************/
export default AppConfig;
