import React from 'react';
import NoPermission from './NoPermission';
import { Button } from '@alicloud/console-components';
import { useStateStore } from '../../store';
import { get, includes } from 'lodash';
import intl from '@ali/wind-intl';
import { IS_SAU_BUSINESS } from 'constants/index.js';

const AccountPermission = () => {
  const state = useStateStore();
  const aliyunSite = aliwareGetCookieByKeyName('aliyun_site');
  const Status = get(state, 'MscAccount.Status');
  const TimeLeft = get(state, 'MscAccount.TimeLeft', 0);
  const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
  let openHref = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn';
  let rechargeHref = 'https://usercenter2.aliyun.com/finance/fund-management/recharge';
  if (includes(['JST', 'NEW_RETAIL'], channel)) {
    openHref = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn'; // https://common-buy4service.aliyun.com/?commodityCode=mse_basic_public_cn
    rechargeHref = 'https://usercenter24service.aliyun.com/finance/fund-management/recharge';
  }
  if (aliyunSite === 'INTL') {
    openHref = 'https://common-buy-intl.alibabacloud.com/?commodityCode=mse_basic_public_intl';
    rechargeHref =
      'https://usercenter2-intl.aliyun.com/renew/manual?spm=5176.mse-ops.top-nav.ditem-ren.36c3142fCQOCud&expiresIn=&commodityCode=';
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center', margin: 100 }}>
      <NoPermission style={{ width: 120, height: 120, marginRight: 16 }} />
      {/* 公测用户 */}
      <If condition={Status === 0 && TimeLeft === 0}>
        <div>
          <h5 style={{ margin: '16px 0 0' }}>{intl('mse.common.no_account_promise')}</h5>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500 }}>{intl.html('mse.common.public.beta.version.zero.data')}</div>
          <a href={openHref} target="_blank">
            <Button type="primary">{intl('mse.common.publc.beta.to.commercialize')}</Button>
          </a>
        </div>
      </If>
      {/* 新用户 */}
      <If condition={Status === 1}>
        <div>
          <h5 style={{ margin: '16px 0 0' }}>{intl('mse.common.no_account_promise')}</h5>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500 }}>{intl.html('mse.account.promisse.no.message', { openHref })}</div>
          <a href={openHref} target="_blank">
            <Button type="primary">{intl('mse.account.promission.active.now')}</Button>
          </a>
        </div>
      </If>
      {/* 欠费停机 */}
      <If condition={Status === 3}>
        <div>
          <h5 style={{ margin: '16px 0 0' }}>{intl('mse.account.promission.arrears')}</h5>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500 }}>{intl.html('mse.account.promisse.shut.down', { rechargeHref })}</div>
          <Button type="primary" style={{ padding: 0 }}>
            <a href={rechargeHref} target="_blank" style={{ color: '#fff', padding: ' 8px 16px' }}>{intl('mse.common.recharge')}</a>
          </Button>
        </div>
      </If>
    </div>
  );
};

export default AccountPermission;

