import React, { useEffect, useState } from 'react';
import { Button } from '@ali/cn-design';
import NoPermission from '../AccountPermission/NoPermission';
import AhasPermissionOpen from 'components/AhasProtectPermission';
import services from 'utils/services';
import { useStateStore } from '../../store';
import { get } from 'lodash';
import intl from '@ali/wind-intl';

const AhasPermission = (props) => {
  const { urlParams, children, tag, goHistory = '' } = props;
  const [visible, setVisible] = useState(true);
  const state = useStateStore();
  const Status = get(state, 'MscAccount.Status');
  const Version = get(state, 'MscAccount.Version');

  useEffect(() => {
    setTimeout(() => setVisible(false), 1000);
    }, [urlParams]);

  return (
    <React.Fragment>
      <If condition={(tag === 'config' && Status === 2) || (tag === 'protect' && Status === 2 && Version === 2) || (tag === 'flow_protect' && Status === 2 && Version === 2) || (tag === 'flow_protect_appList' && Status === 2)}>
        {children}
      </If>
      <If condition={(tag === 'config' && (!Status || Status === 1)) || (tag === 'protect' && (Status !== 2 || (Status === 2 && Version !== 2))) || (tag === 'flow_protect' && (Status !== 2 || (Status === 2 && Version !== 2))) || (tag === 'flow_protect_appList' && Status !== 2)}>
        <If condition={!visible}>
          <AhasPermissionOpen tag={tag} goHistory={goHistory} />
        </If>
      </If>
    </React.Fragment>
  );
};

export default AhasPermission;
