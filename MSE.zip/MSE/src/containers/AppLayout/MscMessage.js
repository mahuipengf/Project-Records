import React from 'react';
import { Message } from '@ali/wind';
import { includes } from 'lodash';
import intl from '@ali/wind-intl';

// 微服务治理开服区域
// 字典序
const mscRegion = [
  'ap-northeast-1',
  'ap-south-1',
  'ap-southeast-1',
  'ap-southeast-2',
  'ap-southeast-3',
  'ap-southeast-5',
  'cn-beijing',
  'cn-chengdu',
  'cn-hangzhou',
  'cn-heyuan',
  'cn-hongkong',
  'cn-huhehaote',
  'cn-shanghai',
  'cn-shenzhen',
  'cn-zhangjiakou',
  'eu-central-1',
  'eu-west-1',
  'us-east-1',
  'us-west-1',
  'cn-qingdao',
  'cn-guangzhou',
  'ap-southeast-6',
  'cn-shenzhen-finance-1',
  'cn-shanghai-finance-1',
  'cn-wulanchabu',
];
const mscRegion_INIT = [
  'ap-southeast-1',
  'cn-hongkong',
];
const MscMessage = props => {
  // 国际站region发布
  // const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
  // let Regions = aliyunSite === 'INTL' ? mscRegion_INIT : mscRegion;
  const { regions = mscRegion } = props;

  return (
    <React.Fragment>
      <If condition={!includes(regions, window.regionId) && window.location.hash.indexOf('#/msc') > -1}>
        <Message type="notice" style={{ color: '#f68300', margin: '16px 0px 0px' }}>
          {intl('mse.common.not.opened.message')}
        </Message>
      </If>
    </React.Fragment>
  );
};


export default MscMessage;
