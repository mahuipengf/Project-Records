import React, { Suspense, useRef, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import Page from '@ali/wind-rc-page';
import { Message } from '@ali/wind';
import BreadLayout from '../../components/common/BreadLayout';
import { isEmpty } from 'lodash';
import PreEnvSelector from 'components/PreEnvSelector';
import { IS_PRE_OR_LOCAL } from 'constants';
import MscMessage from './MscMessage';
import Announcement from '@ali/wind-rc-announcement';

const AppLayout = props => {
  const {
    breadCrumbList = [],
    announcement = [],
    breadCrumbExpand,
    title = '',
    children,
    message = [],
    isKeepCrumb = true,
    productName = '',
    target = '',
    isShowNamespace,
  } = props;
  const [offsetHeight, setoffSetHeight] = useState(0);

  const headerElment = useRef(null);

  useEffect(() => {
    setoffSetHeight(headerElment.current.offsetHeight);
  }, [announcement]);

  return (
    <div style={{ position: 'relative', height: '100%', background: '#fff' }}>
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          padding: '0 24px',
          background: '#fff',
          zIndex: 100,
          boxShadow: '0 4px 8px -5px rgba(0, 0, 0, 0.1)',
        }}
        ref={headerElment}
      >
        <If condition={!isEmpty(announcement)}>
          <div style={{ margin: '16px 0', height: 38 }}>
            <Announcement
              announcementList={announcement}
              dangerouslyRenderAsInnerHTML
              style={{ background: 'red' }}
              className="mse-announcement"
            />
          </div>
        </If>
        <MscMessage />
        <If condition={!isEmpty(message)}>
          <div style={{ paddingTop: 8 }}>
            <For each="item" index="index" of={message}>
              <Message key="index" type={item.type} style={{ color: '#f68300', margin: '8px 0 8px' }}>
                {item.text}
              </Message>
            </For>
          </div>
        </If>
        <If condition={isKeepCrumb}>
          <BreadLayout breadCrumbList={breadCrumbList} breadCrumbExpand={breadCrumbExpand} productName={productName} target={target} isShowNamespace={isShowNamespace} />
        </If>
        <Page.Header title={title} childrenAlign="left" style={{ padding: 0 }} />
      </div>
      <div id="mse-page-content" style={{ height: '100%', paddingTop: offsetHeight, overflow: 'auto', position: 'relative' }} >
        <Page.Content style={{ height: 'calc(100% - 16px)' }}>
          <Suspense fallback="...">
            {children}
          </Suspense>
          <If condition={IS_PRE_OR_LOCAL}>
            <PreEnvSelector />
          </If>
        </Page.Content>
      </div>
    </div>
  );
};

AppLayout.propTypes = {
  breadCrumbList: PropTypes.arrayOf(PropTypes.any),
  breadCrumbExpand: PropTypes.element,
  title: PropTypes.string,
  children: PropTypes.element,
  message: PropTypes.arrayOf(PropTypes.any),
  isKeepCrumb: PropTypes.bool,
};

export default AppLayout;
