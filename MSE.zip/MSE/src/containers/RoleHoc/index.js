import React from 'react';
import { get } from 'lodash';
import NoPermission from '../AccountPermission/NoPermission';
import { Button } from '@ali/cn-design';
import { useStateStore } from '../../store';
import intl from '@ali/wind-intl';

const RoleHoc = (WrapComp, isShow = true) => (props) => {
  const state = useStateStore();
  const Version = get(state, 'MscAccount.Version', 0);
  const UserId = get(state, 'MscAccount.UserId');
  if (Version === 0) {
    const isMore1115 = new Date('2021-11-15 00:00:00') - new Date(Date.now());
    if (isMore1115 > 0) {
      return <WrapComp {...props} />;
    }
    if (!isShow) return null;
    return (
      <div style={{ display: 'flex', justifyContent: 'center', margin: 100 }}>
        <NoPermission style={{ width: 120, height: 120, marginRight: 16 }} />
        <div>
          <h5 style={{ margin: '16px 0 0' }}>{intl('mse.common.mst.permission')}</h5>
          <div style={{ lineHeight: '24px', color: '#555', padding: '8px 0', width: 500 }}>
           {intl.html('mse.common.mst.permission_desc')}
      </div>
          <Button type="primary"><a href={`https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn&orderType=UPGRADE&instanceId=synthetic_post_${UserId}`} target="_blank" style={{ color: '#fff' }}>{intl('mse.common.mst.upgrade')}</a></Button>
        </div>
      </div>
    );
  }
  return <WrapComp {...props} />;
};

export default RoleHoc;
