import React from 'react';
import { Icon, Badge, Balloon } from '@ali/wind';
import { get, includes } from 'lodash';
import intl from '@ali/wind-intl';

const channel = get(window, 'ALIYUN_CONSOLE_CONFIG.CHANNEL');
// 1、CAINIAO开通 注册配置中心
// 2、JST、NEW_RETAIL 开通微服务治理中心、注册配置中心、云原生网关
const virtualNetwork = ['JST', 'NEW_RETAIL'];
const aliyun_lang = aliwareGetCookieByKeyName('aliyun_lang') || 'zh';

const Tooltip = Balloon.Tooltip;

//跳转时加入埋点
const goHandleKey = (key) => {
  window.CN_TRACKER.send({
    name: key,
    type: 'mse-front-menu',
  });
  window.hashHistory.push(key);
};

//跳转页面
const renderAsLink = ({ key, label }) => {
  if (key === '/msc/prosentineltect/app') {
    key = '/msc/appList';
  }
  return <a onClick={() => goHandleKey(key)}>{label}</a>;
};

const overview = {
  key: '/overview',
  label: intl('mse.menu.guide'),
  activePathPatterns: ['/overview'],
  render: renderAsLink,
  linkProps: {
    'data-spm-click': 'gostr=/aliyun;locaid=overview',
  },
};

const msc_CN = {
  key: '/mscCenter',
  label: intl('mse.msc.title'),
  items: [
    {
      key: '/msc/home',
      label: intl('mse.msc.menu.overview'),
      activePathPatterns: ['/msc/home'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_home',
      },
    },
    {
      key: '/msc/service',
      label: intl('mse.msc.menu.service'), // 服务查询
      activePathPatterns: ['/msc/service'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_service',
      },
    },
    {
      key: '/msc/prosentineltect/app',
      label: intl('mse.msc.menu.app.governance'),
      activePathPatterns: ['/msc/appList'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_ahas_sentinel_app',
      },
    },
    {
      key: '/msc/grayscale',
      label: (
        <Badge
          content={intl('mse.msc.common.func.badge')}
          style={{
            backgroundColor: '#f54743',
            color: '#fff',
            borderRadius: '10px',
            top: -10,
            right: -35,
          }}
        >
          {intl('mse.msc.grayscale')}
        </Badge>
      ),
      activePathPatterns: ['/msc/grayscale'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_grayscale',
      },
    },
    {
      key: '/msc/governance',
      label: (
        <Badge
          content={intl('mse.common.beta')}
          style={{
            backgroundColor: '#f54743',
            color: '#fff',
            borderRadius: '10px',
            top: -10,
            right: aliyun_lang === 'en' ? -85 : -40,
          }}
        >
          {intl('mse.msc.menu.test.governance')}
        </Badge>
      ),
      activePathPatterns: ['/msc/governance'],
      // to: '/msc/info',
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_governance',
      },
      items: [
        {
          key: '/msc/services/test',
          label: intl('mse.msc.menu.micro_test'),
          render: renderAsLink,
          activePathPatterns: ['/msc/services/test'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_services_test',
          },
        },
        {
          key: '/msc/services/stress',
          label: intl('mse.msc.menu.micro_stress'),
          render: renderAsLink,
          activePathPatterns: ['/msc/services/stress', '/msc/services/stress/info'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_stress_test',
          },
        },
        {
          key: '/msc/services/regression',
          label: intl('mse.msc.menu.micro_regress'),
          render: renderAsLink,
          activePathPatterns: ['/msc/services/regression', '/msc/services/regressionEdit'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_regression',
          },
        },

        {
          key: '/msc/services/regressionSetList',
          label: intl('mse.msc.menu.micro_setlist'),
          render: renderAsLink,
          activePathPatterns: [
            '/msc/services/regressionSetList',
            '/msc/services/regressionSetDetail',
            '/msc/services/regressionEdit',
          ],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_regressionSetList',
          },
        },
        {
          key: '/msc/services/flowbox',
          label: intl('mse.msc.menu.micro_flowbox'),
          render: renderAsLink,
          activePathPatterns: ['/msc/services/flowbox', '/msc/services/repeatDetail'],
          activePathPatterns: ['/msc/services/flowbox', '/msc/services/recordDetail'],
          activePathPatterns: ['/msc/services/flowbox', '/msc/services/performanceRecordDetail'],

          activePathPatterns: ['/msc/services/flowbox'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_flowbox',
          },
        },
        {
          key: '/msc/mstMock',
          label: intl('mse.msc.menu.mock'),
          render: renderAsLink,
          activePathPatterns: ['/msc/mstMock'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_services_mock',
          },
        },
      ],
    },
    {
      key: '/msc/info',
      label: intl('mse.msc.menu.operation.maintenance.center'),
      activePathPatterns: ['/msc/info'],
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_info',
      },
      items: [
        {
          key: '/msc/k8s',
          label: intl('mse.msc.menu.k8s'),
          activePathPatterns: ['/msc/k8s'],
          render: renderAsLink,
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_k8s',
          },
        },
        {
          key: '/msc/eventCenter',
          label: intl('mse.msc.menu.event'),
          activePathPatterns: ['/msc/eventCenter'],
          render: renderAsLink,
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_event_center',
          },
        },
      ],
    },
    {
      key: '/msc/secure',
      label: '安全',
      activePathPatterns: ['/msc/secure'],
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_secure',
      },
      items: [
        {
          key: '/msc/secure/authentication',
          label: intl('mse.msc.menu.auth'),
          activePathPatterns: ['/msc/secure/authentication'],
          render:renderAsLink,
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=msc_authentication',
          },
        },
      ]
    },
  ]
}

const msc_INTL = {
  key: '/mscCenter',
  label: intl('mse.msc.title'),
  items: [
    {
      key: '/msc/home',
      label: intl('mse.msc.menu.overview'),
      activePathPatterns: ['/msc/home'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_home',
      },
    },
    {
      key: '/msc/app',
      label: intl('mse.msc.menu.app'),
      activePathPatterns: ['/msc/app'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_app',
      },
    },
    {
      key: '/msc/k8s',
      label: intl('mse.msc.menu.k8s'),
      activePathPatterns: ['/msc/k8s'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_k8s',
      },
    },
    {
      key: '/msc/service',
      label: intl('mse.msc.menu.service'),
      activePathPatterns: ['/msc/service'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_service',
      },
    },
    {
      key: '/msc/grayscale',
      label: intl('mse.msc.grayscale'),
      activePathPatterns: ['/msc/grayscale'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_grayscale',
      },
    },
    {
      key: '/msc/route/tag',
      label: intl('mse.msc.menu.route'),
      render: renderAsLink,
      activePathPatterns: ['/msc/route/tag'],
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_route_tag',
      },
    },
    {
      key: '/msc/lossless',
      label: intl('mse.msc.menu.lossless'),
      activePathPatterns: ['/msc/lossless'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_lossless',
      },
    },
    {
      key: '/msc/authentication',
      label: intl('mse.msc.menu.auth'),
      activePathPatterns: ['/msc/authentication'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_authentication',
      },
    },
    {
      key: '/msc/outlierEjection',
      label: intl('mse.msc.menu.outlier'),
      activePathPatterns: ['/msc/outlierEjection'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_outlier_Ejection',
      },
    },
    {
      key: '/msc/eventCenter',
      label: intl('mse.msc.menu.event'),
      activePathPatterns: ['/msc/eventCenter'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_event_center',
      },
    },
    {
      key: '/msc/mstMock',
      label: (
        <Badge
          content={intl('mse.common.beta')}
          style={{
            backgroundColor: '#f54743',
            color: '#fff',
            borderRadius: '10px',
            top: -10,
            right: aliyun_lang === 'en' ? -85 : -40,
          }}
        >
          {intl('mse.msc.menu.mock')}
        </Badge>
      ),
      render: renderAsLink,
      activePathPatterns: ['/msc/mstMock'],
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=msc_services_mock',
      },
    },
  ],
};

const mse = {
  key: '/mse',
  label: intl('mse.register.title'),
  render: renderAsLink,
  items: [
    {
      key: '/InstanceList',
      label: intl('mse.register.menu.instance'),
      activePathPatterns: ['/InstanceList', '/Home'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=mse_instance_list',
      },
    },
    {
      key: '/AlarmManage',
      label: intl('mse.register.menu.alarm'),
      activePathPatterns: ['/Concats', '/Alarm'],
      render: renderAsLink,
      // 金融云华北暂不开放
      visible: window.regionId !== 'cn-beijing-finance-1',
      items: [
        {
          key: '/Concats',
          label: intl('mse.register.menu.concats'),
          render: renderAsLink,
          activePathPatterns: ['/Concats'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=mse_concats',
          },
        },
        {
          key: '/Alarm',
          label: intl('mse.register.menu.alarm_policy'),
          render: renderAsLink,
          activePathPatterns: ['/Alarm'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=mse_alarm',
          },
        },
      ],
    },
    {
      key: '/MigrateCloud',
      label: intl('mse.migrate.title'),
      activePathPatterns: ['/MigrateCloud'],
      render: renderAsLink,
    },
  ],
};

const microgw = {
  key: '/microgw',
  label: intl('mse.microgw.title'),
  render: renderAsLink,
  items: [
    {
      key: '/microgw',
      label: intl('mse.microgw.menu.instance'),
      activePathPatterns: ['/microgw'],
      render: renderAsLink,
      linkProps: {
        'data-spm-click': 'gostr=/aliyun;locaid=mse-microgw',
      },
    },
    {
      key: '/alarm',
      label: intl('mse.microgw.menu.alarm'),
      activePathPatterns: ['/alarm/concats', '/alarm/policy'],
      render: renderAsLink,
      //华北金融云暂不开放
      visible: window.regionId !== 'cn-beijing-finance-1',
      items: [
        {
          key: '/alarm/concats',
          label: intl('mse.microgw.menu.concats'),
          render: renderAsLink,
          activePathPatterns: ['/alarm/concats'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=mse_microgw_concats',
          },
        },
        {
          key: '/alarm/policy',
          label: intl('mse.microgw.menu.alarm_policy'),
          render: renderAsLink,
          activePathPatterns: ['/alarm/policy'],
          linkProps: {
            'data-spm-click': 'gostr=/aliyun;locaid=mse_microgw_alarm',
          },
        },
      ],
    },
  ],
};


const msc = (aliwareGetCookieByKeyName('aliyun_site') === 'INTL') ? msc_INTL : msc_CN;

let menus = [overview, msc, mse, microgw];
if (channel === 'CAINIAO') {
  menus = [overview, mse];
}
const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
if (includes(['JST', 'NEW_RETAIL'], channel) || aliyunSite === 'INTL') {
  menus = [overview, msc, mse, microgw];
}

export default menus;
