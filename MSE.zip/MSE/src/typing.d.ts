declare module 'react-masonry-component';
declare module '@ali/mamba';
declare module 'components/*';
declare module '@alicloud/console-components-actions';
declare module 'bizcharts';
declare module '@alicloud/console-one-conf';
declare module '@alife/aisc-widgets';
declare module '@alicloud/console-components';
declare module '@ali/search-params-interceptor';
declare module '@ali/fecs-csrf-token-error-interceptor';
declare module '@ali/console-request-interceptor';
declare module '@ali/console-mock-interceptor';
declare module '@alicloud/console-components/dist/wind.css';
declare module '*.less';
declare module '@ali/wind-line-chart';
declare module 'react-code-diff-lite';
declare module 'queryString';
declare module 'file-saver';
declare module '@alicloud/console-components-truncate';
declare module '@ali/wind-intl';
declare module '@antv/g6~v3.1.1';
declare module '@antv/g2plot';
declare module '@alife/santa-introjs';
declare module '@ali/cn-design';
// declare module '';
// declare module '';
// declare module '';
// declare module '';
// declare module '';
// declare module '';
// declare module 'containers/*';
// declare module 'constans';
// declare module 'constans/*';


declare global  {
    interface Window {
        getParams: any;
    }
};