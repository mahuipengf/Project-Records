
import createService from 'utils/createService_ahas';
import { BaseModel, dvaModel, effect, reducer } from '@ali/sre-utils-dva';
import {
  ICreateBatchPublishOrderReq,
  IGetAppSwitchLogReq,
  IGetAppUnFinishedPublishOrderAndMachinesReq,
  IGetPublishOrderStatusReq,
  IGetSwitchAppListReq,
  IGetSwitchDetailReq,
  IGetSwitchNameSpaceReq,
  IGetSwitchesReq,
  IGetUnFinishedPublishOrderAndStatistcReq,
  IMachines,
  IPublishAppSwitchTargetBatchReq,
  IRollBackPublishOrderReq,
  ISwitchVO,
  ITerminatePublishOrderReq,
  IUpdateAppSwitchReq,
  IUpdateMachineSwitchReq,
} from 'config/interfaces';

const productName = 'ahas';

interface ISwitchState {
  switches: {
    totalCount: number;
    data: ISwitchVO[];
  };
  namespaces: {
    loaded: boolean;
    data: string[];
  };
  [key: string]: any;
  appAdminList: {
    totalCount: number;
    data: IMachines[];
  };
  machineTopList: {
    pageIndex: number
  }
}

const DEFAULT_STATE: ISwitchState = {
  apps: {
    totalCount: 0,
    data: [],
  },
  switches: {
    totalCount: 0,
    data: [],
  },
  namespaces: {
    loaded: false,
    data: [],
  },
  appAdminList: {
    totalCount: 0,
    data: [],
  },
  machineTopList: {
    pageIndex: 1
  }
};

@dvaModel('switchModel')
class SwitchModel extends BaseModel {
  state: ISwitchState = DEFAULT_STATE;

  @reducer
  clear(key?: string) {
    if (!key) {
      return {
        ...DEFAULT_STATE,
      };
    }
    return {
      ...this.state,
      [key]: DEFAULT_STATE[key],
    };
  }

  @reducer
  setNamespaces(payload: ISwitchState['namespaces']) {
    return {
      ...this.state,
      namespaces: {
        loaded: payload.loaded,
        data: payload.data,
      },
    };
  }

  @reducer
  setSwitches(payload: ISwitchState['switches']) {
    return {
      ...this.state,
      switches: {
        totalCount: payload.totalCount,
        data: payload.data,
      },
    };
  }

  @reducer
  setAppAdminList(payload: ISwitchState['appAdminList']) {
    return {
      ...this.state,
      appAdminList: {
        totalCount: payload.totalCount,
        data: payload.data,
      },
    };
  }

  @reducer
  setMachineTopList(payload: ISwitchState['machineTopList']) {
    return {
      ...this.state,
      machineTopList: {
        pageIndex: payload.pageIndex
      },
    };
  }

  @effect()
  *getApps(payload?: IGetSwitchAppListReq) {
    return yield this.effects.call(createService(productName, 'GetSwitchAppList'), payload);
  }

  @effect()
  *getNameSpaces(payload: IGetSwitchNameSpaceReq) {
    const { Data } = yield this.effects.call(createService(productName, 'GetSwitchNameSpaces'), payload);
    yield this.effects.put(this.setNamespaces({
      loaded: true,
      data: Data,
    }));
    return Data;
  }

  @effect()
  *getSwitches(payload: IGetSwitchesReq) {
    const { Data } = yield this.effects.call(createService(productName, 'GetSwitchDescription'), payload);
    const { PageData: data, TotalCount: totalCount } = Data;
    yield this.effects.put(this.setSwitches({ totalCount, data }));
  }

  @effect()
  *getSwitchDetail(payload: IGetSwitchDetailReq) {
    return yield this.effects.call(createService(productName, 'QuerySwitchDetail'), payload);
  }

  @effect()
  *getSwitchStatistic(payload: IGetUnFinishedPublishOrderAndStatistcReq) {
    return yield this.effects.call(createService(productName, 'GetSwitchStatistic'), payload);
  }
  @effect()
  *getSwitchPersistValue(payload: IGetUnFinishedPublishOrderAndStatistcReq) {
    return yield this.effects.call(createService(productName, 'GetSwitchPersistValue'), payload);
  }

  @effect()
  *updateMachineSwitch(payload: IUpdateMachineSwitchReq) {
    return yield this.effects.call(createService(productName, 'UpdateMachineSwitch'), payload);
  }

  @effect()
  *updateAppSwitch(payload: IUpdateAppSwitchReq) {
    return yield this.effects.call(createService(productName, 'UpdateAppSwitch'), payload);
  }

  @effect()
  *getAppSwitchLog(payload: IGetAppSwitchLogReq) {
    return yield this.effects.call(createService(productName, 'GetAppSwitchLog'), payload);
  }

  @effect()
  *getTagLog(payload: IGetAppSwitchLogReq) {
    return yield this.effects.call(createService(productName, 'GetTagLog'), payload);
  }

  @effect()
  *createBatchPublishOrder(payload: ICreateBatchPublishOrderReq) {
    return yield this.effects.call(createService(productName, 'CreateBatchPublishOrder'), payload);
  }

  @effect()
  *getPublishOrderStatus(payload: IGetPublishOrderStatusReq) {
    return yield this.effects.call(createService(productName, 'GetPublishOrderStatus'), payload);
  }

  @effect()
  *publishAppSwitchTargetBatch(payload: IPublishAppSwitchTargetBatchReq) {
    return yield this.effects.call(createService(productName, 'PublishAppSwitchTargetBatch'), payload);
  }

  @effect()
  *rollBackPublishOrder(payload: IRollBackPublishOrderReq) {
    return yield this.effects.call(createService(productName, 'RollBackPublishOrder'), payload);
  }

  @effect()
  *getUnFinishedPublishOrder(payload: IGetUnFinishedPublishOrderAndStatistcReq) {
    return yield this.effects.call(createService(productName, 'GetUnFinishedPublishOrder'), payload);
  }

  @effect()
  *getAppMachines(payload: IGetAppUnFinishedPublishOrderAndMachinesReq) {
    const { Data } = yield this.effects.call(createService(productName, 'GetAppMachines'), payload);
    const { Data: data, TotalCount: totalCount } = Data;
    yield this.effects.put(this.setAppAdminList({
      totalCount,
      data,
    }));
  }

  @effect()
  *getSimpleAppMachines(payload: IGetAppUnFinishedPublishOrderAndMachinesReq) {
    return yield this.effects.call(createService(productName, 'GetSimpleAppMachines'), payload);
  }

  @effect()
  *setAppMachinesTag(payload: any) {
    return yield this.effects.call(createService(productName, 'SetAppMachinesTag'), payload);
  }

  @effect()
  *getAppTags(payload: any) {
    return yield this.effects.call(createService(productName, 'GetAppTags'), payload);
  }

  @effect()
  *removeAppTags(payload: any) {
    return yield this.effects.call(createService(productName, 'RemoveAppTags'), payload);
  }

  @effect()
  *updateTagAppSwitch(payload: any) {
    return yield this.effects.call(createService(productName, 'UpdateTagAppSwitch'), payload);
  }

  @effect()
  *getTagValue(payload: any) {
    return yield this.effects.call(createService(productName, 'GetTagValue'), payload);
  }

  @effect()
  *getAppUnFinishedPublishOrder(payload: IGetAppUnFinishedPublishOrderAndMachinesReq) {
    return yield this.effects.call(createService(productName, 'GetAppUnFinishedPublishOrder'), payload);
  }

  @effect()
  *terminatePublishOrder(payload: ITerminatePublishOrderReq) {
    return yield this.effects.call(createService(productName, 'TerminatePublishOrder'), payload);
  }

  @effect()
  *CheckSwitchPostUser(payload: any) {
    return yield this.effects.call(createService(productName, 'CheckSwitchPostUser'), payload);
  }
}

export default new SwitchModel().model;

declare global {
  interface Actions {
    switchModel: SwitchModel;
  }
}
