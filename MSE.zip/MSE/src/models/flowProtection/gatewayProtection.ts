import createService from 'utils/createService_ahas';
import { BaseModel, dvaModel, effect, reducer } from '@ali/sre-utils-dva';
import {
  CommonReq,
  IFlowRuleOnOff,
  IGatewayFlowRuleNew,
  IQuerySentinelAppMachineList,
  ISentinelGateway,
  ISentinelGatewayApiAddSava,
} from 'config/interfaces';
import { productName } from 'config/constants';

interface IFlowModelState {
  [key: string]: any;
  apiDetails: {
    activeResourceName: string;
    favorite: boolean;
    hasRule: boolean;
    type: number;
    pResourceName?: string;
  };
}

const DEFAULT_STATE: IFlowModelState = {
  apiDetails: {
    activeResourceName: '',
    favorite: false,
    hasRule: false,
    type: 0,
    pResourceName: '',
  },
};

@dvaModel('flowGwModel')
class FlowGwModel extends BaseModel {
  state: IFlowModelState = DEFAULT_STATE;

  @reducer
  clear(key?: string) {
    if (!key) {
      return {
        ...DEFAULT_STATE,
      };
    }
    return {
      ...this.state,
      [key]: DEFAULT_STATE[key],
    };
  }

  @reducer
  setApiActiveName(payload: IFlowModelState['apiDetails']) {
    return {
      ...this.state,
      apiDetails: {
        activeResourceName: payload.activeResourceName,
        favorite: payload.favorite,
        hasRule: payload.hasRule,
        type: payload.type,
        pResourceName: payload.pResourceName,
      },
    };
  }

  // 应用防护-应用管理-权限管理列表
  @effect()
  *getQuerySubUserAuthList(payload?: CommonReq) {
    return yield this.effects.call(
      createService(productName, 'QuerySubUserAuthList'),
      payload,
    );
  }

  // 网关防护-节点管理-列表数据
  @effect()
  *getQuerySentinelAppMachineList(
    payload?: IQuerySentinelAppMachineList,
  ) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelAppMachineList'),
      payload,
    );
    return Data;
  }

  // 网关防护-api流控规则
  @effect()
  *getSentinelGatewayFlowRuleListAll(payload?: ISentinelGateway) {
    const { Data = [] } = yield this.effects.call(
      createService(productName, 'SentinelGatewayFlowRuleListAll'),
      payload,
    );
    return Data;
  }

  // 网关防护-api流控规则-关闭状态
  @effect()
  *getSentinelGatewayFlowRuleOff(payload?: IFlowRuleOnOff) {
    return yield this.effects.call(
      createService(productName, 'SentinelGatewayFlowRuleOff'),
      payload,
    );
  }

  // 网关防护-api流控规则-开启状态
  @effect()
  *getSentinelGatewayFlowRuleOn(payload?: IFlowRuleOnOff) {
    return yield this.effects.call(
      createService(productName, 'SentinelGatewayFlowRuleOn'),
      payload,
    );
  }

  // 网关防护-api流控规则-删除
  @effect()
  *getSentinelGatewayFlowRuleDelete(payload?: IFlowRuleOnOff) {
    return yield this.effects.call(
      createService(productName, 'SentinelGatewayFlowRuleDelete'),
      payload,
    );
  }

  // 网关防护-api流控规则
  @effect()
  *getSentinelGatewayApiDefinitionsListForApp(payload?: ISentinelGateway) {
    const { Data = [] } = yield this.effects.call(
      createService(productName, 'SentinelGatewayApiDefinitionsListForApp'),
      payload,
    );
    return Data;
  }

  // 网关防护-api流控规则-新增
  @effect()
  *getSentinelGatewayFlowRuleNew(payload?: IGatewayFlowRuleNew) {
    return yield this.effects.call(
      createService(productName, 'SentinelGatewayFlowRuleNew'),
      payload,
    );
  }

  // 网关防护-api流控规则-编辑
  @effect()
  *getSentinelGatewayFlowRuleEdit(payload?: IGatewayFlowRuleNew) {
    return yield this.effects.call(
      createService(productName, 'SentinelGatewayFlowRuleEdit'),
      payload,
    );
  }

  // 网关防护-api管理-删除
  @effect()
  *getSentinelGatewayApiDefinitionDelete(payload?: IFlowRuleOnOff) {
    return yield this.effects.call(
      createService(productName, 'SentinelGatewayApiDefinitionDelete'),
      payload,
    );
  }

  // 网关防护-api管理-保存。
  @effect()
  *getSentinelGatewayApiDefinitionUpdate(payload?: ISentinelGatewayApiAddSava) {
    return yield this.effects.call(
      createService(productName, 'SentinelGatewayApiDefinitionUpdate'),
      payload,
    );
  }

  // 网关防护-api管理-新增。
  @effect()
  *getSentinelGatewayApiDefinitionNew(payload?: ISentinelGatewayApiAddSava) {
    return yield this.effects.call(
      createService(productName, 'SentinelGatewayApiDefinitionNew'),
      payload,
    );
  }
}

export default new FlowGwModel().model;

declare global {
  interface Actions {
    flowGwModel: FlowGwModel;
  }
}
