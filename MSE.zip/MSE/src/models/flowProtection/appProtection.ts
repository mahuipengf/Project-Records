import createService from 'utils/createService_ahas';
import createServiceMst from 'utils/createServiceMst';
import { BaseModel, dvaModel, effect, reducer } from '@ali/sre-utils-dva';
import {
  CommonReq,
  IAddOrEditAlarmRule,
  IAddOrUpdateMonitorDashboardItems,
  IAppMachineList,
  IAppMachineListByPage,
  IAppMetricOverview,
  IAssignMarkDirty,
  IAuthorityParams,
  IAutoRetryRuleOffOnBatch,
  IAutoRetryRuleRecordAdd,
  IBindSentinelBlockFallbackDefinition,
  IBlockFallbackDefinition,
  IClientVersionOfApp,
  IClusterClientQuery,
  IClusterClientUpdate,
  IClusterStatistics,
  IClusterTypeStatistics,
  ICreateCluster,
  ICreateMultiModel,
  ICreateSentinelManualDegradeRule,
  IDegradeRuleDelete,
  IDegradeRuleListAll,
  IDegradeRuleListByPage,
  IDegradeRuleNew,
  IDegradeRuleOffOnBatch,
  IDeleteAlarmRule,
  IDeleteBlockFallbackDefinition,
  IDeleteMonitorDashboardItems,
  IDeleteMultiModel,
  IDeleteScenarioRecord,
  IDescribeScenarioRecord,
  IDescribeScenarioRecordsForAhas,
  IDescribeScenarioStatus,
  IFavoriteApp,
  IFlowRuleDelete,
  IFlowRuleListAllApp,
  IFlowRuleListByPage,
  IFlowRuleNew,
  IFlowRuleOffOmBatch,
  IFlowRuleOnOff,
  IGatewayFlowRuleNew,
  IGetClusterDetail,
  IGetClusterList,
  IGetResourcesPDFReport,
  IGetSentinelMetricsOfResourceReq,
  IHotParamItems,
  IHotParamRule,
  IHotParamRuleDelete,
  IHotParamRuleOffOnBatch,
  IHotparamRule,
  IHttpApiMatchUpdateDefault,
  ILicenseKey,
  IListManualDegradeRulesByPage,
  IListScenarioRecords,
  IListSentinelBlockFallback,
  IManagedTokenServers,
  IMetericOfAppType,
  IMetricListTop,
  IMonitorDashboards,
  INotFineOfResource,
  IOperationLogListOpLogs,
  IParamRuleListByPage,
  IQueryAlarmRuleOperRecords,
  IQueryAlarmRules,
  IQueryAllAlarmRules,
  IQueryClusterResources,
  IQueryParamRuleHotKeyStatistics,
  IQueryParamRulesWithName,
  IResourceMetricOfResource,
  IRulelAppEvents,
  ISaveScenarioSpringCloud,
  IScenario,
  ISentinelAdaptiveFlowSettingOfApp,
  ISentinelAppEvents,
  ISentinelAppResourceEvents,
  ISentinelChangeModel,
  ISentinelFavorite,
  ISentinelGetResourceFallback,
  ISentinelHttpApiMatchNew,
  ISentinelHttpApiMatchUpdate,
  ISentinelListTopNApp,
  ISentinelMacMetricsOfResource,
  ISentinelMacTopNResources,
  ISentinelMetricListTopNResourcesMetricSimpleReq,
  ISentinelModifyAppPriceLevel,
  ISentinelNodeListSentinelMachineNodes,
  ISentinelProtectionModuleListAllByPage,
  ISentinelProtectionModuleNew,
  ISentinelProtectionModuleUpdate,
  ISentinelResourceTopNMacs,
  ISentinelResourceTopNMacsWithMetricsReq,
  ISentinelResourcesPercentage,
  ISentinelWebParamFlowRuleListByPage,
  ISetClusterOnOrOff,
  IStatusTopOfApplication,
  ISubmitDataBasicAdd,
  ISubmitDataWebAdd,
  ISystemResourceMetricOfGroup,
  ISystemRuleListAll,
  ISystemRuleNew,
  ISystemStatResourceMetricOfResource,
  ITestRpcBlockFallbackDefinition,
  IThermodynamicDataReq,
  ITokenServerDetail,
  ITokenServerForAssign,
  IUpdateAlarmStatus,
  IUpdateCluster,
  IUpdateSentinelAdaptiveFlowSettingOfApp,
  IUpdateServerConfig,
} from '../../config/interfaces';
// import { ahasMseRequest } from '../../../src/utils/services_ahas/newRequest';
// import { ahasMseRequest } from '../../../src/utils/services/request_ahas';
import { ahasMseRequest } from '../../../src/utils/services_ahas/newRequest';
import intl from '@ali/wind-intl';
// import { productName } from 'config/constants';
const productName = 'ahas';
interface IFlowModelState {
  [key: string]: any;

  applicationProtection: {
    protecList: ISentinelListTopNApp[];
    totalCount: number;
  };
  apiDetails: {
    activeResourceName: string;
    queryResourceName?: string;
    favorite: boolean;
    hasRule: boolean;
    type: number;
    pResourceName: string;
  };

  serviceDetails:{
    serviceType:number;
  }

  keyStatisticsOnNode:{
    TotalCount: number;
    Metrics: any[];
  };
  machineDetails: {
    privateIp?: string;
    parentIp?: string;
    pid?: number;
    processConfigurationId: string;
    vpcId?: string;
    resource: string;
    hostname?: string;
  };
  apiShowTime: {
    backTime?: number;
    statisticsEndTime?: number;
  };
  HotKey:string;
  resourceType: number;
  machineAllType: number;
  machineJvmAllType: number;
  appVersion: any;
  showModelstype: boolean;
  systemGuardPageType: string;
  sortDesc: {
    sortIndex: number;
    descType: boolean;
    webSortType?: string;
    orderType?: string;
    searchKey?:string
  };
  ApplicationInstancesWithMetircs: {
    PageSize: number;
    PageNumber: number;
    TotalSize: number;
    Result: Array<any>[];
  };
  nodeDetailBaseInfoPageNumber: {
    pageNumber: number;
  };
  fullScreen: {
    fullScreenApi: boolean;
    fullScreenMac: boolean;
  };
  chartsFilter: Array<string>;
  exceptionTime: number;
  protectionSceneDataStepOne: string;
  flowRuleOptionsDataStepTwo: string;
  actionDataStepThree: string;
  alarmRulesDataStepFour: string;
  activeClusterName: string;
  activeHotSpotName: string;
  activeHotSpotDetails: any;
  appServiceData: {
    dubbo?: any;
    springCloud?: any;
    istio?: any;
  };
  appList: Array<any>;
  k8sNamespaceData: Array<any>;
  isNeedOpenGraphical: boolean;
  MscAccount: {
    Status?: number;
    UserId?: string;
    Version?: number;
  };
  GlobalNamespace: {
    label?: string;
    namespace?: string;
    region?: string;
    value?: string;
  };
}

const DEFAULT_STATE: IFlowModelState = {
  applicationProtection: {
    protecList: [],
    totalCount: 0,
  },
  keyStatisticsOnNode: {
    TotalCount: 0,
    Metrics: [],
  },
  apiDetails: {
    activeResourceName: '_all',
    queryResourceName: '',
    favorite: false,
    hasRule: false,
    type: 0,
    pResourceName: '',
  },

  serviceDetails:{
    serviceType:0,
  },
  
  HotKey: '',
  machineDetails: {
    privateIp: '_all',
    parentIp: '',
    pid: -1,
    processConfigurationId: '',
    vpcId: '',
    resource: '',
  },
  apiShowTime: {
    backTime: undefined,
    statisticsEndTime: undefined,
  },
  resourceType: 1,
  machineAllType: 0,
  machineJvmAllType: 0,
  appVersion: {},
  showModelstype: true,
  systemGuardPageType: 'pageApp',
  sortDesc: {
    sortIndex: 0,
    descType: true,
    webSortType: 'qps',
    orderType: 'desc',
    searchKey:''
  },
  ApplicationInstancesWithMetircs: {
    PageSize: 10,
    PageNumber: 1,
    TotalSize: 0,
    Result: [],
  },
  nodeDetailBaseInfoPageNumber: {
    pageNumber: 1,
  },
  fullScreen: {
    fullScreenApi: false,
    fullScreenMac: false,
  },

  chartsFilter: [
    intl('mse.appOverview.allQps'),
    intl('mse.appOverview.paasQps'),
    intl('ahas_sentinel.systemGuard.flowControl.RejectQPS'),
    intl('mse.appOverview.exception'),
    intl('mse.appOverview.waitIoCpuUsed'),
    intl('mse.appOverview.sysCpuUsed'),
    intl('mse.appOverview.useCpuUsed'),
    'Load',
    intl('ahas_sentinel.systemGuard.FuseRules.BufferCache'),
    intl('ahas_sentinel.systemGuard.FuseRules.PageCache'),
    intl('ahas_sentinel.systemGuard.FuseRules.sysFree'),
    intl('ahas_sentinel.systemGuard.FuseRules.usedMemory'),
    intl('mse.apiDetail.diskFree'),
    intl('mse.apiDetail.diskUsed'),
    intl('mse.appOverview.networkReceivedTrafficSize'),
    intl('mse.appOverview.networkSendTrafficSize'),
    intl('mse.appOverview.packetsDroppedNum'),
    intl('ahas_sentinel.systemGuard.FuseRules.NumberOfErrorsReceived'),
    intl('mse.appOverview.messagesReceivedNum'),
    intl('ahas_sentinel.systemGuard.FuseRules.packets'),
    intl('mse.appOverview.fullGCtimes'),
    intl('mse.appOverview.younggctimes'),
    intl('ahas_sentinel.systemGuard.FuseRules.FullGCTimeConsuming-consuming'),
    intl('ahas_sentinel.systemGuard.FuseRules.YoungGCTimeConsuming'),
    intl('mse.appOverview.useSum'),
    intl('mse.appOverview.youngGenerationEdenDistrict'),
    intl('mse.appOverview.oldage'),
    intl('mse.appOverview.youngSurvivorDistrict'),
    intl('ahas_sentinel.systemGuard.flowControl.Metaspace'),
    intl('mse.machine.jvmBlocked'),
    intl('mse.machine.jvmAllcount'),
    intl('mse.machine.jvmDeadlock'),
    intl('mse.machine.jvmNew'),
    intl('mse.machine.jvmRunnable'),
    intl('mse.machine.jvmTerminated'),
    intl('mse.machine.jvmTimed_waiting'),
    intl('mse.machine.jvmWaiting'),
    intl('mse.appOverview.nonHeapMemoryCommitBytes'),
    intl('mse.appOverview.numberOfBytesInHeapMemory'),
    intl('mse.appOverview.numberOfBytesUsedInNonHeapMemory'),
    intl('mse.apiDetail.diskTotal'),
  ],
  exceptionTime: 0,
  protectionSceneDataStepOne: JSON.stringify(''), // 防护管理-Step1-防护场景数据
  flowRuleOptionsDataStepTwo: JSON.stringify(''), // 防护管理-Step2-防护规则数据
  actionDataStepThree: JSON.stringify(''), // 防护管理-Step3-限流行为数据
  alarmRulesDataStepFour: JSON.stringify(''), // 防护管理-Step4-告警规则数据
  activeClusterName: '_all',
  activeHotSpotName: '',
  activeHotSpotDetails: '',
  appServiceData: {
    dubbo: [],
    springCloud: [],
    istio: [],
  },
  appList: [],
  k8sNamespaceData: [],
  isNeedOpenGraphical: true,
  MscAccount: {
    Status: 0,
    UserId: '',
    Version: 0,
  },
  serverTestData: {
    serviceType: '',
    serviceGroup: '',
    serviceVersion: '',
    serviceName: '',
    appId: '',
    serviceId: '',
    registryType: '',
    paths: [],
    requestMethods: [],
  },
  GlobalNamespace: {
    label: '',
    namespace: '',
    region: '',
    value: '',
  },
};

@dvaModel('flowAppModel')
class FlowAppModel extends BaseModel {
  state: IFlowModelState = DEFAULT_STATE;

  @reducer
  clear(key?: string) {
    if (!key) {
      return {
        ...DEFAULT_STATE,
      };
    }
    return {
      ...this.state,
      [key]: DEFAULT_STATE[key],
    };
  }

  @reducer
  setK8sNamespaceData(payload: IFlowModelState['k8sNamespaceData']) {
    return {
      ...this.state,
      k8sNamespaceData: payload,
    };
  }

  @reducer
  setMscAccount(payload: IFlowModelState['MscAccount']) {
    return {
      ...this.state,
      MscAccount: payload,
    };
  }

  @reducer
  setAllAppList(payload: IFlowModelState['appList']) {
    return {
      ...this.state,
      appList: payload,
    };
  }

  @reducer
  setAppServiceData(payload: IFlowModelState['appServiceData']) {
    return {
      ...this.state,
      appServiceData: {
        dubbo: payload.dubbo,
        springCloud: payload.springCloud,
        istio: payload.istio,
      },
    };
  }

  @reducer
  setIsNeedOpenGraphical(payload: IFlowModelState['isNeedOpenGraphical']) {
    return {
      ...this.state,
      isNeedOpenGraphical: payload,
    };
  }


  @reducer
  setApiActiveName(payload: IFlowModelState['apiDetails']) {
    return {
      ...this.state,
      apiDetails: {
        activeResourceName: payload.activeResourceName,
        queryResourceName: payload.queryResourceName || payload.activeResourceName,
        favorite: payload.favorite,
        hasRule: payload.hasRule,
        type: payload.type,
        pResourceName: payload.pResourceName,
      },
    };
  }

  @reducer
  setServiceType(payload: IFlowModelState['serviceDetails']) {
    return {
      ...this.state,
      serviceDetails: {
        serviceType:payload.serviceType,
      },
    };
  }

  @reducer
  setServerTestMethodData(payload: any) {
    return {
      ...this.state,
      serverTestData: payload,
    };
  }

  @reducer
  setGlobalNamespace(payload: any) {
    return {
      ...this.state,
      GlobalNamespace: payload,
    };
  }

  @reducer
  setMachineActiveName(payload: IFlowModelState['machineDetails']) {
    return {
      ...this.state,
      machineDetails: {
        privateIp: payload.privateIp,
        parentIp: payload.parentIp,
        pid: payload.pid,
        processConfigurationId: payload.processConfigurationId,
        vpcId: payload.vpcId,
        resource: payload.resource,
      },
    };
  }

  @reducer
  setApiShowTime(payload: IFlowModelState['apiShowTime']) {
    return {
      ...this.state,
      apiShowTime: {
        backTime: payload.backTime,
        statisticsEndTime: payload.statisticsEndTime,
      },
    };
  }

  @reducer
  setResourceType(payload: IFlowModelState['resourceType']) {
    return {
      ...this.state,
      resourceType: payload,
    };
  }

  @reducer
  setMachineAllType(payload: IFlowModelState['machineAllType']) {
    return {
      ...this.state,
      machineAllType: payload,
    };
  }

  @reducer
  keyStatisticsOnNode(payload:any) {
    return {
      ...this.state,
      keyStatisticsOnNode: payload,
    };
  }
  @reducer
  setHotKey(payload:any) {
    return {
      ...this.state,
      HotKey: payload,
    };
  }
  @reducer
  setMachineJvmAllType(payload: IFlowModelState['machineJvmAllType']) {
    return {
      ...this.state,
      machineJvmAllType: payload,
    };
  }

  @reducer
  setAppVersion(payload: IFlowModelState['appVersion']) {
    return {
      ...this.state,
      appVersion: payload,
    };
  }

  @reducer
  setShowModelstype(payload: IFlowModelState['showModelstype']) {
    return {
      ...this.state,
      showModelstype: payload,
    };
  }

  @reducer
  setSystemGuardPageType(payload: IFlowModelState['systemGuardPageType']) {
    return {
      ...this.state,
      systemGuardPageType: payload,
    };
  }

  @reducer
  setSortDesc(payload: IFlowModelState['sortDesc']) {
    return {
      ...this.state,
      sortDesc: {
        sortIndex: payload.sortIndex,
        descType: payload.descType,
        webSortType: payload?.webSortType || '',
        orderType: payload?.orderType || '',
        searchKey: payload?.searchKey || '',
      },
    };
  }
  @reducer
  setApplicationInstancesWithMetircs(payload: IFlowModelState['ApplicationInstancesWithMetircs']) {
    return {
      ...this.state,
      ApplicationInstancesWithMetircs: {
        PageSize: payload.TotalSize,
        PageNumber: payload.TotalSize,
        TotalSize: payload.TotalSize,
        Result: payload.Result || [],
      },
    };
  }

  @reducer
  setNodeDetailBaseInfoPageNumber(payload: IFlowModelState['nodeDetailBaseInfoPageNumber']) {
    return {
      ...this.state,
      nodeDetailBaseInfoPageNumber: {
        pageNumber: payload.pageNumber,
      },
    };
  }

  @reducer
  setFullScreen(payload: IFlowModelState['fullScreen']) {
    return {
      ...this.state,
      fullScreen: {
        fullScreenApi: payload.fullScreenApi,
        fullScreenMac: payload.fullScreenMac,
      },
    };
  }

  @reducer
  setChartsFilter(payload: IFlowModelState['chartsFilter']) {
    return {
      ...this.state,
      chartsFilter: payload,
    };
  }

  @reducer
  setExceptionTime(payload: IFlowModelState['exceptionTime']) {
    return {
      ...this.state,
      exceptionTime: payload,
    };
  }

  @reducer
  setProtectionSceneDataStepOne(payload: IFlowModelState['protectionSceneDataStepOne']) {
    return {
      ...this.state,
      protectionSceneDataStepOne: payload,
    };
  }

  @reducer
  setFlowRuleOptionsDataStepTwo(payload: IFlowModelState['flowRuleOptionsDataStepTwo']) {
    return {
      ...this.state,
      flowRuleOptionsDataStepTwo: payload,
    };
  }

  @reducer
  setActionDataStepThree(payload: IFlowModelState['actionDataStepThree']) {
    return {
      ...this.state,
      actionDataStepThree: payload,
    };
  }

  @reducer
  setAlarmRulesDataStepFour(payload: IFlowModelState['alarmRulesDataStepFour']) {
    return {
      ...this.state,
      alarmRulesDataStepFour: payload,
    };
  }

  @reducer
  setClusterActiveName(payload: IFlowModelState['activeClusterName']) {
    return {
      ...this.state,
      activeClusterName: payload,
    };
  }

  @reducer
  setActiveHotSpotName(payload: IFlowModelState['activeHotSpotName']) {
    return {
      ...this.state,
      activeHotSpotName: payload,
    };
  }

  @reducer
  setActiveHotSpotDetails(payload: IFlowModelState['activeHotSpotDetails']) {
    return {
      ...this.state,
      activeHotSpotDetails: payload,
    };
  }

  // 应用防护-接口详情-请求接口列表
  @effect()
  *getSentinelMetricListTopNResourceName(payload?: IMetricListTop) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelMetricListTopNResourceName'),
      payload,
    );
    return Data;
  }

  // 应用防护-接口详情-请求列表接口
  // 应用防护-接口详情-请求全部接口charts数据
  @effect()
  *getQuerySentinelAppSummaryMetricOverview(payload?: IAppMetricOverview) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'QuerySentinelAppSummaryMetricOverview'),
      payload,
    );
    return Data;
  }
  @effect()
  *QueryAppSystemMetricsOfGroupByInstance(payload?: any) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'QueryAppSystemMetricsOfGroupByInstance'),
      payload,
    );
    return Data;
  }

  // 应用防护-接口详情-请求所有大盘列表
  @effect()
  *getSentinelGetMonitorDashboards(payload?: IMonitorDashboards) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelGetMonitorDashboards'),
      payload,
    );
    return Data;
  }

  // 应用防护-接口详情-添加至大盘
  @effect()
  *getSentinelAddOrUpdateMonitorDashboardItems(payload?: IAddOrUpdateMonitorDashboardItems) {
    const Data = yield this.effects.call(
      createService(productName, 'SentinelAddOrUpdateMonitorDashboardItems'),
      payload,
    );
    return Data;
  }

  // 应用防护-接口详情-从大盘中删除
  @effect()
  *getSentinelDeleteMonitorDashboardItems(payload?: IDeleteMonitorDashboardItems) {
    const Data = yield this.effects.call(
      createService(productName, 'SentinelDeleteMonitorDashboardItems'),
      payload,
    );
    return Data;
  }

  // 应用防护-节点管理-请求列表接口
  @effect()
  *getSentinelAppMachineList(payload?: IAppMachineList) {
    return yield this.effects.call(
      createService(productName, 'SentinelAppMachineList'),
      payload,
    );
  }

  // 应用防护-接入节点-新请求列表接口
  @effect()
  *getSentinelAppMachineListByPage(payload?: IAppMachineListByPage) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelAppMachineListByPage'),
      payload,
    );
    return Data;
  }

  // 应用防护-应用管理-权限管理列表
  @effect()
  *getQuerySubUserAuthList(payload?: CommonReq) {
    return yield this.effects.call(
      createService(productName, 'QuerySubUserAuthList'),
      payload,
    );
  }

  // 应用防护-应用管理-权限管理设置
  @effect()
  *getUpdateUserAuthority(payload?: IAuthorityParams) {
    return yield this.effects.call(
      createService(productName, 'UpdateUserAuthority'),
      payload,
    );
  }

  // 应用防护-应用管理-基础设置-防护模式配置
  @effect()
  *getSentinelQueryAppPriceLevel(payload?: IAppMachineList) {
    return yield this.effects.call(
      createService(productName, 'SentinelQueryAppPriceLevel'),
      payload,
    );
  }

  // 应用防护-应用管理-集群流控设置-获取QPS档位信息
  @effect()
  *getClusterList(payload?: IGetClusterList) {
    return yield this.effects.call(
      createService(productName, 'GetClusterList'),
      payload,
    );
  }

  // 应用防护-应用管理-集群流控设置-QPS档位信息
  @effect()
  *getClusterDetail(payload?: IGetClusterDetail) {
    return yield this.effects.call(
      createService(productName, 'GetClusterDetail'),
      payload,
    );
  }

  // 应用防护-应用管理-集群流控设置-更新qps档位信息
  @effect()
  *updateCluster(payload?: IUpdateCluster) {
    return yield this.effects.call(
      createService(productName, 'UpdateCluster'),
      payload,
    );
  }

  // 应用防护-应用管理-集群流控设置-创建QPS档位
  @effect()
  *createCluster(payload?: ICreateCluster) {
    return yield this.effects.call(
      createService(productName, 'CreateCluster'),
      payload,
    );
  }

  // 应用防护-应用管理-集群流控设置-开启QPS档位
  @effect()
  *setClusteron(payload?: ISetClusterOnOrOff) {
    return yield this.effects.call(
      createService(productName, 'Clusteron'),
      payload,
    );
  }

  // 应用防护-应用管理-集群流控设置-关闭QPS档位
  @effect()
  *setClusteroff(payload?: ISetClusterOnOrOff) {
    return yield this.effects.call(
      createService(productName, 'Clusteroff'),
      payload,
    );
  }

  // 应用防护-基础设置-创建防护模式配置
  @effect()
  *getSentinelModifyAppPriceLevel(payload?: ISentinelModifyAppPriceLevel) {
    return yield this.effects.call(
      createService(productName, 'SentinelModifyAppPriceLevel'),
      payload,
    );
  }

  // 应用防护-应用管理-基础设置-适配模块配置
  @effect()
  *getSentinelGetAdapterSettingOfApp(payload?: IAppMachineList) {
    return yield this.effects.call(
      createService(productName, 'SentinelGetAdapterSettingOfApp'),
      payload,
    );
  }

  // 应用防护-基础设置-适配模块-更新数据
  @effect()
  *getSentinelUpdateAdapterSettingOfApp(
    payload?: ISubmitDataWebAdd & CommonReq,
  ) {
    return yield this.effects.call(
      createService(productName, 'SentinelUpdateAdapterSettingOfApp'),
      payload,
    );
  }

  // 应用防护-基础设置-通用设置数据
  @effect()
  *getSentinelGetGeneralSettingOfApp(payload?: IAppMachineList) {
    return yield this.effects.call(
      createService(productName, 'SentinelGetGeneralSettingOfApp'),
      payload,
    );
  }

  // 应用防护-基础设置-通用设置-更新数据
  @effect()
  *getSentinelUpdateGeneralSettingOfApp(
    payload?: ISubmitDataBasicAdd & CommonReq,
  ) {
    return yield this.effects.call(
      createService(productName, 'SentinelUpdateGeneralSettingOfApp'),
      payload,
    );
  }

  // 应用防护-基础设置-集群流控客户端配置-获取数据
  @effect()
  *getSentinelClusterClientSettingOfApp(
    payload?: IClusterClientQuery,
  ) {
    return yield this.effects.call(
      createService(productName, 'GetSentinelClusterClientSettingOfApp'),
      payload,
    );
  }

  // 应用防护-基础设置-集群流控客户端配置-更新数据
  @effect()
  *UpdateSentinelClusterClientSettingOfApp(
    payload?: IClusterClientUpdate,
  ) {
    return yield this.effects.call(
      createService(productName, 'UpdateSentinelClusterClientSettingOfApp'),
      payload,
    );
  }

  // 应用防护-应用概述-图表数据、接口详情-查询csv格式数据
  @effect()
  *getQuerySentinelMetricsOfResource(
    payload?: IGetSentinelMetricsOfResourceReq,
  ) {
    const data = yield this.effects.call(
      createService(productName, 'QuerySentinelMetricsOfResource'),
      payload,
    );
    if (data) {
      const { Data = {} } = data;
      return Data;
    }
    return {};
  }

  // 应用防护-接口详情-查询pdf格式数据
  @effect()
  *getResourcesPDFReport(
    payload?: IGetResourcesPDFReport,
  ) {
    const data = yield this.effects.call(
      createService(productName, 'GetResourcesPDFReport'),
      payload,
    );
    if (data) {
      const { Data = {} } = data;
      return Data;
    }
    return {};
  }

  // 应用防护-应用概述-TOP（资源）
  @effect()
  *getSentinelMetricListTopNResourcesMetricSimple(
    payload?: ISentinelMetricListTopNResourcesMetricSimpleReq,
  ) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelMetricListTopNResourcesMetricSimple'),
      payload,
    );
    return Data;
  }


  // 应用防护-应用概述-TOP（机器）
  @effect()
  *getSentinelResourceTopNMacsWithMetrics(
    payload?: ISentinelResourceTopNMacsWithMetricsReq,
  ) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelResourceTopNMacsWithMetrics'),
      payload,
    );
    return Data;
  }

  // 应用防护-应用概述-获取自适应流控配置
  @effect()
  *getSentinelAdaptiveFlowSettingOfApp(
    payload?: ISentinelAdaptiveFlowSettingOfApp,
  ) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'GetSentinelAdaptiveFlowSettingOfApp'),
      payload,
    );
    return Data;
  }

  // 应用防护-应用概述-设置自适应流控配置
  @effect()
  *getUpdateSentinelAdaptiveFlowSettingOfApp(
    payload?: IUpdateSentinelAdaptiveFlowSettingOfApp,
  ) {
    const data = yield this.effects.call(
      createService(productName, 'UpdateSentinelAdaptiveFlowSettingOfApp'),
      payload,
    );
    return data;
  }

  // 规则管理-应用概述-获取版本号
  @effect()
  *getGetSentinelClientVersionOfAppPage(payload?: IClientVersionOfApp) {
    const data = yield this.effects.call(createService(productName, 'GetSentinelClientVersionOfApp'), payload);
    return data;
  }

  // 应用防护-应用概述-按资源分组获取系统资源
  @effect()
  *getQuerySystemResourceMetricOfGroup(payload?: ISystemResourceMetricOfGroup) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'QuerySystemResourceMetricOfGroup'), payload);
    return Data;
  }

  // 应用防护-应用概述-资源统计数据
  @effect()
  *getQuerySystemStatResourceMetricOfResource(payload?: ISystemStatResourceMetricOfResource) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'QuerySystemStatResourceMetricOfResource'), payload);
    return Data;
  }

  // 应用防护-应用概述-应用错误码
  @effect()
  *getQueryStatusNotFineOfApplication(payload?: INotFineOfResource) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'QueryStatusNotFineOfApplication'), payload);
    return Data;
  }

  // 应用防护-应用概述-接口错误码
  @effect()
  *queryStatusNotFineOfResource(payload?: INotFineOfResource) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'QueryStatusNotFineOfResource'), payload);
    return Data;
  }

  // 应用防护-应用概述-状态统计-节点分布Top
  @effect()
  *queryStatusTopOfResource(payload?: INotFineOfResource) {
    return yield this.effects.call(createService(productName, 'QueryStatusTopOfResource'), payload);
  }

  // 应用防护-应用概述-状态统计-节点分布Top
  @effect()
  *queryStatusNotFineOfResourceOnNode(payload?: INotFineOfResource) {
    return yield this.effects.call(createService(productName, 'QueryStatusNotFineOfResourceOnNode'), payload);
  }

  // 应用防护-应用概述-TopN错误码
  @effect()
  *getQueryStatusTopOfApplication(payload?: IStatusTopOfApplication) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'QueryStatusTopOfApplication'), payload);
    return Data;
  }

  // 应用防护-应用概述-指标详情-节点分位
  @effect()
  *queryResourceMetricOfResource(payload?: IResourceMetricOfResource) {
    return yield this.effects.call(createService(productName, 'QuerySystemStatResourceMetricOfResource'), payload);
  }

  // 应用防护-接口详情-全部防护事件列表
  @effect()
  *getSentinelAppEvents(payload?: ISentinelAppEvents) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelAppEvents'),
      payload,
    );
    return Data;
  }

  // 应用防护-接口详情-api防护事件列表
  @effect()
  *ListEventOfReource(payload?: any) {
    const { Data = {} } = yield this.effects.call(
      ahasMseRequest('mse', 'ListEventOfReource'),
      { params: { ...payload, Source: 'edasmsc' } },
    );
    return Data;
  }

  // @effect()
  // *getSentinelAppResourceEvents(payload?: ISentinelAppResourceEvents) {
  //   const { Data = {} } = yield this.effects.call(
  //     createService(productName, 'SentinelAppResourceEvents'),
  //     payload,
  //   );
  //   return Data;
  // }

  // 应用防护-接口详情-api防护事件-分节点详情
  @effect()
  *getSentinelMacMetricsOfResource(payload?: ISentinelMacMetricsOfResource) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'QuerySentinelMacMetricsOfResource'),
      payload,
    );
    return Data;
  }

  // 应用防护-接口详情-收藏接口
  @effect()
  *getSentinelFavoriteAddFavoriteResource(payload?: ISentinelFavorite) {
    const { Success = false } = yield this.effects.call(createService(productName, 'SentinelFavoriteAddFavoriteResource'), payload);
    return Success;
  }

  // 应用防护-接口详情-取消收藏接口
  @effect()
  *getSentinelFavoriteDeleteFavoriteResource(payload?: ISentinelFavorite) {
    const { Success = false } = yield this.effects.call(
      createService(productName, 'SentinelFavoriteDeleteFavoriteResource'),
      payload,
    );
    return Success;
  }

  // 应用防护-接口详情-机器top列表
  @effect()
  *getSentinelResourceTopNMacs(payload?: ISentinelResourceTopNMacs) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelResourceTopNMacs'),
      payload,
    );
    return Data;
  }

  // 应用防护-接口详情-统计模式列表数据
  @effect()
  *getSentinelResourcesPercentage(payload?: ISentinelResourcesPercentage) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelResourcesPercentage'),
      payload,
    );
    return Data;
  }

  // 应用防护-机器监控-callstack列表数据
  @effect()
  *getSentinelNodeListSentinelMachineNodes(payload?: ISentinelNodeListSentinelMachineNodes) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelNodeListSentinelMachineNodes'),
      payload,
    );
    return Data;
  }

  // 应用防护-机器监控-接口详情-api列表数据
  @effect()
  *getSentinelMacTopNResources(payload?: ISentinelMacTopNResources) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelMacTopNResources'),
      payload,
    );
    return Data;
  }

  // 应用防护-机器监控-全部节点-主机监控
  @effect()
  *querySystemResourceMetricOfGroup(payload?: ISystemResourceMetricOfGroup) {
    return yield this.effects.call(
      createService(productName, 'QuerySystemResourceMetricOfGroup'),
      payload,
    );
  }

  // 应用防护-机器监控-全部节点-某台机器-主机监控
  @effect()
  *querySystemResourceMetricOfGroupOnNode(payload?: ISystemResourceMetricOfGroup) {
    return yield this.effects.call(
      createService(productName, 'QuerySystemResourceMetricOfGroupOnNode'),
      payload,
    );
  }

  // 应用防护-列表
  @effect()
  *getSystemGuard(payload?: IMetericOfAppType) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelListTopNAppsSummaryMetricOfAppType'),
      payload,
    );
    return Data;
    // yield this.effects.put(this.setSystemGuard(systemGuard));
  }

  // 应用防护-收藏
  @effect()
  *getSentinelFavoriteAddFavoriteApp(payload?: IFavoriteApp) {
    return yield this.effects.call(
      createService(productName, 'SentinelFavoriteAddFavoriteApp'),
      payload,
    );
  }
  // 应用防护-取消收藏
  @effect()
  *getSentinelFavoriteDeleteFavoriteApp(payload?: IFavoriteApp) {
    return yield this.effects.call(
      createService(productName, 'SentinelFavoriteDeleteFavoriteApp'),
      payload,
    );
  }
  // 应用防护-新应用接口
  @effect()
  *getQueryLicenseKey(payload?: ILicenseKey) {
    return yield this.effects.call(
      createService(productName, 'QueryLicenseKey'),
      payload,
    );
  }

  // 应用防护-应用概览-查询异常charts
  @effect()
  *getApplicationExceptionStatistics(payload?: IStatusTopOfApplication) {
    return yield this.effects.call(
      createService(productName, 'ApplicationExceptionStatistics'),
      payload,
    );
  }

  // 应用防护-应用概览-查询最近一次异常Top
  @effect()
  *getApplicationLatestExceptions(payload?: ISentinelAdaptiveFlowSettingOfApp) {
    return yield this.effects.call(
      createService(productName, 'ApplicationLatestExceptions'),
      payload,
    );
  }

  // 应用防护-应用概览-查询某时刻异常Top
  @effect()
  *getApplicationExceptionsWithTime(payload?: ISentinelAdaptiveFlowSettingOfApp) {
    return yield this.effects.call(
      createService(productName, 'ApplicationExceptionsWithTime'),
      payload,
    );
  }

  // 应用防护-接口详情-查询接口异常charts
  @effect()
  *getResourceExceptionStatistics(payload?: IStatusTopOfApplication) {
    return yield this.effects.call(
      createService(productName, 'ResourceExceptionStatistics'),
      payload,
    );
  }

  // 应用防护-接口详情-查询接口最近一次异常Top
  @effect()
  *getResourceLatestExceptions(payload?: ISentinelAdaptiveFlowSettingOfApp) {
    return yield this.effects.call(
      createService(productName, 'ResourceLatestExceptions'),
      payload,
    );
  }

  // 应用防护-接口详情-查询接口某时刻异常Top
  @effect()
  *getResourceExceptionsWithTime(payload?: ISentinelAdaptiveFlowSettingOfApp) {
    return yield this.effects.call(
      createService(productName, 'ResourceExceptionsWithTime'),
      payload,
    );
  }

  // 应用防护-机器监控-查询接口异常charts
  @effect()
  *getNodeExceptionStatistics(payload?: IStatusTopOfApplication) {
    return yield this.effects.call(
      createService(productName, 'NodeExceptionStatistics'),
      payload,
    );
  }

  // 应用防护-机器监控-查询接口最近一次异常Top
  @effect()
  *getNodeExceptions(payload?: ISentinelAdaptiveFlowSettingOfApp) {
    return yield this.effects.call(
      createService(productName, 'NodeExceptions'),
      payload,
    );
  }

  // 应用防护-机器监控-查询接口某时刻异常Top
  @effect()
  *getNodeExceptionsWithTime(payload?: ISentinelAdaptiveFlowSettingOfApp) {
    return yield this.effects.call(
      createService(productName, 'NodeExceptionsWithTime'),
      payload,
    );
  }

  // 规则管理-规则分组list
  @effect()
  *getSentinelGetModelList(payload?: IAppMachineList) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'SentinelGetModelList'), payload);
    return Data;
  }

  // 规则管理-新建规则分组
  @effect()
  *getSentinelCreateMultiModel(payload?: ICreateMultiModel) {
    return yield this.effects.call(createService(productName, 'SentinelCreateMultiModel'), payload);
  }

  // 规则管理-删除规则分组
  @effect()
  *getSentinelDeleteMultiModel(payload?: IDeleteMultiModel) {
    return yield this.effects.call(createService(productName, 'SentinelDeleteMultiModel'), payload);
  }

  // 规则管理-变更生效规则分组
  @effect()
  *getSentinelChangeModel(payload?: ISentinelChangeModel) {
    return yield this.effects.call(createService(productName, 'SentinelChangeModel'), payload);
  }

  // 规则管理-获取集群流控规则列表
  @effect()
  *getSentinelFlowRuleListAll(payload?: IFlowRuleListAllApp) {
    return yield this.effects.call(createService(productName, 'SentinelFlowRuleListAll'), payload);
  }

  // 规则管理-规则流控-关闭状态
  @effect()
  *getSentinelFlowRuleOffBatch(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateFlowRulesStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则流控-开启状态
  @effect()
  *getSentinelFlowRuleOnBatch(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateFlowRulesStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则流控-开启状态
  @effect()
  *getSentinelIsolationRuleOnBatch(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateIsolationRulesStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则流控-删除
  @effect()
  *getSentinelFlowRuleDelete(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'DeleteFlowRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则隔离-删除
  @effect()
  *getSentinelIsolationRuleDelete(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'DeleteIsolationRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则流控-新增
  @effect()
  *getSentinelFlowRuleNew(payload?: IFlowRuleNew) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateFlowRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则隔离-新增
  @effect()
  *getSentinelIsolationRuleNew(payload?: IFlowRuleNew) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateIsolationRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则流控-编辑
  @effect()
  *getSentinelFlowRuleEdit(payload?: IFlowRuleNew) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateFlowRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则隔离-编辑
  @effect()
  *getSentinelIsolationRuleEdit(payload?: IFlowRuleNew) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateIsolationRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则流控-查询规则（分页）
  @effect()
  *getSentinelFlowRuleListByPage(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListFlowRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-规则隔离-查询规则（分页）
  @effect()
  *getSentinelIsolationRuleListByPage(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListIsolationRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-降级规则-列表
  @effect()
  *getSentinelDegradeRuleListAll(payload?: IDegradeRuleListAll) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'SentinelDegradeRuleListAll'), payload);
    return Data;
  }

  // 规则管理-降级规则-列表(分页)
  @effect()
  *getSentinelDegradeRuleListByPage(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListCircuitBreakerRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-默认熔断规则-列表(分页)
  @effect()
  *getListSentinelAllDefaultCircuitBreakerRule(payload?: IDegradeRuleListAll) {
    return yield this.effects.call(createService(productName, 'ListSentinelAllDefaultCircuitBreakerRule'), payload);
  }

  // 规则管理-降级规则-删除
  @effect()
  *getSentinelDegradeRuleDelete(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'DeleteCircuitBreakerRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-默认熔断规则-删除
  @effect()
  *getDeleteSentinelDefaultCircuitBreakerRule(payload?: IDegradeRuleDelete) {
    return yield this.effects.call(createService(productName, 'DeleteSentinelDefaultCircuitBreakerRule'), payload);
  }

  // 规则管理-降级规则-关闭状态
  @effect()
  *getSentinelDegradeRuleOffBatch(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateCircuitBreakerRulesStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-默认熔断规则-开启状态
  @effect()
  *getDisableSentinelDefaultCircuitBreakerRule(payload?: IDegradeRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'DisableSentinelDefaultCircuitBreakerRule'), payload);
  }

  // 规则管理-降级规则-开启状态
  @effect()
  *getSentinelDegradeRuleOnBatch(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateCircuitBreakerRulesStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-默认熔断规则-开启状态
  @effect()
  *getEnableSentinelDefaulCircuitBreakerRule(payload?: IDegradeRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'EnableSentinelDefaulCircuitBreakerRule'), payload);
  }

  // // 规则管理-降级流控-新增
  // @effect()
  // *getSentinelDegradeRuleNew(payload?: IDegradeRuleNew) {
  //   return yield this.effects.call(createService(productName, 'SentinelDegradeRuleNew'), payload);
  // }

  // 规则管理-降级流控-新增
  @effect()
  *getSentinelDegradeRuleNew(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateCircuitBreakerRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-默认熔断规则-新增
  @effect()
  *getCreateSentinelDefaultCircuitBreakerRule(payload?: IDegradeRuleNew) {
    return yield this.effects.call(createService(productName, 'CreateSentinelDefaultCircuitBreakerRule'), payload);
  }

  // 规则管理-降级流控-保存
  @effect()
  *getSentinelDegradeRuleEdit(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateCircuitBreakerRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 规则管理-默认熔断规则-保存
  @effect()
  *getEditSentinelDefaultCircuitBreakerRule(payload?: IDegradeRuleNew) {
    return yield this.effects.call(createService(productName, 'EditSentinelDefaultCircuitBreakerRule'), payload);
  }

  // 规则管理-系统规则-列表
  @effect()
  *getSentinelSystemRuleListAll(payload?: ISystemRuleListAll) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'SentinelSystemRuleListAll'), payload);
    return Data;
  }

  // 规则管理-系统规则-删除
  @effect()
  *getSentinelSystemRuleDelete(payload?: IDegradeRuleDelete) {
    return yield this.effects.call(createService(productName, 'SentinelSystemRuleDelete'), payload);
  }
  // 规则管理-系统规则-关闭状态
  @effect()
  *getSentinelSystemRuleOffBatch(payload?: IDegradeRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'SentinelSystemRuleOffBatch'), payload);
  }

  // 规则管理-系统规则-开启状态
  @effect()
  *getSentinelSystemRuleOnBatch(payload?: IDegradeRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'SentinelSystemRuleOnBatch'), payload);
  }

  // 规则管理-系统规则-新增
  @effect()
  *getSentinelSystemRuleNew(payload?: ISystemRuleNew) {
    return yield this.effects.call(createService(productName, 'SentinelSystemRuleNew'), payload);
  }

  // 规则管理-系统规则-编辑
  @effect()
  *getSentinelSystemRuleEdit(payload?: ISystemRuleNew) {
    return yield this.effects.call(createService(productName, 'SentinelSystemRuleEdit'), payload);
  }
  // 规则管理-热点规则-列表
  @effect()
  *getQuerySentinelHotparamRule(payload?: IHotparamRule) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'QuerySentinelHotparamRule'), payload);
    return Data;
  }

  // 规则管理-热点规则-列表(分页)
  @effect()
  *getSentinelParamRuleListByPage(payload?: IParamRuleListByPage) {
    return yield this.effects.call(createService(productName, 'SentinelParamRuleListByPage'), payload);
  }

  // 规则管理-热点规则-删除
  @effect()
  *getSentinelHotParamRuleDelete(payload?: IHotParamRuleDelete) {
    return yield this.effects.call(createService(productName, 'SentinelHotParamRuleDelete'), payload);
  }

  // 规则管理-热点规则-关闭状态
  @effect()
  *getSentinelHotParamRuleOffBatch(payload?: IHotParamRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'SentinelHotParamRuleOffBatch'), payload);
  }

  // 规则管理-热点规则-开启状态
  @effect()
  *getSentinelHotParamRuleOnBatch(payload?: IHotParamRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'SentinelHotParamRuleOnBatch'), payload);
  }

  // 规则管理-热点规则-新增
  @effect()
  *getAddSentinelHotParamRule(payload?: IHotParamRule) {
    return yield this.effects.call(createService(productName, 'AddSentinelHotParamRule'), payload);
  }

  // 规则管理-热点规则-新增
  @effect()
  *getEditSentinelHotParamRule(payload?: IHotParamRule) {
    return yield this.effects.call(createService(productName, 'EditSentinelHotParamRule'), payload);
  }

  // 规则管理-热点规则-版本号校验提醒弹窗
  @effect()
  *getGetSentinelClientVersionOfApp(payload?: IClientVersionOfApp) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'GetSentinelClientVersionOfApp'), payload);
    return Data;
  }

  // 规则管理-自动重试规则-列表
  @effect()
  *getListSentinelRetryRules(payload?: IDegradeRuleListAll) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'ListSentinelRetryRules'), payload);
    return Data;
  }

  // 规则管理-自动重试规则-新增
  @effect()
  *getCreateSentinelRetryRule(payload?: IAutoRetryRuleRecordAdd) {
    return yield this.effects.call(createService(productName, 'CreateSentinelRetryRule'), payload);
  }

  // 规则管理-自动重试规则-更新
  @effect()
  *getUpdateSentinelRetryRule(payload?: IAutoRetryRuleRecordAdd) {
    return yield this.effects.call(createService(productName, 'UpdateSentinelRetryRule'), payload);
  }

  // 规则管理-自动重试规则-删除
  @effect()
  *getDeleteSentinelRetryRule(payload?: IDegradeRuleDelete) {
    return yield this.effects.call(createService(productName, 'DeleteSentinelRetryRule'), payload);
  }

  // 规则管理-自动重试规则-开启状态
  @effect()
  *getEnableSentinelRetryRule(payload?: IAutoRetryRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'EnableSentinelRetryRule'), payload);
  }

  // 规则管理-自动重试规则-关闭状态
  @effect()
  *getDisableSentinelRetryRule(payload?: IAutoRetryRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'DisableSentinelRetryRule'), payload);
  }

  // 规则管理-自动重试规则-批量开启状态
  @effect()
  *getBatchEnableSentinelRetryRules(payload?: IDegradeRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'BatchEnableSentinelRetryRules'), payload);
  }

  // 规则管理-自动重试规则-批量关闭状态
  @effect()
  *getBatchDisableSentinelRetryRules(payload?: IDegradeRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'BatchDisableSentinelRetryRules'), payload);
  }

  // 规则管理-操作日志-列表
  @effect()
  *getSentinelOperationLogListOpLogs(payload?: IOperationLogListOpLogs) {
    const { Data = [] } = yield this.effects.call(createService(productName, 'SentinelOperationLogListOpLogs'), payload);
    return Data;
  }

  // 规则管理-事件中心
  @effect()
  *getSentineRulelAppEvents(payload?: IRulelAppEvents) {
    const { Data = {} } = yield this.effects.call(
      createService(productName, 'SentinelAppEvents'),
      payload,
    );
    return Data;
  }

  // 规则管理-热点规则-例外事项
  @effect()
  *getSAddSentinelHotParamItems(payload?: IHotParamItems) {
    return yield this.effects.call(createService(productName, 'AddSentinelHotParamItems'), payload);
  }

  // 集群流控管理后台-获取 server 列表
  @effect()
  *getListSentinelManagedTokenServers(payload?: IManagedTokenServers) {
    return yield this.effects.call(createService(productName, 'ListSentinelManagedTokenServers'), payload);
  }

  // 集群流控管理后台-获取 Server 详情接口
  @effect()
  *getSentinelManagedTokenServerDetail(payload?: ITokenServerDetail) {
    return yield this.effects.call(createService(productName, 'GetSentinelManagedTokenServerDetail'), payload);
  }

  // 集群流控管理后台-变更所属 server
  @effect()
  *getSwitchSentinelTokenServerForAssign(payload?: ITokenServerForAssign) {
    return yield this.effects.call(createService(productName, 'SwitchSentinelTokenServerForAssign'), payload);
  }

  // 集群流控管理后台-标记重新分配
  @effect()
  *getSentinelClusterAssignMarkDirty(payload?: IAssignMarkDirty) {
    return yield this.effects.call(createService(productName, 'SentinelClusterAssignMarkDirty'), payload);
  }

  // 集群流控管理后台-修改 token server 基础配置
  @effect()
  *updateSentinelManagedTokenServerConfig(payload?: IUpdateServerConfig) {
    return yield this.effects.call(createService(productName, 'UpdateSentinelManagedTokenServerConfig'), payload);
  }

  // 主动降级规则-新增处理行为
  @effect()
  *createSentinelBlockFallbackDefinition(payload?: IBlockFallbackDefinition) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateSentinelBlockFallbackDefinition'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 主动降级规则-编辑处理行为
  @effect()
  *updateSentinelBlockFallbackDefinition(payload?: IBlockFallbackDefinition) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateSentinelBlockFallbackDefinition'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 主动降级规则-删除处理行为
  @effect()
  *deleteSentinelBlockFallbackDefinition(payload?: IDeleteBlockFallbackDefinition) {
    return yield this.effects.call(ahasMseRequest('mse', 'DeleteSentinelBlockFallbackDefinition'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 主动降级规则-查询处理行为列表
  @effect()
  *queryListSentinelBlockFallbackDefinitions(payload?: IListSentinelBlockFallback) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListSentinelBlockFallbackDefinitions'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 行为管理-校验rpc
  @effect()
  *queryTestBlockFallbackDefinitionBehavior(payload?: ITestRpcBlockFallbackDefinition) {
    return yield this.effects.call(createService(productName, 'TestBlockFallbackDefinitionBehavior'), payload);
  }

  // 行为管理-绑定接口
  @effect()
  *queryBindSentinelBlockFallbackDefinition(payload?: IBindSentinelBlockFallbackDefinition) {
    return yield this.effects.call(ahasMseRequest('mse', 'BindSentinelBlockFallbackDefinition'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 主动降级规则-查询规则列表
  @effect()
  *queryListSentinelManualDegradeRulesByPage(payload?: IListManualDegradeRulesByPage) {
    return yield this.effects.call(createService(productName, 'ListSentinelManualDegradeRulesByPage'), payload);
  }

  // 主动降级规则-创建规则
  @effect()
  *createSentinelManualDegradeRule(payload?: ICreateSentinelManualDegradeRule) {
    return yield this.effects.call(createService(productName, 'CreateSentinelManualDegradeRule', { ignoreError: true }), payload);
  }

  // 主动降级规则-编辑规则
  @effect()
  *updateSentinelManualDegradeRule(payload?: ICreateSentinelManualDegradeRule) {
    return yield this.effects.call(createService(productName, 'UpdateSentinelManualDegradeRule'), payload);
  }

  // 主动降级规则-删除规则
  @effect()
  *deleteSentinelManualDegradeRule(payload?: IDeleteBlockFallbackDefinition) {
    return yield this.effects.call(createService(productName, 'DeleteSentinelManualDegradeRule'), payload);
  }

  // 主动降级规则-开启规则
  @effect()
  *batchEnableSentinelManualDegradeRules(payload?: IFlowRuleOffOmBatch) {
    return yield this.effects.call(createService(productName, 'BatchEnableSentinelManualDegradeRules'), payload);
  }

  // 主动降级规则-关闭规则
  @effect()
  *batchDisableSentinelManualDegradeRules(payload?: IFlowRuleOffOmBatch) {
    return yield this.effects.call(createService(productName, 'BatchDisableSentinelManualDegradeRules'), payload);
  }

  // Nginx防护-Api管理-查询规则
  @effect()
  *getSentinelHttpApiMatchQueryForApp(payload?: IGetClusterDetail) {
    return yield this.effects.call(createService(productName, 'SentinelHttpApiMatchQueryForApp'), payload);
  }

  // Nginx防护-Api管理-删除规则
  @effect()
  *getSentinelHttpApiMatchDelete(payload?: IFlowRuleOnOff) {
    return yield this.effects.call(createService(productName, 'SentinelHttpApiMatchDelete'), payload);
  }

  // Nginx防护-Api管理-新增规则
  @effect()
  *getSentinelHttpApiMatchNew(payload?: ISentinelHttpApiMatchNew) {
    return yield this.effects.call(createService(productName, 'SentinelHttpApiMatchNew'), payload);
  }

  // Nginx防护-Api管理-编辑规则
  @effect()
  *getSentinelHttpApiMatchUpdate(payload?: ISentinelHttpApiMatchUpdate) {
    return yield this.effects.call(createService(productName, 'SentinelHttpApiMatchUpdate'), payload);
  }

  // Nginx防护-Api管理-编辑未匹配规则API的命名方式
  @effect()
  *getHttpApiMatchUpdateDefault(payload?: IHttpApiMatchUpdateDefault) {
    return yield this.effects.call(createService(productName, 'SentinelHttpApiMatchUpdateDefault'), payload);
  }

  // 服务压测-获取接口相关数据
  @effect()
  *getSentinelMachineSecurityInfoList(payload?: IAppMetricOverview) {
    return yield this.effects.call(createService(productName, 'SentinelMachineSecurityInfoList'), payload);
  }

  // 服务压测-获取压测结果
  @effect()
  *queryDescribeScenarioRecord(payload?: IDescribeScenarioRecord) {
    return yield this.effects.call(createServiceMst(productName, 'DescribeScenarioRecord'), payload);
  }

  // 服务压测-获取压测结果状态
  @effect()
  *queryDescribeScenarioStatus(payload?: IDescribeScenarioStatus) {
    return yield this.effects.call(createServiceMst(productName, 'DescribeScenarioStatus'), payload);
  }

  // 服务压测-获取压测运行记录列表
  @effect()
  *queryListScenarioRecords(payload?: IListScenarioRecords) {
    return yield this.effects.call(createServiceMst(productName, 'ListScenarioRecords'), payload);
  }

  // 服务压测-压测结果-获取压测日志下载地址
  @effect()
  *queryDescribeLogFile(payload?: IDescribeScenarioRecord) {
    return yield this.effects.call(createServiceMst(productName, 'DescribeLogFile'), payload);
  }

  // 服务压测-保存Http场景参数配置
  @effect()
  *saveScenarioSpringCloud(payload?: ISaveScenarioSpringCloud) {
    return yield this.effects.call(createServiceMst(productName, 'SaveScenarioSpringCloud'), payload);
  }

  // 服务压测-保存RPC场景参数配置
  @effect()
  *saveScenarioDubbo(payload?: ISaveScenarioSpringCloud) {
    return yield this.effects.call(createServiceMst(productName, 'SaveScenarioDubbo'), payload);
  }

  // 服务压测-启动压测
  @effect()
  *startScenario(payload?: IScenario) {
    return yield this.effects.call(createServiceMst(productName, 'StartScenario'), payload);
  }

  // 服务压测-停止压测
  @effect()
  *stopScenario(payload?: IScenario) {
    return yield this.effects.call(createServiceMst(productName, 'StopScenario'), payload);
  }

  // 服务压测-查询压测记录
  @effect()
  *queryDescribeScenarioRecordsForAhas(payload?: IDescribeScenarioRecordsForAhas) {
    return yield this.effects.call(createServiceMst(productName, 'DescribeScenarioRecordsForAhas'), payload);
  }

  // 服务压测-删除压测记录
  @effect()
  *deleteScenarioRecord(payload?: IDeleteScenarioRecord) {
    return yield this.effects.call(createServiceMst(productName, 'DeleteScenarioRecord'), payload);
  }

  // 告警管理-查询告警规则
  @effect()
  *queryAlarmRules(payload?: IQueryAlarmRules) {
    return yield this.effects.call(createService(productName, 'QueryAlarmRules'), payload);
  }

  // 告警管理-告警规则开启、关闭
  @effect()
  *updateAlarmStatus(payload?: IUpdateAlarmStatus) {
    return yield this.effects.call(createService(productName, 'UpdateAlarmStatus'), payload);
  }

  // 告警管理-告警规则删除
  @effect()
  *deleteAlarmRule(payload?: IDeleteAlarmRule) {
    return yield this.effects.call(createService(productName, 'DeleteAlarmRule'), payload);
  }

  // 告警管理-新增告警规则
  @effect()
  *addAlarmRule(payload?: IAddOrEditAlarmRule) {
    return yield this.effects.call(createService(productName, 'AddAlarmRule'), payload);
  }

  // 告警管理-编辑告警规则
  @effect()
  *updateAlarmRule(payload?: IAddOrEditAlarmRule) {
    return yield this.effects.call(createService(productName, 'UpdateAlarmRule'), payload);
  }

  // 告警管理-告警规则操作记录按操作人查询
  @effect()
  *queryAlarmRuleOperRecords(payload?: IQueryAlarmRuleOperRecords) {
    return yield this.effects.call(createService(productName, 'QueryAlarmRuleOperRecords'), payload);
  }

  // 告警管理-告警规则操作记录按告警名称查询
  @effect()
  *queryAlarmRecords(payload?: IQueryAlarmRuleOperRecords) {
    return yield this.effects.call(createService(productName, 'QueryAlarmRecords'), payload);
  }

  // 防护管理-关联接口及行为
  @effect()
  *getSentinelProtectionModuleNew(payload?: ISentinelProtectionModuleNew) {
    return yield this.effects.call(createService(productName, 'SentinelProtectionModuleNew'), payload);
  }

  // 防护管理-查询防护规则
  @effect()
  *querySentinelProtectionModuleListAllByPage(payload?: ISentinelProtectionModuleListAllByPage) {
    return yield this.effects.call(createService(productName, 'SentinelProtectionModuleListAllByPage'), payload);
  }

  // 防护管理-更新规则与行为绑定关系
  @effect()
  *onSentinelProtectionModuleUpdate(payload?: ISentinelProtectionModuleUpdate) {
    return yield this.effects.call(createService(productName, 'SentinelProtectionModuleUpdate'), payload);
  }

  // 防护管理-删除规则
  @effect()
  *onSentinelProtectionModuleDelete(payload?: ISentinelProtectionModuleUpdate) {
    return yield this.effects.call(createService(productName, 'SentinelProtectionModuleDelete'), payload);
  }

  // 防护管理-查询规则所属接口类型
  @effect()
  *querySentinelGetResourceFallback(payload?: ISentinelGetResourceFallback) {
    return yield this.effects.call(createService(productName, 'SentinelGetResourceFallback'), payload);
  }

  // 防护管理-取消关联行为
  @effect()
  *onUnbindSentinelBlockFallbackDefinition(payload?: IBindSentinelBlockFallbackDefinition) {
    return yield this.effects.call(createService(productName, 'UnbindSentinelBlockFallbackDefinition'), payload);
  }

  // 集群限流-集群list接口
  @effect()
  *queryClusterResources(payload?: IQueryClusterResources) {
    return yield this.effects.call(createService(productName, 'QueryClusterResources'), payload);
  }

  // 集群限流-集群限流统计
  @effect()
  *queryClusterStatistics(payload?: IClusterStatistics) {
    return yield this.effects.call(createService(productName, 'QueryClusterStatistics'), payload);
  }

  // 集群限流-请求流量环比
  @effect()
  *queryRelativeRatioQpsStatistics(payload?: IClusterStatistics) {
    return yield this.effects.call(createService(productName, 'QueryRelativeRatioQpsStatistics'), payload);
  }

  // 集群限流-TokenClient响应类型
  @effect()
  *queryClusterTypeStatistics(payload?: IClusterTypeStatistics) {
    return yield this.effects.call(createService(productName, 'QueryClusterTypeStatistics'), payload);
  }

  // 集群限流-TokenClient请求耗时
  @effect()
  *queryClusterTimeStatistics(payload?: IClusterTypeStatistics) {
    return yield this.effects.call(createService(productName, 'QueryClusterTimeStatistics'), payload);
  }

  // 集群限流-流量分布统计
  @effect()
  *queryFlowStatistics(payload?: IClusterTypeStatistics) {
    return yield this.effects.call(createService(productName, 'QueryFlowStatistics'), payload);
  }

  // 热点监控-获取热点规则list
  @effect()
  *queryParamRulesWithName(payload?: IQueryParamRulesWithName) {
    return yield this.effects.call(createService(productName, 'QueryParamRulesWithName'), payload);
  }

  // 热点监控-查询热点规则下详情
  @effect()
  *queryParamRuleHotKeysWithName(payload?: IQueryParamRulesWithName) {
    return yield this.effects.call(createService(productName, 'QueryParamRuleHotKeysWithName'), payload);
  }

  // 热点监控-查询热点规则详情下集群详情
  @effect()
  *queryParamRuleHotKeyStatistics(payload?: IQueryParamRuleHotKeyStatistics) {
    const res = yield this.effects.call(createService(productName, 'QueryParamHotKeys'), payload) || {};
    const { Data = {} } = res || {};
    return Data?.Metrics || '';
  }

  // 热点监控-查询热点规则详情下节点详情
  @effect()
  *queryParamRuleHotKeyStatisticsOnNode(payload?:any) {
    if (payload?.HotKey) {
      yield this.effects.put(this.setHotKey(payload?.HotKey));
    }
    const { Data = {} } = yield this.effects.call(createService(productName, 'QueryParamRuleHotKeyOnNodes'), { ...payload, Rule: this.state.activeHotSpotName, HotKey: this.state.HotKey });
    yield this.effects.put(this.keyStatisticsOnNode(Data || {}));
    return Data;
  }
  // web参数限流规则-获取规则list
  @effect()
  *querySentinelWebParamFlowRuleListByPage(payload?: ISentinelWebParamFlowRuleListByPage) {
    return yield this.effects.call(createService(productName, 'SentinelWebFlowRuleListByPage'), payload);
  }

  // web参数限流规则-开启规则
  @effect()
  *UpdateWebFlowRulesStatusquerySentinelWebFlowRuleOnBatch(payload?: IHotParamRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'SentinelWebFlowRuleOnBatch'), payload);
  }

  // web参数限流规则-关闭规则
  @effect()
  *querySentinelWebFlowRuleOffBatch(payload?: IHotParamRuleOffOnBatch) {
    return yield this.effects.call(createService(productName, 'SentinelWebFlowRuleOffBatch'), payload);
  }

  // web参数限流规则-删除规则
  @effect()
  *querySentinelWebParamFlowRuleDelete(payload?: IFlowRuleOnOff) {
    return yield this.effects.call(createService(productName, 'SentinelWebFlowRuleDelete'), payload);
  }

  // web参数限流规则-新建规则
  @effect()
  *querySentinelWebParamFlowRuleNew(payload?: IGatewayFlowRuleNew) {
    return yield this.effects.call(createService(productName, 'SentinelWebFlowRuleNew'), payload);
  }

  // web参数限流规则-查询告警规则list
  @effect()
  *queryAllAlarmRules(payload?: IQueryAllAlarmRules) {
    return yield this.effects.call(createService(productName, 'QueryAllAlarmRules'), payload);
  }

  // web参数限流规则-编辑规则
  @effect()
  *querySentinelWebParamFlowRuleEdit(payload?: IGatewayFlowRuleNew) {
    return yield this.effects.call(createService(productName, 'SentinelWebFlowRuleEdit'), payload);
  }

  // web参数限流规则-编辑规则
  @effect()
  *getSentinelCheckSubUserAuth() {
    return yield this.effects.call(createService(productName, 'SentinelCheckSubUserAuth'));
  }

  // MSE接口demo
  @effect()
  // *getMSEAppList(payload?: any) {
  //   return yield this.effects.call(createService('mse', 'GetApplicationList'), payload);
  // }

  @effect()
  *FetchLosslessRuleList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'FetchLosslessRuleList'), { params: { ...payload, Source: 'edasmsc' } });
  }
  @effect()
  *GetLosslessRuleByApp(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetLosslessRuleByApp'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *GetApplicationInstances(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetApplicationInstanceList'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *GetUserStatus(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetUserStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ListApplicationsWithTagRules(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListApplicationsWithTagRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ApplyTagPolicies(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ApplyTagPolicies'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *getCanaryPolicy(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetCanaryPolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *getRoutePolicy(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetRoutePolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ListApplicationTagInstancese(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListApplicationTagInstancese'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *getServiceList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetServiceList'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *GetAppMessageQueueRoute(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetAppMessageQueueRoute'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *GetApplicationTags(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetApplicationTagList'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *UpdateMessageQueueRoute(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateMessageQueueRoute'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ListEventsPage(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListEventsPage'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *QueryAppRPCMacMetrics(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryAppRPCMacMetrics'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ModifyLosslessRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ModifyLosslessRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *QueryEventOverview(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryEventOverview'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *QueryEmptyPushSetting(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryEmptyPushSetting'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *CreateOrUpdateEmptyPushSetting(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateOrUpdateEmptyPushSetting'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *GetAppList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetApplicationList'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *fetchAuthenticationList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListAuthPolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *updateAuthentication(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateAuthPolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *removeAuthentication(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'RemoveAuthPolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *fetchAuthenticationInfo(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetAuthPolicyInfo'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *RevertApplicationRoutePolicy(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'RevertApplicationRoutePolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *fetchApplicationsByRpcType(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetOutlierApplicationList'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *addOutlierEjection(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateOutlierConfig'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *fetchOutlierEjectionList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListOutlierPolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *removeOutlierEjection(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'RemoveOutlierPolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *updateOutlierEjectionConfig(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateOutlierConfig'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *QueryAppSummaryMetricsOverviewWithSentinel(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryAppSummaryMetricsOverviewWithSentinel'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *GetServiceMethodPageWithMetrics(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetServiceMethodPageWithMetrics'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *addAuthentication(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'AddAuthPolicy'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *CheckAuthPolicyName(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'CheckAuthPolicyName'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ListKubernetesNamespace(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListKubernetesNamespace'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // @effect()
  // *QueryAppDataSourceList(payload?: any) {
  //   return yield this.effects.call(createService('mse', 'QueryAppDataSourceList'), { ...payload, Source: 'edasmsc' });
  // }


  @effect()
  *GetLocalityRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetLocalityRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *UpdateLocalityRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateLocalityRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *QueryAppDataSourceList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryAppDataSourceList'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *QueryDatabaseRoute(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryDatabaseRoute'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *UpdateDatabaseRoute(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateDatabaseRoute'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *UpdateInstanceRegisterStatus(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateInstanceRegisterStatus'), { ...payload, Source: 'edasmsc' });
  }

  @effect()
  *CreateLicenseKey(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateLicenseKey'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ListDashboard(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListDashboard'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // @effect()
  // *ListDashboard(payload?: any) {
  //   return yield this.effects.call(ahasMseRequest('mse', 'ListDashboard'), { params: { ...payload, Source: 'edasmsc' } });
  // }
  @effect()
  *FetchLogConfig(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'FetchLogConfig'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *FetchAppLogConfig(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'FetchAppLogConfig'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *UpdateLogConfig(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateLogConfig'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *UpdateAppLogConfig(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateAppLogConfig'), { params: { ...payload, Source: 'edasmsc' } });
  }
  @effect()
  *AddWhiteScreenRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'AddWhiteScreenRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *FetchWhiteScreenRuleByAppId(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'FetchWhiteScreenRuleByAppId'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *FetchWhiteScreenRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'FetchWhiteScreenRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *DeleteWhiteScreenRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'DeleteWhiteScreenRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *UpdateWhiteScreenRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateWhiteScreenRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *GetApplicationInstanceList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetApplicationInstanceList'), { params: { ...payload, Source: 'edasmsc' } });
  }

  *GetArmsInstanceInfo(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetArmsInstanceInfo'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *FetchGlobalReadWriteSplitRules(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'FetchGlobalReadWriteSplitRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ApplyGlobalReadWriteSplitRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ApplyGlobalReadWriteSplitRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *FetchReadWriteSplitRules(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'FetchReadWriteSplitRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *ApplyReadWriteSplitRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ApplyReadWriteSplitRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *BatchUpdateReadWriteSplitEnable(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'BatchUpdateReadWriteSplitEnable'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *fetchServicesList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'fetchServicesList'), { params: { ...payload, Source: 'edasmsc' } });
  }
  // 日志治理白屏化规则 web接口列表
  @effect()
  *GetServiceMethodPageWithMetricsLogWeb(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetServiceMethodPageWithMetrics'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *listGrayTag(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'listGrayTag'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *QueryServiceDetailWithMetrics(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryServiceDetailWithMetrics'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *AnalyzeProductLog(payload?: any) {
    return yield this.effects.call(ahasMseRequest('sls-inner', 'AnalyzeProductLog'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *BatchUpdateRulesEnable(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'BatchUpdateRulesEnable'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 应用防护-应用概述-图表数据、接口详情-查询csv格式数据
  @effect()
  *getQueryAppResourceMetrics(
    payload?: any,
  ) {
    const data = yield this.effects.call(
      ahasMseRequest('mse', 'QueryAppResourceMetrics'),
      payload,
    );
    if (data) {
      return data;
    }
    return {};
  }

  @effect()
  *getAppResourceMetricsByInstance(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryAppResourceMetricsByInstance'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // @effect()
  // *getSystemGuardApp(payload?: any) {
  //   return yield this.effects.call(ahasMseRequest('mse', 'GetApplicationListWithMetircs'), { params: { ...payload, Source: 'edasmsc' } });
  // }

  @effect()
  *getSystemGuardApp(payload?: any) {
    const { Data = {} } = yield this.effects.call(
      ahasMseRequest('mse', 'GetApplicationListWithMetircs'),
      { params: { ...payload, Source: 'edasmsc' } },
    );
    return Data;
    // yield this.effects.put(this.setSystemGuard(systemGuard));
  }

  @effect()
  *getServicesList(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetServiceListPage'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *getServiceMethodPageWithMetrics(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetServiceMethodPageWithMetrics'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *getDubboServicePageWithMetrics(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetDubboServicePageWithMetrics'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *getApplicationInstancesWithMetrics(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'GetApplicationInstancesWithMetircs'), { params: { ...payload, Source: 'edasmsc' } });
  }

  *FetchDataSourceConfig(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'FetchDataSourceConfig'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *UpdateDataSourceConfig(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateDataSourceConfig'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 应用列表概览qps数据
  @effect()
  *QueryAppSummaryMetricsOverview(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryAppSummaryMetricsOverview'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 获取应用名称
  @effect()
  *ListLogSpanServices(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListLogSpanServices'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 获取spanName
  @effect()
  *ListSpanNames(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListSpanNames'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 获取主机地址
  @effect()
  *ListIpOrHosts(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListIpOrHosts'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *SearchTraces(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'SearchTraces'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *OpenXTraceService(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'OpenXTraceService'), { params: { ...payload, Source: 'edasmsc' } });
  }

  @effect()
  *CheckXTraceServiceStatus(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'CheckXTraceServiceStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 获取命名空间
  @effect()
  *QueryNamespace(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'QueryNamespace'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 删除命名空间
  @effect()
  *DeleteNamespace(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'DeleteNamespace'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 热点规则创建
  @effect()
  *CreateHotParamRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateHotParamRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 热点规则查询
  @effect()
  *ListHotParamRules(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListHotParamRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 热点规则编辑更新
  @effect()
  *UpdateHotParamRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateHotParamRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 热点规则删除
  @effect()
  *DeleteHotParamRules(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'DeleteHotParamRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // 热点规则 关闭状态
  @effect()
  *UpdateHotParamRulesStatus(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateHotParamRulesStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // web防护规则 -- 创建 
  @effect()
  *CreateWebFlowRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'CreateWebFlowRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // web防护规则 -- 查询
  @effect()
  *ListWebFlowRules(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'ListWebFlowRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // web防护规则 -- 编辑/更新
  @effect()
  *UpdateWebFlowRule(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateWebFlowRule'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // web防护规则 -- 删除
  @effect()
  *DeleteWebFlowRules(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'DeleteWebFlowRules'), { params: { ...payload, Source: 'edasmsc' } });
  }

  // web防护规则 -- 开启/关闭
  @effect()
  *UpdateWebFlowRulesStatus(payload?: any) {
    return yield this.effects.call(ahasMseRequest('mse', 'UpdateWebFlowRulesStatus'), { params: { ...payload, Source: 'edasmsc' } });
  }


  // 应用治理-应用概述-TOP（资源）
  @effect()
  *getQueryResourceTopN(
    payload?: any,
  ) {
    return yield this.effects.call(
      ahasMseRequest('mse', 'QueryResourceTopN'),
      { params: { ...payload, Source: 'edasmsc' } },
    );
  }

  // 应用防护-应用概述-图表数据、接口详情-查询csv格式数据
  @effect()
  *getQueryAppMethodMetricsWithSentinel(
    payload?: any,
  ) {
    const data = yield this.effects.call(
      ahasMseRequest('mse', 'QueryAppMethodMetricsWithSentinel'),
      payload,
    );
    if (data) {
      return data;
    }
    return {};
  }

}

export default new FlowAppModel().model;

declare global {
  interface Actions {
    flowAppModel: FlowAppModel;
  }
}
