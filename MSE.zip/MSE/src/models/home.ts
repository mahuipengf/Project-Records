import createService from 'utils/createService_ahas';
import { BaseModel, dvaModel, effect, reducer } from '@ali/sre-utils-dva';
import {
  CommonReq,
  ICaculatePrice,
  ICreateNamespace,
  IFailureRehearse,
  IGetLivedPluginCount,
  IGetOverviewBasicReq,
  IGetTopologyEvents,
  IGlobalDataPackages,
  ILayoutOrder,
  IUpDatalayoutOrder,
  IoverViewOfAppsWithRelationship,
  IoverViewOfAppsWithoutRelationship,
  IsendHoloCommand,
} from 'config/interfaces';
import { mshaProductName, productName } from 'config/constants';

interface IHomeModelState {
  layoutOrder: ILayoutOrder[];
  overview: {
    hosts: number;
    FailInspectCount: number;
    sentinelApps: number;
    sentinelFlowRules: number;
    sentinelDegradeRules: number;
    sentinelSystemRules: number;
    sentinelGateways: number;
    sentinelGatewayRules: number;
    sentinelIsolateRules: number;
  };
  taskOverview: {
    total: number;
    failure: number;
    success: number;
    idle: number;
    active: number;
  };
  switchOverview: {
    SwitchCount: number;
    MachineCount: number;
    NameSpaceCount: number;
  };
  mshaOverView: {
    multiUnit: boolean;
    multiCell: boolean;
    tenants: number;
  }
  globalData: {
    ahasAgentLivedCount: number;
    ahasProEnable: boolean;
    ahasStatus: string;
    commercialSwitch: boolean;
    instanceCount: number;
    onlineTime: number;
    remainingTime: number;
    sub: boolean;
    remainingDate: number;
    sentinelResPackCount: number;
    sentinelRemainingResPack: number;
    packages: IGlobalDataPackages[];
  };
  [key: string]: any;
  paidData: {
    packType: string;
    payingUser: boolean;
    preText: string;
    sufText: string;
    preValue: number;
    sufValue: number;
    type: string;
  },
}

const DEFAULT_STATE: IHomeModelState = {
  layoutOrder: [],
  overview: {
    hosts: 0,
    FailInspectCount: 0,
    sentinelApps: 0,
    sentinelFlowRules: 0,
    sentinelDegradeRules: 0,
    sentinelSystemRules: 0,
    sentinelGateways: 0,
    sentinelGatewayRules: 0,
    sentinelIsolateRules: 0,
  },
  taskOverview: {
    total: 0,
    failure: 0,
    success: 0,
    idle: 0,
    active: 0,
  },
  mshaOverView: {
    multiUnit: false,
    multiCell: false,
    tenants: 0,
  },
  switchOverview: {
    SwitchCount: 0,
    MachineCount: 0,
    NameSpaceCount: 0,
  },
  globalData: {
    ahasAgentLivedCount: 0,
    ahasProEnable: false,
    ahasStatus: '',
    commercialSwitch: false,
    instanceCount: 0,
    onlineTime: 0,
    remainingTime: 0,
    remainingDate: 0,
    sentinelResPackCount: 0,
    sentinelRemainingResPack: 0,
    sub: false,
    packages: [
      {
        expireTime: '2021-02-20 00:00:00',
        packageType: '按量抵扣资源包',
        remaining: '500 节点*天',
        specification: '500 节点*天',
        startTime: '2020-11-19 11:11:11',
      },
    ],
  },
  paidData: {
    packType: '',
    payingUser: false,
    preText: '',
    preValue: 0,
    sufText: '',
    sufValue: 0,
    type: '',
  },
};

@dvaModel('homeModel')
class HomeModel extends BaseModel {
  state: IHomeModelState = DEFAULT_STATE;

  @reducer
  setLayoutOrder(payload: IHomeModelState['layout']) {
    return {
      ...this.state,
      layoutOrder: payload,
    };
  }

  @reducer
  setOverviewBasic(payload: IHomeModelState['overview']) {
    return {
      ...this.state,
      overviewBasic: {
        hosts: payload.hosts,
        failInspectCount: payload.FailInspectCount,
        sentinelApps: payload.sentinelApps,
        sentinelFlowRules: payload.sentinelFlowRules,
        sentinelDegradeRules: payload.sentinelDegradeRules,
        sentinelSystemRules: payload.sentinelSystemRules,
        sentinelGateways: payload.sentinelGateways,
        sentinelGatewayRules: payload.sentinelGatewayRules,
        sentinelIsolateRules: payload.sentinelIsolateRules,
      },
    };
  }

  @reducer
  setTaskOverview(payload: IHomeModelState['taskOverview']) {
    return {
      ...this.state,
      taskOverview: {
        total: payload.total,
        failure: payload.failure,
        success: payload.success,
        idle: payload.idle,
        active: payload.active,
      },
    };
  }

  @reducer
  setUserPayPackOverview(payload: IHomeModelState['paidData']) {
    return {
      ...this.state,
      paidData: {
        packType: payload.packType,
        payingUser: payload.payingUser,
        preText: payload.preText,
        preValue: payload.preValue,
        sufText: payload.sufText,
        sufValue: payload.sufValue,
        type: payload.type,
      },
    };
  }

  @reducer
  setMshaOverView(payload: IHomeModelState['mshaOverView']) {
    return {
      ...this.state,
      mshaOverView: payload,
    };
  }

  @reducer
  setSwitchOverview(payload: IHomeModelState['switchOverview']) {
    return {
      ...this.state,
      switchOverview: payload,
    };
  }

  @reducer
  setGlobals(payload: IHomeModelState['globalData']) {
    return {
      ...this.state,
      globalData: payload,
    };
  }

  @reducer
  clear(key?: string) {
    if (!key) {
      return {
        ...DEFAULT_STATE,
      };
    }
    return {
      ...this.state,
      [key]: DEFAULT_STATE[key],
    };
  }

  // 请求环境列表
  @effect()
  *getNamespaceList(payload?: CommonReq) {
    return yield this.effects.call(createService(productName, 'QueryNamespaceList'), payload);
  }

  // 请求某个环境下各指标数据
  @effect()
  *getLivedPluginCount(payload?: IGetLivedPluginCount) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'QueryLivedPluginCount'), payload);
    return Data;
  }

  // 删除环境
  @effect()
  *DeleteNamespace(payload?: IGetLivedPluginCount) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'DeleteNamespace'), payload);
    return Data;
  }

  // 新增环境
  @effect()
  *CreateNamespace(payload?: ICreateNamespace) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'CreateNamespace'), payload);
    return Data;
  }

  // 请求全局资源状况数据
  @effect()
  *getGlobals(payload?: CommonReq) {
    const { Data: globalData = {} } = yield this.effects.call(createService(productName, 'QueryGlobalData'), payload);
    yield this.effects.put(this.setGlobals(globalData));
  }

  // 请求流量防护数据
  @effect()
  *getOverviewBasic(payload?: IGetOverviewBasicReq) {
    const { Data: overviewBasic = {} } = yield this.effects.call(createService(productName, 'QueryOverviewBasic'), payload);
    yield this.effects.put(this.setOverviewBasic(overviewBasic));
  }

  // 请求流量防护-charts数据
  @effect()
  *getSentinelEventsCount(payload?: CommonReq) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'SentinelEventsCount'), payload);
    return Data;
  }

  // 请求请求流量防护-价格计算器数据
  @effect()
  *getCaculatePrice(payload?: ICaculatePrice) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'CaculatePrice'), payload);
    return Data;
  }


  // 请求公告数据
  @effect()
  *getSummaryNotice(payload?: CommonReq) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'QuerySummaryNotice'), payload);
    return Data;
  }

  // 请求产品快报数据
  @effect()
  *getSummaryExpress(payload?: CommonReq) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'QuerySummaryExpress'), payload);
    return Data;
  }

  // 请求开关预案数据
  @effect()
  *getSwitchOverview(payload?: CommonReq) {
    const { Data: switchOverview = {} } = yield this.effects.call(createService(productName, 'GetUserSummary'), payload);
    yield this.effects.put(this.setSwitchOverview(switchOverview));
  }

  // 请求自定义模块顺序数据
  @effect()
  *getCustomizeLayouts(payload?: CommonReq) {
    const { Data: layoutOrder = {} } = yield this.effects.call(createService(productName, 'QueryComponentLayouts'), payload);
    yield this.effects.put(this.setLayoutOrder(layoutOrder));
  }

  // 请求模块顺序数据
  @effect()
  *getComponentLayouts(payload?: CommonReq) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'QueryComponentLayouts'), payload);
    return Data;
  }

  // 更新模块顺序
  @effect()
  *setComponentLayouts(payload?: IUpDatalayoutOrder) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'UpdateComponentLayouts'), payload);
    return Data;
  }

  // 请求架构感知-charts 数据
  @effect()
  *getInspectFailCountChart(payload?: CommonReq) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'QueryInspectFailCountChart'), payload);
    return Data;
  }

  // 请求架构感知-事件列表数据
  @effect()
  *getTopologyEvents(payload?: IGetTopologyEvents) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'QueryEvents'), payload);
    return Data;
  }

  @effect()
  *getTaskOverview(payload?: IFailureRehearse) {
    const { Data: taskOverview = {} } = yield this.effects.call(createService(productName, 'ExperimentTaskOverview'), payload);
    yield this.effects.put(this.setTaskOverview(taskOverview));
  }

  // 请求故障演练-概览数据
  @effect()
  *getUserPayPackOverview(payload?: IFailureRehearse) {
    const { Data: taskOverview = {} } = yield this.effects.call(createService(productName, 'UserPayPackOverview'), payload);
    yield this.effects.put(this.setUserPayPackOverview(taskOverview));
  }

  // 请求故障演练-charts数据
  @effect()
  *getCountExperimentTaskByDay(payload?: IFailureRehearse) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'CountExperimentTaskByDay'), payload);
    return Data;
  }

  // 请求故障演练-故障场景数据
  @effect()
  *getCountFunctionInvocation(payload?: IFailureRehearse) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'CountFunctionInvocation'), payload);
    return Data;
  }

  // 请求msha数据
  @effect()
  *getMshaOverview(payload?: CommonReq) {
    const resouce = yield this.effects.call(createService(mshaProductName, 'GetUserProductInfo', {
      ignoreError: true,
    }), payload);

    // pop层code不为200 或者 业务层code不为200，将msha设为开通状态且开通数为0
    if (resouce.code !== '200') {
      const mshaOverview = {
        multiUnit: true,
        multiCell: false,
        tenants: 0,
      };

      yield this.effects.put(this.setMshaOverView(mshaOverview));
    } else {
      // 业务层code200，取msha接口返回数据
      const { data: mshaOverview = {} } = resouce;

      yield this.effects.put(this.setMshaOverView(mshaOverview));
    }
  }

  // 请求概览页面应用关系
  @effect()
  *getOverViewOfAppsWithRelationship(payload: IoverViewOfAppsWithRelationship) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'OverViewOfAppsWithRelationship'), payload);
    return Data;
  }

  // 请求概览页面应用关系
  @effect()
  *getOverViewOfAppsWithoutRelationship(payload?: IoverViewOfAppsWithoutRelationship) {
    const { Data = {} } = yield this.effects.call(createService(productName, 'OverViewOfAppsWithoutRelationship'), payload);
    return Data;
  }

  @effect()
  *getPtsSendHoloCommand(payload?: IsendHoloCommand) {
    const { Data = {} } = yield this.effects.call(createService('pts', 'SendHoloCommand'), payload);
    return Data;
  }
}

export default new HomeModel().model;

declare global {
  interface Actions {
    homeModel: HomeModel;
  }
}
