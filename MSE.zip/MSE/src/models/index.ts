import flowAppModel from './flowProtection/appProtection';
import homeModel from './home';
import switchModel from './switch';
import common from './common';
import flowGwModel from './flowProtection/gatewayProtection';

const models = [
  flowAppModel,
  homeModel,
  switchModel,
  common,
  flowGwModel
];

export default models;
