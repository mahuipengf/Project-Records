import createService from 'utils/createService_ahas';
import { BaseModel, dvaModel, effect, reducer } from '@ali/sre-utils-dva';
import { CommonReq } from '../config/interfaces';
import { productName } from '../config/constants';


interface ICommonState {
  licenseKey?: string;
}

const DEFAULT_STATE: ICommonState = {
  licenseKey: undefined,
};

@dvaModel('common')
class Common extends BaseModel {
  state: ICommonState = DEFAULT_STATE;

  @reducer
  setLicenseKey(licenseKey: string) {
    return {
      ...this.state,
      licenseKey,
    };
  }

  @effect()
  *getLicenseKey(payload?: CommonReq) {
    const { Data: licenseKey = {} } = yield this.effects.call(createService(productName, 'QueryLicenseKey'), payload);
    yield this.effects.put(this.setLicenseKey(licenseKey));
  }
}

export default new Common().model;

declare global {
  interface Actions {
    common: Common;
  }
}
