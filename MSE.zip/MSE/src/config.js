module.exports = {
  server: '',
  PAGESIZE: 15,
  TIMERDEFAULT: '5s',
  TIMEDURINT: 2000,
  is_preview: process.env.NODE_ENV === 'development',
  projectName: 'MSE',
};
