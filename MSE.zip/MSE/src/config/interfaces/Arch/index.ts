// 实例节点数据接口
export interface INodes {
  count?: number;
  group?: string;
  hostConfigurationId?: string;
  icon: string;
  id: string;
  instanceId: string;
  name: string;
  nameMinor?: string;
  ptsActive: boolean;
  type: number | string;
  viewId: string;
  status?: string;
  items: any[];
  instanceIconActive?: boolean;
  zone?: string;
  remove?: boolean;
  ExtFields?: {
    ip?: string;
  };
  shape: string;
  category?: string;
  x: number;
  y: number;
  riskLevel?: string;
  state?: string;
  cpuUtil?: number;
  memUtil?: number;
  eventCount?: number;
  alarmCount?: number;
  riskCount?: number;
  origin: string;
  sortId: number;
}

export interface IEdges {
  source: string;
  target: string;
  scope?: string;
  id?: number;
}

export * from './archMap';
export * from './archCheck';
export * from './archSetting';
