
import { CommonReq } from '../index';

export interface IArchCheckCommon extends CommonReq {
  ClusterId: string;
}

export interface ICancelInspection extends CommonReq {
  InspectResultId: number;
}

export interface IQueryInspectItem extends CommonReq {
  InspectId: number;
}

export interface ICheckResultData {
  Description: string;
  EndTime: number;
  FailInspectCount: number;
  Id: number;
  Namespace: string;
  Score: number;
  StartTime: number;
  Status: string;
  Title: string;
  TotalInspectCount: number;
  PassInspectCount: number;
}

export interface ICheckTableData {
  CategoryId: number | string;
  Description: string;
  FunctionCode: string;
  FunctionId: number;
  Id: number;
  InspectId: number;
  InspectStatus: string;
  LastCheckTime: number;
  Level: string;
  Name: string;
  RunStatus: string;
  Success: string;
}

export interface ICheckItemPanle {
  id: string;
  instanceId: string;
  'instanceId.link.topology': string;
  maxIOPS: number;
  mem: number;
  nodeType: number;
  version: string;
  zone: string;
}

export interface ICheckItemPanleHeader {
  Key: string;
  Name: string;
}

export interface IKubClusterParams extends CommonReq {
  RequestTimestamp: number;
}

export interface IKubClusterStateChildren {
  id: string;
  name: string;
}

export interface IKubClusterState extends IKubClusterStateChildren {
  kubNamespaces: string[];
  topologyCluster: IKubClusterStateChildren;
}

