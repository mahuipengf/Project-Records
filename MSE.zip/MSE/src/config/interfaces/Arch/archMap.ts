import SVG from '@svgdotjs/svg.js';
import { CommonReq } from '../index';
import { IEdges, INodes } from './index';
import { ReactNode } from 'react';

export interface IListTopologyViewParams extends CommonReq {
  Source: string;
}

export interface IListTopologySubViewParams extends CommonReq {
  ViewId: string;
}

export interface IQueryTopologyKubNamespaceListParams extends CommonReq {
  RequestTimestamp: number;
}

export interface ITopoNamespaces {
  name: string;
  checked: boolean;
}

export interface ITopoClusters {
  id: string;
  kubNamespaces: ITopoNamespaces[];
  name: string;
}

export interface ITopoStates {
  label: string;
  value: string;
  checked: boolean;
}

export interface ITopoHosts {
  configurationId: string;
  deviceId: string;
  deviceIp: string;
  deviceName: string;
  checked: boolean;
}

export interface IRtFliterArr {
  type: string;
  data: ITopoNamespaces[] | ITopoClusters[] | ITopoHosts[] | ITopoStates[] | ITopoAppFilters[];
}

export interface IRtFliterData {
  states: ITopoStates[];
  clusters: ITopoClusters[];
  hosts: ITopoHosts[];
  namespaces: ITopoNamespaces[];
  appFilters: ITopoAppFilters[];
}

export interface ISelectedProcessTypeMap {
  [key: string]: boolean;
}

export interface ISelectedHostTypeMap {
  [key: string]: boolean;
}

export interface ISelectedHostNodeTypeMap {
  [key: string]: boolean;
}

export interface IListTopologyViewResult {
  atomicViewId: string;
  category: string;
  deep: number;
  defaultGroupView: boolean;
  defaultView: boolean;
  description: string;
  environment: string;
  groupViewId: string;
  viewId: string;
  viewName: string;
  visibility: boolean;
  children: IListTopologyViewResult[];
}

export interface INodesEdges {
  nodes: INodes[];
  edges: IEdges[];
}

export interface IQueryTopologyGraphParams extends CommonReq {
  ViewId: string;
  RequestTimestamp: number;
  ShowUnconnected: boolean;
  Loop: boolean;
  Token: string;
  HostConfigurationId: string;
  KubNamespace: string;
  KubClusterId: string;
  State: string;
}

export interface IQueryTopologyNodeDetailParams extends CommonReq {
  ViewId: string;
  RequestTimestamp: number;
  ConfigurationId: string;
  KubNamespace?: string;
  KubClusterId?: string;
  HostConfigurationId?: string;
  NodeType?: string;
}
export interface IDetailCommon {
  hostConfigurationId?: string;
  id: string;
  instanceId: string;
  instanceUrl?: string;
  label: string;
  viewId?: string;
  nodeType?: number | null;
}

export interface IDetailMeta {
  label: string;
  value: string;
  url: string;
}

export interface IDetailMetrics {
  data: {[ key: string ]: number};
  key: string;
  label: string;
}

export interface IDetailProcesses {
  id: string;
  label: string;
  value: string;
  viewId: string;
}

export interface IDetailContainerImages {
  label: string;
}

export interface IDetailRules {
  label: string;
  value: string;
}

export interface IDetailPodsContainers {
  id: string;
  viewId: string;
  label: string;
}

export interface IDetailRisksItems {
  level: string;
  link: string;
  message: string;
  'metadata-desc': string;
  'metadata-descEn': string;
  'metadata-id': string;
  'metadata-name': string;
  'metadata-nameEn': string;
  reason: string;
  receiveTimestamp: string;
  subject: string;
  timestamp: string;
  type: string;
  idx: number;
  id: number;
}

export interface IDetailEventsRisksAlarms {
  items: IDetailRisksItems;
}

export interface IDetailInboundOutbound {
  canView: boolean;
  id: string;
  label: string;
  port: number;
  viewId: string;
}

export interface IDetailParents {
  id: string;
  label: string;
  value: string;
  viewId: string;
}

export interface INodeDetailResult extends IDetailCommon {
  meta: IDetailMeta[];
  metrics?: IDetailMetrics[];
  rules?: IDetailRules[];
  labels?: IDetailRules[];
  pods?: IDetailPodsContainers[];
  inbound?: IDetailInboundOutbound[];
  outbound?: IDetailInboundOutbound[];
  containers?: IDetailPodsContainers[];
  parents?: IDetailParents[];
  processes?: IDetailProcesses[];
  containerImages: IDetailContainerImages[];
  risks?: IDetailEventsRisksAlarms[];
  events?: IDetailEventsRisksAlarms[];
  alarms?: IDetailEventsRisksAlarms[];
}

export interface IQueryTopologyNodeMetricParams extends CommonReq {
  ViewId: string;
  ConfigurationId: string;
  MetricKey: string;
  StartTime: number;
  EndTime: number;
}

export interface IQueryTopologyIngressMetricParams extends CommonReq {
  ClusterId: string;
  ServiceName: string;
  RequestTimestamp: number;
}

export interface IIngressMetricResult {
  delayAvg: string;
  delayP95: string;
  delayP99: string;
  delayP9999: string;
  errorRate: string;
  pv: string;
  successRate: string;
  uv: string;
  dashboardName?: string;
  projectName?: string;
}

export interface IMetricFormat {
  title: string;
  subTitle: string;
  data: string | ReactNode;
  unit: string;
}

export interface IRedirectToNode {
  detailConnection: boolean;
  redirectToNode: (viewId: string, parentId: string) => void;
}

export interface IListTopologyGroupRiskValuesParams extends CommonReq {
  ViewId: string;
  Zone: string;
  Type: number;
  RequestTimestamp: number;
}

export interface IRiskDataResultItems {
  items: {
    'metadata-name': string;
    receiveTimestamp: string;
  };
}

export interface IRiskDataResult {
  name: string;
  riskCount: number;
  riskNodeCount: number;
  riskList: IRiskDataResultItems[];
}

export interface IQueryEventsParams extends CommonReq {
  PageNo: number;
  PageSize: number;
  Keyword: string;
}

export interface IK8sEventsResult {
  action: string;
  dataType: string;
  eventId: string;
  firstTimestamp: string;
  lastTimestamp: string;
  level: string;
  message: string;
  'metadata-account': string;
  'metadata-environment': string;
  'metadata-name': string;
  'metadata-nameEn': string;
  'metadata-viewId': string;
  reason: string;
  receiveTimestamp: string;
  'source-createTime': string;
  'source-id': string;
  'source-name': string;
  'source-namespace': string;
  'source-node': string;
  'source-uid': string;
  subject: string;
  timestamp: string;
  type: string;
  value: string;
  '__tag__:__receive_time__': string;
  '__topic__': string;
  idx: number;
  id: number;
}

export interface IListMetricsResult {
  desc: string;
  items: {
    average: number;
    maximum: number;
    minimum: number;
    timestamp: number;
    time: number;
    value: number;
  }[];
  metricName: string;
  unit: string;
}

export interface IListMetricsParams extends CommonReq {
  InstanceIds: string;
  MetricNames: string;
  InstanceType: string;
  Group: boolean;
  StartTime: number;
  EndTime: number;
}

export interface IListApplicationName extends CommonReq {
  ViewId: string;
  PageNo: number;
  PageSize: number;
}

export interface IListRevealApplicationFilter extends CommonReq {
  ViewId: string;
}

export interface ITopoAppFilters {
  code: string;
  explanation: string;
}

export interface IQueryAppPanoramicGraphParams extends CommonReq {
  ViewId: string;
  ApplicationName: string;
}

export interface IQueryAppPanoramicGraphResult <T extends IPanoramicNodes, U extends IPanoramicEdges> {
  nodes: T[];
  edges: U[];
  combos: IPanoramicCombos[];
}

export interface IPanoramicNodes {
  configurationId: string;
  deviceName: string;
  id: string;
  comboId: string;
  icon: string;
}

export interface IPanoramicEdges {
  source: string;
  target: string;
}

export interface IPanoramicCombos {
  nodeCount: number;
  sort: number;
  type: string;
  children: IPanoramicNodes[];
}


interface ICustomProto {
  moveTo?: (x: number, y: number, layer?: number, specScale?: number) => void;// 移动
  highLight?: () => void;// 高亮
  offLight?: () => void;// 暗淡
  selectedInfo?: () => void;// 选择
  changeName?: (name: string) => void;// change name
  checkNodeTextExist?: (item: INodes) => void;// 检查节点文案是否存在
  setNodeLayer?: (layer: number) => void;// 设置节点层级
  lineMove?: (x1: number, y1: number, x2: number, y2: number, layer: number) => void;// 线条移动
  setEdgeLayer?: (layer: number) => void;// 设置边层级
}

export interface ISVGgroup extends SVG.G, ICustomProto {}
export interface ISVGpanle extends SVG.Svg, ICustomProto {}
