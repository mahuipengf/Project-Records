import { CommonReq } from '../index';

export interface IListInspectRuleParams extends CommonReq {
  HideNotEnableFunction: boolean;
  HideExcludeFunction: boolean;
  PageNumber: number;
  CategoryId: number | string;
  PageSize?: number;
}

export interface IDEInspectRuleParams extends CommonReq {
  FunctionId: number;
}

export interface IListInspectRuleResult {
  CategoryId: number;
  Description: string;
  Enabled: boolean;
  Id: number;
  Name: string;
  Scope: string;
  CloudProducts?: string;
}

export interface IQuertInspectJobListReq extends CommonReq {
  HideNotEnable: boolean;
}

export interface IQuertInspectJobItem {
  ClusterName: string;
  Cron: string;
  Enable: boolean;
  Id: number;
  LastExecutionTime: string;
  Namespace: string;
  NextExecutionTime?: string;
  Termination: string;
  Type: string;
}

export interface IDeleteInspectJobReq extends CommonReq {
  Id: number;
}

export interface IQueryNextCronReq extends CommonReq {
  Cron: null | string;
  Day: null | string;
  Week: null | string;
  Time: string | number;
  ClusterId: string;
  TerminationDate: string | number;
  TerminationTime: string | number;
  id: string;
}

export interface ICreateAndUpdateInspectJobReq extends CommonReq {
  Cron: null | string;
  Day: null | string;
  Week: null | string;
  Time: string | number;
  ClusterId: string;
  Type: string;
  TerminationDate: string | number;
  TerminationTime: string | number;
  ClusterName: string;
  Namespace: string;
  Id?: string;
}

export interface IQuerySetTaskInfoReq extends CommonReq {
  id: string;
}

export interface ISetTaskInfo {
  ClusterName: string;
  Cron: string;
  Date: string;
  Day: string;
  Id: number;
  Namespace: string;
  Termination: string;
  Time: string;
  Type: string;
  Week: string;
}

