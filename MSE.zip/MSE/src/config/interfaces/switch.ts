import { CommonReq } from './index';

interface SwitchCommonReq {
  RegionId?: string;
  AhasRegionId?: string;
  Lang?: string;
  NameSpace?: string;
  Namespace?: string;
  // 大部分请求接口都用到了下面的字段，所以单独抽离出来一个switch的父类
  AppName?: string;
  SwitchName?: string;
  SwitchNameSpace?: string;
}

export interface ISlidePanelProps {
  isShowing: boolean;
  onMaskClick?: () => void;
  onClose?: () => void;
  onOk?: () => void;
  onCancel?: () => void;
  onSlideCompleted?: () => void;
}

export interface IGetSwitchAppListReq extends CommonReq {
  KeyWord?: string;
  AppTypes?: string;
  PageNo?: number;
  PageSize?: number;
  SourceType?: string;
}

export interface ISwitchAppVO {
  appName: string;
  machineCount: number;
  namespaceCount: number;
  switchCount: number;
  unFinishedPublishOrders: number;
  ahasAppName: string;
}

export interface IGetSwitchNameSpaceReq extends CommonReq {
  AppName: string;
}

export interface IGetSwitchesReq extends CommonReq {
  AppName: string;
  SwitchNameSpace?: string;
  KeyWord?: string;
  PageNo?: number;
  PageSize?: number;
}

export interface ISwitchVO {
  defaultValue?: string;
  des?: string;
  name?: string;
  nameSpace?: string;
  type?: string;
  value?: string;
  valueDes?: string;
  machineCount: number;
}

export interface ISwitchDetail {
  switchWrapper: ISwitchWrapper;
  appMachineDTO: IAppMachine;
  isNodeView?: boolean;
}

export interface ISwitchWrapper {
  valueDes: string;
  des: string;
  level: string;
  defaultValue: string;
  name: string;
  nameSpace: string;
  type: string;
  value: string;
  tags: string[];
}

export interface IAppMachine {
  privateIp: string;
  hostname: string;
  status: MACHINE_STATUS;
  processConfigurationId: string;
  grayTag: string;
}

export enum MACHINE_STATUS {
  ONLINE = 2,
  OFFLINE
}

export interface ISwitchLog {
  switchNamespace: string;
  appName: string;
  switchName: string;
  switchValue: string;
  operationType: string;
  id: number;
  userId: string;
  ipList: string[];
  operationTime: string;
  OperationType: string;
}

export interface IGetSwitchDetailReq extends SwitchCommonReq {
  Ip: string;
  PageNo: number;
  PageSize?: number;
}

export interface IUpdateMachineSwitchReq extends SwitchCommonReq {
  SwitchValue: string;
  Ips: string;
}

export interface IUpdateAppSwitchReq extends SwitchCommonReq {
  SwitchValue: string;
}

export interface IGetAppSwitchLogReq extends SwitchCommonReq {
  OperationType?: string;
  PageNo: number;
  PageSize: number;
  BeginTimeStamp?: number;
  EndTimeStamp?: number;
}

export interface ICreateBatchPublishOrderReq extends SwitchCommonReq {
  SwitchValue: string;
  PauseType: string;
  BatchNum: number;
}

export interface IGetPublishOrderStatusReq extends CommonReq {
  PublishOrderId: number;
}

export interface IPublishAppSwitchTargetBatchReq extends SwitchCommonReq {
  SwitchValue: string;
  TargetBatch: number;
  PublishOrderId: number;
}

export interface IRollBackPublishOrderReq extends CommonReq {
  PublishOrderId: number;
  RollbackValue: string;
}

export interface IGetUnFinishedPublishOrderAndStatistcReq extends CommonReq {
  AppName: string;
  SwitchName: string;
  SwitchNameSpace: string;
}

export interface IMachines {
  deviceType: number;
  pid: number;
  lastHealthPingTime: number;
  appType: number;
  id: number;
  startUpTime: number;
  pluginType: string;
  appName: string;
  privateIp: string;
  userId: string;
  version: string;
  processConfigurationId: string;
  hostname: string;
  vpcId: string;
  namespace: string;
  status: number;
}

export interface IGetAppUnFinishedPublishOrderAndMachinesReq extends CommonReq {
  AppName: string;
  pageNo?: number;
  pageSize?: number;
}

export interface ITerminatePublishOrderReq extends CommonReq {
  publishOrderId: number;
}

export enum PublishStatus {
  NONE = 'NONE',
  START = 'START',
  PAUSE = 'PAUSE',
  FINISHED = 'FINISHED',
  RUNNING = 'RUNNING',
  FAIL = 'FAIL',
  ROLLBACKING = 'ROLLBACKING',
  ROLLBACKED = 'ROLLBACKED'
}

export interface IUnFinishedPublishOrder {
  id: number;
  pauseType: string;
  switchNamespace: string;
  currentStatus: PublishStatus;
  appName: string;
  userId: string;
  switchName: string;
  switchDesc: string;
  switchType: string;
  namespace: string;
  switchValue: string;
  totalBatch: number;
  currentBatch: number;
  createTime: number;
  batchOrderDTOList: IBatchOrderDTO[];
}

export enum BatchStatus {
  NOT_START = 'NOT_START',
  RUNNING = 'RUNNING',
  FINISH = 'FINISH',
  FAIL = 'FAIL',
}

export interface IBatchOrderDTO {
  batchResultDTOList: IBatchResultDTO[];
  publishOrderId: number;
  batchNum: number;
  id: number;
  batchStatus: BatchStatus;
  ipList: string[];
}

interface IBatchResultDTO {
  success: boolean;
  batchOrderId: number;
  errorMessage: string;
  batchNum: number;
  id: number;
}

