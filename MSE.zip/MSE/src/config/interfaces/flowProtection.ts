// import { AttrTypeMapping } from '@svgdotjs/svg.js';
import { CommonReq } from './index';

/** **************** 应用防护模块开始 **************** **/

export interface IMetricListTop extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: number;
  SearchKey: string;
  OrderBy: number;
  Desc: boolean;
  AhasTimestamp: number;
  ResourceType: number;
  TrafficType?: string;
  EndTime?: number;
}

export interface IApiStatisticsRecord {
  type: number;
  resource: string;
  percentage: number;
  sum: number;
  passedQps: number;
  blockedQps: number;
  exception: number;
}

export interface IAppMetricOverview extends CommonReq {
  AppName: string | null;
}

export interface IListScenarioRecords extends CommonReq {
  pageNumber: number;
  pageSize: number;
  scenarioId: number;
}

export interface IStressRecords {
  RecordId: number;
  ScenarioId: number;
  Scenario?: any;
  StartTime: string;
  Status: string;
}

// 应用管理-权限管理单条数据
export interface Irecord {
  displayName: string;
  id: number | undefined;
  parentUid: string;
  roleType: number;
  subUserId: string;
  userName: string;
  comments?: string;
}

// 应用管理-修改权限参数接口
export interface IAuthorityParams extends CommonReq {
  Id: number | undefined;
  SubUid: string;
  UserName: string;
  DisplayName: string;
  roleType: number;
}

export interface IGetResourcesPDFReport extends CommonReq {
  ReportUUID: string;
  AppName: string | null;
  Resources: string;
  StartTime: number;
  EndTime: number;
}

export interface IAppMachineList extends CommonReq {
  AppName: string;
}

export interface ICreateMultiModel extends CommonReq {
  ModelName: string;
}

export interface IDeleteMultiModel extends CommonReq {
  Id: number;
  ModelId: number;
}

export interface ISentinelMetricListTopNResourcesMetricSimpleReq
  extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: number;
  OrderBy: number;
  Desc: boolean;
}

export interface ISentinelResourceTopNMacsWithMetricsReq extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: number;
  OrderBy?: number;
  Desc: boolean;
  AhasTimestamp: number;
  resource: string;
  Type: string
}

export interface ISentinelResourceTopNMacs extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: number;
  OrderBy: number;
  Desc: boolean;
  AhasTimestamp: number;
  Resource: string;
  SearchKey?: string;
}

export interface IManagedTokenServers extends CommonReq {
  TypeList: string;
  RequireAlive: boolean;
}

export interface IMonitorDetailsOfCluster {
  Block: number;
  Pass: number;
  Time: number;
}

export interface IMonitorDetailsOfNode {
  block: number;
  pass: number;
  time: number;
}

export interface ICurMetics {
  passedQps: number;
  blockedQps: number;
  exception: number;
  grayQps: number;
  allQps: number;
  rt: number;
  tagValues?: any,
  thread: number;
  timestamp: number;
  flowruletotal: number;
  flowRuleId: number;
  degradeRuleId:number;
  degraderuletotal:number;
  systemRuleId:number;
  systemruletotal:number;
  paramRuleId:number;
  paramruletotal:number;
  degraderulecount: number;
  flowrulecount: number;
  systemrulecount: number;
  paramrulecount: number;
  degradeRuleQPS:number;
  flowRuleQPS:number;
  systemRuleQPS:number;
  paramRuleQPS:number;
  manualDegradeRuleId: number;
  manualDegradeRuleQPS: number;
  grayStatistics?: any;
  PassQps: number;
  BlockQps: number;
  ExpQps: number;
  Qps: number;
  Rt: number;
  Timestamp: number;
  TagValues: any;
  concurrency?: any;
  Concurrency?: any;
  Thread?: any;
}

export interface IChartsDataSource {
  type: string;
  time: number;
  count: any;
  val?: string;
  degradeRuleId?: number;
  degradeRuleQPS?: number;
  flowRuleId?: number;
  flowRuleQPS?:number;
  systemRuleId?: number;
  systemRuleQPS?:number;
  paramRuleId?: number;
  paramRuleQPS?:number;
  manualDegradeRuleId?: number;
  manualDegradeRuleQPS?: number;
}

export interface IResourceMetricOfResource extends CommonReq {
  AppName: string | null;
  Group: string;
  Resource: string;
}

export interface IGetSentinelMetricsOfResourceReq extends CommonReq {
  AppName: string | null;
  Resource?: string;
  Node?: string;
  StartTime?: number;
  EndTime?: number;
  ProcessConfigurationId?: string;
  Loop?: boolean;
  AppId?: string;
}

export interface IMonitorDashboards extends CommonReq {
  AppName: string | null;
  MetricName: string;
  PageIndex: number;
  PageSize: number;
}

export interface IAddOrUpdateMonitorDashboardItems extends CommonReq {
  DashboardItems: string;
}
export interface ISortMonitorDashboardItems extends CommonReq {
  dashboardId: number;
  itemPosition: string;
}

export interface IDeleteMonitorDashboardItems extends CommonReq {
  DashboardItemIds: string;
}

export interface ISentinelResourcesPercentage extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: number;
  StartTime?: number;
  SearchKey: string;
  EndTime?: number;
  OrderBy: number;
  ResourceType: number;
}

export interface ISentinelMacTopNResources extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: number;
  ProcessConfigurationId: string;
  SearchKey: string;
  AhasTimestamp?: number;
  OrderBy: number;
  Desc: boolean;
  ResourceType: number;
}

export interface IThermodynamicDataReq extends CommonReq {
  AppName: string | null;
  Resource: string;
}

export interface ISentinelAppEvents extends CommonReq {
  AppName: string | null;
  pageSize: number;
  pageIndex: number;
  QueryLevel?: any;
  EventType?: any;
}

export interface ISentinelAppResourceEvents extends CommonReq {
  AppName: string | null;
  Resource: string;
  pageSize: number;
  pageIndex: number;
  sourceType?: string;
}

export interface IServerList {
  Alive: boolean;
  AssignGroupAmount: number;
  DeviceId: string;
  Id: number;
  InstanceId: string;
  MaxAllowedQps: number;
  OccupiedQps: number;
  PrivateIp: string;
  PublicIp: string;
  ServerPort: number;
  ServerType: number;
  SlbIp: string;
  VpcId: string;
}

export interface ITokenServerDetail extends CommonReq {
  Id: number;
}

export interface IAssignMarkDirty extends CommonReq {
  AssignId: number;
}

export interface ITokenServerForAssign extends IAssignMarkDirty {
  NewServerId: string;
}

export interface IUpdateServerConfig extends CommonReq {
  ServerId: string;
  MaxAllowedQps: number;
  MaxAllowedConnection?: number;
  ShareLevel?: number;
  Tags?: string;
}

export interface IQueryParamRuleHotKeyStatistics extends CommonReq {
  AppName?: string;
  Rule?: string;
  HotKey?: string;
  StartTime?: number;
  EndTime?: number;
  PageIndex?: number;
  PageSize?: number;
}

export interface ISentinelProtectionModuleNew extends CommonReq {
  AppName: string
  RuleId: number;
  RuleType: string;
  FallbackId: number;
}

export interface IProtectionAssociateAction {
  AppName: string
  RuleId: number;
  RuleType: string;
  FallbackId: number;
  ApiType: number;
}

export interface ISentinelMacMetricsOfResource extends CommonReq {
  Loop?: boolean;
  AppName: string | null;
  Resource: string;
  ProcessConfigurationId: string;
  endTime?: number;
  AppId?: string | null;
}

export interface IQueryParamRulesWithName extends CommonReq {
  AppName: string;
  Rule: string;
  HotKey?: string;
  PageIndex: number;
  PageSize: number;
}

export interface ISentinelNodeListSentinelMachineNodes extends CommonReq {
  AppName: string | null;
  Pid?: number;
  Ip?: string;
  ProcessConfigurationId: string;
  Type: string;
  VpcId?: string;
}

export interface ISentinelChangeModel extends CommonReq {
  AppName: string;
  OldModel: string;
  NewModel: number;
  NewRules?: string;
}

export interface ICallstackList {
  resource: string;
  passQps: number;
  blockQps: number;
  exceptionQps: number;
  averageRt: number;
  threadNum: number;
  id: string;
  oneMinuteBlock: number;
  oneMinuteException: number;
  oneMinutePass: number;
  parentId: string;
  successQps: number;
  timestamp: number;
  totalQps: number;
  key?: number;
  children?: Array<ICallstackList>;
  isChild?: boolean;
  isTop?: boolean;
}

export interface ISentinelFavorite extends CommonReq {
  AppName: string | null;
  Resource: string;
}

export interface IBlockFallbackDefinition extends CommonReq {
  AppName: string;
  Name: string;
  ResourceClassification: number;
  FallbackBehavior: string;
  Id?: number;
}

export interface IListSentinelManualDegradeRulesByPage extends CommonReq {
  AppName: string;
  Enabled: string;
  FallbackConfig: any;
  Id: number;
  id: number;
  ModelId: number;
  Namespace: string;
  Resource: string;
  ResourceMatchMode: number;
  UserId: string;
}

export interface IListSentinelBlockFallback extends CommonReq {
  AppName: string;
  ClassificationSet: string;
  ResourceClassification?: number;
}

export interface ITestRpcBlockFallbackDefinition extends CommonReq {
  AppName: string;
  FallbackBehavior: string;
}

export interface IBindSentinelBlockFallbackDefinition extends CommonReq {
  AppName: string;
  FallbackId: number;
  Resource: string;
  TargetType: number;
}

export interface IwebActionRules {
  AppName: string;
  FallbackBehavior: any;
  Id: number;
  Name: string;
  Namespace: string;
  ResourceClassification: number;
  UserId: string;
  TargetMap?: object;
  AssociatedResources?: number;
}

export interface IListManualDegradeRulesByPage extends CommonReq {
  AppName: string;
  PageIndex: number;
  PageSize: number;
  SearchKey: string;
  Model: number;
  Resource: string;
}

export interface ICreateSentinelManualDegradeRule extends CommonReq {
  AppName: string;
  Resource: string;
  Enabled: boolean;
  FallbackId: number;
  Id?: number;
}

export interface IDeleteBlockFallbackDefinition extends CommonReq {
  Id: number;
  AppName: string;
}

export interface IResourceTopNMacsItem {
  deviceConfigurationId?: string;
  deviceId?: string;
  parentIp?: string;
  pid?: number;
  privateIp?: string;
  processConfigurationId?: string;
  resource?: string;
  vpcId?: string;
  hostname?: string;
  PrivateIp?: string;
  Pid?: number;
  HostName?: string;
  Ip?: string;
}

export interface ISentinelListTopNApp extends CommonReq {
  latestPassQps: number;
  flowRuleApiCount: number;
  isolateRuleApiCount: number;
  latestBlockedQps: number;
  systemRuleApiCount?: number;
  machineCount: number;
  degradeRuleApiCount: number;
  metric: ISentinelListTopNAppMetric[];
  armsPid?: string;
  accessType?: string;
  app: string;
  ahasAppName?: string;
  favorite: boolean;
  appType?: number;
  clientVersion: {
    sdkVersion?: string;
    agentVersion?: string;
  }
  CurMetricsFm?: any;
  Source?: string;
  InstancesNumber?: number;
  AppId?: string;
  Tags?: any;
}

export interface ISentinelListTopNAppMetric {
  timestamp: number;
  successQps: number;
  blockedQps: number;
  passedQps: number;
  qps: number;
}

export interface IMetericOfAppType extends CommonReq {
  pageIndex: number;
  pageSize: number;
  searchKey: string;
  appTypes: number[] | string;
  SourceType?: string;
}

export interface IMetricQbs {
  time?: number;
  type?: string;
  count?: number;
}

export interface IExceptionStatistics {
  Timestamp: number;
  Count: number;
}

export interface IFavoriteApp extends CommonReq {
  AppName: string;
  AppType?: number;
}

export interface ILicenseKey extends CommonReq {
  params: any;
  region: string;
}
export interface ISetSystemGuard {
  metrics: ISentinelListTopNApp[];
  totalCount: number;
}

export interface ILanguAge {
  title: string;
  type: string;
}

export interface ISentinelModifyAppPriceLevel extends CommonReq {
  AppName: string;
  priceLevel: number;
}

export interface ISubmitDataWebAdd {
  AppName: string;
  WebFallbackMode: any;
  WebRespStatusCode: any;
  WebRedirectUrl: any;
}

export interface ISubmitDataBasicAdd {
  AppName: string;
  MaxResourceAmount: any;
  MaxOriginAmount: any;
  MaxContextAmount: any;
  StatisticMaxRt: any;
}

export interface ISubmitDataClientAdd {
  AppName: string;
  RequestTimeout: number;
}

interface IlabelCol {
  span: number;
}

interface IwrapperCol {
  span: number;
}

export interface IformItemLayout {
  labelCol: IlabelCol;
  wrapperCol: IwrapperCol;
}

export interface IAppData {
  machineCount: number;
  passQps_5m: number;
  blockQps_5m: number;
  expQps_5m: number;
  ydPassQps_5m: number;
  ydBlockQps_5m: number;
  ydExpQps_5m: number;
  chainPassQps_5m: number;
  chainBlockQps_5m: number;
  chainExpQps_5m: number;
  rtAvg: number;
  ydRtAvg: number;
  chainRtAvg: number;
}

export interface IChartDataSource {
  type?: string;
  time: number;
  count: number;
  degradeRuleQPS?: number;
  flowRuleQPS?:number;
  systemRuleQPS?:number;
  paramRuleQPS?:number;
  manualDegradeRuleQPS?: number;
}

export interface IMetricsData {
  passedQps?: number;
  blockedQps?: number;
  exception?: number;
  rt?: number;
  thread?: number;
  timestamp?: number;
  load?: number;
  cpu?: number;
  listType?: string;
  flowRuleQPS?: number;
  degradeRuleQPS?: number;
  systemRuleQPS?: number;
  paramRuleQPS?: number;
  manualDegradeRuleQPS?: number;
  grayQps?: number;
  allQps?: number;
  grayStatistics?: any;
  blockQps?: number;
  expQps?: number;
  passQps?: number;
  qps?: number;
  tagValues?: any;
}

export interface IApiPositionData {
  resource: string;
  passedQps: number;
  blockedQps: number;
  exception: number;
  rt: number;
}

export interface INodePositionData {
  privateIp: string;
  pid: number;
  processConfigurationId: string;
  parentIp: string;
  vpcId: string;
  resource: string;
  successQps: number;
}

export interface IFlowRuleListAllApp extends CommonReq {
  AppName: string;
  Resource: string;
  Grade: number;
  Model: number;
}

export interface IFlowRuleOffOmBatch extends CommonReq {
  Ids: string;
}

export interface IFlowRuleDelete extends CommonReq {
  Id: number;
}

export interface IFlowRuleNew extends CommonReq {
  AppName: string | null;
  Resource: string;
  LimitApp: string;
  Grade: number;
  Count: string;
  Strategy: number;
  RefResource: string;
  ControlBehavior: number;
  WarmUpPeriodSec: string;
  MaxQueueingTimeMs: string;
  ClusterMode: boolean;
  ClusterThresholdType: number;
  FallbackToLocalWhenFail: boolean;
  SampleCount: number;
  WindowIntervalMs: number;
  Enable: boolean;
  EstimatedMaxClusterQps: string;
  ClusterFallbackThreshold: string;
  id?: number;
  Model?: number;
  AutoConfig?: boolean;
  AutoConfigFallback?: number;
}

export interface IFlowRuleListByPage extends IFlowRuleListAllApp {
  PageIndex: number;
  PageSize: number;
  SearchKey: string;
}

export interface IFlowRuleData extends CommonReq {
  appName: string;
  clusterFallbackThreshold: number;
  clusterMode: boolean;
  clusterThresholdType: number;
  controlBehavior: number;
  controlBehaviorShow?: string;
  count: number;
  enable: boolean;
  estimatedMaxClusterQps: number;
  fallbackToLocalWhenFail: boolean;
  grade: number;
  gradeShow?: string;
  id: number;
  limitApp: string;
  namespace: string;
  refResource: string;
  resource: string;
  sampleCount: number;
  strategy: number;
  strategyShow?: string;
  userId: string;
  warmUpPeriodSec: number;
  windowIntervalMs: number;
  maxQueueingTimeMs: string;
  WindowIntervalMs: number;
  clusterRequestMode: number;
  clusterType: string;
  model: number;
  autoAdjustFallbackThresholdEnabled: boolean;
  fallbackThresholdAdjustMargin: number;
}

export interface IFlowId {
  id: string;
}

export interface IAutoId {
  Id: string;
}

export interface IFlowFilterParams {
  [key: string]: IFlowFilterParamsItem;
}

export interface Lengthwise {
  length: number;
  [key: string]: any;
}

export interface IFlowFilterParamsItem {
  visible: boolean;
  selectedKeys: Array<string>;
}

export interface IFlowRules {
  resource: string;
  limitApp: string;
  strategyShow: string;
  gradeShow: string;
  count?: string;
  controlBehaviorShow: string;
  id: number;
  key: number;
  [index: string]: any;
}

export interface IDegradeRuleListAll extends CommonReq {
  AppName: string | null;
  Resource: string;
  Model?: number;
}

export interface IDegradeRuleListByPage extends IDegradeRuleListAll {
  PageIndex: number;
  PageSize: number;
  SearchKey: string;
}

export interface IDegradeRuleDelete extends CommonReq {
  Id: number;
}

export interface IDegradeRuleOffOnBatch extends CommonReq {
  Ids: string;
}

export interface IAutoRetryRuleOffOnBatch extends CommonReq {
  Id: string;
}

export interface IDegradeRuleNew extends CommonReq {
  AppName: string | null;
  Resource?: string;
  Grade: number;
  Count: string;
  TimeWindow: number;
  SlowRatioThreshold: number;
  StatIntervalMs: number;
  MinRequestAmount: number;
  Enable: boolean;
  id?: number;
}

export interface IClusterClientQuery extends CommonReq {
  AppName: string | null;
}

export interface IClusterClientUpdate extends CommonReq {
  RequestTimeout: number;
}

export interface IDegradeRuleRecord {
  appName: string;
  count: number;
  enable: boolean;
  grade: number;
  gradeShow: string;
  id: number;
  limitApp: string;
  namespace: string;
  resource: string;
  timeWindow: number;
  userId: string;
  statIntervalMs: number;
  minRequestAmount: number;
  slowRatioThreshold: number;
  halfOpenRecoveryStepNum: number;
  halfOpenBaseAmountPerStep: number;
}

export interface IAutoRetryRuleRecord {
  appName: string;
  id: number;
  resource: string;
  retryStrategy: number;
  retryStrategyShow?: string;
  retryBaseIntervalMs: number;
  maxRetryTimes: number;
  retryPredicateStrategy: number;
  retryPredicateStrategyShow?: string;
  exceptionPredicates: string;
  exceptionPredicatesShow: string;
  errorRatioUpperBound: string;
  enable: boolean;
  [index: string]: any;
}

export interface IAutoRetryRuleRecordAdd extends CommonReq {
  AppName: string;
  Resource: string;
  RetryStrategy: number;
  RetryBaseIntervalMs: number;
  MaxRetryTimes: number;
  RetryPredicateStrategy: number;
  ExceptionPredicates: any;
  ErrorRatioUpperBound: any;
  Enable: boolean;
  Id?: string;
}

export interface IDegradeRuleDowngradeList {
  resource: string;
  gradeShow: string;
  count: string;
  timeWindow: string;
  statIntervalMs: string;
}

export interface ISystemRuleListAll extends CommonReq {
  AppName: string | null;
  Resource: string;
}

export interface ISystemRuleNew extends CommonReq {
  AppName: string | null;
  Grade: number;
  Count: string;
  Enable: boolean;
  id?: number;
}

export interface ISystemRuleRecord {
  count: number;
  enable: boolean;
  grade: number;
  gradeShow: string;
  id: number;
}

export interface ISystemRulesyStemList {
  grade: number;
  gradeShow: string;
  id: number;
  count: string;
  [index: string]: any;
}

export interface ISystemRulesId {
  id?: string;
}

export interface IHotparamRule extends CommonReq {
  AppName: string;
  Tags: '';
  Model: number;
}

export interface IParamRuleListByPage extends IHotparamRule {
  PageIndex: number;
  PageSize: number;
  SearchKey: string;
  Resource?: string;
}

export interface IHotParamRuleDelete extends CommonReq {
  Id: number;
}

export interface IHotParamRuleOffOnBatch extends CommonReq {
  Ids: string;
}

export interface IHotParamRule extends CommonReq {
  AppName: string | null;
  Resource: string;
  Grade: number;
  ParamIdx: string;
  Count: string;
  DurationInSec: number;
  ControlBehavior: number;
  BurstCount: number;
  MaxQueueingTimeMs: number;
  Enable: boolean;
  Tags: string;
  id?: string;
}

export interface IHotParamRuleRecord {
  appName: string;
  burstCount: number;
  clusterMode: boolean;
  resource: string;
  paramIdx: string;
  controlBehavior: number;
  count: number;
  durationInSec: number;
  enable: boolean;
  grade: number;
  gradeShow: string;
  id: number;
  limitApp: number;
  maxQueueingTimeMs: number;
  namespace: number;
  classType?: string;
  object?: string;
  paramFlowItemList: IExceptionChange[];
}

export interface IHotParamRuleHots {
  resource: string;
  grade: number;
  gradeShow: string;
  id: number;
  paramIdx: string;
  limitApp: string;
  durationInSec: string;
  count: string;
  controlBehavior: number;
  [key: string]: any;
}

export interface IOperationLogListOpLogs extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: 10;
}

export interface IOperationLogRenderContent {
  opType: string;
  newValue: string;
  [key: string]: any;
}

export interface IRulelAppEvents extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: number;
  resource: string;
  QueryLevel: number;
  eventType?: any;
  ResourceTypeSet?: any;
}

export interface IAppMachineListByPage extends CommonReq {
  AppName: string | null;
  PageIndex: number;
  PageSize: number;
}

export interface IControlBehavior {
  grade: number;
  id: number;
  controlBehavior: number;
  paramFlowItemList?: IExceptionChange[];
}

export interface IExceptionChange {
  classType?: string;
  count?: string;
  object?: string;
}

export interface IHotParamItems extends CommonReq {
  AppName: string;
  RuleId: number | string;
  Items: string;
}

export interface IDowngrade {
  appName: string;
  count: number;
  enable: boolean;
  grade: number;
  gradeShow?: string;
  id: number;
  limitApp: string;
  minRequestAmount: number;
  namespace: string;
  resource: string;
  statIntervalMs: number;
  timeWindow: number;
  userId: string;
  [index: string]: any;
}

export interface IEnentCenter {
  app: string;
  eventLevel: number;
  eventType: number;
  gmtCreate: number;
  gmtModified: number;
  namespace: string;
  resource: string;
  userId: string;
}

export interface IClientVersionOfApp extends CommonReq {
  AppName: string | null;
}

export interface IStrategyFilters {
  label?: string;
  value?: string;
}

export interface IGetClusterList extends CommonReq {
  App: string;
}

export interface IGetClusterDetail extends CommonReq {
  AppName: string;
}

export interface ISentinelProtectionModuleListAllByPage extends CommonReq {
  AppName: string;
  PageIndex: number;
  PageSize: number;
  RuleType: number;
}

export interface ISentinelProtectionModuleUpdate extends CommonReq {
  AppName: string;
  Id: number;
  FallbackId?: number;
}

export interface ISentinelGetResourceFallback extends CommonReq {
  AppName: string;
  Resource: string;
  BlockType: number;
}

export interface IUpdateCluster extends CommonReq {
  AppName: string;
  ClusterId: number;
  MaxClusterQps: number;
  TrialFlag: number;
}

export interface ICreateCluster extends CommonReq {
  AppName: string;
  ShareLevel: string;
  MaxClusterQps: number;
  Enable: boolean;
  TrialFlag: number;
}

export interface ISetClusterOnOrOff extends CommonReq {
  ClusterId: number;
}

export interface ISystemResourceMetricOfGroup extends CommonReq {
  AppName: string;
  Group?: string;
  StartTime?: number;
  EndTime: number;
  ProcessConfigurationId?: string;
  AppId?: string;
  PageNumber?: number;
  PageSize?: number;
  Region?: string;
  SysGroup?: any;
}

export interface ISpoint extends CommonReq {
  color: string;
  point: ISoriginQPS
  value: string;
  title: string;
  name: string;
}
export interface ISoriginQPS {
  color: string;
  _origin?: ISorigin | undefined;
}
export interface ISorigin {
  flowruletotal?: number | undefined;
  flowRuleId?: number | undefined;
  degradeRuleId?:number | undefined;
  degraderuletotal?:number | undefined;
  systemRuleId?:number | undefined;
  systemruletotal?:number | undefined;
  paramRuleId?:number | undefined;
  paramruletotal?:number | undefined;
  type: string;
  time: number;
  count: number;
}

export interface ISystemStatResourceMetricOfResource extends CommonReq {
  AppName: string;
  Group: string;
  resource: string;
}

export interface IStatusTopOfApplication extends CommonReq {
  AppName: string;
  Resource?: string;
  Node?: string;
  StartTime: number;
  EndTime: number;
}

export interface IClusterStatistics extends CommonReq {
  AppName: string;
  Resource?: string;
  Node?: string;
  Start: number;
  End: number;
}

export interface IClusterTypeStatistics extends CommonReq {
  AppName: string;
  Resource: string;
  Time: number;
}

export interface ISentinelAdaptiveFlowSettingOfApp extends CommonReq {
  AppName: string;
  Resource?: string;
  Node?: string;
  Time?: number;
}

export interface IUpdateSentinelAdaptiveFlowSettingOfApp extends CommonReq {
  AppName: string;
  EnableAutoSystemAdaptive: boolean;
}

export interface INotFineOfResource extends CommonReq {
  AppName: string;
  Resource?: string;
  StartTime: number;
  EndTime: number;
  ProcessConfigurationId?: string;
}

export interface IStatusOfTop extends CommonReq {
  Key: string;
  Time: number;
  Val: number;
  ProcessConfigurationId: string;
  Percent: number;
}

export interface IStatusNotFine extends CommonReq {
  ErrorNum: number;
  Is200: number;
  Like2xx: number;
  Like3xx: number;
  Like4xx: number;
  Like5xx: number;
  Time: number;
}

export interface IDescribeScenarioRecord extends CommonReq {
  recordId: number;
}

export interface IDescribeScenarioStatus extends CommonReq {
  scenarioId: number;
}

export interface IDataObject {
  balloonNum: number;
  num: number;
  content: string;
}

export interface ISaveScenarioSpringCloud extends CommonReq {
  scenarioName: string;
  preheatInMinutes: number;
  durationInMinutes: number;
  pressureMode: string;
  pressureValue: number;
  pressureModelConfig: string;
  regionId: string;
  scenarioType: string;
  appId?: string;
  appName: string;
  namespace: string;
  namespaceId?: string;
  isLogPrint: boolean;
  address: string;
  uri?: string;
  applicationName?: string;
  group?: string;
  dubboVersion?: string;
  serviceName?: string;
  methodName?: string;
  methodTypes?: string;
  params?: string;
  method?: string;
  headers?: string;
  body?: string;
  timeout: number;
  serviceType: string;
  vpcId: string;
  vSwitchId: string;
  securityGroupId: string;
  isAddressDirect: string;
  source: string;
  region: string;
}

export interface IScenario extends CommonReq {
  scenarioId: number;
}

export interface IDescribeScenarioRecordsForAhas extends CommonReq {
  Source: string;
  AppName: string;
  PageNumber: number;
  PageSize: number;
  ScenarioName: string;
}

export interface IDeleteScenarioRecord extends CommonReq {
  recordId: number;
}

export interface IQueryAlarmRules extends CommonReq {
  AppName: string;
  Group: string;
  AlertName: string;
  PageIndex: number;
  PageSize: number;
}

export interface IQueryAlarmRuleOperRecords extends CommonReq {
  AppName: string;
  StartTime: number;
  EndTime: number;
  PageIndex: number;
  PageSize: number;
  OperUser?: number;
  AlertName?: string;
}


export interface IQueryClusterResources extends CommonReq {
  AppName: string;
  PageIndex: number;
  PageSize: number;
}

export interface IUpdateAlarmStatus extends CommonReq {
  AppName: string;
  AlarmId: number;
  AlarmOn: boolean;
}

export interface IDeleteAlarmRule extends CommonReq {
  AppName: string;
  AlarmIds: number;
}

export interface IDataSourceOfAlarmSystem {
  AlarmName: string;
  AlarmApiName?: string;
  AlarmLevel: string;
  AlarmGroup: string;
  AndOr: string;
  AlarmOn: boolean;
  AlarmRuleId: number;
  AlarmRuleConditions: IAlarmRuleConditionDO[];
  RepeatInterval: string;
  SilencePeriod: string;
}

export interface IDataSourceOfQueryAlarmRecords {
  AlarmDetail: string;
  AlarmLevel: string;
  AlarmName: string;
  AlarmTime: string;
  AlarmType: string;
  Identify: boolean;
  OperUser: number;
}

export interface IDataSourceOfAlarmLog {
  AlarmName: string;
  AlarmLevel: string;
  OperType: string;
  OperUser: string;
  OperTime?: number;
  AlarmDetail?: string;
  AlarmType?: string;
  Identify?: string;
  AlarmTime?: string;
}

export interface IAddOrEditAlarmRule extends CommonReq {
  AppName: string;
  AlarmId?: number;
  AlertName: string;
  AlertLevel: string;
  AlertGroup: string;
  AndOr: string;
  AlarmOn: boolean;
  RepeatInterval: string;
  Conditions: string;
}

export interface IAlarmRuleConditionDO {
  AlarmType: string;
  Relationship: string;
  ConditionVal: string;
  Slo: number;
  GroupWait: number;
  GroupInterval: string;
  RuleId?: number;
}

export interface ISentinelWebParamFlowRuleListByPage extends CommonReq {
  AppName: string;
  PageIndex: number;
  PageSize: number;
  Model: number;
  Resource: string;
  SearchKey: string;
}

/** **************** 应用防护模块结束 **************** **/

/** **************** 网关防护模块开始 **************** **/

export interface IQuerySentinelAppMachineList extends CommonReq {
  AppName: string | null;
}

export interface ISentinelGatewayFlowRuleList {
  resource: string;
  apiCount: number;
  apiItems: IApiItems[];
  apiName: string;
  appName: string;
  id: number;
  namespace: string;
  userId: string;
}

export interface IApiItems {
  matchStrategy: number;
  pattern: string;
}

export interface ISentinelGateway extends CommonReq {
  AppName: string;
}
export interface IFlowRuleListAll {
  appName: string;
  burst: number;
  controlBehavior: number;
  count: 1;
  enable: boolean;
  grade: number;
  id: number;
  intervalSec: number;
  maxQueueingTimeoutMs: number;
  namespace: string;
  resource: string;
  resourceMode: 1;
  userId: string;
  paramItem?: any;
}

export interface IFlowRuleOnOff extends CommonReq {
  AppName: string;
  Id: number;
}

export interface IQueryAllAlarmRules extends CommonReq {
  AppName: string;
  Resource: string;
  PageIndex: number;
  PageSize: number;
}

export interface IGatewayFlowRuleNew extends CommonReq {
  AppName: string;
  Resource: string;
  ResourceMode: number;
  ParseStrategy: number;
  FieldName: string;
  MetricType: number;
  Threshold: number;
  IntervalSec: number;
  ControlBehavior: number;
  MaxQueueingTimeoutMs: number;
  Burst: number;
  HasParam: boolean;
  Enable: boolean;
  MatchStrategy: number | null;
  Pattern: number;
  id?: number;
  Model?: number;
}

export interface IGuardGwFlow {
  appName: string;
  burst: number;
  controlBehavior: number;
  count: number;
  enable: boolean;
  grade: number;
  id: number;
  intervalSec: number;
  maxQueueingTimeoutMs: number;
  namespace: string;
  resource: string;
  resourceMode: number;
  userId: string;
  paramItem?: any;
  parseStrategy?: any;
  matchStrategy?: any;
  fieldName?: any;
  pattern?: any;
}

export interface ISentinelGatewayApiAddSava extends CommonReq {
  AppName: string;
  ApiName: string;
  ApiItems: ISentinelGatewayApiApiItems[];
  id?: number;
}
export interface ISentinelGatewayApiApiItems {
  matchStrategy: number;
  pattern: string;
}

export interface ISystemGuardGwApiModalApiListAdd {
  ids?: number;
  matchStrategy?: number;
  pattern?: string;
}

export interface ISystemGuardGwApiModalProps {
  apiItems: ISentinelGatewayApiApiItems[];
  apiName: string;
  appName: string;
  id: number;
}

export interface ISystemGuardGwApiModalData {
  apiId: number;
  apiName: string;
  type?: number;
  value?: string;
  id: number;
}

/** **************** 网关防护模块结束 **************** **/

/** **************** 流量大盘模块开始 **************** **/
export interface IGetMonitorList extends CommonReq {
  PageIndex: number;
  PageSize: number;
}

export interface IDelMarketTag extends CommonReq {
  DashboardId: number;
}

export interface IAppNameListResult {
  appName: string;
  appType: number;
  id: number;
  lastHealthPingTime: number;
  namespace: string;
  userId: string;
}

export interface IGetApiListParams extends CommonReq {
  AppName: string;
  PageIndex: number;
  PageSize: number;
  OrderBy: number;
  Desc: boolean;
  AhasTimestamp: number;
  ResourceType: number;
  TrafficType?: string;
}

export interface IGetApiListResult {
  blockedQps: number;
  exception: number;
  favorite: boolean;
  hasRule: boolean;
  passedQps: number;
  resource: string;
  rt: number;
  type: number;
  dashboardId: number;
  id: number;
  namespace: string;
  refMetric: string;
  refMetricNickName: string;
  userId: string;
  appName: string;
}

export interface IAddMarketNameParams extends CommonReq {
  DashboardName: string;
}

export interface IAddMarketTagsUpdateParams extends CommonReq {
  DashboardId: number;
  PageIndex: number;
  PageSize: number;
}

export interface IAddMarketTagsDelParams extends CommonReq {
  DashboardItemIds: string;
}

export interface ISelectObj {
  label: string;
  value?: string;
  id?: number;
  appName: string;
  refMetric?: string;
}

export interface IAddMarketParams {
  appName: string;
  refMetric: string;
}

/** **************** 流量大盘模块结束 **************** **/

/** **************** Mesh流控模块开始 **************** **/

export interface IDeleteSentinelMeshFlowGroup extends CommonReq {
  id: number;
}

export interface IMeshFlowGroupDetail extends CommonReq {
  GroupId: number;
}

export interface IMeshAge {
  title: string;
  type: string;
}

export interface IMeshItemData {
  EnvoyRlsDomain: string;
  Id: number;
  MaxEstimatedQps: number;
  MeshType: number;
  Name: string;
  Namespace: string;
  ServerId: string;
  UserId: string;
}

export interface IMeshAccessItemData extends IMeshItemData {
  License: string;
  ServerIp: string;
  ServerPort: number;
}

export interface ICreateSentinelMeshFlowGroup extends CommonReq {
  Name: string;
  EnvoyRlsDomain: string;
  MaxEstimatedQps: number;
  id?: number;
}

export interface IListSentinelMeshEnvoyRlsRulesOfGroup extends CommonReq {
  GroupId: number;
}

export interface IDisableOrEnableSentinelMeshEnvoyRlsRule extends CommonReq {
  Id: number;
}

export interface IResourceDescriptors {
  Key: string;
  Value: string;
}

export interface ICreateSentinelMeshEnvoyRlsRule extends IListSentinelMeshEnvoyRlsRulesOfGroup {
  Name: string;
  ResourceDescriptors: string;
  Threshold: number;
  StatInterval: number;
  TimeUnit: number;
  Enabled: boolean;
  Id?: number;
}
/** **************** Mesh流控模块结束 **************** **/

/** **************** JVM监控模块开始 **************** **/
export interface IJVMMetricOfGroup {
  Resource: string;
  Time: number;
  Val: number;
}

export interface IJVMCurMeticsData {
  type: string;
  time: number;
  count: number;
  val: string;
}

export interface IJVMDataSource {
  type: string;
  time: number;
  count: number;
}

export interface IExceptionDataSource {
  time: number;
  count: number;
}

/** **************** JVM监控模块结束 **************** **/

/** **************** Ngin防护模块开始 **************** **/
export interface IHttpApiMatchQueryForApp extends CommonReq {
  AppName: string;
}

export interface ISentinelHttpApiMatchNew extends CommonReq {
  AppName: string;
  HttpApiMatch: string;
}

export interface ISentinelHttpApiMatchUpdate extends ISentinelHttpApiMatchNew {
  Id: number;
}
export interface IHttpApiMatchUpdateDefault extends CommonReq {
  AppName: string;
  Strategy: string;
}
export interface IHttpApiMatchList {
  apiName: string;
  enable: boolean;
  gmtCreate: number;
  gmtModified: number;
  hostMatch: {
    pattern: string;
    type: string;
  };
  id: number;
  pathMatch: {
    pattern: string;
    type: string;
    useClientRequestPath: boolean;
  };
  resourceNameGenerator: {
    strategy: string;
  }
}

/** **************** Ngin防护模块结束 **************** **/
