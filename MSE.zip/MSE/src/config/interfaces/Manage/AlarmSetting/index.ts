import { CommonReq } from '../../index';

export interface IGetContactsParams extends CommonReq {
  PageSize: number;
  PageIndex: number;
}

export interface IGetContactsResult {
  datas: IContactsResultDatas[];
  pageIndex: number;
  pageSize: number;
  totalCount: number;
  totalPage: number;
}

export interface IContactsResultDatas {
  acceptSystemMessage: boolean;
  dingWebhook: string;
  email: string;
  id: number;
  name: string;
  secret: string;
  userId: string;
}


export interface IDeleteContactParams extends CommonReq {
  ContactId: number;
}


export interface IAddOrUpdateContactParams extends CommonReq {
  Contact: string;
}
