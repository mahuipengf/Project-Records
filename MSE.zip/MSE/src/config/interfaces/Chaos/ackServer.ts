import { CommonReq } from 'config/interfaces';


export interface IAckClusterRes {
  items: IAckCluster[],
  pageNo: number;
  pageSize: number;
  total: number;
}
export interface IAckCluster {
  name: string;
  clusterId: string;
  regionId: string;
  vpcId: string;
}

export interface IRuleStatus {
  rule: string,
  status: string;
}

export interface IAckRulesRes {
  status: string;
  items: IAckRulesResItems[];
}

export interface IAckRulesResItems {
  groupName: string;
  ruleList: IAckRules[],
}

export interface IAckRules {
  enable: boolean;
  group: string;
  name: string;
  displayName: string;
  status: string;
  lastExpTime?: number;
  lastInvokeTime?: number;
  latency?: number;
}

export interface IAutoConfig {
  DailyInvokeTime: string;
  Notify: boolean;
  DingdingUrl: string;
  RuleList: string[];
  Enable: boolean;
}

export interface IAckClusterRules extends CommonReq{
  ClusterId: string;
  VpcId: string;
  [key: string]: any;
}

export interface IBatchAlert extends IAckClusterRules {
  AlertRuleList: string[];
  [key: string]: any;
}

export interface IAddAckRule extends IAckClusterRules {
  newConfig: IAutoConfig
  [key: string]: any;
}

