import { CommonReq } from '..';

export interface IDisasterZoneData {
  availabilityZoneName: string;
  availabilityZoneId: string;
  resourceDetails: IResourceDetails;
  isSelected?: boolean;
}

export interface IResourceDetails {
  slb?: IInstance[];
  ecs?: IInstance[];
  rds?: IInstance[];
  redis?: IInstance[];
}

export interface IInstance {
  instanceId: string;
  instanceName: string;
  status: number;
}

export interface IArchiveDisasterProject extends CommonReq {
  ProjectId: string;
}

export interface ICreateDisasterProject extends CommonReq {
  availabilityZones: string;
  projectName: string;
  description: string;
  tags: string[];
  mode: number;
  autoRecoveryTime: number;
  scope?: any[];
  arch?: any[];
  experimentTaskId?: string | null;
}

export interface ISaveDisasterEvaluationInfo extends CommonReq {
  archEvaluation: string[];
  monitoringEvaluation: string[];
}

export interface IDeleteDisasterExpectIndicator extends CommonReq {
  indicatorId: string | number;
}

export interface IListDisasterIndicatorInfo extends CommonReq {
  projectId: string;
}

export interface IDisasterIndicatorItemInfo {
  actualDuration?: number;
  actualRange?: number;
  conclusion?: number;
  disasterItem: string;
  expectDuration: number;
  expectRange: number;
  indicator: string;
  indicatorId?: string | number;
  projectId?: string;
  mock?: boolean;
}

export interface ICreateDisasterExpectIndicator extends CommonReq {
  disasterItem: string;
  indicator: string;
  expectRange: number;
  expectDuration: number;
  projectId: string;
}

export interface ISetDisasterAuthorization extends CommonReq {
  confirmEffect: string;
  confirmAuthorization: string;
  projectId: string;
}

export interface ISceneDisasterProjectInfo {
  archiveTime: string;
  autoRecoveryTime: number;
  createTime: string;
  description: string;
  disasterAvailabilityZones: string[];
  disasterScope: string[];
  mode: number;
  projectId: string;
  projectName: string;
  projectStage: number;
  projectStatus: number;
  tags: string[];
}

export interface IGetListDisasterExperimentProblem extends CommonReq {
  projectId: string,
  pageNo: number,
  pageSize: number;
}

export interface IDisasterExperimentProblemItem extends CommonReq {
  problemId?: string,
  description: string,
  degree: number,
  status: number,
  createTime?: string;
  principal?: string;
  projectId?: string;
}

export interface IUpdateDisasterExperimentProblem extends CommonReq {
  problemId?: string,
  description: string,
  degree: number,
  status: number,
  projectId: string;
}

export interface IQueryResourceDeploymentArch extends CommonReq {

}
export interface IQueryDisasterResourceDetails extends CommonReq {
  AvailabilityZoneId: string;
  Mode: string;
}

export interface IUpdateDisasterProject extends CommonReq {
  projectName: string;
  description: string;
  tags: string[];
  projectId: string;
}

export interface IDisasterResourceItemDetail {
  name: string;
  items: IDisasterResourceItemDetailCheckd[];
  checkds: IDisasterResourceItemDetailCheckd[];
  visible?: boolean;
  mode?: string;
  historyItems: IDisasterResourceItemDetailCheckd[];
}

export interface IDisasterResourceItemDetailCheckd {
  value: string;
  label: string;
  url: string;
  disabled: boolean;
  disabledInfo: string;
  configurationId: string;
  instanceIp: string;
  appName: string;
}

export interface IDisasterScope {
  desc: string;
  itemName: string;
  productType: string;
  resources: string[];
}

export interface ISceneDisasterProjectInfo {
  archiveTime: string;
  autoRecoveryTime: number;
  createTime: string;
  disasterAvailabilityZones: string[];
  disasterScope: string[];
  experimentTaskId: string;
  mode: number;
  projectId: string;
  projectName: string;
  projectStage: number;
  projectStatus: number;
  tags: string[];
}

export interface IQueryResourceDeploymentArchById extends CommonReq {
  projectId: string;
  recordId?: string;
}

export interface IUpdateDisasterIndicatorInfo extends CommonReq {
  actualDuration?: number;
  actualRange?: number;
  conclusion?: number;
  disasterItem: string;
  expectDuration: number;
  expectRange: number;
  indicator: string;
  indicatorId?: string | number;
  projectId?: string;
}

export interface IQueryDisasterAuthorization extends CommonReq {
  projectId: string;
}

export interface IDeleteDisasterExperimentProblem extends CommonReq {
  problemId: string;
}

export interface IQueryDisasterTaskAndEditorTask extends CommonReq {
  projectId: string;
  experimentTaskId?: string | null;
  activityTaskId?: string;
}

export interface IQueryDisasterMonitoringMetrics extends CommonReq {
  instanceIds: string;
  instanceType: string;
  group: boolean;
}
