import { CommonReq } from 'config/interfaces';

export interface IGetMqExperiments extends CommonReq {
  pageNo: number;
  pageSize: number;
  field: string;
  value: string | string[];
}

export interface IMqExperimentItem {
  archId: string;
  archName: string;
  creator: string;
  deployType: number;
  gmtCreate: number;
  gmtModified: number;
  name: string;
  scenarioId: string;
  status: number;
  timeRemain: string;
}

export interface IGetListArchByGroup extends CommonReq {
  group: string;
}

export interface ICreateArchScenarioAndUpdate extends CommonReq {
  scenarioId?: string;
  archId: string;
  deployType: number;
  name: string;
  info?: string;
  tags?: string[];
  status?: number;
}

export interface IListFaultByArchItem {
  archId?: string;
  detailId: string;
  disabled?: boolean;
  expectEffect?: string;
  faultId: string;
  id?: string;
  module: string[];
  name: string;
  record_nodes?: INodesItem[];
  targets: INodesItem[];
  node?: INodesItem[];
  faultName?: string;
  status?: number;
  tags: string[];
  defaultStatus?: number | string;
  templates: any[];
  templateId?: string;
  checkd?: boolean;
  templateName?: string;
  select?: boolean;
}

export interface IArchGraphInfo {
  nodes: INodesItem[];
  combos: ICombosItem[];
  edges: IEdgesItem[];
}

export interface INodesItem {
  appName: string;
  configurationId: string;
  deviceConfigurationId: string;
  id: string;
  ip: string;
  module: string;
  label?: string;
  comboId?: string;
  groupName?: string;
  type?: string;
  x?: number;
  y?: number;
  style?: any;
}

export interface ICombosItem {
  display: boolean;
  module: string;
  id: string;
  label: string;
  rankdir: string;
  parentId: string;
}

export interface IEdgesItem {
  source: string;
  target: string;
  type: string;
}

export interface IGetArchGraphDetail extends CommonReq {
  archId?: string;
  deployType?: string;
  scenarioId?: string;
}

export interface IGetListPageArchScenarioDetail extends CommonReq {
  pageNo: number,
  pageSize: number,
  scenarioId: string,
  field: string,
  value: string | string[],
}

