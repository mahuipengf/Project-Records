import { CommonReq } from 'config/interfaces';

export interface IQAppNodes extends CommonReq {
  AppName?: string; // 应用名称，全局视图(所有应用)下，传入 *， 非必填
  AppDimension: number; // 应用维度，int 类型，必填；一起固定传入2,表示Pod下的应用视图，未来可能支持主机、进程下的应用
  ClusterId?: string; // 集群ID，非必填；如果appDimension
  ClusterNamespace?: string; // 集群命名空间，非必填；
}

export interface IQAppLs extends CommonReq, IQPage {
  key: string;
  appDimension?: number;
}

export interface IQPage {
  page: number;
  size: number;
}

export interface IQAppExpLs extends CommonReq, IQPage {
  app_name: string;
}
export interface IQDeviceExpHistory extends CommonReq, IQPage {
  configurationId: string;
}

export interface IQEdgeExpHistory extends CommonReq, IQPage {
  sourceAppName: string;
  targetAppName: string;
}

export interface IQSceneByCategory extends CommonReq, IQPage {
  quickSceneType: number|string;
  appName: string;
}

export interface IQDeviceExpLs extends CommonReq, IQPage {
  ConfigurationId: string;
  quickSceneType: number;
  visionNodeType: string;
  nodeIds: string[];
  hosts: any;
}

export interface IQAppDetailGraph extends CommonReq {
  AppName: string; // 应用名称，全局视图(所有应用)下，传入 *， 非必填
  AppDimension: number; // 应用维度，int 类型，必填；一起固定传入2,表示Pod下的应用视图，未来可能支持主机、进程下的应用
}
export interface IQAppDetailFilter {
  name?: string;
  private_ip?: string;
  in_experiment?: boolean;
  groups?: string[];
  kub_namespace?: string[];
}
export interface IQAppDeviceNodes extends CommonReq, IQAppDetailFilter {
  app_name: string; // 应用名称
  filter: IQAppDetailFilter; // 设备节点过滤条件
}
export interface IQNodeToolTip extends CommonReq {
  sourceAppName: string; // 应用
  configurationId: string;
}

export interface IQAppNodeDetail extends CommonReq {
  AppName: string; // 应用名称，必填，字符类型
  AppDimension: number; // 应用维度，int 类型，必填；一起固定传入2,表示Pod下的应用视图，未来可能支持主机、进程下的应用
  ConfigurationId: string; // 节点ID
  HostConfigurationId: string; // 节点主机ID，从拓扑图中获取
}

/** 快速演练场景的种类 */
export interface Category {
  quickSceneType: number;
  description: string;
}

/** 及其详情 执行记录 */
export interface ExpTaskHistory {
  name: string;
  progress: number;
  end_time: number;
  start_time: number;
  task_id: string;
  task_result: string;
  task_state: string;
}

/** 及其详情 执行记录 */
export interface DeviceNode {
  cluster_name: string;
  configuration_id: string;
  experiment_status: boolean;
  group: string;
  host_configuration_id: string;
  kub_namespace: string;
  name: string;
  private_ip: string;
}
