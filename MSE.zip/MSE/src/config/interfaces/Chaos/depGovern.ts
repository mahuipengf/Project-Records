import { CommonReq } from '..';

export interface IDepSensitivityProjectItem {
  stage: number;
  createTime: string;
  appName: string;
  depSnapshot: any;
  description: string;
  projectName: string;
  projectId: string;
  tags: string[];
  status: number;
  userId: number;
  subUserId: number;
}

export interface IApplication {
  appName: string;
  appId: number;
  appType: number;
  scopeType: number;
  stage: string;
}

export interface IApplicationGroup {
  groupName: string;
}
export interface IAgentStatus {
  pass: boolean;
  failCount: number;
  totalCount: number;
}

export interface IDependency {
  ProjectId: string;
  DepTree: IDepTree[];
}

export interface IDepC {
  name: string;
  expectStrong: string;
  resources: any;
  depName: string;
  rowIndex?: number;
  childrenLength?: number;
}

export interface IDep {
  name: string;
  expectStrong: boolean;
  resources: any;
}

export interface IDepTree {
  name: string;
  checked: boolean;
  children: IDep[];
  collapsed?: boolean;
  id: string;
}

export interface IHistoryDependency {
  time: number;
  tree: IDepTree[];
}

export interface IGetTagByPrefix extends CommonReq {
  TagPrefix?: string;
  kind: number;
}

export interface IListSceneProject extends CommonReq {
  PageNo: number;
  PageSize: number;
  AppName?: string;
  Tags?: string[];
  Status?: number;
}

export interface ICreateSceneProject extends CommonReq {
  AppName: string;
  ProjectName: string;
  Description?: string;
  Tags?: string[];
}

export interface IUpdateSceneProject extends CommonReq {
  ProjectId: string;
  AppName?: string;
  ProjectName: string;
  Description?: string;
  Tags?: string[] | string | undefined;
}

export interface IGetSceneProjectById extends CommonReq {
  ProjectId: string;
}

export interface ICheckApplicationAgentStatus extends CommonReq {
  AppName: string;
}

export interface IListApplicationGroup extends CommonReq {
  AppName: string;
}

export interface ICheckSceneProjectAgentStatus extends CommonReq {
  ProjectId: string;
}

export interface IUpdateGovernTarget extends CommonReq {
  ProjectId: string;
  DepTree: IDepTree[];
}

export interface IConfirmGovernTarget extends CommonReq {
  ProjectId: string;
  DepTree: IDepTree[];
}

export interface IGetDepByProjectId extends CommonReq {
  ProjectId: string;
}

export interface IGetDepSnapshotByProjectId extends CommonReq {
  ProjectId: string;
}
export interface IGetSelectedDepByProjectId extends CommonReq {
  ProjectId: string;
}

export interface IGetListDepConfirmedByProjectId extends CommonReq {
  ProjectId: string;
  PageNo: number;
  PageSize: number;
  TargetName?: string;
  DepName?: string;
  Status?: number;
}

export interface IListDepConfirmedByProjectIdReq {
  targetName: string;
  expectStrong: boolean;
  projectId: string;
  depName: string;
  experimentName: string;
  tags: string[];
  status: number;
  experimentId: string;
  experimentTaskId: string;
  recordId: string;
}

export interface IUpdateRecordDepAndCreateExperiment extends CommonReq {
  ProjectId: string;
  TargetName?: string;
  DepName?: string;
  ExpectStrong?: boolean;
  ActualStrong?: boolean;
  RecordId?: string;
  ParamChange?: boolean;
  TargetParam?: ICreateExperimentTargetParam;
  Targets?: ICreateExperimentTarget[];
}

export interface ICreateExperimentTargetParam {
  appGroupName: string;
  appName: string;
  checkIps: boolean;
  ips: string[];
  nodeType: string;
  ports: string[];
}

export interface ICreateExperimentTarget {
  clusterNamespace: string;
  configurationId: string;
  deviceConfigurationId: string;
  instanceName: string;
  ip: string;
}

export interface IGetSceneProjectByIdReq {
  appName: string;
  createTime: string;
  projectId: string;
  projectName: string;
  description?: string;
  tags?: string[];
  stage: number;
  status: number;
  archiveTime?: string;
}

export interface IExperimentParam {
  dependencyEffective: boolean;
  targetName: string;
  depName: string;
  expectStrong: boolean;
  paramChange: boolean;
  config: any;
  targetParam: {
    appGroupName: string;
    appName: string;
    checkIps: boolean;
    ips: string[];
    nodeType: string;
    ports: string[];
    targetAppId: number;
  };
  targets: ICreateExperimentTarget[];
}

export interface ICreateExperiment {
  ProjectId: string;
  TargetName: string;
  DepName: string;
}

export interface IArchiveProject extends CommonReq {
  ProjectId: string;
}

export interface IGetListApplication extends CommonReq {
  PageSize: number;
  PageNo: number;
  AppPrefix: string;
}

export interface IAppName extends CommonReq {
  app_name: string;
}
export interface IMseCluster extends CommonReq {
  clusterId: string;
}
export interface IMseOpenNameSpace extends CommonReq {
  params: any;
  opend: boolean;
}
