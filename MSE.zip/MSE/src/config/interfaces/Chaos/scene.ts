import { CommonReq } from 'config/interfaces';


// 小程序列表
export interface ISceneFunctionRecord extends CommonReq {
  agentRequired: boolean;
  code: string;
  enabled: number;
  functionId: string;
  gmtCreate: number;
  name: string;
  parentFunctionId: string;
  parentName: string;
  phaseFlag: number;
  sceneId: string;
  source: number;
  version: string;
}

export interface IQueryUserSceneFunctionReq extends CommonReq {
  key?: string;
  phase?: number;
  enabled?: number;
  source?: number;
  page?: number;
}

// 创建小程序
export interface ICreateSceneFunction extends CommonReq {
  sceneId: string;
  code: string;
  phaseFlag: number;
  name: string;
  description?: string;
}

export interface IQueryScenePageable extends CommonReq {
  page: number;
}

// 小程序详情
export interface ISceneInfo {
  name: string;
  code: string;
  usedCount?: number;
  description: string;
  source: number;
  parentName: string;
  version: string;
  enabled: number;
  supportScopeTypes: number[];
  phaseFlag: number;
  script: any; // 未找到有这条数据的小程序，暂时为any
  categoryIds: string[];
  functionId: string;
  isPublic: number;
  parameters: ISceneInfoParameterItem[];
  authorizedRecords: any[];
}

export interface ISetSceneInfoParams extends ISceneInfo {
  agentRequired: boolean;
  // authorizedRecords?: any;
  flag?: any;
  gmtCreate: number;
  parentFunctionId: string;
  sceneId: string;
  RegionId?: string;
  AhasRegionId?: string;
  Lang?: string;
  NameSpace?: string;
  Namespace?: string;
}

export interface ISceneInfoParameterItem extends CommonReq {
  alias: string;
  component: IParameterItemComponent;
  functionId: string;
  name: string;
  parameterId: string;
  sequence: number;
  description?: string;
}

export interface IParameterItemComponent {
  opLevel?: number;
  unit?: string;
  cipherText?: string;
  defaultValue: string;
  requestUrl: string | null;
  constraint?: {
    checkerTemplate: string;
    checker: string;
  }
  required: boolean;
  type: string;
  options: any;
  linkage?: {
    defaultState: boolean;
    depends: null | string;
    condition: null | string;
  }
}

export interface ICatetorItem {
  categoryId: string;
  children: ICatetorItem[];
  level: number;
  name: string;
  phase: number;
  supportScopeTypes: number[];
  type: number;
  parentId: string;
}

// 添加子程序
export interface ICreateFissionSceneReq extends CommonReq {
  name: string;
  functionId: string | null;
  description: string;
  code: string;
}

export interface IGetSceneDetailFunctionId extends CommonReq {
  functionId: string;
}

export interface IUpdateScriptReq extends IGetSceneDetailFunctionId {
  language: string;
  scriptContent: string;
  scriptId?: string;
  compile?:true;
}

export interface IDeletePatameterReq extends IGetSceneDetailFunctionId {
  parameterId: string;
}

export interface IQuerySceneFunctionChangeLog extends IGetSceneDetailFunctionId {
  page: number;
}

export interface IExportSceneFunctionConfigReq extends IGetSceneDetailFunctionId {
  regions: string[];
}

export interface ISwitchFunctionAuthorizedStateReq extends IGetSceneDetailFunctionId {
  isPublic: number;
}

export interface IUpdateSceneFunctionAuthorizedReq extends IGetSceneDetailFunctionId {
  userId: string;
  permissions: string;
}

// 类目操作
export interface ICategoryEditorParams extends CommonReq {
  name?: string;
  parentId?: string;
  phase?: number;
  type?: number;
  supportScopeTypes?: number[];
  categoryId?: string;
}


// 演练场景interface
export interface ICategories {
  categoryId: string;
  children: ICategories[];
  level: number;
  name: string;
  parentId: string;
  phase: number;
  supportScopeTypes: number[];
  type: number;
}

export interface ISelectData {
  agentRequired: boolean;
  categoryIds: string[];
  code: string;
  description: string;
  enabled: number;
  functionId: string;
  gmtCreate: number;
  name: string;
  nextDepAppCode: string;
}

