export interface ILoginUserState {
  userId: any;
  grayEnable: boolean;
  betaFlag: number;
  isAdmin: boolean;
  isAliAccount: boolean;
  isSubUser: boolean;
  isStsUser: boolean;
}
