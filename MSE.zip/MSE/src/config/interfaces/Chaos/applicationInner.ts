import { CommonReq } from 'config/interfaces';

export interface IGetApplication extends CommonReq {
  accountId?: string;
  applicationName?: string;
  size: number;
  page: number;
}

export interface IApplicationList {
  data: IList[];
  hasMore: boolean;
  page: number;
  pageSize: number;
  pages: number;
  total: number;
}

export interface IList {
  accountId: string;
  applicationId: number;
  applicationName: string;
  forbidden: false;
  relationId: string;
}

export interface IGetAppName extends CommonReq {
  key?: string;
}

export interface TGetAppBack {
  label: string;
  value: string;
}

export interface IChangeForbidden extends CommonReq {
  relationId: string;
  forbidden: boolean;
}

export interface IDeleteApplication extends CommonReq {
  relationId: string;
}

export interface IAddApplicationAccount extends CommonReq {
  accountId: string;
  applicationId: string[];
}
