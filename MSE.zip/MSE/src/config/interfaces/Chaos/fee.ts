import { CommonReq } from 'config/interfaces';

export interface IQueryExpenseAndOrder extends CommonReq {
  page: number;
  size: number;
}

export interface IExpenseRecord {
  amount: number;
  arrears: boolean;
  createTime: number | string;
  expenseRecordId: string;
  experimentId: string;
  experimentName: string;
  experimentTaskId: string;
}

export interface IOrderRecord {
  orderId: string;
  consumable: boolean | string;
  endTime: number | string;
  expired: boolean;
  packName: string;
  packType: string;
  price: string | number;
  quantity: number;
  remainingAmount: number;
  spec: number | string;
  startTime: number | string;
  experimentTaskId: string;
}

export interface IUserPayPackPermission extends CommonReq{
  code: string;
}

export interface IPayPackPermission {
  payPackList: IPayPack[],
  permission: boolean;
  userId: string;
  userName?: string;
  limitCount?: number;
  type?: string;
}

export interface IPayPack {
  code: string,
  name: string,
}
