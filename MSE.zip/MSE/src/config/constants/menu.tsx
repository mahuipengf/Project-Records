import React from 'react';
import { Badge } from '@alicloud/console-components';
import { MSHA_URL } from 'config/constants/home';
import { getCurrentRegion } from 'utils/index';
import { getAppName, getVirtualMerchant } from 'utils/util_ahas';
import intl from '@ali/wind-intl';

const getActiveNamespace = () => 'default';
const getParams = window.getParams;
// 默认主导航
const menuConfig = [
  {
    key: '/index',
    label: '概览',
    to: `/index?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
  },
  // {
  //   key: '/ahas/arch',
  //   label: '架构感知',
  //   items: [
  //     {
  //       key: '/arch/archMap',
  //       label: '架构地图',
  //       to: `/arch/archMap?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
  //     },
  //     {
  //       key: '/arch/archCheck',
  //       label: '架构巡检',
  //       to: `/arch/archCheck?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
  //     },
  //     {
  //       key: '/arch/archSetting',
  //       label: '巡检设置',
  //       to: `/arch/archSetting?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
  //     },
  //   ],
  // },
  {
    key: '/ahas/flow',
    label: '流量防护',
    items: [
      {
        key: '/flowProtection/systemGuard',
        label: '应用防护',
        to: `/flowProtection/systemGuard?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/flowProtection/systemGuardGw',
        label: '网关防护',
        to: `/flowProtection/systemGuardGw?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/flowProtection/systemGuardNginx',
        label: 'Ingress/Nginx 防护',
        to: `/flowProtection/systemGuardNginx?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/flowProtection/monitorDashboard',
        label: '流量大盘',
        to: `/flowProtection/monitorDashboard?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      // {
      //   key: '/ahas/flow/protection',
      //   label: '集群流控',
      //   href: 'https://ahas.console.aliyun.com/#/SystemGuardClusterProtection',
      // },
      {
        key: '/flowProtection/meshProtection',
        label: 'Mesh 防护',
        to: `/flowProtection/meshProtection?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/manage/alarm',
        label: '告警管理',
        to: `/manage/alarm?ns=${getActiveNamespace()}&region=${getCurrentRegion()}&iis=${getParams('iis')}`,
      },
    ],
  },
  {
    key: '/ahas/log',
    label: '日志治理',
    items: [
      {
        key: '/ahas/log/whiteScreenDiagnosisRule',
        label: '规则列表',
        to: `/logGovernance/whiteScreenDiagnosisRule?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/ahas/log/whiteScreenDiagnosis',
        label: '规则大盘',
        to: `/logGovernance/whiteScreenDiagnosis?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/ahas/log/accessLogMarket',
        label: '流量日志大盘',
        to: `/logGovernance/accessLogMarket?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/ahas/log/logSet',
        label: '设置',
        to: `/logGovernance/logSet?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
    ],
  },
  {
    key: '/ahas/chaos',
    label: '故障演练',
    items: [
      {
        key: '/chaos',
        label: '概览',
        to: `/chaos/overview?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        activePathPatterns: ['/ahas/chaos'],
      },
      {
        key: '/chaos/workspace/owner',
        label: '我的空间',
        to: `/chaos/workspace/owner?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      // {
      //   key: '/chaos/workspace',
      //   label: '空间管理',
      //   to: `/chaos/workspace?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      // },
      {
        key: '/chaos/scenes',
        label: '演练场景',
        to: `/chaos/scenes?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/chaos/expertises',
        label: '演练经验',
        to: `/chaos/expertises?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/chaos/map',
        label: (
          <React.Fragment>
            <span>可视化演练</span>
            {/* <img
              style={{
                width: 27,
                marginLeft: 5,
                position: 'absolute',
                top: '4px',
              }}
              src={'https://img.alicdn.com/imgextra/i3/O1CN01xrPqEd29YgulYoa8X_!!6000000008080-55-tps-360-200.svg'}
            /> */}
          </React.Fragment>
        ),
        to: `/chaos/map?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        activePathPatterns: ['/chaos/map/detail'],
      },
      {
        key: '/ahas/archMap',
        label: (
          <React.Fragment>
            <span>架构感知</span>
            {/* <Icon
              type="external-link"
              size='xs'
              style={{
                color: '#C1C1C1',
                marginLeft: 5,
                marginTop: -2,
              }} /> */}
          </React.Fragment>
        ),
        to: `/arch/archMap?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/ahas/chaos/scenario',
        label: (
          <React.Fragment>
            <span>演练方案</span>
            {/* <Icon
              type="external-link"
              size='xs'
              style={{
                color: '#C1C1C1',
                marginLeft: 5,
                marginTop: -2,
              }} /> */}
          </React.Fragment>
        ),
        to: `/chaos/depGovernHome?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/ahas/chaos/dataAdmin',
        label: (
          <React.Fragment>
            <span>数据管理</span>
            {/* <Icon
              type="external-link"
              size='xs'
              style={{
                color: '#C1C1C1',
                marginLeft: 5,
                marginTop: -2,
              }} /> */}
          </React.Fragment>
        ),
        // to: `/chaos/application?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        to: `/chaos/workspace/list?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
    ],
  },
  {
    key: '/switch/applist',
    label: (
      <div style={{
        display: 'flex',
        alignItems: 'center',
      }}
      >
        <span>功能开关</span>
        <span style={{
          width: '0px',
          height: '0px',
          border: '4px solid',
          borderColor: 'transparent rgb(245, 71, 67) transparent transparent',
        }}
        />
        <Badge
          content="New"
          style={{
            backgroundColor: '#f54743',
            color: '#fff',
          }}
        />
      </div>
    ),
    to: `/switch/applist?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
  },
  {
    key: '/msha',
    label: (
      <div style={{
        display: 'flex',
        alignItems: 'center',
      }}
      >
        <a href={MSHA_URL} target="_black">多活容灾</a>
        <span style={{
          width: '0px',
          height: '0px',
          border: '4px solid',
          borderColor: 'transparent rgb(245, 71, 67) transparent transparent',
        }}
        />
        <Badge
          content="New"
          style={{
            backgroundColor: '#f54743',
            color: '#fff',
          }}
        />
      </div>
    ),
  },
  {
    key: '/manage/setting',
    label: '探针管理',
    to: `/manage/setting?ns=${getActiveNamespace()}&region=${getCurrentRegion()}&iis=${getParams('iis')}`,
    activePathPatterns: ['/manage/setting/k8sHost'],
  },
];

// 要匹配哪个二级导航
export const pathNameList = [
  {
    index: '/flowProtection/systemGuard/',
    value: 'flowApp',
  },
  {
    index: '/flowProtection/systemGuardGw/',
    value: 'flowGw',
  },
  {
    index: '/switch/app/',
    value: 'switchMenu',
  },
  {
    index: '/chaos/',
    value: 'chaosMenu',
  },
  {
    index: '/chaos/application/',
    value: 'chaosApplicationMenu',
  },
  {
    index: '/chaos/workspace',
    value: 'menuConfig',
  },
  {
    index: '/chaos/workspace/detail',
    value: 'chaosMenu',
  },
  {
    index: '/chaos/overview',
    value: 'chaosMenu',
  },
  {
    index: '/chaos/workspace/owner',
    value: 'chaosMenu',
  },
  {
    index: '/chaos/workspace/list',
    value: 'chaosMenu',
  },
  {
    index: '/chaos/expertises',
    value: '',
  },
  {
    index: '/arch',
    value: 'chaosMenu',
  },
];

// 从二级导航返回哪个菜单
export const returnMenuList = [
  {
    key: 'switchMenu',
    value: '/switch/applist',
  },
  {
    key: 'flowApp',
    value: '/flowProtection/systemGuard',
  },
  {
    key: 'flowGw',
    value: '/flowProtection/systemGuardGw',
  },
  {
    key: 'chaosMenu',
    value: '/chaos' || '/arch',
  },
  {
    key: 'chaosApplicationMenu',
    value: '/chaos/application',
  },
];

export function setMenuConfig(key: string) {
  if (key === 'menuConfig') {
    const status = getVirtualMerchant(); // 标识是否为虚商
    const isFinancial: boolean = getCurrentRegion() === 'cn-shanghai-finance-1'; // 标识是否为金融云
    const isGovernment: boolean = getCurrentRegion() === 'cn-north-2-gov-1'; // 标识是否为政务云
    const isSingapore: boolean = getCurrentRegion() === 'ap-southeast-1'; // 标识是否为新加坡

    let menuList = menuConfig;
    const hiddenMenuArry: string[] = ['/manage/alarm', '/msha'];

    if (status || isGovernment) {
      const hideStatusOrGovernmentMenu: string[] = ['/ahas/arch', '/ahas/chaos', '/manage/setting'];
      if (status) {
        hideStatusOrGovernmentMenu.push('/switch/applist');
      }
      hiddenMenuArry.push(...hideStatusOrGovernmentMenu);
    }

    // 在金融云、政务云、新加坡隐藏掉Mesh 防护  ->  流量防护-前端页面部分 region 功能隐藏 (需求ID：39303820)
    if (isFinancial || isGovernment || isSingapore) {
      let flowAppList = menuList.filter(item => item.key === '/ahas/flow')[0].items;
      // 隐藏掉Mesh 防护
      flowAppList = flowAppList?.filter(item => item.key !== '/flowProtection/meshProtection');
      menuList.filter(item => item.key === '/ahas/flow')[0].items = flowAppList;
    }

    // 虚商导航屏蔽
    if (status || isFinancial || isGovernment) {
      menuList = menuConfig.filter(item => !hiddenMenuArry.includes(item.key));
    }

    return menuList;
  }
  if (key === 'switchMenu') {
    return [
      {
        key: '/switch/app/switchlist',
        label: '开关列表',
        to: `/switch/app/switchlist/${getAppName()}?ns=${getActiveNamespace()}&region=${getCurrentRegion()}&ahasAppName=${getParams('ahasAppName')}`,
      },
      {
        key: '/switch/app/history',
        label: '历史记录',
        to: `/switch/app/history/${getAppName()}?ns=${getActiveNamespace()}&region=${getCurrentRegion()}&ahasAppName=${getParams('ahasAppName')}`,
      },
      {
        key: '/switch/app/taghistory',
        label: '标签记录',
        to: `/switch/app/taghistory/${getAppName()}?ns=${getActiveNamespace()}&region=${getCurrentRegion()}&ahasAppName=${getParams('ahasAppName')}`,
      },
      {
        key: '/switch/app/appadmin',
        label: '节点列表',
        to: `/switch/app/appadmin/${getAppName()}?ns=${getActiveNamespace()}&region=${getCurrentRegion()}&ahasAppName=${getParams('ahasAppName')}`,
      },
    ];
  }
  if (key === 'flowApp') {
    const urlAppName = getParams('appName') || getParams('ahasAppName')|| null;
    const urlAhasAppName = getParams('ahasAppName') ||getParams('appName')|| '';
    const isPublic = getParams('region') === 'public';
    const isNginx = sessionStorage.getItem('isNginx') === 'true';
    const isStressTab = sessionStorage.getItem('isStressTab') === 'true';
    const isOnlyGOSDK = sessionStorage.getItem('isOnlyGOSDK') === 'true';
    const MscAccount = JSON.parse(localStorage.getItem('MscAccount'));
    const isMscAccount = MscAccount.Version !== 2;
    const isNeedOpenArms = sessionStorage.getItem('isNeedOpenArms');
    const flowAppMenu = [
      {
        key: '/flowProtection/systemGuard/systemGuardSummary',
        label: intl('mse.msc.protect.overview'),
        to: `/flowProtection/systemGuard/systemGuardSummary?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
      },
      {
        key: '/flowProtection/systemGuard/systemGuardApiDetails',
        label: intl('mse.msc.app.sub.interface.details'),
        to: `/flowProtection/systemGuard/systemGuardApiDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
      },
      {
        key: '/flowProtection/systemGuard/systemGuardMachineDetails',
        label: intl('widget.msc.interface_details'),
        to: `/flowProtection/systemGuard/systemGuardMachineDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}&privateIp=_all`,
      },
      {
        key: '/flowProtection/systemGuard/flowGovernment',
        label: intl('mse.msc.menu.flow.government'),
        to: `/flowProtection/systemGuard/flowGovernment?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
      },
      {
        key: '/flowProtection/flowProtection',
        label: intl('mse.msc.menu.protect.flower'),
        items: [
          {
            key: '/flowProtection/systemGuard/SetRules',
            label: '限流降级',
            to: `/flowProtection/systemGuard/setRules?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
          {
            key: '/flowProtection/systemGuard/systemHotSpotMonitor',
            label: intl('mse.msc.protect.hotSpotMonitor'),
            to: `/flowProtection/systemGuard/systemHotSpotMonitor?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
          {
            key: '/flowProtection/clusterFlowControl',
            label: intl('mse.msc.protect.clusterControl'),
            items: [
              {
                key: '/flowProtection/systemGuard/systemGuardClusterProtection',
                label: intl('mse.msc.protect.clusterControl.config'),
                to: `/flowProtection/systemGuard/systemGuardClusterProtection?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
              {
                key: '/flowProtection/systemGuard/systemGuardClusterDetails',
                label: intl('mse.msc.protect.clusterControl.details'),
                to: `/flowProtection/systemGuard/systemGuardClusterDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
            ],
          },
          {
            key: '/flowProtection/SceneOriented',
            label: intl('mse.msc.protect.sence'),
            items: [
              {
                key: '/flowProtection/systemGuard/systemGuardWebSceneOriented',
                label: intl('mse.msc.protect.sence.web'),
                to: `/flowProtection/systemGuard/systemGuardWebSceneOriented?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
            ],
          },
        ],
      },
      {
        key: '/flowProtection/systemGuard/dataBaseGovernment',
        label: <div><Badge
          content="公测"
          style={{
            backgroundColor: '#f54743',
            color: '#fff',
            borderRadius: '10px',
            top: -10,
            right: -40,
          }}
        >
          {intl('mse.msc.menu.dataBase.government')}
        </Badge></div>,
        to: `/flowProtection/systemGuard/dataBaseGovernment?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
      },
      {
        key: '/flowProtection/systemGuard/securityGovernance',
        label: intl('mse.msc.menu.security.governance'),
        // to: `/flowProtection/systemGuard/securityGovernance?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
        items: [
          {
            key: '/flowProtection/systemGuard/authentication',
            label: intl('mse.msc.menu.auth'),
            to: `/flowProtection/systemGuard/authentication?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
        ],
      },
      {
        key: '/flowProtection/systemGuard/appConfig',
        label: intl('mse.msc.menu.config'),
        items: [
          {
            key: '/flowProtection/systemGuard/configList',
            label: intl('mse.msc.config.applist'),
            to: `/flowProtection/systemGuard/configList/${urlAppName}?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
          {
            key: '/flowProtection/systemGuard/history',
            label: intl('mse.msc.config.history'),
            to: `/flowProtection/systemGuard/history/${urlAppName}?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
          {
            key: '/flowProtection/systemGuard/taghistory',
            label: intl('mse.msc.config.taghistory'),
            to: `/flowProtection/systemGuard/taghistory/${urlAppName}?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
          {
            key: '/flowProtection/systemGuard/appadmin',
            label: intl('mse.msc.config.appadmin'),
            to: `/flowProtection/systemGuard/appadmin/${urlAppName}?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
        ],
      },
      {
        key: '/flowProtection/AppDevOps',
        label: '应用运维',
        items: [
          {
            key: '/flowProtection/systemGuard/SystemEventsCenter',
            label: '事件中心',
            to: `/flowProtection/systemGuard/SystemEventsCenter?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
          {
            key: '/flowProtection/systemGuard/operationLog',
            label: '操作日志',
            to: `/flowProtection/systemGuard/operationLog?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
          {
            key: '/flowProtection/flowSetting',
            label: '流控设置',
            items: [
              {
                key: '/flowProtection/systemGuard/SystemGuardBasic',
                label: '基础设置',
                to: `/flowProtection/systemGuard/SystemGuardBasic?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
              {
                key: '/flowProtection/systemGuard/SystemGuardBehavior',
                label: '行为管理',
                to: `/flowProtection/systemGuard/SystemGuardBehavior?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
            ],
          },
          {
            key: '/flowProtection/AlarmManage',
            label: '告警管理',
            items: [
              {
                key: '/flowProtection/systemGuard/systemGuardAlarmRulesNew',
                label: '告警规则',
                to: `/flowProtection/systemGuard/systemGuardAlarmRulesNew?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
              {
                key: '/flowProtection/systemGuard/systemGuardAlarmDetailsNew',
                label: '告警详情',
                to: `/flowProtection/systemGuard/systemGuardAlarmDetailsNew?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
              {
                key: '/flowProtection/systemGuard/concats',
                label: '联系人管理',
                to: `/flowProtection/systemGuard/concats?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
              {
                key: '/flowProtection/systemGuard/alarmDispatch',
                label: '通知策略',
                to: `/flowProtection/systemGuard/alarmDispatch?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
              },
            ],
          },
          {
            key: '/flowProtection/systemGuard/systemGuardAlarmRules',
            label: '告警规则',
            to: `/flowProtection/systemGuard/systemGuardAlarmRules?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
          {
            key: '/flowProtection/systemGuard/systemGuardAlarmDetails',
            label: '告警详情',
            to: `/flowProtection/systemGuard/systemGuardAlarmDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
          },
        ],
      },
      // {
      //   key: '/flowProtection/systemGuard/systemHotSpotMonitor',
      //   label: '热点详情',
      //   to: `/flowProtection/systemGuard/systemHotSpotMonitor?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      // },
      {
        key: '/flowProtection/systemGuard/SystemGuardNginxApi',
        label: '请求分组管理',
        to: `/flowProtection/systemGuard/SystemGuardNginxApi?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
      },
      // {
      //   key: '/flowProtection/systemGuard/SetRules',
      //   label: '规则管理',
      //   to: `/flowProtection/systemGuard/setRules?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      // },
      // {
      //   key: '/flowProtection/SceneOriented',
      //   label: '场景防护',
      //   items: [
      //     {
      //       key: '/flowProtection/systemGuard/systemGuardWebSceneOriented',
      //       label: 'WEB 场景',
      //       to: `/flowProtection/systemGuard/systemGuardWebSceneOriented?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      //     },
      //   ],
      // },
      // {
      //   key: '/flowProtection/systemGuard/systemGuardGeneral',
      //   label: '应用管理',
      //   to: `/flowProtection/systemGuard/systemGuardGeneral?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      // },
      // {
      //   key: '/flowProtection/systemGuard/systemServiceStressTest',
      //   label: '服务压测',
      //   to: `/flowProtection/systemGuard/systemServiceStressTest?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      // },
      // {
      //   key: '/flowProtection/clusterFlowControl',
      //   label: '集群流控',
      //   items: [
      //     {
      //       key: '/flowProtection/systemGuard/systemGuardClusterProtection',
      //       label: '集群配置',
      //       to: `/flowProtection/systemGuard/systemGuardClusterProtection?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      //     },
      //     {
      //       key: '/flowProtection/systemGuard/systemGuardClusterDetails',
      //       label: '集群详情',
      //       to: `/flowProtection/systemGuard/systemGuardClusterDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      //     },
      //   ],
      // },
      // {
      //   key: '/flowProtection/alarmManagement',
      //   label: '告警管理',
      //   items: [
      //     {
      //       key: '/flowProtection/systemGuard/systemGuardAlarmRules',
      //       label: '告警规则',
      //       to: `/flowProtection/systemGuard/systemGuardAlarmRules?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      //     },
      //     {
      //       key: '/flowProtection/systemGuard/systemGuardAlarmDetails',
      //       label: '告警详情',
      //       to: `/flowProtection/systemGuard/systemGuardAlarmDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      //     },
      //   ],
      // },
      // {
      //   key: '/flowProtection/systemGuard/systemServiceStress',
      //   label: '应用压测',
      //   to: `/flowProtection/systemGuard/systemServiceStress?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&armsAppId=${getParams('armsAppId') || ''}`,
      // },
      // {
      //   key: '/flowProtection/systemGuard/systemProtectionManagement',
      //   label: '防护管理',
      //   to: `/flowProtection/systemGuard/systemProtectionManagement?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      // },
    ];

    const MicroServiceInsight: any = { // 微服务洞察
      key: '/flowProtection/systemGuard/ruleDetails',
      label: <div><Badge
        content="公测"
        style={{
          backgroundColor: '#f54743',
          color: '#fff',
          borderRadius: '10px',
          top: -10,
          right: -40,
        }}
      >
        {intl('mse.msc.menu.ruleDetails')}
      </Badge></div>,
      items: [
        {
          key: '/flowProtection/systemGuard/ruleDetails',
          label: intl('mse.msc.log.governance.rule.list'),
          to: `/flowProtection/systemGuard/ruleDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
        },
        {
          key: '/flowProtection/systemGuard/linkPresentation',
          label: intl('mse.msc.menu.linkPresentation'),
          to: `/flowProtection/systemGuard/linkPresentation?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}&armsAppId=${getParams('armsAppId') || ''}&accessType=${getParams('accessType') || ''}`,
        },
      ],
    };
    const abroadRegion = [ // 微服务洞察功能国外暂不透出
      'ap-southeast-1', // 新加坡
      'eu-central-1', // 德国（法兰克福）
    ];
    for (let i = 0; i < abroadRegion.length; i++) {
      if (abroadRegion[i] === getParams('region')) {
        break;
      }
      if (abroadRegion[i] !== getParams('region')) {
        flowAppMenu.splice(4, 0, MicroServiceInsight);
      }
    }

    let menuList = flowAppMenu;
    const isFinancial: boolean = getCurrentRegion() === 'cn-shanghai-finance-1'; // 标识是否为金融云
    const isGovernment: boolean = getCurrentRegion() === 'cn-north-2-gov-1'; // 标识是否为政务云
    const isSingapore: boolean = getCurrentRegion() === 'ap-southeast-1'; // 标识是否为新加坡
    let hiddenArry: string[] = ['/flowProtection/systemGuard/SystemGuardNginxApi'];
    (isNginx || !isStressTab) && hiddenArry.push('/flowProtection/systemGuard/systemServiceStress');
    isNginx && hiddenArry.push('/flowProtection/alarmManagement', '/flowProtection/systemGuard/systemGuardClusterDetails', '/flowProtection/SceneOriented');
    isNginx && isPublic && hiddenArry.push('/flowProtection/clusterFlowControl');
    // 纯GO语言隐藏菜单: 流量治理、数据库治理、集群流控、场景防护
    isOnlyGOSDK && hiddenArry.push('/flowProtection/systemGuard/flowGovernment', '/flowProtection/systemGuard/dataBaseGovernment', '/flowProtection/clusterFlowControl', '/flowProtection/SceneOriented', '/flowProtection/systemGuard/appConfig', '/flowProtection/systemGuard/systemHotSpotMonitor', '/flowProtection/systemGuard/securityGovernance');
    // if (isOnlyGOSDK) {
    //   hiddenArry.push('/flowProtection/systemGuard/flowGovernment', '/flowProtection/systemGuard/dataBaseGovernment', '/flowProtection/clusterFlowControl', '/flowProtection/SceneOriented');
    // }
    isMscAccount && hiddenArry.push('/flowProtection/flowProtection');

    if (isNeedOpenArms === 'true') {
      hiddenArry.push('/flowProtection/AlarmManage');
    } else {
      hiddenArry.push('/flowProtection/systemGuard/systemGuardAlarmRules', '/flowProtection/systemGuard/systemGuardAlarmDetails');
    }

    if (isNginx) {
      const nginxHiddenArr = hiddenArry.filter((item: string) => {
        return item !== '/flowProtection/systemGuard/SystemGuardNginxApi';
      });
      hiddenArry = nginxHiddenArr;
    }

    // 在金融云、政务云、新加坡隐藏掉集群流控和应用压测  ->  流量防护-前端页面部分 region 功能隐藏 (需求ID：39303820)
    if (isFinancial || isGovernment || isSingapore) {
      // 隐藏掉集群流控和应用压测
      hiddenArry.push('/flowProtection/clusterFlowControl');
      hiddenArry.push('/flowProtection/systemGuard/systemServiceStress');
    }

    if (sessionStorage.getItem('CurrentAppType') === '2') {
      hiddenArry.push('/flowProtection/systemGuard/systemHotSpotMonitor');
      hiddenArry.push('/flowProtection/SceneOriented');
      hiddenArry.push('/flowProtection/clusterFlowControl');
      hiddenArry.push('/flowProtection/alarmManagement');
      hiddenArry.push('/flowProtection/systemGuard/systemServiceStress');
    }

    const filterMenuList = (menuList: any) => {
      return menuList.filter((item: any) => {
        return !hiddenArry.includes(item.key);
      }).map((item: any) => {
        item = Object.assign({}, item);
        if (item.items && item.items.length > 0) {
          item.items = filterMenuList(item.items);
        }
        return item;
      });
    };

    menuList = filterMenuList(flowAppMenu);
    return menuList;
  }

  if (key === 'flowGw') {
    const urlAppName = getParams('appName') ||getParams('ahasAppName')|| null;
    const urlAhasAppName = getParams('ahasAppName') ||getParams('appName')|| '';
    return [
      {
        key: '/flowProtection/systemGuardGw/systemGuardGwApiDetails',
        label: intl('mse.msc.app.sub.interface.details'),
        to: `/flowProtection/systemGuardGw/systemGuardGwApiDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/flowProtection/systemGuardGw/systemGuardGwMachineDetails',
        label: intl('widget.msc.interface_details'),
        to: `/flowProtection/systemGuardGw/systemGuardGwMachineDetails?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/flowProtection/systemGuardGw/SystemGuardGwApi',
        label: '请求分组管理',
        to: `/flowProtection/systemGuardGw/SystemGuardGwApi?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      // {
      //   key: '/flowProtection/systemGuardGw/systemGuardGwFlow',
      //   label: 'API 流控规则',
      //   to: `/flowProtection/systemGuardGw/systemGuardGwFlow?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      // },
      {
        key: '/flowProtection/systemGuardGw/systemGuardGwSetRules',
        label: '规则管理',
        to: `/flowProtection/systemGuardGw/systemGuardGwSetRules?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      },
      {
        key: '/flowProtection/systemGuardGw/systemGuardGwClusterProtection',
        label: '集群流控',
        to: `/flowProtection/systemGuardGw/systemGuardGwClusterProtection?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/flowProtection/systemGuardGw/systemGuardGwGeneral',
        label: '应用管理',
        to: `/flowProtection/systemGuardGw/systemGuardGwGeneral?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}&isNginx=${getParams('isNginx') || ''}`,
      },
      // {
      //   key: '/flowProtection/systemGuardGw/systemGuardGwNode',
      //   label: '节点管理',
      //   to: `/flowProtection/systemGuardGw/systemGuardGwNode?appName=${urlAppName}&ahasAppName=${urlAhasAppName}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      // },
    ];
  }
  if (key === 'chaosMenu') {
    return [
      {
        key: '/chaos/overview',
        label: '概览',
        to: `/chaos/overview?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/chaos/workspace/owner',
        label: '我的空间',
        to: `/chaos/workspace/owner?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        activePathPatterns: [
          '/chaos/workspace/owner',
        ],
      },
      {
        key: '/chaos/scenes',
        label: '演练场景',
        to: `/chaos/scenes?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/chaos/expertise/list',
        label: '演练经验',
        to: `/chaos/expertise/list?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        activePathPatterns: ['/chaos/expertise/detail'],
      },
      {
        key: '/chaos/map',
        label: (
          <React.Fragment>
            <span>可视化演练</span>
            {/* <img
                style={{
                  width: 27,
                  marginLeft: 5,
                  position: 'absolute',
                  top: '4px',
                }}
                src={'https://img.alicdn.com/imgextra/i3/O1CN01xrPqEd29YgulYoa8X_!!6000000008080-55-tps-360-200.svg'} // 内测按钮
              /> */}
          </React.Fragment>
        ),
        to: `/chaos/map?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        activePathPatterns: ['/chaos/map/detail'],
      },
      {
        key: '/arch/archMap',
        label: '架构感知',
        // items: [
        //   {
        //     key: '/arch/archMap',
        //     label: '架构地图',
        //     to: `/arch/archMap?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        //   },
        //   {
        //     key: '/arch/archCheck',
        //     label: '架构巡检',
        //     to: `/arch/archCheck?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        //   },
        //   {
        //     key: '/arch/archSetting',
        //     label: '巡检设置',
        //     to: `/arch/archSetting?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        //   },
        // ],
        to: `/arch/archMap?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        activePathPatterns: [
          '/arch/archMap', '/arch/archCheck', '/arch/archSetting',
        ],
      },
      // {
      //   key: '/chaos/workspace/list',
      //   label: '空间管理',
      //   to: `/chaos/workspace/list?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      //   activePathPatterns: [
      //     '/chaos/experiment/detail',
      //     '/chaos/workspace/detail',
      //     '/chaos/workspace/list',
      //     '/chaos/experiment/editor',
      //     '/chaos/experiment/task',
      //   ],
      // },
      {
        key: '/ahas/chaos/scenario',
        label: '演练方案',
        items: [
          {
            key: '/chaos/depGovernHome',
            label: (
              <React.Fragment>
                <span>微服务演练</span>
                {/* <img
                    style={{
                      width: 27,
                      marginLeft: 5,
                    }}
                    src={'https://img.alicdn.com/tfs/TB1eW1HNXT7gK0jSZFpXXaTkpXa-34-18.svg'}
                  /> */}
                </React.Fragment>
            ),
            to: `/chaos/depGovernHome?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
            activePathPatterns: ['/chaos/depGovernHome', '/chaos/depGovernList', '/chaos/depGovernCreate', '/chaos/depGovernEdit', '/chaos/depGovernDetail', '/chaos/mq/experiments', '/chaos/mq/experiment/detail', '/chaos/mq/experiment/editor'],
          },
          {
            key: '/chaos/disaster',
            label: (
              <React.Fragment>
                <span>容灾演练</span>{/* <img
                  style={{
                    width: 27,
                    marginLeft: 5,
                  }}
                  src={'https://img.alicdn.com/tfs/TB1eW1HNXT7gK0jSZFpXXaTkpXa-34-18.svg'}
                /> */}
              </React.Fragment>
            ),
            to: `/chaos/disaster?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
            activePathPatterns: ['/chaos/disaster/editor'],
          },
          {
            key: '/chaos/container/alarm',
            label: (
              <React.Fragment><span>容器演练</span>{/* <img
                  style={{
                    width: 27,
                    marginLeft: 5,
                  }}
                  src={'https://img.alicdn.com/tfs/TB1eW1HNXT7gK0jSZFpXXaTkpXa-34-18.svg'}
                /> */}
                </React.Fragment>
            ),
            to: `/chaos/container/alarm?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
            // activePathPatterns: [ '/chaos/mq/experiment/detail', '/chaos/mq/experiment/editor' ],
          },
          // {
          //   key: '/chaos/mq/experiments',
          //   label: (
          //     <>
          //       <span>消息演练</span>
          //       {/* <img
          //         style={{
          //           width: 27,
          //           marginLeft: 5,
          //         }}
          //         src={'https://img.alicdn.com/tfs/TB1eW1HNXT7gK0jSZFpXXaTkpXa-34-18.svg'}
          //       /> */}
          //     </>
          //   ),
          //   to: `/chaos/mq/experiments?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
          //   activePathPatterns: [ '/chaos/mq/experiment/detail', '/chaos/mq/experiment/editor' ],
          // },
        ],
      },
      {
        key: '/chaos/application',
        label: '应用管理',
        to: `/chaos/application?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        activePathPatterns: ['/chaos/freshapplication/access'],
      },
      {
        key: '/chaos/experiment/scope/control',
        label: '探针管理',
        to: `/chaos/experiment/scope/control?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
        activePathPatterns: [
          '/chaos/experiment/scope/detail',
          '/chaos/agentmanage/k8sHostl',
          '/chaos/agentmanage/detail',
          '/chaos/agentmanage/setting/step',
          '/chaos/agentmanage/alarm',
        ],
      },
      // {
      //   key: '/ahas/chaos/global',
      //   label: '全局高可用',
      //   visible: getCurrentRegion() !== 'public',
      //   items: [
      //     {
      //       key: '/chaos/disaster',
      //       label: (
      //         <>
      //           <span>容灾演练</span>
      //           <img
      //             style={{
      //               width: 27,
      //               marginLeft: 5,
      //             }}
      //             src={'https://img.alicdn.com/tfs/TB1eW1HNXT7gK0jSZFpXXaTkpXa-34-18.svg'}
      //           />
      //         </>
      //       ),
      //       to: `/chaos/disaster?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      //       activePathPatterns: [ '/chaos/disaster/editor' ],
      //     },
      //   ],
      // },
      {
        key: '/ahas/chaos/dataAdmin',
        label: '数据管理',
        items: [
          {
            key: '/chaos/workspace/list',
            label: (
              <React.Fragment><span>空间管理</span></React.Fragment>
            ),
            to: `/chaos/workspace/list?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
            activePathPatterns: [
              '/chaos/experiment/detail',
              '/chaos/workspace/detail',
              '/chaos/workspace/list',
              '/chaos/experiment/editor',
              '/chaos/experiment/task',
            ],
          },
          // {
          //   key: '/chaos/feeIndex',
          //   label: '消费记录',
          //   to: `/chaos/feeIndex?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
          //   // eslint-disable-next-line no-bitwise
          //   betaFlag: (1 << 4),
          // },
          {
            key: '/chaos/expertise/admin',
            label: '经验库管理',
            to: `/chaos/expertise/admin?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
            activePathPatterns: ['/chaos/expertise/editor'],
          },
          {
            key: '/chaos/scene/list',
            label: '小程序管理',
            to: `/chaos/scene/list?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
            isAdmin: true, // 需要鉴权
            activePathPatterns: ['/chaos/scene/detail'],
          },
          {
            key: '/chaos/applicationInner',
            label: '集团应用管理',
            to: `/chaos/applicationInner?ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
            isAdmin: true, // 需要鉴权
          },
        ],
      },
    ];
  }
  if (key === 'chaosApplicationMenu') {
    return [
      {
        key: '/chaos/application/detail',
        label: intl('mse.msc.protect.overview'),
        to: `/chaos/application/detail?appId=${getParams('appId')}&appType=${getParams('appType')}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/chaos/application/scopelist',
        label: '机器列表',
        to: `/chaos/application/scopelist?appId=${getParams('appId')}&appType=${getParams('appType')}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/chaos/application/tasklist',
        label: '演练记录',
        to: `/chaos/application/tasklist?appId=${getParams('appId')}&appType=${getParams('appType')}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
      {
        key: '/chaos/application/setting',
        label: '应用配置',
        to: `/chaos/application/setting?appId=${getParams('appId')}&appType=${getParams('appType')}&ns=${getActiveNamespace()}&region=${getCurrentRegion()}`,
      },
    ];
  }
}

// 激活菜单
export const activeKeys: {[key: string]: string} = {
  '/arch/archMap': '/ahas/arch',
  '/arch/archCheck': '/ahas/arch',
  '/arch/archSetting': '/ahas/arch',
  '/flowProtection/systemGuard': '/ahas/flow',
  '/flowProtection/systemGuardGw': '/ahas/flow',
  '/flowProtection/monitorDashboard': '/ahas/flow',
  '/flowProtection/meshProtection': '/ahas/flow',
  '/flowProtection/systemGuardAlarmRules': '/flowProtection/alarmManagement',
  '/flowProtection/systemGuardAlarmDetails': '/flowProtection/alarmManagement',
  '/flowProtection/systemGuardWebSceneOriented': '/flowProtection/SceneOriented',
  // '/flowProtection/systemGuard/SetRules': '/flowProtection/flowProtection',
  '/chaos': '/ahas/chaos',
  '/chaos/workspace': '/ahas/chaos',
  '/chaos/workspace/detail': '/ahas/chaos',
  '/chaos/expertises': '/ahas/chaos',
};
