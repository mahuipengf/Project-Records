/** **************** 应用防护模块开始 **************** **/
import intl from '@ali/wind-intl';
import { get, toLength } from 'lodash';
// 接口详情模块

// 切换tab项
export const API_TAB_DEFAULT = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.WEBservice'), // WEB服务
    value: 'iconfont icon-Ahas-Web',
    key: '1',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.RPCservice'), // 'RPC服务',
    value: 'iconfont icon-Ahas-RPC',
    key: '2',
  },
  // {
  //   title: intl('ahas_sentinel.systemGuard.flowControl.database'), // 数据库
  //   value: 'iconfont icon-Ahas-shujuku',
  //   key: '4',
  // },
  // {
  //   title: intl('ahas_sentinel.systemGuard.flowControl.Cache'), // 缓存
  //   value: 'iconfont icon-Ahas-huancun',
  //   key: '5',
  // },
  // {
  //   title: intl('ahas_sentinel.systemGuard.flowControl.DependentService'), // 依赖服务
  //   value: 'iconfont icon-Ahas-guanlian',
  //   key: '-1',
  // },
  // {
  //   title: intl('ahas_sentinel.systemGuard.flowControl.Customburiedpoint'), // 自定义埋点',
  //   value: 'iconfont icon-Ahas-zidingyi',
  //   key: '0',
  // },
  // {
  //   title: intl('ahas_sentinel.systemGuard.flowControl.mycollection'), // 我的收藏
  //   value: 'iconfont icon-Ahas-Collect',
  //   key: '-2',
  // },
];

export const new_API_TAB_DEFAULT = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.WEBservice'), // WEB服务
    value: 'iconfont icon-Ahas-Web',
    key: '1',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.RPCservice'), // 'RPC服务',
    value: 'iconfont icon-Ahas-RPC',
    key: '2',
  },
];

export const GATEWAY_TAB_DEFAULT = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.All'), // '全部',
    value: 'iconfont icon-Ahas-All',
    key: '-1',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.mycollection'), // 我的收藏
    value: 'iconfont icon-Ahas-Collect',
    key: '-2',
  },
];

export const MACGINE_ALL_TAB_DEFAULT = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.ApplicationIndex'), // 应用指标',
    key: '0',
  },
  {
    title: 'CPU',
    key: '1',
  },
  {
    title: 'LOAD',
    key: '2',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.Physicalmemory'), // 物理内存
    key: '3',
  },
  {
    title: 'Disk',
    key: '4',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.NetworkTraffic'), // 网络流量
    key: '5',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.Networkpacket'), // 网络数据包
    key: '6',
  },
];

export const MACGINE_JVM_ALL_TAB_DEFAULT = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.GCtimes'), // GC次数
    key: '0',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.GCimeconsuming'), // GC耗时
    key: '1',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.Heapmemorydetails'), // 堆内存详情
    key: '2',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.nonHeapMemoryDetails'), // 非堆内存详情
    key: '5',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.Metaspacedetails'), // 元空间详情
    key: '3',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.NumberofJVMthreads'), // JVM线程数
    key: '4',
  },
];

export const SORT_TAB = [
  {
    value: 0,
    title: intl('ahas_sentinel.systemGuard.flowControl.ViaQPS'), // 通过QPS
    type: 'api',
  },
  {
    value: 1,
    title: intl('ahas_sentinel.systemGuard.flowControl.CurrentlimitQPS'), // 限流QPS
    type: 'api',
  },
  {
    value: 2,
    title: intl('ahas_sentinel.systemGuard.flowControl.AbnormalQPS'), // 异常QPS
    type: 'api',
  },
  {
    value: 4,
    title: 'RT',
    type: 'api',
  },
];

export const SORT_TAB_Machine = [
  {
    value: 0,
    title: intl('mse.apiDetail.RequestsVolume'), // 请求量
    type: 'api',
  },
  {
    value: 1,
    title: intl('mse.appOverview.rejection'), // 拒绝量
    type: 'api',
  },
  {
    value: 2,
    title: intl('mse.appOverview.AnomalousQuantity'), // 异常量
    type: 'api',
  },
  {
    value: 3,
    title: 'RT',
    type: 'api',
  },
];

export const SORT_TAB_WEB = [
  {
    value: 0,
    title: intl('ahas_sentinel.systemGuard.flowControl.ViaQPS'), // 通过QPS
    type: 'api',
  },
  {
    value: 1,
    title: intl('ahas_sentinel.systemGuard.flowControl.CurrentlimitQPS'), // 限流QPS
    type: 'api',
  },
  {
    value: 4,
    title: 'RT',
    type: 'api',
  },
];

export const BASIC_NODE = [
  {
    value: 'baseInfo',
    title: intl('ahas_sentinel.systemGuard.flowControl.baseInfo'), // 基本信息,
  },
  {
    value: 'nodeOverview',
    title: intl('ahas_sentinel.systemGuard.flowControl.nodeOverview'), // 节点概览
  },
  {
    value: 'SubDetails',
    title: intl('ahas_sentinel.systemGuard.flowControl.InterfaceDetails'), // 接口详情
  },
];

export const MACHINE_MONITORING_NODE = [
  {
    value: 'baseInfo',
    title: intl('ahas_sentinel.systemGuard.flowControl.baseInfo'), // 基本信息,
  },
  {
    value: 'nodeOverview',
    title: intl('ahas_sentinel.systemGuard.flowControl.nodeOverview'), // 节点概览
  },
  {
    value: 'jvm',
    title: intl('ahas_sentinel.systemGuard.flowControl.JVMmonitoring'), // JVM 监控
  },
  {
    value: 'SubDetails',
    title: intl('ahas_sentinel.systemGuard.flowControl.InterfaceDetails'), // 接口详情
  },
  // {
  //   value: 'callstack',
  //   title: intl('ahas_sentinel.systemGuard.flowControl.callstackinformation'), // callstack 信息,
  // },
  // {
  //   value: 'esxception',
  //   title: intl('ahas_sentinel.systemGuard.FuseRules.ExceptionStatistics'), // 异常统计,
  // },
];

export const new_MACHINE_MONITORING_NODE = [
  {
    value: 'baseInfo',
    title: intl('ahas_sentinel.systemGuard.flowControl.baseInfo'), // 基本信息,
  },
  {
    value: 'nodeOverview',
    title: intl('ahas_sentinel.systemGuard.flowControl.nodeOverview'), // 节点概览
  },
  {
    value: 'SubDetails',
    title: intl('ahas_sentinel.systemGuard.flowControl.InterfaceDetails'), // 接口详情
  },
];

export const NGINX_MONITORING_NODE = [
  {
    value: 'nodeOverview',
    title: intl('ahas_sentinel.systemGuard.flowControl.Nodeoverview'), // 节点概览
  },
  {
    value: 'SubDetails',
    title: intl('ahas_sentinel.systemGuard.flowControl.InterfaceDetails'), // 接口详情
  },
  // {
  //   value: 'callstack',
  //   title: intl('ahas_sentinel.systemGuard.flowControl.callstackinformation'), // callstack 信息,
  // },
];

export const CHARTS_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.QPSdata'), // QPS数据（秒级）
  intl('ahas_sentinel.systemGuard.flowControl.RTdata'), // RT数据（ms）
  intl('ahas_sentinel.systemGuard.flowControl.Concurrentdata'), // 并发数据（秒级）
];

export const CHARTS_TYPE = ['allQps', 'rt', 'thread'];

export const JVM_CHARTS_TYPE = ['jvmGc', 'jvmGcTime', 'jvmHeap', 'jvMetaSpace', 'jvmThreadCount'];

export const SUMMARY_REQUESTS_COUNT_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.NumberofPassedRequest'), // 通过请求数
  intl('ahas_sentinel.systemGuard.flowControl.Flowcontrolrequests'), // 流控请求数
  intl('ahas_sentinel.systemGuard.flowControl.Numberofexceptionrequests'), // 异常请求数
];

export const SUMMARY_RT_STATUS_TITLE = [
  {
    title: 'RT(ms)',
    width: '100%',
  },
];

export const SUMMARY_RT_CPU_STATUS_TITLE = [
  {
    title: 'RT(ms)',
    width: '49.5%',
  },
  {
    title: 'CPU',
    width: '49.5%',
  },
  // {
  //   title: intl('ahas_sentinel.systemGuard.flowControl.Statuscodestatistics'), // 状态码统计
  //   width: '24.5%',
  // },
];

export const SUMMARY_RT_CPU_TITLE = [
  {
    title: 'RT(ms)',
    width: '49.5%',
  },
  {
    title: 'CPU',
    width: '49.5%',
  },
];

export const SUMMARY_RT_CPU_STATUS_TYPE = [
  'rt',
  'cpu',
  'statusCode',
];

export const SUMMARY_CHARTS_Flow_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.QPSData'), // QPS数据
  'RT(ms)',
  'CPU',
  intl('ahas_sentinel.systemGuard.flowControl.Protectionevent'), // 防护事件
];

export const SUMMARY_CHARTS_Flow_TYPE = [
  'allQps',
  'rt',
  'cpu',
  'event',
];

export const MACHINE_CHARTS_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.QPSData'), // QPS数据
  intl('ahas_sentinel.systemGuard.flowControl.RTData'), // RT数据
  'CPU',
  'Load',
  intl('ahas_sentinel.systemGuard.flowControl.Concurrentdata'), // 并发数据（秒级）
];


export const SUMMARY_CHARTS_SYSTEM_TITLE = [
  'Load',
  // intl('ahas_sentinel.systemGuard.flowControl.physicalMemory'), // 物理内存（G）
  // 'Disk（G)',
];

export const SUMMARY_CHARTS_SYSTEM_TYPE = [
  'load',
  // 'system_memory',
  // 'system_disk',
];

export const SUMMARY_CHARTS_JVM_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.GCtimes'), // GC次数
  intl('ahas_sentinel.systemGuard.flowControl.GCduration'), // GC时长
  // intl('ahas_sentinel.systemGuard.flowControl.Heapmemorydetails'), // 堆内存详情
  // intl('ahas_sentinel.systemGuard.FuseRules.memorydetails'),
  // `${intl('ahas_sentinel.systemGuard.flowControl.nonHeapMemoryDetails')} / M`,
  intl('ahas_sentinel.systemGuard.flowControl.NumberofJVMthreads'), // JVM线程数
];

export const SUMMARY_CHARTS_JVM_TYPE = [
  'jvm_gc',
  'jvm_gc_time',
  'jvm_heap',
  'jvm_none_heap',
  'jvm_thread_count',
];

export const SUMMARY_CHARTS_NETWORK_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.NetworkTraffic'),
  // intl('ahas_sentinel.systemGuard.flowControl.Networktraffic'), // 网络流量（Byte）
  intl('ahas_sentinel.systemGuard.flowControl.Networkdatapacket'), // 网络数据包（个）
];

export const SUMMARY_CHARTS_NETWORK_TYPE = [
  'system_network',
  'system_network_data_pack',
];

export const SUMMARY_CHARTS_MODELS_TYPE = ['system', 'jvm', 'netWork'];

export const MACHINE_CHARTS_TYPE = ['allQps', 'rt', 'cpu', 'load', 'thread','system_memory', 'system_disk', 'system_network', 'system_network_data_pack'];

export const NODE_CHARTS_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.QPSdataofthenode'), // 节点的QPS数据（秒级）,
  intl('ahas_sentinel.systemGuard.flowControl.RTdataofthenode'), // 节点的RT数据（ms）
  intl('ahas_sentinel.systemGuard.flowControl.Concurrent'), // 节点的并发数据（秒级）
];

export const NODE_MACHINE_CHARTS_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.secondlevel'), // 接口的QPS数据（秒级）
  intl('ahas_sentinel.systemGuard.flowControl.RTdataoftheinterface'), // 接口的RT数据（ms）
  intl('ahas_sentinel.systemGuard.flowControl.Concurrentdataoftheinterface'), // 接口的并发数据（秒级,
];

export const SELECT_CHARTS_TYPE = [
  intl('mse.appOverview.allQps'),
  intl('ahas_sentinel.systemGuard.flowControl.ViaQPS'), // 通过QPS
  intl('ahas_sentinel.systemGuard.flowControl.RejectQPS'), // 拒绝QPS,
  intl('ahas_sentinel.systemGuard.flowControl.AbnormalQPS'), // 异常QPS
  // intl('ahas_sentinel.systemGuard.flowControl.GaryQPS'), // 灰度QPS
  'RT(ms)',
  intl('ahas_sentinel.systemGuard.flowControl.Concurrents'), // 并发,
];

export const SELECT_CHARTS_TYPE_SQL = [
  intl('mse.appOverview.allQps'),
  intl('ahas_sentinel.systemGuard.flowControl.ViaQPS'), // 通过QPS
  intl('ahas_sentinel.systemGuard.flowControl.RejectQPS'), // 拒绝QPS,
  intl('ahas_sentinel.systemGuard.flowControl.AbnormalQPS'), // 异常QPS
  // intl('ahas_sentinel.systemGuard.flowControl.GaryQPS'), // 灰度QPS
  'RT(ms)',
  intl('ahas_sentinel.systemGuard.flowControl.maxConcurrency'), // 并发,
];


export const NODE_CHARTS_TYPE = [
  'allQps',
  'rt',
];

export const MACHINE_RESOURCE_ARR = [
  '__app_summary_metric_resource_name__',
  '__cpu_usage__',
  '__system_load__',
  '__thread__',
];

export const RENDER_API_ICON_TYPE = [
  'iconAhas-All',
  'iconAhas-Web',
  'iconAhas-RPC',
  'iconAhas-SQL',
  'iconAhas-Other',
  'iconAhas-Collect',
];

export const ICON_OF_FALL_URL =
  'https://img.alicdn.com/tfs/TB1dbJkGLb2gK0jSZK9XXaEgFXa-12-10.svg';

export const ICON_OF_RISE_URL =
  'https://img.alicdn.com/tfs/TB1RAxkGFT7gK0jSZFpXXaTkpXa-12-10.svg';

export const RAM_URL = 'https://ram.console.aliyun.com'; // 权限管理-开通子账号

export const CLUSTER_CHARTS_OF_LINE_TYPE: IControlOpType = {
  0: '集群限流统计（均值）',
  1: '限流比（均值）',
  2: '接口流量环比',
};

export const CLUSTER_CHARTS_OF_CHARTS_TYPE: IControlOpType = {
  0: 'statistics',
  1: 'ratio',
  2: 'ratioQps',
};

export const CLUSTER_CHARTS_OF_AREA_TYPE = [
  {
    title: 'TokenClient 响应类型',
    type: 'req',
  },
  {
    title: 'TokenClient 请求耗时',
    type: 'res',
  },
  {
    title: '分节点限流统计',
    type: 'sub_node',
  },
];

interface IauthName {
  [key: string]: string;
}

export const ALARM_RULES_SPLICE_TYPE:IauthName = {
  QPS: '->',
  RT: '->',
  STATUS: '--',
};

// 权限管理-权限
export const STATISTICS_TYPE: IauthName = {
  PassedQps: '通过流量',
  BlockedQps: '阻塞流量',
  SuccessQps: '成功流量',
  ExceptionQps: '失败流量',
  Rt: '响应时长',
  Thread: '线程',
  Ratio: '限流比',
};

// 权限管理-权限
export const AUTH_NAME: IauthName = {
  0: intl('ahas_sentinel.systemGuard.flowControl.Readandwritepermissions'), // 读写权限
  1: intl('ahas_sentinel.systemGuard.flowControl.Read-onlyAccess'), // 只读权限
  '-1': intl('ahas_sentinel.systemGuard.flowControl.no'), // 无
};

// 节点管理-健康筛选
export const HEALTHY_FILTERS = [
  { label: intl('ahas_sentinel.systemGuard.flowControl.health'), value: 1 }, // 健康
  { label: intl('ahas_sentinel.systemGuard.flowControl.Lostcontact'), value: 0 }, // 失联
];

// 基础设置-防护模式设置-入门/高级
export const BEGINNER_TIPS =
  intl('ahas_sentinel.systemGuard.flowControl.2protection'); // 入门级防护模式 : 防护规则仅支持2条，建议使用高级防护提升系统防护能力。
export const PROFESSIONAL_TIPS =
  intl('ahas_sentinel.systemGuard.flowControl.restrictions'); // 高级防护模式 : 防护规则无限制，有效的规则可提升系统防护能力。

// // 基础设置-开通专业版url
// export const POST_BUY_URL = window.ALIYUN_CONSOLE_CONFIG?.CHANNEL_LINKS?.post_buy ? window.ALIYUN_CONSOLE_CONFIG.CHANNEL_LINKS.post_buy :
//   'http://common-buy.aliyun.com/?commodityCode=ahas_post#/buy';

export const PROTECTION_EVENTS_TYPE = {
  0: intl('ahas_sentinel.systemGuard.flowControl.Clusterpoin'), // 簇点限流
  1: intl('ahas_sentinel.systemGuard.flowControl.Abnormal'), // 簇点异常
  2: intl('ahas_sentinel.systemGuard.flowControl.utilization'), // 集群cpu利用率过高
};

export const MODULE_TYPE: IauthName = {
  0: 'Web',
  1: 'Web',
};

export const FLOW_TYPE: IauthName = {
  0: intl('ahas_sentinel.systemGuard.flowControl.specifiedcontent'), // 返回指定内容
  1: intl('ahas_sentinel.systemGuard.flowControl.specifiedpage'), // 跳转到指定页面
};

export const ACTION_MODULE_TYPE: IauthName = {
  1: 'Web',
  2: 'RPC',
};

export const DEFAULT_RESOURCE_AMOUNT = 6000;
export const DEFAULT_ORIGIN_AMOUNT = 1000;
export const DEFAULT_CONTEXT_AMOUNT = 2000;
export const DEFAULT_STATISTIC_RT = 4900;
export const SUCCESS_MSG = intl('ahas_sentinel.systemGuard.flowControl.configurationsuccessfully'); // 需改配置成功
export const JUMP_URL_NOT_EMPTY = intl('ahas_sentinel.systemGuard.flowControl.redirect'); // 跳转url不可为空
export const STATUS_CODE_NOT_EMPTY = intl('ahas_sentinel.systemGuard.flowControl.empty'); // 状态码不可为空
export const DEFAULT_REQUEST_TIMEOUT = 20;
export const OPERATION_FAILED = intl('ahas_sentinel.systemGuard.flowControl.operationfFailed'); // 操作失败
export const MODIFY_SUCCESS = intl('ahas_sentinel.systemGuard.flowControl.Successfullymodified');
export const MODIFY_ERROR = intl('ahas_sentinel.systemGuard.flowControl.failtoedit'); // 修改失败
export const MSG_TIPS = intl('ahas_sentinel.systemGuard.flowControl.model'); // 00:00-00:15为系统结算期，请勿在此期间更改价格模式。
export const SWITCH_FAILED = intl('ahas_sentinel.systemGuard.flowControl.SwitchFailed'); // 切换失败
export const SWITCH_SUCCESS = intl('ahas_sentinel.systemGuard.flowControl.Switchsuccessfully'); // 切换成功
// 应用防护===================================================================================

export const LANGUAGE_TYPE_ARR = [
  // 语言种类
  {
    title: 'JAVA语言',
    type: 'java',
    value: 0,
  },
  {
    title: 'GO语言',
    type: 'go',
    value: 1,
  },
  {
    title: 'PHP语言',
    type: 'php',
    value: 2,
  },
];

export const ACCESS_JAVA_DATA = [
  // Java 接入方式
  // {
  //   title: 'Agent 接入',
  //   type: 'syringe',
  //   value: 0,
  // },
  {
    title: 'SDK 接入' /* SDK 接入*/,
    type: 'sdk',
    value: 1,
  },
  // {
  //   title: 'K8s 接入' /* K8s 接入*/,
  //   type: 'Kubernetes',
  //   value: 2,
  // },
  // {
  //   title: 'SAE 接入' /* SAE 接入*/,
  //   type: 'sae',
  //   value: 3,
  // },
  {
    title: '体验 Demo' /* 体验 Demo*/,
    type: 'demo',
    value: 4,
  },
];

export const ACCESS_JAVA_DATA_OF_PTS = [
  // pts 嵌入时 Java 接入方式
  {
    title: 'Agent 接入',
    type: 'syringe',
    value: 0,
  },
  {
    title: 'K8s 接入' /* K8s 接入*/,
    type: 'Kubernetes',
    value: 2,
  },
];

export const ACCESS_GO_DATA = [
  // GO 接入方式
  {
    title: 'SDK 接入',
    type: 'go_sdk',
    value: 0,
  },
  {
    title: '体验 Demo' /* 体验 Demo*/,
    type: 'demo',
    value: 1,
  },
];

export const ACCESS_PHP_DATA = [
  // PHP 接入方式
  {
    title: 'SDK 接入',
    type: 'php_sdk',
    value: 0,
  },
];
export const JAVA_SDK_ENV = [
  // JAVA_SDK接入环境
  {
    title: 'Spring Boot 应用接入' /* Spring Boot 应用接入*/,
    type: 'icon-spring-boot',
    value: 0,
  },
  {
    title: 'Spring 应用接入' /* Spring 应用接入*/,
    type: 'Asset',
    value: 1,
  },
  {
    title: 'Dubbo/HSF 应用接入' /* Dubbo/HSF 应用接入*/,
    type: 'dubbo',
    value: 2,
  },
  {
    title: 'Web 应用接入' /* Web 应用接入*/,
    type: 'web',
    value: 3,
  },
  {
    title: '自定义埋点' /* 自定义埋点*/,
    type: 'spot',
    value: 4,
  },
];

export const GO_SDK_ENV = [
  // GO_SDK接入环境
  {
    title: 'Dubbo 应用接入' /* Dubbo 应用接入*/,
    type: 'dubbo',
    value: 0,
  },
  {
    title: 'Gin Web 应用接入' /* Gin Web 应用接入*/,
    type: 'web',
    value: 1,
  },
  {
    title: 'gRPC 应用接入' /* gRPC 应用接入*/,
    type: 'gRPC',
    value: 2,
  },
  {
    title: 'Micro 服务接入' /* gRPC 应用接入*/,
    type: 'micro',
    value: 3,
  },
  {
    title: '自定义埋点' /* 自定义埋点*/,
    type: 'spot',
    value: 4,
  },
];

export const PHP_SDK_ENV = [
  // PHP_SDK接入环境
  {
    title: '自定义埋点' /* 自定义埋点*/,
    type: 'spot',
    value: 0,
  },
];

export const ACCESS_DATA = [
  {
    name: 'Spring Boot 应用接入',
    value: 'Spring-Boot',
  },
  {
    name: 'Spring 应用接入',
    value: 'Spring',
  },
  {
    name: 'Dubbo 应用接入',
    value: 'Dubbo',
  },
  {
    name: 'Web 应用接入',
    value: 'Web',
  },
  {
    name: '自定义埋点',
    value: 'urying-point',
  },
];

export const BUTYING_POINT = [
  {
    title: 'HTTP 接口埋点',
  },
  {
    title: 'MyBatis SQL埋点',
  },
  {
    title: '普通接口埋点',
  },
];

export const DOWNLOAD_GO_LINUX_DEMO_URL =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sdk/go/demo/ahas_sentinel_go_demo_linux'; // 下载 Go demo Linux 版压缩包
export const DOWNLOAD_GO_MACOS_DEMO_URL =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sdk/go/demo/ahas_sentinel_go_demo_macos'; // 下载 Go demo macOS 版压缩包
export const agentInstallSh =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/agent/prod/latest/ahas-agent.sh';
export const AHAS_JAVA_AGENT_URL =
  'https://help.aliyun.com/document_detail/128800.html'; // AHAS Java Agent 支持列表
export const DOWNLOAD_GO_SDK_URL =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sdk/go/latest/aliyun-ahas-go-sdk.zip'; // 下载 AHAS Go SDK 压缩包
export const API_DETAILS_URL =
  'https://help.aliyun.com/document_detail/154664.html'; // API详情参考文档
export const AHAS_SPRING_BOOT_URL =
  'https://help.aliyun.com/document_detail/102555.html#title-jsk-jqr-r5b'; // Spring Boot应用接入-普通接口埋点-帮助文档
export const AUTO_RETRY_DOSC_URL = 'https://help.aliyun.com/document_detail/102559.html'; // Java Sdk 接入-自定义埋点-自动重试规则文档
export const AHAS_JAVA_SDK_DUBBO_ADAPTER_URL = 'https://help.aliyun.com/document_detail/102555.html?spm=a2c4g.11186623.2.14.353c3a73TDLXTK#section-rgg-4vj-kgb'; // Dubbo Adapter 帮助文档
export const AHAS_CUSTOMIZE_URL =
  'https://help.aliyun.com/document_detail/110601.html'; // 添加埋点帮助文档
export const FULL_SCREEN_OFF =
  'https://img.alicdn.com/tfs/TB1FSXLkxv1gK0jSZFFXXb0sXXa-64-64.png';
export const FULL_SCREEN_ON =
  'https://img.alicdn.com/tfs/TB1aS4wkET1gK0jSZFrXXcNCXXa-64-64.png';
export const DOWNLOAD_PHP_SDK_URL =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sidecar/0.6/ahas-sentinel-sidecar-linux.tar.gz'; // 下载 AHAS PHP SDK 压缩包
export const AHAS_INSTALL_K8S_URL = 'https://cs.console.aliyun.com/index2#/k8s/catalog/detail/incubator_ack-ahas-sentinel-pilot'; // 安装k8s插件链接

// 规则管理

interface IControlOpType {
  [key: string]: string;
}

export const ALARM_LEVEL: IControlOpType = {
  INFO: '通知',
  WARN: '告警',
  FATAL: '严重',
};

export const ALARM_RULRS_CONDITION_DO: IControlOpType = {
  'system.cpu.total': 'CPU资源平均使用率',
  'system.mem.used': '内存资源平均使用率',
  'system.disk.partition.used': '磁盘资源平均使用率',
  'system.load.1min': '系统1min平均负载',
  'jvm.gc.old.count': '老年代GC平均次数',
  'jvm.gc.old.time': '老年代GC平均时长',
  'jvm.gc.young.count': '年轻代GC平均次数',
  'jvm.gc.young.time': '年轻代GC平均时长',
  'status.3xx': '状态为 3xx 的接口平均请求数',
  'status.4xx': '状态为 4xx 的接口平均请求数',
  'status.5xx': '状态为 5xx 的接口平均请求数',

  'qps.exceptionMax': '异常流量最大值',
  'qps.exceptionMin': '异常流量最小值',
  'qps.exceptionAvg': '异常流量平均值',
  // 'qps.exceptionStd': '异常流量方差',
  'qps.exceptionP99': '异常流量P99分位值',
  'qps.exceptionP95': '异常流量P95分位值',
  'qps.exceptionP75': '异常流量P75分位值',
  'qps.blockedMax': '阻塞流量最大值',
  'qps.blockedMin': '阻塞流量最小值',
  'qps.blockedAvg': '阻塞流量平均值',
  // 'qps.blockedStd': '阻塞流量方差',
  'qps.blockedP99': '阻塞流量P99分位值',
  'qps.blockedP95': '阻塞流量P95分位值',
  'qps.blockedP75': '阻塞流量P75分位值',

  'rt.max': '接口耗时最大值',
  'rt.min': '接口耗时最小值',
  'rt.avg': '接口耗时平均值',
  // 'rt.std': '接口耗时方差',
  'rt.p99': '接口耗时99分位值',
  'rt.p95': '接口耗时95分位值',
  'rt.p75': '接口耗时75分位值',
};

export const ALARM_SYSTEM_RULRS_ITEM = [
  {
    type: 'system.cpu.total',
    name: 'CPU资源平均使用率',
  },
  {
    type: 'system.mem.used',
    name: '内存资源平均使用率',
  },
  {
    type: 'system.disk.partition.used',
    name: '磁盘资源平均使用率',
  },
  {
    type: 'system.load.1min',
    name: '系统1min平均负载',
  },
  {
    type: 'jvm.gc.old.count',
    name: '老年代GC平均次数',
  },
  {
    type: 'jvm.gc.old.time',
    name: '老年代GC平均时长',
  },
  {
    type: 'jvm.gc.young.count',
    name: '年轻代GC平均次数',
  },
  {
    type: 'jvm.gc.young.time',
    name: '年轻代GC平均时长',
  },
];

export const ALARM_STATUS_RULRS_ITEM = [
  {
    type: 'status.3xx',
    name: '状态为 3xx 的接口平均请求数',
  },
  {
    type: 'status.4xx',
    name: '状态为 4xx 的接口平均请求数',
  },
  {
    type: 'status.5xx',
    name: '状态为 5xx 的接口平均请求数',
  },
];

export const ALARM_QPS_RULRS_ITEM = [
  {
    type: 'qps.exceptionMax',
    name: '异常流量最大值',
  },
  {
    type: 'qps.exceptionMin',
    name: '异常流量最小值',
  },
  {
    type: 'qps.exceptionAvg',
    name: '异常流量平均值',
  },
  // {
  //   type: 'qps.exceptionStd',
  //   name: '异常流量方差',
  // },
  {
    type: 'qps.exceptionP99',
    name: '异常流量P99分位值',
  },
  {
    type: 'qps.exceptionP95',
    name: '异常流量P95分位值',
  },
  {
    type: 'qps.exceptionP75',
    name: '异常流量P75分位值',
  },
  {
    type: 'qps.blockedMax',
    name: '阻塞流量最大值',
  },
  {
    type: 'qps.blockedMin',
    name: '阻塞流量最小值',
  },
  {
    type: 'qps.blockedAvg',
    name: '阻塞流量平均值',
  },
  // {
  //   type: 'qps.blockedStd',
  //   name: '阻塞流量方差',
  // },
  {
    type: 'qps.blockedP99',
    name: '阻塞流量P99分位值',
  },
  {
    type: 'qps.blockedP95',
    name: '阻塞流量P95分位值',
  },
  {
    type: 'qps.blockedP75',
    name: '阻塞流量P75分位值',
  },
];

export const ALARM_RT_RULRS_ITEM = [
  {
    type: 'rt.max',
    name: '接口耗时最大值',
  },
  {
    type: 'rt.min',
    name: '接口耗时最小值',
  },
  {
    type: 'rt.avg',
    name: '接口耗时平均值',
  },
  // {
  //   type: 'rt.std',
  //   name: '接口耗时方差',
  // },
  {
    type: 'rt.p99',
    name: '接口耗时99分位值',
  },
  {
    type: 'rt.p95',
    name: '接口耗时95分位值',
  },
  {
    type: 'rt.p75',
    name: '接口耗时75分位值',
  },
];

export const ALARM_SYSTEM_RELATIONSHIP = [
  {
    type: '>',
    name: '>',
  },
  {
    type: '=',
    name: '=',
  },
  {
    type: '<',
    name: '<',
  },
  {
    type: '>=',
    name: '>=',
  },
  {
    type: '<=',
    name: '<=',
  },
  {
    type: '!=',
    name: '!=',
  },
];

export const shGRADE_TYPE = {
  0: intl('ahas_sentinel.systemGuard.flowControl.Threads'), // 线程数
  1: 'QPS',
};

export const CONTROL_TYPE = {
  0: intl('ahas_sentinel.systemGuard.flowControl.FailFast'), // 快速失败
  2: intl('ahas_sentinel.systemGuard.flowControl.Waitinginline'), // 排队等待
};

export const OP_TYPE: IControlOpType = {
  ADD: intl('ahas_sentinel.systemGuard.flowControl.Add'), // 新增
  MODIFY: intl('ahas_sentinel.systemGuard.flowControl.modify'), // 修改
  DELETE: intl('ahas_sentinel.systemGuard.flowControl.delete'), // 删除
  ON: intl('ahas_sentinel.systemGuard.flowControl.Turnon'), // 开启
  BATCH_ON: intl('ahas_sentinel.systemGuard.flowControl.Turnon'), // 开启
  OFF: intl('ahas_sentinel.systemGuard.flowControl.shutdown'), // 关闭
  BATCH_OFF: intl('ahas_sentinel.systemGuard.flowControl.shutdown'), // 关闭
  ADD_ITEM: intl('ahas_sentinel.systemGuard.flowControl.Addexception'), // 添加例外项
  CHANGE_OFF: intl('ahas_sentinel.systemGuard.flowControl.Schemeswitching'), // 方案切换
  BIND: '绑定',
  UNBIND: '解绑',
};

export const RULE_TYPE: IControlOpType = {
  FLOW: intl('ahas_sentinel.systemGuard.flowControl.InterfaceFlowcontrol'), // 接口流控
  DEGRADE: intl('ahas_sentinel.systemGuard.flowControl.Fuserules'), // 熔断规则
  SYSTEM: intl('ahas_sentinel.systemGuard.flowControl.Systemrules'), // 系统规则
  ADAPTER_SETTING: intl('ahas_sentinel.systemGuard.flowControl.Generalconfiguration'), // 通用配置
  GENERAL_SETTING: intl('ahas_sentinel.systemGuard.flowControl.Generalconfiguration'), // 通用配置
  PARAM_FLOW: intl('ahas_sentinel.systemGuard.flowControl.HotspotParameterProtection'), // 热点参数防护（RPC）
  CLUSTER_CLIENT_SETTING: intl('ahas_sentinel.systemGuard.flowControl.TokenClientConfiguration'), // Token Client 配置
  ADAPTIVE_FLOW_SETTING: intl('ahas_sentinel.systemGuard.flowControl.AdaptiveFlowControl'), // 自适应流控
  GATEWAY_API_DEFINITION: intl('ahas_sentinel.systemGuard.flowControl.Gateway'), // 网关
  ALL_RULES: intl('ahas_sentinel.systemGuard.flowControl.Allruless'), // 全部规则
  RETRY: intl('ahas_sentinel.systemGuard.flowControl.Automaticretryrules'), // 自动重试规则
  HTTP_API_MATCH: intl('ahas_sentinel.systemGuard.flowControl.ApiRules'), // API规则
  BLOCK_FALLBACK_DEFINITION: intl('ahas_sentinel.systemGuard.flowControl.fallbackbehavior'), // fallback 行为
  MANUAL_DEGRADE: intl('ahas_sentinel.systemGuard.flowControl.ActiveDemotion'), // 主动降级
  APP_TS_CLUSTER: intl('ahas_sentinel.systemGuard.flowControl.Clusterprotectionsettings'), // 集群防护设置
  GATEWAY_FLOW: intl('ahas_sentinel.systemGuardGw.SystemOperationLog.GatewayFlowControlRules'), // 网关流控规则
  BLOCK_FALLBACK_BIND: intl('ahas_sentinel.systemGuard.FuseRules.relatedBehavior'),
  DEFAULT_CIRCUIT_BREAKER: intl('ahas_sentinel.systemGuard.flowControl.FuseDefaultrules'),
  WEB_FLOW: intl('mse.apiDetail.WebFlowRule'),
};

export const FLOW_RULE = 'https://help.aliyun.com/document_detail/421958.html';
export const NGINX_FLOW_RULE = 'https://help.aliyun.com/document_detail/200920.html';
export const QUARA_RULE = 'https://help.aliyun.com/document_detail/421959.html';
export const LEVE_RULE = 'https://help.aliyun.com/document_detail/200919.html';
export const FUSE_RULE = 'https://help.aliyun.com/document_detail/421960.html';
export const STSTEM_RULE =
  'https://help.aliyun.com/document_detail/101079.html';
export const HOTS_RULE = 'https://help.aliyun.com/document_detail/421964.html';
export const HTTP_RULE = 'https://help.aliyun.com/document_detail/421971.html?spm=a2c4g.429556.0.0.374f30d5sinDJ7';
export const RETRY_RULES_URL = 'https://help.aliyun.com/document_detail/194976.html';
export const APACHE_HTTP_CLIENT = 'https://help.aliyun.com/document_detail/195443.html';
export const AHAS_USE_GUIDELINES_URL = 'https://help.aliyun.com/document_detail/144439.html'; // ahas 使用指引文档地址
export const GATEWAY_FLOW_RULE_URL = 'https://help.aliyun.com/document_detail/118482.html'; // API 流控规则文档

export const dialogFlowTips =
   intl('ahas_sentinel.systemGuard.flowControl.dia1'); // '流量控制会监控应用实时的 QPS ，当达到指定的阈值时控制流量，以避免被瞬时的流量高峰冲垮.';
export const dialogIsolateTips =
  intl('ahas_sentinel.systemGuard.flowControl.dia2'); // '隔离规则会监控应用实时调用的线程数，当达到指定的阈值时控制流量，通过隔离有问题的接口，避免系统资源占用过多影响全局可用性。';
export const FLOW_URL =
  'https://help.aliyun.com/document_detail/421958.html';
export const DOWNG_CONTENT =
  intl('ahas_sentinel.systemGuard.flowControl.dia3'); // '熔断规则会在调用链路中某个资源出现不稳定时（例如 Timeout或异常比例升高），对这个资源的调用进行限制，让请求快速失败，避免影响到其它的资源而导致级联错误。Sentinel 熔断规则支持两种策略：单位时间内的慢调用比例和异常比例。';
export const DOWNG_URL = 'https://help.aliyun.com/document_detail/101078.html';
export const MANUAL_DOWNG_CONTENT =
  intl('ahas_sentinel.systemGuard.flowControl.dia4'); // '主动降级规则可以针对某些接口的全部请求进行降级，执行自定义的降级行为。';
export const MANUAL_DOWNG_URL = 'https://help.aliyun.com/document_detail/201862.html';
export const SYSTEM_CON_A =
  intl('ahas_sentinel.systemGuard.flowControl.dia5'); // '系统保护规则可以从系统指标维度来进行流量控制，如系统的整体 QPS、RT、负载等。';
export const SYSTEM_CON_B =
  intl('ahas_sentinel.systemGuard.flowControl.dia6'); // '注意：系统规则只针对入口资源生效，且每种相同类型的系统保护规则最多只能存在一条。';
export const SYSTEM_CON_C =
  intl('ahas_sentinel.systemGuard.flowControl.dia7'); // '注意：Load 模式会在当前系统 load1超过阈值，且系统当前的并发线程数超过系统的容量（maxQps * minRt)时才会触发系统保护。';
export const SYSTEM_URL = 'https://help.aliyun.com/document_detail/101079.html';
export const BEHAVIOR_CONTENT =
  intl('ahas_sentinel.systemGuard.flowControl.dia8'); // 'Fallback 行为定义某种埋点资源类型触发了某种规则（如流控、熔断、降级）后的处理行为。';
export const BEHAVIOR_URL = 'https://help.aliyun.com/document_detail/201863.html';
export const SPRINGCLOUD_STRESS_URL = 'https://help.aliyun.com/document_detail/199525.html';
export const DUBBO_STRESS_URL = 'https://help.aliyun.com/document_detail/199524.html';

export const gradeFilters = [
  { label: 'QPS', value: 1 },
  {
    label: intl('ahas_sentinel.systemGuard.flowControl.Threads'), // 线程数,
    value: 0,
  },
];

export const controlFilters = [
  {
    label: intl('ahas_sentinel.systemGuard.flowControl.FailFast'), // 快速失败,
    value: 0,
  },
  {
    label: intl('ahas_sentinel.systemGuard.flowControl.Waitinginline'), // 排队等待,
    value: 2,
  },
];
export const enableFilters = [
  { label: intl('ahas_sentinel.systemGuard.flowControl.Turnon'), value: 1 },
  { label: intl('ahas_sentinel.systemGuard.flowControl.shutdown'), value: 0 },
];

export const thresholdTypeFilters = [
  { label: intl('ahas_sentinel.systemGuard.flowControl.Standalone'), value: 0 }, // 单机
  { label: intl('ahas_sentinel.systemGuard.flowControl.Clusteroverall'), value: 1 }, // 集群总体
  { label: intl('ahas_sentinel.systemGuard.flowControl.ClusterAmortization'), value: 2 }, // 集群均摊
];

// 应用概述

export const SUMMARY_TAB_DEFAULT = [
  { key: 'passedQps', content: intl('ahas_sentinel.systemGuard.flowControl.ViaQPS') },
  { key: 'blockedQps', content: intl('ahas_sentinel.systemGuard.flowControl.FlowControlQPS') }, // 流控QPS
  { key: 'exceptionQps', content: intl('ahas_sentinel.systemGuard.flowControl.AbnormalQPS') },
  { key: 'rt', content: intl('ahas_sentinel.systemGuard.flowControl.AverageRT') }, // 平均RT
];

export const SUMMARY_TAB_TOP = [
  { key: 'passedQps', content: intl('ahas_sentinel.systemGuard.flowControl.PassQPSTOP') }, // 通过QPS TOP'
  { key: 'blockedQps', content: intl('ahas_sentinel.systemGuard.flowControl.BlockQPSTOP') }, // 防护拒绝QPS TOP'
  { key: 'rt', content: intl('ahas_sentinel.systemGuard.flowControl.AverageRTTOP') }, // 平均RT TOP
];

interface IMapObject {
  [index: string]: string;
}

export const THERMODYNAMIC_CHART_KEY_DATA: IMapObject = {
  passedQps: intl('ahas_sentinel.systemGuard.flowControl.ViaQPS'), // 通过QPS
  rt: intl('ahas_sentinel.systemGuard.flowControl.AverageRt'), // 平均Rt
  blockedQps: intl('ahas_sentinel.systemGuard.flowControl.FlowControlQPS'), // 流控QPS
  exceptionQps: intl('ahas_sentinel.systemGuard.flowControl.AbnormalQPS'), // 异常QPS,
  totalQps: intl('ahas_sentinel.systemGuard.flowControl.TotalQPS'), // 总QPS
  thread: intl('ahas_sentinel.systemGuard.flowControl.Concurrents'), // 并发,
  cpu: 'CPU',
  load: 'Load',
};

export const CHART_TYPE: IMapObject = {
  passQps: intl('ahas_sentinel.systemGuard.flowControl.ViaQPS'), // 通过QPS
  flowRuleQPS: '限流触发',
  degradeRuleQPS: '熔断触发',
  systemRuleQPS: '系统保护触发',
  paramRuleQPS: '热点参数触发',
  manualDegradeRuleQPS: '主动降级触发',
  blockedQps: intl('ahas_sentinel.systemGuard.flowControl.RejectQPS'), // 拒绝QPS,,
  exceptionQps: intl('ahas_sentinel.systemGuard.flowControl.AbnormalQPS'), // 异常QPS,
  rt: 'RT(ms)',
  thread: intl('ahas_sentinel.systemGuard.flowControl.Concurrents'), // 并发,
  cpu: 'CPU',
  load: 'Load',
};
export const CHART_CONTRAST_TYPE: IMapObject = {
  passQps: intl('ahas_sentinel.systemGuard.flowControl.PassQPSyear-on-year'), // 同比通过QPS
  flowRuleQPS: '限流触发',
  degradeRuleQPS: '熔断触发',
  systemRuleQPS: '系统保护触发',
  paramRuleQPS: '热点参数触发',
  manualDegradeRuleQPS: '主动降级触发',
  blockedQps: intl('ahas_sentinel.systemGuard.flowControl.RejectQPSyear-on-year'), // 同比拒绝QPS
  exceptionQps: intl('ahas_sentinel.systemGuard.flowControl.Year-on-yearabnormalQPS'), // 同比异常QPS
  rt: intl('ahas_sentinel.systemGuard.flowControl.YoYRT'), // 同比RT(ms)
  thread: intl('ahas_sentinel.systemGuard.flowControl.Concurrencyyear-on-year'), // 同比并发
  cpu: intl('ahas_sentinel.systemGuard.flowControl.YoYCPU'), // 同比CPU
  load: intl('ahas_sentinel.systemGuard.flowControl.Year-on-yearLoad'), // 同比Load
};

export const CHART_COUNT: IMapObject = {
  passQps: 'passedQps',
  flowRuleQPS: 'flowRuleQPS',
  degradeRuleQPS: 'degradeRuleQPS',
  systemRuleQPS: 'systemRuleQPS',
  paramRuleQPS: 'paramRuleQPS',
  manualDegradeRuleQPS: 'manualDegradeRuleQPS',
  blockedQps: 'blockedQps',
  exceptionQps: 'exception',
  rt: 'rt',
  thread: 'thread',
  cpu: 'passedQps',
  load: 'passedQps',
};

export const API_NAME_MAP: IMapObject = {
  __total_inbound_traffic__: intl('ahas_sentinel.systemGuard.flowControl.ClusterQPS'), // 集群 QPS
  __cpu_usage__: intl('ahas_sentinel.systemGuard.flowControl.ClusteraverageCPU'), // 集群平均 CPU
  __system_load__: intl('ahas_sentinel.systemGuard.flowControl.Clusteraverageload'), // 集群平均 load
  pass_qps: intl('ahas_sentinel.systemGuard.flowControl.ViaQPSTop'), // 通过QPS Top
  block_qps: intl('ahas_sentinel.systemGuard.flowControl.CurrentlimitQPSTop'), // 限流QPS Top
  exception_qps: intl('ahas_sentinel.systemGuard.flowControl.AbnormalQPSTop'), // 异常QPS Top
  _rt: intl('ahas_sentinel.systemGuard.flowControl.AverageRTTop'), // 平均RT Top
  _cpu: 'CPU Top',
  _load: 'LOAD Top',
};

// 概览页-系统负载
export const SYSTEM_LOAD_LIST = ['system_cpu', 'system_memory', 'system_load'];

// 定义接口详情页引导步骤文案
export const API_DETAILS_STEPS_TIPS = [
  {
    element: '.next-menu-content',
    content: "<p style='color: #7b7b7b; font-size: 16px; font-weight: bold;'>监控细分，数据更全面</p><p style='color: #7b7b7b; margin: 1px;'>原“监控详情”拆分为<span style='color: #0070CC;'>接口详情</span>与<span style='color: #0070CC;'>节点详情</span>两个维度，簇点链路合并到节点详情中</p>",
    position: 'right',
  },
  {
    element: '#api_deatils_show_type',
    content: '<p style="color: #7b7b7b; font-size: 16px; font-weight: bold;">调用统计转到这里啦</p><p style="color: #7b7b7b;">切换到<span style="color: #0070CC;">“统计模式”</span>即可查看指定日期的接口统计信息，同时增加峰值统计信息。</p>',
  },
];

// 定义应用概览页引导步骤文案
export const SUMMARY_PAGE_STEPS_TIPS = [
  {
    element: '#summary_page_show_dashboard',
    content: "<p style='color: #7b7b7b; font-size: 16px; font-weight: bold;'>全新维度，数据更直观</p><p style='color: #7b7b7b; margin: 1px;'>从<span style='color: #0070CC;'>业务流量</span>、<span style='color: #0070CC;'>应用性能</span>、<span style='color: #0070CC;'>系统负载</span>维度展示数据</p>",
  },
  // {
  //   element: '#summary_page_show_node',
  //   content: "<p style='color: #7b7b7b; font-size: 16px; font-weight: bold;'>节点分位，数据更详细</p><p style='color: #7b7b7b; margin: 1px;'>展示不同统计指标的节点分位信息</p>",
  //   position: 'top',
  // },
];

export const CLUSTRER_GEARLEVEL = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.beginnerlevel'), // 入门级
    descQps: '0 ～ 10000',
    descCount: '0 ～ 5000',
    value: 1,
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.primary'), // 初级
    descQps: '10000 ～ 20000',
    descCount: '5000 ～ 15000',
    value: 2,
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.intermediate'), // 中级
    descQps: '20000 ～ 30000',
    descCount: '15000 ～ 25000',
    value: 3,
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.advanced'), // 高级
    descQps: '30000 ～ 40000',
    descCount: '25000 ～ 35000',
    value: 4,
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.Professionallevel'), // 专业级
    descQps: '40000 ～ 50000',
    descCount: '35000 ～ 45000',
    value: 5,
  },
];

// 接口详情-导出接口详情文案
export const EXPORT_API_TIPS = [
  {
    type: 'pdf',
    title: intl('ahas_sentinel.systemGuard.flowControl.PDFversion'), // 接口详情报告 PDF 版
    desc: intl('ahas_sentinel.systemGuard.flowControl.Trafficprotection'), // 流量防护
    iconName: 'icon-PDF',
  },
  {
    type: 'csv',
    title: intl('ahas_sentinel.systemGuard.flowControl.CSVversion'), // 接口详情报告 CSV 版
    desc: intl('ahas_sentinel.systemGuard.flowControl.InterfaceDetail'), // 接口详情报告导出
    iconName: 'icon-csv',
  },
];

// 集群流控管理后台-server 类型
export const SERVER_TYPE_LIST: IControlOpType = {
  0: '普通', // 普通
  1: 'Mesh',
};

// 集群流控状态
export const CLISTER_STATUS: IControlOpType = {
  0: '待调度', // 待调度
  1: '资源分配中', // 资源分配中
  2: '资源分配完成', // 资源分配完成
  5: '分配异常', // 分配异常
};

// 规则管理tab
export const RULES_SET_TAB_ITEM:IMapObject = {
  FLOW: intl('ahas_sentinel.systemGuard.flowControl.InterfaceFlowcontrol'), // 接口流控
  quarantine: intl('ahas_sentinel.systemGuard.flowControl.ConcurrentIsolation'), // '并发隔离',
  downGrade: intl('ahas_sentinel.systemGuard.flowControl.Fuserules'), // 熔断规则,
  activeDemote: intl('ahas_sentinel.systemGuard.flowControl.ActiveDemotion'), // 主动降级,
  system: intl('ahas_sentinel.systemGuard.flowControl.AdaptiveFlowControl'), // 自适应流控,
  hotSpot: intl('ahas_sentinel.systemGuard.flowControl.HotspotParameterProtection'), // 热点参数防护（RPC）,
  autoRetry: intl('ahas_sentinel.systemGuard.flowControl.Automaticretryrules'), // 自动重试规则,
  apiGwFlow: intl('mse.apiDetail.gatewayRule'),
};

// 机器监控-主机监控类型
export const HOST_LIST = ['system_cpu', 'system_memory', 'system_disk', 'system_load', 'system_network', 'system_network_data_pack'];

// 机器监控-主机监控类型
export const HOST_LIST_TITLE: IauthName = {
  system_cpu: 'CPU（%）',
  system_memory: intl('ahas_sentinel.systemGuard.flowControl.physicalMemory'), // '物理内存（G）',
  system_disk: intl('ahas_sentinel.systemGuard.FuseRules.tenseconds'), // Disk/每十秒
  system_load: 'Load',
  system_network: intl('ahas_sentinel.systemGuard.FuseRules.Byte'),
  // system_network: intl('ahas_sentinel.systemGuard.FuseRules.Byte'), // 网络流量（Byte）/每十秒
  system_network_data_pack: intl('ahas_sentinel.systemGuard.FuseRules.Network'), // 网络数据包（个）/每分钟
};

// 接口详情-分类tab
export const API_DETAILS_TAB_ITEM = [
  {
    title: '接口压测',
    key: 4,
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.Interfaceoverview'), // 接口概览
    key: 0,
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.NodeDetails'), // 节点详情
    key: 1,
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.InterfaceFlowcontrol'), // 接口流控
    key: 6,
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.ConcurrentIsolation'), // 并发隔离
    key: 7,
  },
  {
    title: intl('mse.apiDetail.HotspotParameterProtection.HTTP'), // 热点参数防护（HTTP 请求）
    key: 5,
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.HotspotParameterProtection'), // 热点参数防护（RPC）
    key: 9,
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.ServiceFuse'), // 服务熔断
    key: 8,
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.StatusStatistics'), // 状态统计
    key: 2,
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.ExceptionStatistics'), // 异常统计
    key: 3,
  },
];

// 机器监控-JVM监控类型
export const JVM_LIST = ['jvm_gc', 'jvm_gc_time', 'jvm_thread_count'];

// 机器监控-JVM监控图表标题
export const JVM_CHARTS_TITLE: IMapObject = {
  jvm_gc: intl('ahas_sentinel.systemGuard.flowControl.GCtimes'), // GC次数,
  jvm_gc_time: intl('ahas_sentinel.systemGuard.FuseRules.GCtimems'), // 'GC耗时 / ms',
  jvm_thread_count: intl('ahas_sentinel.systemGuard.flowControl.NumberofJVMthreads'), // JVM线程数
};

// 机器监控-主机监控-cpu_tab
export const CPU_ITEM_TAB = [
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.user'), // 用户
    val: 'system.cpu.user',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.system'), // 用户
    val: 'system.cpu.system',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.Wait'), // 等待IO完成
    val: 'system.cpu.iowait',
  },
];

// 机器监控-主机监控-物理内存tab
export const MEMORY_ITEM_TAB = [
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.SystemFreeMemory'), // 系统空闲内存
    val: 'system.mem.free',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.systemhas'), // 系统已经使用内存
    val: 'system.mem.used',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.PageCache'), // 系统PageCache内存数
    val: 'system.mem.cached',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.BufferCache'), // 系统BufferCache内存数
    val: 'system.mem.buffers',
  },
];

// 机器监控-主机监控-Disk_tab
export const DISK_ITEM_TAB = [
  {
    title: intl('mse.apiDetail.diskFree'),
    val: 'system.disk.partition.free',
  },
  {
    title: intl('mse.apiDetail.diskTotal'),
    val: 'system.disk.partition.total',
  },
];

// 机器监控-主机监控-Load_tab
export const LOAD_ITEM_TAB = [
  {
    title: 'Load',
    val: 'system.load.1min',
  },
];

// 机器监控-主机监控-网络流量_tab
export const NETWORK_ITEM_TAB = [
  {
    title: intl('mse.appOverview.networkReceivedTrafficSize'),
    val: 'system.net.in.bytes',
  },
  {
    title: intl('mse.appOverview.networkSendTrafficSize'),
    val: 'system.net.out.bytes',
  },
];

// 机器监控-主机监控-网络数据包_tab
export const NETWORK_DATA_PACK_ITEM_TAB = [
  {
    title: intl('mse.appOverview.messagesReceivedNum'),
    val: 'system.net.in.packets',
  },
  {
    title: intl('mse.appOverview.messagesSendNum'),
    val: 'system.net.out.packets',
  },
  {
    title: intl('mse.appOverview.errorsReceivedNum'),
    val: 'system.net.in.errs',
  },
  {
    title: intl('mse.appOverview.packetsDroppedNum'),
    val: 'system.net.in.dropped',
  },
];

// 机器监控-jvm监控-jvm_gc
export const GC_ITEM_TAB = [
  {
    title: intl('mse.appOverview.younggctimes'),
    val: 'jvm.gc.young.count',
  },
  {
    title: intl('mse.appOverview.fullGCtimes'),
    val: 'jvm.gc.old.count',
  },
];

// 机器监控-jvm监控-jvm_gc_time
export const GC_TIME_ITEM_TAB = [
  {
    title: intl('mse.appOverview.younggctime'),
    val: 'jvm.gc.young.time',
  },
  {
    title: intl('mse.appOverview.fullGCtime'),
    val: 'jvm.gc.old.time',
  },
];


// 机器监控-jvm监控-jvm_thread_count
export const THREAD_COUNT_ITEM_TAB = [
  {
    title: intl('mse.machine.jvmBlocked'),
    val: 'jvm.thread.blocked.count',
  },
  {
    title: intl('mse.machine.jvmDeadlock'),
    val: 'jvm.thread.deadlock.count',
  },
  {
    title: intl('mse.machine.jvmNew'),
    val: 'jvm.thread.new.count',
  },
  {
    title: intl('mse.machine.jvmRunnable'),
    val: 'jvm.thread.runnable.count',
  },
  {
    title: intl('mse.machine.jvmTerminated'),
    val: 'jvm.thread.terminated.count',
  },
  {
    title: intl('mse.machine.jvmTimed_waiting'),
    val: 'jvm.thread.timed_waiting.count',
  },
  {
    title: intl('mse.machine.jvmWaiting'),
    val: 'jvm.thread.waiting.count',
  },
  {
    title: intl('mse.machine.jvmAllcount'),
    val: 'jvm.thread.count',
  },
];

interface IHostOfTabItem {
  title: string;
  val: string;
}
interface IHostOfTab {
  [key: string]: IHostOfTabItem[];
}

export const HOST_OF_DETAIL_TAB: IHostOfTab = {
  system_cpu: CPU_ITEM_TAB,
  system_memory: MEMORY_ITEM_TAB,
  system_disk: DISK_ITEM_TAB,
  system_load: LOAD_ITEM_TAB,
  system_network: NETWORK_ITEM_TAB,
  system_network_data_pack: NETWORK_DATA_PACK_ITEM_TAB,
  cpu: CPU_ITEM_TAB,
  load: LOAD_ITEM_TAB,
  jvm_gc: GC_ITEM_TAB,
  jvm_gc_time: GC_TIME_ITEM_TAB,
  jvm_thread_count: THREAD_COUNT_ITEM_TAB,
};

// 指标详情默认选中tab
export const SUB_SELECTE_DEFAULT_TAB: IauthName = {
  system_cpu: 'system.cpu.user',
  system_memory: 'system.mem.free',
  system_disk: 'system.disk.partition.free',
  system_load: 'system.load.1min',
  system_network: 'system.net.in.bytes',
  system_network_data_pack: 'system.net.in.packets',
  cpu: 'system.cpu.user',
  load: 'system.load.1min',
  jvm_gc: 'jvm.gc.young.count',
  jvm_gc_time: 'jvm.gc.young.time',
  jvm_heap: 'jvm.mem.pools.eden_space.used',
  jvm_none_heap: 'jvm.mem.non_heap.committed',
  jvm_meta_space: 'jvm.mem.pools.metaspace.used',
  jvm_thread_count: 'jvm.thread.blocked.count',
};

// 校验charts传入数据类别
export const DATA_OF_CHARTS_SHOW: IauthName = {
  // cpu 相关
  'system.cpu.total': intl('mse.apiDetail.diskTotal'),
  'system.cpu.iowait': intl('mse.appOverview.waitIoCpuUsed'),
  'system.cpu.user': intl('mse.appOverview.useCpuUsed'),
  'system.cpu.system': intl('mse.appOverview.sysCpuUsed'),
  // load
  'system.load.1min': 'Load',
  // 物理内存相关
  'system.mem.total': intl('mse.apiDetail.diskTotal'),
  'system.mem.free': intl('ahas_sentinel.systemGuard.FuseRules.sysFree'),
  'system.mem.used': intl('ahas_sentinel.systemGuard.FuseRules.usedMemory'),
  'system.mem.cached': intl('ahas_sentinel.systemGuard.FuseRules.PageCache'),
  'system.mem.buffers': intl('ahas_sentinel.systemGuard.FuseRules.BufferCache'),
  // Network 相关
  'system.net.in.bytes': intl('mse.appOverview.networkReceivedTrafficSize'),
  'system.net.out.bytes': intl('mse.appOverview.networkSendTrafficSize'),
  'system.net.in.packets': intl('mse.appOverview.messagesReceivedNum'),
  'system.net.out.packets': intl('ahas_sentinel.systemGuard.FuseRules.packets'),
  'system.net.in.errs': intl('ahas_sentinel.systemGuard.FuseRules.NumberOfErrorsReceived'),
  'system.net.in.dropped': intl('mse.appOverview.packetsDroppedNum'),
  // Disk 相关
  'system.disk.partition.total': intl('mse.apiDetail.diskTotal'),
  'system.disk.partition.free': intl('mse.apiDetail.diskFree'),
  'system.disk.partition.used': intl('mse.apiDetail.diskUsed'),
  // jvm堆内存 相关
  'jvm.mem.heap.used': intl('mse.appOverview.useSum'),
  'jvm.mem.pools.old_gen.used': intl('mse.appOverview.oldage'),
  'jvm.mem.pools.survivor_space.used': intl('mse.appOverview.youngSurvivorDistrict'),
  'jvm.mem.pools.eden_space.used': intl('mse.appOverview.youngGenerationEdenDistrict'),

  // jvm非堆内存 相关
  'jvm.mem.non_heap.committed': intl('mse.appOverview.nonHeapMemoryCommitBytes'),
  'jvm.mem.non_heap.init': intl('mse.appOverview.numberOfBytesInHeapMemory'),
  'jvm.mem.non_heap.used': intl('mse.appOverview.numberOfBytesUsedInNonHeapMemory'),

  // jvm元空间 相关
  'jvm.mem.pools.metaspace.used': intl('ahas_sentinel.systemGuard.flowControl.Metaspace'),
  // jvm线程数 相关
  'jvm.thread.count': intl('mse.machine.jvmAllcount'),
  'jvm.thread.deadlock.count': intl('mse.machine.jvmDeadlock'),
  'jvm.thread.new.count': intl('mse.machine.jvmNew'),
  'jvm.thread.blocked.count': intl('mse.machine.jvmBlocked'),
  'jvm.thread.runnable.count': intl('mse.machine.jvmRunnable'),
  'jvm.thread.terminated.count': intl('mse.machine.jvmTerminated'),
  'jvm.thread.timed_waiting.count': intl('mse.machine.jvmTimed_waiting'),
  'jvm.thread.waiting.count': intl('mse.machine.jvmWaiting'),
};

export const DUUBO_APP_RESOURCE_NAME: IauthName = {
  String: 'java.lang.String',
  Void: 'java.lang.Void',
  Float: 'java.lang.Float',
  Boolean: 'java.lang.Boolean',
  Byte: 'java.lang.Byte',
  Short: 'java.lang.Short',
  Integer: 'java.lang.Integer',
  Int: 'java.lang.Integer',
  Long: 'java.lang.Long',
  Double: 'java.lang.Double',
  Character: 'java.lang.Character',
  Char: 'java.lang.Character',
};

export const PRESSURE_MODE: IauthName = {
  thread: 'fix_thread',
  tps: 'fix_tps',
};

export const FLOW_MODEL: IauthName = {
  fix: 'fix',
  step: 'step',
  pulse: 'pulse',
};

interface IStressName {
  [key: string]: number;
}

export const DIALOG_RULES_MANAGEMENT_TAB_ITEM: IStressName = {
  flow: 1,
  isolate: 0,
  degrade: 2,
  hotSpot: 4,
  activeDemote: 5,
  database: 7,
};

export const TYPE_STATISRTICS: IControlOpType = {
  NoRuleExist: 'NO_RULE_EXISTS',
  TooMany: 'TOO_MANY_REQUEST',
  ShouldWait: 'SHOULD_WAIT',
  BadRequest: 'BAD_REQUEST',
  NotAvailable: 'NOT_AVAILABLE',
  Unknown: 'UNKNOWN',
  NoRefRule: 'NO_REF_RULE_EXISTS',
  Ok: 'OK',
  Blocked: 'BLOCKED',
  Fail: 'FAIL',
  Invalid: 'INVALID_CREDENTIAL',
};

export const TIME_STATISRTICS: IControlOpType = {
  Percent99: 'P99',
  Percent95: 'P95',
  Percent90: 'P90',
  Percent75: 'P75',
  Percent50: 'P50',
  Max: '最大值',
  Min: '最小值',
  Avg: '平均值',
};

export const ADJUST_MODEL: IStressName = {
  auto: 0,
  manual: 1,
};

export const REQUEST_METHODS = ['GET', 'POST', 'PUT', 'DELETE'];

export const CONFIG_REQUEST_PARAMS = 'https://help.aliyun.com/document_detail/199524.html?spm=5176.11961263.0.0.44103bc162pN08'; // 服务压测-如何配置请求参数文档地址

interface IControlOpType {
  [key: number]: string;
}

export const TIMR_INTERVAL_SEC: IControlOpType = {
  1: '秒',
  60: '分',
  3600: '时',
  86400: '天',
};

export const PARSE_STRATEGY_TYPE: IControlOpType = {
  0: 'Client IP',
  1: 'Remote Host',
  2: 'Header',
  3: 'URL 参数',
  5: 'Body',
};

export const FLOW_RULES_SCENE_STEPTWO: IControlOpType = {
  0: 'isolate',
  1: 'flow',
  2: 'fuse',
  3: 'system',
  4: 'hotspot',
  5: 'activeDemote',
  6: 'autoRetry',
};

export const PROTECTION_MANAGEMENT_STEPS = [
  { title: intl('ahas_sentinel.systemGuard.flowControl.addRuleStep1') },
  { title: intl('ahas_sentinel.systemGuard.flowControl.addRuleStep2') },
  { title: intl('ahas_sentinel.systemGuard.flowControl.addRuleStep3') },
  // { title: '配置告警时间' },
];

export const PROTECTION_MANAGEMENT_STEPS_SQL = [
  { title: intl('ahas_sentinel.systemGuard.flowControl.addRuleStep1') },
  { title: intl('ahas_sentinel.systemGuard.flowControl.addRuleStep2') },
];

export const PROTECTION_MANAGEMENT_STEPS_ACTIVE = [
  { title: intl('ahas_sentinel.systemGuard.flowControl.addRuleStep1') },
  { title: intl('ahas_sentinel.systemGuard.flowControl.addRuleStep4') },
];

export const PROTECTION_MANAGEMENT_TAB = [
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.ruleType1'),
    value: 1,
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.ruleType2'),
    value: 0,
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.ruleType3'),
    value: 2,
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.ruleType4'),
    value: 3,
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.HotspotParameterProtection'),
    value: 4,
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.ruleType6'),
    value: 5,
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.ruleType7'),
    value: 6,
  },
];

export const PROTECTION_SERVICE_TYPE = [
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.WEBservice'),
    value: 0,
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.RPCservice'),
    value: 1,
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.database_SQL'),
    value: 2,
  },
  {
    name: intl('ahas.component.Topology.otherNode'),
    value: 3,
  },
];

export const PROTECTION_MANAGEMENT_TAB_TYPE: IControlOpType = {
  1: intl('ahas_sentinel.systemGuard.flowControl.ruleType1'),
  0: intl('ahas_sentinel.systemGuard.flowControl.ruleType2'),
  2: intl('ahas_sentinel.systemGuard.flowControl.ruleType3'),
  3: intl('ahas_sentinel.systemGuard.flowControl.ruleType4'),
  4: intl('ahas_sentinel.systemGuard.flowControl.HotspotParameterProtection'),
  5: intl('ahas_sentinel.systemGuard.flowControl.ruleType6'),
  6: intl('ahas_sentinel.systemGuard.flowControl.ruleType7'),
};

export const API_MANAGEMENT_TAB = [
  {
    name: 'Web',
    value: 1,
  },
  {
    name: 'Rpc',
    value: 2,
  },
];

export const API_MANAGEMENT_TAB_TYPE: IControlOpType = {
  '-1': '未知',
  0: '自定义埋点',
  1: 'Web',
  2: 'Rpc',
};

export const CONFIG_CONTROL_BEHAVIOR_SHOW: IControlOpType = {
  0: intl('ahas_sentinel.systemGuard.flowControl.FailFast'),
  1: intl('ahas_sentinel.systemGuard.flowControl.Warm-upStart'),
  2: intl('ahas_sentinel.systemGuard.flowControl.Waitinginline'),
};

export const CONFIG_GRADE_SHOW: IControlOpType = {
  0: 'Load',
  1: 'RT',
  2: intl('ahas_sentinel.systemGuard.flowControl.Threads'),
  3: 'QPS',
  4: 'CPU 使用率',
};

export const CONFIG_STRATEGY_SHOW: IControlOpType = {
  0: intl('ahas_sentinel.systemGuard.flowControl.CurrentInterface'),
  1: intl('ahas_sentinel.systemGuard.flowControl.AssociatedInterface'),
  2: intl('ahas_sentinel.systemGuard.flowControl.LinkEntry'),
};

export const RPC_BACK_PATH = intl('ahas_sentinel.systemGuard.ActionRulesDialog.rpcBackPath'); // 自定义返回路径
export const RPC_ERROR_PATH = intl('ahas_sentinel.systemGuard.ActionRulesDialog.rpcErrorPath'); // 自定义异常路径
export const RPC_CONTENT_BODY = intl('ahas_sentinel.systemGuard.ActionRulesDialog.rpcContentBody'); // 实体类

/** **************** 应用防护模块结束 **************** **/

/** **************** 网关防护模块开始 **************** **/
export const agentFullUrl =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/agent/prod/latest/ahas-java-agent.jar';
export const NGINX_SIDECAR = 'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sidecar/latest/ahas-sentinel-sidecar-linux.tar.gz';
export const INGRESS_CONTROL = 'https://cs.console.aliyun.com/';
export const KUBERNETES_CLUSTERS = 'https://help.aliyun.com/document_detail/95108.html#task-skz-qwk-qfb';
export const INGRESS_GLOBAL_CONFIG = 'https://help.aliyun.com/document_detail/178819.html?spm=a2c4g.11186623.2.13.57cb5a18Zbr55H';
export const NGINX_SYSTEM_DATA = [
  {
    system: 'Ubuntu 18.04',
    version: 'nginx-1.14.0',
    url: 'lib/ubuntu-18.04-nginx-1.14.0/ngx_sentinel_module.so',
  },
  {
    system: 'CentOS 6',
    version: 'nginx-1.10.3',
    url: 'lib/centos6-nginx-1.10.3/ngx_sentinel_module.so',
  },
  {
    system: 'CentOS 7',
    version: 'nginx-1.16.1',
    url: 'lib/centos7-nginx-1.16.1/ngx_sentinel_module.so',
  },
];
export const RESOURCE_TYPE = {
  0: 'Route ID',
  1: intl('ahas_sentinel.systemGuard.flowControl.CustomAPI'), // '自定义API',
};
export const MATCH_PATTERN = {
  0: intl('ahas_sentinel.systemGuard.flowControl.accurate'), // 精确
  1: intl('ahas_sentinel.systemGuard.flowControl.Prefix'), // 前缀
  2: intl('ahas_sentinel.systemGuard.flowControl.Regular'), // 正则
};
export const GRADE_TYPE = {
  1: intl('ahas_sentinel.systemGuard.flowControl.RequestsCounts'), // 请求数
  0: intl('ahas_sentinel.systemGuard.flowControl.Concurrency'), // 并发数
};
/** **************** 网关防护模块结束 **************** **/

/** **************** 流量大盘模块开始 **************** **/

export const RESOURCE_FLOW = [
  '__total_inbound_traffic__',
  '__cpu_usage__',
  '__system_load__',
  'pass_qps',
  'block_qps',
  'exception_qps',
  '_rt',
  '_cpu',
  '_load',
];

/** **************** 流量大盘模块结束 **************** **/

/** **************** Mesh流控模块开始 **************** **/

export const MESH_TYPE_ARR = [
  // mesh流控接入方式
  {
    title: 'Istio 接入',
    type: 'istio',
    value: 0,
  },
  {
    title: 'Envoy 接入',
    type: 'envoy',
    value: 1,
  },
];

export const CLUSTER_DETAIL_STATINTERVAL: IControlOpType = {
  0: intl('ahas_sentinel.systemGuard.second'), // '秒',
  1: intl('ahas_sentinel.systemGuard.flowControl.minute'), // '分钟',
  2: intl('ahas_sentinel.systemGuard.flowControl.hour'), // '小时',
};

export const MATCH_RULES_TYPE_LIST: IControlOpType = {
  0: 'source_cluster',
  1: 'destination_cluster',
  2: 'generic_key',
  3: intl('ahas_sentinel.systemGuard.flowControl.customize'), // '自定义',
};

/** **************** Mesh流控模块结束 **************** **/

/** **************** Nginx防护模块开始 **************** **/

export const NGINX_API_DEFAULT_NAME = '如请求 URL 为 http://demo.aliyun.com:8090/api/login ，则接口名称为 default:demo.aliyun.com:8090。';

export const NGINX_API_URL_NAME = '如请求 URL 为 http://demo.aliyun.com/api/login ，则接口名称为 /api/login。';

export const NGINX_API_MATCH_TYPE: IControlOpType = {
  Any: intl('ahas_sentinel.systemGuard.flowControl.Unlimited'), // 无限制
  Exact: intl('ahas_sentinel.systemGuard.flowControl.Exactmatch'), // 精确匹配
  Suffix: intl('ahas_sentinel.systemGuard.flowControl.Suffixmatch'), // 后缀匹配
  Regex: intl('ahas_sentinel.systemGuard.flowControl.Regularexpression'), // 正则表达式
  Prefix: intl('ahas_sentinel.systemGuard.flowControl.Prefixmatch'), // 前缀匹配
};

export const INGRESS_SENTINEL_OTHER_REGION_URL = 'https://img.alicdn.com/imgextra/i4/O1CN01yOqoha1p56zAeyVXj_!!6000000005308-2-tps-1656-174.png'; // ingerss 接入其它 region 下配图地址

export const INGRESS_SENTINEL_PUBLIC_REGION_URL = 'https://img.alicdn.com/imgextra/i1/O1CN01Y3AQQg1qpCSRfgjI2_!!6000000005544-2-tps-1658-180.png'; // ingerss 接入公网 region 下配图地址

export const INGRESS_SENTINEL_SWITCH_URL = 'https://img.alicdn.com/imgextra/i3/O1CN01GyIw4k20B1sMuBZ3V_!!6000000006810-2-tps-1660-180.png'; // ingerss 接入公网 region 下配图地址

export const INGRESS_SENTINEL_LICENSE_URL = 'https://help.aliyun.com/document_detail/172351.htm?spm=a2c4g.11186623.2.13.676e5a18c1yIiU#task-2505338'; // 查看License获取地址

export const MSC_WIDGET_CONSOLE_CONFIG = window.WIDGET_CONSOLE_CONFIG?.edasmsc || { id: '@ali/widget-edas-msc', isUsePopApi: true, productName: 'mse', version: '0.11.58' };

// 预发、本地多环境
const fEnv = get(window, 'ALIYUN_CONSOLE_CONFIG.fEnv');
const host = get(window, 'location.host');
const str = /^([a-z\-\d+]+\.){1,}[a-z\-\d]+:\d{1,5}$/i;
export const IS_PRE_OR_LOCAL = fEnv === 'pre' || str.test(host);

/** **************** Nginx防护模块结束 **************** **/
