import intl from '@ali/wind-intl';

/** **************** 公共美杜莎文案开始 **************** **/

export const SEARCH_PLACEHOLDER = intl('ahas_sentinel.systemGuard.search.placeholder'); // 请输入资源名称进行筛选

/** ****************** 流控规则 or 隔离规则 ************ **/
export const SUCCESSS_OPENED = intl('ahas_sentinel.systemGuard.flowControl.SuccessOpened'); // 开启成功
export const CLOES_SUCCESSS = intl('ahas_sentinel.systemGuard.flowControl.ClosedSuccessfully'); // 关闭成功
export const DELETE_SUCCESSS = intl('ahas_sentinel.systemGuard.flowControl.successfullyDeleted'); // 删除成功
export const EDIT = intl('ahas_sentinel.systemGuard.flowControl.edit'); // 编辑
export const COPY = intl('ahas_sentinel.systemGuard.flowControl.copy'); // 复制
export const DELETE = intl('ahas_sentinel.systemGuard.flowControl.delete'); // 删除
export const RESOURCE_NAME = intl('ahas_sentinel.systemGuard.flowControl.ResourceName'); // 资源名
export const FOR_APPLICATIONS = intl('ahas_sentinel.systemGuard.flowControl.ForApplications'); // 针对应用
export const THRESSHOULD_TYPE = intl('ahas_sentinel.systemGuard.flowControl.ThresholdType'); // 阈值类型
export const THRESSHOULD = intl('ahas_sentinel.systemGuard.flowControl.Threshold'); // 阈值
export const PERCENTAGE = intl('mse.flow.governance.flow.protection.fuse.rules.percentage'); // 百分比
export const FLOW_MODE = intl('ahas_sentinel.systemGuard.flowControl.FlowControlMode'); // 流控模式
export const FLOW_EFFECT = intl('ahas_sentinel.systemGuard.flowControl.FlowControlEffect'); // 流控效果
export const NO_DATA = intl('ahas_sentinel.systemGuard.flowControl.noData'); // 暂无数据
export const INTER_NAME = intl('ahas_sentinel.systemGuard.flowControl.InterfaceName'); // 接口名称
export const SOURCE_APPLICATION = intl('ahas_sentinel.systemGuard.flowControl.SourceApplication'); // 来源应用
export const STRATEGY_SHOW = intl('ahas_sentinel.systemGuard.flowControl.StatisticalDimension'); // 统计维度
export const CLUSTER_TYPE = intl('ahas_sentinel.systemGuard.flowControl.ThresholdMode'); // 阈值模式
export const SINGLE_THRESHOLD = intl('ahas_sentinel.systemGuard.flowControl.SingleThreshold'); // 单机阈值
export const STATUS = intl('ahas_sentinel.systemGuard.flowControl.status'); // 状态
export const OPERATING = intl('ahas_sentinel.systemGuard.flowControl.operating'); // 操作
export const BATCH_OPEN = intl('ahas_sentinel.systemGuard.flowControl.BatchOpen'); // 批量开启
export const BATCH_CLOSE = intl('ahas_sentinel.systemGuard.flowControl.BatchClose'); // 批量关闭
export const ADD_FLOW_RULES = intl('ahas_sentinel.systemGuard.flowControl.AddControlRules'); // 新增流控规则
export const ADD_CLUSTER_RULES = intl('ahas_sentinel.systemGuard.flowControl.AddClusterRules'); // 新增集群流控规则
export const EDIT_CLUSTER_RULES = intl('ahas_sentinel.systemGuard.flowControl.EditClusterRules'); // 编辑集群流控规则
export const EDIT_FLOW_RULES = intl('ahas_sentinel.systemGuard.flowControl.EditControlRules'); // 编辑流控规则
export const ADD_IS_RULES = intl('ahas_sentinel.systemGuard.flowControl.NewIsolationRule'); // 新增隔离规则
export const EDIT_IS_RULES = intl('ahas_sentinel.systemGuard.flowControl.EditQuaraRules'); // 编辑隔离规则
export const PROMPT = intl('ahas_sentinel.systemGuard.flowControl.prompt'); // 提示
export const ON_OK = intl('ahas.component.SystemGuardMarketSortAdd.doc2'); // 确定

export const C_THRES = intl('ahas_sentinel.systemGuard.Clusterthreshold'); // 集群阈值
export const STH_QPS = intl('ahas_sentinel.systemGuard.sth'); // 单机QPS阈值
export const SEE_DETAILS = intl('ahas_sentinel.systemGuard.seeDetails'); // 查看详情
export const PLEASE_NAME = intl('ahas_sentinel.systemGuard.PleaseName'); // 请输入接口名称
export const NOT_NULL = intl('ahas_sentinel.systemGuard.notnul'); // 不能为空
export const PLEASE_ENTER = intl('ahas_sentinel.systemGuard.pleaseenter'); // 请输入
export const STA_DIME = intl('ahas_sentinel.systemGuard.staDime'); // 统计维度
export const SECOND = intl('ahas_sentinel.systemGuard.second'); // 秒
export const PLEASE_NUMBER = intl('ahas_sentinel.systemGuard.PleaseNumber'); // 请输入合法的数字
export const MILLISSECOND = intl('ahas_sentinel.systemGuard.millisecond'); // 毫秒
export const WHETHER_TO_OPEN = intl('ahas_sentinel.systemGuard.flowControl.WhetherToOpen'); // 是否开启
export const MINUTE = intl('ahas_sentinel.systemGuard.flowControl.minute'); // 分钟
export const HOUR = intl('ahas_sentinel.systemGuard.flowControl.hour'); // 小时
export const NOTE = intl('ahas_sentinel.systemGuard.flowControl.note'); // 注意：
export const EVERY_REQUEST = intl('ahas_sentinel.systemGuard.flowControl.Everyrequest'); // 每次请求
export const BULK_REQUEST = intl('ahas_sentinel.systemGuard.flowControl.Bulkrequest'); // 批量请求
export const SHOW_AD_OP = intl('ahas_sentinel.systemGuard.flowControl.ShowAdvancedOptions'); // 显示高级选项
export const HIDE_AD_OP = intl('ahas_sentinel.systemGuard.flowControl.HideAdvancedOptions'); // 隐藏高级选项
export const NEW_AND_SEE = intl('ahas_sentinel.systemGuard.flowControl.Newandview'); // 新建并查看
export const NEW = intl('ahas_sentinel.systemGuard.flowControl.New'); // 新建
export const SAVE = intl('ahas_sentinel.systemGuard.flowControl.save'); // 保存
export const CANCEL = intl('ahas_sentinel.systemGuard.flowControl.cancel'); // 取消
export const CHECK = intl('ahas_sentinel.systemGuard.flowControl.check'); // 校验


/** ****************** 熔断规则 ************ **/
export const DEGRADE_MODE = intl('ahas_sentinel.systemGuard.FuseRules.DegradedMode'); // 降级模式
export const MORE = intl('ahas_sentinel.systemGuard.FuseRules.More'); // 更多
export const STATIN_VALMS = intl('ahas_sentinel.systemGuard.FuseRules.StatisticalTime'); // 统计时长
export const CLICK_HERE = intl('ahas_sentinel.systemGuard.FuseRules.ClickHere'); // 点击此处查看文档。
export const OP_FAILED = intl('ahas_sentinel.systemGuard.FuseRules.operationFailed'); // 操作失败
export const CE_SUCCESS = intl('ahas_sentinel.systemGuard.FuseRules.CrSuccess'); // 新建成功
export const SAVE_SUCCESS = intl('ahas_sentinel.systemGuard.FuseRules.SavedSuccessfully'); // 保存成功
export const CAVEAT = intl('ahas_sentinel.systemGuard.FuseRules.caveat'); // 警告

export const GREATER_THAN_0 = intl('ahas_sentinel.systemGuard.FuseRules.greaterThan0'); // 请输入大于 0 的整数
export const RESET = intl('ahas_sentinel.systemGuard.FuseRules.Reset'); // 重置

/** **************** 公共美杜莎文案结束 **************** **/
