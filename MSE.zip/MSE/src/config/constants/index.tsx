import { IBreadCrumbItem } from '../interfaces';

export const productName = 'ahas';
export const mshaProductName = 'msha';

// Request Code校验
export const ERROR_CODE_ENUM = {
  needBuy: {
    code: 'RedirectToCommonBuy',
    url:
      window.ALIYUN_CONSOLE_CONFIG?.CHANNEL_LINKS?.common_buy &&
      window.ALIYUN_CONSOLE_CONFIG.CHANNEL_LINKS.common_buy,
  },
  openAHASServiceFailed: {
    code: 'OpenAHASServiceFailed',
    message: '服务开通失败，请稍后再试',
  },
  demoNoOpt: {
    code: 'demo.not.support.operation',
  },
  sgNoAuth: {
    code: 'sub_user_no_authority',
    message: '子账号没有对应权限',
  },
  systemError: {
    code: 'system.error',
    message: '请求失败，请稍后再试',
  },
};

export const DEFAULT_BREADCRUMB_ITEM: IBreadCrumbItem = {
  key: 'home',
  value: '应用高可用服务',
  path: '/index',
};

// 公有云补齐金融云region
export const PUBLIC_CLOUD_REGION = [
  {
    localName: '华东 2 金融云',
    regionEndpoint: 'ahas.cn-shanghai-finance-1.aliyuncs.com',
    regionId: 'cn-shanghai-finance-1',
    disabled: true,
  },
  {
    localName: '华北 2 阿里政务云1',
    regionEndpoint: 'http://ahas-share.cn-north-2-gov-1.aliyuncs.com',
    regionId: 'cn-north-2-gov-1',
    disabled: true,
  },
];

// 金融云、政务云补齐共有云region
export const FINANCE_CLOUD_REGION = [
  {
    localName: '华南1（深圳）',
    regionEndpoint: 'ahas.cn-shenzhen.aliyuncs.com',
    regionId: 'cn-shenzhen',
    disabled: true,
  },
  {
    localName: '华北2（北京）',
    regionEndpoint: 'ahas.cn-beijing.aliyuncs.com',
    regionId: 'cn-beijing',
    disabled: true,
  },
  {
    localName: '公网',
    regionEndpoint: 'ahas.aliyuncs.com',
    regionId: 'public',
    disabled: true,
  },
  {
    localName: '华东2（上海）',
    regionEndpoint: 'ahas.cn-shanghai.aliyuncs.com',
    regionId: 'cn-shanghai',
    disabled: true,
  },
  {
    localName: '华北3（张家口）',
    regionEndpoint: 'ahas.cn-zhangjiakou.aliyuncs.com',
    regionId: 'cn-zhangjiakou',
    disabled: true,
  },
  {
    localName: '华东1（杭州）',
    regionEndpoint: 'ahas.cn-hangzhou.aliyuncs.com',
    regionId: 'cn-hangzhou',
    disabled: true,
  },
];

export * from './menu';
export * from './Arch';
export * from './Chaos';
export * from './switch';
export * from './Manage';
