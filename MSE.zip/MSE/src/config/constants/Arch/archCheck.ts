import { ICommonStringType } from './index';

export const CATEGORY_TYPE: ICommonStringType = {
  1: '稳定',
  2: '容量',
  3: '性能',
  4: '安全',
  5: '成本',
};

