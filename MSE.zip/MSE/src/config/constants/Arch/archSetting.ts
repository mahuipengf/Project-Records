import { ICommonStringType } from './index';

// 巡检列表
export const CHECK_ITEM_PAGE_SIZE = 10;

export const CHECK_TAB_KEY: ICommonStringType = {
  0: '巡检项',
  1: '定时巡检',
};


// 定时巡检

export const WEEK_CHECKBOX_LIST = [
  { label: '周一', value: '1' },
  { label: '周二', value: '2' },
  { label: '周三', value: '3' },
  { label: '周四', value: '4' },
  { label: '周五', value: '5' },
  { label: '周六', value: '6' },
  { label: '周日', value: '7' },
];

// cron输入框属性

export const CRON_INOUTS = [
  { label: '分', name: 'customMinute', pattern: /^([0-9])$|^([1-9])([0-9])$|^([0-9])([0-9,-]+)([0-9])$/g, initValue: '0' },
  { label: '时', name: 'customTime', pattern: /^([0-9]+)$|^([1-9])([0-9])$|^([1-9])([0-9,-]+)([0-9])$|^[*,?]$/g, initValue: '1' },
  { label: '日', name: 'customDate', pattern: /^([1-9])$|^([1-9])([0-9])$|^([0-9])([0-9,-]+)([0-9])$|^[*,?]$/g, initValue: '*' },
  { label: '月', name: 'customMonth', pattern: /^([1-9])$|^([1-9])([0-2])$|^([0-9])([0-9,-]+)([0-9])$|^[*,?]$/g, initValue: '*' },
  { label: '周', name: 'customWeek', pattern: /^([1-7])$|^([1-7])([,-]+)([1-7])$|^[*,?]$/g, initValue: '?' },
];

