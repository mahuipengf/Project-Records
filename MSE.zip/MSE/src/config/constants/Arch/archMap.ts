import { ICommonNumberType, ICommonStringType } from './index';

// viewId 集合
export const VIEW_ID = {
  Cloud: {
    cloud: 'CloudConfigView', // 基础云资源视图
    risk_cloud: 'CloudConfigRiskView', // 风险云资源视图
    cloud_group: 'CloudConfigGroupView', // 基础云资源聚合图
    risk_cloud_group: 'CloudConfigRiskGroupView', // 风险云资源聚合图
  },
  Kub: {
    k: 'KubernetesView',
    k_node: 'KubernetesNodeView',
    k_pod: 'KubernetesPodView',
    k_deployment: 'KubernetesDeploymentView',
    k_daemonSet: 'KubernetesDaemonSetView',
    k_service: 'KubernetesServiceView',
    k_container: 'KubernetesContainerView',
    k_process: 'KubernetesProcessView',
    k_panoramic: 'KubernetesPanoramicView',
    m: 'KubernetesMonitorView',
    m_node: 'KubernetesNodeMonitorView',
    m_pod: 'KubernetesPodMonitorView',
    m_deployment: 'KubernetesDeploymentMonitorView',
    m_daemonSet: 'KubernetesDaemonSetMonitorView',
    m_service: 'KubernetesServiceMonitorView',
    m_container: 'KubernetesContainerMonitorView',
    m_process: 'KubernetesProcessMonitorView',
    m_panoramic: 'KubernetesPanoramicMonitorView',
  },
  Application: {
    a: 'ApplicationView',
    node: 'ApplicationNodeView',
    process: 'ApplicationProcessView',
    panoramic: 'ApplicationPanoramicView',
  },
  Host: {
    node: 'NodeMonitorView',
  },
};

// 进程类型
export const PROCESS_TYPE_ENUM: ICommonStringType = {
  SYSTEM: 's',
  CLOUND: 'y',
  USER: 'u',
  VIRTUAL: 'v',
};

// 逻辑关系
export const HOST_TYPE_ENUM: ICommonStringType = {
  LOGICALRELATION: 'l', // 逻辑关系
  REALTIMERELATION: 'p', // 实时关系
};

// 节点类型
export const HOST_NODE_TYPE_ENUM: ICommonStringType = {
  _ECS_INSTALL: '_ecs_install', // 已安装的ecs
  _ECS_UNINSTALL: '_ecs_unInstall', // 未安装ecs
  __OTHER_NODE: '__other_node',
  SLB: 'slb',
  RDS: 'rds',
  KVSTORE: 'kvstore',
  NAT: 'nat',
  WAF: 'waf',
  DDOS: 'ddos',
  DNS: 'dns',
  ROCKETMQ: 'rocketmq',
  DRDS: 'drds',
  EIP: 'eip',
};

export const PROCESS_TYPE_MAP = {
  [PROCESS_TYPE_ENUM.VIRTUAL]: true,
  [PROCESS_TYPE_ENUM.USER]: true,
};

export const HOST_TYPE_MAP = {
  [HOST_TYPE_ENUM.LOGICALRELATION]: true,
  [HOST_TYPE_ENUM.REALTIMERELATION]: true,
};

export const HOST_NODE_TYPE_MAP = {
  [HOST_NODE_TYPE_ENUM._ECS_INSTALL]: true,
  [HOST_NODE_TYPE_ENUM._ECS_UNINSTALL]: true,
  [HOST_NODE_TYPE_ENUM.SLB]: true,
  [HOST_NODE_TYPE_ENUM.RDS]: true,
  [HOST_NODE_TYPE_ENUM.KVSTORE]: true,
  [HOST_NODE_TYPE_ENUM.NAT]: true,
  [HOST_NODE_TYPE_ENUM.WAF]: true,
  [HOST_NODE_TYPE_ENUM.DDOS]: true,
  [HOST_NODE_TYPE_ENUM.__OTHER_NODE]: true,
  [HOST_NODE_TYPE_ENUM.DNS]: true,
  [HOST_NODE_TYPE_ENUM.ROCKETMQ]: true,
  [HOST_NODE_TYPE_ENUM.DRDS]: true,
  [HOST_NODE_TYPE_ENUM.EIP]: true,
};

export const LT_FILTERS = {
  processFlag: 'ProcessType',
  nodeTypeFlag: 'ProductType',
  lpFlag: 'ConnectorType',
  ipNameFlag: 'NameType',
  linkFlag: 'ConnectedType',
};

export const NODE_TYPE_MAP: ICommonNumberType = {
  0: '__other_node',
  10: '_ecs_install', // 已安装ecs 添加下划线是为了排序显示在最后
  100: '_ecs_unInstall', // 未安装ecs
  101: 'slb',
  102: 'rds',
  103: 'kvstore',
  104: 'nat',
  105: 'waf',
  106: 'ddos',
  107: 'dns',
  108: 'rocketmq',
  109: 'drds',
  110: 'eip',
};

export const ZONE_GRID = 'ZoneGrid';
export const NODE_OFFSET_X = 70;// x轴
export const NODE_OFFSET_Y = 70;// y轴
export const H_F_OFFSET_Y = 80;// 头部和底部节点间距
export const ONELINEMAX_DEFAULT = 20;// 一行最大数量

export const SVG_CONSTANTS = {
  animateScale: 20,
  offLightOpacity: 0.1, // 线的虚拟 程度
  animateTime: 400, // svg 动画时长
  lineColor: '#666699', // 线头，的颜色
  nodeColor: '#666699', // 普通颜色的节点
  cloudNodeColor: '#00c1de', // 阿里云 颜色节点
  nodeWarningColor: 'orange',
  shadowColor: 'rgba(102, 102, 153, 0.1)', // 线的透明度
  shadowPathColor: 'rgba(102, 102, 153, 0.7)', // hover线的颜色
  outerCircleColor: 'rgba(119, 144, 174, 0.2)', // svg圆未激活时的颜色
  outerCircleColorActive: 'rgba(102, 102, 153, 0.7)', // svg圆激活时轮廓的颜色
  outerCircleColorOffLight: `rgba(102, 102, 153, ${0.05})`, // 激活之后其他节点轮廓的颜色变淡
  cpuColor0_50: 'rgba(0, 134, 250,0.7)', // cpu 0-50 所占的颜色 蓝
  memColor0_50: '#87CEEB', // mem 0-50 的颜色 蓝
  cpuColor50_80: '#ffbf00', // cpu 50-80 所占的颜色 黄
  memColor50_80: '#F9F92C', // mem 50-80 的颜色 黄
  cupColor80_: '#FF0000', // cup 80+ 所占的颜色 红
  memColor80_: '#FF6347', // mem 80+ 所占的颜色 红
  riskLevelUrgencyBorderColor: 'rgba(217, 48, 38, 1)', // risk严重bc
  riskLevelWarningBorderColor: 'rgba(255, 196, 64, 1)', // risk警告bc
  riskLevelUrgencyBg: '#FFEBEB', // risk严重bg
  riskLevelWarningBg: '#FFF5DD', // risk警告bg
  riskListBg: 'rgba(0, 0, 0, 0.65)', // risk列表背景颜色
};

export const ONE_100 = '#F0F5FF'; // 1-100颜色bg
export const ONEHUNDRED_1000 = '#D6E4FF'; // 101-1000颜色bg
export const THOUSAND_ = '#ADC6FF'; // 大于1001颜色bg

export const NODE_COLOR = '#55555'; // 普通颜色的节点
export const CLOUD_NODE_COLOR = '#55555'; // 阿里云 颜色节点
export const RISK_LEVEL_URGENCY_BORDER_COLOR = '#D93026';// risk严重
export const RISK_LEVEL_WARNING_BORDER_COLOR = '#FFC440';// risk警告

export const NODE_TYPE_MAP_ICON: ICommonNumberType = {
  0: '',
  10: 'HOST', // 实际是ecs 但是展示的是host的图标
  100: 'HOST', // 实际是ecs 但是展示的是host的图标
  101: 'SLB',
  102: 'RDS',
  103: 'KVSTORE',
  104: 'NAT',
  105: 'WAF',
  106: 'DDOS',
  107: 'DNS',
  108: 'ROCKETMQ',
  109: 'DRDS',
  110: 'EIP',
};

export const ONE_100_BG = {
  backgroundColor: ONE_100,
};

export const ONE_HUNDRED_1000_bg = {
  backgroundColor: ONEHUNDRED_1000,
};

export const THOUSAND = {
  backgroundColor: THOUSAND_,
};


// slb parmas name
export const METRIC_NAMES: ICommonStringType = {
  slb: [
    'NewConnection',
    'DropConnection',
    'ActiveConnection',
    'InactiveConnection',
    'MaxConnection',
    'HeathyServerCount',
    'UnhealthyServerCount',
    'TrafficTXNew',
    'TrafficRXNew',
    'Qps',
  ],
  eip: [
    'net_rx.rate',
    'net_tx.rate',
    'out_ratelimit_drop_speed',
  ],
  ecs: [
    'CPUUtilization',
    'memory_usedutilization',
    'InternetInRate',
    'InternetOutRate',
    'IntranetInRate',
    'IntranetOutRate',
    'DiskReadIOPS',
    'DiskWriteIOPS',
    'load_5m',
  ],
  rds: [
    'ConnectionUsage',
    'CpuUsage',
    'DiskUsage',
    'MemoryUsage',
    'IOPSUsage',
    'MySQL_NetworkInNew',
    'MySQL_NetworkOutNew',
  ],
  redis: [
    'ConnectionUsage',
    'UsedConnection',
    'MaxRt',
    'AvgRt',
    'QPSUsage',
    'HitRate',
  ],
};

export const ICON_URL: ICommonStringType = {
  pod: 'https://img.alicdn.com/tfs/TB1qvxN1vb2gK0jSZK9XXaEgFXa-200-200.png',
  nginx: 'https://img.alicdn.com/tfs/TB1kTPgmSslXu8jSZFuXXXg7FXa-200-179.png',
  process: 'https://img.alicdn.com/tfs/TB1iJvAk4vbeK8jSZPfXXariXXa-200-200.png',
  redis: 'https://img.alicdn.com/tfs/TB1YChI1xz1gK0jSZSgXXavwpXa-200-200.png',
  rds: 'https://img.alicdn.com/tfs/TB1YChI1xz1gK0jSZSgXXavwpXa-200-200.png',
  slb: 'https://img.alicdn.com/tfs/TB1hKJDnAcx_u4jSZFlXXXnUFXa-200-200.png',
  mysql: 'https://img.alicdn.com/tfs/TB1htFT1EH1gK0jSZSyXXXtlpXa-200-168.png',
  etcd: 'https://img.alicdn.com/tfs/TB1AIFV1AL0gK0jSZFAXXcA9pXa-200-200.png',
  application: 'https://img.alicdn.com/tfs/TB1GeFT1EH1gK0jSZSyXXXtlpXa-200-200.png',
  host: 'https://img.alicdn.com/imgextra/i4/O1CN01fI3aIG1epPEMCDXLc_!!6000000003920-2-tps-32-32.png',
  rocketmq: 'https://img.alicdn.com/imgextra/i4/O1CN01CIDYeV1WPHhva48lp_!!6000000002780-2-tps-200-200.png',
  zone: 'https://img.alicdn.com/imgextra/i4/O1CN01u21t7a1lHEzr7hn5h_!!6000000004793-2-tps-32-32.png',
};
