/** **************** 应用防护模块开始 **************** **/

import intl from '@ali/wind-intl';

// 接口详情模块

// 切换tab项
export const API_TAB_DEFAULT = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.WEBservice'),
    value: 'iconfont icon-Ahas-Web',
    key: '1',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.RPCservice'),
    value: 'iconfont icon-Ahas-RPC',
    key: '2',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.database'),
    value: 'iconfont icon-Ahas-shujuku',
    key: '4',
  },
  {
    title: '缓存',
    value: 'iconfont icon-Ahas-huancun',
    key: '5',
  },
  {
    title: '依赖服务',
    value: 'iconfont icon-Ahas-guanlian',
    key: '-1',
  },
  {
    title: '自定义埋点',
    value: 'iconfont icon-Ahas-zidingyi',
    key: '0',
  },
  {
    title: '我的收藏',
    value: 'iconfont icon-Ahas-Collect',
    key: '-2',
  },
];

export const GATEWAY_TAB_DEFAULT = [
  {
    title: '全部',
    value: 'iconfont icon-Ahas-All',
    key: '-1',
  },
  {
    title: '我的收藏',
    value: 'iconfont icon-Ahas-Collect',
    key: '-2',
  },
];

export const MACGINE_ALL_TAB_DEFAULT = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.ApplicationIndex'),
    key: '0',
  },
  {
    title: 'CPU',
    key: '1',
  },
  {
    title: 'LOAD',
    key: '2',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.Physicalmemory'),
    key: '3',
  },
  {
    title: 'Disk',
    key: '4',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.NetworkTraffic'),
    key: '5',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.Networkpacket'),
    key: '6',
  },
];

export const MACGINE_JVM_ALL_TAB_DEFAULT = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.GCtimes'),
    key: '0',
  },
  {
    title: 'GC耗时',
    key: '1',
  },
  {
    title: '堆内存详情',
    key: '2',
  },
  {
    title: '元空间详情',
    key: '3',
  },
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.NumberofJVMthreads'),
    key: '4',
  },
];

export const SORT_TAB = [
  {
    value: 0,
    title: intl('mse.appOverview.paasQps'),
    type: 'api',
  },
  {
    value: 1,
    title: intl('ahas_sentinel.systemGuard.flowControl.CurrentlimitQPS'),
    type: 'api',
  },
  {
    value: 2,
    title: intl('mse.appOverview.exception'),
    type: 'api',
  },
  {
    value: 4,
    title: 'RT',
    type: 'api',
  },
];

export const MACHINE_MONITORING_NODE = [
  {
    value: 'nodeOverview',
    title: '节点概览',
  },
  {
    value: 'jvm',
    title: 'JVM 监控',
  },
  {
    value: 'SubDetails',
    title: '接口详情',
  },
  {
    value: 'callstack',
    title: 'callstack 信息',
  },
];

export const NGINX_MONITORING_NODE = [
  {
    value: 'nodeOverview',
    title: '节点概览',
  },
  {
    value: 'SubDetails',
    title: '接口详情',
  },
  // {
  //   value: 'callstack',
  //   title: 'callstack 信息',
  // },
];

export const CHARTS_TITLE = [
  'QPS数据（秒级）',
  'RT数据（ms）',
  '并发数据（秒级）',
];

export const CHARTS_TYPE = ['allQps', 'rt', 'thread'];

export const JVM_CHARTS_TYPE = ['jvmGc', 'jvmGcTime', 'jvmHeap', 'jvMetaSpace', 'jvmThreadCount'];

export const SUMMARY_REQUESTS_COUNT_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.NumberofPassedRequest'),
  intl('ahas_sentinel.systemGuard.flowControl.Flowcontrolrequests'),
  intl('ahas_sentinel.systemGuard.flowControl.Numberofexceptionrequests'),
];

export const SUMMARY_RT_CPU_STATUS_TITLE = [
  {
    title: 'RT(ms)',
    width: '36.5%',
  },
  {
    title: 'CPU',
    width: '36.5%',
  },
  {
    title: '状态码统计',
    width: '24.5%',
  },
];

export const SUMMARY_RT_CPU_TITLE = [
  {
    title: 'RT(ms)',
    width: '49.5%',
  },
  {
    title: 'CPU',
    width: '49.5%',
  },
];

export const SUMMARY_RT_CPU_STATUS_TYPE = [
  'rt',
  'cpu',
  'statusCode',
];

export const SUMMARY_CHARTS_Flow_TITLE = [
  'QPS数据',
  'RT(ms)',
  'CPU',
  '防护事件',
];

export const SUMMARY_CHARTS_Flow_TYPE = [
  'allQps',
  'rt',
  'cpu',
  'event',
];

export const MACHINE_CHARTS_TITLE = [
  'QPS数据',
  'RT数据',
  'CPU',
  'Load',
  intl('ahas_sentinel.systemGuard.flowControl.physicalMemory'),
  'Disk（G）',
  intl('ahas_sentinel.systemGuard.flowControl.NetworkTraffic'),
  intl('ahas_sentinel.systemGuard.flowControl.Networkdatapacket'),
];


export const SUMMARY_CHARTS_SYSTEM_TITLE = [
  'Load',
  intl('ahas_sentinel.systemGuard.flowControl.physicalMemory'),
  'Disk（G）',
];

export const SUMMARY_CHARTS_SYSTEM_TYPE = [
  'load',
  'system_memory',
  'system_disk',
];

export const SUMMARY_CHARTS_JVM_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.GCtimes'),
  intl('ahas_sentinel.systemGuard.flowControl.GCduration'),
  intl('ahas_sentinel.systemGuard.FuseRules.memorydetails'),
  intl('ahas_sentinel.systemGuard.flowControl.NumberofJVMthreads'),
];

export const SUMMARY_CHARTS_JVM_TYPE = [
  'jvm_gc',
  'jvm_gc_time',
  'jvm_heap',
  'jvm_thread_count',
];

export const SUMMARY_CHARTS_NETWORK_TITLE = [
  intl('ahas_sentinel.systemGuard.flowControl.NetworkTraffic'),
  intl('ahas_sentinel.systemGuard.flowControl.Networkdatapacket'),
];

export const SUMMARY_CHARTS_NETWORK_TYPE = [
  'system_network',
  'system_network_data_pack',
];

export const SUMMARY_CHARTS_MODELS_TYPE = ['system', 'jvm', 'netWork'];

export const MACHINE_CHARTS_TYPE = ['allQps', 'rt', 'cpu', 'load','thread','system_memory', 'system_disk', 'system_network', 'system_network_data_pack'];

export const NODE_CHARTS_TITLE = [
  '节点的QPS数据（秒级）',
  '节点的RT数据（ms）',
  '节点的并发数据（秒级）',
];

export const NODE_MACHINE_CHARTS_TITLE = [
  '接口的QPS数据（秒级）',
  '接口的RT数据（ms）',
  '接口的并发数据（秒级）',
];

export const SELECT_CHARTS_TYPE = [
  intl('mse.appOverview.paasQps'),
  intl('ahas_sentinel.systemGuard.flowControl.RejectQPS'),
  intl('mse.appOverview.exception'),
  'RT(ms)',
  intl('ahas_sentinel.systemGuard.flowControl.Concurrents'),
];

export const NODE_CHARTS_TYPE = [
  'allQps',
  'rt',
  'thread',
];

export const MACHINE_RESOURCE_ARR = [
  '__app_summary_metric_resource_name__',
  '__cpu_usage__',
  '__system_load__',
  '__thread__',
];

export const RENDER_API_ICON_TYPE = [
  'iconAhas-All',
  'iconAhas-Web',
  'iconAhas-RPC',
  'iconAhas-SQL',
  'iconAhas-Other',
  'iconAhas-Collect',
];

export const ICON_OF_FALL_URL =
  'https://img.alicdn.com/tfs/TB1dbJkGLb2gK0jSZK9XXaEgFXa-12-10.svg';

export const ICON_OF_RISE_URL =
  'https://img.alicdn.com/tfs/TB1RAxkGFT7gK0jSZFpXXaTkpXa-12-10.svg';

export const RAM_URL = 'https://ram.console.aliyun.com'; // 权限管理-开通子账号

interface IauthName {
  [key: string]: string;
}

// 权限管理-权限
export const AUTH_NAME: IauthName = {
  0: '读写权限',
  1: '只读权限',
  '-1': '无',
};

// 节点管理-健康筛选
export const HEALTHY_FILTERS = [
  { label: '健康', value: 1 },
  { label: '失联', value: 0 },
];

// 基础设置-防护模式设置-入门/高级
export const BEGINNER_TIPS =
  '入门级防护模式 : 防护规则仅支持2条，建议使用高级防护提升系统防护能力。';
export const PROFESSIONAL_TIPS =
  '高级防护模式 : 防护规则无限制，有效的规则可提升系统防护能力。';

// 基础设置-开通专业版url
// export const POST_BUY_URL = window.ALIYUN_CONSOLE_CONFIG?.CHANNEL_LINKS?.post_buy ? window.ALIYUN_CONSOLE_CONFIG.CHANNEL_LINKS.post_buy :
  // 'http://common-buy.aliyun.com/?commodityCode=ahas_post#/buy';

export const PROTECTION_EVENTS_TYPE = {
  0: '簇点限流',
  1: '簇点异常',
  2: '集群cpu利用率过高',
};

export const MODULE_TYPE: IauthName = {
  0: 'Web',
  1: 'Web',
};

export const FLOW_TYPE: IauthName = {
  0: '返回指定内容',
  1: '跳转到指定页面',
};

export const ACTION_MODULE_TYPE: IauthName = {
  1: 'Web',
};

export const DEFAULT_RESOURCE_AMOUNT = 6000;
export const DEFAULT_ORIGIN_AMOUNT = 1000;
export const DEFAULT_CONTEXT_AMOUNT = 2000;
export const DEFAULT_STATISTIC_RT = 4900;
export const SUCCESS_MSG = '需改配置成功';
export const JUMP_URL_NOT_EMPTY = '跳转url不可为空';
export const STATUS_CODE_NOT_EMPTY = '状态码不可为空';
export const DEFAULT_REQUEST_TIMEOUT = 20;
export const OPERATION_FAILED = '操作失败';
export const MODIFY_SUCCESS = '修改成功';
export const MODIFY_ERROR = '修改失败';
export const MSG_TIPS = '00:00-00:15为系统结算期，请勿在此期间更改价格模式。';
export const SWITCH_FAILED = '切换失败';
export const SWITCH_SUCCESS = '切换成功';
// 应用防护===================================================================================

export const LANGUAGE_TYPE_ARR = [
  // 语言种类
  {
    title: 'JAVA语言',
    type: 'java',
    value: 0,
  },
  {
    title: 'GO语言',
    type: 'go',
    value: 1,
  },
  {
    title: 'PHP语言',
    type: 'php',
    value: 2,
  },
];

export const ACCESS_JAVA_DATA = [
  // Java 接入方式
  {
    title: 'Agent 接入',
    type: 'syringe',
    value: 0,
  },
  {
    title: 'SDK 接入' /* SDK 接入*/,
    type: 'sdk',
    value: 1,
  },
  {
    title: 'K8s 接入' /* K8s 接入*/,
    type: 'Kubernetes',
    value: 2,
  },
  {
    title: 'SAE 接入' /* SAE 接入*/,
    type: 'sae',
    value: 3,
  },
  {
    title: '体验 Demo' /* 体验 Demo*/,
    type: 'demo',
    value: 4,
  },
];

export const ACCESS_GO_DATA = [
  // GO 接入方式
  {
    title: 'SDK 接入',
    type: 'go_sdk',
    value: 0,
  },
  {
    title: '体验 Demo' /* 体验 Demo*/,
    type: 'demo',
    value: 1,
  },
];

export const ACCESS_PHP_DATA = [
  // PHP 接入方式
  {
    title: 'SDK 接入',
    type: 'php_sdk',
    value: 0,
  },
];
export const JAVA_SDK_ENV = [
  // JAVA_SDK接入环境
  {
    title: 'Spring Boot 应用接入' /* Spring Boot 应用接入*/,
    type: 'icon-spring-boot',
    value: 0,
  },
  {
    title: 'Spring 应用接入' /* Spring 应用接入*/,
    type: 'Asset',
    value: 1,
  },
  {
    title: 'Dubbo/HSF 应用接入' /* Dubbo/HSF 应用接入*/,
    type: 'dubbo',
    value: 2,
  },
  {
    title: 'Web 应用接入' /* Web 应用接入*/,
    type: 'web',
    value: 3,
  },
  {
    title: '自定义埋点' /* 自定义埋点*/,
    type: 'spot',
    value: 4,
  },
];

export const GO_SDK_ENV = [
  // GO_SDK接入环境
  {
    title: 'Dubbo 应用接入' /* Dubbo 应用接入*/,
    type: 'dubbo',
    value: 0,
  },
  {
    title: 'Gin Web 应用接入' /* Gin Web 应用接入*/,
    type: 'web',
    value: 1,
  },
  {
    title: 'gRPC 应用接入' /* gRPC 应用接入*/,
    type: 'gRPC',
    value: 2,
  },
  {
    title: 'Micro 服务接入' /* gRPC 应用接入*/,
    type: 'micro',
    value: 3,
  },
  {
    title: '自定义埋点' /* 自定义埋点*/,
    type: 'spot',
    value: 4,
  },
];

export const PHP_SDK_ENV = [
  // PHP_SDK接入环境
  {
    title: '自定义埋点' /* 自定义埋点*/,
    type: 'spot',
    value: 0,
  },
];

export const ACCESS_DATA = [
  {
    name: 'Spring Boot 应用接入',
    value: 'Spring-Boot',
  },
  {
    name: 'Spring 应用接入',
    value: 'Spring',
  },
  {
    name: 'Dubbo 应用接入',
    value: 'Dubbo',
  },
  {
    name: 'Web 应用接入',
    value: 'Web',
  },
  {
    name: '自定义埋点',
    value: 'urying-point',
  },
];

export const BUTYING_POINT = [
  {
    title: 'HTTP 接口埋点',
  },
  {
    title: 'MyBatis SQL埋点',
  },
  {
    title: '普通接口埋点',
  },
];

export const DOWNLOAD_GO_LINUX_DEMO_URL =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sdk/go/demo/ahas_sentinel_go_demo_linux'; // 下载 Go demo Linux 版压缩包
export const DOWNLOAD_GO_MACOS_DEMO_URL =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sdk/go/demo/ahas_sentinel_go_demo_macos'; // 下载 Go demo macOS 版压缩包
export const agentInstallSh =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/agent/prod/latest/ahas-agent.sh';
export const AHAS_JAVA_AGENT_URL =
  'https://help.aliyun.com/document_detail/128800.html'; // AHAS Java Agent 支持列表
export const DOWNLOAD_GO_SDK_URL =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sdk/go/latest/aliyun-ahas-go-sdk.zip'; // 下载 AHAS Go SDK 压缩包
export const API_DETAILS_URL =
  'https://help.aliyun.com/document_detail/154664.html'; // API详情参考文档
export const AHAS_SPRING_BOOT_URL =
  'https://help.aliyun.com/document_detail/102555.html#title-jsk-jqr-r5b'; // Spring Boot应用接入-普通接口埋点-帮助文档
export const AUTO_RETRY_DOSC_URL = 'https://help.aliyun.com/document_detail/102559.html'; // Java Sdk 接入-自定义埋点-自动重试规则文档
export const AHAS_JAVA_SDK_DUBBO_ADAPTER_URL = 'https://help.aliyun.com/document_detail/102555.html?spm=a2c4g.11186623.2.14.353c3a73TDLXTK#section-rgg-4vj-kgb'; // Dubbo Adapter 帮助文档
export const AHAS_CUSTOMIZE_URL =
  'https://help.aliyun.com/document_detail/110601.html'; // 添加埋点帮助文档
export const FULL_SCREEN_OFF =
  'https://img.alicdn.com/tfs/TB1FSXLkxv1gK0jSZFFXXb0sXXa-64-64.png';
export const FULL_SCREEN_ON =
  'https://img.alicdn.com/tfs/TB1aS4wkET1gK0jSZFrXXcNCXXa-64-64.png';
export const DOWNLOAD_PHP_SDK_URL =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sidecar/0.6/ahas-sentinel-sidecar-linux.tar.gz'; // 下载 AHAS PHP SDK 压缩包
export const AHAS_INSTALL_K8S_URL = 'https://cs.console.aliyun.com/index2#/k8s/catalog/detail/incubator_ack-ahas-sentinel-pilot'; // 安装k8s插件链接

// 规则管理

interface IControlOpType {
  [key: string]: string;
}

export const shGRADE_TYPE = {
  0: intl('ahas_sentinel.systemGuard.flowControl.Threads'),
  1: 'QPS',
};

export const CONTROL_TYPE = {
  0: intl('ahas_sentinel.systemGuard.flowControl.FailFast'),
  2: intl('ahas_sentinel.systemGuard.flowControl.Waitinginline'),
};

export const OP_TYPE: IControlOpType = {
  ADD: intl('ahas_sentinel.systemGuard.flowControl.Add'),
  MODIFY: intl('widget.common.change'),
  DELETE: intl('mse.common.delete'),
  ON: intl('ahas_sentinel.systemGuard.flowControl.Turnon'),
  BATCH_ON: intl('ahas_sentinel.systemGuard.flowControl.Turnon'),
  OFF: intl('mse.tag.dialog.close'),
  BATCH_OFF: intl('mse.tag.dialog.close'),
  ADD_ITEM: intl('ahas_sentinel.systemGuard.FuseRules.AddException'),
  CHANGE_OFF: intl('ahas_sentinel.systemGuard.flowControl.Schemeswitching'),
};

export const RULE_TYPE: IControlOpType = {
  FLOW: intl('ahas_sentinel.systemGuard.flowControl.InterfaceFlowcontrol'),
  DEGRADE: intl('ahas_sentinel.systemGuard.flowControl.Fuserules'),
  SYSTEM: intl('ahas_sentinel.systemGuard.flowControl.Systemrules'),
  ADAPTER_SETTING: intl('ahas_sentinel.systemGuard.flowControl.Generalconfiguration'),
  GENERAL_SETTING: intl('ahas_sentinel.systemGuard.flowControl.Generalconfiguration'),
  PARAM_FLOW: intl('ahas_sentinel.systemGuard.flowControl.HotspotParameterProtection'),
  CLUSTER_CLIENT_SETTING: intl('ahas_sentinel.systemGuard.flowControl.TokenClientConfiguration'),
  ADAPTIVE_FLOW_SETTING: intl('ahas_sentinel.systemGuard.flowControl.AdaptiveFlowControl'),
  GATEWAY_API_DEFINITION: intl('ahas_sentinel.systemGuard.flowControl.Gateway'),
  ALL_RULES: intl('ahas_sentinel.systemGuard.flowControl.Allruless'),
  RETRY: intl('ahas_sentinel.systemGuard.flowControl.Automaticretryrules'),
  HTTP_API_MATCH: intl('ahas_sentinel.systemGuard.flowControl.RequestGroupingRules'),
  BLOCK_FALLBACK_DEFINITION: intl('ahas_sentinel.systemGuard.flowControl.fallbackbehavior'),
  MANUAL_DEGRADE: intl('ahas_sentinel.systemGuard.flowControl.ActiveDemotion'),
  APP_TS_CLUSTER: intl('ahas_sentinel.systemGuard.flowControl.Clusterprotectionsettings'),
};

export const FLOW_RULE = 'https://help.aliyun.com/document_detail/421958.html';
export const NGINX_FLOW_RULE = 'https://help.aliyun.com/document_detail/200920.html';
export const QUARA_RULE = 'https://help.aliyun.com/document_detail/421959.html';
export const LEVE_RULE = 'https://help.aliyun.com/document_detail/200919.html';
export const STSTEM_RULE =
  'https://help.aliyun.com/document_detail/101079.html';
export const HOTS_RULE = 'https://help.aliyun.com/document_detail/421964.html';
export const RETRY_RULES_URL = 'https://help.aliyun.com/document_detail/194976.html';
export const APACHE_HTTP_CLIENT = 'https://help.aliyun.com/document_detail/195443.html';

export const dialogFlowTips =
  '流量控制会监控应用实时的 QPS ，当达到指定的阈值时控制流量，以避免被瞬时的流量高峰冲垮.';
export const dialogIsolateTips =
  '隔离规则会监控应用实时调用的线程数，当达到指定的阈值时控制流量，通过隔离有问题的接口，避免系统资源占用过多影响全局可用性。';
export const FLOW_URL =
  'https://help.aliyun.com/document_detail/421958.html';
export const DOWNG_CONTENT =
  '熔断规则会在调用链路中某个资源出现不稳定时（例如 Timeout或异常比例升高），对这个资源的调用进行限制，让请求快速失败，避免影响到其它的资源而导致级联错误。Sentinel 熔断规则支持两种策略：单位时间内的慢调用比例和异常比例。';
export const DOWNG_URL = 'https://help.aliyun.com/document_detail/101078.html';
export const MANUAL_DOWNG_CONTENT =
  '主动降级规则可以针对某些接口的全部请求进行降级，执行自定义的降级行为。';
export const MANUAL_DOWNG_URL = 'https://help.aliyun.com/document_detail/201862.html';
export const SYSTEM_CON_A =
  '系统保护规则可以从系统指标维度来进行流量控制，如系统的整体 QPS、RT、负载等。';
export const SYSTEM_CON_B =
  '注意：系统规则只针对入口资源生效，且每种相同类型的系统保护规则最多只能存在一条。';
export const SYSTEM_CON_C =
  '注意：Load 模式会在当前系统 load1超过阈值，且系统当前的并发线程数超过系统的容量（maxQps * minRt)时才会触发系统保护。';
export const SYSTEM_URL = 'https://help.aliyun.com/document_detail/101079.html';
export const BEHAVIOR_CONTENT =
  'Fallback 行为定义某种埋点资源类型触发了某种规则（如流控、熔断、降级）后的处理行为。';
export const BEHAVIOR_URL = 'https://help.aliyun.com/document_detail/201863.html';
export const SPRINGCLOUD_STRESS_URL = 'https://help.aliyun.com/document_detail/199525.html';
export const DUBBO_STRESS_URL = 'https://help.aliyun.com/document_detail/199524.html';

export const gradeFilters = [
  { label: 'QPS', value: 1 },
  {
    label: intl('ahas_sentinel.systemGuard.flowControl.Threads'),
    value: 0,
  },
];

export const controlFilters = [
  {
    label: intl('ahas_sentinel.systemGuard.flowControl.FailFast'),
    value: 0,
  },
  {
    label: intl('ahas_sentinel.systemGuard.flowControl.Waitinginline'),
    value: 2,
  },
];
export const enableFilters = [
  { label: intl('ahas_sentinel.systemGuard.flowControl.Turnon'), value: 1 },
  { label: intl('mse.tag.dialog.close'), value: 0 },
];

export const thresholdTypeFilters = [
  { label: intl('ahas_sentinel.systemGuard.flowControl.Standalone'), value: 0 },
  { label: intl('ahas_sentinel.systemGuard.flowControl.Clusteroverall'), value: 1 },
  { label: intl('ahas_sentinel.systemGuard.flowControl.ClusterAmortization'), value: 2 },
];

// 应用概述

export const SUMMARY_TAB_DEFAULT = [
  { key: 'passedQps', content: intl('mse.appOverview.paasQps') },
  { key: 'blockedQps', content: intl('ahas_sentinel.systemGuard.flowControl.FlowControlQPS') },
  { key: 'exceptionQps', content: intl('mse.appOverview.exception') },
  { key: 'rt', content: intl('ahas_sentinel.systemGuard.flowControl.AverageRT') },
];

export const SUMMARY_TAB_TOP = [
  { key: 'passedQps', content: `${intl('mse.appOverview.paasQps')} TOP` },
  { key: 'blockedQps', content: intl('ahas_sentinel.systemGuard.flowControl.FlowControlQPSTOP') },
  { key: 'rt', content: intl('ahas_sentinel.systemGuard.flowControl.AverageRTTOP') },
];

interface IMapObject {
  [index: string]: string;
}

export const THERMODYNAMIC_CHART_KEY_DATA: IMapObject = {
  passedQps: intl('mse.appOverview.paasQps'),
  rt: intl('ahas_sentinel.systemGuard.flowControl.AverageRt'),
  blockedQps: intl('ahas_sentinel.systemGuard.flowControl.FlowControlQPS'),
  exceptionQps: intl('ahas_sentinel.systemGuard.flowControl.AbnormalQPS'),
  totalQps: intl('ahas_sentinel.systemGuard.flowControl.TotalQPS'),
  thread: intl('ahas_sentinel.systemGuard.flowControl.Concurrents'),
  cpu: 'CPU',
  load: 'Load',
};

export const CHART_TYPE: IMapObject = {
  passQps: intl('mse.appOverview.paasQps'),
  blockedQps: intl('mse.appOverview.blockflow'),
  exceptionQps: intl('mse.appOverview.exceptionflow'),
  rt: 'RT(ms)',
  thread: intl('ahas_sentinel.systemGuard.flowControl.Concurrents'),
  cpu: 'CPU',
  load: 'Load',
};

export const CHART_CONTRAST_TYPE: IMapObject = {
  passQps: intl('ahas_sentinel.systemGuard.flowControl.PassQPSyear-on-year'),
  blockedQps: intl('ahas_sentinel.systemGuard.flowControl.RejectQPSyear-on-year'),
  exceptionQps: intl('ahas_sentinel.systemGuard.flowControl.Year-on-yearabnormalQPS'),
  rt: intl('ahas_sentinel.systemGuard.flowControl.YoYRT'),
  thread: intl('ahas_sentinel.systemGuard.flowControl.Concurrencyyear-on-year'),
  cpu: intl('ahas_sentinel.systemGuard.flowControl.YoYCPU'),
  load: intl('ahas_sentinel.systemGuard.flowControl.Year-on-yearLoad'),
};

export const CHART_COUNT: IMapObject = {
  passQps: 'passedQps',
  blockedQps: 'blockedQps',
  exceptionQps: 'exception',
  rt: 'rt',
  thread: 'thread',
  cpu: 'passedQps',
  load: 'passedQps',
};

export const API_NAME_MAP: IMapObject = {
  __total_inbound_traffic__: `${intl('mse.register.service.cluster_groups')} QPS`,
  __cpu_usage__: intl('ahas_sentinel.systemGuard.flowControl.ClusteraverageCPU'),
  __system_load__: intl('ahas_sentinel.systemGuard.flowControl.Clusteraverageload'),
  pass_qps: `${intl('mse.appOverview.paasQps')} Top`,
  block_qps: `${intl('ahas_sentinel.systemGuard.flowControl.CurrentlimitQPS')} Top`,
  exception_qps: `${intl('mse.appOverview.exception')} Top`,
  _rt: intl('ahas_sentinel.systemGuard.flowControl.AverageRTTop'),
  _cpu: 'CPU Top',
  _load: 'LOAD Top',
};

// 概览页-系统负载
export const SYSTEM_LOAD_LIST = ['system_cpu', 'system_memory', 'system_load'];

// 定义接口详情页引导步骤文案
export const API_DETAILS_STEPS_TIPS = [
  {
    element: '.next-menu-content',
    content: "<p style='color: #7b7b7b; font-size: 16px; font-weight: bold;'>监控细分，数据更全面</p><p style='color: #7b7b7b; margin: 1px;'>原“监控详情”拆分为<span style='color: #0070CC;'>接口详情</span>与<span style='color: #0070CC;'>节点详情</span>两个维度，簇点链路合并到节点详情中</p>",
    position: 'right',
  },
  {
    element: '#api_deatils_show_type',
    content: '<p style="color: #7b7b7b; font-size: 16px; font-weight: bold;">调用统计转到这里啦</p><p style="color: #7b7b7b;">切换到<span style="color: #0070CC;">“统计模式”</span>即可查看指定日期的接口统计信息，同时增加峰值统计信息。</p>',
  },
];

// 定义应用概览页引导步骤文案
export const SUMMARY_PAGE_STEPS_TIPS = [
  {
    element: '#summary_page_show_dashboard',
    content: "<p style='color: #7b7b7b; font-size: 16px; font-weight: bold;'>全新维度，数据更直观</p><p style='color: #7b7b7b; margin: 1px;'>从<span style='color: #0070CC;'>业务流量</span>、<span style='color: #0070CC;'>应用性能</span>、<span style='color: #0070CC;'>系统负载</span>维度展示数据</p>",
  },
  // {
  //   element: '#summary_page_show_node',
  //   content: "<p style='color: #7b7b7b; font-size: 16px; font-weight: bold;'>节点分位，数据更详细</p><p style='color: #7b7b7b; margin: 1px;'>展示不同统计指标的节点分位信息</p>",
  //   position: 'top',
  // },
];

export const CLUSTRER_GEARLEVEL = [
  {
    title: '入门级',
    descQps: '0 ～ 10000',
    descCount: '0 ～ 5000',
    value: 1,
  },
  {
    title: '初级',
    descQps: '10000 ～ 20000',
    descCount: '5000 ～ 15000',
    value: 2,
  },
  {
    title: '中级',
    descQps: '20000 ～ 30000',
    descCount: '15000 ～ 25000',
    value: 3,
  },
  {
    title: '高级',
    descQps: '30000 ～ 40000',
    descCount: '25000 ～ 35000',
    value: 4,
  },
  {
    title: '专业级',
    descQps: '40000 ～ 50000',
    descCount: '35000 ～ 45000',
    value: 5,
  },
];

// 接口详情-导出接口详情文案
export const EXPORT_API_TIPS = [
  {
    type: 'pdf',
    title: '接口详情报告 PDF 版',
    desc: '流量防护-接口详情报告导出',
    iconName: 'icon-PDF',
  },
  {
    type: 'csv',
    title: '接口详情报告 CSV 版',
    desc: '流量防护-接口详情报告导出',
    iconName: 'icon-csv',
  },
];

// 集群流控管理后台-server 类型
export const SERVER_TYPE_LIST: IControlOpType = {
  0: '普通',
  1: 'Mesh',
};

// 集群流控状态
export const CLISTER_STATUS: IControlOpType = {
  0: '待调度',
  1: '资源分配中',
  2: '资源分配完成',
  5: '分配异常',
};

// 规则管理tab
export const RULES_SET_TAB_ITEM:IMapObject = {
  FLOW: intl('ahas_sentinel.systemGuard.flowControl.InterfaceFlowcontrol'), // 接口流控
  quarantine: intl('ahas_sentinel.systemGuard.flowControl.ConcurrentIsolation'), // '并发隔离',
  downGrade: intl('ahas_sentinel.systemGuard.flowControl.Fuserules'), // 熔断规则,
  activeDemote: intl('ahas_sentinel.systemGuard.flowControl.ActiveDemotion'), // 主动降级,
  system: intl('ahas_sentinel.systemGuard.flowControl.AdaptiveFlowControl'), // 自适应流控,
  hotSpot: intl('ahas_sentinel.systemGuard.flowControl.HotspotParameterProtection'), // 热点参数防护（RPC）,
  autoRetry: intl('ahas_sentinel.systemGuard.flowControl.Automaticretryrules'), // 自动重试规则,
  apiGwFlow: intl('mse.apiDetail.gatewayRule'),
};

// 机器监控-主机监控类型
export const HOST_LIST = ['system_cpu', 'system_memory', 'system_disk', 'system_load', 'system_network', 'system_network_data_pack'];

// 机器监控-主机监控类型
export const HOST_LIST_TITLE: IauthName = {
  system_cpu: 'CPU（%）',
  system_memory: intl('ahas_sentinel.systemGuard.flowControl.physicalMemory'),
  system_disk: intl('ahas_sentinel.systemGuard.FuseRules.tenseconds'),
  system_load: 'Load',
  system_network: intl('ahas_sentinel.systemGuard.FuseRules.Byte'),
  system_network_data_pack: intl('ahas_sentinel.systemGuard.FuseRules.Network'),
};

// 接口详情-分类tab
export const API_DETAILS_TAB_ITEM = [
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.Interfaceoverview'),
    key: 0,
  },
  {
    title: intl('mse.apiDetail.HotspotParameterProtection.HTTP'),
    key: 1,
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.StatusStatistics'),
    key: 2,
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.ExceptionStatistics'),
    key: 3,
  },
];

// 机器监控-JVM监控类型
export const JVM_LIST = ['jvm_gc', 'jvm_gc_time', 'jvm_heap', 'jvm_meta_space', 'jvm_thread_count'];

// 机器监控-JVM监控图表标题
export const JVM_CHARTS_TITLE: IMapObject = {
  jvm_gc: intl('ahas_sentinel.systemGuard.flowControl.GCtimes'),
  jvm_gc_time: intl('ahas_sentinel.systemGuard.FuseRules.GCtimems'),
  jvm_heap: intl('ahas_sentinel.systemGuard.FuseRules.memorydetails'),
  jvm_meta_space: intl('ahas_sentinel.systemGuard.FuseRules.Metaspace'),
  jvm_thread_count: intl('ahas_sentinel.systemGuard.flowControl.NumberofJVMthreads'),
};

// 机器监控-主机监控-cpu_tab
export const CPU_ITEM_TAB = [
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.user'),
    val: 'system.cpu.user',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.system'),
    val: 'system.cpu.system',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.Wait'),
    val: 'system.cpu.iowait',
  },
];

// 机器监控-主机监控-物理内存tab
export const MEMORY_ITEM_TAB = [
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.SystemFreeMemory'),
    val: 'system.mem.free',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.systemhas'),
    val: 'system.mem.used',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.PageCache'),
    val: 'system.mem.cached',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.BufferCache'),
    val: 'system.mem.buffers',
  },
];

// 机器监控-主机监控-Disk_tab
export const DISK_ITEM_TAB = [
  {
    title: intl('mse.apiDetail.diskFree'),
    val: 'system.disk.partition.free',
  },
  {
    title: intl('mse.apiDetail.diskTotal'),
    val: 'system.disk.partition.total',
  },
];

// 机器监控-主机监控-Load_tab
export const LOAD_ITEM_TAB = [
  {
    title: 'Load',
    val: 'system.load.1min',
  },
];

// 机器监控-主机监控-网络流量_tab
export const NETWORK_ITEM_TAB = [
  {
    title: intl('mse.appOverview.networkReceivedTrafficSize'),
    val: 'system.net.in.bytes',
  },
  {
    title: intl('mse.appOverview.networkSendTrafficSize'),
    val: 'system.net.out.bytes',
  },
];

// 机器监控-主机监控-网络数据包_tab
export const NETWORK_DATA_PACK_ITEM_TAB = [
  {
    title: intl('mse.appOverview.messagesReceivedNum'),
    val: 'system.net.in.packets',
  },
  {
    title: intl('mse.appOverview.messagesSendNum'),
    val: 'system.net.out.packets',
  },
  {
    title: intl('mse.appOverview.errorsReceivedNum'),
    val: 'system.net.in.errs',
  },
  {
    title: intl('ahas_sentinel.systemGuard.FuseRules.NumberOfDiscarded'),
    val: 'system.net.in.dropped',
  },
];

// 机器监控-jvm监控-jvm_gc
export const GC_ITEM_TAB = [
  {
    title: intl('mse.appOverview.younggctimes'),
    val: 'jvm.gc.young.count',
  },
  {
    title: intl('mse.appOverview.fullGCtimes'),
    val: 'jvm.gc.old.count',
  },
];

// 机器监控-jvm监控-jvm_gc_time
export const GC_TIME_ITEM_TAB = [
  {
    title: intl('mse.appOverview.younggctime'),
    val: 'jvm.gc.young.time',
  },
  {
    title: intl('mse.appOverview.fullGCtime'),
    val: 'jvm.gc.old.time',
  },
];

// 机器监控-jvm监控-jvm_heap
export const HEAP_ITEM_TAB = [
  {
    title: intl('mse.appOverview.youngGenerationEdenDistrict'),
    val: 'jvm.mem.pools.eden_space.used',
  },
  {
    title: intl('mse.appOverview.youngSurvivorDistrict'),
    val: 'jvm.mem.pools.survivor_space.used',
  },
  {
    title: intl('mse.appOverview.oldage'),
    val: 'jvm.mem.pools.old_gen.used',
  },
  {
    title: intl('mse.appOverview.useSum'),
    val: 'jvm.mem.heap.used',
  },
];

// 机器监控-jvm监控-jvm_meta_space
export const META_SPACE_ITEM_TAB = [
  {
    title: intl('ahas_sentinel.systemGuard.flowControl.Metaspace'),
    val: 'jvm.mem.pools.metaspace.used',
  },
];

// 机器监控-jvm监控-jvm_thread_count
export const THREAD_COUNT_ITEM_TAB = [
  {
    title: intl('mse.machine.jvmBlocked'),
    val: 'jvm.thread.blocked.count',
  },
  {
    title: intl('mse.machine.jvmDeadlock'),
    val: 'jvm.thread.deadlock.count',
  },
  {
    title: intl('mse.machine.jvmNew'),
    val: 'jvm.thread.new.count',
  },
  {
    title: intl('mse.machine.jvmRunnable'),
    val: 'jvm.thread.runnable.count',
  },
  {
    title: intl('mse.machine.jvmTerminated'),
    val: 'jvm.thread.terminated.count',
  },
  {
    title: intl('mse.machine.jvmTimed_waiting'),
    val: 'jvm.thread.timed_waiting.count',
  },
  {
    title: intl('mse.machine.jvmWaiting'),
    val: 'jvm.thread.waiting.count',
  },
  {
    title: intl('mse.machine.jvmAllcount'),
    val: 'jvm.thread.count',
  },
];

interface IHostOfTabItem {
  title: string;
  val: string;
}
interface IHostOfTab {
  [key: string]: IHostOfTabItem[];
}

export const HOST_OF_DETAIL_TAB: IHostOfTab = {
  system_cpu: CPU_ITEM_TAB,
  system_memory: MEMORY_ITEM_TAB,
  system_disk: DISK_ITEM_TAB,
  system_load: LOAD_ITEM_TAB,
  system_network: NETWORK_ITEM_TAB,
  system_network_data_pack: NETWORK_DATA_PACK_ITEM_TAB,
  cpu: CPU_ITEM_TAB,
  load: LOAD_ITEM_TAB,
  jvm_gc: GC_ITEM_TAB,
  jvm_gc_time: GC_TIME_ITEM_TAB,
  jvm_heap: HEAP_ITEM_TAB,
  jvm_meta_space: META_SPACE_ITEM_TAB,
  jvm_thread_count: THREAD_COUNT_ITEM_TAB,
};

// 指标详情默认选中tab
export const SUB_SELECTE_DEFAULT_TAB: IauthName = {
  system_cpu: 'system.cpu.user',
  system_memory: 'system.mem.free',
  system_disk: 'system.disk.partition.free',
  system_load: 'system.load.1min',
  system_network: 'system.net.in.bytes',
  system_network_data_pack: 'system.net.in.packets',
  cpu: 'system.cpu.user',
  load: 'system.load.1min',
  jvm_gc: 'jvm.gc.young.count',
  jvm_gc_time: 'jvm.gc.young.time',
  jvm_heap: 'jvm.mem.pools.eden_space.used',
  jvm_meta_space: 'jvm.mem.pools.metaspace.used',
  jvm_thread_count: 'jvm.thread.blocked.count',
};

// 校验charts传入数据类别
export const DATA_OF_CHARTS_SHOW: IauthName = {
  // cpu 相关
  'system.cpu.total': intl('mse.apiDetail.diskTotal'),
  'system.cpu.iowait': intl('mse.appOverview.waitIoCpuUsed'),
  'system.cpu.user': intl('mse.appOverview.useCpuUsed'),
  'system.cpu.system': intl('mse.appOverview.sysCpuUsed'),
  // load
  'system.load.1min': 'Load',
  // 物理内存相关
  'system.mem.total': intl('mse.apiDetail.diskTotal'),
  'system.mem.free': intl('ahas_sentinel.systemGuard.FuseRules.sysFree'),
  'system.mem.used': intl('ahas_sentinel.systemGuard.FuseRules.usedMemory'),
  'system.mem.cached': intl('ahas_sentinel.systemGuard.FuseRules.PageCache'),
  'system.mem.buffers': intl('ahas_sentinel.systemGuard.FuseRules.BufferCache'),
  // Network 相关
  'system.net.in.bytes': intl('mse.appOverview.networkReceivedTrafficSize'),
  'system.net.out.bytes': intl('mse.appOverview.networkSendTrafficSize'),
  'system.net.in.packets': intl('mse.appOverview.messagesReceivedNum'),
  'system.net.out.packets': intl('ahas_sentinel.systemGuard.FuseRules.packets'),
  'system.net.in.errs': intl('ahas_sentinel.systemGuard.FuseRules.NumberOfErrorsReceived'),
  'system.net.in.dropped': intl('mse.appOverview.packetsDroppedNum'),
  // Disk 相关
  'system.disk.partition.total': intl('mse.apiDetail.diskTotal'),
  'system.disk.partition.free': intl('mse.apiDetail.diskFree'),
  'system.disk.partition.used': intl('mse.apiDetail.diskUsed'),
  // jvm堆内存 相关
  'jvm.mem.heap.used': intl('mse.appOverview.useSum'),
  'jvm.mem.pools.old_gen.used': intl('mse.appOverview.oldage'),
  'jvm.mem.pools.survivor_space.used': intl('mse.appOverview.youngSurvivorDistrict'),
  'jvm.mem.pools.eden_space.used': intl('mse.appOverview.youngGenerationEdenDistrict'),

  // jvm非堆内存 相关
  'jvm.mem.non_heap.committed': intl('mse.appOverview.nonHeapMemoryCommitBytes'),
  'jvm.mem.non_heap.init': intl('mse.appOverview.numberOfBytesInHeapMemory'),
  'jvm.mem.non_heap.used': intl('mse.appOverview.numberOfBytesUsedInNonHeapMemory'),

  // jvm元空间 相关
  'jvm.mem.pools.metaspace.used': intl('ahas_sentinel.systemGuard.flowControl.Metaspace'),
  // jvm线程数 相关
  'jvm.thread.count': intl('mse.machine.jvmAllcount'),
  'jvm.thread.deadlock.count': intl('mse.machine.jvmDeadlock'),
  'jvm.thread.new.count': intl('mse.machine.jvmNew'),
  'jvm.thread.blocked.count': intl('mse.machine.jvmBlocked'),
  'jvm.thread.runnable.count': intl('mse.machine.jvmRunnable'),
  'jvm.thread.terminated.count': intl('mse.machine.jvmTerminated'),
  'jvm.thread.timed_waiting.count': intl('mse.machine.jvmTimed_waiting'),
  'jvm.thread.waiting.count': intl('mse.machine.jvmWaiting'),
};

export const DUUBO_APP_RESOURCE_NAME: IauthName = {
  String: 'java.lang.String',
  Void: 'java.lang.Void',
  Float: 'java.lang.Float',
  Boolean: 'java.lang.Boolean',
  Byte: 'java.lang.Byte',
  Short: 'java.lang.Short',
  Integer: 'java.lang.Integer',
  Int: 'java.lang.Integer',
  Long: 'java.lang.Long',
  Double: 'java.lang.Double',
  Character: 'java.lang.Character',
  Char: 'java.lang.Character',
};

export const PRESSURE_MODE: IauthName = {
  thread: 'fix_thread',
  tps: 'fix_tps',
};

export const FLOW_MODEL: IauthName = {
  fix: 'fix',
  step: 'step',
  pulse: 'pulse',
};

interface IStressName {
  [key: string]: number;
}

export const ADJUST_MODEL: IStressName = {
  auto: 0,
  manual: 1,
};

export const REQUEST_METHODS = ['GET', 'POST', 'PUT', 'DELETE'];

export const CONFIG_REQUEST_PARAMS = 'https://help.aliyun.com/document_detail/199524.html?spm=5176.11961263.0.0.44103bc162pN08'; // 服务压测-如何配置请求参数文档地址

/** **************** 应用防护模块结束 **************** **/

/** **************** 网关防护模块开始 **************** **/
export const agentFullUrl =
  'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/agent/prod/latest/ahas-java-agent.jar';
export const NGINX_SIDECAR = 'https://ahasoss-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/sidecar/latest/ahas-sentinel-sidecar-linux.tar.gz';
export const INGRESS_CONTROL = 'https://cs.console.aliyun.com/';
export const KUBERNETES_CLUSTERS = 'https://help.aliyun.com/document_detail/95108.html#task-skz-qwk-qfb';
export const INGRESS_GLOBAL_CONFIG = 'https://help.aliyun.com/document_detail/178819.html?spm=a2c4g.11186623.2.13.57cb5a18Zbr55H';
export const NGINX_SYSTEM_DATA = [
  {
    system: 'Ubuntu 18.04',
    version: 'nginx-1.14.0',
    url: 'lib/ubuntu-18.04-nginx-1.14.0/ngx_sentinel_module.so',
  },
  {
    system: 'CentOS 6',
    version: 'nginx-1.10.3',
    url: 'lib/centos6-nginx-1.10.3/ngx_sentinel_module.so',
  },
  {
    system: 'CentOS 7',
    version: 'nginx-1.16.1',
    url: 'lib/centos7-nginx-1.16.1/ngx_sentinel_module.so',
  },
];
export const RESOURCE_TYPE = {
  0: 'Route ID',
  1: intl('ahas_sentinel.systemGuard.flowControl.CustomAPI'),
};
export const MATCH_PATTERN = {
  0: intl('ahas_sentinel.systemGuard.flowControl.accurate'),
  1: intl('ahas_sentinel.systemGuard.flowControl.Prefix'),
  2: intl('ahas_sentinel.systemGuard.flowControl.Regular'),
};
export const GRADE_TYPE = {
  1: 'QPS',
  0: intl('ahas_sentinel.systemGuard.flowControl.Threads'),
};
/** **************** 网关防护模块结束 **************** **/

/** **************** 流量大盘模块开始 **************** **/

export const RESOURCE_FLOW = [
  '__total_inbound_traffic__',
  '__cpu_usage__',
  '__system_load__',
  'pass_qps',
  'block_qps',
  'exception_qps',
  '_rt',
  '_cpu',
  '_load',
];

/** **************** 流量大盘模块结束 **************** **/

/** **************** Mesh流控模块开始 **************** **/
interface IControlOpType {
  [key: number]: string;
}

export const MESH_TYPE_ARR = [
  // mesh流控接入方式
  {
    title: intl('widget.msc.containers.app_access_istio'),
    type: 'istio',
    value: 0,
  },
  {
    title: intl('widget.msc.containers.app_access_envoy'),
    type: 'envoy',
    value: 1,
  },
];

export const CLUSTER_DETAIL_STATINTERVAL: IControlOpType = {
  0: intl('ahas_sentinel.systemGuard.second'),
  1: intl('ahas_sentinel.systemGuard.flowControl.minute'),
  2: intl('widget.common.hours'),
};

export const MATCH_RULES_TYPE_LIST: IControlOpType = {
  0: 'source_cluster',
  1: 'destination_cluster',
  2: 'generic_key',
  3: intl('widget.service.the_custom'),
};

/** **************** Mesh流控模块结束 **************** **/

/** **************** Nginx防护模块开始 **************** **/

export const NGINX_API_DEFAULT_NAME = '如请求 URL 为 http://demo.aliyun.com:8090/api/login ，则接口名称为 default:demo.aliyun.com:8090。';

export const NGINX_API_URL_NAME = '如请求 URL 为 http://demo.aliyun.com/api/login ，则接口名称为 /api/login。';

export const NGINX_API_MATCH_TYPE: IControlOpType = {
  Any: intl('ahas_sentinel.systemGuard.flowControl.Unlimited'),
  Exact: intl('ahas_sentinel.systemGuard.flowControl.Exactmatch'),
  Suffix: intl('ahas_sentinel.systemGuard.flowControl.Suffixmatch'),
  Regex: intl('ahas_sentinel.systemGuard.flowControl.Regularexpression'),
  Prefix: intl('ahas_sentinel.systemGuard.flowControl.Prefixmatch'),
};

export const INGRESS_SENTINEL_OTHER_REGION_URL = 'https://img.alicdn.com/imgextra/i4/O1CN01yOqoha1p56zAeyVXj_!!6000000005308-2-tps-1656-174.png'; // ingerss 接入其它 region 下配图地址

export const INGRESS_SENTINEL_PUBLIC_REGION_URL = 'https://img.alicdn.com/imgextra/i1/O1CN01Y3AQQg1qpCSRfgjI2_!!6000000005544-2-tps-1658-180.png'; // ingerss 接入公网 region 下配图地址

export const INGRESS_SENTINEL_SWITCH_URL = 'https://img.alicdn.com/imgextra/i3/O1CN01GyIw4k20B1sMuBZ3V_!!6000000006810-2-tps-1660-180.png'; // ingerss 接入公网 region 下配图地址

export const INGRESS_SENTINEL_LICENSE_URL = 'https://help.aliyun.com/document_detail/172351.htm?spm=a2c4g.11186623.2.13.676e5a18c1yIiU#task-2505338'; // 查看License获取地址

/** **************** Nginx防护模块结束 **************** **/
