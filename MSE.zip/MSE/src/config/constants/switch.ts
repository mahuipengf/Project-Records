export const CARD_WIDTH = 384;
export const CARD_GAP = 16;
export const MAX_DISPLAY_CARD_ROW = 4;
