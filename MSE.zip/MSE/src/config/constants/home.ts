
export const BAG_BUY_URL_FLOW = window.ALIYUN_CONSOLE_CONFIG?.CHANNEL_LINKS?.bag_buy ? window.ALIYUN_CONSOLE_CONFIG.CHANNEL_LINKS.bag_buy : 'http://common-buy.aliyun.com/?commodityCode=ahas_bag#/buy'; // 购买资源包Url 流量防护;

export const getParentUrl = () => {
  let url = null;
  if (parent !== window) {
    try {
      url = parent.location.href;
    } catch (e) {
      url = document.referrer;
    }
  }
  return url;
};
// export const SENTINEL_PREPAY_PUBILC_URL = 'http://common-buy.aliyun.com?commodityCode=ahas_sentinelprepay_public_cn#/buy'; // 资源包-包年包月
export const VERSION_OF_CONTRAST = 'https://www.aliyun.com/price/product?#/ahas/detail'; // 版本对比Url
export const QUESTION_OF_RESEARCH = 'https://page.aliyun.com/form/act1563655433/index.htm'; // 问卷调研Url
export const PRODUCT_NEWS_URL = 'https://www.aliyun.com/product/new?category=13&product=332'; // 产品动态url
export const HELP_DOC_INDEX_URL = 'https://help.aliyun.com/document_detail/144439.html?spm=a2c4g.11186623.6.541.7ff729dcVSOD6l'; // 概览页帮助文档url
export const HELP_DOC_TOPOLOGY_URL = 'https://help.aliyun.com/document_detail/97583.html?spm=a2c4g.11186623.6.561.29b57c6fYnMcKk'; // 架构感知帮助文档url
export const HELP_DOC_FLOW_URL = 'https://help.aliyun.com/document_detail/101132.html?spm=a2c4g.11186623.6.580.4bb35fa3ftCH0b'; // 流量防护帮助文档url
export const HELP_DOC_WSITCH_URL = 'https://help.aliyun.com/document_detail/155939.html'; // 功能开关帮助文档url
export const VERSION_PRICE_URL = 'https://www.aliyun.com/price/product/?spm=5176.11961263.Summary.7.2b343bc121s3yV#/ahas/detail'; // 版本说明和价格详情
export const MESH_ISTIO_URL = 'https://www.envoyproxy.io/docs/envoy/latest/configuration/http/http_filters/rate_limit_filter?spm=5176.11961263.SystemGuardMeshProtection.4.662b3bc1kQFSe6#config-http-filters-rate-limit'; //  mesh接入，istio文档链接
export const CHOAS_WORKSPACE_URL = 'https://help.aliyun.com/document_detail/189580.html'; // chaos演练空间文档
export const MSHA_URL = 'https://msha.console.aliyun.com/'; // MSHA项目URL

export const helpDocConfig: any = {
  choasMap: {
    url: 'https://help.aliyun.com/document_detail/307105.html',
    toPaths: ['/chaos/map'],
  },
};
export const ORDER_DEFAULT = [1, 2, 3, 4];

export const SLIDES_ITEM = [
  {
    url: 'https://img.alicdn.com/imgextra/i3/O1CN01Zw1Yok1FOVa7qxbEL_!!6000000000477-2-tps-1280-540.png',
    title: 'Ingress/Nginx 流控',
    description: '为 Ingress/Nginx 网关提供开箱即用的流控降级能力。',
    link: 'https://help.aliyun.com/document_detail/178827.html',
  },
  {
    url: 'https://img.alicdn.com/tfs/TB1VkNWYvb2gK0jSZK9XXaEgFXa-1280-540.png',
    title: '自适应流控',
    description:
      '开启自适应流控后，会通过一系列的流控操作，将系统负载控制在一个较为均衡的水位范围内，不需要您额外手动设置各指标阈值。',
    link:
      'https://help.aliyun.com/document_detail/101079.html?spm=a2c4g.11186623.6.603.5b8c65cc8T3wke',
  },
  {
    url: 'https://img.alicdn.com/tfs/TB17VhcRhz1gK0jSZSgXXavwpXa-1280-540.png',
    title: '熔断降级',
    description:
      '全新改进的熔断降级特性，支持更丰富的熔断策略、灵活定制统计时长的能力以及更加智能的渐进式恢复策略。',
    link: 'https://help.aliyun.com/document_detail/101078.html?#title-e6e-1b7-uxm',
  },
  {
    url: 'https://img.alicdn.com/tfs/TB1NVIDfCR26e4jSZFEXXbwuXXa-1280-540.png',
    title: '集群流控和 Mesh 流控',
    description:
      '集群流控：精确控制服务在整个集群维度的实时调用量，支持分钟小时级别的业务集群流控，token server 全自动化托管。<br />Mesh 流控：为 Istio/Envoy 服务网格提供无侵入的全局流量控制的能力，仅需简单配置即可从多个维度对 Mesh 流量进行控制。',
    link: 'https://help.aliyun.com/document_detail/174871.html',
  },
];

