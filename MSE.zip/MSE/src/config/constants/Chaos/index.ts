export const DepGovernSteps = [
  '应用接入',
  '依赖分析',
  '依赖预判',
  '依赖验证',
  '方案归档',
];

export const DepGovernStatus = [
  '初始化',
  '符合预期',
  '不符合预期',
];

export const DepSelectData = [
  {
    label: '弱依赖',
    value: false,
  },
  {
    label: '强依赖',
    value: true,
  },
];

export const customIconUrl = '//at.alicdn.com/t/font_2615886_9xiym7iayd6.js';
