import intl from '@ali/wind-intl';
export const STEPS = [
  '容灾能力评估',
  '演练影响说明',
  '选择演练方案',
  '演练影响预判及授权',
  '演练验证及问题跟进',
  '归档',
];

export const ARCH_EVALUATION = [
  {
    name: 'SLB',
    info: '多可用区SLB实例',
    id: 'SLB',
  },
  {
    name: '应用层',
    info: 'ECS多可用区部署，相关应用多可用区部署',
    id: '应用层',
  },
  {
    name: intl('ahas_sentinel.systemGuard.flowControl.database'),
    info: '以RDS为例，实例为多可用区部署',
    id: intl('ahas_sentinel.systemGuard.flowControl.database'),
  },
  {
    name: '缓存',
    info: '以Redis为例，实例为多可用区部署',
    id: '缓存',
  },
  {
    name: '应用设计',
    info: '',
    id: '应用设计',
  },
];

export const MONITORING_EVALUATION = [
  {
    name: 'SLB指标监控',
    info: '关注其后端健康/异常ECS实例数等',
    id: 'SLB指标监控',
    defaultCheckd: true,
  },
  {
    name: '数据库指标监控',
    info: '以RDS为例，关注连接数信息、实例的IOPS等',
    id: '数据库指标监控',
    defaultCheckd: true,
  },
  {
    name: '缓存指标监控',
    info: '以Redis为例，关注连接数信息、请求数信息（QPS）等',
    id: '缓存指标监控',
    defaultCheckd: true,
  },
  {
    name: '核心业务指标监控',
    info: '监控需覆盖核心业务指标的总量、成功量等',
    id: '核心业务指标监控',
    defaultCheckd: false,
  },
];

export const DEGREE = [
  {
    label: '紧急',
    value: 1,
  },
  {
    label: '一般',
    value: 2,
  },
];

export const STATUS = [
  {
    label: '待处理',
    value: 0,
  },
  {
    label: '处理中',
    value: 1,
  },
  {
    label: '已完成',
    value: 2,
  },
];

