export const MQ_EXPERIMENT_STEPS = [
  '选择演练组件',
  '选择演练方案',
  '演练影响预判',
  '演练验证',
  '归档',
];

export const CREATE_EXPERIMENT_STEP = [
  {
    name: 'RocketMQ',
    label: 'Apache',
    imgUrl: 'https://img.alicdn.com/tfs/TB1V7BCsDM11u4jSZPxXXahcXXa-16-16.svg',
    id: 'rocketmq1',
    disabled: false,
  },
  {
    name: 'Kafka',
    label: 'Apache',
    imgUrl: 'https://img.alicdn.com/tfs/TB1hLE8oCslXu8jSZFuXXXg7FXa-16-16.svg',
    id: 'kafka1',
    disabled: true,
  },
  {
    name: 'RabbitMQ',
    label: '',
    imgUrl: 'https://img.alicdn.com/tfs/TB1sqrH3oH1gK0jSZSyXXXtlpXa-12-12.svg',
    id: 'rabbitmq1',
    disabled: true,
  },
  {
    name: 'RocketMQ',
    label: '阿里云',
    imgUrl: 'https://img.alicdn.com/tfs/TB1jNYrpkcx_u4jSZFlXXXnUFXa-200-200.svg',
    id: 'rocketmq4',
    disabled: true,
  },
  {
    name: 'Kafka',
    label: '阿里云',
    imgUrl: 'https://img.alicdn.com/tfs/TB136fJ3oY1gK0jSZFMXXaWcVXa-200-200.svg',
    id: 'kafka4',
    disabled: true,
  },
  {
    name: 'RabbitMQ',
    label: '阿里云',
    imgUrl: 'https://img.alicdn.com/tfs/TB1ipdpm4vbeK8jSZPfXXariXXa-200-200.svg',
    id: 'rabbitmq4',
    disabled: true,
  },
];

export const MQ_NAMESPACE = [
  {
    label: 'ECS 主机',
    value: 1,
  },
  {
    label: 'Kubernetes',
    value: 2,
  },
  {
    label: '阿里云环境',
    value: 4,
  },
];
