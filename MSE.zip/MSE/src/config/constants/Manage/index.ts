export * from './AgentSetting';

export const breadCrumbConf = {
  ahaos: {
    key: 'scope/control',
    value: '探针管理',
    path: '/chaos/experiment/scope/control',
  },
  manage: {
    key: 'setting',
    value: '探针管理',
    path: '/manage/setting',
  },
};
