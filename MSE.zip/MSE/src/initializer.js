import intl from '@ali/wind-intl';
import messages from './locales/messages';

intl.set({
  messages,
});

