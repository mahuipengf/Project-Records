import React, { useEffect, useState, Component, useMemo } from 'react';
import { router } from 'dva';
import { get, isEmpty } from 'lodash';
import { useStateStore, useDispatchStore } from './store';
import services from 'utils/services';
import { timeFmt } from 'utils/time';

// msc
import Home from 'pages/msc/Home';
import { AppList, AppAccessType, AppSub } from 'pages/msc/App';
import { K8sClusterList, K8sClusterInfo } from 'pages/msc/K8sCluster';
import { MockList, MstMockList } from 'pages/msc/Mock';
import { RouteTagList } from 'pages/msc/Route';
import { LosslessList } from 'pages/msc/Lossless';
import { AuthenticationList } from 'pages/msc/Authentication';
import { OutilierEjectionList, OutilierEjectionNew } from 'pages/msc/OutlierEjection';
import { EventCenterList } from 'pages/msc/EventCenter';
import { ServiceList, ServiceTestList, ServiceTestInfo, ServiceTestQueryList } from 'pages/msc/Service';
import { FullLinkGrayscaleList } from 'pages/msc/FullLinkGrayscale';
import { SwimminLaneMonitorList } from 'pages/msc/FullLinkGrayscale/SwimminLaneMonitorList';
import AppProtectList from 'pages/msc/Ahas/AhasProtectList';
// import AppConfigList from 'pages/msc/Ahas/AhasConfigList';
import AhasAlarm from 'pages/msc/Ahas/AhasAlarm';
// import AhasIngressNginx from 'pages/msc/Ahas/AhasIngressNginx';
import AhasJavaGateway from 'pages/msc/Ahas/AhasJavaGateway';
import AhasMonitorDashboard from 'pages/msc/Ahas/AhasMonitorDashboard';
import Authentication from './pages/msc/Ahas/AppList/AppListSub/FlowGovernment/Authentication/AuthenticationSecure';

// AHAS
import { LogSet, WhiteScreenDiagnosisRule, AccessLogMarket, WhiteScreenDiagnosis } from 'pages/ahas';
import AppListSub from './pages/msc/Ahas/AppList/AppListSub';

// mst
import { ServiceStressList, ServiceStressInfo, ServiceRegressionList, ServiceInspectionList, ServiceWarnningList, ServiceFlowBoxList, ServiceStressEdit, ServiceRegressionEdit, ServiceRecordDetail, ServiceRepeatDetail, ServicePerformanceRecordDetail, ServiceRegressionSetList, ServiceRegressionSetDetail } from 'pages/mst';
import intl from '@ali/wind-intl';
import { IS_SAU_BUSINESS } from 'constants/index.js';

const MscRouter = ({ location }) => {
  const aliyunSite = aliwareGetCookieByKeyName('aliyun_site') || 'CN';
  const state = useStateStore();
  const dispatch = useDispatchStore();
  let openHref = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn';
  let rechargeHref = 'https://usercenter24service.aliyun.com/finance/fund-management/recharge';
  let openEnterpriseHref = 'https://common-buy.aliyun.com/?commodityCode=mse_basic_public_cn';
  const { Switch, Route, Router, Redirect } = router;
  if (aliyunSite === 'INTL') {
    openHref = 'https://common-buy-intl.alibabacloud.com/?commodityCode=mse_basic_public_intl';
    rechargeHref =
      'https://usercenter2-intl.aliyun.com/renew/manual?spm=5176.mse-ops.top-nav.ditem-ren.36c3142fCQOCud&expiresIn=&commodityCode=';
  }

  useEffect(() => {
    fetchState();
  }, []);

  const dateFmt = (s) => {
    if (!(s > 0)) return 0;
    return parseInt((s / 1000) / 3600 / 24, 10);
  };

  const renderAppListSub = (props) => {
    return useMemo(() => {
      return <AppListSub {...props} message={message()} />;
    }, []);
  };
  const fetchState = async () => {
    const data = await services.GetUserStatus({
      params: { Region: window.regionId },
      ignoreError: true,
    });
    if (!data) return;
    if (data.Status === 0) {
      data.TimeLeft = dateFmt(new Date('2021-07-02 00:00:00') - new Date(timeFmt(Date.now(), 'YYYY-MM-DD 00:00:00')));
    }
    dispatch({ type: 'MscAccount', payload: data });
  };

  const message = (test) => {
    const Status = get(state, 'MscAccount.Status');
    const Version = get(state, 'MscAccount.Version');
    const TimeLeft = get(state, 'MscAccount.TimeLeft', 0);

    const pathname = get(location, 'pathname');
    // 无损上下线上线测试message
    if (test === 'losslessTest') {
      return {
        type: 'notice',
        text: intl.html('mse.msc.router.message.lossless'),
      };
    }
    // 全链路灰度
    // if (test === 'grayscaleTest') {
    //   return {
    //     type: 'notice',
    //     text: intl.html('mse.msc.router.message.grayscale'),
    //   };
    // }

    // 服务压测
    if (test === 'stress') {
      return [
        {
          type: 'notice',
          text: intl.html('mse.msc.router.message.stress'),
        },
        {
          type: 'notice',
          text: intl.html('mse.msc.automated_regression.notice')
        },
      ]
    }
    
    //
    if (Status === 0 && TimeLeft > 0) {
return {
      type: 'warning',
      text: <div>
        {intl.html('mse.msc.router.message.publisc.free.one')}<span style={{ color: 'red' }}>{TimeLeft}</span>{intl.html('mse.msc.router.message.publisc.free.two')}
      </div>
    };
}
    if (pathname === '/msc/home' || pathname === '/msc/app') {
      /* 公测过期 */
      if (Status === 0 && TimeLeft === 0) {
return {
        type: 'warning',
        text: intl.html('mse.msc.router.message.publisc.expired'),
      };
}
      /* 新用户 */
      if (Status === 1) {
return {
        type: 'notice',
        text: intl.html('mse.msc.router.message.new.user', { openHref })
      };
}
      /* 企业版用户 */
      // if (Status === 2 && Version !== 2) {
      //   return {
      //           type: 'notice',
      //           text: intl.html('mse.msc.router.message.new.user.enterprise', { openHref: openEnterpriseHref })
      //         };
      //   }
      /* 欠费停机 */
      if (Status === 3) {
return {
        type: 'notice',
        text: intl.html('mse.msc.router.message.owe.shutdown', { rechargeHref }),
      };
    }
   }
  };

  return (
    <React.Fragment>
      <Switch>
        <Route path="/msc/home" component={(props) => <Home {...props} message={message()} />} />
        <Route path="/msc/appList/accessType" component={(props) => <AppAccessType {...props} message={message()} />} />
        <Route path="/msc/app/info" component={(props) => <AppSub {...props} message={message()} />} />
        <Route path="/msc/app" component={(props) => <AppList {...props} message={message()} />} />
        <Route path="/msc/service" component={(props) => <ServiceList {...props} message={message()} />} />
        <Route path="/msc/services/test/info" component={(props) => <ServiceTestInfo {...props} message={message()} />} />
        <Route path="/msc/services/query" component={(props) => <ServiceTestInfo {...props} message={message()} />} />
        <Route path="/msc/services/test" component={(props) => <ServiceTestList {...props} message={message()} />} />
        <Route path="/msc/services/stress/info" component={(props) => <ServiceStressInfo {...props} message={message()} />} />
        <Route path="/msc/services/stress" component={(props) => <ServiceStressList {...props} message={message} />} />
        <Route path="/msc/services/stressEdit" component={(props) => <ServiceStressEdit {...props} message={message()} />} />
        <Route path="/msc/services/warnningList" component={(props) => <ServiceWarnningList {...props} message={message()} />} />
        <Route path="/msc/services/inspectionList" component={(props) => <ServiceInspectionList {...props} message={message()} />} />
        <Route path="/msc/services/regression" component={(props) => <ServiceRegressionList {...props} message={message()} />} />
        <Route path="/msc/services/regressionEdit" component={(props) => <ServiceRegressionEdit {...props} message={message()} />} />
        <Route path="/msc/services/regressionSetList" component={(props) => <ServiceRegressionSetList {...props} message={message()} />} />
        <Route path="/msc/services/regressionSetDetail" component={(props) => <ServiceRegressionSetDetail {...props} message={message()} />} />
        <Route path="/msc/services/flowbox" component={(props) => <ServiceFlowBoxList {...props} message={message()} />} />
        <Route path="/msc/services/recordDetail" component={(props) => <ServiceRecordDetail {...props} message={message()} />} />
        <Route path="/msc/services/performanceRecordDetail" component={(props) => <ServicePerformanceRecordDetail {...props} message={message()} />} />
        <Route path="/msc/services/repeatDetail" component={(props) => <ServiceRepeatDetail {...props} message={message()} />} />
        <Route path="/msc/route/tag" component={(props) => <RouteTagList {...props} message={message()} />} />
        <Route path="/msc/appList/info" component={(props) => renderAppListSub(props)} />
        <Route path="/msc/appList" component={(props) => <AppProtectList {...props} message={message()} />} />
        {/* <Route path="/msc/config" component={(props) => <AppConfigList {...props} message={message()} />} /> */}
        <Route path="/msc/alarm" component={(props) => <AhasAlarm {...props} message={message()} />} />
        <Route path="/msc/javaGateway" component={(props) => <AhasJavaGateway {...props} message={message()} />} />
        <Route path="/msc/monitorDashboard" component={(props) => <AhasMonitorDashboard {...props} message={message()} />} />
        {/* <Route path="/msc/sentinel/ingressNginx" component={(props) => <AhasIngressNginx {...props} message={message()} />} /> */}
        <Route path="/msc/lossless" component={(props) => <LosslessList {...props} message={message} />} />
        <Route path="/msc/secure/authentication" component={(props) => <Authentication {...props} message={message()} />} />
        <Route path="/msc/authentication" component={(props) => <AuthenticationList {...props} message={message()} />} />
        <Route path="/msc/outlierEjection/new" component={(props) => <OutilierEjectionNew {...props} message={message()} />} />
        <Route path="/msc/outlierEjection" component={(props) => <OutilierEjectionList {...props} message={message()} />} />
        <Route path="/msc/eventCenter" component={(props) => <EventCenterList {...props} message={message()} />} />
        <Route path="/msc/mstMock" component={(props) => <MstMockList {...props} message={message()} />} />
        <Route path="/msc/mock" component={(props) => <MockList {...props} message={message()} />} />
        <Route path="/msc/grayscale" component={(props) => <FullLinkGrayscaleList {...props} message={message()} />} />
        <Route path="/msc/monitor" component={(props) => <SwimminLaneMonitorList {...props} message={message()} />} />
        <Route path="/msc/k8s/info" component={(props) => <K8sClusterInfo {...props} message={message()} />} />
        <Route path="/msc/k8s" component={(props) => <K8sClusterList {...props} message={message()} />} />
        <Route path="/msc/whiteScreenDiagnosisRule" component={(props) => <WhiteScreenDiagnosisRule {...props} message={message()} />} />
        <Route path="/msc/log" component={(props) => <WhiteScreenDiagnosisRule {...props} message={message()} />} />
        <Route path="/msc/logSet" component={(props) => <LogSet {...props} message={message()} />} />
        <Route path="/msc/accessLogMarket" component={(props) => <AccessLogMarket {...props} message={message()} />} />
        <Route path="/msc/whiteScreenDiagnosis" component={(props) => <WhiteScreenDiagnosis {...props} message={message()} />} />
        <Route path="/msc" component={(props) => <Home {...props} message={message()} />} />
      </Switch>
    </React.Fragment>
  );
};

export default MscRouter;
