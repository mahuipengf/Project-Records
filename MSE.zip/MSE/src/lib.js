import React, { useState } from 'react';
import { Button, Input, Message, Icon } from '@ali/wind';
import { Dialog } from '@alicloud/console-components';
import { get, includes, isEmpty } from 'lodash';
import intl from '@ali/wind-intl';
import { IS_SAU_BUSINESS } from 'constants/index.js';
import { CopyContent } from '@ali/mamba';

window.regionList = []; //默认region

/** oneconsole 异常码 */
window.REGION_NAME_MAP = {
  'cn-hangzhou': intl('mse.register.region.hangzhou'),
  'cn-shanghai': intl('mse.register.region.shanghai'),
  'cn-qingdao': intl('mse.register.region.qingdao'),
  'cn-beijing': intl('mse.register.region.beijing'),
  'cn-zhangjiakou': intl('mse.register.region.zhangjiakou'),
  'cn-huhehaote': intl('mse.register.region.huhehaote'),
  'cn-wulanchabu': intl('mse.register.region.wulanchabu'),
  'cn-shenzhen': intl('mse.register.region.shenzhen'),
  'cn-heyuan': intl('mse.register.region.heyuan'),
  'cn-guangzhou': intl('mse.register.region.chengdu'),
  'cn-hongkong': intl('mse.register.region.hongkong'),
  'cn-fuzhou': intl('mse.register.region.fuzhou'),
  'ap-northeast-1': intl('mse.register.region.japan.tokyo'),
  'ap-northeast-2': intl('mse.register.region.southKorea.seoul'),
  'ap-southeast-1': intl('mse.register.region.singapore'),
  'ap-southeast-2': intl('mse.register.region.australia.sydney'),
  'ap-southeast-3': intl('mse.register.region.malaysia.kualaLumpur'),
  'ap-southeast-5': intl('mse.register.region.indonesia.jakarta'),
  'ap-southeast-6': intl('mse.register.region.philippines.manila'),
  'ap-southeast-7': intl('mse.register.region.thailand.bangkok'),
  'ap-south-1': intl('mse.register.region.india.mumbai'),
  'eu-central-1': intl('mse.register.region.germany.frankfurt'),
  'eu-west-1': intl('mse.register.region.uk.london'),
  'us-west-1': intl('mse.register.region.us.silicon.valley'),
  'us-east-1': intl('mse.register.region.us.virginia'),
  'me-central-1': intl('mse.register.region.sau.riyadh'),
};

/**
 * 引擎菜单列表
 */
window.CLUSTER_NAME_MAP = {
  ZooKeeper: {
    name: intl('mse.register.data'),
    label: 'ZooKeeper',
    visible: true, // 是否展示
  },
  Eureka: {
    name: intl('mse.register.service'),
    label: 'Eureka',
    visible: true,
  },
  'Nacos-Ans': {
    name: intl('mse.register.service'),
    label: 'Nacos',
    visible: true,
  },
  'Diamond-Over-Nacos2': {
    name: intl('mse.register.service'),
    label: 'Diamond-Over-Nacos2',
    visible: false,
  },
};

/**列表页及基本详情页状态映射 */
window.STATUS_MAP = {
  SCALE_ING: { name: intl.html('mse.register.state.loading'), icon: 'loading' },
  SCALE_SUCCESS: { name: intl('mse.register.state.running'), icon: 'select', color: 'green' },
  SCALE_FAILED: { name: intl('mse.register.state.restart_faile'), icon: 'warning', color: 'red' },
  INIT_ING: { name: intl.html('mse.register.state.loading'), icon: 'loading' },
  INIT_FAILED: { name: intl('mse.register.state.resume'), icon: 'warning', color: 'red' },
  INIT_SUCCESS: { name: intl('mse.register.state.running'), icon: 'select', color: 'green' },
  INIT_TIME_OUT: { name: intl('mse.register.state.create_timeout'), icon: 'warning', color: 'red' },
  DESTROY_ING: { name: intl('mse.register.state.destroying'), icon: 'loading' },
  DESTROY_FAILED: { name: intl('mse.register.state.destroy_faile'), icon: 'warning', color: 'red' },
  DESTROY_SUCCESS: { name: intl('mse.register.state.destroyed'), icon: 'select', color: 'green' },
  Success: { name: intl('mse.register.state.running'), icon: 'select', color: 'green' },
  Fail: { name: intl('mse.register.state.resume'), icon: 'warning', color: 'red' },
  RUNNING: { name: intl('mse.register.state.running'), icon: 'select', color: 'green' },
  Running: { name: intl('mse.register.state.running'), icon: 'select', color: 'green' },
  FAILED: { name: intl('mse.register.state.getting_status'), icon: 'warning', color: 'red' },
  Failed: { name: intl('mse.register.state.resume'), icon: 'warning', color: 'red' },
  Pending: { name: intl('mse.register.state.create'), icon: 'loading' },
  RESTART_ING: { name: intl('mse.register.state.restart'), icon: 'loading' },
  RESTART_SUCCESS: { name: intl('mse.register.state.running'), icon: 'select', color: 'green' },
  RESTART_FAILED: { name: intl('mse.register.state.restart_faile'), icon: 'warning', color: 'red' },
  STOPED: { name: intl('mse.register.state.stopped'), icon: 'warning', color: 'red' },
};

/**错误映射 */
const errorEnum = {
  noPermission: {
    code: 'NoPermission',
    message: intl('mse.common.nopermission'),
  },
  invalidParameter: {
    code: 'InvalidParameter',
    message: intl('mse.common.invalid_param'),
  },
  illegalRequest: {
    code: 'IllegalRequest',
    message: intl('mse.common.illegal_req'),
  },
  notFound: {
    code: 'NotFound',
    message: intl('mse.common.not_found'),
  },
  internalError: {
    code: 'InternalError',
    message: intl('mse.common.internal_err'),
  },
  serviceNotOpen: {
    code: 'MseServiceNotOpen',
    url: intl('mse.common.service_not_open'),
  },
  serviceUnavailable: {
    code: 'ServiceUnavailable',
    message: intl('mse.common.service_unavailable'),
  },
  needLogin: {
    code: 'ConsoleNeedLogin',
    url: 'https://account.aliyun.com/login/login.htm?oauth_callback=',
  },
  needBuy: {
    code: 'RedirectToCommonBuy',
    url: intl('mse.common.service_not_open'),
  },
  openAHASServiceFailed: {
    code: 'OpenAHASServiceFailed',
    message: intl('mse.errormessage.ahas_failed'),
  },
  demoNoOpt: {
    code: 'demo.not.support.operation',
  },
  postonlyOrTokenError: {
    code: 'PostonlyOrTokenError',
  },
  changeRegionError: {
    code: 'SERVER_ERROR_CODE',
    message: intl('mse.errormessage.region'),
  },
  verifyCodeInvalid: {
    code: 'verifyCodeInvalid',
    message: intl('mse.errormessage.code_invalid'),
  },
  missingClusterId: {
    code: 'MissingClusterId',
    message: intl('mse.errormessage.miss_clusterid'),
  },
  riskShow: {
    code: 'FoundRiskAndDoubleConfirm',
  },
};

/**公共region 方法 */
window.publicRegion = (() => {
  class RegionBar {
    constructor(props) {
      window.regionId =
        window.getParams('region') ||
        (window.aliwareGetCookieByKeyName && window.aliwareGetCookieByKeyName('currentRegionId')) ||
        (IS_SAU_BUSINESS ? 'me-central-1' : 'cn-hangzhou');
      window.addEventListener('message', this.handleAliyunNav);
      // setTimeout(() => { // 顶栏监听的滞后，延长1s 后发送消息。
      //   this.changeRegionBarRegionId(window.regionId);
      // }, 1000);
    }
    handleAliyunNav(event) {
      const { data = {} } = event;
      const { type } = data;
      const { payload = {} } = data; // { fromRegionId: 'xxx', toRegionId: 'xxx'' }
      switch (type) {
        case 'CONSOLE_REGION_CHANGE':
          window.location.reload();
          break;
        default:
          break;
      }
    }
    getRegionList = () => {
      window.request({
        url: 'com.alibaba.MSE.service.QueryBusinessLocations',
        product: 'mse',
        async: false,
        data: {},
        success: (res) => {
          const { Data = [] } = res.data;
          const financeRegions = [
            'cn-shanghai-finance-1',
            'cn-shenzhen-finance-1',
            'cn-beijing-finance-1',
          ];
          const govRegions = ['cn-north-2-gov-1'];
          let regionList = Data.map((item) => {
            const regionName = item.ShowName;
            return {
              regionName,
              regionId: item.Name,
            };
          });
          if (window.ALIYUN_CONSOLE_CONFIG.CHANNEL) {
            switch (window.ALIYUN_CONSOLE_CONFIG.CHANNEL) {
              case 'OFFICIAL': {
                regionList = _.filter(
                  regionList,
                  (item) =>
                    !_.includes(financeRegions, item.regionId) &&
                    !_.includes(govRegions, item.regionId)
                );
                break;
              }
              case 'FINANCE': {
                regionList = _.filter(regionList, (item) =>
                  _.includes(financeRegions, item.regionId)
                );
                break;
              }
              case 'BJ_GOV': {
                regionList = _.filter(regionList, (item) => _.includes(govRegions, item.regionId));
                break;
              }
              case 'vco_mpkintl_saudijv':
              case 'vco_mpkintl_saudijv01':
              case 'vco_mpkintl_saudijv02':
              case 'vco_mpkintl_saudijv03':
              case 'ali_testforJV': {
                regionList.push({ regionName: 'SAU (Riyadh)', regionId: 'me-central-1' });
                break;
              }
              default: {
                regionList = _.filter(
                  regionList,
                  (item) =>
                    !_.includes(financeRegions, item.regionId) &&
                    !_.includes(govRegions, item.regionId)
                );
                break;
              }
            }
          }

          window.ALIYUN_CONSOLE_CONFIG.STATIC_API.regions = regionList;
          window.regionList = regionList;
          const regionIdArray = regionList.map((item) => {
            return item.regionId;
          });
          if (!regionIdArray.includes(window.regionId)) {
            // window.regionId = regionIdArray[0]; //判断当前regionId 是否在可用区，不在则默认置设置成首个
            window.regionId = IS_SAU_BUSINESS ? 'me-central-1' : regionIdArray[0];
          }
        },
      });
    };
    // changeRegionBarRegionId = regionId => {
    //   window.regionId = regionId;
    //   window.viewframeSetting && (window.viewframeSetting.defaultRegionId = regionId);
    //   window.postMessage(
    //     { type: 'SET_ACTIVE_REGION_ID', payload: { defaultRegionId: regionId } },
    //     window.location
    //   );
    // };
  }
  return new RegionBar();
})();
// const handleAliyunNav = event => {
//   const { data = {} } = event;
//   const { type } = data;
//   const { payload = {} } = data; // { fromRegionId: 'xxx', toRegionId: 'xxx'' }

//   switch (type) {
//     case 'CONSOLE_REGION_CHANGE':
//       window.location.reload();
//       break;

//     default:
//       break;
//   }
// };
// window.addEventListener('message', handleAliyunNav);
/**
 * oneconsole异常码处理
 */
const consoleExpHanlder = {
  //子账号无权限
  [errorEnum.noPermission.code]: (data, options, res) => {
    window.showErrorMessage(res.message || errorEnum.noPermission.message, options, res);
  },
  //非法参数
  [errorEnum.invalidParameter.code]: (data, options, res) => {
    window.showErrorMessage(res.message || errorEnum.invalidParameter.message, options, res);
  },
  //请求非法：参数越权、用法错误
  [errorEnum.illegalRequest.code]: (data, options, res) => {
    window.showErrorMessage(res.message || errorEnum.illegalRequest.message, options, res);
  },
  //找不到集群
  [errorEnum.notFound.code]: (data, options, res) => {
    window.showErrorMessage(res.message || errorEnum.notFound.message, options, res);
  },
  //兜底错误
  [errorEnum.internalError.code]: (data, options, res) => {
    window.showErrorMessage(res.message || errorEnum.internalError.message, options, res);
  },
  //需要开通
  [errorEnum.serviceNotOpen.code]: () => {
    window.location.href = errorEnum.serviceNotOpen.url;
  },
  // // 服务不可用
  [errorEnum.serviceUnavailable.code]: (data, options, res) => {
    window.showErrorMessage(res.message || errorEnum.serviceUnavailable.message, options, res);
  },
  // 跳转登陆页
  [errorEnum.needLogin.code]: () => {
    window.location.href = errorEnum.needLogin.url + window.location.href;
  },
  // 跳转购买页
  [errorEnum.needBuy.code]: () => {
    window.location.href = errorEnum.needLogin.url + window.location.href;
  },
  // 服务开通失败
  [errorEnum.openAHASServiceFailed.code]: () => {
    Message.warning({
      content: errorEnum.openAHASServiceFailed.message,
      style: { marginTop: '50px' },
      animation: false,
      duration: 4000,
    });
  },
  // token 过期处理
  [errorEnum.postonlyOrTokenError.code]: () => {
    window.reloadDialog(intl('mse.errormessage.token_error'));
  },
  [errorEnum.missingClusterId.code]: () => {
    window.showErrorMessage(intl('mse.errormessage.miss_clusterid'));
  },
  [errorEnum.verifyCodeInvalid.code]: () => {
    window.showErrorMessage(errorEnum.verifyCodeInvalid.message);
  },
  [errorEnum.riskShow.code]: (data, options) => {
    const { codeType, verifyDetail, verifyType } = data;
    let customInputCode = '';
    let msgRequestId = '';
    let dialogIns;

    const sendVerifyMsg = () => {
      const ele = $('.msg-verify-getcode');
      let restSec = 60;

      ele.text(intl.html('mse.errormessage.few_sec_refetch'));
      ele.attr('disabled', true);

      const resetSecInterval = setInterval(() => {
        restSec--;

        ele.text(intl.html('mse.errormessage.few_sec_refetch'));
        ele.attr('disabled', true);

        if (restSec <= 0) {
          ele.text(intl('mse.common.get_code'));
          ele.attr('disabled', false);
          clearInterval(resetSecInterval);
        }
      }, 1000);
      window.request({
        url: '/risk/sendVerifyMessage.json',
        type: 'post',
        data: {
          sec_token: window.ALIYUN_CONSOLE_CONFIG.SEC_TOKEN,
          codeType, //这个参数是由风控返回的，不要写死。
          verifyType, // sms短信 email邮箱，ga,这个参数是由风控返回的，不要写死。
          umid: window.RISK_INFO ? window.RISK_INFO.UMID : 'aliyun_umid',
          collina: window.RISK_INFO ? window.RISK_INFO.GETUA() : 'aliyun_collina',
        },
        success: (res) => {
          const { data = {} } = res;
          msgRequestId = data.requestId;
        },
      });
    };

    const resendRequst = () => {
      const verifyCode = $('.msg-verify-input input').val().trim();

      if (verifyCode) {
        _.assign(options.data, {
          verifyCode: customInputCode,
          verifyType,
          requestId: msgRequestId,
        });
        options.success = (res) => {
          dialogIns.hide();
          options.success(res);
        };
        window.request(options);
      } else {
        $('.msg-verify-error-tip').show();
      }
    };

    const style = {
      width: 380,
      fontSize: 12,
      lineHeight: '24px',
      marginTop: 8,
    };

    const inlineStyle = {
      display: 'inline-block',
      width: 120,
      marginRight: 10,
      textAlign: 'right',
    };

    let contentTip;
    if (verifyType === 'ga') {
      contentTip = (
        <span>
          <span style={inlineStyle}>{intl('mse.common.verify_mfa')}</span>
        </span>
      );
    } else {
      contentTip = (
        <span>
          <span style={inlineStyle}>{intl.html('mse.common.verifytype_choose')}</span>
          <strong style={{ fontSize: 18, marginRight: 13 }}>{verifyDetail}</strong>
        </span>
      );
    }

    const content = (
      <div style={style}>
        <div style={{ marginBottom: 10 }}>
          {contentTip}
          <a target="_blank" href="https://account.console.aliyun.com">
            {intl('mse.common.change_verify_method')}
          </a>
        </div>

        <div>
          <span style={inlineStyle}>{intl('mse.common.verify_code')}</span>

          <Input
            className="msg-verify-input"
            onChange={(val) => {
              customInputCode = val;
              customInputCode && $('.msg-verify-error-tip').hide();
            }}
            trim
            style={{ width: 100, marginRight: 10 }}
          />
          {verifyType !== 'ga' && (
            <Button onClick={sendVerifyMsg} className="msg-verify-getcode">
              {intl('mse.common.get_code')}
            </Button>
          )}
          <div
            className="msg-verify-error-tip"
            style={{ paddingLeft: 110, color: 'red', display: 'none' }}
          >
            {intl('mse.common.verify_code_input')}
          </div>
        </div>
      </div>
    );

    const footer = (
      <div>
        <Button onClick={resendRequst} type="primary">
          {intl('mse.errormessage.confirm')}
        </Button>
        <Button
          onClick={() => {
            dialogIns.hide();
          }}
          style={{ marginLeft: 10 }}
        >
          {intl('mse.common.cancel')}
        </Button>
      </div>
    );

    dialogIns = Dialog.show({
      title: intl.html('mse.common.dialogins_title'),
      content,
      footer,
    });
  },
  // demo示例下无权限操作
  [errorEnum.demoNoOpt.code]: (res) => {
    Message.warning({
      content: res.message,
      style: { marginTop: '50px' },
      animation: false,
      duration: 4000,
    });
  },
  // 还有找到对应的region信息
  [errorEnum.changeRegionError.code]: () => {
    Message.warning({
      content: errorEnum.changeRegionError.message,
      animation: false,
      duration: 4000,
      align: 'cc cc',
    });
  },
};

window.reloadDialog = function reloadDialog(content) {
  const dialogRef = Dialog.alert({
    content,
    footer: (
      <div>
        <Button type={'primary'} className={'mr-4'} onClick={() => window.location.reload()}>
          {intl('mse.common.reload_page')}
        </Button>
        <Button type={'normal'} onClick={() => dialogRef.hide()}>
          {intl('mse.common.cancel')}
        </Button>
      </div>
    ),
    language: aliwareIntl.currentLanguageCode,
  });
};
// window.getRegionList = () => {
//   window.request({
//     url: 'com.alibaba.MSE.service.QueryBusinessLocations',
//     special: true,
//     product: 'mse',
//     async: false,
//     data: {},
//     success: res => {
//       const { Data = [] } = res.data;
//       const regionList = Data.map(item => {
//         return {
//           regionId: item.name,
//           regionName: item.showName,
//         };
//       });
//       window.ALIYUN_CONSOLE_CONFIG.STATIC_API.regions = regionList;
//       window.regionList = regionList;
//       //window.ALIYUN_CONSOLE_CONFIG.STATIC_API.regions = regionList;
//       //window.viewframeSetting.regionList = regionList;
//     },
//   });
// };

const ErrorComp = ({ content, options, res }) => {
  const [isShow, setIsShow] = useState(false);
  const errorMessage = {
    requestUrl: `${window.location.origin}/${options.url}` || '',
    product: get(options, 'data.product') || '',
    requestId: res.requestId || res.RequestId || '',
    params: get(options, 'data.params') || '',
  };
  return (
    <div style={{ lineHeight: '20px', minWidth: 460 }}>
      <div>{content}</div>
      <If condition={options && res}>
        <CopyContent text={JSON.stringify(errorMessage)} visibility>
          <div style={{ display: 'inline' }}>
            <span>
              {intl('mse.common.error_detail')}
              <span style={{ color: '#0077cc' }}>{res && res.code}</span>）
            </span>
            <Icon
              size="xs"
              type="arrow-down"
              onClick={() => setIsShow(!isShow)}
              style={{
                transform: isShow ? 'rotate(0deg)' : 'rotate(-90deg)',
                cursor: 'pointer',
                transition: 'transform 0.3s cubic-bezier(0.23, 1, 0.32, 1)',
                color: '#999',
              }}
            />
          </div>
        </CopyContent>
      </If>
      <If condition={isShow}>
        <div style={{ lineHeight: '20px' }}>
          <If condition={get(options, 'url')}>
            <div>requestUrl: {`${window.location.origin}/${options.url}`}</div>
          </If>
          <If condition={get(options, 'data.product')}>
            <div>product: {get(options, 'data.product')}</div>
          </If>
          <If condition={!!res.requestId}>
            <div>requestId: {res.requestId}</div>
          </If>
          <If condition={get(options, 'data.params')}>
            <div>params: {get(options, 'data.params')}</div>
          </If>
        </div>
      </If>
    </div>
  );
};

window.showErrorMessage = function showErrorMessage(content, options, res) {
  if (!window.dialogRef) {
    window.dialogRef = Dialog.alert({
      content: <ErrorComp content={content} options={options} res={res} />,
      title: intl('mse.errormessage.wrong'),
      footer: (
        <div>
          <Button
            type={'primary'}
            onClick={() => {
              window.dialogRef.hide();
              window.dialogRef = null;
            }}
          >
            {intl('mse.errormessage.confirm')}
          </Button>
        </div>
      ),
      onClose: () => {
        window.dialogRef.hide();
        window.dialogRef = null;
      },
      language: aliwareIntl.currentLanguageCode,
    });
  }
};
const mseRequest = window.request;
const { serviceList = [] } = mseRequest;
const serviceMap = {};
serviceList.forEach((item) => {
  serviceMap[item.registerName] = item;
});
window.ALIYUN_CONSOLE_CONFIG = window.ALIYUN_CONSOLE_CONFIG || {};

mseRequest
  .middleWare((config) => {
    const { data, url } = config;
    const serviceObj = serviceMap[url] || {};
    const { action } = serviceObj;
    const regionId = window.regionId;

    config.type = 'post';
    const sec_token = window.ALIYUN_CONSOLE_CONFIG.SEC_TOKEN;
    const defaultRegionId = IS_SAU_BUSINESS ? 'me-central-1' : 'cn-hangzhou';
    let consoleData = {
      action,
      product: 'mse',
      sec_token,
      umid: window.RISK_INFO ? window.RISK_INFO.UMID : 'aliyun_umid',
      collina: window.RISK_INFO ? window.RISK_INFO.GETUA() : 'aliyun_collina',
      region:
        (process.env.NODE_ENV === 'development' || window.ALIYUN_CONSOLE_CONFIG.fEnv === 'pre') &&
        action === 'QueryBusinessLocations'
          ? defaultRegionId
          : regionId, // 预发环境只有杭州region
    };
    if (config.special) {
      consoleData.product = config.product;
      delete consoleData.region;
    }
    if (data) {
      consoleData.params = JSON.stringify(data);
    }
    if (action) {
      config.url = `data/api.json?action=${action}`;
      config.data = consoleData;
    }

    const { success, error } = config;
    config.success = (res) => {
      const { code, data = {} } = res;
      if (code === '200' && data.Success !== false) {
        success(res);
      } else {
        const handleFunc = consoleExpHanlder[code] || consoleExpHanlder[data.ErrorCode]; //捕获外部异常码或业务异常码
        if (handleFunc && typeof handleFunc === 'function') {
          handleFunc(data, config, res);
        } else if (data.Success === false && !config.noerror) {
          window.showErrorMessage(data.Message); // 业务部分的异常
        }
        typeof error === 'function' && error(res);
      }
    };
  }, false)
  .middleWare((config) => {
    const preError = config.error;
    config.error = (res) => {
      window.reloadDialog(intl('mse.errormessage.server'));
      typeof preError === 'function' && preError(res);
    };
    return config;
  }, false);
window.request = mseRequest;

window.publicRegion.getRegionList(); //获取region列表

if (!window.RISK_INFO || _.isEmpty(window.RISK_INFO)) {
  window.RISK_INFO = {
    GETUA: () => 'aliyun_collina',
    UMID: 'aliyun_umid',
  };
}
