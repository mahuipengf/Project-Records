const webpackExtends = require('./builder.extend.js');

module.exports = {
  presets: [
    [
      '@ali/breezr-preset-wind',
      {
        webpack: webpackExtends,
        useTypescript: true,
      }
    ],
  ],
};
